// 
// File:          TSTTM_MOAB_MoabMesh_Impl.hh
// Symbol:        TSTTM_MOAB.MoabMesh-v0.2
// Symbol Type:   class
// Babel Version: 0.9.8
// sidl Created:  20051011 14:26:09 GMT-06:00
// Generated:     20051011 14:26:12 GMT-06:00
// Description:   Server-side implementation for TSTTM_MOAB.MoabMesh
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.8
// source-line   = 5
// source-url    = file:/home/tjtautg/tstt/cvs/TSTTM/TSTTM_MOAB.sidl
// 

#ifndef included_TSTTM_MOAB_MoabMesh_Impl_hh
#define included_TSTTM_MOAB_MoabMesh_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_TSTTM_MOAB_MoabMesh_IOR_h
#include "TSTTM_MOAB_MoabMesh_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_TSTTB_Error_hh
#include "TSTTB_Error.hh"
#endif
#ifndef included_TSTTB_TagValueType_hh
#include "TSTTB_TagValueType.hh"
#endif
#ifndef included_TSTTM_AdjacencyInfo_hh
#include "TSTTM_AdjacencyInfo.hh"
#endif
#ifndef included_TSTTM_CreationStatus_hh
#include "TSTTM_CreationStatus.hh"
#endif
#ifndef included_TSTTM_EntityTopology_hh
#include "TSTTM_EntityTopology.hh"
#endif
#ifndef included_TSTTM_EntityType_hh
#include "TSTTM_EntityType.hh"
#endif
#ifndef included_TSTTM_StorageOrder_hh
#include "TSTTM_StorageOrder.hh"
#endif
#ifndef included_TSTTM_MOAB_MoabMesh_hh
#include "TSTTM_MOAB_MoabMesh.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._includes)
// Put additional includes or other arbitrary code here...
#include "TSTTM_MOAB.h"
// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._includes)

namespace TSTTM_MOAB { 

  /**
   * Symbol "TSTTM_MOAB.MoabMesh" (version 0.2)
   */
  class MoabMesh_impl
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    MoabMesh self;

    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._implementation)
    // Put additional implementation details here...
    TSTTM_Instance tsttmInstance;
    void processError() throw(::TSTTB::Error);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._implementation)

  private:
    // private default constructor (required)
    MoabMesh_impl() {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    MoabMesh_impl( struct TSTTM_MOAB_MoabMesh__object * s ) : self(s,
      true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~MoabMesh_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

  public:

    /**
     * user defined non-static method.
     */
    void
    load (
      /*in*/ void* entity_set_handle,
      /*in*/ const ::std::string& name
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    save (
      /*in*/ void* entity_set_handle,
      /*in*/ const ::std::string& name
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void*
    getRootSet() throw ( 
      ::TSTTB::Error
    );
    /**
     * user defined non-static method.
     */
    int32_t
    getGeometricDim() throw ( 
      ::TSTTB::Error
    );
    /**
     * user defined non-static method.
     */
    ::TSTTM::StorageOrder
    getDfltStorage() throw ( 
      ::TSTTB::Error
    );
    /**
     * user defined non-static method.
     */
    void
    getAdjTable (
      /*inout*/ ::sidl::array< ::TSTTM::AdjacencyInfo>& adjacency_table,
      /*out*/ int32_t& adjacency_table_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    areEHValid (
      /*in*/ bool reset
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getNumOfType (
      /*in*/ void* entity_set_handle,
      /*in*/ ::TSTTM::EntityType entity_type
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getNumOfTopo (
      /*in*/ void* entity_set_handle,
      /*in*/ ::TSTTM::EntityTopology entity_topology
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getAllVtxCoords (
      /*in*/ void* entity_set,
      /*inout*/ ::sidl::array<double>& coords,
      /*out*/ int32_t& coords_size,
      /*inout*/ ::sidl::array<int32_t>& in_entity_set,
      /*out*/ int32_t& in_entity_set_size,
      /*inout*/ ::TSTTM::StorageOrder& storage_order
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getVtxCoordIndex (
      /*in*/ void* entity_set,
      /*in*/ ::TSTTM::EntityType requested_entity_type,
      /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
      /*in*/ ::TSTTM::EntityType entity_adjacency_type,
      /*inout*/ ::sidl::array<int32_t>& offset,
      /*out*/ int32_t& offset_size,
      /*inout*/ ::sidl::array<int32_t>& index,
      /*out*/ int32_t& index_size,
      /*inout*/ ::sidl::array< ::TSTTM::EntityTopology>& entity_topologies,
      /*out*/ int32_t& entity_topologies_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntities (
      /*in*/ void* entity_set,
      /*in*/ ::TSTTM::EntityType entity_type,
      /*in*/ ::TSTTM::EntityTopology entity_topology,
      /*inout*/ ::sidl::array<void*>& entity_handles,
      /*out*/ int32_t& entity_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getVtxArrCoords (
      /*in*/ ::sidl::array<void*> vertex_handles,
      /*in*/ int32_t vertex_handles_size,
      /*inout*/ ::TSTTM::StorageOrder& storage_order,
      /*inout*/ ::sidl::array<double>& coords,
      /*out*/ int32_t& coords_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getAdjEntities (
      /*in*/ void* entity_set,
      /*in*/ ::TSTTM::EntityType entity_type_requestor,
      /*in*/ ::TSTTM::EntityTopology entity_topology_requestor,
      /*in*/ ::TSTTM::EntityType entity_type_requested,
      /*inout*/ ::sidl::array<void*>& adj_entity_handles,
      /*out*/ int32_t& adj_entity_handles_size,
      /*inout*/ ::sidl::array<int32_t>& offset,
      /*out*/ int32_t& offset_size,
      /*inout*/ ::sidl::array<int32_t>& in_entity_set,
      /*out*/ int32_t& in_entity_set_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    initEntArrIter (
      /*in*/ void* entity_set_handle,
      /*in*/ ::TSTTM::EntityType requested_entity_type,
      /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
      /*in*/ int32_t requested_array_size,
      /*out*/ void*& entArr_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    getNextEntArrIter (
      /*in*/ void* entArr_iterator,
      /*inout*/ ::sidl::array<void*>& entity_handles,
      /*out*/ int32_t& entity_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    resetEntArrIter (
      /*in*/ void* entArr_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    endEntArrIter (
      /*in*/ void* entArr_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntArrTopo (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*inout*/ ::sidl::array< ::TSTTM::EntityTopology>& topology,
      /*out*/ int32_t& topology_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntArrType (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*inout*/ ::sidl::array< ::TSTTM::EntityType>& type,
      /*out*/ int32_t& type_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntArrAdj (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ ::TSTTM::EntityType entity_type_requested,
      /*inout*/ ::sidl::array<void*>& adj_entity_handles,
      /*out*/ int32_t& adj_entity_handles_size,
      /*inout*/ ::sidl::array<int32_t>& offset,
      /*out*/ int32_t& offset_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setVtxCoords (
      /*in*/ void* vertex_handles,
      /*in*/ double x,
      /*in*/ double y,
      /*in*/ double z
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createVtx (
      /*in*/ double x,
      /*in*/ double y,
      /*in*/ double z,
      /*out*/ void*& new_vertex_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createEnt (
      /*in*/ ::TSTTM::EntityTopology new_entity_topology,
      /*in*/ ::sidl::array<void*> lower_order_entity_handles,
      /*in*/ int32_t lower_order_entity_handles_size,
      /*out*/ void*& new_entity_handle,
      /*out*/ ::TSTTM::CreationStatus& status
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    deleteEnt (
      /*in*/ void* entity_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setVtxArrCoords (
      /*in*/ ::sidl::array<void*> vertex_handles,
      /*in*/ int32_t vertex_handles_size,
      /*in*/ ::TSTTM::StorageOrder storage_order,
      /*in*/ ::sidl::array<double> new_coords,
      /*in*/ int32_t new_coords_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createVtxArr (
      /*in*/ int32_t num_verts,
      /*in*/ ::TSTTM::StorageOrder storage_order,
      /*in*/ ::sidl::array<double> new_coords,
      /*in*/ int32_t new_coords_size,
      /*inout*/ ::sidl::array<void*>& new_vertex_handles,
      /*out*/ int32_t& new_vertex_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createEntArr (
      /*in*/ ::TSTTM::EntityTopology new_entity_topology,
      /*in*/ ::sidl::array<void*> lower_order_entity_handles,
      /*in*/ int32_t lower_order_entity_handles_size,
      /*inout*/ ::sidl::array<void*>& new_entity_handles,
      /*out*/ int32_t& new_entity_handles_size,
      /*inout*/ ::sidl::array< ::TSTTM::CreationStatus>& status,
      /*out*/ int32_t& status_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    deleteEntArr (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createTag (
      /*in*/ const ::std::string& tag_name,
      /*in*/ int32_t number_of_values,
      /*in*/ ::TSTTB::TagValueType tag_type,
      /*out*/ void*& tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    destroyTag (
      /*in*/ void* tag_handle,
      /*in*/ bool forced
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    ::std::string
    getTagName (
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getTagSizeValues (
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getTagSizeBytes (
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void*
    getTagHandle (
      /*in*/ const ::std::string& tag_name
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    ::TSTTB::TagValueType
    getTagType (
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<char>& value_array,
      /*out*/ int32_t& value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getIntArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<int32_t>& value_array,
      /*out*/ int32_t& value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getDblArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<double>& value_array,
      /*out*/ int32_t& value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEHArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<void*>& value_array,
      /*out*/ int32_t& value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*in*/ ::sidl::array<char> value_array,
      /*in*/ int32_t value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setIntArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*in*/ ::sidl::array<int32_t> value_array,
      /*in*/ int32_t value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setDblArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*in*/ ::sidl::array<double> value_array,
      /*in*/ int32_t value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEHArrData (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle,
      /*in*/ ::sidl::array<void*> value_array,
      /*in*/ int32_t value_array_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvArrTag (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<char>& tag_value,
      /*out*/ int32_t& tag_value_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getIntData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    double
    getDblData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void*
    getEHData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle,
      /*in*/ ::sidl::array<char> tag_value,
      /*in*/ int32_t tag_value_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setIntData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle,
      /*in*/ int32_t tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setDblData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle,
      /*in*/ double tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEHData (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle,
      /*in*/ void* tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getAllTags (
      /*in*/ void* entity_handle,
      /*inout*/ ::sidl::array<void*>& tag_handles,
      /*out*/ int32_t& tag_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvTag (
      /*in*/ void* entity_handle,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    createEntSet (
      /*in*/ bool isList,
      /*out*/ void*& entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    destroyEntSet (
      /*in*/ void* entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    isList (
      /*in*/ void* entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getNumEntSets (
      /*in*/ void* entity_set,
      /*in*/ int32_t num_hops
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntSets (
      /*in*/ void* entity_set,
      /*in*/ int32_t num_hops,
      /*inout*/ ::sidl::array<void*>& contained_entset_handles,
      /*out*/ int32_t& contained_entset_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    addEntToSet (
      /*in*/ void* entity_handle,
      /*inout*/ void*& entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvEntFromSet (
      /*in*/ void* entity_handle,
      /*inout*/ void*& entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    addEntArrToSet (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*inout*/ void*& entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvEntArrFromSet (
      /*in*/ ::sidl::array<void*> entity_handles,
      /*in*/ int32_t entity_handles_size,
      /*inout*/ void*& entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    addEntSet (
      /*in*/ void* entity_set_to_add,
      /*inout*/ void*& entity_set_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvEntSet (
      /*in*/ void* entity_set_to_remove,
      /*inout*/ void*& entity_set_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    isEntContained (
      /*in*/ void* containing_entity_set,
      /*in*/ void* entity_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    isEntSetContained (
      /*in*/ void* containing_entity_set,
      /*in*/ void* contained_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    subtract (
      /*in*/ void* entity_set_1,
      /*in*/ void* entity_set_2,
      /*out*/ void*& result_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    intersect (
      /*in*/ void* entity_set_1,
      /*in*/ void* entity_set_2,
      /*out*/ void*& result_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    unite (
      /*in*/ void* entity_set_1,
      /*in*/ void* entity_set_2,
      /*out*/ void*& result_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    initEntIter (
      /*in*/ void* entity_set_handle,
      /*in*/ ::TSTTM::EntityType requested_entity_type,
      /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
      /*out*/ void*& entity_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    getNextEntIter (
      /*in*/ void* entity_iterator,
      /*out*/ void*& entity_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    resetEntIter (
      /*in*/ void* entity_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    endEntIter (
      /*in*/ void* entity_iterator
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    ::TSTTM::EntityTopology
    getEntTopo (
      /*in*/ void* entity_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    ::TSTTM::EntityType
    getEntType (
      /*in*/ void* entity_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getVtxCoord (
      /*in*/ void* vertex_handle,
      /*out*/ double& x,
      /*out*/ double& y,
      /*out*/ double& z
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntAdj (
      /*in*/ void* entity_handle,
      /*in*/ ::TSTTM::EntityType entity_type_requested,
      /*inout*/ ::sidl::array<void*>& adj_entity_handles,
      /*out*/ int32_t& adj_entity_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    addPrntChld (
      /*inout*/ void*& parent_entity_set,
      /*inout*/ void*& child_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvPrntChld (
      /*inout*/ void*& parent_entity_set,
      /*inout*/ void*& child_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    bool
    isChildOf (
      /*in*/ void* parent_entity_set,
      /*in*/ void* child_entity_set
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getNumChld (
      /*in*/ void* entity_set,
      /*in*/ int32_t num_hops
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getNumPrnt (
      /*in*/ void* entity_set,
      /*in*/ int32_t num_hops
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getChldn (
      /*in*/ void* from_entity_set,
      /*in*/ int32_t num_hops,
      /*inout*/ ::sidl::array<void*>& child_handles,
      /*out*/ int32_t& child_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getPrnts (
      /*in*/ void* from_entity_set,
      /*in*/ int32_t num_hops,
      /*inout*/ ::sidl::array<void*>& parent_handles,
      /*out*/ int32_t& parent_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEntSetData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<char>& tag_value,
      /*in*/ int32_t tag_value_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEntSetIntData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle,
      /*in*/ int32_t tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEntSetDblData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle,
      /*in*/ double tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    setEntSetEHData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle,
      /*in*/ void* tag_value
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getEntSetData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle,
      /*inout*/ ::sidl::array<char>& tag_value,
      /*out*/ int32_t& tag_value_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    int32_t
    getEntSetIntData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    double
    getEntSetDblData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void*
    getEntSetEHData (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    getAllEntSetTags (
      /*in*/ void* entity_set,
      /*inout*/ ::sidl::array<void*>& tag_handles,
      /*out*/ int32_t& tag_handles_size
    )
    throw ( 
      ::TSTTB::Error
    );

    /**
     * user defined non-static method.
     */
    void
    rmvEntSetTag (
      /*in*/ void* entity_set,
      /*in*/ void* tag_handle
    )
    throw ( 
      ::TSTTB::Error
    );

  };  // end class MoabMesh_impl

} // end namespace TSTTM_MOAB

// DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._misc)

#endif
