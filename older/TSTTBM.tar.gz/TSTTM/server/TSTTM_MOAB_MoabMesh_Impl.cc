// 
// File:          TSTTM_MOAB_MoabMesh_Impl.cc
// Symbol:        TSTTM_MOAB.MoabMesh-v0.2
// Symbol Type:   class
// Babel Version: 0.9.8
// sidl Created:  20051011 14:26:09 GMT-06:00
// Generated:     20051011 14:26:12 GMT-06:00
// Description:   Server-side implementation for TSTTM_MOAB.MoabMesh
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.8
// source-line   = 5
// source-url    = file:/home/tjtautg/tstt/cvs/TSTTM/TSTTM_MOAB.sidl
// 
#include "TSTTM_MOAB_MoabMesh_Impl.hh"

// DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._includes)
// Put additional includes or other arbitrary code here...
/**
 * MOAB, a Mesh-Oriented datABase, is a software component for creating,
 * storing and accessing finite element mesh data.
 * 
 * Copyright 2004 Sandia Corporation.  Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Coroporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 */

#include "sidlArray.h"
#include "TSTTB.hh"
#include "MBCore.hpp"
#include "MBCN.hpp"
#include "MBRange.hpp"
#include "TSTTM_MOAB.h"
#include "TSTTM_EntityTopology_IOR.h"
#include "TSTTM_EntityType_IOR.h"
#include "TSTTM_AdjacencyCost.hh"
#include "TSTTB_Error.hh"
#include <iostream>

#define ARRAY_PTR(array, type) reinterpret_cast<type*>(array._get_ior()->d_firstElement)
#define ARRAY_SIZE(array) (array._is_nil() ? 0 : (int)(array.upper(0) - array.lower(0) + 1))
#define PROCESS_ERROR if (TSTTM_LAST_ERROR.error_type != TSTTB_SUCCESS) this->processError()

// need this for definitions in TSTTB_SNL_SIDL_defs.h
#define LOCAL_TSTTB_ERROR TSTTM_LAST_ERROR
#include "TSTTB_SNL_SIDL_defs.h"
#include <string>

// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._includes)

// user defined constructor
void TSTTM_MOAB::MoabMesh_impl::_ctor() {
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._ctor)
    // add construction details here
  tsttmInstance = 0;
  TSTTM_ctor(&tsttmInstance);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._ctor)
}

// user defined destructor
void TSTTM_MOAB::MoabMesh_impl::_dtor() {
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._dtor)
    // add destruction details here
  TSTTM_dtor(tsttmInstance);
  tsttmInstance = 0;
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  load[]
 */
void
TSTTM_MOAB::MoabMesh_impl::load (
  /*in*/ void* entity_set_handle,
  /*in*/ const ::std::string& name ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.load)
    // insert implementation here

  TSTTM_load (tsttmInstance, entity_set_handle, name.c_str());
  PROCESS_ERROR;
 
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.load)
}

/**
 * Method:  save[]
 */
void
TSTTM_MOAB::MoabMesh_impl::save (
  /*in*/ void* entity_set_handle,
  /*in*/ const ::std::string& name ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.save)
    // insert implementation here

  TSTTM_save (tsttmInstance, entity_set_handle, name.c_str());
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.save)
}

/**
 * Method:  getRootSet[]
 */
void*
TSTTM_MOAB::MoabMesh_impl::getRootSet () 
throw ( 
  ::TSTTB::Error
)
{
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getRootSet)
    // insert implementation here

  void* temp = TSTTM_getRootSet (tsttmInstance);
  PROCESS_ERROR;
  return temp;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getRootSet)
}

/**
 * Method:  getGeometricDim[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getGeometricDim () 
throw ( 
  ::TSTTB::Error
)
{
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getGeometricDim)
    // insert implementation here

  int32_t temp = TSTTM_getGeometricDimension(tsttmInstance);
  PROCESS_ERROR;
  return temp;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getGeometricDim)
}

/**
 * Method:  getDfltStorage[]
 */
::TSTTM::StorageOrder
TSTTM_MOAB::MoabMesh_impl::getDfltStorage () 
throw ( 
  ::TSTTB::Error
)
{
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getDfltStorage)
    // insert implementation here
  return static_cast<TSTTM::StorageOrder>(TSTTM_getDfltStorage (tsttmInstance));
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getDfltStorage)
}

/**
 * Method:  getAdjTable[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getAdjTable (
  /*inout*/ ::sidl::array< ::TSTTM::AdjacencyInfo>& adjacency_table,
  /*out*/ int32_t& adjacency_table_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getAdjTable)
    // insert implementation here
  CREATE_TEMP_ENUM_ARRAY(TSTTM_AdjacencyCost, adjacency_table);

  TSTTM_getAdjTable (tsttmInstance,
                     TEMP_ARRAY_INOUT(adjacency_table));
  PROCESS_ERROR;
  ASSIGN_ENUM_ARRAY(adjacency_table);
  
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getAdjTable)
}

/**
 * Method:  areEHValid[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::areEHValid (
  /*in*/ bool reset ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.areEHValid)
  // insert implementation here
  return true;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.areEHValid)
}

/**
 * Method:  getNumOfType[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getNumOfType (
  /*in*/ void* entity_set_handle,
  /*in*/ ::TSTTM::EntityType entity_type ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNumOfType)
    // insert implementation here

  int32_t temp = TSTTM_getNumOfType (tsttmInstance,
                                     entity_set_handle, (TSTTM_EntityType)entity_type);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNumOfType)
}

/**
 * Method:  getNumOfTopo[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getNumOfTopo (
  /*in*/ void* entity_set_handle,
  /*in*/ ::TSTTM::EntityTopology entity_topology ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNumOfTopo)
    // insert implementation here
  int32_t temp = TSTTM_getNumOfTopo (tsttmInstance, entity_set_handle,
                             (TSTTM_EntityTopology) entity_topology);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNumOfTopo)
}

/**
 * Method:  getAllVtxCoords[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getAllVtxCoords (
  /*in*/ void* entity_set,
  /*inout*/ ::sidl::array<double>& coords,
  /*out*/ int32_t& coords_size,
  /*inout*/ ::sidl::array<int32_t>& in_entity_set,
  /*out*/ int32_t& in_entity_set_size,
  /*inout*/ ::TSTTM::StorageOrder& storage_order ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getAllVtxCoords)
    // insert implementation here

  CREATE_TEMP_ARRAY(double, coords);
  CREATE_TEMP_ARRAY(int32_t, in_entity_set);
  
  TSTTM_getAllVtxCoords (tsttmInstance, entity_set,
                         TEMP_ARRAY_INOUT(coords),
                         TEMP_ARRAY_INOUT(in_entity_set),
                         (TSTTM_StorageOrder*)&storage_order);

  PROCESS_ERROR;
  ASSIGN_ARRAY(coords);
  ASSIGN_ARRAY(in_entity_set);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getAllVtxCoords)
}

/**
 * Method:  getVtxCoordIndex[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getVtxCoordIndex (
  /*in*/ void* entity_set,
  /*in*/ ::TSTTM::EntityType requested_entity_type,
  /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
  /*in*/ ::TSTTM::EntityType entity_adjacency_type,
  /*inout*/ ::sidl::array<int32_t>& offset,
  /*out*/ int32_t& offset_size,
  /*inout*/ ::sidl::array<int32_t>& index,
  /*out*/ int32_t& index_size,
  /*inout*/ ::sidl::array< ::TSTTM::EntityTopology>& entity_topologies,
  /*out*/ int32_t& entity_topologies_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getVtxCoordIndex)
    // insert implementation here

  CREATE_TEMP_ARRAY(int32_t, offset);
  CREATE_TEMP_ARRAY(int32_t, index);
  CREATE_TEMP_ENUM_ARRAY(TSTTM_EntityTopology, entity_topologies);
  
  TSTTM_getVtxCoordIndex (tsttmInstance, entity_set, 
                          (TSTTM_EntityType)requested_entity_type, 
                          (TSTTM_EntityTopology)requested_entity_topology,
                          (TSTTM_EntityType)entity_adjacency_type,
                          TEMP_ARRAY_INOUT(offset), 
                          TEMP_ARRAY_INOUT(index), 
                          TEMP_ARRAY_INOUT(entity_topologies));

  PROCESS_ERROR;
  ASSIGN_ARRAY(offset);
  ASSIGN_ARRAY(index);
  ASSIGN_ENUM_ARRAY(entity_topologies);
  
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getVtxCoordIndex)
}

/**
 * Method:  getEntities[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntities (
  /*in*/ void* entity_set,
  /*in*/ ::TSTTM::EntityType entity_type,
  /*in*/ ::TSTTM::EntityTopology entity_topology,
  /*inout*/ ::sidl::array<void*>& entity_handles,
  /*out*/ int32_t& entity_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntities)
    // insert implementation here
  
  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, entity_handles);
  
  TSTTM_getEntities (tsttmInstance, entity_set, 
                     (TSTTM_EntityType)entity_type, (TSTTM_EntityTopology)entity_topology,
                     TEMP_ARRAY_INOUT(entity_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(entity_handles);
  
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntities)
}

/**
 * Method:  getVtxArrCoords[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getVtxArrCoords (
  /*in*/ ::sidl::array<void*> vertex_handles,
  /*in*/ int32_t vertex_handles_size,
  /*inout*/ ::TSTTM::StorageOrder& storage_order,
  /*inout*/ ::sidl::array<double>& coords,
  /*out*/ int32_t& coords_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getVtxArrCoords)
    // insert implementation here

  CREATE_TEMP_ARRAY(double, coords);
  
  TSTTM_getVtxArrCoords (tsttmInstance,
                         TEMP_ARRAY_IN(vertex_handles),
                         (TSTTM_StorageOrder*)&storage_order,
                         TEMP_ARRAY_INOUT(coords));
  PROCESS_ERROR;

  ASSIGN_ARRAY(coords);
  
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getVtxArrCoords)
}

/**
 * Method:  getAdjEntities[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getAdjEntities (
  /*in*/ void* entity_set,
  /*in*/ ::TSTTM::EntityType entity_type_requestor,
  /*in*/ ::TSTTM::EntityTopology entity_topology_requestor,
  /*in*/ ::TSTTM::EntityType entity_type_requested,
  /*inout*/ ::sidl::array<void*>& adj_entity_handles,
  /*out*/ int32_t& adj_entity_handles_size,
  /*inout*/ ::sidl::array<int32_t>& offset,
  /*out*/ int32_t& offset_size,
  /*inout*/ ::sidl::array<int32_t>& in_entity_set,
  /*out*/ int32_t& in_entity_set_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getAdjEntities)
    // insert implementation here
  
  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, adj_entity_handles);
  CREATE_TEMP_ARRAY(int32_t, offset);
  CREATE_TEMP_ARRAY(int32_t, in_entity_set);
  
  TSTTM_getAdjEntities (tsttmInstance, entity_set, 
                        (TSTTM_EntityType)entity_type_requestor,
                        (TSTTM_EntityTopology)entity_topology_requestor, 
                        (TSTTM_EntityType)entity_type_requested,
                        TEMP_ARRAY_INOUT(adj_entity_handles),
                        TEMP_ARRAY_INOUT(offset),
                        TEMP_ARRAY_INOUT(in_entity_set));
  PROCESS_ERROR;


  ASSIGN_ARRAY(adj_entity_handles);
  ASSIGN_ARRAY(offset);
  ASSIGN_ARRAY(in_entity_set);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getAdjEntities)
}

/**
 * Method:  initEntArrIter[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::initEntArrIter (
  /*in*/ void* entity_set_handle,
  /*in*/ ::TSTTM::EntityType requested_entity_type,
  /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
  /*in*/ int32_t requested_array_size,
  /*out*/ void*& entArr_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.initEntArrIter)
    // insert implementation here
  bool result = TSTTM_initEntArrIter (tsttmInstance, entity_set_handle,
                                      (TSTTM_EntityType)requested_entity_type, 
                                      (TSTTM_EntityTopology)requested_entity_topology,
                                      requested_array_size, &entArr_iterator);
  PROCESS_ERROR;
  return result;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.initEntArrIter)
}

/**
 * Method:  getNextEntArrIter[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::getNextEntArrIter (
  /*in*/ void* entArr_iterator,
  /*inout*/ ::sidl::array<void*>& entity_handles,
  /*out*/ int32_t& entity_handles_size ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNextEntArrIter)
  // insert implementation here
  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, entity_handles);
  
  bool val = TSTTM_getNextEntArrIter (tsttmInstance, entArr_iterator,
                                      TEMP_ARRAY_INOUT(entity_handles));


  ASSIGN_ARRAY(entity_handles);
  return val;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNextEntArrIter)
}

/**
 * Method:  resetEntArrIter[]
 */
void
TSTTM_MOAB::MoabMesh_impl::resetEntArrIter (
  /*in*/ void* entArr_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.resetEntArrIter)
    // insert implementation here
  TSTTM_resetEntArrIter (tsttmInstance, entArr_iterator);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.resetEntArrIter)
}

/**
 * Method:  endEntArrIter[]
 */
void
TSTTM_MOAB::MoabMesh_impl::endEntArrIter (
  /*in*/ void* entArr_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.endEntArrIter)
    // insert implementation here
  TSTTM_endEntArrIter (tsttmInstance, entArr_iterator);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.endEntArrIter)
}

/**
 * Method:  getEntArrTopo[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntArrTopo (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*inout*/ ::sidl::array< ::TSTTM::EntityTopology>& topology,
  /*out*/ int32_t& topology_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntArrTopo)
    // insert implementation here

  CREATE_TEMP_ENUM_ARRAY(TSTTM_EntityTopology, topology);

  TSTTM_getEntArrTopo (tsttmInstance,
                       TEMP_ARRAY_IN(entity_handles),
                       TEMP_ARRAY_INOUT(topology));
  PROCESS_ERROR;


  ASSIGN_ENUM_ARRAY(topology);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntArrTopo)
}

/**
 * Method:  getEntArrType[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntArrType (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*inout*/ ::sidl::array< ::TSTTM::EntityType>& type,
  /*out*/ int32_t& type_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntArrType)
    // insert implementation here


  CREATE_TEMP_ENUM_ARRAY(TSTTM_EntityType, type);

  TSTTM_getEntArrType (tsttmInstance,
                       TEMP_ARRAY_IN(entity_handles),
                       TEMP_ARRAY_INOUT(type));
  PROCESS_ERROR;

  ASSIGN_ENUM_ARRAY(type);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntArrType)
}

/**
 * Method:  getEntArrAdj[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntArrAdj (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ ::TSTTM::EntityType entity_type_requested,
  /*inout*/ ::sidl::array<void*>& adj_entity_handles,
  /*out*/ int32_t& adj_entity_handles_size,
  /*inout*/ ::sidl::array<int32_t>& offset,
  /*out*/ int32_t& offset_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntArrAdj)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, adj_entity_handles);
  CREATE_TEMP_ARRAY(int32_t, offset);

  TSTTM_getEntArrAdj (tsttmInstance,
                      TEMP_ARRAY_IN(entity_handles),
                      (TSTTM_EntityType)entity_type_requested,
                      TEMP_ARRAY_INOUT(adj_entity_handles),
                      TEMP_ARRAY_INOUT(offset));
  PROCESS_ERROR;

  ASSIGN_ARRAY(adj_entity_handles);
  ASSIGN_ARRAY(offset);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntArrAdj)
}

/**
 * Method:  setVtxCoords[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setVtxCoords (
  /*in*/ void* vertex_handles,
  /*in*/ double x,
  /*in*/ double y,
  /*in*/ double z ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setVtxCoords)
    // insert implementation here
  TSTTM_setVtxCoords (tsttmInstance, vertex_handles,
                      x, y, z);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setVtxCoords)
}

/**
 * Method:  createVtx[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createVtx (
  /*in*/ double x,
  /*in*/ double y,
  /*in*/ double z,
  /*out*/ void*& new_vertex_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createVtx)
    // insert implementation here
  TSTTM_createVtx (tsttmInstance,
                   x, y, z, &new_vertex_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createVtx)
}

/**
 * Method:  createEnt[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createEnt (
  /*in*/ ::TSTTM::EntityTopology new_entity_topology,
  /*in*/ ::sidl::array<void*> lower_order_entity_handles,
  /*in*/ int32_t lower_order_entity_handles_size,
  /*out*/ void*& new_entity_handle,
  /*out*/ ::TSTTM::CreationStatus& status ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createEnt)
    // insert implementation here
  TSTTM_createEnt (tsttmInstance, 
                   (TSTTM_EntityTopology)new_entity_topology,
                   TEMP_ARRAY_IN(lower_order_entity_handles),
                   &new_entity_handle, (TSTTM_CreationStatus*)&status);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createEnt)
}

/**
 * Method:  deleteEnt[]
 */
void
TSTTM_MOAB::MoabMesh_impl::deleteEnt (
  /*in*/ void* entity_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.deleteEnt)
    // insert implementation here
  TSTTM_deleteEnt (tsttmInstance, entity_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.deleteEnt)
}

/**
 * Method:  setVtxArrCoords[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setVtxArrCoords (
  /*in*/ ::sidl::array<void*> vertex_handles,
  /*in*/ int32_t vertex_handles_size,
  /*in*/ ::TSTTM::StorageOrder storage_order,
  /*in*/ ::sidl::array<double> new_coords,
  /*in*/ int32_t new_coords_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setVtxArrCoords)
    // insert implementation here
  TSTTM_setVtxArrCoords (tsttmInstance,
                         TEMP_ARRAY_IN(vertex_handles), 
                         (TSTTM_StorageOrder)storage_order,
                         TEMP_ARRAY_IN(new_coords));
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setVtxArrCoords)
}

/**
 * Method:  createVtxArr[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createVtxArr (
  /*in*/ int32_t num_verts,
  /*in*/ ::TSTTM::StorageOrder storage_order,
  /*in*/ ::sidl::array<double> new_coords,
  /*in*/ int32_t new_coords_size,
  /*inout*/ ::sidl::array<void*>& new_vertex_handles,
  /*out*/ int32_t& new_vertex_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createVtxArr)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, new_vertex_handles);

  TSTTM_createVtxArr (tsttmInstance,
                      num_verts, 
                      (TSTTM_StorageOrder)storage_order,
                      TEMP_ARRAY_IN(new_coords),
                      TEMP_ARRAY_INOUT(new_vertex_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(new_vertex_handles);

// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createVtxArr)
}

/**
 * Method:  createEntArr[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createEntArr (
  /*in*/ ::TSTTM::EntityTopology new_entity_topology,
  /*in*/ ::sidl::array<void*> lower_order_entity_handles,
  /*in*/ int32_t lower_order_entity_handles_size,
  /*inout*/ ::sidl::array<void*>& new_entity_handles,
  /*out*/ int32_t& new_entity_handles_size,
  /*inout*/ ::sidl::array< ::TSTTM::CreationStatus>& status,
  /*out*/ int32_t& status_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createEntArr)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, new_entity_handles);
  CREATE_TEMP_ENUM_ARRAY(TSTTM_CreationStatus, status);

  TSTTM_createEntArr (tsttmInstance,
                      (TSTTM_EntityTopology)new_entity_topology,
                      TEMP_ARRAY_IN(lower_order_entity_handles),
                      TEMP_ARRAY_INOUT(new_entity_handles),
                      TEMP_ARRAY_INOUT(status));
  PROCESS_ERROR;

  ASSIGN_ARRAY(new_entity_handles);
  ASSIGN_ENUM_ARRAY(status);

// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createEntArr)
}

/**
 * Method:  deleteEntArr[]
 */
void
TSTTM_MOAB::MoabMesh_impl::deleteEntArr (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.deleteEntArr)
    // insert implementation here
  TSTTM_deleteEntArr (tsttmInstance,
                      TEMP_ARRAY_IN(entity_handles));
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.deleteEntArr)
}

/**
 * Method:  createTag[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createTag (
  /*in*/ const ::std::string& tag_name,
  /*in*/ int32_t number_of_values,
  /*in*/ ::TSTTB::TagValueType tag_type,
  /*out*/ void*& tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createTag)
    // insert implementation here
  TSTTM_createTag (tsttmInstance,
                   tag_name.c_str(), number_of_values, 
                   (TSTTM_TagValueType)tag_type,
                   &tag_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createTag)
}

/**
 * Method:  destroyTag[]
 */
void
TSTTM_MOAB::MoabMesh_impl::destroyTag (
  /*in*/ void* tag_handle,
  /*in*/ bool forced ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.destroyTag)
    // insert implementation here
  TSTTM_destroyTag (tsttmInstance, tag_handle, forced);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.destroyTag)
}

/**
 * Method:  getTagName[]
 */
::std::string
TSTTM_MOAB::MoabMesh_impl::getTagName (
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getTagName)
    // insert implementation here
  ::std::string temp = TSTTM_getTagName (tsttmInstance, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getTagName)
}

/**
 * Method:  getTagSizeValues[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getTagSizeValues (
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getTagSizeValues)
  // insert implementation here
  int32_t temp = TSTTM_getTagSizeValues (tsttmInstance, tag_handle);
  PROCESS_ERROR;
  return temp;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getTagSizeValues)
}

/**
 * Method:  getTagSizeBytes[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getTagSizeBytes (
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getTagSizeBytes)
  // insert implementation here
  int32_t temp = TSTTM_getTagSizeBytes (tsttmInstance, tag_handle);
  PROCESS_ERROR;
  return temp;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getTagSizeBytes)
}

/**
 * Method:  getTagHandle[]
 */
void*
TSTTM_MOAB::MoabMesh_impl::getTagHandle (
  /*in*/ const ::std::string& tag_name ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getTagHandle)
    // insert implementation here
  void* temp = TSTTM_getTagHandle (tsttmInstance, tag_name.c_str());
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getTagHandle)
}

/**
 * Method:  getTagType[]
 */
::TSTTB::TagValueType
TSTTM_MOAB::MoabMesh_impl::getTagType (
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getTagType)
    // insert implementation here
   ::TSTTB::TagValueType temp = (::TSTTB::TagValueType)TSTTM_getTagType (tsttmInstance, tag_handle);
   PROCESS_ERROR;
   return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getTagType)
}

/**
 * Method:  getArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<char>& value_array,
  /*out*/ int32_t& value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getArrData)
    // insert implementation here

  CREATE_TEMP_TAG_ARRAY(value_array);

  TSTTM_getArrData (tsttmInstance,
                    TEMP_ARRAY_IN(entity_handles), 
                    tag_handle,
                    TEMP_ARRAY_INOUT(value_array));
  PROCESS_ERROR;

  ASSIGN_TAG_ARRAY(value_array);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getArrData)
}

/**
 * Method:  getIntArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getIntArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<int32_t>& value_array,
  /*out*/ int32_t& value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getIntArrData)
    // insert implementation here

  CREATE_TEMP_ARRAY(int32_t, value_array);

  TSTTM_getIntArrData (tsttmInstance, TEMP_ARRAY_IN(entity_handles),
                       tag_handle, TEMP_ARRAY_INOUT(value_array));
  PROCESS_ERROR;

  ASSIGN_ARRAY(value_array);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getIntArrData)
}

/**
 * Method:  getDblArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getDblArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<double>& value_array,
  /*out*/ int32_t& value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getDblArrData)
    // insert implementation here
  CREATE_TEMP_ARRAY(double, value_array);

  TSTTM_getDblArrData (tsttmInstance,
                       TEMP_ARRAY_IN(entity_handles), tag_handle,
                       TEMP_ARRAY_INOUT(value_array));
  PROCESS_ERROR;

  ASSIGN_ARRAY(value_array);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getDblArrData)
}

/**
 * Method:  getEHArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEHArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<void*>& value_array,
  /*out*/ int32_t& value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEHArrData)
    // insert implementation here

  CREATE_TEMP_EH_ARRAY(value_array);

  TSTTM_getEHArrData (tsttmInstance,
                      TEMP_ARRAY_IN(entity_handles), tag_handle,
                      TEMP_ARRAY_INOUT(value_array));
  PROCESS_ERROR;

  ASSIGN_ARRAY(value_array);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEHArrData)
}

/**
 * Method:  setArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*in*/ ::sidl::array<char> value_array,
  /*in*/ int32_t value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setArrData)
    // insert implementation here

  TSTTM_setArrData (tsttmInstance,
                    TEMP_ARRAY_IN(entity_handles), tag_handle,
                    TEMP_TAG_ARRAY_IN(value_array));
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setArrData)
}

/**
 * Method:  setIntArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setIntArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*in*/ ::sidl::array<int32_t> value_array,
  /*in*/ int32_t value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setIntArrData)
    // insert implementation here

  TSTTM_setIntArrData (tsttmInstance,
                       TEMP_ARRAY_IN(entity_handles), tag_handle,
                       TEMP_ARRAY_IN(value_array));
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setIntArrData)
}

/**
 * Method:  setDblArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setDblArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*in*/ ::sidl::array<double> value_array,
  /*in*/ int32_t value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setDblArrData)
    // insert implementation here

  TSTTM_setDblArrData (tsttmInstance,
                       TEMP_ARRAY_IN(entity_handles), tag_handle,
                       TEMP_ARRAY_IN(value_array));
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setDblArrData)
}

/**
 * Method:  setEHArrData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEHArrData (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle,
  /*in*/ ::sidl::array<void*> value_array,
  /*in*/ int32_t value_array_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEHArrData)
    // insert implementation here

  TSTTM_setEHArrData (tsttmInstance,
                      TEMP_ARRAY_IN(entity_handles), tag_handle,
                      (value_array._get_ior() == NULL ? NULL : 
                       value_array._get_ior()->d_firstElement),
                      value_array_size);
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEHArrData)
}

/**
 * Method:  rmvArrTag[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvArrTag (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvArrTag)
    // insert implementation here
  TSTTM_rmvArrTag (tsttmInstance,
    TEMP_ARRAY_IN(entity_handles), tag_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvArrTag)
}

/**
 * Method:  getData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<char>& tag_value,
  /*out*/ int32_t& tag_value_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getData)
    // insert implementation here
  CREATE_TEMP_TAG_ARRAY(tag_value);

  TSTTM_getData (tsttmInstance,
                 entity_handle, 
                 tag_handle,
                 TEMP_ARRAY_INOUT(tag_value));

  PROCESS_ERROR;

  ASSIGN_TAG_ARRAY(tag_value);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getData)
}

/**
 * Method:  getIntData[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getIntData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getIntData)
    // insert implementation here
  int32_t temp = TSTTM_getIntData (tsttmInstance, entity_handle, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getIntData)
}

/**
 * Method:  getDblData[]
 */
double
TSTTM_MOAB::MoabMesh_impl::getDblData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getDblData)
    // insert implementation here
  double temp = TSTTM_getDblData (tsttmInstance, entity_handle, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getDblData)
}

/**
 * Method:  getEHData[]
 */
void*
TSTTM_MOAB::MoabMesh_impl::getEHData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEHData)
    // insert implementation here
  void* temp = TSTTM_getEHData (tsttmInstance, entity_handle, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEHData)
}

/**
 * Method:  setData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle,
  /*in*/ ::sidl::array<char> tag_value,
  /*in*/ int32_t tag_value_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setData)
    // insert implementation here
  TSTTM_setData (tsttmInstance, entity_handle,
                 tag_handle, 
                 ARRAY_PTR(tag_value, const char),
                 tag_value_size);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setData)
}

/**
 * Method:  setIntData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setIntData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle,
  /*in*/ int32_t tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setIntData)
    // insert implementation here
  TSTTM_setIntData (tsttmInstance, entity_handle,
                    tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setIntData)
}

/**
 * Method:  setDblData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setDblData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle,
  /*in*/ double tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setDblData)
    // insert implementation here
  TSTTM_setDblData (tsttmInstance, entity_handle,
                    tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setDblData)
}

/**
 * Method:  setEHData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEHData (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle,
  /*in*/ void* tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEHData)
    // insert implementation here
  TSTTM_setEHData (tsttmInstance, entity_handle,
                   tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEHData)
}

/**
 * Method:  getAllTags[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getAllTags (
  /*in*/ void* entity_handle,
  /*inout*/ ::sidl::array<void*>& tag_handles,
  /*out*/ int32_t& tag_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getAllTags)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_TagHandle, tag_handles);

  TSTTM_getAllTags (tsttmInstance, entity_handle,
                    TEMP_ARRAY_INOUT(tag_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(tag_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getAllTags)
}

/**
 * Method:  rmvTag[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvTag (
  /*in*/ void* entity_handle,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvTag)
    // insert implementation here
  TSTTM_rmvTag (tsttmInstance, entity_handle, tag_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvTag)
}

/**
 * Method:  createEntSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::createEntSet (
  /*in*/ bool isList,
  /*out*/ void*& entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.createEntSet)
    // insert implementation here
  TSTTM_createEntSet (tsttmInstance, isList, &entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.createEntSet)
}

/**
 * Method:  destroyEntSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::destroyEntSet (
  /*in*/ void* entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.destroyEntSet)
    // insert implementation here
  TSTTM_destroyEntSet (tsttmInstance, entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.destroyEntSet)
}

/**
 * Method:  isList[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::isList (
  /*in*/ void* entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.isList)
    // insert implementation here
  bool temp = TSTTM_isList (tsttmInstance, entity_set);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.isList)
}

/**
 * Method:  getNumEntSets[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getNumEntSets (
  /*in*/ void* entity_set,
  /*in*/ int32_t num_hops ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNumEntSets)
    // insert implementation here
  int32_t temp = TSTTM_getNumEntSets (tsttmInstance, entity_set, num_hops);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNumEntSets)
}

/**
 * Method:  getEntSets[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntSets (
  /*in*/ void* entity_set,
  /*in*/ int32_t num_hops,
  /*inout*/ ::sidl::array<void*>& contained_entset_handles,
  /*out*/ int32_t& contained_entset_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntSets)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, contained_entset_handles);

  TSTTM_getEntSets (tsttmInstance,
                    entity_set, num_hops,
                    TEMP_ARRAY_INOUT(contained_entset_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(contained_entset_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntSets)
}

/**
 * Method:  addEntToSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::addEntToSet (
  /*in*/ void* entity_handle,
  /*inout*/ void*& entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.addEntToSet)
    // insert implementation here
  TSTTM_addEntToSet (tsttmInstance, entity_handle, &entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.addEntToSet)
}

/**
 * Method:  rmvEntFromSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvEntFromSet (
  /*in*/ void* entity_handle,
  /*inout*/ void*& entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvEntFromSet)
    // insert implementation here
  TSTTM_rmvEntFromSet (tsttmInstance, entity_handle, &entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvEntFromSet)
}

/**
 * Method:  addEntArrToSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::addEntArrToSet (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*inout*/ void*& entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.addEntArrToSet)
    // insert implementation here

  TSTTM_addEntArrToSet (tsttmInstance,
                        TEMP_ARRAY_IN(entity_handles), &entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.addEntArrToSet)
}

/**
 * Method:  rmvEntArrFromSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvEntArrFromSet (
  /*in*/ ::sidl::array<void*> entity_handles,
  /*in*/ int32_t entity_handles_size,
  /*inout*/ void*& entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvEntArrFromSet)
    // insert implementation here
  TSTTM_rmvEntArrFromSet (tsttmInstance,
                          TEMP_ARRAY_IN(entity_handles), &entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvEntArrFromSet)
}

/**
 * Method:  addEntSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::addEntSet (
  /*in*/ void* entity_set_to_add,
  /*inout*/ void*& entity_set_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.addEntSet)
    // insert implementation here
  TSTTM_addEntSet (tsttmInstance, entity_set_to_add, &entity_set_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.addEntSet)
}

/**
 * Method:  rmvEntSet[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvEntSet (
  /*in*/ void* entity_set_to_remove,
  /*inout*/ void*& entity_set_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvEntSet)
    // insert implementation here
  TSTTM_rmvEntSet (tsttmInstance, entity_set_to_remove,
                   &entity_set_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvEntSet)
}

/**
 * Method:  isEntContained[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::isEntContained (
  /*in*/ void* containing_entity_set,
  /*in*/ void* entity_handle ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.isEntContained)
  // insert implementation here
  bool temp = TSTTM_isEntContained(tsttmInstance,
                                   containing_entity_set, entity_handle);
  PROCESS_ERROR;
  return temp;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.isEntContained)
}

/**
 * Method:  isEntSetContained[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::isEntSetContained (
  /*in*/ void* containing_entity_set,
  /*in*/ void* contained_entity_set ) 
throw ( 
  ::TSTTB::Error
){
  // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.isEntSetContained)
  // insert implementation here
  bool temp = TSTTM_isEntSetContained(tsttmInstance,
                                      containing_entity_set, contained_entity_set);
  PROCESS_ERROR;
  return temp;
  // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.isEntSetContained)
}

/**
 * Method:  subtract[]
 */
void
TSTTM_MOAB::MoabMesh_impl::subtract (
  /*in*/ void* entity_set_1,
  /*in*/ void* entity_set_2,
  /*out*/ void*& result_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.subtract)
    // insert implementation here
  TSTTM_subtract (tsttmInstance, entity_set_1,
                  entity_set_2, &result_entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.subtract)
}

/**
 * Method:  intersect[]
 */
void
TSTTM_MOAB::MoabMesh_impl::intersect (
  /*in*/ void* entity_set_1,
  /*in*/ void* entity_set_2,
  /*out*/ void*& result_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.intersect)
    // insert implementation here
  TSTTM_intersect (tsttmInstance, entity_set_1,
                   entity_set_2, &result_entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.intersect)
}

/**
 * Method:  unite[]
 */
void
TSTTM_MOAB::MoabMesh_impl::unite (
  /*in*/ void* entity_set_1,
  /*in*/ void* entity_set_2,
  /*out*/ void*& result_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.unite)
    // insert implementation here
  TSTTM_unite (tsttmInstance, entity_set_1,
               entity_set_2, &result_entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.unite)
}

/**
 * Method:  initEntIter[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::initEntIter (
  /*in*/ void* entity_set_handle,
  /*in*/ ::TSTTM::EntityType requested_entity_type,
  /*in*/ ::TSTTM::EntityTopology requested_entity_topology,
  /*out*/ void*& entity_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.initEntIter)
    // insert implementation here
  bool result = TSTTM_initEntIter (tsttmInstance, entity_set_handle,
                                   (TSTTM_EntityType)requested_entity_type, 
                                   (TSTTM_EntityTopology)requested_entity_topology,
                                   &entity_iterator);
  PROCESS_ERROR;
  return result;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.initEntIter)
}

/**
 * Method:  getNextEntIter[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::getNextEntIter (
  /*in*/ void* entity_iterator,
  /*out*/ void*& entity_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNextEntIter)
    // insert implementation here
  bool temp = TSTTM_getNextEntIter (tsttmInstance, entity_iterator, &entity_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNextEntIter)
}

/**
 * Method:  resetEntIter[]
 */
void
TSTTM_MOAB::MoabMesh_impl::resetEntIter (
  /*in*/ void* entity_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.resetEntIter)
    // insert implementation here
  TSTTM_resetEntIter (tsttmInstance, entity_iterator);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.resetEntIter)
}

/**
 * Method:  endEntIter[]
 */
void
TSTTM_MOAB::MoabMesh_impl::endEntIter (
  /*in*/ void* entity_iterator ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.endEntIter)
    // insert implementation here
  TSTTM_endEntIter (tsttmInstance, entity_iterator);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.endEntIter)
}

/**
 * Method:  getEntTopo[]
 */
::TSTTM::EntityTopology
TSTTM_MOAB::MoabMesh_impl::getEntTopo (
  /*in*/ void* entity_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntTopo)
    // insert implementation here
  ::TSTTM::EntityTopology temp = (::TSTTM::EntityTopology) TSTTM_getEntTopo (tsttmInstance, entity_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntTopo)
}

/**
 * Method:  getEntType[]
 */
::TSTTM::EntityType
TSTTM_MOAB::MoabMesh_impl::getEntType (
  /*in*/ void* entity_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntType)
    // insert implementation here
  ::TSTTM::EntityType temp = (TSTTM::EntityType) TSTTM_getEntType (tsttmInstance, entity_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntType)
}

/**
 * Method:  getVtxCoord[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getVtxCoord (
  /*in*/ void* vertex_handle,
  /*out*/ double& x,
  /*out*/ double& y,
  /*out*/ double& z ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getVtxCoord)
    // insert implementation here

  TSTTM_getVtxCoord (tsttmInstance, vertex_handle,
                     x, y, z);
  PROCESS_ERROR;

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getVtxCoord)
}

/**
 * Method:  getEntAdj[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntAdj (
  /*in*/ void* entity_handle,
  /*in*/ ::TSTTM::EntityType entity_type_requested,
  /*inout*/ ::sidl::array<void*>& adj_entity_handles,
  /*out*/ int32_t& adj_entity_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntAdj)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, adj_entity_handles);

  TSTTM_getEntAdj (tsttmInstance, entity_handle,  
                   (TSTTM_EntityType)entity_type_requested,
                   TEMP_ARRAY_INOUT(adj_entity_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(adj_entity_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntAdj)
}

/**
 * Method:  addPrntChld[]
 */
void
TSTTM_MOAB::MoabMesh_impl::addPrntChld (
  /*inout*/ void*& parent_entity_set,
  /*inout*/ void*& child_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.addPrntChld)
    // insert implementation here
  TSTTM_addPrntChld (tsttmInstance,
                     &parent_entity_set, &child_entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.addPrntChld)
}

/**
 * Method:  rmvPrntChld[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvPrntChld (
  /*inout*/ void*& parent_entity_set,
  /*inout*/ void*& child_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvPrntChld)
    // insert implementation here
  TSTTM_rmvPrntChld (tsttmInstance,
                       /*inout*/ &parent_entity_set,
                       /*inout*/ &child_entity_set);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvPrntChld)
}

/**
 * Method:  isChildOf[]
 */
bool
TSTTM_MOAB::MoabMesh_impl::isChildOf (
  /*in*/ void* parent_entity_set,
  /*in*/ void* child_entity_set ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.isChildOf)
    // insert implementation here
  bool temp = TSTTM_isChildOf (tsttmInstance,
                          parent_entity_set, child_entity_set);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.isChildOf)
}

/**
 * Method:  getNumChld[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getNumChld (
  /*in*/ void* entity_set,
  /*in*/ int32_t num_hops ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNumChld)
    // insert implementation here
  int32_t temp = TSTTM_getNumChld (tsttmInstance, entity_set, num_hops);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNumChld)
}

/**
 * Method:  getNumPrnt[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getNumPrnt (
  /*in*/ void* entity_set,
  /*in*/ int32_t num_hops ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getNumPrnt)
    // insert implementation here
  int32_t temp = TSTTM_getNumPrnt (tsttmInstance, entity_set, num_hops);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getNumPrnt)
}

/**
 * Method:  getChldn[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getChldn (
  /*in*/ void* from_entity_set,
  /*in*/ int32_t num_hops,
  /*inout*/ ::sidl::array<void*>& child_handles,
  /*out*/ int32_t& child_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getChldn)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, child_handles);

  TSTTM_getChldn (tsttmInstance, from_entity_set, num_hops,
                  TEMP_ARRAY_INOUT(child_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(child_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getChldn)
}

/**
 * Method:  getPrnts[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getPrnts (
  /*in*/ void* from_entity_set,
  /*in*/ int32_t num_hops,
  /*inout*/ ::sidl::array<void*>& parent_handles,
  /*out*/ int32_t& parent_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getPrnts)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_EntityHandle, parent_handles);

  TSTTM_getPrnts (tsttmInstance, from_entity_set, num_hops,
                  TEMP_ARRAY_INOUT(parent_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(parent_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getPrnts)
}

/**
 * Method:  setEntSetData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEntSetData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<char>& tag_value,
  /*in*/ int32_t tag_value_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEntSetData)
    // insert implementation here
  TSTTM_setEntSetData (tsttmInstance, entity_set, tag_handle,
                       ARRAY_PTR(tag_value, const char), tag_value_size);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEntSetData)
}

/**
 * Method:  setEntSetIntData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEntSetIntData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle,
  /*in*/ int32_t tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEntSetIntData)
    // insert implementation here
  TSTTM_setEntSetIntData (tsttmInstance,
                          entity_set, tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEntSetIntData)
}

/**
 * Method:  setEntSetDblData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEntSetDblData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle,
  /*in*/ double tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEntSetDblData)
    // insert implementation here
  TSTTM_setEntSetDblData (tsttmInstance,
                          entity_set, tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEntSetDblData)
}

/**
 * Method:  setEntSetEHData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::setEntSetEHData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle,
  /*in*/ void* tag_value ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.setEntSetEHData)
    // insert implementation here
  TSTTM_setEntSetEHData (tsttmInstance,
                         entity_set, tag_handle, tag_value);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.setEntSetEHData)
}

/**
 * Method:  getEntSetData[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getEntSetData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle,
  /*inout*/ ::sidl::array<char>& tag_value,
  /*out*/ int32_t& tag_value_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntSetData)
    // insert implementation here

  CREATE_TEMP_TAG_ARRAY(tag_value);
  
  TSTTM_getEntSetData (tsttmInstance,
                       entity_set, tag_handle, 
                       TEMP_ARRAY_INOUT(tag_value));
  PROCESS_ERROR;

  ASSIGN_TAG_ARRAY(tag_value);
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntSetData)
}

/**
 * Method:  getEntSetIntData[]
 */
int32_t
TSTTM_MOAB::MoabMesh_impl::getEntSetIntData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntSetIntData)
    // insert implementation here
  int32_t temp = TSTTM_getEntSetIntData (tsttmInstance,
                                         entity_set, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntSetIntData)
}

/**
 * Method:  getEntSetDblData[]
 */
double
TSTTM_MOAB::MoabMesh_impl::getEntSetDblData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntSetDblData)
    // insert implementation here
  double temp = TSTTM_getEntSetDblData (tsttmInstance, entity_set, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntSetDblData)
}

/**
 * Method:  getEntSetEHData[]
 */
void*
TSTTM_MOAB::MoabMesh_impl::getEntSetEHData (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getEntSetEHData)
    // insert implementation here
  void* temp = TSTTM_getEntSetEHData (tsttmInstance, entity_set, tag_handle);
  PROCESS_ERROR;
  return temp;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getEntSetEHData)
}

/**
 * Method:  getAllEntSetTags[]
 */
void
TSTTM_MOAB::MoabMesh_impl::getAllEntSetTags (
  /*in*/ void* entity_set,
  /*inout*/ ::sidl::array<void*>& tag_handles,
  /*out*/ int32_t& tag_handles_size ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.getAllEntSetTags)
    // insert implementation here

  CREATE_TEMP_ARRAY(TSTTM_TagHandle, tag_handles);

  TSTTM_getAllEntSetTags (tsttmInstance, entity_set,
                          TEMP_ARRAY_INOUT(tag_handles));
  PROCESS_ERROR;

  ASSIGN_ARRAY(tag_handles);

    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.getAllEntSetTags)
}

/**
 * Method:  rmvEntSetTag[]
 */
void
TSTTM_MOAB::MoabMesh_impl::rmvEntSetTag (
  /*in*/ void* entity_set,
  /*in*/ void* tag_handle ) 
throw ( 
  ::TSTTB::Error
){
    // DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh.rmvEntSetTag)
    // insert implementation here
  TSTTM_rmvEntSetTag (tsttmInstance, entity_set, tag_handle);
  PROCESS_ERROR;
    // DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh.rmvEntSetTag)
}


// DO-NOT-DELETE splicer.begin(TSTTM_MOAB.MoabMesh._misc)
// Put miscellaneous code here
// call this function when you want to throw an error
void
TSTTM_MOAB::MoabMesh_impl::processError() throw(::TSTTB::Error)
{
  static void *behavior_tag = NULL;
  TSTTB::ErrorActions action = TSTTB::ErrorActions_THROW_ERROR;

    // save this info before calling tag get function to get behavior
  std::string this_desc(TSTTM_LAST_ERROR.description);
  TSTTB::ErrorType this_err = (TSTTB::ErrorType)TSTTM_LAST_ERROR.error_type;

  if (0 == behavior_tag) {
    behavior_tag = TSTTM_getTagHandle(tsttmInstance, "Error_Behavior");
      // reset the TSTTM error indicator to what was passed in here
    TSTTM_LAST_ERROR.error_type = (TSTTB_ErrorType) this_err;
    TSTTM_LAST_ERROR.description[0] = '\0';
  }

  if (0 != behavior_tag) {
    TSTTB::ErrorActions temp = (TSTTB::ErrorActions) TSTTM_getIntData (tsttmInstance, NULL,
                                                                         behavior_tag);
    if (TSTTB_SUCCESS == TSTTM_LAST_ERROR.error_type) action = temp;
  }

  TSTTB::Error this_error = TSTTB::Error::_create();
  switch (action) {
    case TSTTB::ErrorActions_THROW_ERROR:
      this_error.set(this_err, this_desc);
      throw this_error;
      break;
    case TSTTB::ErrorActions_WARN_ONLY:
      std::cerr << TSTTM_LAST_ERROR.description << std::endl;
      break;
    case TSTTB::ErrorActions_SILENT:
      break;
  }
}

// DO-NOT-DELETE splicer.end(TSTTM_MOAB.MoabMesh._misc)
