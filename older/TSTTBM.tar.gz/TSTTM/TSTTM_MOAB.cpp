#include "TSTTM_MOAB.h"
#include "MBCore.hpp"
#include "MBRange.hpp"
#include "MBCN.hpp"
#include "MBInternals.hpp"

#include <iostream>

#define CHECK_SIZE(array, allocated, size, type, retval)  \
  if (0 == allocated || allocated < size) {\
    if (NULL != array) free(array); \
    array = (type*)malloc(size*sizeof(type));\
    allocated=size;\
    if (NULL == array) {TSTTM_processError(TSTTB_MEMORY_ALLOCATION_FAILED, \
          "Couldn't allocate array.");return retval; }\
  }
// TAG_CHECK_SIZE is like CHECK_SIZE except it checks for and makes the allocated memory
// size a multiple of sizeof(void*), and the pointer is assumed to be type char*
#define TAG_CHECK_SIZE(array, allocated, size)  \
  if (allocated < size) {\
    if (NULL != array) free(array); \
    allocated=size; \
    array = (char*)malloc(allocated); \
    if (NULL == array) {TSTTM_processError(TSTTB_MEMORY_ALLOCATION_FAILED, \
          "Couldn't allocate array.");return TSTTB_MEMORY_ALLOCATION_FAILED; }\
  }
#define HANDLE_ARRAY_PTR(array) reinterpret_cast<MBEntityHandle*>(array)
#define CONST_HANDLE_ARRAY_PTR(array) reinterpret_cast<const MBEntityHandle*>(array)
#define TAG_HANDLE(handle) static_cast<MBTag>(handle)
#define CONST_TAG_HANDLE(handle) static_cast<const MBTag>(handle)
#define ENTITY_HANDLE(handle) reinterpret_cast<MBEntityHandle>(handle)
#define CONST_ENTITY_HANDLE(handle) reinterpret_cast<const MBEntityHandle>(handle)
#define RANGE_ITERATOR(it) reinterpret_cast<RangeIterator*>(it)
#define CAST_TO_VOID(ptr) reinterpret_cast<void*>(ptr)

// map from MB's entity type to TSTT's entity topology
const TSTTM_EntityTopology tstt_topology_table[] =
{
  TSTTM_POINT,          // MBVERTEX
  TSTTM_LINE_SEGMENT,   // MBEDGE
  TSTTM_TRIANGLE,       // MBTRI
  TSTTM_QUADRILATERAL,  // MBQUAD
  TSTTM_POLYGON,        // MBPOLYGON
  TSTTM_TETRAHEDRON,    // MBTET
  TSTTM_PYRAMID,        // MBPYRAMID
  TSTTM_PRISM,          // MBPRISM
  TSTTM_ALL_TOPOLOGIES, // MBKNIFE
  TSTTM_HEXAHEDRON,     // MBHEX
  TSTTM_POLYHEDRON,     // MBPOLYHEDRON
  TSTTM_ALL_TOPOLOGIES, // MBENTITYSET
  TSTTM_ALL_TOPOLOGIES, // MBMAXTYPE
};

// map from MB's entity type to TSTT's entity type
const TSTTM_EntityType tstt_type_table[] =
{
  TSTTM_VERTEX,         // MBVERTEX
  TSTTM_EDGE,           // MBEDGE
  TSTTM_FACE,           // MBTRI
  TSTTM_FACE,           // MBQUAD
  TSTTM_FACE,           // MBPOLYGON
  TSTTM_REGION,         // MBTET
  TSTTM_REGION,         // MBPYRAMID
  TSTTM_REGION,         // MBPRISM
  TSTTM_REGION,         // MBKNIFE
  TSTTM_REGION,         // MBHEX
  TSTTM_REGION,         // MBPOLYHEDRON
  TSTTM_ALL_TYPES, // MBENTITYSET
  TSTTM_ALL_TYPES  // MBMAXTYPE
};

// map to MB's entity type from TSTT's entity topology
const MBEntityType mb_topology_table[] =
{
  MBVERTEX,
  MBEDGE,
  MBPOLYGON,
  MBTRI,
  MBQUAD,
  MBPOLYHEDRON,
  MBTET,
  MBHEX,
  MBPRISM,
  MBPYRAMID,
  MBMAXTYPE,
  MBMAXTYPE
};

// map between TSTT's tag types and MOAB's
const MBDataType mb_data_type_table[] = 
{
  MB_TYPE_INTEGER,
  MB_TYPE_DOUBLE ,
  MB_TYPE_HANDLE ,
  MB_TYPE_OPAQUE
};

const TSTTM_TagValueType tstt_tag_value_table[] = 
{
  TSTTM_BYTES,
  TSTTM_INTEGER,
  TSTTM_DOUBLE,
  TSTTM_BYTES,
  TSTTM_ENTITY_HANDLE
};

const TSTTB_ErrorType TSTTB_ERROR_MAP[] = 
{
  TSTTB_SUCCESS, // MB_SUCCESS = 0,
  TSTTB_INVALID_ENTITY_HANDLE, // MB_INDEX_OUT_OF_RANGE,
  TSTTB_INVALID_ENTITY_TYPE, // MB_TYPE_OUT_OF_RANGE,
  TSTTB_MEMORY_ALLOCATION_FAILED, // MB_MEMORY_ALLOCATION_FAILED,
  TSTTB_INVALID_ENTITY_HANDLE, // MB_ENTITY_NOT_FOUND,
  TSTTB_NOT_SUPPORTED, // MB_MULTIPLE_ENTITIES_FOUND,
  TSTTB_TAG_NOT_FOUND, // MB_TAG_NOT_FOUND,
  TSTTB_FILE_NOT_FOUND, // MB_FILE_DOES_NOT_EXIST,
  TSTTB_FILE_WRITE_ERROR, // MB_FILE_WRITE_ERROR,
  TSTTB_NOT_SUPPORTED, // MB_NOT_IMPLEMENTED,
  TSTTB_TAG_ALREADY_EXISTS, // MB_ALREADY_ALLOCATED,
  TSTTB_FAILURE // MB_FAILURE};
};

struct RangeIterator
{
  MBRange iteratorRange;
  MBRange::iterator currentPos;
  int requestedSize;
};

#define MBI static_cast<MBInterface*>(instance)

#define RETURN(a) {TSTTM_LAST_ERROR.error_type = a; return a;}
#define TSTTM_processError(a, b) {sprintf(TSTTM_LAST_ERROR.description, b); TSTTM_LAST_ERROR.error_type = a;}

void TSTTM_tag_set_vertices(TSTTM_Instance instance,
                            MBEntityHandle in_set, 
                            const int req_dimension, const MBEntityType req_type,
                            MBTag &tag, MBRange &req_entities, int &num_verts);

TSTTB_Error TSTTM_LAST_ERROR;

TSTTB_ErrorType 
TSTTM_ctor(TSTTM_Instance *instance)
{
  if (NULL != *instance) delete (MBCore*) *instance;
  
  *instance = new MBCore();
  if (NULL == *instance) {
    TSTTM_processError(TSTTB_FAILURE, "Failed to instantiate mesh instance.");
    return TSTTB_FAILURE;
  }
  
  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_dtor(TSTTM_Instance instance)
{
  delete static_cast<MBCore*>(instance);
  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType TSTTM_load(TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle,
                          /*in*/ const char *name) 
{
  MBErrorCode result = MBI->load_mesh(name);

  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_load:ERROR loading a mesh, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType TSTTM_save(TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle entity_set,
                           /*in*/ const char *name ) 
{
  MBErrorCode result = MBI->write_mesh(name, CONST_HANDLE_ARRAY_PTR(&entity_set), 1);

  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_save:ERROR saving a mesh, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTM_EntityHandle TSTTM_getRootSet(TSTTM_Instance instance) 
{
  return 0;
    //return CAST_TO_VOID(MBI->get_root_set());
}

int
TSTTM_getGeometricDimension(TSTTM_Instance instance)
{
  int dim;
  MBI->get_dimension(dim);
  return dim;
}

TSTTM_StorageOrder 
TSTTM_getDfltStorage(TSTTM_Instance instance)
{
  return TSTTM_BLOCKED;
}
  
TSTTB_ErrorType
TSTTM_getAdjTable (TSTTM_Instance instance,
                   TSTTM_AdjacencyCost** adjacency_table,
                   /*inout*/ int* adjacency_table_allocated, 
                   /*out*/ int* adjacency_table_size )
{
  *adjacency_table_allocated = 0;
  *adjacency_table_size = 0;
  *adjacency_table = NULL;
  RETURN(TSTTB_ERROR_MAP[MB_SUCCESS]);
}

int 
TSTTM_getNumOfType(TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_set_handle,
                   /*in*/ const TSTTM_EntityType entity_type)
{
  int num_entities = 0;
  MBErrorCode result;
  if (entity_type == TSTTM_ALL_TYPES)
    result = MBI->get_number_entities_by_handle
      (ENTITY_HANDLE(entity_set_handle), num_entities);
  else
    result = MBI->get_number_entities_by_dimension
      (ENTITY_HANDLE(entity_set_handle), entity_type, num_entities);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_entitysetGetNumberEntityOfType: ERROR getting number of entities"
                    " by type, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return 0;
  }

  return num_entities;
}
  
int 
TSTTM_getNumOfTopo(TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_set_handle,
                   /*in*/ const TSTTM_EntityTopology entity_topology)
{
  int num_entities;
  MBErrorCode result = 
    MBI->get_number_entities_by_type(ENTITY_HANDLE(entity_set_handle), 
                                     mb_topology_table[entity_topology], 
                                     num_entities);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_entitysetGetNumberEntityOfTopology: ERROR getting "
                    "number of entities by topology., with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return -1;
  }
  else
    return num_entities;
}

TSTTB_ErrorType
TSTTM_getAllVtxCoords (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_set_handle,
                       /*inout*/ double** coordinates,
                       /*inout*/ int* coordinates_allocated,
                       /*out*/ int* coordinates_size,
                       /*inout*/ int** in_entity_set,
                       /*inout*/ int* in_entity_set_allocated,
                       /*out*/ int* in_entity_set_size,
                       /*inout*/ TSTTM_StorageOrder* storage_order ) 
{
  MBEntityHandle in_set = ENTITY_HANDLE(entity_set_handle);

    // get all the entities then vertices
  MBRange entities, vertices;
  MBErrorCode result = MBI->get_entities_by_handle(in_set, entities, false);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_entitysetGetVertexCoordinates: getting entities didn't succeed, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }
  
    // get all the vertices
  result = MBI->get_adjacencies(entities, 0, false, vertices,
                                MBInterface::UNION);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_entitysetGetVertexCoordinates: getting vertices didn't succeed, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }
  
    // now get all the coordinates
  *coordinates_size = 3*vertices.size();
  CHECK_SIZE(*coordinates, *coordinates_allocated,
             *coordinates_size, double, TSTTB_MEMORY_ALLOCATION_FAILED);
  *in_entity_set_size = vertices.size();
  CHECK_SIZE(*in_entity_set, *in_entity_set_allocated,
             *in_entity_set_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);
  
    // coords will come back interleaved by default
  MBRange::iterator vit;
  if (*storage_order == TSTTM_INTERLEAVED || *storage_order == TSTTM_UNDETERMINED) {
    result = MBI->get_coords(vertices, *coordinates);
    *storage_order = TSTTM_INTERLEAVED;
  }
  
  else {
    double *dum_coords = new double[3*vertices.size()];
    result = MBI->get_coords(vertices, dum_coords);
    if (MB_SUCCESS == result) {
      unsigned int offset = vertices.size();
      for (unsigned int i= 0; i < offset; i++) {
        (*coordinates)[i]= dum_coords[3*i];
        (*coordinates)[offset+i] = dum_coords[3*i+1];
        (*coordinates)[2*offset+i] = dum_coords[3*i+2];
      }
    }
    delete [] dum_coords;
  }
  
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_entitysetGetVertexCoordinates: problem getting vertex coords, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }
  
    // now fill the in_entity_set array
  MBRange::iterator endr = entities.end();
  int i;
  for (i = 0, vit = vertices.begin(); vit != vertices.end(); vit++, i++) {
    if (0 == in_set || entities.find(*vit) != endr)
      (*in_entity_set)[i] = 1;
    else 
      (*in_entity_set)[i] = 0;
  }

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_getVtxCoordIndex (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set_handle,
                        /*in*/ const TSTTM_EntityType requested_entity_type,
                        /*in*/ const TSTTM_EntityTopology requested_entity_topology,
                        /*in*/ const TSTTM_EntityType entity_adjacency_type,
                        /*inout*/ int** offset,
                        /*inout*/ int* offset_allocated,
                        /*out*/ int* offset_size,
                        /*inout*/ int** index,
                        /*inout*/ int* index_allocated,
                        /*out*/ int* index_size,
                        /*inout*/  TSTTM_EntityTopology** entity_topologies,
                        /*inout*/ int* entity_topologies_allocated,
                        /*out*/ int* entity_topologies_size ) 
{
  MBEntityType req_type = mb_topology_table[requested_entity_topology];
  int req_dimension = (req_type == MBMAXTYPE ? (int) requested_entity_type : -1);

  MBEntityHandle in_set = ENTITY_HANDLE(entity_set_handle);
  
  MBTag pos_tag = 0;
  MBRange req_entities;
  int num_verts;
  TSTTM_tag_set_vertices(instance, in_set, req_dimension, req_type, pos_tag, 
                         req_entities, num_verts);
  if (0 == pos_tag || req_entities.empty()) {
    *offset_size = 0;
    *index_size = 0;
    *entity_topologies_size = 0;
    RETURN(TSTTB_SUCCESS);
  }
  
    // now get the connectivity; get it all in one vector before setting indices, so that
    // we can check size of or allocate index vector; but, we can check and allocate
    // count vector
  const MBEntityHandle *tmp_connect;
  int num_connect;
  std::vector<MBEntityHandle> connect;
  *offset_size = req_entities.size();
  CHECK_SIZE(*offset, *offset_allocated, *offset_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);
  *entity_topologies_size = req_entities.size();
  CHECK_SIZE(*entity_topologies, *entity_topologies_allocated, 
             *entity_topologies_size, TSTTM_EntityTopology, TSTTB_MEMORY_ALLOCATION_FAILED);
  
  MBRange::iterator ent_it;
  int curr_offset = 0;
  int i;
  for (ent_it = req_entities.begin(), i = 0; ent_it != req_entities.end(); 
       ent_it++, i++) {
    MBErrorCode result = MBI->get_connectivity(*ent_it, tmp_connect, num_connect, true);
    if (MB_SUCCESS != result) {
      std::string msg("TSTTM_getVtxCoordIndex: couldn't get connectivity, with error type: ");
      msg += MBI->get_error_string(result);
      TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
      return TSTTB_ERROR_MAP[result];
    }
    std::copy(tmp_connect, tmp_connect+num_connect, std::back_inserter(connect));
    MBEntityType this_type = MBI->type_from_handle(*ent_it);
    (*entity_topologies)[i] = tstt_topology_table[this_type];
    (*offset)[i] = curr_offset;
    curr_offset += num_connect;
  }
  
    // now check size of, allocate, and assign index vector
  *index_size = connect.size();
  CHECK_SIZE(*index, *index_allocated, *index_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);
    // get the tags all at once, it's more efficient
  MBErrorCode result = MBI->tag_get_data(pos_tag, &connect[0], 
                                         connect.size(), *index);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_getVtxCoordIndex: couldn't get index tag, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

    // don't need the tag any more
  result = MBI->tag_delete(pos_tag);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_getVtxCoordIndex: error deleting tag, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType 
TSTTM_getEntities(TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_set_handle,
                  /*in*/ const TSTTM_EntityType entity_type,
                  /*in*/ const TSTTM_EntityTopology entity_topology,
                  /*inout*/ TSTTM_EntityHandle** entity_handles,
                  /*inout*/ int* entity_handles_allocated,
                  /*out*/ int* entity_handles_size ) 
{
  bool use_top = false;
  bool use_type = false;
  MBEntityType type;
  MBRange out_entities;
 
  if (entity_topology >= TSTTM_POINT
      && entity_topology < TSTTM_ALL_TOPOLOGIES) {
    type = mb_topology_table[entity_topology];
    use_top = true;
  }
  else if (entity_type >= TSTTM_VERTEX
           && entity_type <= TSTTM_ALL_TYPES)
    use_type = true;
  else {
    TSTTM_processError(TSTTB_ERROR_MAP[TSTTB_BAD_TYPE_AND_TOPO], 
                       "TSTTM_getEntities:ERROR not valid entity type or topology");
    return TSTTB_ERROR_MAP[TSTTB_BAD_TYPE_AND_TOPO];
  }

  MBEntityHandle handle = ENTITY_HANDLE(entity_set_handle);
  MBErrorCode result;

  if (use_top)
    result = MBI->get_entities_by_type(handle, type, out_entities);
  else if (use_type && entity_type != TSTTM_ALL_TYPES)
    result = MBI->get_entities_by_dimension(handle, entity_type, out_entities);
  else 
    result = MBI->get_entities_by_handle(handle, out_entities);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_GetEntities:ERROR getting entities, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  *entity_handles_size = out_entities.size();
  CHECK_SIZE(*entity_handles, *entity_handles_allocated, 
             *entity_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  
  MBRange::iterator iter = out_entities.begin();
  MBRange::iterator end_iter = out_entities.end();
  int k = 0;

    // filter out entity sets here
  if (TSTTM_ALL_TYPES == entity_type && TSTTM_ALL_TOPOLOGIES == entity_topology) {
    for (; iter != end_iter && MBI->type_from_handle(*iter) != MBENTITYSET; iter++)
      (*entity_handles)[k++] = CAST_TO_VOID(*iter);
    *entity_handles_size = k;
  }
  else {
    for (; iter != end_iter; iter++)
      (*entity_handles)[k++] = CAST_TO_VOID(*iter);
  }

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_getVtxArrCoords (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle* vertex_handles,
                       /*in*/ const int vertex_handles_size,
                       /*inout*/ TSTTM_StorageOrder* storage_order,
                       /*inout*/ double** coords,
                       /*inout*/ int* coords_allocated,
                       /*out*/ int* coords_size ) 
{

    // make sure we can hold them all
  *coords_size = 3*vertex_handles_size;
  CHECK_SIZE(*coords, *coords_allocated, *coords_size, double, TSTTB_MEMORY_ALLOCATION_FAILED);
  
    // now get all the coordinates
    // coords will come back interleaved by default
  MBErrorCode result;
  if (*storage_order == TSTTM_INTERLEAVED || *storage_order == TSTTM_UNDETERMINED) {
    result = MBI->get_coords(CONST_HANDLE_ARRAY_PTR(vertex_handles), 
                             vertex_handles_size, *coords);
    *storage_order = TSTTM_INTERLEAVED;
  }
  
  else {
    std::vector<double> dum_coords(3*vertex_handles_size);
    result = MBI->get_coords(CONST_HANDLE_ARRAY_PTR(vertex_handles), 
                             vertex_handles_size,
                             &dum_coords[0]);
    if (MB_SUCCESS == result) {
      int i;
      double *x = *coords;
      double *y = *coords+vertex_handles_size;
      double *z = *coords+2*vertex_handles_size;
      std::vector<double>::const_iterator c_iter = dum_coords.begin();
      for (i = 0; i < vertex_handles_size; i++) {
        *x = *c_iter; ++x; ++c_iter;
        *y = *c_iter; ++y; ++c_iter;
        *z = *c_iter; ++z; ++c_iter;
      }
    }
  }
  
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_getVtxArrCoords: problem getting vertex coords, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_getAdjEntities(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set_handle,
                     /*in*/ const TSTTM_EntityType entity_type_requestor,
                     /*in*/ const TSTTM_EntityTopology entity_topology_requestor,
                     /*in*/ const TSTTM_EntityType entity_type_requested,
                     /*inout*/ TSTTM_EntityHandle** adj_entity_handles,
                     /*inout*/ int* adj_entity_handles_allocated,
                     /*out*/ int* adj_entity_handles_size,
                     /*inout*/ int** offset,
                     /*inout*/ int* offset_allocated,
                     /*out*/ int* offset_size,
                     /*inout*/ int** in_entity_set,
                     /*inout*/ int* in_entity_set_allocated,
                     /*out*/ int* in_entity_set_size ) 
{
  MBEntityHandle in_set = ENTITY_HANDLE(entity_set_handle);
  MBRange entities;
  MBEntityType requestor_type = mb_topology_table[entity_topology_requestor];
  MBErrorCode result;

  if (entity_type_requestor == TSTTM_ALL_TYPES &&
      entity_topology_requestor == TSTTM_ALL_TOPOLOGIES )
    result = MBI->get_entities_by_handle( in_set, entities );
  else if (requestor_type == MBMAXTYPE)
    result = MBI->get_entities_by_dimension
      (in_set, (int) entity_type_requestor, entities);
  else
    result = MBI->get_entities_by_type(in_set, requestor_type, entities);
  
  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_getAdjEntities: ERROR getting requestor entities in entityset, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  int num_entities = entities.size();

  if (num_entities == 0) 
  {
    *adj_entity_handles_size = *offset_size = *in_entity_set_size = 0;
    RETURN(TSTTB_ERROR_MAP[result]);
  }

    // first, count the number of adjacent entities we'll have
  int num_sub = 0;
  int to_dim = entity_type_requested;
  if (to_dim == 0) {
    const MBEntityHandle *connect;
    int num_connect;
    MBErrorCode result;
    for (MBRange::iterator rit = entities.begin(); rit != entities.end(); rit++) {
      result = MBI->get_connectivity(*rit, connect, num_connect);
      if (MB_SUCCESS != result) RETURN(TSTTB_ERROR_MAP[result]);
      num_sub += num_connect;
    }
  }
  else {
    MBRange tmp_adjs;
    MBErrorCode result;
    for (MBRange::iterator rit = entities.begin(); rit != entities.end(); rit++) {
      result = MBI->get_adjacencies(&(*rit), 1, to_dim, false, tmp_adjs);
      if (MB_SUCCESS != result) RETURN(TSTTB_ERROR_MAP[result]);
      num_sub += tmp_adjs.size();
      tmp_adjs.clear();
    }
  }
  
    // allocate enough space for those adjacent entities
  *adj_entity_handles_size = num_sub;
  CHECK_SIZE(*adj_entity_handles, *adj_entity_handles_allocated,
             *adj_entity_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  
  *offset_size = entities.size();
  CHECK_SIZE(*offset, *offset_allocated, *offset_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);

  *in_entity_set_size = num_sub;
  CHECK_SIZE(*in_entity_set, *in_entity_set_allocated,
             *in_entity_set_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);

    // now iterate over entities
  num_sub = 0;
  int i = 0;
  std::vector<MBEntityHandle> adj_ents;
  MBRange::iterator endr = entities.end();
  for (MBRange::iterator rit = entities.begin(); rit != endr; rit++) {
    adj_ents.clear();
    (*offset)[i] = num_sub;
    
    result = MBI->get_adjacencies(&(*rit), 1, (int)entity_type_requested, false,
                                  adj_ents);
    
    if (result != MB_SUCCESS) {
      std::string msg("TSTTM_getAdjEntities: ERROR getting adjacencies of requested entities, "
                      "with error type: ");
      msg += MBI->get_error_string(result);
      TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
      return TSTTB_ERROR_MAP[result];
    }
    
    for (std::vector<MBEntityHandle>::iterator vit = adj_ents.begin(); 
         vit != adj_ents.end(); vit++) {
      (*adj_entity_handles)[num_sub] = CAST_TO_VOID(*vit);
      if (0 == in_set || entities.find(*vit) != endr)
        (*in_entity_set)[num_sub] = 1;
      else
        (*in_entity_set)[num_sub] = 0;

      num_sub++;
    }

    i++;
  }

  RETURN(TSTTB_SUCCESS);
}

/**
 * Method:  initEntArrIter[]
 */
bool
TSTTM_initEntArrIter (TSTTM_Instance instance,
                      /*in*/ const TSTTM_EntityHandle entity_set_handle,
                      /*in*/ const TSTTM_EntityType requested_entity_type,
                      /*in*/ const TSTTM_EntityTopology requested_entity_topology,
                      /*in*/ const int requested_array_size,
                      /*out*/ TSTTM_EntityIterator* entArr_iterator ) 
{
  MBEntityType req_type = mb_topology_table[requested_entity_topology];
  int req_dimension = (req_type == MBMAXTYPE ? (int) requested_entity_type : -1);
  RangeIterator *new_it = new RangeIterator;
  *entArr_iterator = new_it;
  new_it->requestedSize = requested_array_size;
  
  MBErrorCode result;
  if (requested_entity_type == TSTTM_ALL_TYPES &&
      requested_entity_topology == TSTTM_ALL_TOPOLOGIES)
    result = MBI->get_entities_by_handle( ENTITY_HANDLE(entity_set_handle),
                                          new_it->iteratorRange );
  else if (MBMAXTYPE != req_type)
    result = MBI->get_entities_by_type(ENTITY_HANDLE(entity_set_handle),
                                       req_type,
                                       new_it->iteratorRange);
  else
    result = MBI->get_entities_by_dimension(ENTITY_HANDLE(entity_set_handle),
                                            req_dimension,
                                            new_it->iteratorRange);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_initEntArrIter: ERROR getting entities of proper type or topology, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    TSTTM_LAST_ERROR.error_type = TSTTB_ERROR_MAP[result];
    return false;
  }

  new_it->currentPos = new_it->iteratorRange.begin();
  TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;

  return (!new_it->iteratorRange.empty());
}

/**
 * Method:  getEntArrNextIter[]
 */
bool
TSTTM_getNextEntArrIter (TSTTM_Instance instance,
                         /*in*/ TSTTM_EntityIterator entArr_iterator,
                         /*inout*/ TSTTM_EntityHandle** entity_handles,
                         /*inout*/ int* entity_handles_allocated,
                         /*out*/ int* entity_handles_size ) 
{
  RangeIterator *this_it = RANGE_ITERATOR(entArr_iterator);

    // check the size of the destination array
  int expected_size = (this_it->requestedSize < (int)this_it->iteratorRange.size() ? 
                       this_it->requestedSize : this_it->iteratorRange.size());
  CHECK_SIZE(*entity_handles, *entity_handles_allocated, expected_size,
             TSTTM_EntityHandle, false);
  
  int& i = *entity_handles_size;
  for (i = 0; i < this_it->requestedSize; ++i, ++this_it->currentPos)
  {
    if (this_it->currentPos == this_it->iteratorRange.end())
      return false;
    (*entity_handles)[i] = CAST_TO_VOID(*this_it->currentPos);
  }
  
  return true;
}

/**
 * Method:  resetEntArrIter[]
 */
TSTTB_ErrorType
TSTTM_resetEntArrIter (TSTTM_Instance instance,
                       /*in*/ TSTTM_EntityIterator entArr_iterator ) 
{
  RangeIterator *this_it = RANGE_ITERATOR(entArr_iterator);

  this_it->currentPos = this_it->iteratorRange.begin();

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_endEntArrIter (TSTTM_Instance instance,
                     /*in*/ TSTTM_EntityIterator entArr_iterator ) 
{
  RangeIterator *this_it = RANGE_ITERATOR(entArr_iterator);

  this_it->currentPos = this_it->iteratorRange.end();

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType 
TSTTM_getEntArrTopo(TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle* entity_handles,
                    /*in*/ const int entity_handles_size,
                    /*inout*/ TSTTM_EntityTopology** topology,
                    /*inout*/ int* topology_allocated,
                    /*out*/ int* topology_size ) 
{
    // go through each entity and look up its type
  *topology_size = entity_handles_size;
  CHECK_SIZE(*topology, *topology_allocated, *topology_size, TSTTM_EntityTopology, TSTTB_MEMORY_ALLOCATION_FAILED);

  for (int i = 0; i < entity_handles_size; i++)
    (*topology)[i] = 
      tstt_topology_table[MBI->type_from_handle(ENTITY_HANDLE(entity_handles[i]))];

  RETURN(TSTTB_SUCCESS);
}
  
TSTTB_ErrorType 
TSTTM_getEntArrType(TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle* entity_handles,
                    /*in*/ const int entity_handles_size,
                    /*inout*/ TSTTM_EntityType** etype,
                    /*inout*/ int* etype_allocated,
                    /*out*/ int* etype_size) 
{
    // go through each entity and look up its type
  *etype_size = entity_handles_size;
  CHECK_SIZE(*etype, *etype_allocated, *etype_size, TSTTM_EntityType, TSTTB_MEMORY_ALLOCATION_FAILED);

  for (int i = 0; i < entity_handles_size; i++)
    (*etype)[i] = 
      tstt_type_table[MBI->type_from_handle(ENTITY_HANDLE(entity_handles[i]))];

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType
TSTTM_getEntArrAdj(TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle* entity_handles,
                   /*in*/ const int entity_handles_size,
                   /*in*/ const TSTTM_EntityType entity_type_requested,
                   /*inout*/ TSTTM_EntityHandle** adjacentEntityHandles,
                   /*inout*/ int* adjacentEntityHandles_allocated,
                   /*out*/ int* adjacentEntityHandles_size,
                   /*inout*/ int** offset,
                   /*inout*/ int* offset_allocated,
                   /*out*/ int* offset_size ) 
{
  MBErrorCode result = MB_SUCCESS;

  *offset_size = entity_handles_size;
  CHECK_SIZE(*offset, *offset_allocated, *offset_size, int, TSTTB_MEMORY_ALLOCATION_FAILED);
  
  const MBEntityHandle* entity_iter = (const MBEntityHandle*)entity_handles;
  const MBEntityHandle* const entity_end = entity_iter + entity_handles_size;
  int* off_iter = *offset;
  int prev_off = 0;
  
  std::vector<MBEntityHandle> all_adj_ents;
    
  for ( ; entity_iter != entity_end; ++entity_iter, ++off_iter )
  {
    *off_iter = prev_off;
    std::vector<MBEntityHandle> adj_ents;

    result = MBI->get_adjacencies( entity_iter, 1, entity_type_requested, false, adj_ents );
    if (MB_SUCCESS != result) {
      TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getEntArrAdj: trouble getting adjacency list.");
      return TSTTB_ERROR_MAP[result];
    }

    std::copy(adj_ents.begin(), adj_ents.end(), std::back_inserter(all_adj_ents));
    prev_off += adj_ents.size();
  }
    
  CHECK_SIZE(*adjacentEntityHandles, *adjacentEntityHandles_allocated, 
             (int)all_adj_ents.size(), 
             TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  memcpy(*adjacentEntityHandles, &all_adj_ents[0], sizeof(MBEntityHandle) * all_adj_ents.size() );
  *adjacentEntityHandles_size = all_adj_ents.size();

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType TSTTM_createEntSet(TSTTM_Instance instance,
                                  /*in*/ const bool isList,
                                  /*out*/ TSTTM_EntityHandle* entity_set_created ) 
{
    // create the entity set
  MBEntityHandle meshset;
  MBErrorCode result;

  if (isList)
    result = MBI->create_meshset(MESHSET_ORDERED, meshset);
  else
    result = MBI->create_meshset(MESHSET_SET, meshset);
  
  if (MB_SUCCESS != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_createEntSet: ERROR creating a entityset instance");
    return TSTTB_ERROR_MAP[result];
  }
  
    // return EntitySet_Handle
  *entity_set_created = CAST_TO_VOID(meshset);
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_destroyEntSet (TSTTM_Instance instance,
                     /*in*/ TSTTM_EntityHandle entity_set) 
{
  MBErrorCode result = MBI->delete_entities(HANDLE_ARRAY_PTR(&entity_set), 1);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_destroyEntSet: couldn't delete the set.");
  

  RETURN(TSTTB_SUCCESS);
}

bool
TSTTM_isList (TSTTM_Instance instance,
              /*in*/ const TSTTM_EntityHandle entity_set ) 
{
  unsigned int options;
  MBErrorCode result = MBI->get_meshset_options(ENTITY_HANDLE(entity_set), options);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_isList: couldn't query set.");
  if (options & MESHSET_ORDERED) return true;
  return false;
}

int 
TSTTM_getNumEntSets(TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle entity_set_handle,
                    /*in*/ const int num_hops ) 
{
  if (num_hops > 1) {
    TSTTM_processError(TSTTB_ERROR_MAP[TSTTB_NOT_SUPPORTED], 
                       "TSTTM_getNumEntSets: not currently implemented for num_hops > 1.");
    return 0;
  }
    
  int num_sets = 0;
  MBErrorCode result = MBI->get_number_entities_by_type
    (ENTITY_HANDLE(entity_set_handle), MBENTITYSET, 
     num_sets, (num_hops == -1 ? true : false));

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_entitysetGetNumberEntitySets:ERROR getting number of entitysets "
                    "in EntitySet, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  return num_sets;
} 

TSTTB_ErrorType 
TSTTM_getEntSets(TSTTM_Instance instance,
                 /*in*/ const TSTTM_EntityHandle entity_set_handle,
                 /*in*/ const int num_hops,
                 /*inout*/ TSTTM_EntityHandle** contained_entset_handles,
                 /*inout*/ int* contained_entset_handles_allocated,
                 /*inout*/ int* contained_entset_handles_size ) 
{
  if (num_hops > 1) {
    TSTTM_processError(TSTTB_NOT_SUPPORTED, "TSTTM_getEntSets: not currently implemented for num_hops > 1.");
    return TSTTB_NOT_SUPPORTED;
  }
    
  MBRange sets;
  MBErrorCode result = MBI->get_entities_by_type
    (ENTITY_HANDLE(entity_set_handle), MBENTITYSET, sets, (num_hops == -1 ? true : false));
  if (MB_SUCCESS != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_entitysetGetEntitySets: problem getting entities by type.");
    return TSTTB_ERROR_MAP[result];
  }

  *contained_entset_handles_size = sets.size();
  CHECK_SIZE(*contained_entset_handles, *contained_entset_handles_allocated,
             *contained_entset_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);

  MBRange::iterator iter = sets.begin();
  MBRange::iterator end_iter = sets.end();
  int k = 0;

  for (; iter != end_iter; iter++)
    (*contained_entset_handles)[k++] = CAST_TO_VOID(*iter);

  RETURN(TSTTB_SUCCESS);
}

TSTTB_ErrorType TSTTM_addEntToSet(TSTTM_Instance instance,
                                 /*in*/ const TSTTM_EntityHandle entity_handle,
                                 /*inout*/ TSTTM_EntityHandle* entity_set)
{
  return TSTTM_addEntArrToSet(instance, &entity_handle, 1, entity_set);
}

TSTTB_ErrorType TSTTM_rmvEntFromSet(TSTTM_Instance instance,
                                   /*in*/ const TSTTM_EntityHandle entity_handle,
                                   /*inout*/ TSTTM_EntityHandle* entity_set)
{
  return TSTTM_rmvEntArrFromSet(instance, &entity_handle, 1, entity_set);
}
  
TSTTB_ErrorType 
TSTTM_addEntArrToSet(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*inout*/ TSTTM_EntityHandle* entity_set)
{
  const MBEntityHandle *ents = CONST_HANDLE_ARRAY_PTR(entity_handles);
  MBErrorCode result = MBI->add_entities(ENTITY_HANDLE(*entity_set),
                                         ents, entity_handles_size);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_addEntArrToSet:ERROR adding entities in EntitySet, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_rmvEntArrFromSet(TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle* entity_handles,
                       /*in*/ const int entity_handles_size,
                       /*inout*/ TSTTM_EntityHandle* entity_set)
{
  const MBEntityHandle *ents = CONST_HANDLE_ARRAY_PTR(entity_handles);

  MBErrorCode result = MBI->remove_entities
    (ENTITY_HANDLE(*entity_set), ents, entity_handles_size);
  
  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_rmvEntArrFromSet:ERROR removing entities in EntitySet, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  

  RETURN(TSTTB_ERROR_MAP[result]);
}
  
TSTTB_ErrorType 
TSTTM_addEntSet(TSTTM_Instance instance,
                /*in*/ const TSTTM_EntityHandle entity_set_to_add,
                /*inout*/ TSTTM_EntityHandle* entity_set_handle)
{
  MBErrorCode result = MBI->add_entities(ENTITY_HANDLE(*entity_set_handle),
                                         CONST_HANDLE_ARRAY_PTR(&entity_set_to_add), 1);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_addEntSet:ERROR adding entitysets, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_rmvEntSet(TSTTM_Instance instance,
                /*in*/ const TSTTM_EntityHandle entity_set_to_remove,
                /*inout*/ TSTTM_EntityHandle *entity_set_handle)
{
  MBErrorCode result = MBI->remove_entities
    (ENTITY_HANDLE(entity_set_handle), CONST_HANDLE_ARRAY_PTR(&entity_set_to_remove), 1);
  
  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_rmvEntSet:ERROR removing entitysets in EntitySet, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

bool
TSTTM_isEntContained (TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle containing_entity_set,
                     /*in*/ const TSTTM_EntityHandle contained_entity) 
{
  MBRange all_ents;
  MBErrorCode result = MBI->get_entities_by_handle(ENTITY_HANDLE(containing_entity_set),
                                                   all_ents);
  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_isContainedIn:ERROR getting entities in EntitySet, "
                    "with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
  if (all_ents.find(ENTITY_HANDLE(contained_entity)) == all_ents.end())
    return false;
  
  return true;
}

bool
TSTTM_isEntSetContained (TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle containing_entity_set,
                         /*in*/ const TSTTM_EntityHandle contained_entity_set) 
{
  return TSTTM_isEntContained(instance, containing_entity_set, contained_entity_set);
}

TSTTB_ErrorType TSTTM_addPrntChld(TSTTM_Instance instance,
                                 /*inout*/ TSTTM_EntityHandle* parent_entity_set,
                                 /*inout*/ TSTTM_EntityHandle* child_entity_set ) 
{
  MBErrorCode result = MBI->add_parent_child
    (ENTITY_HANDLE(*parent_entity_set),
     ENTITY_HANDLE(*child_entity_set));

  if (result != MB_SUCCESS) {
    std::string msg("MB Mesh::addPrntChld: ERROR addParentChild failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType TSTTM_rmvPrntChld(TSTTM_Instance instance,
                                 /*inout*/ TSTTM_EntityHandle* parent_entity_set,
                                 /*inout*/ TSTTM_EntityHandle* child_entity_set)
{
  MBErrorCode result = MBI->remove_parent_child
    (ENTITY_HANDLE(*parent_entity_set),
     ENTITY_HANDLE(*child_entity_set));
  
  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_rmvPrntChld: ERROR RemoveParentChild failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  RETURN(TSTTB_ERROR_MAP[result]);
}

bool 
TSTTM_isChildOf(TSTTM_Instance instance,
                /*in*/ const TSTTM_EntityHandle parent_entity_set,
                /*in*/ const TSTTM_EntityHandle child_entity_set)
{
  std::vector<MBEntityHandle> children;

  MBErrorCode result = MBI->get_child_meshsets
    (ENTITY_HANDLE(parent_entity_set), children);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_isChildOf: ERROR IsParentChildRelated failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return false;
  }
  

  
  if (std::find(children.begin(), children.end(), ENTITY_HANDLE(child_entity_set))
      != children.end())
    return true;

  return false;
}

int TSTTM_getNumChld(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set,
                     /*in*/ const int num_hops)
{
  int num_children = 0;

  MBErrorCode result = MBI->num_child_meshsets
    (ENTITY_HANDLE(entity_set), &num_children, num_hops);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_getNumChld: ERROR GetNumChildren failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return 0;
  }

  return num_children;
}

int TSTTM_getNumPrnt(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set,
                     /*in*/ const int num_hops)
{
  int num_parents = 0;

  MBErrorCode result = MBI->num_parent_meshsets
    (ENTITY_HANDLE(entity_set), &num_parents, num_hops);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_getNumPrnt:\
           ERROR GetNumParents failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return 0;
  }

  return num_parents;
}

TSTTB_ErrorType TSTTM_getChldn(TSTTM_Instance instance,
                              /*in*/ const TSTTM_EntityHandle from_entity_set,
                              /*in*/ const int num_hops,
                              /*out*/ TSTTM_EntityHandle** entity_set_handles,
                              /*out*/ int* entity_set_handles_allocated,
                              /*out*/ int* entity_set_handles_size ) 
{
  std::vector<MBEntityHandle> children;

  MBErrorCode result = MBI->get_child_meshsets
    (ENTITY_HANDLE(from_entity_set), children, num_hops);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_getChldn:\
           ERROR getChildren failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  *entity_set_handles_size = (int)children.size();
  CHECK_SIZE(*entity_set_handles, *entity_set_handles_allocated,
             *entity_set_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);

  MBEntityHandle *ents = HANDLE_ARRAY_PTR(*entity_set_handles);
    // use a memcpy for efficiency
  memcpy(ents, &children[0], children.size()*sizeof(MBEntityHandle));

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType TSTTM_getPrnts(TSTTM_Instance instance,
                              /*in*/ const TSTTM_EntityHandle from_entity_set,
                              /*in*/ const int num_hops,
                              /*out*/ TSTTM_EntityHandle** entity_set_handles,
                              /*out*/ int* entity_set_handles_allocated,
                              /*out*/ int* entity_set_handles_size ) 
{
  std::vector<MBEntityHandle> parents;

  MBErrorCode result = MBI->get_parent_meshsets
    (ENTITY_HANDLE(from_entity_set), parents, num_hops);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_getPrnts:\
           ERROR getParents failed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return TSTTB_ERROR_MAP[result];
  }

  *entity_set_handles_size = (int)parents.size();
  CHECK_SIZE(*entity_set_handles, *entity_set_handles_allocated,
             *entity_set_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);

  MBEntityHandle *ents = HANDLE_ARRAY_PTR(*entity_set_handles);
    // use a memcpy for efficiency
  memcpy(ents, &parents[0], parents.size()*sizeof(MBEntityHandle));

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType TSTTM_setVtxArrCoords (TSTTM_Instance instance,
                                      /*in*/ TSTTM_EntityHandle* vertex_handles,
                                      /*in*/ const int vertex_handles_size,
                                      /*in*/ const TSTTM_StorageOrder storage_order,
                                      /*in*/ const double* new_coords,
                                      /*in*/ const int new_coords_size ) 
{
  MBErrorCode result = MB_SUCCESS, tmp_result;
  if (storage_order == TSTTM_INTERLEAVED) {
    result = MBI->set_coords(HANDLE_ARRAY_PTR(vertex_handles),
                             vertex_handles_size, new_coords);
  }
  else {
    MBEntityHandle *verts = HANDLE_ARRAY_PTR(vertex_handles);
    double dummy[3];
    for (int i = 0; i < vertex_handles_size; i++) {
      dummy[0] = new_coords[i]; dummy[1] = new_coords[vertex_handles_size+i]; 
      dummy[2] = new_coords[2*vertex_handles_size+i];
      tmp_result = MBI->set_coords(&verts[i], 1, dummy);
      if (MB_SUCCESS != tmp_result) result = tmp_result;
    }
  }
  
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_setVtxArrCoords: problem setting coordinates.");
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_createVtxArr(TSTTM_Instance instance,
                   /*in*/ const int num_verts,
                   /*in*/ const TSTTM_StorageOrder storage_order,
                   /*in*/ const double* new_coords,
                   /*in*/ const int new_coords_size,
                   /*inout*/ TSTTM_EntityHandle** new_vertex_handles,
                   /*inout*/ int* new_vertex_handles_allocated,
                   /*inout*/ int* new_vertex_handles_size) 
{
    // if there aren't any elements in the array, allocate it
  *new_vertex_handles_size = new_coords_size/3;
  CHECK_SIZE(*new_vertex_handles, *new_vertex_handles_allocated,
             *new_vertex_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  
    // make the entities
  MBEntityHandle *new_verts = HANDLE_ARRAY_PTR(*new_vertex_handles);
  
  for (int i = 0; i < *new_vertex_handles_size; i++) {
    MBErrorCode result = MBI->create_vertex(&new_coords[3*i], new_verts[i]);
    if (MB_SUCCESS != result) {
      TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_createVtxArr: couldn't create vertex.");
      return TSTTB_ERROR_MAP[result];
    }
  }  

  RETURN(TSTTB_SUCCESS);
}
                                                   
TSTTB_ErrorType 
TSTTM_createEntArr(TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityTopology new_entity_topology,
                   /*in*/ const TSTTM_EntityHandle* lower_order_entity_handles,
                   /*in*/ const int lower_order_entity_handles_size,
                   /*out*/ TSTTM_EntityHandle** new_entity_handles,
                   /*out*/ int* new_entity_handles_allocated,
                   /*out*/ int* new_entity_handles_size,
                   /*inout*/  TSTTM_CreationStatus** status,
                   /*inout*/ int* status_allocated,
                   /*out*/ int* status_size ) 
{
    // for now, throw an error if lower order entity handles aren't vertices
  MBEntityType this_type = mb_topology_table[new_entity_topology];
  int num_ents, num_verts;
  const MBEntityHandle *lower_ents;
  if (MBVERTEX != this_type) {
    num_verts = MBCN::VerticesPerEntity(this_type);
    num_ents = lower_order_entity_handles_size / num_verts;
    lower_ents = CONST_HANDLE_ARRAY_PTR(lower_order_entity_handles);
      // check that we have the right number of lower order entity handles
    if (lower_order_entity_handles_size % MBCN::VerticesPerEntity(this_type) != 0) {
      TSTTM_processError(TSTTB_ERROR_MAP[TSTTB_INVALID_ENTITY_COUNT], "TSTTM_createEntArr: wrong # vertices for this entity type.");
      return TSTTB_ERROR_MAP[TSTTB_INVALID_ENTITY_COUNT];
    }
  }
  
  if (num_ents == 0) {
    TSTTM_processError(TSTTB_INVALID_ENTITY_COUNT, 
                       "TSTTM_createEntArr: called to create 0 entities.");
    return TSTTB_ERROR_MAP[TSTTB_INVALID_ENTITY_COUNT];
  }

    // if there aren't any elements in the array, allocate it
  *new_entity_handles_size = num_ents;
  CHECK_SIZE(*new_entity_handles, *new_entity_handles_allocated,
             *new_entity_handles_size, TSTTM_EntityHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  
  *status_size = num_ents;
  if (0 == *status_allocated || *status_allocated < *status_size) {
    if (NULL != *status) free(*status); 
    *status = (TSTTM_CreationStatus*)malloc((*status_size)*sizeof(TSTTM_CreationStatus));
    *status_allocated=*status_size;
    if (NULL == *status) {
      TSTTM_processError(TSTTB_MEMORY_ALLOCATION_FAILED,
                         "Couldn't allocate array.");
      return TSTTB_MEMORY_ALLOCATION_FAILED; 
    }
  }
//  CHECK_SIZE(*status, *status_allocated, *status_size, TSTTM_CreationStatus, TSTTB_MEMORY_ALLOCATION_FAILED);
  
    // make the entities
  MBEntityHandle *new_ents = HANDLE_ARRAY_PTR(*new_entity_handles);
  static double dum_coords[] = {0.0, 0.0, 0.0};

  MBErrorCode tmp_result, result = MB_SUCCESS;
  
  if (this_type == MBVERTEX) {
    for (int i = 0; i < num_ents; i++) {
      tmp_result = MBI->create_vertex(dum_coords, new_ents[i]);
      if (MB_SUCCESS != tmp_result) {
        (*status)[i] = TSTTM_CREATION_FAILED;
        result = tmp_result;
      }
      else
        (*status)[i] = TSTTM_NEW;
    }  
  }
  else {
    for (int i = 0; i < num_ents; i++) {
      tmp_result = MBI->create_element(this_type, lower_ents, num_verts,
                                       new_ents[i]);
      if (MB_SUCCESS != tmp_result) {
        (*status)[i] = TSTTM_CREATION_FAILED;
        result = tmp_result;
      }
      else
        (*status)[i] = TSTTM_NEW;
    
      lower_ents += num_verts;
    }
  }

  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_createEntArr: couldn't create one of the entities.");

  RETURN(TSTTB_ERROR_MAP[result]);
}
                                                   
TSTTB_ErrorType
TSTTM_deleteEntArr(TSTTM_Instance instance,
                   /*in*/ TSTTM_EntityHandle* entity_handles,
                   /*in*/ const int entity_handles_size ) 
{
  if (0 == entity_handles_size) {
    RETURN(TSTTB_SUCCESS);
  }

  MBErrorCode result = MBI->delete_entities(HANDLE_ARRAY_PTR(entity_handles),
                                            entity_handles_size);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_deleteEntArr: trouble deleting entities.");

  RETURN(TSTTB_ERROR_MAP[result]);
}
                                                 
TSTTB_ErrorType
TSTTM_createTag(TSTTM_Instance instance,
                /*in*/ const char* tag_name,
                /*in*/ const int tag_size,
                /*in*/ const TSTTM_TagValueType tag_type,
                /*out*/ TSTTM_TagHandle* tag_handle)
{
  MBTag new_tag;
  int this_size = tag_size;
  switch (tag_type) {
    case TSTTM_INTEGER:
      this_size *= sizeof(int);
      break;
    case TSTTM_DOUBLE:
      this_size *= sizeof(double);
      break;
    case TSTTM_ENTITY_HANDLE:
      this_size *= sizeof(TSTTM_EntityHandle);
      break;
    case TSTTM_BYTES:
      break;
  }
      
  MBErrorCode result = MBI->tag_create(tag_name, this_size,
                                       MB_TAG_SPARSE, 
                                       mb_data_type_table[tag_type],
                                       new_tag,
                                       NULL);

  if (MB_SUCCESS != result && MB_ALREADY_ALLOCATED != result) {
    std::string msg = std::string("TSTTM_createTag: error creating tag with name '") +
      std::string(tag_name) + std::string("'.");
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  else if (MB_ALREADY_ALLOCATED == result) {
    std::string msg = std::string("TSTTM_createTag: tag with name '") +
      std::string(tag_name) + std::string("' already created.");
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  *tag_handle = new_tag;

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_destroyTag(TSTTM_Instance instance,
                 /*in*/ TSTTM_TagHandle tag_handle,
                 /*in*/ const bool forced)
{
    // might need to check if it's used first
  if (false == forced) {
    MBRange ents;
    MBErrorCode result;
    MBTag this_tag = TAG_HANDLE(tag_handle);
    for (MBEntityType this_type = MBVERTEX; this_type != MBMAXTYPE; this_type++) {
      result = MBI->get_entities_by_type_and_tag(0, this_type, &this_tag, NULL, 1, 
                                                 ents, MBInterface::UNION);
      if (result != MB_SUCCESS) {
        std::string msg("TSTTM_destroyTag: problem finding tag., with error type: ");
        msg += MBI->get_error_string(result);
        TSTTM_processError(TSTTB_ERROR_MAP[result],
                           msg.c_str());
      }
      else if (!ents.empty())
        RETURN(TSTTB_ERROR_MAP[result]);
    }
  }
  
    // ok, good to go - either forced or no entities with this tag
  MBErrorCode result = MBI->tag_delete(TAG_HANDLE(tag_handle));
  if (MB_SUCCESS != result && MB_TAG_NOT_FOUND != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_destroyTag: problem deleting tag.");

  RETURN(TSTTB_ERROR_MAP[result]);
}

const char *
TSTTM_getTagName(TSTTM_Instance instance,
                 /*in*/ const TSTTM_TagHandle tag_handle)
{
  static ::std::string name;
  MBErrorCode result = MBI->tag_get_name(TAG_HANDLE(tag_handle), name);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagName: problem getting name.")
  else
    TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;
  return name.c_str();
}

int
TSTTM_getTagSizeValues(TSTTM_Instance instance,
                       /*in*/ const TSTTM_TagHandle tag_handle)
{
  int tag_size;
  MBErrorCode result = MBI->tag_get_size(TAG_HANDLE(tag_handle), tag_size);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagSize: problem getting size.")
  else {
    switch (TSTTM_getTagType(instance, tag_handle)) {
      case TSTTM_INTEGER:
        tag_size /= sizeof(int);
        break;
      case TSTTM_DOUBLE:
        tag_size /= sizeof(double);
        break;
      case TSTTM_ENTITY_HANDLE:
        tag_size /= sizeof(MBEntityHandle);
        break;
      case TSTTM_BYTES:
        break;
    }
        
    TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;
  }
  
  return tag_size;
}

int
TSTTM_getTagSizeBytes(TSTTM_Instance instance,
                      /*in*/ const TSTTM_TagHandle tag_handle)
{
  int tag_size;
  MBErrorCode result = MBI->tag_get_size(TAG_HANDLE(tag_handle), tag_size);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagSize: problem getting size.")
  else {
    TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;
  }
  
  return tag_size;
}

TSTTM_TagHandle
TSTTM_getTagHandle(TSTTM_Instance instance,
                   /*in*/ const char* tag_name)
{
  MBTag tag_handle = 0;
  MBErrorCode result = MBI->tag_get_handle(tag_name, tag_handle);
    
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_getTagHandle: problem getting handle for tag named '");
    msg += std::string(tag_name) + std::string("'");
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    return 0;
  }

  TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;
  return tag_handle;
}

TSTTM_TagValueType
TSTTM_getTagType (TSTTM_Instance instance,
                  /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  MBDataType this_type;
  MBErrorCode result = MBI->tag_get_data_type(TAG_HANDLE(tag_handle),
                                              this_type);
  if (MB_SUCCESS != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagType: problem getting type.");
    return TSTTM_BYTES;
  }
  
  else
  {
    TSTTM_LAST_ERROR.error_type = TSTTB_SUCCESS;
    return tstt_tag_value_table[this_type];
  }
}

TSTTB_ErrorType 
TSTTM_setEntSetData (TSTTM_Instance instance,
                     /*in*/ TSTTM_EntityHandle entity_set_handle,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*in*/ const char* tag_value,
                     /*in*/ const int ) 
{
  MBErrorCode result;

  if (entity_set_handle == NULL)
      // set the tag data on this entity set
    result = MBI->tag_set_data(TAG_HANDLE(tag_handle),
                               NULL, 0, tag_value);
  else
    result = MBI->tag_set_data(TAG_HANDLE(tag_handle),
                               HANDLE_ARRAY_PTR(&entity_set_handle), 1, tag_value);
  
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_setEntSetData: error");

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_setEntSetIntData (TSTTM_Instance instance,
                        /*in*/ TSTTM_EntityHandle entity_set,
                        /*in*/ const TSTTM_TagHandle tag_handle,
                        /*in*/ const int tag_value ) 
{
  return TSTTM_setEntSetData(instance, entity_set, tag_handle, 
                             reinterpret_cast<const char*>(&tag_value), 
                             sizeof(int));
}

TSTTB_ErrorType
TSTTM_setEntSetDblData (TSTTM_Instance instance,
                        /*in*/ TSTTM_EntityHandle entity_set,
                        /*in*/ const TSTTM_TagHandle tag_handle,
                        /*in*/ const double tag_value ) 
{
  return TSTTM_setEntSetData(instance, entity_set, tag_handle, 
                             reinterpret_cast<const char*>(&tag_value),
                             sizeof(double));
}

TSTTB_ErrorType
TSTTM_setEntSetBoolData (TSTTM_Instance instance,
                         /*in*/ TSTTM_EntityHandle entity_set,
                         /*in*/ const TSTTM_TagHandle tag_handle,
                         /*in*/ const bool tag_value ) 
{
  return TSTTM_setEntSetData(instance, entity_set, tag_handle, 
                             reinterpret_cast<const char*>(&tag_value), 
                             sizeof(bool));
}

TSTTB_ErrorType
TSTTM_setEntSetEHData (TSTTM_Instance instance,
                       /*in*/ TSTTM_EntityHandle entity_set,
                       /*in*/ const TSTTM_TagHandle tag_handle,
                       /*in*/ const TSTTM_EntityHandle tag_value ) 
{
  return TSTTM_setEntSetData(instance, entity_set, tag_handle, 
                             reinterpret_cast<const char*>(&tag_value), 
                             sizeof(TSTTM_EntityHandle));
}

TSTTB_ErrorType
TSTTM_getEntSetData (TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set_handle,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*inout*/ char** tag_value,
                     /*inout*/ int* tag_value_allocated,
                     /*inout*/ int* tag_value_size) 
{
  MBEntityHandle eh = ENTITY_HANDLE(entity_set_handle);
  MBTag tag = TAG_HANDLE(tag_handle);

  int tag_size;
  MBErrorCode result = MBI->tag_get_size(tag, tag_size);
  if (MB_SUCCESS != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getEntSetData: couldn't get tag size.");
  }

  else {
    *tag_value_size = tag_size;
    TAG_CHECK_SIZE(*tag_value, *tag_value_allocated, *tag_value_size);

    if (eh == 0)
      result = MBI->tag_get_data(tag, NULL, 0, *tag_value);
    else
      result = MBI->tag_get_data(tag, &eh, 1, *tag_value);

    if (MB_SUCCESS != result)
      TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getEntSetData didn't succeed.");
  }
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

int
TSTTM_getEntSetIntData (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set,
                        /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  int tag_value;
  char *tag_ptr = reinterpret_cast<char*>(&tag_value);
  int dum_size = sizeof(int);
  TSTTM_getEntSetData(instance, entity_set, tag_handle, &tag_ptr, 
                      &dum_size, &dum_size);
  return tag_value;
}

double
TSTTM_getEntSetDblData (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set,
                        /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  double tag_value;
  char *tag_ptr = reinterpret_cast<char*>(&tag_value);
  int tag_size = sizeof(double);
  TSTTM_getEntSetData(instance, entity_set, tag_handle, &tag_ptr, 
                      &tag_size, &tag_size);
  return tag_value;
}

bool
TSTTM_getEntSetBoolData (TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle entity_set,
                         /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  bool tag_value;
  char *tag_ptr = reinterpret_cast<char*>(&tag_value);
  int tag_size = sizeof(bool);
  TSTTM_getEntSetData(instance, entity_set, tag_handle, &tag_ptr, 
                      &tag_size, &tag_size);
  return tag_value;
}

TSTTM_EntityHandle
TSTTM_getEntSetEHData (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_set,
                       /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  TSTTM_EntityHandle tag_value;
  char* tag_ptr = reinterpret_cast<char*>(&tag_value);
  int tag_size = sizeof(MBEntityHandle);
  TSTTM_getEntSetData(instance, entity_set, tag_handle, &tag_ptr, 
                      &tag_size, &tag_size);
  return tag_value;
}

TSTTB_ErrorType
TSTTM_getAllEntSetTags (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set_handle,
                        /*out*/ TSTTM_TagHandle** tag_handles,
                        /*out*/ int* tag_handles_allocated,
                        /*out*/ int* tag_handles_size ) 
{
  MBEntityHandle eh = ENTITY_HANDLE(entity_set_handle);
  std::vector<MBTag> all_tags;
  
  MBErrorCode result = MBI->tag_get_tags_on_entity(eh, all_tags);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_entitysetGetAllTagHandles failed.");
 
    // now put those tag handles into sidl array
  *tag_handles_size = (int) all_tags.size();
  CHECK_SIZE(*tag_handles, *tag_handles_allocated, 
             *tag_handles_size, TSTTM_TagHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  memcpy(*tag_handles, &all_tags[0], all_tags.size()*sizeof(MBTag));

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_rmvEntSetTag (TSTTM_Instance instance,
                    /*in*/ TSTTM_EntityHandle entity_set_handle,
                    /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  if (0 == entity_set_handle) {
    entity_set_handle = TSTTM_getRootSet(instance);
  }
  MBErrorCode result = MBI->tag_delete_data(TAG_HANDLE(tag_handle),
                                            HANDLE_ARRAY_PTR(&entity_set_handle), 1);
  
    // don't check return; this tag may have never been set on the entity set
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_setVtxCoords (TSTTM_Instance instance,
                    /*in*/ TSTTM_EntityHandle vertex_handle,
                      /*in*/ const double x, /*in*/ const double y, 
                      /*in*/ const double z)
                    
{
  const double xyz[3] = {x, y, z};
  
  return TSTTM_setVtxArrCoords(instance, &vertex_handle, 1, TSTTM_BLOCKED,
                               xyz, 3);
}

TSTTB_ErrorType
TSTTM_createVtx(TSTTM_Instance instance,
                /*in*/ const double x, /*in*/ const double y, 
                /*in*/ const double z,
                /*out*/ TSTTM_EntityHandle* new_vertex_handle ) 
{
  int dum = 1;
  const double xyz[3] = {x, y, z};
  return TSTTM_createVtxArr(instance, 1, TSTTM_BLOCKED,
                            xyz, 3, &new_vertex_handle, &dum, &dum);
}
                                                   
TSTTB_ErrorType 
TSTTM_createEnt(TSTTM_Instance instance,
                /*in*/ const TSTTM_EntityTopology new_entity_topology,
                /*in*/ const TSTTM_EntityHandle* lower_order_entity_handles,
                /*in*/ const int lower_order_entity_handles_size,
                /*out*/ TSTTM_EntityHandle* new_entity_handle,
                /*out*/ TSTTM_CreationStatus* status ) 
{
  if (0 == lower_order_entity_handles_size) {
    TSTTM_processError(TSTTB_INVALID_ENTITY_COUNT, 
                       "TSTTM_createEnt: need more than zero lower order entities.");
    return TSTTB_INVALID_ENTITY_COUNT;
  }

  int dum = 1;
  return TSTTM_createEntArr(instance, new_entity_topology, 
                            lower_order_entity_handles,
                            lower_order_entity_handles_size,
                            &new_entity_handle,
                            &dum, &dum,
                            &status, &dum, &dum);
}

TSTTB_ErrorType
TSTTM_deleteEnt(TSTTM_Instance instance,
                /*in*/ TSTTM_EntityHandle entity_handle) 
{
  return TSTTM_deleteEntArr(instance, &entity_handle, 1);
}
                                                 
TSTTB_ErrorType
TSTTM_getArrData (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle* entity_handles,
                  /*in*/ const int entity_handles_size,
                  /*in*/ const TSTTM_TagHandle tag_handle,
                  /*inout*/ char** tag_values,
                  /*inout*/int* tag_values_allocated,
                  /*out*/ int* tag_values_size) 
{
  const MBEntityHandle *ents = reinterpret_cast<const MBEntityHandle *>(entity_handles);
  MBTag tag = TAG_HANDLE(tag_handle);
  int tag_size;
  MBErrorCode result = MBI->tag_get_size(tag, tag_size);
  if (MB_SUCCESS != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getArrData: couldn't get tag size.");
    return TSTTB_ERROR_MAP[result];
  }
  *tag_values_size = tag_size * entity_handles_size;
  if (0 == entity_handles_size) {
    RETURN(TSTTB_ERROR_MAP[MB_SUCCESS]);
  }
  
  TAG_CHECK_SIZE(*tag_values, *tag_values_allocated, *tag_values_size);

  result = MBI->tag_get_data(tag, ents, entity_handles_size,
                             *tag_values);

  if (MB_SUCCESS != result && MB_TAG_NOT_FOUND != result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagData didn't succeed.");
  }
  else if (MB_TAG_NOT_FOUND == result) {
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getTagData: tag not found.");
  }

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_getIntArrData (TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*inout*/ int** tag_values,
                     /*inout*/ int* tag_values_allocated,
                     /*out*/ int* tag_values_size ) 
{
  *tag_values_allocated *= sizeof(int);
  *tag_values_size *= sizeof(int);
  TSTTB_ErrorType retval = TSTTM_getArrData(instance, entity_handles, 
                                           entity_handles_size, tag_handle,
                                           reinterpret_cast<char**>(tag_values), 
                                           tag_values_allocated, 
                                           tag_values_size);
  *tag_values_allocated /= sizeof(int);
  *tag_values_size /= sizeof(int);
  return retval;
}

TSTTB_ErrorType
TSTTM_getDblArrData (TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*inout*/ double** tag_values,
                     /*inout*/ int* tag_values_allocated,
                     /*out*/ int* tag_values_size ) 
{
  *tag_values_allocated *= sizeof(double);
  *tag_values_size *= sizeof(double);
  TSTTB_ErrorType retval = TSTTM_getArrData(instance, entity_handles, 
                                           entity_handles_size, tag_handle,
                                           reinterpret_cast<char**>(tag_values), 
                                           tag_values_allocated, tag_values_size);
  *tag_values_allocated /= sizeof(double);
  *tag_values_size /= sizeof(double);
  return retval;
}

TSTTB_ErrorType
TSTTM_getBoolArrData (TSTTM_Instance instance,
                      /*in*/ const TSTTM_EntityHandle* entity_handles,
                      /*in*/ const int entity_handles_size,
                      /*in*/ const TSTTM_TagHandle tag_handle,
                      /*inout*/ bool** tag_value,
                      /*inout*/ int* tag_value_allocated,
                      /*out*/ int* tag_value_size ) 
{
  *tag_value_allocated *= sizeof(bool);
  *tag_value_size *= sizeof(bool);
  TSTTB_ErrorType retval = TSTTM_getArrData(instance, entity_handles, 
                                           entity_handles_size, tag_handle,
                                           reinterpret_cast<char**>(tag_value), 
                                           tag_value_allocated, tag_value_size);
  *tag_value_allocated /= sizeof(bool);
  *tag_value_size /= sizeof(bool);
  return retval;
}

TSTTB_ErrorType
TSTTM_getEHArrData (TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle* entity_handles,
                    /*in*/ const int entity_handles_size,
                    /*in*/ const TSTTM_TagHandle tag_handle,
                    /*inout*/ TSTTM_EntityHandle** tag_value,
                    /*inout*/ int* tag_value_allocated,
                    /*out*/ int* tag_value_size ) 
{
  *tag_value_allocated *= sizeof(TSTTM_EntityHandle);
  *tag_value_size *= sizeof(TSTTM_EntityHandle);
  TSTTB_ErrorType retval = TSTTM_getArrData(instance, entity_handles, 
                                           entity_handles_size, tag_handle,
                                           reinterpret_cast<char**>(tag_value), 
                                           tag_value_allocated, 
                                           tag_value_size);
  *tag_value_allocated /= sizeof(TSTTM_EntityHandle);
  *tag_value_size /= sizeof(TSTTM_EntityHandle);
  return retval;
}

TSTTB_ErrorType
TSTTM_setArrData (TSTTM_Instance instance,
                  /*in*/ TSTTM_EntityHandle* entity_handles,
                  /*in*/ const int entity_handles_size,
                  /*in*/ const TSTTM_TagHandle tag_handle,
                  /*in*/ const char* tag_values,
                  /*in*/ const int tag_values_size) 
{
  if (0 == entity_handles_size) {
    RETURN(TSTTB_ERROR_MAP[MB_SUCCESS]);
  }

  MBErrorCode result = MBI->tag_set_data(TAG_HANDLE(tag_handle), 
                                         HANDLE_ARRAY_PTR(entity_handles),
                                         entity_handles_size,
                                         tag_values);
  if (MB_SUCCESS != result) {
    std::string msg("TSTTM_setArrData didn't succeed, with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_setIntArrData (TSTTM_Instance instance,
                     /*in*/ TSTTM_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*in*/ const int* tag_values,
                     /*in*/ const int tag_values_size ) 
{
  return TSTTM_setArrData(instance, entity_handles, 
                          entity_handles_size, tag_handle, 
                          reinterpret_cast<const char*>(tag_values), 
                          sizeof(int)*tag_values_size);
}

TSTTB_ErrorType
TSTTM_setDblArrData (TSTTM_Instance instance,
                     /*in*/ TSTTM_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*in*/ const TSTTM_TagHandle tag_handle,
                     /*in*/ const double* tag_values,
                     /*in*/ const int tag_values_size ) 
{
  return TSTTM_setArrData(instance, entity_handles, 
                          entity_handles_size, tag_handle, 
                          reinterpret_cast<const char*>(tag_values), 
                          sizeof(double)*tag_values_size);
}

TSTTB_ErrorType
TSTTM_setBoolArrData (TSTTM_Instance instance,
                      /*in*/ TSTTM_EntityHandle* entity_handles,
                      /*in*/ const int entity_handles_size,
                      /*in*/ const TSTTM_TagHandle tag_handle,
                      /*in*/ const bool* tag_values,
                      /*in*/ const int tag_values_size ) 
{
  return TSTTM_setArrData(instance, entity_handles, 
                          entity_handles_size, tag_handle, 
                          reinterpret_cast<const char*>(tag_values), 
                          sizeof(bool)*tag_values_size);
}

TSTTB_ErrorType
TSTTM_setEHArrData (TSTTM_Instance instance,
                    /*in*/ TSTTM_EntityHandle* entity_handles,
                    /*in*/ const int entity_handles_size,
                    /*in*/ const TSTTM_TagHandle tag_handle,
                    /*in*/ const TSTTM_EntityHandle* tag_values,
                    /*in*/ const int tag_values_size ) 
{
  return TSTTM_setArrData(instance, entity_handles, 
                          entity_handles_size, tag_handle, 
                          reinterpret_cast<const char*>(tag_values), 
                          sizeof(TSTTM_EntityHandle)*tag_values_size);
}

TSTTB_ErrorType
TSTTM_rmvArrTag (TSTTM_Instance instance,
                 /*in*/ TSTTM_EntityHandle* entity_handles,
                 /*in*/ const int entity_handles_size,
                 /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  MBErrorCode result = MBI->tag_delete_data(TAG_HANDLE(tag_handle),
                                            HANDLE_ARRAY_PTR(entity_handles),
                                            entity_handles_size);
  
    // don't check return; this tag may have never been set on the entity
  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_getData (TSTTM_Instance instance,
               /*in*/ const TSTTM_EntityHandle entity_handle,
               /*in*/ const TSTTM_TagHandle tag_handle,
               /*out*/ char** tag_value,
               /*inout*/ int *tag_value_allocated,
               /*out*/ int *tag_value_size) 
{
  return TSTTM_getArrData(instance, &entity_handle, 1,
                          tag_handle, tag_value, tag_value_allocated,
                          tag_value_size);
}

int
TSTTM_getIntData (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_handle,
                  /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  int val;
  char *val_ptr = reinterpret_cast<char*>(&val);
  int val_size = sizeof(int);
  TSTTM_getArrData(instance, &entity_handle, 1,
                   tag_handle, &val_ptr, &val_size, &val_size);
  return val;
}

double
TSTTM_getDblData (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_handle,
                  /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  double val;
  char *val_ptr = reinterpret_cast<char*>(&val);
  int val_size = sizeof(double);
  TSTTM_getArrData(instance, &entity_handle, 1,
                   tag_handle, &val_ptr, &val_size, &val_size);
  return val;
}

bool
TSTTM_getBoolData (TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_handle,
                   /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  bool val;
  char *val_ptr = reinterpret_cast<char*>(&val);
    // make the data size a full word, because of sidl needing at least a full word
  int val_size = sizeof(int);
  TSTTM_getArrData(instance, &entity_handle, 1,
                   tag_handle, &val_ptr, &val_size, &val_size);
  return val;
}

TSTTM_EntityHandle
TSTTM_getEHData (TSTTM_Instance instance,
                 /*in*/ const TSTTM_EntityHandle entity_handle,
                 /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  TSTTM_EntityHandle val;
  char *val_ptr = reinterpret_cast<char*>(&val);
  int dum = sizeof(TSTTM_EntityHandle);
  TSTTM_getArrData(instance, &entity_handle, 1,
                   tag_handle, &val_ptr, &dum, &dum);
  return val;
}

TSTTB_ErrorType
TSTTM_setData (TSTTM_Instance instance,
               /*in*/ TSTTM_EntityHandle entity_handle,
               /*in*/ const TSTTM_TagHandle tag_handle,
               /*in*/ const char* tag_value,
               /*in*/ const int tag_value_size ) 
{
  return TSTTM_setArrData(instance, &entity_handle, 1,
                          tag_handle, tag_value, tag_value_size);
}

TSTTB_ErrorType
TSTTM_setIntData (TSTTM_Instance instance,
                  /*in*/ TSTTM_EntityHandle entity_handle,
                  /*in*/ const TSTTM_TagHandle tag_handle,
                  /*in*/ const int tag_value ) 
{
  return TSTTM_setArrData(instance, &entity_handle, 1,
                          tag_handle, 
                          reinterpret_cast<const char*>(&tag_value), 
                          sizeof(int));
}

TSTTB_ErrorType
TSTTM_setDblData (TSTTM_Instance instance,
                   
                  /*in*/ TSTTM_EntityHandle entity_handle,
                  /*in*/ const TSTTM_TagHandle tag_handle,
                  /*in*/ const double tag_value ) 
{
  return TSTTM_setArrData(instance, &entity_handle, 1,
                          tag_handle, 
                          reinterpret_cast<const char*>(&tag_value), 
                          sizeof(double));
}

TSTTB_ErrorType
TSTTM_setBoolData (TSTTM_Instance instance,
                   /*in*/ TSTTM_EntityHandle entity_handle,
                   /*in*/ const TSTTM_TagHandle tag_handle,
                   /*in*/ const bool tag_value ) 
{
  return TSTTM_setArrData(instance, &entity_handle, 1,
                          tag_handle, 
                          reinterpret_cast<const char*>(&tag_value), 
                          sizeof(bool));
}

TSTTB_ErrorType
TSTTM_setEHData (TSTTM_Instance instance,
                 /*in*/ TSTTM_EntityHandle entity_handle,
                 /*in*/ const TSTTM_TagHandle tag_handle,
                 /*in*/ const TSTTM_EntityHandle tag_value ) 
{
  return TSTTM_setArrData(instance, &entity_handle, 1,
                          tag_handle, reinterpret_cast<const char*>(&tag_value), 
                          sizeof(TSTTM_EntityHandle));
}

TSTTB_ErrorType
TSTTM_getAllTags (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_handle,
                  /*inout*/ TSTTM_TagHandle** tag_handles,
                  /*inout*/ int* tag_handles_allocated,
                  /*out*/ int* tag_handles_size ) 
{
  std::vector<MBTag> all_tags;
  
  MBErrorCode result = MBI->tag_get_tags_on_entity(ENTITY_HANDLE(entity_handle), all_tags);
  if (MB_SUCCESS != result)
    TSTTM_processError(TSTTB_ERROR_MAP[result], "TSTTM_getAllTags failed.");
    
    // now put those tag handles into sidl array
  *tag_handles_size = (int)all_tags.size();
  CHECK_SIZE(*tag_handles, *tag_handles_allocated,
             *tag_handles_size, TSTTM_TagHandle, TSTTB_MEMORY_ALLOCATION_FAILED);
  memcpy(*tag_handles, &all_tags[0], all_tags.size()*sizeof(MBTag));

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType
TSTTM_rmvTag (TSTTM_Instance instance,
              /*in*/ TSTTM_EntityHandle entity_handle,
              /*in*/ const TSTTM_TagHandle tag_handle ) 
{
  return TSTTM_rmvArrTag(instance, &entity_handle, 1, tag_handle);
}

bool
TSTTM_initEntIter (TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_set_handle,
                   /*in*/ const TSTTM_EntityType requested_entity_type,
                   /*in*/ const TSTTM_EntityTopology requested_entity_topology,
                   /*out*/ TSTTM_EntityIterator* entity_iterator ) 
{
  return TSTTM_initEntArrIter(instance, entity_set_handle, requested_entity_type,
                              requested_entity_topology, 1, entity_iterator);
}

bool
TSTTM_getNextEntIter (TSTTM_Instance instance,
                      /*in*/ TSTTM_EntityIterator entity_iterator,
                      /*out*/ TSTTM_EntityHandle* entity_handle ) 
{
  int eh_size = 1;
  return TSTTM_getNextEntArrIter(instance,
                                 entity_iterator, &entity_handle, &eh_size, &eh_size);
  
}

TSTTB_ErrorType
TSTTM_resetEntIter (TSTTM_Instance instance,
                    /*in*/ TSTTM_EntityIterator entity_iterator ) 
{
  return TSTTM_resetEntArrIter(instance, entity_iterator);  
}

TSTTB_ErrorType
TSTTM_endEntIter (TSTTM_Instance instance,
                  /*in*/ TSTTM_EntityIterator entity_iterator ) 
{
  return TSTTM_endEntArrIter(instance, entity_iterator);
}

TSTTM_EntityTopology
TSTTM_getEntTopo (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_handle ) 
{
  return tstt_topology_table[MBI->type_from_handle(ENTITY_HANDLE(entity_handle))];
}
  
TSTTM_EntityType
TSTTM_getEntType (TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle entity_handle ) 
{
  return tstt_type_table[MBI->type_from_handle(ENTITY_HANDLE(entity_handle))];
}

TSTTB_ErrorType
TSTTM_getVtxCoord (TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle vertex_handle,
                     /*out*/ double &x, /*out*/ double &y, /*out*/ double &z)
{
  TSTTM_StorageOrder order = TSTTM_BLOCKED;
  double xyz[3] = {x, y, z};
  double *xyzp = xyz;
  int dum = 3;
  
  return TSTTM_getVtxArrCoords(instance,
                               &vertex_handle, 1, &order,
                               &xyzp, &dum, &dum);
}

TSTTB_ErrorType  
TSTTM_getEntAdj (TSTTM_Instance instance,
                 /*in*/ const TSTTM_EntityHandle entity_handle,
                 /*in*/ const TSTTM_EntityType entity_type_requested,
                 /*inout*/ TSTTM_EntityHandle** adj_entity_handles,
                 /*inout*/ int* adj_entity_handles_allocated,
                 /*out*/ int* adj_entity_handles_size )
{
  int offset = 1;
  int *offset_ptr = &offset;
  
  return TSTTM_getEntArrAdj(instance,
                            &entity_handle, 1, entity_type_requested,
                            adj_entity_handles, adj_entity_handles_allocated, 
                            adj_entity_handles_size, &offset_ptr, &offset, &offset);
}
 
TSTTB_ErrorType
TSTTM_subtract(TSTTM_Instance instance,
               /*in*/ const TSTTM_EntityHandle entity_set_1,
               /*in*/ const TSTTM_EntityHandle entity_set_2,
               /*out*/ TSTTM_EntityHandle* result_entity_set)
{
  MBEntityHandle temp_set;
  MBEntityHandle set1 = ENTITY_HANDLE(entity_set_1), 
    set2 = ENTITY_HANDLE(entity_set_2);
  MBErrorCode result = MBI->create_meshset(MESHSET_SET, temp_set);
  if (MB_SUCCESS == result) result = MBI->unite_meshset(temp_set, set1);
  if (MB_SUCCESS == result) result = MBI->subtract_meshset(temp_set, set2);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_entitysetSubtract:\
           ERROR subtract failed, with error type: ");
    msg += MBI->get_error_string(result);
    MBI->delete_entities(&temp_set, 1);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  *result_entity_set = CAST_TO_VOID(temp_set);

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_intersect(TSTTM_Instance instance,
                /*in*/ const TSTTM_EntityHandle entity_set_1,
                /*in*/ const TSTTM_EntityHandle entity_set_2,
                /*out*/ TSTTM_EntityHandle* result_entity_set)
{
  MBEntityHandle temp_set;
  MBEntityHandle set1 = ENTITY_HANDLE(entity_set_1), 
    set2 = ENTITY_HANDLE(entity_set_2);
  MBErrorCode result = MBI->create_meshset(MESHSET_SET, temp_set);
  if (MB_SUCCESS == result) result = MBI->unite_meshset(temp_set, set1);
  if (MB_SUCCESS == result) result = MBI->intersect_meshset(temp_set, set2);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_entitysetIntersect:\
           ERROR subtract failed, with error type: ");
    msg += MBI->get_error_string(result);
    MBI->delete_entities(&temp_set, 1);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  *result_entity_set = CAST_TO_VOID(temp_set);

  RETURN(TSTTB_ERROR_MAP[result]);
}

TSTTB_ErrorType 
TSTTM_unite(TSTTM_Instance instance,
            /*in*/ const TSTTM_EntityHandle entity_set_1,
            /*in*/ const TSTTM_EntityHandle entity_set_2,
            /*out*/ TSTTM_EntityHandle* result_entity_set)
{  
  MBEntityHandle temp_set;
  MBEntityHandle set1 = ENTITY_HANDLE(entity_set_1), 
    set2 = ENTITY_HANDLE(entity_set_2);
  MBErrorCode result = MBI->create_meshset(MESHSET_SET, temp_set);
  if (MB_SUCCESS == result) result = MBI->unite_meshset(temp_set, set1);
  if (MB_SUCCESS == result) result = MBI->unite_meshset(temp_set, set2);

  if (result != MB_SUCCESS) {
    std::string msg("TSTTM_entitysetIntersect:\
           ERROR subtract failed, with error type: ");
    msg += MBI->get_error_string(result);
    MBI->delete_entities(&temp_set, 1);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }

  *result_entity_set = CAST_TO_VOID(temp_set);

  RETURN(TSTTB_ERROR_MAP[result]);
}

void TSTTM_tag_set_vertices(TSTTM_Instance instance,
                            MBEntityHandle in_set, 
                            const int req_dimension, const MBEntityType req_type,
                            MBTag &tag, MBRange &req_entities, int &num_verts) 
{
    // get all the entities then vertices
  MBRange vertices, entities;
  entities.clear();
  MBErrorCode result = MBI->get_entities_by_handle(in_set, entities, false);
  if (MB_SUCCESS != result) {
    std::string msg("MBMesh::tag_set_vertices: getting entities didn't succeed., with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  result = MBI->get_adjacencies(entities, 0, false, vertices,
                                MBInterface::UNION);
  if (MB_SUCCESS != result) {
    std::string msg("MBMesh::tag_set_vertices: getting vertices didn't succeed., with error type: ");
    msg += MBI->get_error_string(result);
    TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
  }
  
    // tag each vertex with its index in this list
  int i = 0;
  if (tag == 0) {
    result = MBI->tag_create("__position_tag", 4, MB_TAG_DENSE, tag, &i);
    if (MB_SUCCESS != result || 0 == tag) {
      std::string msg("MBMesh::tag_set_vertices: couldn't make tag., with error type: ");
      msg += MBI->get_error_string(result);
      TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    }
  }
  
  MBRange::iterator vit;
  for (vit = vertices.begin(), i = 0; vit != vertices.end(); vit++, i++) {
    result = MBI->tag_set_data(tag, &(*vit), 1, &i);
    if (MB_SUCCESS != result) {
      std::string msg("MBMesh::tag_set_vertices: couldn't set pos_tag., with error type: ");
      msg += MBI->get_error_string(result);
      TSTTM_processError(TSTTB_ERROR_MAP[result], msg.c_str());
    }
  }

  if (req_dimension == -1 && req_type == MBMAXTYPE) return;
  
    // winnow the list for entities of the desired type and/or topology
  num_verts = 0;
  MBRange::iterator ent_it;
  MBEntityType this_type;
  for (ent_it = entities.begin(); ent_it != entities.end(); ent_it++) {
    this_type = MBI->type_from_handle(*ent_it);
    if (req_dimension == MBCN::Dimension(this_type) ||
        this_type == req_type) {
      req_entities.insert(*ent_it);
      num_verts += MBCN::VerticesPerEntity(this_type);
    }
  }
}
  
