/**
 * MOAB, a Mesh-Oriented datABase, is a software component for creating,
 * storing and accessing finite element mesh data.
 * 
 * Copyright 2004 Sandia Corporation.  Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Coroporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 */

//
//-------------------------------------------------------------------------
// Filename      : EntitySet.hpp
//
// Creator       : Hong-Jun Kim
//
// Date          : 05/03
//
// Owner         : Hong-Jun Kim
//
// Description   : EntitySet is the real implementation for TSTT_EntitySet
//-------------------------------------------------------------------------

#ifndef ENTITYSET_HPP
#define ENTITYSET_HPP

#include <vector>
#include <list>
#include <set>

// use the C++ definition of functions etc.
#define TSTT_CPP_DECLS
#include "TSTT.hh"

/*====================================================================
// Typedef Entity_Handle
//====================================================================
*/
  
/**
An opaque object containing enough information for the underlying implementation
to determine a unique entity.
 */
  typedef void * Entity_Handle;


/*====================================================================
// Typedef cEntity_Handle
//====================================================================
*/

/**
An const opaque object containing enough information for the underlying 
implementation to determine a unique entity.  This is used to distinquish
which subroutines can change the opaque object and which cannot.
**/
  typedef const void * cEntity_Handle;

//--------------------------------------------------------------------

/*====================================================================
// Typedef EntitySet_Handle
//====================================================================
*/
  
/**
An opaque object containing enough information for the underlying implementation
to determine a unique entity.
 */
  typedef void * EntitySet_Handle;


/*====================================================================
// Typedef cEntitySet_Handle
//====================================================================
*/

/**
An const opaque object containing enough information for the underlying 
implementation to determine a unique entity.  This is used to distinquish
which subroutines can change the opaque object and which cannot.
**/
  typedef const void * cEntitySet_Handle;

class EntitySet;

class EntitySetManager 
{
public:
  EntitySetManager() {}
  ~EntitySetManager() {}
  
  void add_set(EntitySet*);
  void remove_set(EntitySet*);
  bool find_set(EntitySet*);

  EntitySet *create_set(const int multiset, const int ordered);
  void delete_set(EntitySet *this_set);

private:
  static std::set<EntitySet*> entityset_list;
};

class EntitySet
{
public:
  
    // needed to call the private destructor
  friend class EntitySetManager;
  
  int subtract(EntitySet *);
  int unite(EntitySet *);
  static int add_parent_child(EntitySet*, EntitySet*);
  int add_parent(EntitySet *);
  int add_child(EntitySet *);
  static int remove_parent_child(EntitySet*, EntitySet*);
  int remove_parent(EntitySet *);
  int remove_child(EntitySet *);
  int get_parents(const int, std::vector<EntitySet*> &) const;
  int get_children(const int, std::vector<EntitySet*> &) const;
  int num_children() const;
  int num_parents() const;
  int is_related(EntitySet *);
  int get_ordered_flag(int &);
  int get_multiset_flag(int &);

    //! add num_entities entities to a meshset
  virtual int add_entities(const Entity_Handle *, const int) = 0;
  virtual int add_entitysets(const EntitySet_Handle *, const int) = 0;
  virtual int get_entities(std::vector<Entity_Handle>& ) = 0;
  virtual int get_entitysets(std::vector<EntitySet_Handle>&) = 0;
  virtual int get_all_entitysets(std::vector<EntitySet*>&) = 0;
  virtual int remove_entities(const Entity_Handle *, const int) = 0;
  virtual int remove_entitysets(const EntitySet_Handle *, const int) = 0;
  virtual int get_num_entities() = 0;
  virtual int get_num_entitysets() = 0;
  virtual int intersect(EntitySet *) = 0;
  virtual int get_all_entities(std::vector<Entity_Handle> &) = 0;
  
  
private:

    // private so they can only be called from the manager
  EntitySet(int, int);
  virtual ~EntitySet();
  
  // links to parents/children
  std::vector<EntitySet*> parentEntitySets;
  std::vector<EntitySet*> childEntitySets;
  int multiSet;
  int ordered;
};


#define ENTITY_SET_VIRTUAL_FUNCTIONS \
  virtual int add_entities(const Entity_Handle *, const int); \
  virtual int add_entitysets(const EntitySet_Handle *, const int); \
  virtual int get_entities(std::vector<Entity_Handle>&); \
  virtual int get_entitysets(std::vector<EntitySet_Handle>&); \
  virtual int get_all_entitysets(std::vector<EntitySet*>&); \
  virtual int remove_entities(const Entity_Handle *, const int); \
  virtual int remove_entitysets(const EntitySet_Handle *, const int); \
  virtual int get_num_entities(); \
  virtual int get_num_entitysets(); \
  virtual int intersect(EntitySet *); \
  virtual int get_all_entities(std::vector<Entity_Handle> &);

class VectorEntitySet : public EntitySet
{
public:

  ENTITY_SET_VIRTUAL_FUNCTIONS

private:
  VectorEntitySet(int multi_set, int ordered);
  virtual ~VectorEntitySet();
  std::vector<Entity_Handle> eVector;
  std::vector<EntitySet*> eSetVector;
};


class SetEntitySet : public EntitySet
{
public:
 
  ENTITY_SET_VIRTUAL_FUNCTIONS

private:
  SetEntitySet(int multi_set, int ordered);
  virtual ~SetEntitySet();
  std::set<Entity_Handle> eSet;
  std::set<EntitySet*> eSetSet;
};


class MultiSetEntitySet : public EntitySet
{
public:
 
  ENTITY_SET_VIRTUAL_FUNCTIONS

private:
  MultiSetEntitySet(int multi_set, int ordered);
  virtual ~MultiSetEntitySet();
  std::multiset<Entity_Handle> eMultiSet;
  std::multiset<EntitySet*> eSetMultiSet;
};


#endif







