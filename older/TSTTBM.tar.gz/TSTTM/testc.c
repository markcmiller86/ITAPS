/**
 * MOAB, a Mesh-Oriented datABase, is a software component for creating,
 * storing and accessing finite element mesh data.
 * 
 * Copyright 2004 Sandia Corporation.  Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Coroporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 */

#include <stdlib.h>
#include <stdio.h>

//#include "sidl.hh"
#include "TSTTB.h"
#include "TSTTM.h"
#include "TSTTM_MOAB_MoabMesh.h"


/*!
@test 
Load Mesh
@li Load a mesh file
*/
int load_mesh_test(const char* filename, TSTTM_MOAB_MoabMesh my_mesh)
{
  // leave the file names alone for now, but eventually these should be 
  // mdb-independent
  sidl_BaseInterface err;

  // load a mesh
  //try {
  //my_mesh.load(filename);
    TSTTM_MOAB_MoabMesh_load(my_mesh, 0, filename, &err);
    //}
    //catch (TSTT_MDB::Error) {
    //cerr << "ERROR : can not load a mesh" << endl;
    //return false;
    //}

  return 1;
}

int main( int argc, char *argv[] )
{
  /*
  // create a TSTTMDBMesh interface
  TSTT_MDB_MoabMesh mesh = TSTT_MDB_MoabMesh__create();

  // "Load" a mesh
  TSTTDemo_DemoMesh_Load(demoMesh,"this is a demonstration mesh",&err);

  // cast it to the more general "DemoInterface::Mesh" interface
  //   Read this as casting the REFERENCE demoMesh to a REFERENCE of a DemoInterface::Mesh interface
  //   You can also read this as a kind of shallow copy to a "base class"
  TSTTDemo_DemoMesh_addReference(demoMesh);
  mesh = TSTTDemoInterface_Mesh__cast(demoMesh);
  */


  /*
  // Check command line arg
  char* filename = argv[1];

  //if (filename == "" || argc < 1) {
  if (1 == 0) {
  //printf("Usage: %s <mesh_filename>", argv[0]);
    //return 1;
    printf("\n\nTSTT TEST PROGRAM:\n\n");
  }
  */

  // initialize the Mesh
  TSTTM_MOAB_MoabMesh mesh = TSTTM_MOAB_MoabMesh__create();

  // Print out Header information
  //cout << "\n\nTSTT TEST PROGRAM:\n\n";
  printf("\n\nTSTT TEST PROGRAM:\n\n");

  // load_mesh test
  //cout << "   load_mesh: ";
  //result = load_mesh_test(filename, mesh);
  /*
  handle_error_code(result, number_tests_failed,
                    number_tests_not_implemented,
                    number_tests_successful);
  number_tests++;
  cout << "\n";
  */
  /*
  // entity sets test
  cout << "   entity_sets_test: ";
  result = entity_sets_test(&mesh);
  handle_error_code(result, number_tests_failed,
                    number_tests_not_implemented,
                    number_tests_successful);
  number_tests++;
  cout << "\n";

  // summary

  cout << "\nTSTT TEST SUMMARY: \n"
       << "   Number Tests:           " << number_tests << "\n"
       << "   Number Successful:      " << number_tests_successful << "\n"
       << "   Number Not Implemented: " << number_tests_not_implemented << "\n"
       << "   Number Failed:          " << number_tests_failed 
       << "\n\n";
  */
  return 0;
}







