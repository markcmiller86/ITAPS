/**
 * MOAB, a Mesh-Oriented datABase, is a software component for creating,
 * storing and accessing finite element mesh data.
 * 
 * Copyright 2004 Sandia Corporation.  Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Coroporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 */

//
//-------------------------------------------------------------------------
// Filename      : EntitySet.cpp
// Creator       : Hong-Jun Kim
//
// Date          : 05/03
//
// Owner         : Hong-Jun Kim
//
// Description   : TSTT_MeshSet is the interface to an arbitrary or non-arbitrary
//                 set of mesh entities
//-------------------------------------------------------------------------

#include <algorithm>
#include "EntitySet.hpp"

#define TSTT_CPP_DECLS

using namespace std;

std::set<EntitySet*> EntitySetManager::entityset_list;


void EntitySetManager::add_set(EntitySet *this_set) 
{
  entityset_list.insert(this_set);
}

void EntitySetManager::remove_set(EntitySet *this_set) 
{
  entityset_list.erase(this_set);
}

bool EntitySetManager::find_set(EntitySet*) 
{
  return (entityset_list.find() == entityset_list.end());
}

EntitySet *EntitySetManager::create_set(const int multiset, const int ordered) 
{
  EntitySet *new_set = NULL;
  if (multiset)
    new_set = new MultiSetEntitySet(multiset, ordered);
  else if (ordered)
    new_set = new VectorEntitySet(multiset, ordered);
  else
    new_set = new SetEntitySet(multiset, ordered);

  if (NULL != new_set) add_set(new_set);

  return new_set;
}

void EntitySetManager::delete_set(EntitySet *this_set) 
{
  remove_set(this_set);
  delete this_set;
}

int VectorEntitySet::add_entities(const Entity_Handle *entities,
                                  const int num_entities)
{
  for(int i = 0; i < num_entities; i++)
    eVector.push_back(entities[i]);

  return 1;
}

int VectorEntitySet::add_entitysets(const EntitySet_Handle *entitysets,
                                    const int num_entitysets)
{
  for(int i = 0; i < num_entitysets; i++)
    eSetVector.push_back(static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));

  return 1;
}

int VectorEntitySet::get_entities(std::vector<Entity_Handle>& entity_list)
{
  std::vector<Entity_Handle>::iterator iter = eVector.begin();
  std::vector<Entity_Handle>::iterator end_iter = eVector.end();
  
  for(; iter != end_iter; iter++) {
    entity_list.push_back(*iter);
  }
  
  return 1;
}

int VectorEntitySet::get_entitysets(std::vector<EntitySet_Handle>& entitysets)
{
  std::vector<EntitySet*>::iterator iter, end_iter = eSetVector.end();
  
  for(iter = eSetVector.begin(); iter != end_iter; iter++)
    entitysets.push_back(reinterpret_cast<EntitySet_Handle>(*iter));
  
  return 1;
}

int VectorEntitySet::remove_entities(const Entity_Handle *entity_handles,
                                     const int num_entities)
{
  std::vector<Entity_Handle>::iterator iter;
  std::vector<Entity_Handle>::iterator end_iter = eVector.end();

  for (int i = 0; i < num_entities; i++) {
    iter = std::find(eVector.begin(), eVector.end(), entity_handles[i]);
    
    if (iter == end_iter)
      return 0;
    
    eVector.erase(iter);
  }

  return 1;
}

int VectorEntitySet::remove_entitysets(const EntitySet_Handle *entitysets,
                                       const int num_entitysets)
{
  std::vector<EntitySet*>::iterator iter;
  std::vector<EntitySet*>::iterator end_iter = eSetVector.end();
  
  for (int i = 0; i < num_entitysets; i++) {
    iter = std::find(eSetVector.begin(), eSetVector.end(), 
                     static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));
    
    if (iter == end_iter)
      return 0;
    
    eSetVector.erase(iter);
  }
  
  return 1;
}

int VectorEntitySet::intersect(EntitySet *entity_set2)
{
  std::vector<Entity_Handle> other_vector ;
  entity_set2->get_entities(other_vector);

  std::sort(eVector.begin(), eVector.end());

  std::set<Entity_Handle> tmp;

  std::set_intersection(eVector.begin(), eVector.end(), other_vector.begin(), other_vector.end(), 
                        std::inserter< std::set<Entity_Handle> >(tmp, tmp.end()));

  eVector.resize(tmp.size());
  std::copy(tmp.begin(), tmp.end(), eVector.begin());

  return 1;
}

int VectorEntitySet::get_all_entities(std::vector<Entity_Handle> &entities)
{
  if (eVector.size() > 0) {
    std::vector<Entity_Handle>::iterator iter = eVector.begin();
    std::vector<Entity_Handle>::iterator end_iter = eVector.end();
    std::vector<Entity_Handle>::iterator jter;
    
    for (; iter != end_iter; iter++) {
      jter = std::find(entities.begin(), entities.end(), *iter);
      if (jter == entities.end())
        entities.push_back(*iter);
    }
  }
    
  if (eSetVector.size() > 0) {
    std::vector<EntitySet*>::iterator kter = eSetVector.begin();
    std::vector<EntitySet*>::iterator end_kter = eSetVector.end();

    for (; kter != end_kter; kter++) {
      (*kter)->get_all_entities(entities);
    }
  }

  return 1;
}

int VectorEntitySet::get_all_entitysets(std::vector<EntitySet*> &sets)
{
  if (eSetVector.size() > 0) {
    std::vector<EntitySet*>::iterator iter = eSetVector.begin();
    std::vector<EntitySet*>::iterator end_iter = eSetVector.end();
    std::vector<EntitySet*>::iterator jter;

    for (; iter != end_iter; iter++) {
      jter = std::find(sets.begin(), sets.end(), *iter);

      if (jter == sets.end()) {
        sets.push_back(*iter);
        (*iter)->get_all_entitysets(sets);
      }
    }
  }

  return 1;
}

VectorEntitySet::VectorEntitySet(int multi_set, int ordered) : EntitySet(multi_set, ordered)
{
  cout << "VectorEntitySet_created" << endl;
}

int VectorEntitySet::get_num_entities()
{
  return eVector.size();
}

int VectorEntitySet::get_num_entitysets()
{
  return eSetVector.size();
}

VectorEntitySet::~VectorEntitySet()
{}

EntitySet::EntitySet(int multi, int order)
{
  multiSet = multi;
  ordered = order;
}

EntitySet::~EntitySet()
{
}

SetEntitySet::~SetEntitySet()
{}

MultiSetEntitySet::~MultiSetEntitySet()
{}

int SetEntitySet::add_entities(const Entity_Handle *entities,
                               const int num_entities)
{
  for(int i = 0; i < num_entities; i++)
    eSet.insert(entities[i]);

  return 1;
}

int MultiSetEntitySet::add_entities(const Entity_Handle *entities,
                                    const int num_entities)
{
  for(int i = 0; i < num_entities; i++)
    eMultiSet.insert(entities[i]);

  return 1;
}

int SetEntitySet::add_entitysets(const EntitySet_Handle *entitysets,
                                 const int num_entitysets)
{
  for(int i = 0; i < num_entitysets; i++)
    eSetSet.insert(static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));

  return 1;
}

int MultiSetEntitySet::add_entitysets(const EntitySet_Handle *entitysets,
                                      const int num_entitysets)
{
  for(int i = 0; i < num_entitysets; i++)
    eSetMultiSet.insert(static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));

  return 1;
}

int SetEntitySet::get_entities(std::vector<Entity_Handle>& entity_list)
{
  std::set<Entity_Handle>::iterator iter = eSet.begin();;
  std::set<Entity_Handle>::iterator end_iter = eSet.end();

  for (; iter != end_iter; iter++)
    entity_list.push_back(*iter);
  
  return 1;
}

int MultiSetEntitySet::get_entities(std::vector<Entity_Handle>& entity_list)
{
  std::multiset<Entity_Handle>::iterator iter = eMultiSet.begin();
  std::multiset<Entity_Handle>::iterator end_iter = eMultiSet.end();
  
  for (; iter != end_iter; iter++)
    entity_list.push_back(*iter);
  
  return 1;
}

int SetEntitySet::get_entitysets(std::vector<EntitySet_Handle>& entity_sets)
{
  std::set<EntitySet*>::iterator iter = eSetSet.begin();
  std::set<EntitySet*>::iterator end_iter = eSetSet.end();
  
  for(; iter != end_iter; iter++)
    entity_sets.push_back(*iter);
  
  return 1;
}

int MultiSetEntitySet::get_entitysets(std::vector<EntitySet_Handle>& entity_sets)
{
  std::multiset<EntitySet*>::iterator iter = eSetMultiSet.begin();
  std::multiset<EntitySet*>::iterator end_iter = eSetMultiSet.end();
  
  for(; iter != end_iter; iter++)
    entity_sets.push_back(*iter);
  
  return 1;
}

int SetEntitySet::remove_entities(const Entity_Handle *entity_handles,
                                  const int num_entities)
{
  std::set<Entity_Handle>::iterator iter;

  for (int i = 0; i < num_entities; i++) {
    iter = eSet.find(entity_handles[i]);
    
    if (iter == eSet.end())
      return 0;
    
    eSet.erase(iter);
  }

  return 1;
}

int MultiSetEntitySet::remove_entities(const Entity_Handle *entity_handles,
                                       const int num_entities)
{
  std::multiset<Entity_Handle>::iterator iter;

  for (int i = 0; i < num_entities; i++) {
    iter = eMultiSet.find(entity_handles[i]);
    
    if (iter == eMultiSet.end())
      return 0;

    eMultiSet.erase(iter);
  }

  return 1;
}

int SetEntitySet::remove_entitysets(const EntitySet_Handle *entitysets,
                                    const int num_entitysets)
{
  std::set<EntitySet*>::iterator iter;
  
  for (int i = 0; i < num_entitysets; i++) {
    iter = eSetSet.find(static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));
    
    if (iter == eSetSet.end())
      return 0;
    
    eSetSet.erase(iter);
  }
  
  return 1;
}

int MultiSetEntitySet::remove_entitysets(const EntitySet_Handle *entitysets,
                                         const int num_entitysets)
{
  std::multiset<EntitySet*>::iterator iter;
  
  for (int i = 0; i < num_entitysets; i++) {
    iter = eSetMultiSet.find(static_cast<EntitySet*>(const_cast<void *>(entitysets[i])));
    
    if (iter == eSetMultiSet.end())
      return 0;
    
    eSetMultiSet.erase(iter);
  }
  
  return 1;
}

int EntitySet::subtract(EntitySet *entity_set2)
{
  std::vector<Entity_Handle> other_vector;
  entity_set2->get_entities(other_vector);
  
  return remove_entities(&other_vector[0], other_vector.size());
}

int SetEntitySet::intersect(EntitySet *entity_set2)
{
  std::vector<Entity_Handle> other_vector ;
  entity_set2->get_entities(other_vector);

    //std::sort(eSet.begin(), eSet.end());

  std::set<Entity_Handle> tmp;

  std::set_intersection(eSet.begin(), eSet.end(), other_vector.begin(), other_vector.end(), 
                        std::inserter< std::set<Entity_Handle> >(tmp, tmp.end()));

  eSet.clear();

  std::set<Entity_Handle>::iterator iter = tmp.begin();
  std::set<Entity_Handle>::iterator end_iter = tmp.end();

  for (; iter != end_iter; iter++) {
    eSet.insert(*iter);
  }

  return 1;
}

int MultiSetEntitySet::intersect(EntitySet *entity_set2)
{
  std::vector<Entity_Handle> other_vector ;
  entity_set2->get_entities(other_vector);

  std::multiset<Entity_Handle> tmp;

  std::set_intersection(eMultiSet.begin(), eMultiSet.end(), other_vector.begin(), other_vector.end(), 
                        std::inserter< std::multiset<Entity_Handle> >(tmp, tmp.end()));

  eMultiSet.clear();

  std::multiset<Entity_Handle>::iterator iter = tmp.begin();
  std::multiset<Entity_Handle>::iterator end_iter = tmp.end();

  for (; iter != end_iter; iter++) {
    eMultiSet.insert(*iter);
  }

  return 1;
}

int EntitySet::unite(EntitySet *entity_set2)
{
  std::vector<Entity_Handle> other_vector;
  entity_set2->get_entities(other_vector);
  return add_entities(&other_vector[0], other_vector.size());
}

//! add a parent/child link between the meshsets; returns error if entities are already
//! related or if child is already a parent of parent
int EntitySet::add_parent_child(EntitySet* parent, 
                                EntitySet* child) 
{ 
  return parent->add_child(child) && child->add_parent(parent);
}

int EntitySet::add_parent(EntitySet *parent) 
{
    //add parent to this's parent-entity-set-list
  if (std::find(parentEntitySets.begin(),
                parentEntitySets.end(), parent) == parentEntitySets.end()) 
  {
    parentEntitySets.push_back(parent);
    return 1; 
  }
  else 
    return 0;
}

int EntitySet::add_child(EntitySet *child) 
{
    //add child to this's child-entity-set-list
  if (std::find(childEntitySets.begin(),
                childEntitySets.end(), child) == childEntitySets.end()) 
  {
    childEntitySets.push_back(child);
    return 1; 
  }
  else 
    return 0;
}

int EntitySet::remove_parent_child(EntitySet* parent, 
                                   EntitySet* child) 
{ 
  return parent->remove_child(child)
    && child->remove_parent(parent);
}

int EntitySet::remove_parent(EntitySet *parent) 
{
    //remove parent to this's parent-entity-set-list
  std::vector<EntitySet*>::iterator iter = 
    std::find(parentEntitySets.begin(),
              parentEntitySets.end(), parent);

  if (iter != parentEntitySets.end()) {
    parentEntitySets.erase(iter);
    return 1; 
  }
  else 
    return 0;
}

int EntitySet::remove_child(EntitySet *child) 
{
    //remove child to this's child-entity-set-list
  std::vector<EntitySet*>::iterator iter = 
    std::find(childEntitySets.begin(),
              childEntitySets.end(), child);

  if (iter != childEntitySets.end()) {
    childEntitySets.erase(iter);
    return 1; 
  }
  else 
    return 0;
}

int EntitySet::get_parents(const int num_hops, 
                           std::vector<EntitySet*> &parents) const
{
    // compute new value of num_hops, either decremented or equal to -1
  int this_hops = (-1 == num_hops ? -1 : num_hops-1);
  
  std::vector<EntitySet*>::const_iterator i = parentEntitySets.begin();
    // go through parent sets; if we find a unique parentchild, and we haven't exceeded
    // the hops, recurse
  while (i != parentEntitySets.end()) {
    std::vector<EntitySet*>::iterator j = std::find(parents.begin(), parents.end(), *i);
    if (j == parents.end()) {
      parents.push_back(*i);
      if (0 != num_hops)
        (*i)->get_parents(this_hops, parents);
    }
    i++;
  }
  
  return 1;
}

int EntitySet::get_children(const int num_hops, 
                            std::vector<EntitySet*> &children) const
{
    // compute new value of num_hops, either decremented or equal to -1
  int this_hops = (-1 == num_hops ? -1 : num_hops-1);
  
  std::vector<EntitySet*>::const_iterator i = childEntitySets.begin();
    // go through child sets; if we find a unique child, and we haven't exceeded
    // the hops, recurse
  while (i != childEntitySets.end()) {
    std::vector<EntitySet*>::iterator j = std::find(children.begin(), children.end(), *i);
    if (j == children.end()) {
      children.push_back(*i);
      if (0 != num_hops)
        (*i)->get_children(this_hops, children);
    }
    i++;
  }
  
  return 1;
}

//! return the number of child/parent relations for this meshset
int EntitySet::num_children() const
{ 
  return childEntitySets.size();
}

int EntitySet::num_parents() const
{ 
  return parentEntitySets.size();
}

int EntitySet::is_related(EntitySet *entity_set)
{
  std::vector<EntitySet*>::iterator iter;
  
  iter = std::find(childEntitySets.begin(), childEntitySets.end(), entity_set);
  
  if (iter != childEntitySets.end())
    return 1;
  
  iter = std::find(parentEntitySets.begin(), parentEntitySets.end(), entity_set);
  
  if (iter != parentEntitySets.end())
    return 1;
  else
    return 0;
}
		   
int EntitySet::get_ordered_flag(int &flag)
{
  flag = ordered;
  
  return 1;
}
		   
int EntitySet::get_multiset_flag(int &flag)
{
  flag = multiSet;
  
  return 1;
}    

int SetEntitySet::get_all_entities(std::vector<Entity_Handle> &entities)
{
  if (eSet.size() > 0) {
    std::set<Entity_Handle>::iterator iter = eSet.begin();
    std::set<Entity_Handle>::iterator end_iter = eSet.end();
    std::vector<Entity_Handle>::iterator jter;

    for (; iter != end_iter; iter++) {
      jter = std::find(entities.begin(), entities.end(), *iter);
      if (jter == entities.end())
        entities.push_back(*iter);
    }
  }

  if (eSetSet.size() > 0) {
    std::set<EntitySet*>::iterator kter = eSetSet.begin();
    std::set<EntitySet*>::iterator end_kter = eSetSet.end();

    for (; kter != end_kter; kter++) {
      (*kter)->get_all_entities(entities);
    }
  }
  
  return 1;
}

int MultiSetEntitySet::get_all_entities(std::vector<Entity_Handle> &entities)
{
  if (eMultiSet.size() > 0) {
    std::multiset<Entity_Handle>::iterator iter = eMultiSet.begin();
    std::multiset<Entity_Handle>::iterator end_iter = eMultiSet.end();
    std::vector<Entity_Handle>::iterator jter;
    
    for (; iter != end_iter; iter++) {
      jter = std::find(entities.begin(), entities.end(), *iter);
      if (jter == entities.end())
        entities.push_back(*iter);
    }
  }
  
  if (eSetMultiSet.size() != 0) {
    std::set<EntitySet*>::iterator kter = eSetMultiSet.begin();
    std::set<EntitySet*>::iterator end_kter = eSetMultiSet.end();
    
    for (; kter != end_kter; kter++) {
      (*kter)->get_all_entities(entities);
    }
  }
  
  return 1;
}

int SetEntitySet::get_all_entitysets(std::vector<EntitySet*> &sets)
{
  if (eSetSet.size() > 0) {
    std::set<EntitySet*>::iterator iter = eSetSet.begin();
    std::set<EntitySet*>::iterator end_iter = eSetSet.end();
    std::vector<EntitySet*>::iterator jter;
    
    for (; iter != end_iter; iter++) {
      jter = std::find(sets.begin(), sets.end(), *iter);
      
      if (jter == sets.end()) {
        sets.push_back(*iter);
        (*iter)->get_all_entitysets(sets);
      }
    }
  }

  return 1;
}

int MultiSetEntitySet::get_all_entitysets(std::vector<EntitySet*> &sets)
{
  if (eSetMultiSet.size() > 0) {
    std::multiset<EntitySet*>::iterator iter = eSetMultiSet.begin();
    std::multiset<EntitySet*>::iterator end_iter = eSetMultiSet.end();
    std::vector<EntitySet*>::iterator jter;

    for (; iter != end_iter; iter++) {
      jter = std::find(sets.begin(), sets.end(), *iter);
      
      if (jter == sets.end()) {
        sets.push_back(*iter);
        (*iter)->get_all_entitysets(sets);
      }
    }
  }

  return 1;
}

MultiSetEntitySet::MultiSetEntitySet(int multi_set, int ordered) : EntitySet(multi_set, ordered)
{
  cout << "MultiSetEntitySet_created" << endl;
}

SetEntitySet::SetEntitySet(int multi_set, int ordered) : EntitySet(multi_set, ordered)
{
  cout << "SetEntitySet_created" << endl;
}


int SetEntitySet::get_num_entities()
{
  return eSet.size();
}

int MultiSetEntitySet::get_num_entities()
{
  return eMultiSet.size();
}

int SetEntitySet::get_num_entitysets()
{
  return eSetSet.size();
}

int MultiSetEntitySet::get_num_entitysets()
{
  return eSetMultiSet.size();
}
