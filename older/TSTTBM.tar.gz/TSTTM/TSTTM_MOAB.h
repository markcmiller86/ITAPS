#ifndef __MB_MESH_HPP__
#define __MB_MESH_HPP__

#include "TSTTB_SNL.h"

#ifdef __cplusplus
#include <string>

extern "C" 
{
#else
  typedef int bool;
#endif

  typedef void* TSTTM_EntityHandle;
  typedef void* TSTTM_TagHandle;
  typedef void* TSTTM_Instance;
  typedef void* TSTTM_EntityIterator;

  enum TSTTM_StorageOrder {TSTTM_BLOCKED, TSTTM_INTERLEAVED, TSTTM_UNDETERMINED};

  enum TSTTM_EntityType {       
    TSTTM_VERTEX, 
    TSTTM_EDGE, 
    TSTTM_FACE, 
    TSTTM_REGION,
    TSTTM_ALL_TYPES
  };


  enum TSTTM_EntityTopology {
    TSTTM_POINT,              /**< a general zero-dimensional entity  */
    TSTTM_LINE_SEGMENT,       /**< a general one-dimensional entity  */
    TSTTM_POLYGON,            /**< a general two-dimensional element  */
    TSTTM_TRIANGLE,           /**< a three-sided, two-dimensional element  */
    TSTTM_QUADRILATERAL,      /**< a four-sided, two-dimensional element  */
    TSTTM_POLYHEDRON,         /**< a general three-dimensional element */
    TSTTM_TETRAHEDRON,        /**< a four-sided, three-dimensional element whose 
                         *                            faces are quadrilaterals */
    TSTTM_HEXAHEDRON,         /**< a six-sided, three-dimensional element whose 
                         *                            faces are quadrilaterals */
    TSTTM_PRISM,              /**< a five-sided, three-dimensional element which 
                         *                            has three quadrilateral faces and two
                         *                            triangular faces  */
    TSTTM_PYRAMID,            /**< a five-sided, three-dimensional element
                         *                            which has one quadrilateral face and four
                         *                            triangular faces */
    TSTTM_SEPTAHEDRON,        /**< a hexahedral entity with one collapsed edge */
    TSTTM_ALL_TOPOLOGIES      /**< allows the user to request information 
                         *                            about all the topology types */
  };

  enum TSTTM_AdjacencyCost {
    TSTTM_UNAVAILABLE,          /**< Adjacency information not supported */
    TSTTM_IMMEDIATE,            /**< No mesh traversal required */
    TSTTM_LOCAL_TRAVERSAL,      /**< Must traverse entity's neighborhood */
    TSTTM_GLOBAL_TRAVERSAL      /**< Must traverse entire mesh */
  };

  enum TSTTM_CreationStatus {	
    TSTTM_NEW,               
    TSTTM_ALREADY_EXISTED,   
    TSTTM_CREATED_DUPLICATE,
    TSTTM_CREATION_FAILED
  };

  enum TSTTM_TagValueType {
    TSTTM_INTEGER,
    TSTTM_DOUBLE,
    TSTTM_ENTITY_HANDLE,
    TSTTM_BYTES
  };

  enum TSTTM_ErrorActions {
    TSTTM_SILENT,
    TSTTM_WARN_ONLY,		 
    TSTTM_ABORT_ON_ERROR,
    TSTTM_PRINT_AND_THROW_ERROR, 
    TSTTM_THROW_ERROR		 
  };

  extern struct TSTTB_Error TSTTM_LAST_ERROR;

  enum TSTTB_ErrorType 
  TSTTM_ctor(TSTTM_Instance *instance);

  enum TSTTB_ErrorType 
  TSTTM_dtor(TSTTM_Instance instance);

  enum TSTTB_ErrorType 
  TSTTM_load(TSTTM_Instance instance,
             /*in*/ const TSTTM_EntityHandle,
             /*in*/ const char *name);

  enum TSTTB_ErrorType 
  TSTTM_save(TSTTM_Instance instance,
             /*in*/ const TSTTM_EntityHandle,
             /*in*/ const char *name );

  TSTTM_EntityHandle 
  TSTTM_getRootSet(TSTTM_Instance instance);

  int 
  TSTTM_getGeometricDimension(TSTTM_Instance instance);

  enum TSTTM_StorageOrder 
  TSTTM_getDfltStorage(TSTTM_Instance instance);
 
  enum TSTTB_ErrorType
  TSTTM_getAdjTable (TSTTM_Instance instance,
                     enum TSTTM_AdjacencyCost** adjacency_table,
                        /*inout*/ int* adjacency_table_allocated, 
                        /*out*/ int* adjacency_table_size );

  int 
  TSTTM_getNumOfType(TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set_handle,
                     /*in*/ const enum TSTTM_EntityType entity_type);
 
  int 
  TSTTM_getNumOfTopo(TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set_handle,
                        /*in*/ const enum TSTTM_EntityTopology entity_topology);

  enum TSTTB_ErrorType
  TSTTM_getAllVtxCoords (TSTTM_Instance instance,
                            /*in*/ const TSTTM_EntityHandle entity_set_handle,
                            /*inout*/ double** coordinates,
                            /*inout*/ int* coordinates_allocated,
                            /*out*/ int* coordinates_size,
                         /*inout*/ int** in_entity_set,
                            /*inout*/ int* in_entity_set_allocated,
                            /*out*/ int* in_entity_set_size,
                            /*inout*/ enum TSTTM_StorageOrder* storage_order );

  enum TSTTB_ErrorType
  TSTTM_getVtxCoordIndex (TSTTM_Instance instance,
                             /*in*/ const TSTTM_EntityHandle entity_set_handle,
                             /*in*/ const enum TSTTM_EntityType requested_entity_type,
                             /*in*/ const enum TSTTM_EntityTopology requested_entity_topology,
                             /*in*/ const enum TSTTM_EntityType entity_adjacency_type,
                             /*inout*/ int** offset,
                             /*inout*/ int* offset_allocated,
                             /*out*/ int* offset_size,
                             /*inout*/ int** index,
                             /*inout*/ int* index_allocated,
                             /*out*/ int* index_size,
                             /*inout*/  enum TSTTM_EntityTopology** entity_topologies,
                             /*inout*/ int* entity_topologies_allocated,
                             /*out*/ int* entity_topologies_size );

  enum TSTTB_ErrorType 
  TSTTM_getEntities(TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle entity_set_handle,
                    /*in*/ const enum TSTTM_EntityType entity_type,
                    /*in*/ const enum TSTTM_EntityTopology entity_topology,
                    /*inout*/ TSTTM_EntityHandle** entity_handles,
                    /*inout*/ int* entity_handles_allocated,
                    /*out*/ int* entity_handles_size );

  enum TSTTB_ErrorType
  TSTTM_getVtxArrCoords (TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle* vertex_handles,
                            /*in*/ const int vertex_handles_size,
                            /*inout*/ enum TSTTM_StorageOrder* storage_order,
                            /*inout*/ double** coords,
                            /*inout*/ int* coords_allocated,
                            /*out*/ int* coords_size );

  enum TSTTB_ErrorType
  TSTTM_getAdjEntities(TSTTM_Instance instance,
                          /*in*/ const TSTTM_EntityHandle entity_set_handle,
                          /*in*/ const enum TSTTM_EntityType entity_type_requestor,
                          /*in*/ const enum TSTTM_EntityTopology entity_topology_requestor,
                          /*in*/ const enum TSTTM_EntityType entity_type_requested,
                          /*inout*/ TSTTM_EntityHandle** adj_entity_handles,
                          /*inout*/ int* adj_entity_handles_allocated,
                          /*out*/ int* adj_entity_handles_size,
                          /*inout*/ int** offset,
                          /*inout*/ int* offset_allocated,
                          /*out*/ int* offset_size,
                          /*inout*/ int** in_entity_set,
                          /*inout*/ int* in_entity_set_allocated,
                          /*out*/ int* in_entity_set_size );

  bool
  TSTTM_initEntArrIter (TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle entity_set_handle,
                           /*in*/ const enum TSTTM_EntityType requested_entity_type,
                           /*in*/ const enum TSTTM_EntityTopology requested_entity_topology,
                           /*in*/ const int requested_array_size,
                           /*out*/ TSTTM_EntityIterator* entArr_iterator );

  bool
  TSTTM_getNextEntArrIter (TSTTM_Instance instance,
                              /*in*/ TSTTM_EntityIterator entArr_iterator,
                              /*inout*/ TSTTM_EntityHandle** entity_handles,
                              /*inout*/ int* entity_handles_allocated,
                              /*out*/ int* entity_handles_size );

  enum TSTTB_ErrorType
  TSTTM_resetEntArrIter (TSTTM_Instance instance,
                            /*in*/ TSTTM_EntityIterator entArr_iterator );

  enum TSTTB_ErrorType
  TSTTM_endEntArrIter (TSTTM_Instance instance,
                          /*in*/ TSTTM_EntityIterator entArr_iterator );

  enum TSTTB_ErrorType 
  TSTTM_getEntArrTopo(TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*inout*/ enum TSTTM_EntityTopology** topology,
                         /*inout*/ int* topology_allocated,
                         /*out*/ int* topology_size );
 
  enum TSTTB_ErrorType 
  TSTTM_getEntArrType(TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*inout*/ enum TSTTM_EntityType** type,
                         /*inout*/ int* type_allocated,
                         /*out*/ int* type_size );

  enum TSTTB_ErrorType
  TSTTM_getEntArrAdj (TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*in*/ const enum TSTTM_EntityType entity_type_requested,
                         /*inout*/ TSTTM_EntityHandle** adjacentEntityHandles,
                         /*inout*/ int* adjacentEntityHandles_allocated,
                         /*out*/ int* adj_entity_handles_size,
                         /*inout*/ int** offset,
                         /*inout*/ int* offset_allocated,
                         /*out*/ int* offset_size );
  
  enum TSTTB_ErrorType TSTTM_createEntSet(TSTTM_Instance instance,
                             /*in*/ const bool isList,
                             /*out*/ TSTTM_EntityHandle* entity_set_created );

  enum TSTTB_ErrorType
  TSTTM_destroyEntSet (TSTTM_Instance instance,
                          /*in*/ TSTTM_EntityHandle entity_set);

  bool
  TSTTM_isList (TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_set );

  int 
  TSTTM_getNumEntSets(TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle entity_set_handle,
                         /*in*/ const int num_hops );

  enum TSTTB_ErrorType 
  TSTTM_getEntSets(TSTTM_Instance instance,
                      /*in*/ const TSTTM_EntityHandle entity_set_handle,
                      /*in*/ const int num_hops,
                      /*out*/ TSTTM_EntityHandle** contained_entity_set_handles,
                      /*out*/ int* contained_entity_set_handles_allocated,
                      /*out*/ int* contained_entity_set_handles_size );

  enum TSTTB_ErrorType TSTTM_addEntToSet(TSTTM_Instance instance,
                            /*in*/ const TSTTM_EntityHandle entity_handle,
                            /*inout*/ TSTTM_EntityHandle* entity_set);

  enum TSTTB_ErrorType TSTTM_rmvEntFromSet(TSTTM_Instance instance,
                              /*in*/ const TSTTM_EntityHandle entity_handle,
                              /*inout*/ TSTTM_EntityHandle* entity_set);
 
  enum TSTTB_ErrorType 
  TSTTM_addEntArrToSet(TSTTM_Instance instance,
                          /*in*/ const TSTTM_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*inout*/ TSTTM_EntityHandle* entity_set);

  enum TSTTB_ErrorType 
  TSTTM_rmvEntArrFromSet(TSTTM_Instance instance,
                            /*in*/ const TSTTM_EntityHandle* entity_handles,
                            /*in*/ const int entity_handles_size,
                            /*inout*/ TSTTM_EntityHandle* entity_set);
 
  enum TSTTB_ErrorType 
  TSTTM_addEntSet(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set_to_add,
                     /*inout*/ TSTTM_EntityHandle* entity_set_handle);

  enum TSTTB_ErrorType 
  TSTTM_rmvEntSet(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set_to_remove,
                     /*inout*/ TSTTM_EntityHandle *entity_set_handle);

  bool
  TSTTM_isEntContained (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle containing_entity_set,
                        /*in*/ const TSTTM_EntityHandle contained_entity );

  bool
  TSTTM_isEntSetContained (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle containing_entity_set,
                        /*in*/ const TSTTM_EntityHandle contained_entity_set );

  enum TSTTB_ErrorType TSTTM_addPrntChld(TSTTM_Instance instance,
                            /*inout*/ TSTTM_EntityHandle* parent_entity_set,
                            /*inout*/ TSTTM_EntityHandle* child_entity_set );

  enum TSTTB_ErrorType TSTTM_rmvPrntChld(TSTTM_Instance instance,
                            /*inout*/ TSTTM_EntityHandle* parent_entity_set,
                            /*inout*/ TSTTM_EntityHandle* child_entity_set);

  bool 
  TSTTM_isChildOf(TSTTM_Instance instance,
                  /*in*/ const TSTTM_EntityHandle parent_entity_set,
                  /*in*/ const TSTTM_EntityHandle child_entity_set);

  int TSTTM_getNumChld(TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_set,
                              /*in*/ const int num_hops);

  int TSTTM_getNumPrnt(TSTTM_Instance instance,
                              /*in*/ const TSTTM_EntityHandle entity_set,
                              /*in*/ const int num_hops);

  enum TSTTB_ErrorType TSTTM_getChldn(TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle from_entity_set,
                         /*in*/ const int num_hops,
                         /*out*/ TSTTM_EntityHandle** entity_set_handles,
                         /*out*/ int* entity_set_handles_allocated,
                         /*out*/ int* entity_set_handles_size );

  enum TSTTB_ErrorType TSTTM_getPrnts(TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle from_entity_set,
                         /*in*/ const int num_hops,
                         /*out*/ TSTTM_EntityHandle** entity_set_handles,
                         /*out*/ int* entity_set_handles_allocated,
                         /*out*/ int* entity_set_handles_size );

  enum TSTTB_ErrorType TSTTM_setVtxArrCoords (TSTTM_Instance instance,
                                 /*in*/ TSTTM_EntityHandle* vertex_handles,
                                 /*in*/ const int vertex_handles_size,
                                 /*in*/ const enum TSTTM_StorageOrder storage_order,
                                 /*in*/ const double* new_coords,
                                 /*in*/ const int new_coords_size );

  enum TSTTB_ErrorType 
  TSTTM_createVtxArr(TSTTM_Instance instance,
                        /*in*/ const int num_verts,
                        /*in*/ const enum TSTTM_StorageOrder storage_order,
                        /*in*/ const double* new_coords,
                        /*in*/ const int new_coords_size,
                        /*inout*/ TSTTM_EntityHandle** new_vertex_handles,
                        /*inout*/ int* new_vertex_handles_allocated,
                        /*inout*/ int* new_vertex_handles_size);
                                                  
  enum TSTTB_ErrorType 
  TSTTM_createEntArr(TSTTM_Instance instance,
                        /*in*/ const enum TSTTM_EntityTopology new_entity_topology,
                        /*in*/ const TSTTM_EntityHandle* lower_order_entity_handles,
                        /*in*/ const int lower_order_entity_handles_size,
                        /*out*/ TSTTM_EntityHandle** new_entity_handles,
                        /*out*/ int* new_entity_handles_allocated,
                        /*out*/ int* new_entity_handles_size,
                        /*inout*/  enum TSTTM_CreationStatus** status,
                        /*inout*/ int* status_allocated,
                        /*out*/ int* status_size );
                                                   
  enum TSTTB_ErrorType
  TSTTM_deleteEntArr(TSTTM_Instance instance,
                        /*in*/ TSTTM_EntityHandle* entity_handles,
                        /*in*/ const int entity_handles_size );
                                                
  enum TSTTB_ErrorType
  TSTTM_createTag(TSTTM_Instance instance,
                     /*in*/ const char* tag_name,
                     /*in*/ const int tag_size,
                     /*in*/ const enum TSTTM_TagValueType tag_type,
                     /*out*/ TSTTM_TagHandle* tag_handle);

  enum TSTTB_ErrorType
  TSTTM_destroyTag(TSTTM_Instance instance,
                      /*in*/ TSTTM_TagHandle tag_handle,
                      /*in*/ const bool forced);

  const char *
  TSTTM_getTagName(TSTTM_Instance instance,
                      /*in*/ const TSTTM_TagHandle tag_handle);

  int
  TSTTM_getTagSizeValues(TSTTM_Instance instance,
                         /*in*/ const TSTTM_TagHandle tag_handle);

  int
  TSTTM_getTagSizeBytes(TSTTM_Instance instance,
                        /*in*/ const TSTTM_TagHandle tag_handle);

  TSTTM_TagHandle
  TSTTM_getTagHandle(TSTTM_Instance instance,
                        /*in*/ const char* tag_name);

  enum TSTTM_TagValueType
  TSTTM_getTagType (TSTTM_Instance instance,
                       /*in*/ const TSTTM_TagHandle tag_handle );

  enum TSTTB_ErrorType 
  TSTTM_setEntSetData (TSTTM_Instance instance,
                          /*in*/ TSTTM_EntityHandle entity_set_handle,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                          /*in*/ const char* tag_value,
                       /*in*/ const int tag_value_size);

  enum TSTTB_ErrorType
  TSTTM_setEntSetIntData (TSTTM_Instance instance,
                            /*in*/ TSTTM_EntityHandle entity_set,
                            /*in*/ const TSTTM_TagHandle tag_handle,
                            /*in*/ const int tag_value );

  enum TSTTB_ErrorType
  TSTTM_setEntSetDblData (TSTTM_Instance instance,
                            /*in*/ TSTTM_EntityHandle entity_set,
                            /*in*/ const TSTTM_TagHandle tag_handle,
                            /*in*/ const double tag_value );

  enum TSTTB_ErrorType
  TSTTM_setEntSetBoolData (TSTTM_Instance instance,
                             /*in*/ TSTTM_EntityHandle entity_set,
                             /*in*/ const TSTTM_TagHandle tag_handle,
                             /*in*/ const bool tag_value );

  enum TSTTB_ErrorType
  TSTTM_setEntSetEHData (TSTTM_Instance instance,
                           /*in*/ TSTTM_EntityHandle entity_set,
                           /*in*/ const TSTTM_TagHandle tag_handle,
                           /*in*/ const TSTTM_EntityHandle tag_value );

  enum TSTTB_ErrorType
  TSTTM_getEntSetData (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_set_handle,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                       /*inout*/ char** tag_value,
                       /*inout*/ int* tag_value_size,
                       /*inout*/ int* tag_value_allocated);

  int
  TSTTM_getEntSetIntData (TSTTM_Instance instance,
                            /*in*/ const TSTTM_EntityHandle entity_set,
                            /*in*/ const TSTTM_TagHandle tag_handle );

  double
  TSTTM_getEntSetDblData (TSTTM_Instance instance,
                        
                            /*in*/ const TSTTM_EntityHandle entity_set,
                            /*in*/ const TSTTM_TagHandle tag_handle );

  bool
  TSTTM_getEntSetBoolData (TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle entity_set,
                             /*in*/ const TSTTM_TagHandle tag_handle );

  TSTTM_EntityHandle
  TSTTM_getEntSetEHData (TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle entity_set,
                           /*in*/ const TSTTM_TagHandle tag_handle );

  enum TSTTB_ErrorType
  TSTTM_getAllEntSetTags (TSTTM_Instance instance,
                             /*in*/ const TSTTM_EntityHandle entity_set_handle,
                             /*out*/ TSTTM_TagHandle** tag_handles,
                             /*out*/ int* tag_handles_allocated,
                             /*out*/ int* tag_handles_size );

  enum TSTTB_ErrorType 
  TSTTM_rmvEntSetTag (TSTTM_Instance instance,
                         /*in*/ TSTTM_EntityHandle entity_set_handle,
                         /*in*/ const TSTTM_TagHandle tag_handle );

  enum TSTTB_ErrorType 
  TSTTM_setVtxCoords (TSTTM_Instance instance,
                      /*in*/ TSTTM_EntityHandle vertex_handle,
                      /*in*/ const double x, /*in*/ const double y, 
                      /*in*/ const double z);

  enum TSTTB_ErrorType
  TSTTM_createVtx(TSTTM_Instance instance,
                  /*in*/ const double x, /*in*/ const double y, 
                  /*in*/ const double z,
                  /*out*/ TSTTM_EntityHandle* new_vertex_handle );
                                                  
  enum TSTTB_ErrorType 
  TSTTM_createEnt(TSTTM_Instance instance,
                  /*in*/ const enum TSTTM_EntityTopology new_entity_topology,
                  /*in*/ const TSTTM_EntityHandle* lower_order_entity_handles,
                  /*in*/ const int lower_order_entity_handles_size,
                  /*out*/ TSTTM_EntityHandle* new_entity_handle,
                  /*out*/ enum TSTTM_CreationStatus* status );

  enum TSTTB_ErrorType
  TSTTM_deleteEnt(TSTTM_Instance instance,
                        /*in*/ TSTTM_EntityHandle entity_handle);
                                                
  enum TSTTB_ErrorType
  TSTTM_getArrData (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle* entity_handles,
                       /*in*/ const int entity_handles_size,
                       /*in*/ const TSTTM_TagHandle tag_handle,
                       /*inout*/ char** tag_values,
                       /*inout*/int* tag_values_allocated,
                       /*out*/ int* tag_values_size);

  enum TSTTB_ErrorType
  TSTTM_getIntArrData (TSTTM_Instance instance,
                          /*in*/ const TSTTM_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                          /*inout*/ int** tag_values,
                          /*inout*/ int* tag_values_allocated,
                          /*out*/ int* tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_getDblArrData (TSTTM_Instance instance,
                          /*in*/ const TSTTM_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                          /*inout*/ double** tag_values,
                          /*inout*/ int* tag_values_allocated,
                          /*out*/ int* tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_getBoolArrData (TSTTM_Instance instance,
                           /*in*/ const TSTTM_EntityHandle* entity_handles,
                           /*in*/ const int entity_handles_size,
                           /*in*/ const TSTTM_TagHandle tag_handle,
                           /*inout*/ bool** tag_value,
                           /*inout*/ int* tag_value_allocated,
                           /*out*/ int* tag_value_size );

  enum TSTTB_ErrorType
  TSTTM_getEHArrData (TSTTM_Instance instance,
                         /*in*/ const TSTTM_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*in*/ const TSTTM_TagHandle tag_handle,
                         /*inout*/ TSTTM_EntityHandle** tag_value,
                         /*inout*/ int* tag_value_allocated,
                         /*out*/ int* tag_value_size );

  enum TSTTB_ErrorType
  TSTTM_setArrData (TSTTM_Instance instance,
                       /*in*/ TSTTM_EntityHandle* entity_handles,
                       /*in*/ const int entity_handles_size,
                       /*in*/ const TSTTM_TagHandle tag_handle,
                       /*in*/ const char* tag_values,
                       /*in*/ const int tag_values_size);

  enum TSTTB_ErrorType
  TSTTM_setIntArrData (TSTTM_Instance instance,
                          /*in*/ TSTTM_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                          /*in*/ const int* tag_values,
                          /*in*/ const int tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_setDblArrData (TSTTM_Instance instance,
                          /*in*/ TSTTM_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const TSTTM_TagHandle tag_handle,
                          /*in*/ const double* tag_values,
                          /*in*/ const int tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_setBoolArrData (TSTTM_Instance instance,
                           /*in*/ TSTTM_EntityHandle* entity_handles,
                           /*in*/ const int entity_handles_size,
                           /*in*/ const TSTTM_TagHandle tag_handle,
                           /*in*/ const bool* tag_values,
                           /*in*/ const int tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_setEHArrData (TSTTM_Instance instance,
                         /*in*/ TSTTM_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*in*/ const TSTTM_TagHandle tag_handle,
                         /*in*/ const TSTTM_EntityHandle* tag_values,
                         /*in*/ const int tag_values_size );

  enum TSTTB_ErrorType
  TSTTM_rmvArrTag (TSTTM_Instance instance,
                      /*in*/ TSTTM_EntityHandle* entity_handles,
                      /*in*/ const int entity_handles_size,
                      /*in*/ const TSTTM_TagHandle tag_handle );

  enum TSTTB_ErrorType
  TSTTM_getData (TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle entity_handle,
                    /*in*/ const TSTTM_TagHandle tag_handle,
                    /*inout*/ char** tag_value,
                 /*inout*/ int *tag_value_allocated,
                 /*out*/ int *tag_value_size);

  int
  TSTTM_getIntData (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_handle,
                       /*in*/ const TSTTM_TagHandle tag_handle );

  double
  TSTTM_getDblData (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_handle,
                       /*in*/ const TSTTM_TagHandle tag_handle );

  bool
  TSTTM_getBoolData (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_handle,
                        /*in*/ const TSTTM_TagHandle tag_handle );

  TSTTM_EntityHandle
  TSTTM_getEHData (TSTTM_Instance instance,
                      /*in*/ const TSTTM_EntityHandle entity_handle,
                      /*in*/ const TSTTM_TagHandle tag_handle );

  enum TSTTB_ErrorType
  TSTTM_setData (TSTTM_Instance instance,
                    /*in*/ TSTTM_EntityHandle entity_handle,
                    /*in*/ const TSTTM_TagHandle tag_handle,
                    /*in*/ const char* tag_value,
                 /*in*/ const int tag_value_size);

  enum TSTTB_ErrorType
  TSTTM_setIntData (TSTTM_Instance instance,
                       /*in*/ TSTTM_EntityHandle entity_handle,
                       /*in*/ const TSTTM_TagHandle tag_handle,
                       /*in*/ const int tag_value );

  enum TSTTB_ErrorType
  TSTTM_setDblData (TSTTM_Instance instance,
                   
                       /*in*/ TSTTM_EntityHandle entity_handle,
                       /*in*/ const TSTTM_TagHandle tag_handle,
                       /*in*/ const double tag_value );

  enum TSTTB_ErrorType
  TSTTM_setBoolData (TSTTM_Instance instance,
                        /*in*/ TSTTM_EntityHandle entity_handle,
                        /*in*/ const TSTTM_TagHandle tag_handle,
                        /*in*/ const bool tag_value );

  enum TSTTB_ErrorType
  TSTTM_setEHData (TSTTM_Instance instance,
                      /*in*/ TSTTM_EntityHandle entity_handle,
                      /*in*/ const TSTTM_TagHandle tag_handle,
                   /*in*/ const TSTTM_EntityHandle tag_value );

  enum TSTTB_ErrorType
  TSTTM_getAllTags (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_handle,
                       /*inout*/ TSTTM_TagHandle** tag_handles,
                       /*inout*/ int* tag_handles_allocated,
                       /*out*/ int* tag_handles_size );

  enum TSTTB_ErrorType
  TSTTM_rmvTag (TSTTM_Instance instance,
                   /*in*/ TSTTM_EntityHandle entity_handle,
                   /*in*/ const TSTTM_TagHandle tag_handle );

  bool
  TSTTM_initEntIter (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle entity_set_handle,
                        /*in*/ const enum TSTTM_EntityType requested_entity_type,
                        /*in*/ const enum TSTTM_EntityTopology requested_entity_topology,
                        /*out*/ TSTTM_EntityIterator* entity_iterator );

  bool
  TSTTM_getNextEntIter (TSTTM_Instance instance,
                           /*in*/ TSTTM_EntityIterator entity_iterator,
                           /*out*/ TSTTM_EntityHandle* entity_handle );

  enum TSTTB_ErrorType
  TSTTM_resetEntIter (TSTTM_Instance instance,
                         /*in*/ TSTTM_EntityIterator entity_iterator );

  enum TSTTB_ErrorType
  TSTTM_endEntIter (TSTTM_Instance instance,
                       /*in*/ TSTTM_EntityIterator entity_iterator );

  enum TSTTM_EntityTopology
  TSTTM_getEntTopo (TSTTM_Instance instance,
                       /*in*/ const TSTTM_EntityHandle entity_handle );
 
  enum TSTTM_EntityType
  TSTTM_getEntType (TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle entity_handle );

  enum TSTTB_ErrorType
  TSTTM_getVtxCoord (TSTTM_Instance instance,
                        /*in*/ const TSTTM_EntityHandle vertex_handle,
                     /*out*/ double &x, /*out*/ double &y, /*out*/ double &z);

  enum TSTTB_ErrorType  
  TSTTM_getEntAdj (TSTTM_Instance instance,
                   /*in*/ const TSTTM_EntityHandle entity_handle,
                     /*in*/ const enum TSTTM_EntityType entity_type_requested,
                     /*inout*/ TSTTM_EntityHandle** adj_entity_handles,
                     /*inout*/ int* adj_entity_handles_allocated,
                     /*out*/ int* adj_entity_handles_size );

  enum TSTTB_ErrorType
  TSTTM_subtract(TSTTM_Instance instance,
                    /*in*/ const TSTTM_EntityHandle entity_set_1,
                    /*in*/ const TSTTM_EntityHandle entity_set_2,
                    /*out*/ TSTTM_EntityHandle* result_entity_set);

  enum TSTTB_ErrorType 
  TSTTM_intersect(TSTTM_Instance instance,
                     /*in*/ const TSTTM_EntityHandle entity_set_1,
                     /*in*/ const TSTTM_EntityHandle entity_set_2,
                     /*out*/ TSTTM_EntityHandle* result_entity_set);

  enum TSTTB_ErrorType 
  TSTTM_unite(TSTTM_Instance instance,
              /*in*/ const TSTTM_EntityHandle entity_set_1,
              /*in*/ const TSTTM_EntityHandle entity_set_2,
              /*out*/ TSTTM_EntityHandle* result_entity_set);

#ifdef __cplusplus
}
#endif

#endif
