// 
// File:          TSTTB_Error_Impl.cc
// Symbol:        TSTTB.Error-v0.7
// Symbol Type:   class
// Babel Version: 0.9.8
// sidl Created:  20051011 14:22:30 GMT-06:00
// Generated:     20051011 14:22:33 GMT-06:00
// Description:   Server-side implementation for TSTTB.Error
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.8
// source-line   = 49
// source-url    = file:/home/tjtautg/tstt/cvs/TSTTB/TSTTB.sidl
// 
#include "TSTTB_Error_Impl.hh"

// DO-NOT-DELETE splicer.begin(TSTTB.Error._includes)
// Put additional includes or other arbitrary code here...
// DO-NOT-DELETE splicer.end(TSTTB.Error._includes)

// user defined constructor
void TSTTB::Error_impl::_ctor() {
  // DO-NOT-DELETE splicer.begin(TSTTB.Error._ctor)
  // add construction details here
  thisType = ErrorType_SUCCESS;
  // DO-NOT-DELETE splicer.end(TSTTB.Error._ctor)
}

// user defined destructor
void TSTTB::Error_impl::_dtor() {
  // DO-NOT-DELETE splicer.begin(TSTTB.Error._dtor)
  // add destruction details here
  // DO-NOT-DELETE splicer.end(TSTTB.Error._dtor)
}

// user defined static methods: (none)

// user defined non-static methods:
/**
 * Method:  set[]
 */
void
TSTTB::Error_impl::set (
  /*in*/ ::TSTTB::ErrorType error,
  /*in*/ const ::std::string& description ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(TSTTB.Error.set)
  // insert implementation here
  thisType = error;
  thisDescription = description;
  // DO-NOT-DELETE splicer.end(TSTTB.Error.set)
}

/**
 * Method:  getErrorType[]
 */
::TSTTB::ErrorType
TSTTB::Error_impl::getErrorType () 
throw () 

{
  // DO-NOT-DELETE splicer.begin(TSTTB.Error.getErrorType)
  // insert implementation here
  return thisType;
  // DO-NOT-DELETE splicer.end(TSTTB.Error.getErrorType)
}

/**
 * Method:  get[]
 */
void
TSTTB::Error_impl::get (
  /*out*/ ::TSTTB::ErrorType& err,
  /*out*/ ::std::string& description ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(TSTTB.Error.get)
  // insert implementation here
  err = thisType;
  description = thisDescription;
  // DO-NOT-DELETE splicer.end(TSTTB.Error.get)
}

/**
 * Method:  getDescription[]
 */
::std::string
TSTTB::Error_impl::getDescription () 
throw () 

{
  // DO-NOT-DELETE splicer.begin(TSTTB.Error.getDescription)
  // insert implementation here
  return thisDescription;
  // DO-NOT-DELETE splicer.end(TSTTB.Error.getDescription)
}

/**
 * Method:  echo[]
 */
void
TSTTB::Error_impl::echo (
  /*in*/ const ::std::string& label ) 
throw () 
{
  // DO-NOT-DELETE splicer.begin(TSTTB.Error.echo)
  // insert implementation here
  thisDescription = label + thisDescription;
  // DO-NOT-DELETE splicer.end(TSTTB.Error.echo)
}


// DO-NOT-DELETE splicer.begin(TSTTB.Error._misc)
// Put miscellaneous code here
// DO-NOT-DELETE splicer.end(TSTTB.Error._misc)

