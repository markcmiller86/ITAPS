// 
// File:          TSTTB_Error_Impl.hh
// Symbol:        TSTTB.Error-v0.7
// Symbol Type:   class
// Babel Version: 0.9.8
// sidl Created:  20051011 14:22:30 GMT-06:00
// Generated:     20051011 14:22:33 GMT-06:00
// Description:   Server-side implementation for TSTTB.Error
// 
// WARNING: Automatically generated; only changes within splicers preserved
// 
// babel-version = 0.9.8
// source-line   = 49
// source-url    = file:/home/tjtautg/tstt/cvs/TSTTB/TSTTB.sidl
// 

#ifndef included_TSTTB_Error_Impl_hh
#define included_TSTTB_Error_Impl_hh

#ifndef included_sidl_cxx_hh
#include "sidl_cxx.hh"
#endif
#ifndef included_TSTTB_Error_IOR_h
#include "TSTTB_Error_IOR.h"
#endif
// 
// Includes for all method dependencies.
// 
#ifndef included_TSTTB_Error_hh
#include "TSTTB_Error.hh"
#endif
#ifndef included_TSTTB_ErrorType_hh
#include "TSTTB_ErrorType.hh"
#endif
#ifndef included_sidl_BaseInterface_hh
#include "sidl_BaseInterface.hh"
#endif
#ifndef included_sidl_ClassInfo_hh
#include "sidl_ClassInfo.hh"
#endif


// DO-NOT-DELETE splicer.begin(TSTTB.Error._includes)
// Put additional includes or other arbitrary code here...
/**
 * MOAB, a Mesh-Oriented datABase, is a software component for creating,
 * storing and accessing finite element mesh data.
 * 
 * Copyright 2004 Sandia Corporation.  Under the terms of Contract
 * DE-AC04-94AL85000 with Sandia Coroporation, the U.S. Government
 * retains certain rights in this software.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 */

// DO-NOT-DELETE splicer.end(TSTTB.Error._includes)

namespace TSTTB { 

  /**
   * Symbol "TSTTB.Error" (version 0.7)
   */
  class Error_impl
  // DO-NOT-DELETE splicer.begin(TSTTB.Error._inherits)
  // Put additional inheritance here...
  // DO-NOT-DELETE splicer.end(TSTTB.Error._inherits)
  {

  private:
    // Pointer back to IOR.
    // Use this to dispatch back through IOR vtable.
    Error self;

    // DO-NOT-DELETE splicer.begin(TSTTB.Error._implementation)
    // Put additional implementation details here...
    ErrorType thisType;
    ::std::string thisDescription;
    // DO-NOT-DELETE splicer.end(TSTTB.Error._implementation)

  private:
    // private default constructor (required)
    Error_impl() {} 

  public:
    // sidl constructor (required)
    // Note: alternate Skel constructor doesn't call addref()
    // (fixes bug #275)
    Error_impl( struct TSTTB_Error__object * s ) : self(s,true) { _ctor(); }

    // user defined construction
    void _ctor();

    // virtual destructor (required)
    virtual ~Error_impl() { _dtor(); }

    // user defined destruction
    void _dtor();

  public:

    /**
     * user defined non-static method.
     */
    void
    set (
      /*in*/ ::TSTTB::ErrorType error,
      /*in*/ const ::std::string& description
    )
    throw () 
    ;

    /**
     * user defined non-static method.
     */
    ::TSTTB::ErrorType
    getErrorType() throw () 
    ;
    /**
     * user defined non-static method.
     */
    void
    get (
      /*out*/ ::TSTTB::ErrorType& err,
      /*out*/ ::std::string& description
    )
    throw () 
    ;

    /**
     * user defined non-static method.
     */
    ::std::string
    getDescription() throw () 
    ;
    /**
     * user defined non-static method.
     */
    void
    echo (
      /*in*/ const ::std::string& label
    )
    throw () 
    ;

  };  // end class Error_impl

} // end namespace TSTTB

// DO-NOT-DELETE splicer.begin(TSTTB.Error._misc)
// Put miscellaneous things here...
// DO-NOT-DELETE splicer.end(TSTTB.Error._misc)

#endif
