#include "babel_config.h"

#if defined(PACKAGE_VERSION)
#define ARRAY_PTR(array, type) reinterpret_cast<type*>(array._get_ior()->d_firstElement)

#define ARRAY_SIZE(array) (array._is_nil() ? 0 : (int)(array.upper(0) - array.lower(0) + 1))

#define ASSIGN_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(my_arr._get_ior()->d_firstElement);\
            my_arr._get_ior()->d_firstElement = my_arr ## _temp;\
            my_arr._get_ior()->d_lower[0] = 0;\
            my_arr._get_ior()->d_upper[0] = my_arr ## _allocated_size -1;\
            my_arr._get_ior()->d_stride[0] = 1;\
          }

#define CREATE_TEMP_ARRAY(this_type, my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          this_type *my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          my_arr._get_ior()->d_upper[0] - my_arr._get_ior()->d_lower[0] + 1)

#define CREATE_TEMP_EH_ARRAY(my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          void **my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          my_arr._get_ior()->d_upper[0] - my_arr._get_ior()->d_lower[0] + 1)

#define ASSIGN_TAG_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(my_arr._get_ior()->d_firstElement);\
            my_arr._get_ior()->d_firstElement = (char*) my_arr ## _temp;\
            my_arr._get_ior()->d_lower[0] = 0;\
            my_arr._get_ior()->d_upper[0] = (my_arr ## _allocated_size) -1;\
            my_arr._get_ior()->d_stride[0] = 1;\
          };

#define CREATE_TEMP_TAG_ARRAY(my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          char *my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          (my_arr._get_ior()->d_upper[0] - my_arr._get_ior()->d_lower[0] + 1))

#define ASSIGN_ENUM_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(((sidl_int__array*)my_arr._get_ior())->d_firstElement);\
            ((sidl_int__array*)my_arr._get_ior())->d_firstElement = (int*)my_arr ## _temp;\
            ((sidl_int__array*)my_arr._get_ior())->d_lower[0] = 0;\
            ((sidl_int__array*)my_arr._get_ior())->d_upper[0] = my_arr ## _size -1;\
            ((sidl_int__array*)my_arr._get_ior())->d_stride[0] = 1; \
          }

#define CREATE_TEMP_ENUM_ARRAY(this_type, my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          this_type *my_arr ## _temp = (this_type*)(my_arr._get_ior() == NULL ? NULL : \
                                                    ((sidl_int__array*)my_arr._get_ior())->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 : \
                                           ((sidl_int__array*)my_arr._get_ior())->d_upper[0] - \
                                           ((sidl_int__array*)my_arr._get_ior())->d_lower[0] + 1)

#define TEMP_ARRAY_INOUT(my_arr) &my_arr ## _temp, &my_arr ## _allocated_size, &my_arr ## _size

#define TEMP_ARRAY_IN(my_arr) \
          (my_arr._get_ior() == NULL ? NULL : my_arr._get_ior()->d_firstElement), \
          my_arr ## _size

#define TEMP_TAG_ARRAY_IN(my_arr) \
          my_arr._get_ior()->d_firstElement, \
          (my_arr._get_ior()->d_upper[0] - my_arr._get_ior()->d_lower[0] + 1)

#else
#define ARRAY_PTR(array, type) reinterpret_cast<type*>(array._get_ior()->d_firstElement)

#define ARRAY_SIZE(array) (array._is_nil() ? 0 : (int)(array.upper(0) - array.lower(0) + 1))

#define ASSIGN_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(my_arr._get_ior()->d_firstElement);\
            my_arr._get_ior()->d_firstElement = my_arr ## _temp;\
            my_arr._get_ior()->d_metadata.d_lower[0] = 0;\
            my_arr._get_ior()->d_metadata.d_upper[0] = my_arr ## _allocated_size -1;\
            my_arr._get_ior()->d_metadata.d_stride[0] = 1;\
          }

#define CREATE_TEMP_ARRAY(this_type, my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          this_type *my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          my_arr._get_ior()->d_metadata.d_upper[0] - my_arr._get_ior()->d_metadata.d_lower[0] + 1)

#define CREATE_TEMP_EH_ARRAY(my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          void **my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          my_arr._get_ior()->d_metadata.d_upper[0] - my_arr._get_ior()->d_metadata.d_lower[0] + 1)

#define ASSIGN_TAG_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(my_arr._get_ior()->d_firstElement);\
            my_arr._get_ior()->d_firstElement = (char*) my_arr ## _temp;\
            my_arr._get_ior()->d_metadata.d_lower[0] = 0;\
            my_arr._get_ior()->d_metadata.d_upper[0] = (my_arr ## _allocated_size) -1;\
            my_arr._get_ior()->d_metadata.d_stride[0] = 1;\
          };

#define CREATE_TEMP_TAG_ARRAY(my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          char *my_arr ## _temp = (my_arr._get_ior() == NULL ? NULL : \
              my_arr._get_ior()->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 :\
          (my_arr._get_ior()->d_metadata.d_upper[0] - my_arr._get_ior()->d_metadata.d_lower[0] + 1))

#define ASSIGN_ENUM_ARRAY(my_arr) \
          if (!my_arr ## _i_allocated && \
              ARRAY_SIZE(my_arr) < my_arr ## _allocated_size) {\
                LOCAL_TSTTB_ERROR.error_type = TSTTB_MEMORY_ALLOCATION_FAILED;\
                sprintf(LOCAL_TSTTB_ERROR.description, "Array passed in is non-zero length but not long enough.");\
                processError();} \
          else if (my_arr ## _i_allocated && my_arr ## _allocated_size > 0) {\
            my_arr = my_arr.create1d(0);\
            free(((sidl_int__array*)my_arr._get_ior())->d_firstElement);\
            ((sidl_int__array*)my_arr._get_ior())->d_firstElement = (int*)my_arr ## _temp;\
            ((sidl_int__array*)my_arr._get_ior())->d_metadata.d_lower[0] = 0;\
            ((sidl_int__array*)my_arr._get_ior())->d_metadata.d_upper[0] = my_arr ## _size -1;\
            ((sidl_int__array*)my_arr._get_ior())->d_metadata.d_stride[0] = 1; \
          }

#define CREATE_TEMP_ENUM_ARRAY(this_type, my_arr) \
          bool my_arr ## _i_allocated = (my_arr._get_ior() == NULL); \
          this_type *my_arr ## _temp = (this_type*)(my_arr._get_ior() == NULL ? NULL : \
                                                    ((sidl_int__array*)my_arr._get_ior())->d_firstElement); \
          int my_arr ## _allocated_size = (my_arr._get_ior() == NULL ? 0 : \
                                           ((sidl_int__array*)my_arr._get_ior())->d_metadata.d_upper[0] - \
                                           ((sidl_int__array*)my_arr._get_ior())->d_metadata.d_lower[0] + 1)

#define TEMP_ARRAY_INOUT(my_arr) &my_arr ## _temp, &my_arr ## _allocated_size, &my_arr ## _size

#define TEMP_ARRAY_IN(my_arr) \
          (my_arr._get_ior() == NULL ? NULL : my_arr._get_ior()->d_firstElement), \
          my_arr ## _size

#define TEMP_TAG_ARRAY_IN(my_arr) \
          my_arr._get_ior()->d_firstElement, \
          (my_arr._get_ior()->d_metadata.d_upper[0] - my_arr._get_ior()->d_metadata.d_lower[0] + 1)

#endif

#ifdef TEST_DEFS
CREATE_TEMP_ARRAY(TSTTB_ErrorType, error_table);

TEMP_ARRAY_INOUT(error_table);

TEMP_ARRAY_IN(error_table);

ASSIGN_ARRAY(error_table);
#endif
