// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <stdlib.h>

#include "RI_config.h"
#include "RI_Classes.h"

#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Vertex.h"
#include "RI_VolMesh.h"

// The semantics of these calls are essentially identical to the ITAPS
// createEnt calls.
//   createFace returns a face with given vertices; if the face
//     already existed it might be opposite in sense, but that's OK.
//   create*Cell returns a cell with given verts or faces.

Face* VolMesh::createFace(int *status,
			  Vert * const pV0, Vert * const pV1,
			  Vert * const pV2, Vert * const pV3)
{
  // iMesh merge: need to return both the face ptr and a flag indicating
  // whether the face already existed.
  assert(pV0->qValid());
  assert(pV1->qValid());
  assert(pV2->qValid());
  Face *pF;
  if (!pV3->qValid()) {
    // Creating a tri.
    // Check for prior existence.
    pF = findCommonFace(pV0, pV1, pV2);
    if (pF == pFInvalidFace) {
      // Face doesn't exist yet.
      *status = iBase_NEW;
      pF = pFNewFace(3);
      pF->vSetVerts(pV0, pV1, pV2);
    }
    else {
      *status = iBase_ALREADY_EXISTED;
    }
  }
  else {
    // Creating a quad.
    // Check for prior existence.
    pF = findCommonFace(pV0, pV1, pV2, pV3);
    if (pF == pFInvalidFace) {
      // Face doesn't exist yet.
      *status = iBase_NEW;
      pF = pFNewFace(4);
      pF->vSetVerts(pV0, pV1, pV2, pV3);
    }
    else {
      *status = iBase_ALREADY_EXISTED;
    }
  }
  // Not a lot of checking possible here, since the face is created
  // before the cell...

  return pF;
}

static Cell* commonCell(Face * const pF0, Face * const pF1,
			Face * const pF2, Face * const pF3,
			Face * const pF4 = NULL, Face * const pF5 = NULL)
{
  // If one exists, find the cell common to all the faces in the arg
  // list.
  Cell *pCCom01, *pCCom02, *pCCom03, *pCCom04 = NULL, *pCCom05 = NULL;
  if ((pCCom01 = pCCommonCell(pF0, pF1))->qValid() &&
      (pCCom02 = pCCommonCell(pF0, pF2))->qValid() &&
      (pCCom03 = pCCommonCell(pF0, pF3))->qValid() &&
      (!pF4->qValid() || (pCCom04 = pCCommonCell(pF0, pF4))->qValid()) &&
      (!pF5->qValid() || (pCCom05 = pCCommonCell(pF0, pF5))->qValid())) {
    // Hit a common cell.
    return pCCom01;
  }
  else {
    return NULL;
  }  
}

static void vQuadSetCellWithOrientation(Cell * const pC, Face * const pF,
					const Vert * const pVRef)
{
  assert(pF->eType() == Face::eQuadFace);
  // The quad, if it already exists, may be in either orientation.
  // This could also be checked topologically, and maybe should be.
  Vert *apV[4];
  pF->vAllVertHandles(reinterpret_cast<RefImpl_Entity**>(apV));
  
  // If this orientation is negative, then surely it means that the
  // bottom face is oriented out.
  int iOrient = iOrient3D(apV[0], apV[1], apV[2], pVRef);
  assert(iOrient3D(apV[0], apV[2], apV[3], pVRef) == iOrient);

  if (iOrient == 1) {
    assert(!pF->pCCellRight()->qValid());
    pF->vSetRightCell(pC);
  }
  else {
    assert(!pF->pCCellLeft()->qValid());
    pF->vSetLeftCell(pC);
  }
}

static void vTriSetCellWithOrientation(Cell * const pC, Face * const pF,
				       const Vert * const pVRef)
{
  assert(pF->eType() == Face::eTriFace);
  // The tri, if it already exists, may be in either orientation.
  // This could also be checked topologically, and maybe should be.
  Vert *apV[3];
  pF->vAllVertHandles(reinterpret_cast<RefImpl_Entity**>(apV));
  
  // If this orientation is negative, then surely it means that the
  // bottom face is oriented out.
  int iOrient = iOrient3D(apV[0], apV[1], apV[2], pVRef);

  if (iOrient == 1) {
    assert(!pF->pCCellRight()->qValid());
    pF->vSetRightCell(pC);
  }
  else {
    assert(!pF->pCCellLeft()->qValid());
    pF->vSetLeftCell(pC);
  }

  // This failed to work in some cases.
  //   // If the verts are in cyclic order for the tri face, then pC is the
  //   // right cell, otherwise the left cell.
  //   if (dynamic_cast<TriFace*>(pF)->qRightHanded(pVA, pVB, pVC))
  //     { pF->vSetRightCell(pC); }
  //   else
  //     { pF->vSetLeftCell(pC); }
}

TetCell* VolMesh::createTetCell(int *status,
				Face * const pF103, Face * const pF213,
				Face * const pF023, Face * const pF012)
// This call creates a tet.
//
// Faces are stored in canonical order, even if they aren't passed that
// way.  Also, face->cell connectivity is set up as part of this
// function.
{
  // Faces must already exist
  if (!(pF012->qValid() && pF103->qValid() &&
	pF213->qValid() && pF023->qValid())) {
    *status = iBase_ENTITY_CREATION_ERROR;
    return NULL;
  }

  // Set up the face->cell connectivity properly.  The canonical tet
  // looks like this, where face 3 is the bottom (see ITAPS docs):
  //
  //                3
  //               /|\         .
  //              / | \        .
  //             /  |2 \       .
  //            /   |   \      .
  //           0 - - - - 2
  //            \ 0 | 1 /
  //             \ (3) /
  //              \ | /
  //               \|/
  //                1

  // Check whether the cell already exists.
  Cell *pC = commonCell(pF103, pF213, pF023, pF012);

  if (pC) {
    TetCell *pTC = dynamic_cast<TetCell*>(pC);
    if (pTC->qValid()) {
      *status = iBase_ALREADY_EXISTED;
      return pTC;
    }
    else {
      // Horrible error, almost surely!
      *status = iBase_CREATION_FAILED;
      return NULL;
    }
  }
  
  // Each trio of faces  must have a common vert.
  Vert *apV[4];
  apV[0] = pVCommonVert(pF103, pF023, pF012);
  apV[1] = pVCommonVert(pF103, pF213, pF012);
  apV[2] = pVCommonVert(pF213, pF023, pF012);
  apV[3] = pVCommonVert(pF103, pF213, pF023);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());
  assert(apV[3]->qValid());

  
  TetCell *pTC = dynamic_cast<TetCell*>(pCNewCell(4));

  int iOrient = iOrient3D(apV[0], apV[1], apV[2], apV[3]);
  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pTC->vAssign(pF103, pF213, pF023, pF012);
  }
  else {
    // Left-handed (faces 2 and 3 reversed above)
    pTC->vAssign(pF103, pF213, pF012, pF023);
  }

  vTriSetCellWithOrientation(pTC, pF213, apV[0]);
  vTriSetCellWithOrientation(pTC, pF023, apV[1]);
  vTriSetCellWithOrientation(pTC, pF103, apV[2]);
  vTriSetCellWithOrientation(pTC, pF012, apV[3]);

  assert(pTC->iFullCheck());
  assert(pTC->qHasFace(pF103));
  assert(pTC->qHasFace(pF213));
  assert(pTC->qHasFace(pF023));
  assert(pTC->qHasFace(pF012));
  assert(pF103->pCCellLeft() == pTC ||
	 pF103->pCCellRight() == pTC);
  assert(pF213->pCCellLeft() == pTC ||
	 pF213->pCCellRight() == pTC);
  assert(pF023->pCCellLeft() == pTC ||
	 pF023->pCCellRight() == pTC);
  assert(pF012->pCCellLeft() == pTC ||
	 pF012->pCCellRight() == pTC);

  *status = iBase_NEW;
  return pTC;
}

TetCell* VolMesh::createTetCell(int *status,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3)
// This one creates tets from verts via faces.
{
  int stat103, stat213, stat023, stat012;
  Face *pF012 = createFace(&stat012, pV0, pV1, pV2);
  Face *pF103 = createFace(&stat103, pV1, pV0, pV3);
  Face *pF213 = createFace(&stat213, pV2, pV1, pV3);
  Face *pF023 = createFace(&stat023, pV0, pV2, pV3);
  // Ignore status; if anything failed, we'll know soon enough.

  TetCell *pTC = createTetCell(status, pF103, pF213, pF023, pF012);

#ifndef NDEBUG
  assert(pTC->qHasVert(pV0));
  assert(pTC->qHasVert(pV1));
  assert(pTC->qHasVert(pV2));
  assert(pTC->qHasVert(pV3));

  // Now confirm that we've got orientation right
  Vert *apV[] = {pTC->pVVert(0), pTC->pVVert(1), pTC->pVVert(2), pTC->pVVert(3)};
  assert(iOrient3D(apV[0], apV[1], apV[2], apV[3]) == 1);
#endif
  return (pTC);
}

// The pyramid looks like this:
//
//                  4
//                 /|\               .
//                / | \              .
//               / |\  \             .
//              /  / |  \            .
//             /  |  |   \           .
//            /   /  \    \          .
//           /   |_---3-_  \         .
//          0--- /       ---2        .
//           \_ |    ---
//             \1---
//
// Okay, so it's a crappy pyramid; so what?  Faces are:
//  0:  014
//  1:  124
//  2:  234
//  3:  304
//  4:  0123
 
PyrCell* VolMesh::createPyrCell(int *status,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3,
				Vert * const pV4)
// This one creates pyramids from verts via faces.
{
  int stat014, stat124, stat234, stat304, stat0123;
  Face *pF014 = createFace(&stat014, pV0, pV1, pV4);
  Face *pF124 = createFace(&stat124, pV1, pV2, pV4);
  Face *pF234 = createFace(&stat234, pV2, pV3, pV4);
  Face *pF304 = createFace(&stat304, pV3, pV0, pV4);
  Face *pF0123 = createFace(&stat0123, pV0, pV1, pV2, pV3);
  // Ignore status; if any of the face creations failed, we'll know soon
  // enough. 
  
  return createPyrCell(status, pF014, pF124, pF234, pF304, pF0123);
}

PyrCell* VolMesh::createPyrCell(int *status,
				Face * const pF014, Face * const pF124,
				Face * const pF234, Face * const pF304,
				Face * const pF0123)
{
  // Faces must already exist and be the right type
  if (!((pF014->qValid()  && pF014->eType()  == Face::eTriFace ) &&
	(pF124->qValid()  && pF124->eType()  == Face::eTriFace ) &&
	(pF234->qValid()  && pF234->eType()  == Face::eTriFace ) &&
	(pF304->qValid()  && pF304->eType()  == Face::eTriFace ) &&
	(pF0123->qValid() && pF0123->eType() == Face::eQuadFace))) {
    *status = iBase_ENTITY_CREATION_ERROR;
    return NULL;
  }

  Cell *pC = commonCell(pF014, pF124, pF234, pF304, pF0123);
  if (pC) {
    PyrCell *pPC = dynamic_cast<PyrCell*>(pC);
    if (pPC->qValid()) {
      *status = iBase_ALREADY_EXISTED;
      return pPC;
    }
    else {
      // Horrible error, almost surely!
      *status = iBase_CREATION_FAILED;
      return NULL;
    }
  }

  PyrCell *pPC = dynamic_cast<PyrCell*>(pCNewCell(5, 5));
  assert(pPC);
  // Be sure to assign these with canonical ordering.
  pPC->vAssign(pF014, pF124, pF234, pF304, pF0123);

  Vert *pV4 = pVCommonVert(pF014, pF124, pF234);
  vQuadSetCellWithOrientation(pPC, pF0123, pV4);

  Vert *pV0 = pVCommonVert(pF014, pF304, pF0123);
  Vert *pV2 = pVCommonVert(pF124, pF234, pF0123);
  vTriSetCellWithOrientation(pPC, pF124, pV0);
  vTriSetCellWithOrientation(pPC, pF234, pV0);
  vTriSetCellWithOrientation(pPC, pF304, pV2);
  vTriSetCellWithOrientation(pPC, pF014, pV2);

#ifndef NDEBUG
  // Now confirm that we've got orientation right
  Vert *apV[] = {pPC->pVVert(0), pPC->pVVert(1), pPC->pVVert(2), pPC->pVVert(3),
		 pPC->pVVert(4)};
  assert(iOrient3D(apV[0], apV[1], apV[2], apV[4]) == 1);
  assert(iOrient3D(apV[0], apV[2], apV[3], apV[4]) == 1);
  assert(iOrient3D(apV[0], apV[4], apV[1], apV[2]) == 1);
  assert(iOrient3D(apV[1], apV[4], apV[2], apV[3]) == 1);
  assert(iOrient3D(apV[2], apV[4], apV[3], apV[0]) == 1);
  assert(iOrient3D(apV[3], apV[4], apV[0], apV[1]) == 1);
  
  assert(pF014->pCCellLeft() == pPC ||
	 pF014->pCCellRight() == pPC);
  assert(pF124->pCCellLeft() == pPC ||
	 pF124->pCCellRight() == pPC);
  assert(pF234->pCCellLeft() == pPC ||
	 pF234->pCCellRight() == pPC);
  assert(pF304->pCCellLeft() == pPC ||
	 pF304->pCCellRight() == pPC);
  assert(pF0123->pCCellLeft() == pPC ||
	 pF0123->pCCellRight() == pPC);

#endif

  *status = iBase_NEW;
  return (pPC);
}

PrismCell* VolMesh::createPrismCell(int *status,
				    Vert * const pV0, Vert * const pV1,
				    Vert * const pV2, Vert * const pV3,
				    Vert * const pV4, Vert * const pV5)
// This one creates prisms from verts via faces.
{
  // Verts 0, 1, 2 form a ring around the bottom.
  // Verts 3, 4, 5 form a ring around the top.
  
  int stat0143, stat1254, stat2035, stat012, stat543;
  Face *pF0143 = createFace(&stat0143, pV0, pV1, pV4, pV3);
  Face *pF1254 = createFace(&stat1254, pV1, pV2, pV5, pV4);
  Face *pF2035 = createFace(&stat2035, pV2, pV0, pV3, pV5);
  Face *pF012 = createFace(&stat012, pV0, pV1, pV2);
  Face *pF543 = createFace(&stat543, pV5, pV4, pV3);
  // If one fails, we'll know immediately anyway.

  return createPrismCell(status, pF0143, pF1254, pF2035, pF012, pF543);
}

PrismCell* VolMesh::createPrismCell(int *status,
				    Face * const pF0143, Face * const pF1254,
				    Face * const pF2035, Face * const pF012,
				    Face * const pF543)
{
  // Faces must already exist
  if (!((pF0143->qValid() && pF0143->eType() == Face::eQuadFace) &&
	(pF1254->qValid() && pF1254->eType() == Face::eQuadFace) &&
	(pF2035->qValid() && pF2035->eType() == Face::eQuadFace) &&
	(pF543->qValid()  && pF543 ->eType() == Face::eTriFace ) &&
	(pF012->qValid()  && pF012 ->eType() == Face::eTriFace ))) {
    *status = iBase_ENTITY_CREATION_ERROR;
    return NULL;
  }

  Cell *pC = commonCell(pF0143, pF1254, pF2035, pF543, pF012);
  if (pC) {
    PrismCell *pPC = dynamic_cast<PrismCell*>(pC);
    if (pPC->qValid()) {
      *status = iBase_ALREADY_EXISTED;
      return pPC;
    }
    else {
      // Horrible error, almost surely!
      *status = iBase_CREATION_FAILED;
      return NULL;
    }
  }

  PrismCell *pPC = dynamic_cast<PrismCell*>(pCNewCell(5, 6));
  assert(pPC);
  // Be sure to assign these with canonical ordering.
  pPC->vAssign(pF0143, pF1254, pF2035, pF012, pF543);

  Vert *pV0 = pVCommonVert(pF0143, pF2035, pF012);
  Vert *pV1 = pVCommonVert(pF0143, pF1254, pF012);
  Vert *pV2 = pVCommonVert(pF1254, pF2035, pF012);
  Vert *pV3 = pVCommonVert(pF0143, pF2035, pF543);

  vQuadSetCellWithOrientation(pPC, pF0143, pV2);
  vQuadSetCellWithOrientation(pPC, pF1254, pV0);
  vQuadSetCellWithOrientation(pPC, pF2035, pV1);
  vTriSetCellWithOrientation(pPC, pF012, pV3);
  vTriSetCellWithOrientation(pPC, pF543, pV0);

  assert(pF0143->pCCellLeft() == pPC ||
	 pF0143->pCCellRight() == pPC);
  assert(pF1254->pCCellLeft() == pPC ||
	 pF1254->pCCellRight() == pPC);
  assert(pF2035->pCCellLeft() == pPC ||
	 pF2035->pCCellRight() == pPC);
  assert(pF012->pCCellLeft() == pPC ||
	 pF012->pCCellRight() == pPC);
  assert(pF543->pCCellLeft() == pPC ||
	 pF543->pCCellRight() == pPC);

  assert(pPC->qHasVert(pV0));
  assert(pPC->qHasVert(pV1));
  assert(pPC->qHasVert(pV2));
  assert(pPC->qHasVert(pV3));
  // These two verts aren't currently identified.
//   assert(pPC->qHasVert(pV4));
//   assert(pPC->qHasVert(pV5));

  *status = iBase_NEW;
  return pPC;
}

HexCell* VolMesh::createHexCell(int *status,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3,
				Vert * const pV4, Vert * const pV5,
				Vert * const pV6, Vert * const pV7)
// This one creates hexes from verts via faces.
{
  // Verts 0, 1, 2, 3 form a ring around the bottom.
  // Verts 4, 5, 6, 7 form a ring around the top.
  int stat0123, stat4567, stat0154, stat1265, stat2376, stat3047;
  Face *pF0123 = createFace(&stat0123, pV0, pV1, pV2, pV3);
  Face *pF4567 = createFace(&stat4567, pV4, pV5, pV6, pV7);
  Face *pF0154 = createFace(&stat0154, pV0, pV1, pV5, pV4);
  Face *pF1265 = createFace(&stat1265, pV1, pV2, pV6, pV5);
  Face *pF2376 = createFace(&stat2376, pV2, pV3, pV7, pV6);
  Face *pF3047 = createFace(&stat3047, pV3, pV0, pV4, pV7);
  // If any faces couldn't be created, we'll soon know.

  return createHexCell(status, pF0123, pF0154, pF1265, pF2376, pF3047, pF4567);
}

HexCell* VolMesh::createHexCell(int *status,
				Face * const pF0123, Face * const pF0154,
				Face * const pF1265, Face * const pF2376,
				Face * const pF3047, Face * const pF4567)
{
  // Faces must already exist
  if (!((pF0123->qValid() && pF0123->eType() == Face::eQuadFace) &&
	(pF0154->qValid() && pF0154->eType() == Face::eQuadFace) &&
	(pF1265->qValid() && pF1265->eType() == Face::eQuadFace) &&
	(pF2376->qValid() && pF2376->eType() == Face::eQuadFace) &&
	(pF3047->qValid() && pF3047->eType() == Face::eQuadFace) &&
	(pF4567->qValid() && pF4567->eType() == Face::eQuadFace))) {
    *status = iBase_ENTITY_CREATION_ERROR;
    return NULL;
  }

  Cell *pC = commonCell(pF0123, pF0154, pF1265, pF2376, pF3047, pF4567);
  if (pC) {
    HexCell *pHC = dynamic_cast<HexCell*>(pC);
    if (pHC->qValid()) {
      *status = iBase_ALREADY_EXISTED;
      return pHC;
    }
    else {
      // Horrible error, almost surely!
      *status = iBase_CREATION_FAILED;
      return NULL;
    }
  }

  HexCell *pHC = dynamic_cast<HexCell*>(pCNewCell(6, 8));
  assert(pHC);
  // Be sure to assign these with canonical ordering.
  pHC->vAssign(pF0123, pF0154, pF1265, pF2376, pF3047, pF4567);

  Vert *pV0 = pVCommonVert(pF0123, pF0154, pF3047);
  Vert *pV6 = pVCommonVert(pF1265, pF4567, pF2376);
  vQuadSetCellWithOrientation(pHC, pF1265, pV0);
  vQuadSetCellWithOrientation(pHC, pF4567, pV0);
  vQuadSetCellWithOrientation(pHC, pF2376, pV0);
  vQuadSetCellWithOrientation(pHC, pF0123, pV6);
  vQuadSetCellWithOrientation(pHC, pF0154, pV6);
  vQuadSetCellWithOrientation(pHC, pF3047, pV6);

  assert(pF0123->pCCellLeft() == pHC ||
	 pF0123->pCCellRight() == pHC);
  assert(pF4567->pCCellLeft() == pHC ||
	 pF4567->pCCellRight() == pHC);
  assert(pF0154->pCCellLeft() == pHC ||
	 pF0154->pCCellRight() == pHC);
  assert(pF1265->pCCellLeft() == pHC ||
	 pF1265->pCCellRight() == pHC);
  assert(pF2376->pCCellLeft() == pHC ||
	 pF2376->pCCellRight() == pHC);
  assert(pF3047->pCCellLeft() == pHC ||
	 pF3047->pCCellRight() == pHC);

  *status = iBase_NEW;
  return pHC;
}

bool VolMesh::deleteCell(Cell * const pC)
{
#ifndef OMIT_OLD_DATA_STRUCTURES
  // Free up connectivity for faces.
  for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pC->pFFace(i);
    if (pF->qValid())
      pF->vRemoveCell(pC);
  }
  // Under the old data structures, just mark it.
  pC->vMarkDeleted();
  return true;
#endif
}

// Like ITAPS, faces that are in use can't be deleted.
bool VolMesh::deleteFace(Face * const pF, const bool qForce)
{
  // Make sure that verts whose hint is going away realize it...
  for (int iV = pF->iNumVerts() - 1; iV >= 0; iV--) {
    Vert *pV = pF->pVVert(iV);
    pV->vRemoveFace(pF);
  }

#ifndef OMIT_OLD_DATA_STRUCTURES
  // Under the old data structures, just mark it.
  if (qForce ||
      (!pF->pCCellLeft()->qValid() && !pF->pCCellRight()->qValid())) {
    pF->vMarkDeleted();
    return true;
  }
  else {
    return false;
  }
#endif
}

Vert* VolMesh::createVert(const double dX, const double dY, const double dZ)
{
  Vert *pV = pVNewVert();
  pV->vSetDefaultFlags();
  double adData[] = {dX, dY, dZ};
  pV->vSetCoords(3, adData);
  return pV;
}

bool VolMesh::deleteVert(Vert * const pV, bool qForce)
// Again, verts that are in use can't be deleted without forcing that.
{
  if (pV->iNumFaces() == 0 || qForce) {
#ifndef OMIT_OLD_DATA_STRUCTURES
    // Under the old data structures, just mark it.
    pV->vMarkDeleted();
#endif
    return true;
  }
  else {
    return false;
  }
}

