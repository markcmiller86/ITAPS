// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include "RI_misc.h"
#include "RI_Vertex.h"
#include "RI_Face.h"
#include "RI_Cell.h"

#define MINMAX4(da, db, dc, dd, dMin, dMax) { \
  double dMax1, dMax2, dMin1, dMin2; \
  if (da > db) {dMax1 = da; dMin1 = db;} \
  else         {dMax1 = db; dMin1 = da;} \
  if (dc > dd) {dMax2 = dc; dMin2 = dd;} \
  else         {dMax2 = dd; dMin2 = dc;} \
  if (dMax1 > dMax2) dMax = dMax1; \
  else               dMax = dMax2; \
  if (dMin1 < dMin2) dMin = dMin1; \
  else               dMin = dMin2; \
}

//@ 3D orientation test
int iOrient3D(const Vert* const pVertA, const Vert* const pVertB,
	      const Vert* const pVertC, const Vert* const pVertD)
{
  assert(pVertA->qValid());
  assert(pVertB->qValid());
  assert(pVertC->qValid());
  assert(pVertD->qValid());

  return (iOrient3D(pVertA->adCoords(), pVertB->adCoords(),
		    pVertC->adCoords(), pVertD->adCoords()));
}

//@@ 3D orientation predicate, with adaptive precision arithmetic
int iOrient3D(const double adA[3], const double adB[3],
	      const double adC[3], const double adD[3]) 
     // Computes the orientation of four verts in 3D, using as nearly
     // exact arithmetic as required.
{
  double dXa = adA[0];
  double dYa = adA[1];
  double dZa = adA[2];
  
  double dXb = adB[0];
  double dYb = adB[1];
  double dZb = adB[2];
  
  double dXc = adC[0];
  double dYc = adC[1];
  double dZc = adC[2];
  
  double dXd = adD[0];
  double dYd = adD[1];
  double dZd = adD[2];
  
  double dMaxX, dMinX, dMaxY, dMinY, dMaxZ, dMinZ;
  
  double dDX2 = dXb - dXa;
  double dDX3 = dXc - dXa;
  double dDX4 = dXd - dXa;
  MINMAX4(dXa, dXb, dXc, dXd, dMinX, dMaxX);
  
  double dDY2 = dYb - dYa;
  double dDY3 = dYc - dYa;
  double dDY4 = dYd - dYa;
  MINMAX4(dYa, dYb, dYc, dYd, dMinY, dMaxY);
  
  double dDZ2 = dZb - dZa;
  double dDZ3 = dZc - dZa;
  double dDZ4 = dZd - dZa;
  MINMAX4(dZa, dZb, dZc, dZd, dMinZ, dMaxZ);
  double dMax = max( max(dMaxX-dMinX, dMaxY-dMinY), dMaxZ-dMinZ);
  
  // dDet is proportional to the cell volume
  double dDet = (dDX2*(dDY3*dDZ4 - dDY4*dDZ3) +
		 dDX3*(dDY4*dDZ2 - dDY2*dDZ4) +
		 dDX4*(dDY2*dDZ3 - dDY3*dDZ2));
  
  //   // Compute a length scale based on edge lengths.
  //   double dScale = ( dDIST3D(adA, adB) + dDIST3D(adA, adC) +
  // 		    dDIST3D(adA, adD) + dDIST3D(adB, adC) +
  // 		    dDIST3D(adB, adD) + dDIST3D(adC, adD) ) / 6.;
  
  //   dDet /= (dScale*dScale*dScale);
  
  //   double dError = 1.e-13;
  
  // Compute an upper bound on the error bound.
  
  const double dMachEps = 2.22044605e-13; // about 2^-52 * 1000;
  
  double dError = dMachEps * dMax*dMax*dMax;
  
  if (dDet > dError)
    return (1);
  else if (dDet < -dError) 
    return (-1);
  else 
    return(0);
}



//@ End of file
