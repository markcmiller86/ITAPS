// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include "RI_misc.h"
#include "RI_Vertex.h"
#include "RI_Face.h"
#include "RI_Cell.h"

#define dDIST2D(a, b) sqrt((a[0]-b[0])*(a[0]-b[0]) + (a[1]-b[1])*(a[1]-b[1]))

//@ 2D orientation test
static int
iOrient2D (const double adA[2], const double adB[2],
	   const double adC[2])
{
  double xa = adA[0];
  double ya = adA[1];
  
  double xb = adB[0];
  double yb = adB[1];
  
  double xc = adC[0];
  double yc = adC[1];
  
  // Currently no exact arithmetic
  double dDet = ((xb - xa) * (yc - ya) - (xc - xa) * (yb - ya));
  // Scale the determinant by the mean of the magnitudes of vectors:
  double dScale = (dDIST2D (adA, adB) + dDIST2D (adB, adC)
		   + dDIST2D (adC, adA)) / 3;
  dDet /= (dScale * dScale);
  if (dDet > 1.e-10)
    return 1;
  else if (dDet < -1.e-10)
    return -1;
  else
    return 0;
}

int
iOrient2D (const Vert * const pVertA, const Vert * const pVertB,
	   const Vert * const pVertC)
  // Computes the orientation of three verts in 2D
{
  assert (pVertA->qValid ());
  assert (pVertB->qValid ());
  assert (pVertC->qValid ());
  assert (pVertA->iSpaceDimen () == 2);
  assert (pVertB->iSpaceDimen () == 2);
  assert (pVertC->iSpaceDimen () == 2);
  return iOrient2D (pVertA->adCoords (), pVertB->adCoords (),
		    pVertC->adCoords ());
}

