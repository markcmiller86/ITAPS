// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <stdlib.h>

#include "RI_Mesh.h"

// Generally speaking, the functions in this file are generic topology
// change functions that are members of Face, Cell, etc.  These
// functions are intended only to be called by Mesh member functions
// that are changing topology in ways that only valid entities can ever
// exist (although topology may be incomplete at times).

void Face::vAssign(Cell* const pCA, Cell* const pCB,
		   Vert* const pV0, Vert* const pV1,
		   Vert* const pV2, Vert* const pV3)
{
  assert(qValid());
  pCL = pCA;
  pCR = pCB;
  vSetVerts(pV0, pV1, pV2, pV3);
}

/// This topology change function is only used in createFace (both in 2D
/// and 3D) and in vAssign.
void Face::vSetVerts(Vert* const pV0, Vert* const pV1,
		     Vert* const pV2, Vert* const pV3)
{
  assert(qValid());
  // Fallthrough is deliberate
  switch (iNumVerts()) {
  case 4:
    assert(pV3->qValid());
    apVVerts[3] = pV3;
    pV3->vAddFace(this);
  case 3:
    assert(pV2->qValid());
    apVVerts[2] = pV2;
    pV2->vAddFace(this);
  case 2:
    assert(pV1->qValid());
    apVVerts[1] = pV1;
    pV1->vAddFace(this);
  case 1:
    assert(pV0->qValid());
    apVVerts[0] = pV0;
    pV0->vAddFace(this);
    break;
  default:
    assert(0); // Bad number of verts
  }
}

