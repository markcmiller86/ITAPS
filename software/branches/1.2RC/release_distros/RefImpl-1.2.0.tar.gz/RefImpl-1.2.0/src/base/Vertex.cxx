// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include <stdlib.h>
#include "RI_Vertex.h"
#include "RI_Mesh.h"

#if (defined(SOLARIS2) && !defined(NDEBUG))
// Solaris puts the definition of finite() in an odd place.  Need this
// only in some assertions, so don't include the file when assertions
// are null.
#include <ieeefp.h>
#endif

void Vert::vAddFace(Face * const pF) {
  assert(pF->qHasVert(this));
#ifdef USE_VECTOR
  pvecpFInc.push_back(pF);
#else
  pFL->vAddFace(pF);
#endif
}

Face* findCommonFace(const Vert * const pV0, const Vert * const pV1)
{
#ifdef USE_VECTOR
  std::vector<Face *>::const_iterator iter0 = pV0->vecpFInc.begin(),
    iter0_end = pV0->vecpFInc.end(),
    iter1, iter1_end = pV1->vecpFInc.end();

  for (; iter0 != iter0_end; iter0++) {
    for (iter1 = pV1->vecpFInc.begin(); iter1 != iter1_end; iter1++) {
      if (*iter0 == *iter1) return (*iter0);
    }
  }
  return pFInvalidFace;
#else
  int iMax0 = pV0->pFL->size();

  for (int i0 = 0; i0 < iMax0; i0++) {
    Face *pF0 = pV0->pFL->pFGetFace(i0);
    if (!pF0->qDeleted() && pF0->qHasVert(pV1)) {
      return pF0;
    }
  }
  return pFInvalidFace;
#endif
}

Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
		     const Vert * const pV2, const Vert * const pV3)
{
  assert(pV0->qValid());
  assert(pV1->qValid());
  assert(pV2->qValid());
#ifdef USE_VECTOR
  std::vector<Face *>::const_iterator iterA = pV0->vecpFInc.begin(),
    iterA_end = pV0->vecpFInc.end(),
    iterB, iterB_end = pV1->vecpFInc.end();
  Face *apFCom01[pV0->vecpFInc.size()];
  int iComCount = 0;

  Face *result = pFInvalidFace;
  
  for (; iterA != iterA_end; iterA++) {
    for (iterB = pV1->vecpFInc.begin(); iterB != iterB_end; iterB++) {
      if (*iterA == *iterB) {
	apFCom01[iComCount++] = *iterA;
      }
    }
  }

  // Now check which of those faces are also common to pV2.
  Face **iterCom_end = apFCom01 + iComCount;
  iterB_end = pV2->vecpFInc.end();
  for (Face **iterCom = apFCom01;
       iterCom != iterCom_end && !result;
       iterCom++) {
    for (iterB = pV2->vecpFInc.begin();
	 iterB != iterB_end && !result;
	 iterB++) {
      if (*iterCom == *iterB) {
	result = (*iterCom);
      }
    }
  }
#else
  int iMax0 = pV0->pFL->size();
  Face *result = pFInvalidFace;
  
  for (int i0 = 0; i0 < iMax0; i0++) {
    Face *pFCand = pV0->pFL->pFGetFace(i0);
    assert(pFCand != pFInvalidFace);
    if (!pFCand->qDeleted() &&
	pFCand->qHasVert(pV1) &&
	pFCand->qHasVert(pV2)) {
      result = pFCand;
    }
  }
#endif

  if (pV3->qValid() && result->qValid()) {
    bool qOK = pV3->qHasFace(result);
    if (!qOK) {
      // Trying to create a quad, but hit a snag...
      switch (result->eType()) {
      case Face::eTriFace:
	vMessage(0, "Error in %s:\n%s\n",
		 "findCommonFace",
		 "Tried to identify a quad, but three verts form a tri.");
	result = pFInvalidFace;
	break;
      case Face::eQuadFace:
	vMessage(0, "Error in %s:\n%s\n",
		 "findCommonFace",
		 "Tried to identify a quad, but another exists with three of these verts.");
	assert(0);
	result = pFInvalidFace;
	break;
      case Face::eEdgeFace:
	assert(0);
	result = pFInvalidFace;
	// Should never be able to ID an edge w/ three verts in common.
	break;
      }
    }
  } // Done confirming face identity
  return result;
}

void Vert::vSetDefaultFlags()
{
  uiDim = 0;
  qDel = false;
}

void Vert::vResetAllData()
{
  vSetDefaultFlags();
#ifdef USE_VECTOR
  vecpFInc.clear();
#else
  if (pFL) delete pFL;
  pFL = new FaceList();
#endif
  adLoc[0] = adLoc[1] = adLoc[2] = 0;
}  

void Vert::vCopyAllFlags(const Vert &V)
{
  uiDim = V.uiDim;
  qDel = V.qDel;
}

void Vert::vSetCoords(const int iNumDim, const double adNewLoc[])
{
  assert(iNumDim == 2 || iNumDim == 3);
  if (iSpaceDimen() == 0) vSetDimen(iNumDim);
  // The following assertion is false for ITAPS setting 2D coords...
#ifndef ITAPS
  assert(iNumDim == iSpaceDimen());
#endif
  switch(iNumDim) {
  case 3:
    assert(finite(adNewLoc[2]));
    adLoc[2] = adNewLoc[2];
    // Deliberate fallthrough
  case 2:
    assert(finite(adNewLoc[1]));
    assert(finite(adNewLoc[0]));
    adLoc[1] = adNewLoc[1];
    adLoc[0] = adNewLoc[0];
    break;
  default:
    assert(0);
  }
}

