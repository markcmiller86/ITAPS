// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Vertex
#define RI_Vertex 1

#include <vector>

#include "RI_config.h"
#include "RI_Entity.h"
#include "iMesh.h"

#ifndef USE_VECTOR
/**\brief A class for storing faces adjacent to a given vertex.
 *
 * The class stores an arbitrary number of faces in a linked list, with
 * each link storing the same number of faces.  The faces aren't stored
 * in any special order.
 */
class FaceList {
  /// The number of faces that can be stored in each link.
  static const int block_size = 10;

  /// The number of faces actually stored in this link.
  int iNUsed;

  /// Storage for the faces.
  Face *apF[block_size];

  /// The next link in the chain.
  FaceList *pFL;
 public:
  /// Constructor.
  FaceList() : iNUsed(0), pFL(NULL) {}

  /// Destructor.
  ~FaceList() {
    if (pFL) {
      delete pFL;
      pFL = NULL;
    }
  }

  /// Add a face to the connectivity for this vert.
  void vAddFace(Face * const pF) {
    assert(iNUsed <= block_size);
    if (iNUsed == block_size) {
      if (!pFL) {
	pFL = new FaceList();
      }
      pFL->vAddFace(pF);
    }
    else {
      apF[iNUsed++] = pF;
    }
  }

  /// Remove a face from the connectivity for this vert.
  void vRemoveFace(Face * const pF) {
    int i;
    FaceList *pFLCand = this;
    FaceList *pFLLast = this;
    FaceList *pFLPrev = NULL;
    assert(iNUsed > 0);
    do {
      for (i = 0; i < iNUsed; i++) {
	if (pFLCand->apF[i] == pF) {
	  // Get the last face...
	  while (pFLLast->pFL) {
	    pFLPrev = pFLLast;
	    pFLLast = pFLLast->pFL;
	  }
	  assert(pFLLast);
	  // Put it here instead
	  pFLCand->apF[i] = pFLLast->apF[pFLLast->iNUsed - 1];
	  // And drop the last one
	  pFLLast->iNUsed --;
	  assert(pFLLast->iNUsed >= 0);
	  if (pFLLast->iNUsed == 0 && !(pFLLast == this)) {
	    assert(pFLPrev);
	    pFLLast->~FaceList();
	    pFLPrev->pFL = NULL;
	  }
	  return;
	}
      }
      // If you got here, this block doesn't have it.
      pFLPrev = pFLCand;
      pFLCand = pFLCand->pFL;
    } while (pFLCand);
    assert(0);
  }

  /// Get a face by index; may require traversal to the next link.
  Face* pFGetFace(const int i) const {
    if (i >= block_size)
      return pFL->pFGetFace(i - block_size);
    else {
      if (i >= iNUsed) return pFInvalidFace;
      else             return apF[i];
    }
  }

  /// Does the linked list contain this face?
  bool qHasFace(const Face* const pF) const {
    int i;
    for (i = 0; i < iNUsed; i++) {
      if (apF[i] == pF) {
	return true;
      }
    }
    // If you got here, this block doesn't have it.
    if (pFL) return pFL->qHasFace(pF);
    else return false;
  }

  /// Clear the whole linked list.
  void clear() {
    if (pFL) pFL->~FaceList();
    pFL = NULL;
    iNUsed = 0;
  }

  /// Total size of the linked list
  int size() {
    if (pFL) {
      assert(iNUsed == block_size);
      return block_size + pFL->size();
    }
    else return iNUsed;
  } 

  /// Copy the linked list; required for Vert::op=
  FaceList& operator=(const FaceList& FL) {
    if (this != &FL) {
      iNUsed = FL.iNUsed;
      for (int ii = 0; ii < block_size; ii++) {
	apF[ii] = FL.apF[ii];
      }
      if (pFL != NULL) {
	delete pFL;
	pFL = NULL;
      }
      if (FL.pFL != NULL) {
	pFL = new FaceList;
	(*pFL) = *(FL.pFL);
      }
    }
    return *this;
  }
};
#endif

/** Stores vertex data; like Face and Cell, derived from Entity.
 *
 * Functions declared in Entity aren't re-documented here.
 */
class Vert : public Entity {
  /// Vertex coordinates.
  double adLoc[3];

#ifdef USE_VECTOR
  /// New-style upward adjacency: all faces, implemented as a std::vector.
  std::vector<Face*> vecpFInc;
#else
  /// New-style upward adjacency: all faces, implemented as a linked list.
  FaceList *pFL;
#endif
  /// Space dimension of the vertex coords; either 2 or 3, currently.
  unsigned int uiDim:2;

  /// Has the vert been deleted?
  bool qDel:1;
  
  /// Copy constructor disallowed.
  Vert(const Vert&) : Entity() { assert(0); }
    
 public:
  /**\brief Retrieved adjacent faces by index.
   *
   * Warning: This function isn't stable, in the sense that a later call
   * (after mesh modification) with the same arg may give a different
   * answer, even if the face originally returned is still adjacent to
   * the vert.
   */
  Face *pFFace(const int i) {return Entity::pFFace(i);}
  const Face *pFFace(const int i) const {
#ifdef USE_VECTOR
    return vecpFInc[i];
#else
    return(pFL->pFGetFace(i));
#endif
  }
private:
  // Inherited from Entity, but not currently used.
  Cell *pCCell(const int) {assert(0); return pCInvalidCell;}
  const Cell *pCCell(const int) const {assert(0); return pCInvalidCell;}
public:
  /// Default constructor.
  Vert() :
#ifdef USE_VECTOR
      vecpFInc()
#else
      pFL(NULL)
#endif
    // Others set by SetDefaultFlags
    {
#ifdef USE_VECTOR
      vecpFInc.reserve(8);
#else
      pFL = new FaceList();
#endif
      vSetDefaultFlags();
      adLoc[0] = adLoc[1] = adLoc[2] = 0.;
    }
  /// Destructor.
    ~Vert() {if (pFL) delete pFL;}
  /**\brief Assignment operator.
   *
   * Copies the upward adjacency data, but this will not be valid, in
   * the sense of face-vert connectivity being reciprocal with this,
   * unless the faces are updated, too.  This is true for all three
   * possible ways to represent the upward adjacency.
   */
  Vert& operator=(const Vert& V) {
    if (this != &V) {
      adLoc[0] = V.adLoc[0];
      adLoc[1] = V.adLoc[1];
      adLoc[2] = V.adLoc[2];
#ifdef USE_VECTOR
      vecpFInc = V.vecpFInc; 
#else
      (*pFL) = *(V.pFL);
#endif
      vCopyAllFlags(V);
    }
    return (*this);
  }

  /// Ensure a sane initial state for face data
  void vResetAllData();

  // Inherited from Entity.
  const Vert *pVVert(const int iV) const {
    assert(iV == 0);
    return this;
  }
  Vert *pVVert(const int iV) {
    assert(iV == 0);
    return this;
  }
  void vAllVertHandles(RefImpl_Entity* []) const {assert(0);}
  void vAllCellHandles(RefImpl_Entity* []) const {assert(0);}
  void vAllFaceHandles(RefImpl_Entity* []) const {assert(0);}
  int iNumVerts() const {return 0;}
  int iNumFaces() const {
#ifdef USE_VECTOR
    return(vecpFInc.size());
#else
    return pFL->size();
#endif
  }
  int iNumCells() const {assert(0); return(0);}
  int eEntType() const {return iBase_VERTEX;}
  int eEntTopology() const {return iMesh_POINT;}

  /// Add a face to full upward adjacency.
  void vAddFace(Face * const pF);

  /// Remove a face from full upward adjacency.
  void vRemoveFace(Face * const pF)
  {
#ifdef USE_VECTOR
    std::vector<Face*>::iterator iter, iter_end = vecpFInc.end();
    for (iter = vecpFInc.begin(); iter != iter_end; iter++) {
      if ((*iter) == pF) {
	vecpFInc.erase(iter);
	break;
      }
    }
#else
    pFL->vRemoveFace(pF);
#endif
  }

  /// Clear all data in full upward adjacency.
  void vClearFaceConnectivity() {
#ifdef USE_VECTOR
    vecpFInc.clear();
#else
    pFL->clear();
#endif
  }

  /// Is the given face stored as part of full upward adjacency?
  bool qHasFace(const Face * const pF) const
  {
#ifdef USE_VECTOR
    std::vector<Face*>::const_iterator iter, iter_end = vecpFInc.end();
    for (iter = vecpFInc.begin(); iter != iter_end; iter++) {
      if ((*iter) == pF) {
	return true;
      }
    }
    return false;
#else
    return pFL->qHasFace(pF);
#endif
  }

  /// Set internal state to default.
  void vSetDefaultFlags();

  /// Copy internal state.
  void vCopyAllFlags(const Vert &V);

  /// Return spatial dimension of the vertex
  int iSpaceDimen() const {return (uiDim);}

  /// Set spatial dimension; requires that it isn't already set.
  void vSetDimen(const int iSD) {
    assert(uiDim == 0);
    assert(iSD == 2 || iSD == 3);
    uiDim = iSD;
  }

  /// Mark this vertex as deleted.
  void vMarkDeleted() { qDel = true; }

  /// Is this vertex deleted?
  bool qDeleted() const { return (qDel); }

  /// Set vertex coordinates from given data.
  void vSetCoords(const int iNumDim, const double adNewLoc[]);

  /// Retrieve a pointer to vertex coords; the result can't be modified.
  const double* adCoords() const { assert(qValid()); return adLoc; }

  /// Return an edge common to two verts, or NULL if there is none.
  friend Face* findCommonFace(const Vert * const pV0, const Vert * const pV1);

  /// Return a tri or quad face common to three or four verts, or NULL.
  friend Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
			      const Vert * const pV2,
			      const Vert * const pV3 = NULL);
};

/// Return true iff the three verts (in 2D) form a right-handed triangle.
int iOrient2D(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC);

/// Return true iff the four verts (in 3D) form a right-handed tetrahedron.
int iOrient3D(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC, const Vert* const pVD);

/// Return true iff the four sets of coords form a right-handed tetrahedron.
int iOrient3D(const double adA[3], const double adB[3],
	      const double adC[3], const double adD[3]);

#endif
