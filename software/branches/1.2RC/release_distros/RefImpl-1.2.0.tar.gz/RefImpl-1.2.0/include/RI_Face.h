// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Face
#define RI_Face 1

#include "RI_config.h"
#include "RI_Entity.h"
#include "RI_Cell.h"
#include "RI_Vertex.h"

/// Categories of triangular faces for face swapping purposes.
/** Categories into which tetrahedral faces are placed for purposes of
 * swapping.  T indicates that the face is transformable, N indicates
 * non-transformable.  For "T" faces, the digits are the number of tets
 * before and after the transformation.  For "N" faces, the digits are
 * the number of tets that would be present for a transformable case.
 * A zero as the second digit indicates that the case is irrevocably
 * unswappable.  The N32 and N44 cases are candidates for edge
 * swapping.
 */
enum eFaceCat {eT23 = 0, eT32 = 1, eT22 = 2, eT44 = 3, eN32 = 4,
	       eN44 = 5, eN40 = 6, eN30 = 7, eN20 = 8, eBdry = 9,
	       eBdryReflex = 10, eOther = 11};

/**\brief Class for second-highest-dimensional entities in the mesh.
 *
 * The reference implementation has finite-volume roots, so it refers to
 * entities that separate cells (highest-dim entities) as faces.
 * These correspond to iMesh faces for 3D meshes and iMesh edges for 2D
 * meshes.
 *
 * Functions inherited from the Entity base class are not documented
 * again in Face or its derivatives.
 */

class Face : public Entity {
protected:
  /// Copy construction disallowed.
  Face(const Face&) : Entity() {assert(0);}
  /**\brief Cell on the left side of the face.
   *
   * Faces are oriented.  The left cell is the one that the left-hand
   * rule would point to.  Alternatively, it's the one towards your feet
   * if you walked around the face with the face to your left (CCW).
   */
  Cell* pCL;
  /**\brief Cell on the right side of the face.
   *
   * Faces are oriented.  The right cell is the one that the right-hand
   * rule would point to.  Alternatively, it's the one towards your head
   * if you walked around the face with the face to your left (CCW).
   */
  Cell* pCR;
  /// Array to hold the verts of the face (possibly oversized).
  Vert* apVVerts[4];
  /// Constructor usable when you already have full knowledge of connectivity.
  Face(Cell* const pCA, Cell* const pCB, const int iNV,
       Vert* const pV0 = pVInvalidVert,
       Vert* const pV1 = pVInvalidVert,
       Vert* const pV2 = pVInvalidVert,
       Vert* const pV3 = pVInvalidVert);
public:
  /// Enumeration of possible face types.
  enum eFaceType {eEdgeFace, eTriFace, eQuadFace};
protected:
  /// Has the face been deleted?
  bool qDel:1;
public:
  /// Destructor; doesn't need to do anything.
  virtual ~Face() {}

  /// Operator=; use with caution, as pointers must be updated properly.
  Face& operator=(const Face& F);

  /// Ensure a sane initial state for face data
  void vResetAllData();

  /// Return the type of the face
  virtual eFaceType eType() const = 0; 

  /// Set internal state variables to sane values
  void vSetDefaultFlags();

  /// Copy internal state variables from another face
  void vCopyAllFlags(const Face &F);

  /// Return deletion status of the face
  bool qDeleted() const {return qDel;}
  
  // Inherited from Entity
  virtual int iNumVerts() const = 0;
  void vMarkDeleted() {qDel = true;}

  /// A complete validity check, including adjacency data.
  virtual int iFullCheck() const;

  /// True iff this face has the given vert as part of its closure.
  bool qHasVert(const Vert* const pV) const;

  /// True iff this face has the given cell as one of its neighbors.
  virtual bool qHasCell(const Cell* const pC) const
    {return (pC == pCL || pC == pCR);}

  /// Return left cell
  Cell* pCCellLeft () const {assert(qValid()); return pCL;}

  /// Return right cell
  Cell* pCCellRight() const {assert(qValid()); return pCR;}

  /// Return cell opposite the one given.
  virtual Cell* pCCellOpposite(const Cell* const pC) const {
    assert(qValid());
    assert(pCL == pC || pCR == pC ||
	   (pCL == pCInvalidCell && pCR == pCInvalidCell));
    return ((pCL == pC) ? pCR : pCL);
  }

  // Inherited from Entity
  virtual int iNumCells() const {
    int iN = 0;
    if (pCL->qValid()) iN++;
    if (pCR->qValid()) iN++;
    return iN;
  }
  int iNumFaces() const {return 0;}
  const Vert* pVVert(const int i) const {
    assert(qValid());
    assert(i>=0 && i<iNumVerts());
    return apVVerts[i];
  }
  Vert* pVVert(const int i) {
    assert(qValid());
    assert(i>=0 && i<iNumVerts());
    return apVVerts[i];
  }
  const Face *pFFace(const int i) const {
    assert(i == 0);
    return this;
  }
  Face *pFFace(const int i) {
    assert(i == 0);
    return this;
  }

  const Cell *pCCell(const int i) const {
    assert(i == 0 || i == 1);
    if (i == 0) {
      if (pCL->qValid()) {
	return (pCL);
      }
      else { // pCL is invalid
	return (pCR);
      }
    }
    else {
      if (pCL->qValid() && pCR->qValid()) {
	return (pCR);
      }
      else return pCInvalidCell; // If one cell's invalid, then the
				 // valid one is returned for i=0, so
				 // return garbage here.
    }
    // Can never get here.
    assert(0);
    return pCInvalidCell;
  }
  Cell *pCCell(const int i) {return Entity::pCCell(i);}

  void vAllFaceHandles(RefImpl_Entity* /*aHandle*/[]) const {}
  void vAllCellHandles(RefImpl_Entity* aHandle[]) const;

  /// Add this cell as a neighbor; there must be exactly one empty slot.
  virtual void vAddCell(Cell* const pCNew);

  /// Remove this cell as a neighbor.
  virtual void vRemoveCell(const Cell* const pCOld);

  /// Replace old cell with a new one.
  virtual void vReplaceCell(const Cell* const pCOld, Cell* const pCNew);

  /// Assign all connectivity data.
  void vAssign(Cell* const pCA, Cell* const pCB,
	       Vert* const pV0 = pVInvalidVert,
	       Vert* const pV1 = pVInvalidVert,
	       Vert* const pV2 = pVInvalidVert,
	       Vert* const pV3 = pVInvalidVert);

  /**\brief Change right cell connectivity data.
   *
   * No checks are done, so caveat programmer. This function should be
   * called only from functions defined in MeshMod2D.cxx or
   * MeshMod3D.cxx.
   */
  void vSetRightCell(Cell* const pC) {pCR = pC;}

  /**\brief Change left cell connectivity data.
   *
   * No checks are done, so caveat programmer. This function should be
   * called only from functions defined in MeshMod2D.cxx or
   * MeshMod3D.cxx.
   */
  void vSetLeftCell (Cell* const pC) {pCL = pC;}

  /// Set all vertex connectivity data.
  void vSetVerts(Vert* const pV0,
		 Vert* const pV1,
		 Vert* const pV2 = pVInvalidVert,
		 Vert* const pV3 = pVInvalidVert);
};

/// A specialization of Face to represent quadrilateral faces in 3D meshes.
class QuadFace : public Face {
  /// Copy construction disallowed.
  QuadFace(const QuadFace& QF) : Face(QF) {assert(0);}
public:
  /// Default (and only) constructor for QuadFaces.
  QuadFace(Cell* const pCA = pCInvalidCell,
	   Cell* const pCB = pCInvalidCell,
	   Vert* const pV0 = pVInvalidVert,
	   Vert* const pV1 = pVInvalidVert,
	   Vert* const pV2 = pVInvalidVert,
	   Vert* const pV3 = pVInvalidVert)
    : Face(pCA, pCB, 4, pV0, pV1, pV2, pV3) {}
  // Inherited from Face
  int iFullCheck() const;
  eFaceType eType() const {return eQuadFace;} 
  // Inherited from Entity
  int iNumVerts() const {return 4;}
  int eEntType() const {return iBase_FACE;}
  int eEntTopology() const {return iMesh_QUADRILATERAL;}

  void vAllVertHandles(RefImpl_Entity* aHandle[]) const {
    aHandle[0] = static_cast<Entity* const>(apVVerts[0]);
    aHandle[1] = apVVerts[1];
    aHandle[2] = apVVerts[2];
    aHandle[3] = apVVerts[3];
  }
};

/// A specialization of Face to represent triangular faces in 3D meshes.
class TriFace : public Face {

  /// Copy construction disallowed.
  TriFace(const TriFace& TF) : Face(TF) {assert(0);}
public:
  /// Constructor for TriFaces
  TriFace(Cell* const pCA = pCInvalidCell,
	  Cell* const pCB = pCInvalidCell,
	  Vert* const pV0 = pVInvalidVert,
	  Vert* const pV1 = pVInvalidVert,
	  Vert* const pV2 = pVInvalidVert)
    : Face(pCA, pCB, 3, pV0, pV1, pV2) {}
  // Inherited from Face
  int iFullCheck() const;
  eFaceType eType() const {return eTriFace;} 
  // Inherited from Entity
  int iNumVerts() const {return 3;}
  int eEntType() const {return iBase_FACE;}
  int eEntTopology() const {return iMesh_TRIANGLE;}

  void vAllVertHandles(RefImpl_Entity* aHandle[]) const {
    aHandle[0] = apVVerts[0];
    aHandle[1] = apVVerts[1];
    aHandle[2] = apVVerts[2];
  }

  /**\brief Check face orientation.
   *
   * If the verts stored by the face are in the same orientation as the
   * three passed in as args, return true.  Otherwise false.  Used in
   * getting tri-tet connectivity and orientation right.
   */
  bool qRightHanded(const Vert * const pV0, const Vert * const pV1,
		    const Vert * const pV2) {
    if (pV0 == apVVerts[0]) {
      assert((pV1 == apVVerts[1] && pV2 == apVVerts[2]) ||
	     (pV2 == apVVerts[1] && pV1 == apVVerts[2]));
      return (pV1 == apVVerts[1] && pV2 == apVVerts[2]);
    }
    else if (pV0 == apVVerts[1]) {
      assert((pV1 == apVVerts[2] && pV2 == apVVerts[0]) ||
	     (pV2 == apVVerts[2] && pV1 == apVVerts[0]));
      return (pV1 == apVVerts[2] && pV2 == apVVerts[0]);
    }
    else {
      assert(pV0 == apVVerts[2]);
      assert((pV1 == apVVerts[0] && pV2 == apVVerts[1]) ||
	     (pV2 == apVVerts[0] && pV1 == apVVerts[1]));
      return (pV1 == apVVerts[0] && pV2 == apVVerts[1]);
    }
  }
};

/// A specialization of Face to represent edge faces in 2D meshes.
class EdgeFace : public Face {
protected:
  /// Copy construction disallowed.
  EdgeFace(const EdgeFace& EF) : Face(EF) {assert(0);}
public:
  /// Constructor for EdgeFaces
  EdgeFace(Cell* const pCA = pCInvalidCell,
	   Cell* const pCB = pCInvalidCell,
	   Vert* const pV0 = pVInvalidVert,
	   Vert* const pV1 = pVInvalidVert)
    : Face(pCA, pCB, 2, pV0, pV1) {}
  // Inherited from Face
  int iFullCheck() const
  {
    if (!Face::iFullCheck()) return 0;
    
    if (pCR->qValid() && pCL->qValid()) {
      if ( (pCR->eType() != Cell::eTriCell &&
	    pCR->eType() != Cell::eQuadCell)
	   ||
	   (pCL->eType() != Cell::eTriCell &&
	    pCL->eType() != Cell::eQuadCell)
	   ) {
	printf("Type:   %d %d\n", pCL->eType(),   pCR->eType());
	return 0;
      }
    }
    return 1;
  };
  eFaceType eType() const {return eEdgeFace;} 

  // Inherited from Entity
  int iNumVerts() const {return 2;}
  int eEntType() const {return iBase_EDGE;}
  int eEntTopology() const {return iMesh_LINE_SEGMENT;}
  void vAllVertHandles(RefImpl_Entity* aHandle[]) const {
    aHandle[0] = apVVerts[0];
    aHandle[1] = apVVerts[1];
  }
};

/// If the two faces share a cell, return it; otherwise return NULL.
Cell* pCCommonCell(const Face* const pF0, const Face* const pF1);

/// If the two faces share a vert, return it; otherwise return NULL.
Vert* pVCommonVert(const Face* const pF0, const Face* const pF1);

/// If the three faces share a vert, return it; otherwise return NULL.
Vert* pVCommonVert(const Face* const pF0, const Face* const pF1,
		   const Face* const pF2);

#endif
