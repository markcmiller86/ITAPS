#ifndef GR_LENGTH3D_H
#define GR_LENGTH3D_H

#include "GR_config.h"

#include <queue>
#include <set>
#include <utility>

class BFace;
class Cell;
class Vert;
class Subseg;
class SubsegMap;
class VolMesh;

class Length3D {

  double m_refine, m_grade, m_min_length;
  
  std::queue<Vert*> m_length_check_queue;

  //Pointer to the subsegment map created and maintained in the TetMeshRefiner
  //object used to refine the tetrahedral mesh.
  const SubsegMap* m_subseg_map;

  //Defining a vertex pair type.
  typedef std::pair<Vert*, Vert*> VertexPair;

  //Struct that cleans up queries to Mesh::vNeighborhood.
  struct Neighborhood {
    Vert* my_vert;
    std::set<Vert*>  verts;
    std::set<Cell*>  cells;
    std::set<BFace*> bfaces;
    Neighborhood() : my_vert(NULL), verts(), cells(), bfaces() {}
    void clear() { my_vert = NULL, verts.clear(); cells.clear(); bfaces.clear(); }
  };

  //A neighborhood object declared here to save time on initilization.
  Neighborhood m_neigh;

#ifndef NDEBUG
  bool m_length_initialized;
#endif

  Length3D() 
    : m_refine(-LARGE_DBL), m_grade(-LARGE_DBL), m_min_length(LARGE_DBL), 
      m_length_check_queue(), m_subseg_map(NULL), m_neigh() { assert(0); }
  Length3D(const Length3D&) 
    : m_refine(-LARGE_DBL), m_grade(-LARGE_DBL), m_min_length(LARGE_DBL),
      m_length_check_queue(), m_subseg_map(NULL), m_neigh() { assert(0); }
  Length3D& operator=(const Length3D&) { assert(0); return *this; }

 public:

  Length3D(double refine, double grade, 
	   const SubsegMap* subseg_map = NULL, double min_length = LARGE_DBL) 
    : m_refine(refine), m_grade(grade), m_min_length(min_length),
      m_length_check_queue(), m_subseg_map(subseg_map), m_neigh() { 
    if( m_min_length <= 0. ) m_min_length = LARGE_DBL; 
#ifndef NDEBUG
    m_length_initialized = false;
#endif
  }
  
  virtual ~Length3D() { }

  //Shortest squared distance to a subseg (or to the curve it discretizes).
  static double sq_distance_to_subseg(const Vert* const vert0, const Subseg* const subseg);

  //Shortest squared distance to a bface (or to the surface it discretizes).
  static double sq_distance_to_bface(const Vert* const vert0, const BFace* const bface);

  //Initializes the length scale of all the vertices in mesh (only supports CDT's).
  //NOTE: All the vertices must lie on a boundary entity (apex, curve or surface).
  void init_length(const VolMesh* const mesh);

  //Setting vert0's length scale to a given value.
  void set_given_length_scale(Vert* const vert0, double length);

  //The following three calls are used to set the length scale during refinement phase.

  //Sets the length scale of a curve vertex.
  //subseg0 and subseg1 must be the two subsegments connected to vert0.
  void set_curv_vert_length(Vert* const vert0,
			    const Subseg* const subseg0, const Subseg* const subseg1);

  //Sets the length scale for a surface vertex.
  void set_surf_vert_length(Vert* const vert0);

  //Sets the length scale for an interior vertex.
  void set_volu_vert_length(Vert* const vert0);

  ///

  //Sets the refinement factor.
  void set_refine_factor(double refine) { m_refine = refine; }

  //Sets the grading factor.
  void set_grade_factor(double grade) { m_grade = grade; }

  //Sets the m_subseg_map pointer.
  void set_subseg_map(const SubsegMap* subseg_map) { m_subseg_map = subseg_map; }

  //Returns the m_subseg_map pointer.
  const SubsegMap* get_subseg_map() const { return m_subseg_map; }

  //Sets the minimum length (m_min_length) that all vertices will have to respect.
  void set_min_length(const double min_length) { assert(m_min_length > 0.); m_min_length = min_length; }

 private:

  //Initializes the length of a given vertex (called from this class only).
  void init_vert_length(Vert* const vert0);

  //Three phase to compute the initial length of a given vertex.
  //When and how these are called depend on the vertex type and
  //during what phase of Delaunay refinement we are.
  void comp_length_phase1(Vert* const vert0, double& min_dist);
  void comp_length_phase2(Vert* const vert0, double& min_dist,
			  Vert* const sub_vert1 = NULL, Vert* const sub_vert2 = NULL);
  void comp_length_phase3(Vert* const vert0, double& min_dist);

  //Sets the graded length of all verts in m_length_check_queue.
  void set_graded_length();

  //Computes the neighborhood of vertex and stores it in m_neigh.
  void get_neighborhood(Vert* const vertex);

  void get_ring_edges(Vert* const vert0, std::vector<VertexPair>& edges);

};

#endif


