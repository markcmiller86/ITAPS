#ifndef GR_FUNCTORS_H
#define GR_FUNCTORS_H

#include <functional>

namespace GRUMMP {

  //A template functor to delete objects in containers

  struct DeleteObject {
    template<typename T>
    void operator()(const T* ptr) const {
      if(ptr) delete ptr;
    }
  };

  //A simple hash for pointer addresses.

  struct PointerHash {
    template<typename T>
    size_t operator()(const T* ptr) const {
      return reinterpret_cast<size_t>(ptr);    
    }
  };

  //Instead of using the non-portable SGI implementation, here is my own.

  template<typename PairType>
    struct select1st : public std::unary_function<const PairType&, const typename PairType::first_type&> {
    const typename PairType::first_type& operator()(const PairType& p) const { return p.first; }
  };

  template<typename PairType>
    struct select2nd : public std::unary_function<const PairType&, const typename PairType::second_type&> {
    const typename PairType::second_type& operator()(const PairType& p) const { return p.second; }
  };

  //The extern_mem_fun is a member function adaptor that lets 
  //algorithms such as for_each and find_if process the elements 
  //in a container by invoking a method of a class and passing 
  //each element in the container as a parameter.

  template<typename ReturnType, typename ClassType, typename ArgType>
  class extern_mem_fun_t : public std::unary_function<ArgType, ReturnType> {
   private:
    ReturnType (ClassType::*m_func_ptr)(ArgType);
    ClassType* m_ptr_obj;
   public :
    extern_mem_fun_t(ReturnType (ClassType::*ptr)(ArgType), ClassType* obj) : m_func_ptr(ptr), m_ptr_obj(obj) { }
    ReturnType operator() (ArgType arg) { return( (m_ptr_obj->*m_func_ptr)(arg) ); }
  };

  template<typename ReturnType, typename ClassType, typename ArgType>
    extern_mem_fun_t<ReturnType,ClassType,ArgType>
    extern_mem_fun(ReturnType (ClassType::*ptr_mfunc)(ArgType), ClassType* type) 
    { return( extern_mem_fun_t<ReturnType, ClassType, ArgType>(ptr_mfunc, type) ); }

}

#endif 

