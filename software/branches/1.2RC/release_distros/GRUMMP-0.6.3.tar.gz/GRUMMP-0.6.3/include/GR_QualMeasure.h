#ifndef GR_QualMeasure_h

#include <values.h>
#include <string>

#include "GR_config.h"
#include "GR_Cell.h"
#include "GR_Util.h"

namespace GRUMMP {
  template<int dim>
  class QualMeasure {
  protected:
    /// String description of the quality measure.
    std::string m_name;
  public:
    QualMeasure(std::string name) : m_name(name) {}
    virtual ~QualMeasure() {}
      
    std::string getName() const {return m_name;}
      
  private:  
    double evalMin(const Vert* vert0, const Vert* vert1,
		   const Vert* vert2, const Vert* vert3 = NULL,
		   const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		   const Vert* vert6 = NULL, const Vert* vert7 = NULL) const
    {
      int n = maxNumValues();
      double *values = new double[n];
      int nValsReturned = 0;
      evalAll(nValsReturned, values,
	      vert0, vert1, vert2, vert3, vert4, vert5, vert6, vert7);
      double minVal = DBL_MAX;
      for (int i = 0; i < nValsReturned; i++)
	minVal = std::min(minVal, values[i]);
      delete [] values;
      return minVal;
    }
    double evalMax(const Vert* vert0, const Vert* vert1,
		   const Vert* vert2, const Vert* vert3 = NULL,
		   const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		   const Vert* vert6 = NULL, const Vert* vert7 = NULL) const
    {
      int n = maxNumValues();
      double *values = new double[n];
      int nValsReturned = 0;
      evalAll(nValsReturned, values,
	      vert0, vert1, vert2, vert3, vert4, vert5, vert6, vert7);
      double maxVal = DBL_MIN;
      for (int i = 0; i < nValsReturned; i++)
	maxVal = std::max(maxVal, values[i]);
      delete [] values;
      return maxVal;
    }
      
  protected:
    virtual bool shouldMinimize() const = 0;
      
  public:
    /// This is the value that optimizing code should compute, as
    /// maximizing this will maximize the min or minimize the max, as
    /// appropriate.
    ///
    /// Because this mode of use will often be focusing on scenarios where
    /// verts are known rather than cells, the function signature
    /// accomodates anything from tris to hexes. The callee has the
    /// responsibility to something reasonable with this.
    double eval(const Vert* vert0, const Vert* vert1,
		const Vert* vert2, const Vert* vert3 = NULL,
		const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		const Vert* vert6 = NULL, const Vert* vert7 = NULL) const {
      VALIDATE_INPUT(vert0->iSpaceDimen() == dim);
      if (shouldMinimize())
	return -evalMax(vert0, vert1, vert2, vert3, vert4, vert5, vert6, vert7);
      else
	return evalMin(vert0, vert1, vert2, vert3, vert4, vert5, vert6, vert7);
    }
      
    /// \brief Evaluate all values of the quality function for the cell.
    ///
    /// An alternate interface to support usage when verts are known
    /// rather than cells.
    ///
    /// Contrary to custom, the output variables are put first to
    /// accommodate a variable number of args.
    virtual void evalAll(int& nValues, double* values,
			 const Vert* vert0, const Vert* vert1,
			 const Vert* vert2, const Vert* vert3 = NULL,
			 const Vert* vert4 = NULL, const Vert* vert5 = NULL,
			 const Vert* vert6 = NULL, const Vert* vert7 = NULL)
      const = 0;
      
    /// \brief Evaluate all values of the quality function for the cell.
    ///
    /// In many cases, there's only one value (for instance, aspect ratio
    /// measures.  But in other cases (for instance, dihedral angles),
    /// there's more than one.  The caller is responsible for ensuring
    /// there's enough space in values for all the data.
    ///
    /// Contrary to custom, the output variables are put first for
    /// consistent ordering with the other evalAll call.
    virtual void evalAll(int& nValues, double* values,
			 const Cell* pCell) const = 0;

    /// \brief Return the number of separate values evalAll returns.
    virtual int maxNumValues() const = 0;
  };
    
  class DihedralAngles : public QualMeasure<3> {
  public:
    DihedralAngles() : QualMeasure<3>("dihedral angles") {}
    ~DihedralAngles() {}
  protected:
    virtual bool shouldMinimize() const {return true;}
  public:
    void evalAll(int& nValues, double* values,
		 const Cell* pCell) const;
    void evalAll(int& nValues, double* values,
		 const Vert* vert0, const Vert* vert1,
		 const Vert* vert2, const Vert* vert3 = NULL,
		 const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		 const Vert* vert6 = NULL, const Vert* vert7 = NULL) const;
    int maxNumValues() const {return 12;}
  };

  class SineDihedralAngles : public QualMeasure<3> {
  public:
    SineDihedralAngles() : QualMeasure<3>("sine of dihedral angles") {}
    ~SineDihedralAngles() {}
  protected:
    virtual bool shouldMinimize() const {return false;}
  public:
    void evalAll(int& nValues, double* values,
		 const Cell* pCell) const;
    void evalAll(int& nValues, double* values,
		 const Vert* vert0, const Vert* vert1,
		 const Vert* vert2, const Vert* vert3 = NULL,
		 const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		 const Vert* vert6 = NULL, const Vert* vert7 = NULL) const;
    int maxNumValues() const {return 12;}
  };

  class MinMaxAngle2D: public QualMeasure<2> {
  public:
    MinMaxAngle2D() : QualMeasure<2>("minmax angles (2D)") {}
    ~MinMaxAngle2D() {}
  protected:
    virtual bool shouldMinimize() const {return true;}
  public:
    void evalAll(int& nValues, double* values,
		 const Cell* pCell) const;
    void evalAll(int& nValues, double* values,
		 const Vert* vert0, const Vert* vert1,
		 const Vert* vert2, const Vert* vert3 = NULL,
		 const Vert* vert4 = NULL, const Vert* vert5 = NULL,
		 const Vert* vert6 = NULL, const Vert* vert7 = NULL) const;
    int maxNumValues() const {return 4;} // 4 for quads
  };

} // namespace GRUMMP

#endif
