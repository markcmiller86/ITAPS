#ifndef GR_SwapManager_h
#define GR_SwapManager_h

#include <set>

#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Mesh2D.h"
#include "GR_Observer.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

namespace GRUMMP {
  class EdgeSwapInfo;
  class FaceSwapInfo2D;
  class FaceSwapInfo3D;
  class SwapDecider2D;
  class SwapDecider3D;

  class SwapManager2D : public Observer {
    SwapDecider2D* m_pSD;
    Mesh2D* m_pM2D;
    GR_index_t m_attempts, m_successes;
    /// Default construction is a really, really bad idea.
    SwapManager2D();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SwapManager2D(SwapManager2D&);
    // Need to have a queue and ways to access it, but that can wait for
    // specializations --- OpenMP, MPI, etc --- and/or Observer giving
    // feedback about faces that should be looked at.
    //
    // The following set is the simple serial version.  For parallel
    // (either version) it isn't going to be adequate.
    std::set<Face*> faceQueue;
  public:
    /// Set the swap criterion and mesh at construction time.
    SwapManager2D(SwapDecider2D* pSD, Mesh2D* pMeshToSwap) :
      m_pSD(pSD), m_pM2D(pMeshToSwap), m_attempts(0), m_successes(0)
      {
	m_pM2D->addObserver(this,
			   Observable::cellCreated | Observable::faceDeleted);
      }
    ~SwapManager2D();

    // Observer function overrides
    void receiveDeletedFaces(std::vector<Face*>& deletedFaces);
    void receiveCreatedCells(std::vector<Cell*>& createdCells);
    void receiveMovedVerts(std::vector<Vert*>& movedVerts);

    // If a function is added to change swap criteria, that's fine, but
    // that function must be sure to add all (interior) faces to the
    // swap queue -before- it returns.
    int swapAllFaces();
    int swapAllQueuedFaces();
    int swapFace(FaceSwapInfo2D& FSI2D);
    bool reconfigure(FaceSwapInfo2D& FSI2D) const;
  };

  class SwapManager3D : public Observer {
    SwapDecider3D* m_pSD;
    VolMesh* m_pVM;
    // The following set is going to eventually need to be replaced, at
    // least for some situations, with a more general queue.  If nothing
    // else, the set won't work well for parallel.
    std::set<Face*> faceQueue;
    /// Keep track of the number of swaps attempted and succeeded.
    GR_index_t m_edgeAttempts[11], m_edgeSuccesses[11];
    GR_index_t m_faceAttempts[11], m_faceSuccesses[11];
    /// Default construction is a really, really bad idea.
    SwapManager3D() : m_pSD(NULL), m_pVM(NULL) {}
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SwapManager3D(SwapManager3D& SM) : m_pSD(SM.m_pSD) {assert(0);}
    // Need to have a queue and ways to access it, but that can wait for
    // specializations --- OpenMP, MPI, etc --- and/or Observer giving
    // feedback about faces that should be looked at.
  public:
    /// Set the swap criterion and mesh at construction time.
    SwapManager3D(SwapDecider3D* pSD, VolMesh* pMeshToSwap) :
      m_pSD(pSD), m_pVM(pMeshToSwap)
      {
	m_pVM->addObserver(this,
			   Observable::cellCreated | Observable::faceDeleted |
			   Observable::vertMoved);
	for (int i = 0; i < 11; i++) {
	  m_edgeAttempts[i] = 0;
	  m_edgeSuccesses[i] = 0;
	  m_faceAttempts[i] = 0;
	  m_faceSuccesses[i] = 0;
	}
      }
    ~SwapManager3D();

    // Observer function overrides
    void receiveDeletedFaces(std::vector<Face*>& deletedFaces);
    void receiveCreatedCells(std::vector<Cell*>& createdCells);
    void receiveMovedVerts(std::vector<Vert*>& movedVerts);

    // If a function is added to change swap criteria, that's fine, but
    // that function must be sure to add all (interior) faces to the
    // swap queue -before- it returns.
    int swapAllFaces();
    int swapAllQueuedFaces();
    int swapFace(Face* face);
    int swapFace(const FaceSwapInfo3D& FC);
    bool reconfigure(const FaceSwapInfo3D& FC);
    void reconfigureEdge(const EdgeSwapInfo& ES);
    void reconfigureBdryEdge(const EdgeSwapInfo& ES);
  private:
    // These are the functions that do the actual reconfiguration.
    bool reconfTet22(Cell* pTets[4],
		     Vert *const pVVertA, Vert* const pVVertB,
		     Vert *const pVVertC, Vert *const pVVertD,
		     Vert *const pVVertE, Vert *const pVVertF,
		     TriBFace *const pTBFA, TriBFace *const pTBFB);
    bool reconfTet23(Cell* pTets[4],
		     Vert *const pVVertA, Vert* const pVVertB,
		     Vert *const pVVertC, Vert *const pVVertD,
		     Vert *const pVVertE, Vert *const pVVertF);
    bool reconfTet32(Cell* pTets[4],
		     Vert *const pVVertA, Vert* const pVVertB,
		     Vert *const pVVertC, Vert *const pVVertD,
		     Vert *const pVVertE, Vert *const pVVertF);
    bool reconfTet44(Cell* pTets[4],
		     Vert *const pVVertA, Vert* const pVVertB,
		     Vert *const pVVertC, Vert *const pVVertD,
		     Vert *const pVVertE, Vert *const pVVertF);
  };

};

#endif
