#ifndef GR_SurfMesh
#define GR_SurfMesh 1

#include "GR_config.h"
#include "GR_Mesh2D.h"
#include "GR_EntContainer.h"

///
class SurfMesh : public Mesh2D {
  // MultiEdge's are needed to allow non-manifold surface meshes.
  EntContainer<MultiEdge> ECME;
  int iOnMultiEdge;
  /// surface geometry data
  Bdry3D *pB3D;
  /// Tie-in from cells in surface mesh to boundary patches.  This array
  // should be variable-sized, but I couldn't be bothered on the first
  // cut at this code.  (CFO-G, 11/2000)
  BdryPatch3D **apBPatch;
  GR_index_t iBPatchSize;
 private:
  /// This constructor might be helpful for volume meshing if we cared
  /// about the surface mesh afterwards; the volume initialization
  /// doesn't currently clean up the surface mesh if points are inserted
  /// in it.
  SurfMesh(const SurfMesh& ): Mesh2D() {assert(0);}
  /// Op= isn't needed either
  SurfMesh& operator=(const SurfMesh&) {assert(0); return *this;}

public:
  /// This is the default constructor
  SurfMesh(const int iQualMeas = 2) :
    Mesh2D(iQualMeas), ECME(), iOnMultiEdge(0),
    pB3D(NULL), apBPatch(NULL), iBPatchSize(0)
      { }
  ///
  SurfMesh(Bdry3D * const pB3D, const int iQualMeas = 2);
  ///
  SurfMesh(const char strBaseFileName[], const int iQualMeas = 2);
  ///
  SurfMesh(EntContainer<Vert>& EC, const int iQualMeas = 2) :
    Mesh2D(iQualMeas), ECME(), iOnMultiEdge(0),
    pB3D(NULL), apBPatch(NULL), iBPatchSize(0)
    { 
      // Don't pass the vertex list to the Mesh2D constructor, because
      // it will try to triangulate the point set as if it were 2D.
      for (GR_index_t i = 0; i < EC.lastEntry(); i++) {
	Vert *pVOld = EC.getEntry(i);
	Vert *pVNew = ECVerts.getNewEntry();
	pVNew->vSetCoords(3, pVOld->adCoords());
	pVNew->vCopyAllFlags(pVOld);
	// Don't copy vertex data any deeper than this.
      }

      apBPatch = new BdryPatch3D*[50];
      iBPatchSize = 50;
      // Can't set up faces and cells here, because there's not enough
      // info to do this correctly.
    }
  ///
  virtual ~SurfMesh()
    {
      if (apBPatch) {
	delete [] apBPatch;
	apBPatch = NULL;
      }
    }
  ///
  void vSetVertFaceNeighbors();
  Vert* createVert(const double adCoords[]);
  Vert* createVert(const double dX, const double dY, const double dZ);
  MultiEdge* createMultiEdge(Face* const pF);
  MultiEdge* createMultiEdge(Vert* const pV0, Vert* const pV1);
  virtual TriCell* createTriCell(Vert * const pV0, Vert * const pV1,
				 Vert * const pV2,
				 const int iReg = iDefaultRegion);
  TriCell* createTriCell(Face *& pF0, Face *& pF1,
			 Face *& pF2,
			 const int iReg = iDefaultRegion);
  virtual QuadCell* createQuadCell(Face * const /* pF0 */,
				   Face * const /* pF1 */,
				   Face * const /* pF2 */,
				   Face * const /* pF3 */,
				   const int /* iReg = iDefaultRegion */)
  { assert(0); return (static_cast<QuadCell*>(pCInvalidCell)); }
  virtual QuadCell* createQuadCell(Vert * const /* pV0 */,
				   Vert * const /* pV1 */,
				   Vert * const /* pV2 */,
				   Vert * const /* pV3 */,
				   const int /* iReg = iDefaultRegion */)
  { assert(0); return (static_cast<QuadCell*>(pCInvalidCell)); }

  virtual GR_index_t iNumFaces() const 
  {return ECEdgeF.lastEntry() + ECME.lastEntry();}
  virtual GR_index_t iFaceIndex(const Face* const pF) const;
  virtual Face* pFFace(const GR_index_t i) const;
  ///
  GR_index_t iNumEdgeFaces() const {return ECEdgeF.lastEntry();}
  GR_index_t iNumMultiEdges() const {return ECME.lastEntry();}
  ///
  MultiEdge* pMENewMultiEdge();
  ///
  MultiEdge* pMEMultiEdge(const GR_index_t i) const
    {
      assert(i < ECME.lastEntry());
      return ECME.getEntry(i);
    }
  ///
  void vConvertFromCellVert(EntContainer<TriCellCV>& ECTriCV);
  ///
  Bdry3D * pBoundaryData() const {return pB3D;}
  ///
  BdryPatch3D * pBdryPatch(const GR_index_t iCell) const
    {
      assert(iCell < iNumCells());
      return apBPatch[iCell];
    }
  BdryPatch3D * pBdryPatch(const Cell* const pC) const
    {
      GR_index_t iCell = iCellIndex(pC);
      return apBPatch[iCell];
    }
  void vSetBdryPatch(const GR_index_t iCell, BdryPatch3D* const pBP)
    {
      assert(pBP != NULL);
      if (iBPatchSize == 0) {
	assert(apBPatch == NULL);
	iBPatchSize = iNumCells() < 50 ? 50 : iNumCells();
	apBPatch = new BdryPatch3D*[iBPatchSize];
      }
      if (iCell >= iBPatchSize) {
	assert(iBPatchSize > 0);
	BdryPatch3D **apBPTemp = apBPatch;
        GR_index_t iNewSize = iBPatchSize*2;
	while (iNewSize < iCell) iNewSize *= 2;
	apBPatch = new BdryPatch3D*[iNewSize];
	// Copy the data into the new array
	for (GR_index_t iTmp = 0; iTmp < iBPatchSize; iTmp++) {
	  apBPatch[iTmp] = apBPTemp[iTmp];
	}
	iBPatchSize = iNewSize;
	delete [] apBPTemp;
      }
      apBPatch[iCell] = pBP;
    }
  void vSetBdryPatch(const Cell* const pC, BdryPatch3D* const pBP)
    {
      GR_index_t iCell = iCellIndex(pC);
      vSetBdryPatch(iCell, pBP);
    }
  ///
  void vCreatePatches();
public:
  ///
  eMeshType eType() const {return eSurfMesh;}
  // Smoothing not yet implemented for surface meshes
  int iSmooth(const int iMaxPasses = 10){assert(0 && iMaxPasses); return 0;}
  ///
  int iReconfigure(Face*& pF);
  ///
  bool qInsertPoint(const double adPoint[3], Cell* const pC,
		   int * const piSwaps, const bool qSwap = true,
		   const bool qForce = false, Vert* pVNew = pVInvalidVert);
  ///
  int iInsertOnFace(Vert* const pVNew, Face* const pF, Cell* const pC,
		    const bool qSwap, bool* qInsertOnEdge = NULL);
  ///
  int iInsertOnMultiEdge(Vert* const pVNew, MultiEdge* const pME,
			 const bool qSwap);
  ///
  int iInsertInInterior(Vert* const pVNew, Cell* const pC,
			const bool qSwap);
  ///
  void vMarkSmallAngles();
  ///
  void vProtectSmallAngles();
  ///
  int iFaceSwap(Face*& pF);
  ///
  virtual bool qDoSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE = pVInvalidVert) const;
public:
  ///
  double dBoundarySize() const;
  ///
  double dInteriorSize() const;  
  ///
  bool qWatertight() const;
  ///
  void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
};

void vWriteFile_Surface(SurfMesh & Mesh,
			const char strBaseFileName[],
			const char strExtraFileSuffix[] = "");

///
void vReadFile_Surface(const char * const strBaseFileName,
		       GR_index_t& iNumVerts,
		       GR_index_t& iNumFaces,
		       GR_index_t& iNumCells,
                       GR_index_t& iNumIntBdryFaces,
		       bool& qFaceVert,
		       bool& qCellVert,
		       bool& qFaceCell,
		       bool& qCellFace,
		       bool& qCellRegion,
                       bool& qIntBFaceFace,
                       bool& qIntBFaceVert,
                       bool& qIntBFaceBC,
		       EntContainer<Vert>& ECVerts,
		       GR_index_t (*&a2iFaceVert)[2],
		       GR_sindex_t (*&a2iFaceCell)[2],
		       GR_index_t (*&a2iCellVert)[3],
		       GR_index_t (*&a2iCellFace)[3],
		       int *&aiCellRegion,
                       GR_index_t (*&a2iIntBFaceFace)[2],
                       int *&aiIntBFaceBC,
                       GR_index_t (*&a2iIntBFaceVert)[2]);

#endif
