#ifndef GR_BFace
#define GR_BFace 1

class BFace;

#include "GR_config.h"
#include "GR_misc.h"
#include "GR_Cell.h"

#include <set>

class BasicTopologyEntity;
class GeometryEntity;
class CubitBox;

enum eEncroachType   { eBall, eLens, eNewLens };
enum eEncroachResult { eClean, eSplit, eOffsetPoint };

// A boundary face is a Cell so that a Face can point to it just like
// any other Cell.  This gives a Face access to its BC if that's needed,
// for example, while making all Faces look exactly the same for stuff
// other than BC's.  At the same time, BFace's can walk right into the
// mesh by way of the actual Face to which they're attached.  The Cell
// dSize and vAllDihed member functions are also useful here; the former
// is overloaded to evaluated surface area of a BFace and the latter to
// evaluate angles in the surface mesh.

class BFace : public Cell {
protected:
  // Some data required for point insertion at/near boundaries.
  mutable bool qOffsetInsRequested:1, qNeverDoOffsetIns:1;
  mutable double adInsertionLoc[3];
  // Copy construction disallowed, but must be declared protected so
  // that derived classes can pretend to use it.
  BFace(const BFace& BF) : Cell(BF), qOffsetInsRequested(false),
    qNeverDoOffsetIns(false) {assert(0);}
  // Called only by more-derived classes; all args provided.
  BFace(const bool qIsInternal, Face* const pFLeft, Face* const pFRight)
    : Cell(qIsInternal, pFLeft, pFRight), qOffsetInsRequested(false),
    qNeverDoOffsetIns(false)
    {
      adInsertionLoc[0] = adInsertionLoc[1] = adInsertionLoc[2] = 1.e300;
    }
private:
  // These are functions needed for TSTT support, and TSTT doesn't
  // recognize the existence of such a thing as BFace's, so these can
  // all be private and garbage.
  int iNumCells() const {assert(0); return 1;}
#ifdef ITAPS
  int iTopologicalDimension() const {assert(0); return -1;}
  int eEntType() const {assert(0); return iBase_ALL_TYPES;}
  int eEntTopology() const {assert(0); return iMesh_ALL_TOPOLOGIES;}
#endif
  void vAllVertHandles(GRUMMP_Entity*[]) const {assert(0);}
  void vAllFaceHandles(GRUMMP_Entity*[]) const {assert(0);}
  void vAllCellHandles(GRUMMP_Entity*[]) const {assert(0);}
public:
  // The destructor has nothing to do.
  virtual ~BFace() {}
  // Necessary when (for example) removing deleted BFace's from EntContainer's
  BFace& operator=(const BFace& BF);
  // This is implemented differently in 2D and 3D.
  virtual int iBdryCond() const = 0;

  // The new interface to access boundary conditions (Sept. 11 2006)
  virtual int bdry_cond(const bool left) const = 0;

  // Is there any point in the mesh that encroaches on this BFace?
  virtual eEncroachResult eIsEncroached(const eEncroachType eET = eLens) const = 0;
  eEncroachResult eIsPointEncroaching(const double adPoint[],
				      const eEncroachType eET = eLens,
				      const bool qTieBreaker = false) const {
    switch (eET) {
    case eBall:
      return eIsPointEncroachingBall(adPoint, qTieBreaker);
      break;
    case eLens:
      return eIsPointEncroachingLens(adPoint, qTieBreaker);
      break;
    case eNewLens:
      return eIsPointEncroachingNewLens(adPoint, qTieBreaker);
      break;
    default:
      assert(0);
      return(eClean);
    }
  }

  virtual eEncroachResult
    eIsPointEncroachingBall(const double adPoint[],
			    const bool qTieBreak = false) const = 0;
  virtual eEncroachResult
    eIsPointEncroachingLens(const double adPoint[],
			    const bool qTieBreak = false) const = 0;
  virtual eEncroachResult
    eIsPointEncroachingNewLens(const double adPoint[],
			       const bool qTieBreak = false) const = 0;
  virtual double dInsertionPriority() const {assert(0); return 0;}
  virtual void vGetOffsetInsertionPoint(const double[],	double[]) const
    {assert(0);}
  const double* adInsertionLocation() const {return adInsertionLoc;}
  virtual void vSetInsertionLocation(const double[]) const {assert(0);}
  bool qOffsetInsertionRequested() const {return qOffsetInsRequested;}
  void vRequestOffsetInsertion() const {qOffsetInsRequested = true;}
  void vClearOffsetInsertionRequest() const {qOffsetInsRequested = false;}
  bool qOffsetInsertionAllowed() const {return !qNeverDoOffsetIns;}
  void vForbidOffsetInsertion() const
    {qNeverDoOffsetIns = true; qOffsetInsRequested = false;}
  void vAllowOffsetInsertion() const {qNeverDoOffsetIns = false;}
  virtual void vCircumcenter(double []) const = 0;
  // Closure makes no sense for BFace's
  bool qIsClosed() const {return true;}
  // It is a bdry face/cell...
  virtual bool qIsBdryCell() const {return true;}
  Face *pFFace(const int i = 0)
    {
      assert(i < iNumFaces());
      return(ppFFaces[i]);
    }
  const Face *pFFace(const int i = 0) const
    {
      assert(i < iNumFaces());
      return(ppFFaces[i]);
    }
  const Vert* pVVert(const int i) const;
  Vert* pVVert(const int i) {
    return const_cast<Vert*>(static_cast<const BFace*>(this)->pVVert(i));
  }
  double dSize() const;
  void vVecSize(double adRes[]) const;
  void vUnitNormal(double adRes[]) const;
  virtual void vSetPatch(BdryPatch* const pBP) = 0;
  virtual BdryPatch* pPatchPointer() const = 0;
  virtual void vCentroid(double[]) const {assert(0);}
  
  //Split point for Delaunay refinement.
  virtual void compute_split_point(double*) const { assert(0); }

  //Computes and returns the face's bounding box.
  virtual CubitBox bounding_box() const = 0;

  //Computes the closest point on the BFace 
  //(projected to the attached surface if it is a curved surface)
  //Only implemented for TriBFaceBase for now.
  virtual void closest_on_bface(const double pt[3], double close[3]) const 
  { assert(0); assert(pt); close[0] = close[1] = close[2] = -LARGE_DBL; }

  //FIX ME: SG 09/2007.
  //The following was added to store geometry definition with the boundary
  //face. Initially, the 2D code was designed to store these as
  //GeometryEntity pointers. The 3D tetrahedral meshing code uses
  //BasicTopolgyEntity. Given the difference, I am not sure the pure
  //virtual calls should remain, especially if they only apply to one
  //particular derived class...
  
  //Sets and returns the geometric entity associated with this boundary face.
  virtual void set_geometry(GeometryEntity* const geom_ent) = 0;
  virtual GeometryEntity* get_geometry() = 0;

  virtual void set_topological_parent(BasicTopologyEntity* const topo_ent) = 0;
  virtual BasicTopologyEntity* get_topological_parent() = 0;

  //Functor to copy the face pointers of the boundary face to a set.
  struct GetFaces {
    std::set<Face*>* m_faces;
    GetFaces(std::set<Face*>* const faces) : m_faces(faces) { }
    void operator() (BFace* const bface) {
      for(int i = bface->iNumFaces() - 1; i >= 0; --i)
	m_faces->insert(bface->pFFace(i));
    }
  };

}; // End of BFace base class declaration

#endif
