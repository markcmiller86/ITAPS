#ifndef GR_VECTOR_H
#define GR_VECTOR_H

#include "GR_config.h"
#include <cmath>

namespace GRUMMP {

  class Vector {

    double m_x, m_y, m_z;

  public:

    Vector( ) 
      : m_x(-LARGE_DBL), m_y(-LARGE_DBL), m_z(-LARGE_DBL) { }

    Vector( double x_coord, double y_coord, double z_coord ) 
      : m_x(x_coord), m_y(y_coord), m_z(z_coord) { }

    Vector( const double coords[3] ) 
      : m_x(coords[0]), m_y(coords[1]), m_z(coords[2]) { }

    Vector( const Vector& pt1, const Vector& pt2 ) 
      : m_x(pt2.m_x - pt1.m_x), m_y(pt2.m_y - pt1.m_y), m_z(pt2.m_z - pt1.m_z) { }

    Vector( const Vector& vector ) 
      : m_x(vector.m_x), m_y(vector.m_y), m_z(vector.m_z) { }

    Vector& operator=( const Vector& vector ) 
      { m_x = vector.m_x; m_y = vector.m_y; m_z = vector.m_z; return *this; }

    virtual ~Vector() { }

    void set( double x_coord, double y_coord, double z_coord );
    
    void set( const double coords[3] );

    void set( const Vector& pt1, const Vector& pt2);
  
    void set( const Vector& vector);

    double x() const { return m_x; }

    double y() const { return m_y; }

    double z() const { return m_z; }

    void x( double x_coord ) { m_x = x_coord; }

    void y( double y_coord ) { m_y = y_coord; }

    void z( double z_coord ) { m_z = z_coord; }

    void get_coords( double &x_cood, double &y_coord, double &z_coord ) const;

    void get_coords( double coords[3] ) const;

    double normalize();

    double length() const;
    
    double length_squared() const;

    //Angle returned in degrees.
    double interior_angle( const Vector& other_vec ) const;

    void print_me() const;

    bool about_equal( const Vector& other_vec, 
		      double rel_tolerance = 1.e-6, double abs_tolerance = 1.e-6 ) const;

    bool within_tolerance( const Vector& other_vec, double tolerance = 1.e-6 ) const;

    //Operator overloading:
    
    //addition: {this = this + vector}
    Vector& operator+= ( const Vector &vector );
    
    //subtraction: {this = this - vector}
    Vector& operator-= ( const Vector &vector );
    
    //cross product: {this = this * vector} -> NON-COMMUTATIVE.
    Vector& operator*= ( const Vector &vector );
    
    //multiplication: {this = this * scale}
    Vector& operator*= ( const double scale );
    
    //division: {this = this / scale}
    Vector& operator/= ( const double scale );
    
    //unary negation  
    Vector operator-() const;

    //ith value of the vector (x, y, z)
    double operator[] ( int i ) const;

    //normalize: returns new vector aligned with vector, magnitude = 1. 
    friend Vector operator~ ( const Vector &vector );
  
    //addition
    friend Vector operator+ ( const Vector &v1, const Vector &v2 );
    
    //subtraction
    friend Vector operator- ( const Vector &v1, const Vector &v2 );

    //cross product
    friend Vector operator* ( const Vector &v1, const Vector &v2 );
    
    //vector-scalar multiply
    friend Vector operator* ( const Vector &vector, double scale );
    
    //scalar-vector multiply
    friend Vector operator* ( double scale, const Vector &vector );
    
    //dot product
    friend double operator% ( const Vector &v1, const Vector &v2 );

    //vector / scalar.
    friend Vector operator/ ( const Vector &v1, const double scale );
     
  };

  inline void Vector::set( double x_coord, double y_coord, double z_coord ) 
    { m_x = x_coord; m_y = y_coord; m_z = z_coord; }

  inline void Vector::set( const double coords[3] )
    { m_x = coords[0]; m_y = coords[1]; m_z = coords[2]; }

  inline void Vector::set( const Vector& pt1, const Vector& pt2 ) { 
    m_x = pt2.m_x - pt1.m_x;
    m_y = pt2.m_y - pt1.m_y;
    m_z = pt2.m_z - pt1.m_z;
  }

  inline void Vector::set( const Vector& vector )
    { m_x = vector.m_x; m_y = vector.m_y; m_z = vector.m_z; }

  inline void Vector::get_coords( double &x_coord, double &y_coord, double &z_coord ) const 
    { x_coord = m_x; y_coord = m_y, z_coord = m_z; }

  inline void Vector::get_coords( double coords[3] ) const 
    { coords[0] = m_x; coords[1] = m_y; coords[2] = m_z; }

  inline double Vector::normalize() {
    double mag = length(); assert( mag >= 0. );
    if( mag > 0. ) { m_x /= mag; m_y /= mag; m_z /= mag; }
    return mag;
  }

  inline double Vector::length() const 
    { return sqrt(m_x * m_x + m_y * m_y + m_z * m_z); }

  inline double Vector::length_squared() const
    { return ( m_x * m_x + m_y * m_y + m_z * m_z ); }

  inline void Vector::print_me() const 
    { printf("Vector: x = %lf, y = %lf, z = %lf\n", m_x, m_y, m_z); }

  inline bool Vector::within_tolerance( const Vector& other_vec, double tolerance ) const { 
    assert( tolerance >= 0. );
    return ( fabs( m_x - other_vec.m_x ) <= tolerance &&
	     fabs( m_y - other_vec.m_y ) <= tolerance &&
	     fabs( m_z - other_vec.m_z ) <= tolerance ); 
  }

  inline Vector& Vector::operator+= ( const Vector &vector ) 
    { m_x += vector.m_x; m_y += vector.m_y; m_z += vector.m_z; return *this; }
    
  inline Vector& Vector::operator-= ( const Vector &vector )
    { m_x -= vector.m_x; m_y -= vector.m_y; m_z -= vector.m_z; return *this; }
    
  inline Vector& Vector::operator*= ( const Vector &vector ) {   
    double cross[] = { m_y * vector.m_z - m_z * vector.m_y, 
		       m_z * vector.m_x - m_x * vector.m_z,
		       m_x * vector.m_y - m_y * vector.m_x };
    m_x = cross[0]; m_y = cross[1]; m_z = cross[2];
    return *this;
  }
    
  inline Vector& Vector::operator*= ( const double scale ) {
    m_x *= scale; m_y *= scale; m_z *= scale;
    return *this;
  }
    
  inline Vector& Vector::operator/= ( const double scale ) {
    if( scale < 0. || scale > 0. )
      { m_x /= scale; m_y /= scale; m_z /= scale; }
    return *this;
  }
    
  inline Vector Vector::operator- () const 
    { return Vector(-m_x, -m_y, -m_z); }

  inline double Vector::operator[] ( int i ) const {
    switch( i ) {
    case 0: return m_x;
    case 1: return m_y;
    case 2: return m_z;
    default: assert(0); return -LARGE_DBL;
    }
  }
   
  inline Vector operator~ ( const Vector &vector ) { 
    Vector new_vector( vector );
    double mag = vector.length();
    if( mag < 0. || mag > 0. ) new_vector /= mag;
    return new_vector;
  }
  
  inline Vector operator+ ( const Vector &v1, const Vector &v2 ) 
    { return Vector( v1.m_x + v2.m_x, v1.m_y + v2.m_y, v1.m_z + v2.m_z ); }

  inline Vector operator- ( const Vector &v1, const Vector &v2 ) 
    { return Vector( v1.m_x - v2.m_x, v1.m_y - v2.m_y, v1.m_z - v2.m_z ); }

  inline Vector operator* ( const Vector &v1, const Vector &v2 )
    { return ( Vector(v1) *= v2 ); }
    
  inline Vector operator* ( const Vector &vector, double scale )
    { return ( Vector(vector) *= scale ); }
        
  inline Vector operator* ( double scale, const Vector &vector ) 
    { return ( Vector(vector) *= scale ); }
    
  inline Vector operator/ ( const Vector& vector, const double scale ) { 
    if( scale < 0. || scale > 0. ) return ( Vector( vector ) /= scale ); 
    else return Vector( vector );
  }

  inline double operator%(const Vector &v1, const Vector &v2) 
    { return( v1.m_x * v2.m_x + v1.m_y * v2.m_y + v1.m_z * v2.m_z ); }


}

#endif
