#ifndef GR_BFACE2D_H
#define GR_BFACE2D_H

#include "GR_config.h"
#include "GR_BFace.h"
#include "GR_Face.h"
#include "GR_GRCurve.h"

class Cell;
class CubitVector;
class CubitBox;
class GeometryEntity;
class Vert;

class BdryEdgeBase : public BFace {

 public:

  enum SplitType { UNKNOWN, MID_TVT, MID_PARAM };

 protected:

  // In case of emergency (like reading a file with no geometry
  // present), a place to stash the associated bdry condition. 
  int iBdryCond_;
  
  //The curve associated with this boudary edge.
  GRCurve* m_curve;

  //The parameters of the beg and end verts on the curve.
  //Storing this here causes redundancy storage, however, 
  //it is better than storing the param in the Vert class
  //since interior vertices have nothing to do with a parameter.
  double m_vert0_param, m_vert1_param;

  //Default constructor.
  BdryEdgeBase() : 
    BFace(false, pFInvalidFace, pFInvalidFace),
    iBdryCond_(-1), m_curve(NULL), 
    m_vert0_param(-LARGE_DBL), m_vert1_param(LARGE_DBL),
    pBPBdryPatch(NULL) {};
  
  // Typical constructor; called from BdryEdge and IntBdryEdge
  // constructors with first two args guaranteed to exist.
  BdryEdgeBase( const bool qIsInternal, 
		Face* const pFLeft,
		Face* const pFRight = pFInvalidFace, 
		GRCurve* const parent_curve = NULL, 
		double vert0_param = -LARGE_DBL,
		double vert1_param =  LARGE_DBL );

  // Copy construction disallowed, but declared protected so that
  // derived classes can pretend to use it.
  BdryEdgeBase(BdryEdgeBase& BEB) : 
    BFace(BEB), m_curve(BEB.m_curve), 
    m_vert0_param(BEB.m_vert0_param), 
    m_vert1_param(BEB.m_vert1_param),
    pBPBdryPatch(NULL) { assert(0); }

  BdryEdgeBase& operator=(const BdryEdgeBase& BEB); 

 public:

  virtual ~BdryEdgeBase() {}

  //Sets the geometric curve associated with this boundary edge.
  void set_curve(GRCurve* const curve);
  
  //Returns a pointer to the geometric curve object associated to the BE.
  GRCurve* get_curve() const;

  //Sets the parameters on curve at begin and end points.
  void set_vert0_param(double param);
  void set_vert1_param(double param);
 
  //Returns parameter on curve at begin and end points.
  double vert0_param(bool run_debug_code = true) const;
  double vert1_param(bool run_debug_code = true) const;

  //Returns the boundary condition on left or right.
  int bdry_cond(const bool left) const;
  int bdry_left() const;
  int bdry_right() const;

  //Return the distance between pVVert(0) and pVVert(1)
  double length() const;
  
  //Returns the edge's midpoint
  CubitVector mid_point() const;

  //Is pVVert(0) before pVVert(1) along the curve?
  //The mesh is generated in such a way that the faces located at the boundary 
  //are always in the same direction as the underlying curve. If the boundary
  //edge is in the same direction as its face, then it is also in the same direction
  //as the underlying curve. MIGHT NOT HOLD AFTER Mesh2D::vReorder() IS CALLED!
  bool is_forward() const { return (pVVert(0) == pFFace(0)->pVVert(0)); }

  //Returns the number of verts. Always returns 2.
  int iNumVerts() const { return 2; }

  //This is needed by the refinement code. Returns the split parameter
  //and set split_coord. concentric_shell_split set to true if a shell
  //split is required.
  double get_split_data(const SplitType split_type,
			CubitVector& split_coord,
			bool& concentric_shell_split) const;

  //Returns the axis-aligned bounding box for this boundary edge.
  CubitBox bounding_box() const;

  //Functions to call to verify if the boundary edge is encroached.
  virtual eEncroachResult eIsEncroached(const enum eEncroachType enc_type) const;

  virtual eEncroachResult eIsPointEncroachingBall(const double coord[],
						  const bool tie_break = false) const;

  virtual eEncroachResult eIsPointEncroachingLens(const double coord[],
						  const bool tie_break = false) const;

  virtual eEncroachResult eIsPointEncroachingNewLens(const double coord[],
						     const bool tie_break = false) const;

  //Offset insertion is disabled for now.
/*   CubitVector get_offset_loc(const CubitVector& trigger) const; */
/*   CubitVector get_offset_loc(bool left = true) const; */

  //These two return the center poit of this edge.
  void vCentroid(double centroid[]) const;
  void vCircumcenter(double circumcenter[]) const;

  //Sets and returns the geometric entity associated with this boundary face.
  //Pure virtual functions defined in BFace.
  void set_geometry(GeometryEntity* const geom_ent);
  GeometryEntity* get_geometry();

  bool qValid() const;

 private:

  eEncroachResult encroaching_lens(const double coord[], 
				   const bool tie_break, 
				   const eEncroachType enc_type) const;

 public:

  /// Set bdry condition to a given integer.  This is a temporary hack
  /// to deal with reading a mesh from native format.
  void vSetBdryCond(const int i) {
    assert(i >= 0);
    iBdryCond_ = i;
  }
  /////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////
  //The following are no longer necessary but are defined//
  //because base class declare them as pure virtual.     //
  /////////////////////////////////////////////////////////
  /////////////////////////////////////////////////////////
  int iBdryCond() const {
    //This is the original function called by the BFace
    //interface. It only allows to store and return a
    //boundary on one side of a curve. Still maintained for
    //compatibility with IO functions generated by lex.c 
    if (iBdryCond_ >= 0) return iBdryCond_;
    
    int left  = bdry_left();
    int right = bdry_right();

#ifndef NDEBUG

    assert(eType() == CellSkel::eBdryEdge ||
	   eType() == CellSkel::eIntBdryEdge);

    switch(eType()) {
    case CellSkel::eBdryEdge:
      assert(   left == 0 || right == 0  );
      assert( !(left == 0 && right == 0) );
      break;
    case CellSkel::eIntBdryEdge:
      assert( left == iInvalidBC && right == iInvalidBC );
      break;
    }

#endif

    return left == 0 ? right : left;

  }

  //The following has been re-instated because it is necessary
  //for the "original" 3D mesh generation code.

 private:

  BdryPatch* pBPBdryPatch;

 public:

  //This should not be necessary.
  int iPatchIndex() {
    //Patches do not exist in 2D anymore. However, do not want
    //to remove from BFace interface just yet.
    assert(0);
    return 0;
  }

  void vSetPatch(BdryPatch* const pBPBdryPatchIn) {
    //Patches do not exist in 2D anymore. However, do not want
    //to remove from BFace interface just yet.
    assert(pBPBdryPatchIn);
    pBPBdryPatch = pBPBdryPatchIn;
  }

  BdryPatch* pPatchPointer() const {
    assert(0);
    assert(pBPBdryPatch);
    return pBPBdryPatch;
  }

  //////////////////////////////////////////////////////////
  //////////////////////////////////////////////////////////

  void set_topological_parent(BasicTopologyEntity* const topo_ent) 
  { if(topo_ent) {} assert(0); abort(); } ;
  BasicTopologyEntity* get_topological_parent() 
    { assert(0); abort(); return static_cast<BasicTopologyEntity*>(NULL); }

};

class BdryEdge : public BdryEdgeBase {

 private:

  // Disallow copy constructor
  BdryEdge(BdryEdge& BE) : BdryEdgeBase(BE) { assert(0); }

 public:

  BdryEdge(Face* const pF = pFInvalidFace, 
	   GRCurve* const parent_curve = NULL,
	   double param_at_beg = -LARGE_DBL,
	   double param_at_end =  LARGE_DBL) 
    : BdryEdgeBase(false, pF, pFInvalidFace, parent_curve, param_at_beg, param_at_end) 
    { vSetType(Cell::eBdryEdge); }

  BdryEdge& operator=(BdryEdge& BE) {
    
    if(this != &BE) 
      this->BdryEdgeBase::operator=(BE);
      
    return *this;

  }
 public:
  virtual ~BdryEdge() {}

  int iNumFaces() const { return 1; }

};

class IntBdryEdge : public BdryEdgeBase {

 private:

  // Disallow copy constructor
  IntBdryEdge(IntBdryEdge& IBE) : BdryEdgeBase(IBE) { assert(0); }

 public:
  
  IntBdryEdge( Face* const pFLeft  = pFInvalidFace,
	       Face* const pFRight = pFInvalidFace,
	       GRCurve* const parent_curve = NULL,
	       double param_at_beg = -LARGE_DBL,
	       double param_at_end =  LARGE_DBL )
    : BdryEdgeBase(true, pFLeft, pFRight, parent_curve, param_at_beg, param_at_end)
    { vSetType(Cell::eIntBdryEdge); }

  IntBdryEdge& operator=(IntBdryEdge& IBE) {

    if(this != &IBE) 
      this->BdryEdgeBase::operator=(IBE);

    return *this;

  }

  virtual ~IntBdryEdge() {}

  int iNumFaces() const { return 2; }

  Face *pFOtherFace(const Face * const pF) const {
    if (pF == pFFace(0)) return const_cast<Face*>(pFFace(1));
    else                 return const_cast<Face*>(pFFace(0));
  }

}; 

#endif
