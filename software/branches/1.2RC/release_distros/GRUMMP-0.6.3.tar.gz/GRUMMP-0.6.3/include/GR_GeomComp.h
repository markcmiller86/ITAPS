#ifndef GR_GEOMCOMP_H
#define GR_GEOMCOMP_H

#include "GR_config.h"

//Finds the normal (optionally unit normal) to a plane defined by three points.
void normal_to_plane( const double pt0[3], const double pt1[3], const double pt2[3],
		      double norm[3], const bool unit = true );

//Projects a 3D point onto a plane defined by three points.
void project_point_to_plane( const double pt[3], 
			     const double pt0[3], const double pt1[3], const double pt2[3],
			     double proj[3]  );

//Find the closest point on a 3D triangle from a 3D point.
void closest_on_triangle( const double pt[3], 
			  const double t0[3], const double t1[3], const double t2[3], 
			  double close[3] );

//Given three points in space, computes the plane equation 
//coefficients, a, b, c and d, such that a*x + b*y + c*z + d = 0.
void compute_plane(const double pt0[3], const double pt1[3], const double pt2[3],
		   double& a, double& b, double& c, double& d);

#endif
