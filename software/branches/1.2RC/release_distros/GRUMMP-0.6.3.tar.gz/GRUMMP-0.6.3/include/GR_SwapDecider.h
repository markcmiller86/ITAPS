#ifndef GR_SwapDecider_h
#define GR_SwapDecider_h

#include <string>

#include "GR_EdgeSwapInfo.h"
#include "GR_QualMeasure.h"
#include "GR_SwapManager.h"
#include "GR_Vertex.h"

#define SIM_ANNEAL_TEST

namespace GRUMMP {
  class SwapDecider2D {
  protected:
    QualMeasure<2> *m_pQM;
    std::string m_name;
  private:
    SwapDecider2D(const SwapDecider2D& SD) :
      m_pQM(SD.m_pQM), m_name(SD.m_name) {}
  public:
    SwapDecider2D(QualMeasure<2>* const pQM, const std::string name) :
      m_pQM(pQM), m_name(name)
    {}
    virtual ~SwapDecider2D() {if (m_pQM) delete m_pQM;}
    // No protected data accessors at this point.  Add them later if
    // they're needed.
    const std::string& getName() const {return m_name;}
    virtual bool doFaceSwap(const FaceSwapInfo2D& FC) const;
  };

  class DelaunaySwapDecider2D : public SwapDecider2D {
  private:
  public:
    DelaunaySwapDecider2D() :
      SwapDecider2D(NULL, "Delaunay") {}
    ~DelaunaySwapDecider2D() {}
    bool doFaceSwap(const FaceSwapInfo2D& FC) const;
  };

  class MinMaxAngleSwapDecider2D : public SwapDecider2D {
  private:
  public:
    MinMaxAngleSwapDecider2D() :
      SwapDecider2D(new MinMaxAngle2D(),
		    "minmax angle") {}
    ~MinMaxAngleSwapDecider2D() {}
    bool doFaceSwap(const FaceSwapInfo2D& FC) const;
  };

  class UniformDegreeSwapDecider2D : public SwapDecider2D {
  private:
  public:
    UniformDegreeSwapDecider2D() :
      SwapDecider2D(NULL, "uniform degree") {}
    ~UniformDegreeSwapDecider2D() {}
    bool doFaceSwap(const FaceSwapInfo2D& FC) const;
  };

  class SwapDecider3D {
  protected:
    bool m_allowBdryChanges, m_allowEdgeSwaps;
    double m_maxBdryAngle;
    QualMeasure<3> *m_pQM;
    std::string m_name;
  private:
    SwapDecider3D(const SwapDecider3D& SD) :
      m_allowBdryChanges(SD.m_allowBdryChanges),
      m_allowEdgeSwaps(SD.m_allowEdgeSwaps),
      m_maxBdryAngle(SD.m_maxBdryAngle), 
      m_pQM(SD.m_pQM), m_name(SD.m_name) {}
    double calcOrigQuality(const EdgeSwapInfo& ES) const;
    bool areBdryFacesOKToSwap(const BFace* const pBF0,
			      const BFace* const pBF1) const;
  public:
    SwapDecider3D(const bool bdryChangeable, const bool edgesSwappable,
		  const bool maxBdryAngle,
		  QualMeasure<3>* const pQM, const std::string name) :
      m_allowBdryChanges(bdryChangeable), m_allowEdgeSwaps(edgesSwappable),
      m_maxBdryAngle(maxBdryAngle), m_pQM(pQM), m_name(name)
    {}
    virtual ~SwapDecider3D() {if (m_pQM) delete m_pQM;}
    // No protected data accessors at this point.  Add them later if
    // they're needed.
    const std::string& getName() const {return m_name;}
    virtual bool doFaceSwap(const FaceSwapInfo3D& FC) const;
    bool doEdgeSwap(EdgeSwapInfo& ES, Vert * const pVWant0 = pVInvalidVert,
		    Vert * const pVWant1 = pVInvalidVert) const;
    bool doBdryEdgeSwap(EdgeSwapInfo& ES) const;
    double evalTetQual(const Cell* const pC) const;
  };

  class DelaunaySwapDecider3D : public SwapDecider3D {
  private:
  public:
    DelaunaySwapDecider3D(const bool bdryChangeable,
			  const double maxBdryAngle = 0) :
      SwapDecider3D(bdryChangeable, false, maxBdryAngle, NULL,
		    "Delaunay") {}
    ~DelaunaySwapDecider3D() {}
    bool doFaceSwap(const FaceSwapInfo3D& FC) const;
  };

  class MaxMinSineSwapDecider3D : public SwapDecider3D {
  private:
  public:
    MaxMinSineSwapDecider3D(const bool bdryChangeable,
			    const double maxBdryAngle = 0) :
      SwapDecider3D(bdryChangeable, true, maxBdryAngle,
		    new SineDihedralAngles(),
		    "maxmin sine dihedral") {}
    ~MaxMinSineSwapDecider3D() {}
    bool doFaceSwap(const FaceSwapInfo3D& FC) const;
  };

  class MinMaxDihedSwapDecider3D : public SwapDecider3D {
  private:
  public:
    MinMaxDihedSwapDecider3D(const bool bdryChangeable,
			     const double maxBdryAngle = 0) :
      SwapDecider3D(bdryChangeable, true, maxBdryAngle,
		    new DihedralAngles(),
		    "minmax dihedral") {}
    ~MinMaxDihedSwapDecider3D() {}
    bool doFaceSwap(const FaceSwapInfo3D& FC) const;
  };
} // namespace GRUMMP

#endif
