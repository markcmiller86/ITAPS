#ifndef GR_Mesh2D
#define GR_Mesh2D 1

#include "GR_config.h"
#include "GR_Classes.h"
#include "GR_BFace2D.h"
#include "GR_BFaceCV.h"
#include "GR_Cell.h"
#include "GR_CellCV.h"
#include "GR_Face.h"
#include "GR_GRCurve.h"
#include "GR_Mesh.h" 
#include "GR_EntContainer.h"
#include <map>

class GRGeom2D;

/**\brief The 2D specialization of the Mesh base class.
 *
 * Functions inherited from Mesh will not be documented again here.
 */
class Mesh2D : public Mesh {
protected:
  /// Variable size array containing faces in the 2D mesh
  EntContainer<EdgeFace>      ECEdgeF;      

  /// Variable size array containing bdry faces in the 2D mesh
  EntContainer<BdryEdge>      ECEdgeBF; 

  /// Variable sized array containing triangular cells in the 2D mesh
  EntContainer<TriCell>       ECTri; 

  /// Variable sized array containing quadrilateral cells in the 2D mesh
  EntContainer<QuadCell>      ECQuad;
  
  /// Variable size array containing internal bdry faces in the 2D mesh
  EntContainer<IntBdryEdge>   ECIntEdgeBF; 

  /// Variables (counters) to keep track of where vertices are inserted.
  int iOnEdge, iOnBdryEdge, iOnBdryEdge2;
  int iInterior, iInternalBdry, iInternalBdry2;

private:
  /// The copy constructor currently appears to be unnecessary.
  Mesh2D(const Mesh2D& ) : Mesh() {assert(0);}
  
  /// operator= has probably always been unnecessary.
  Mesh2D& operator=(const Mesh2D&) {assert(0); return *this;}


public:


  ///This constructor is used by MeshOpt2D and Coarsen2D executables.
  ///It requires a good rework to make it work with the new geometry interface.
  Mesh2D(const char strInFileName[], GRGeom2D* const geometry = NULL,
	 const int iQualMeas = 2);
  /// Read mesh data from a file.
  void readMeshFile(const char strFileName[]);
  ///
  void relateMeshToGeometry(GRGeom2D* const geometry);

  ///Default constructor called by TriMeshBuilder.
  Mesh2D(const int iQualMeas = 2);

  ///This constructor is deprecated, but still required for 3D initial
  ///tetrahedralization until Serge's facet branch merges in -and- can
  ///read .bdry and .smesh files.
  Mesh2D(const Bdry2D& B2D, const int iQualMeas = 2);

  //Creating a Delaunay mesh from a set of vertices.
  //THIS SHOULD BE REIMPLEMENTED IN THE TriMeshBuilder CLASS.
  // This is only used in the scat2d executable, apparently, so it can wait. 
  Mesh2D(const EntContainer<Vert>& EC);

  ///Destructor.
  virtual ~Mesh2D() { }

  /// Inquiry functions


  //////////////////////////////////////////////////////////////////////
  /// Functions that directly manipulate or query the mesh database. ///
  //////////////////////////////////////////////////////////////////////
  
  GR_index_t iVertIndex(const Vert* const pV) const { return (ECVerts.getIndex(pV)); }
  GR_index_t iNumVerts() const {return ECVerts.lastEntry();}
  Vert* pVVert(const GR_index_t i) const {return ECVerts.getEntry(i);}
  Vert* pVNewVert()
    {
      Vert *pV = ECVerts.getNewEntry();
      pV->vSetDefaultFlags();
      pV->vClearFaceConnectivity();
      return (pV);
    }
  /// Given a face pointer, find the corresponding integer index.
  virtual GR_index_t iFaceIndex(const Face* const pF) const;
  virtual GR_index_t iNumFaces() const {return ECEdgeF.lastEntry();}
  virtual Face* pFFace(const GR_index_t i) const;
  ///
  virtual GR_index_t iBFaceIndex(const BFace* const pBF) const;
  virtual GR_index_t iNumBdryFaces() const {return ECEdgeBF.lastEntry();}
  virtual GR_index_t iNumIntBdryFaces() const {return ECIntEdgeBF.lastEntry();}
  GR_index_t iNumTotalBdryFaces() const {return iNumBdryFaces() + iNumIntBdryFaces();}
  virtual BFace* pBFBFace(const GR_index_t i) const;
  virtual GR_index_t iNumBdryPatches() {assert(0); return (~0);/*B2D.iNumPatches();*/}
  virtual void vBuildBdryPatches();
  ///
  virtual GR_index_t iCellIndex(const Cell* const pC) const;
  GR_index_t iNumTriCells() const {return ECTri.lastEntry();}
  GR_index_t iNumQuadCells() const {return ECQuad.lastEntry();}
  virtual GR_index_t iNumCells() const {return iNumTriCells() + iNumQuadCells();}
  virtual Cell* pCCell(const GR_index_t i) const;
  ///
  virtual bool qIsValidEnt(void* pvEnt) const;
  ///
  virtual eMeshType eType() const {return Mesh::eMesh2D;}
  ///
  /// perimeter length or  area:
  virtual double dBoundarySize() const;
  /// interior   area  or volume:
  virtual double dInteriorSize() const;
  virtual bool qWatertight() const;
  /// 
  /// Validity checking
  virtual bool qValid() const;
  ///
  bool qIsLocallyDelaunay() const;

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////

  // The generic, ITAPS-style calls
/*   Face* createFace(Vert * const apV[], const int iNVerts); */
/*   Cell* createCell(Face * const apF[], const int iNFaces, const int iReg); */
/*   Cell* createCell(Vert * const apV[], const int iNFaces, const int iReg); */

  // The size-specific (and more efficient) calls; the ITAPS-style calls
  // will either call these or switch on number of verts and execute the
  // same code.
  Vert* createVert(const double dX, const double dY, const double dZ = 0);
  Vert* createVert(const double adCoords[]);
  BFace* createBFace(Face * const pF, BFace * const pBF = pBFInvalidBFace);
  /// This form is deprecated, but currently needed to read native format.
  BFace* createBFace(Face * const pF, const int i);
  Face* createFace(bool& qAlreadyExisted, Vert * const pV0, Vert * const pV1);
  /// This form will almost certainly be deprecated in future
  IntBdryEdge* createIntBdryEdge(Face * const pFA, Face * const pFB,
				 BFace * const pBF = pBFInvalidBFace);
  /// Create a new internal bdry edge, including setting geometry info.
  IntBdryEdge* createIntBdryEdge(Vert* const pVBeg, Vert* const pVEnd,
				 GRCurve* const curve,
				 double dBegParam, double dEndParam );
  /// Create a new bdry edge, including setting geometry info.
  BdryEdge* createBdryEdge(Vert* const pVBeg, Vert* const pVEnd,
			   GRCurve* const curve,
			   double dBegParam, double dEndParam );
  TriCell* createTriCell(Face * const pF0, Face * const pF1,
			 Face * const pF2,
			 const int iReg = iDefaultRegion);
  virtual QuadCell* createQuadCell(Face * const pF0, Face * const pF1,
				   Face * const pF2, Face * const pF3,
				   const int iReg = iDefaultRegion);
  virtual TriCell* createTriCell(Vert * const pV0, Vert * const pV1,
				 Vert * const pV2,
				 const int iReg = iDefaultRegion);
  virtual QuadCell* createQuadCell(Vert * const pV0, Vert * const pV1,
				   Vert * const pV2, Vert * const pV3,
				   const int iReg = iDefaultRegion);
  bool deleteVert(Vert * const pV);
  // The second arg in the next function is used only to avoid a painful
  // rewrite of RemoveVertByContraction!  Use of it even in that context
  // is discouraged, but I haven't yet fixed it; use in other contexts
  // is definitely discouraged, because the arg is going to go away in
  // the future.  So delete cells before faces!
  bool deleteFace(Face * const pF);
  bool deleteBFace(BFace * const pBF);
  bool deleteCell(Cell * const pC);
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  

  ///
  virtual void vPurgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL);
  ///
  virtual void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL);
  ///
  virtual void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  ///
  virtual void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  /// Return the number of triangular cells.
  virtual void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL,
		      std::map<BFace*, BFace*>* bface_map = NULL);

  /// Return the number of quadrilateral cells.
  void vResetVertexConnectivity();
  ///
  void vReorder(void) {
    vReorderVerts_RCM();
    vReorderCells();
    vReorderFaces();
    for (GR_index_t iF = 0; iF < iNumFaces(); iF++) {
      Face *pF = pFFace(iF);
      if (pF->qIsBdryFace() && pF->pCCellLeft()->qIsBdryCell()) {
	pF->vInterchangeCellsAndVerts();
      }
    }
  }
 protected:
  virtual void vReorderVerts_RCM(void);
  virtual void vReorderCells(void);
  virtual void vReorderFaces(void);
 public:

  ////////////////////////////////////////////////////////
  /// Functions that affect the behavior of algorithms ///
  ////////////////////////////////////////////////////////

  ///
  eSwap eSwapType() const {return eSwapMeasure;}
  void vSetSwapType(const eSwap eSwapIn) {eSwapMeasure = eSwapIn;}
  ///
  bool qBdryChangesAllowed() const {return qAllowBdryChanges;}
  void vAllowBdryChanges() {qAllowBdryChanges = true;}
  void vDisallowBdryChanges() {qAllowBdryChanges = false;}
  ///
  bool qSwapRecursionAllowed() const {return qSwapRecur;}
  void vAllowSwapRecursion() {qSwapRecur = true;}
  void vDisallowSwapRecursion() {qSwapRecur = false;}
  ///
  bool qSimplicial() const {return qSimplex;}
  virtual void vMakeSimplicial() {assert(0);}
  void vAllowNonSimplicial() {qSimplex = false;}

  // Smoothing:
  virtual void vSetSmoothingGoal(const int iGoal)
  {
    SMsetSmoothFunction(pvSmoothData, iGoal);
  }
  // End smoothing

  // Insertion:
  // The worst shape quality measure (shortest edge to circumradius) allowed.
  // The worst shape quality measure allowed.
  virtual double dWorstAllowedCellShape() const
    {
      // These should correspond to minimum angles of 20.7, 25.7, and 30 deg,
      // respectively.
      switch (eEncType) {
      case eBall:
	return sqrt(1./6.); // = sin(20.7 deg) / sin(60 deg)
      case eLens:
	return 0.5;         // = sin(25.7 deg) / sin(60 deg)
      case eNewLens:
	return sqrt(1./3.); // = sin(30 deg) / sin(60 deg)
      default:
	assert(0);
	return 0;
      }
    }
  void vSetEncroachmentType(const eEncroachType eET) { eEncType = eET; }
  eEncroachType eEncroachmentType() const {return eEncType;}
  // End insertion

  // Coarsen:
  void vSetInteriorSkip(const int iNewSkip)
    {
      assert(iNewSkip > 0);
      iIntSkip = iNewSkip;
    }
  void vSetBoundaryFill(const bool qNewFill) {qBdryFill = qNewFill;}
  virtual double dCoarsenConstant() const {return 0.45;}
  // End coarsen

  /////////////////////////////////////////
  /// Functions related to mesh quality ///
  /////////////////////////////////////////

  void vSetQualityMeasure(const int iQual) {
    delete pQ;
    pQ = new Quality(this, iQual);
  }
  void vEvaluateQuality() const {pQ->vEvaluate();}
  double dEvaluateQuality(const CellSkel* const pCS) const
    {return pQ->dEvaluate(pCS);}
  void vImportQualityData(const double adData[]) const
    {pQ->vImportQualityData(adData);}
  void vWriteQualityToFile(char strQualFileName[]) const
    {pQ->vWriteToFile(strQualFileName);}

  ///////////////////////////////////////////////////////
  /// Low-level algorithms that change mesh geom/topo ///
  ///////////////////////////////////////////////////////

  // Swapping
  virtual bool qDoSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE = pVInvalidVert) const;
  virtual int iFaceSwap(Face*& pF);

  // Vertex removal
  virtual bool qRemoveVertByContraction(Vert * const pV, int& iNewSwaps,
					Vert * apVPreferred[] = NULL,
					const int iNPref = 0);
  virtual bool qRemoveVert(Vert * const pV, int& iNewSwaps);

  // Vertex insertion
  virtual bool qInsertPoint(const double adPoint[], Cell* const pCGuess,
			    int * const piSwaps, const bool qSwap = true,
			    const bool qForce = false,
			    Vert* pVNew = pVInvalidVert);
  ///
#ifndef FACET_MERGED
  void vGetNeighborVertsAndFaces(Vert* pV,
				 List<Vert*>& LpVNear,
				 List<Face*>& LpFNear );
#endif

  /////WATSON INSERTION DECLARATIONS/////

  friend class TriMeshBuilder;
  friend class TriMeshRefiner;
    
  //Define this struct to make function calls a little "cleaner".
  struct WatsonData {
    std::map<Face*, int> hull_faces;
    std::set<Face*> faces_to_remove;
    std::set<Cell*> cells_to_remove;
    std::set<BdryEdgeBase*> encroached_bdry_edges;
  };


  //
  typedef std::pair<BdryEdgeBase*, BdryEdgeBase*> BEdgePair; 

  //This is a pure virtual function in the base class.
  virtual int iInsertPointWatson(WatsonInfo& WI);
   
  /// The following function is deliberately blank; it's not needed in 2D.
  void vCleanupWatson(WatsonInfo&) {}

  //////////////////////////////////////////////////
  /// High-level algorithms that change the mesh ///
  //////////////////////////////////////////////////

  virtual int iSwap(const int iMaxPasses = 2,
		    const bool qAlreadyMarked = false);
  virtual int iSmooth(const int iMaxPasses = 10);
  virtual bool qDelaunayize();

  ////////////////////////////////////////////////////////
  /// Internal routines to assist with mesh coarsening ///
  ////////////////////////////////////////////////////////

private:
  // Find the cell incident on pV0 that covers the ray towards pV1 (may be
  // a multiple choice question if pV0 and pV1 are adjacent, or if there
  // is a face containing one but not the other and colinear with both.
  virtual Cell* pCBeginPipe(const Vert* const pVLast,
			    const Vert* const pVNew) const;
public:
  virtual void vIdentifyVertexTypesGeometrically() const;

  /////////////////////////////////////////////
  /// Quasi-internal routines for insertion ///
  /////////////////////////////////////////////

  //This will actually call compute_watson_data with default arguments. 
  //It is a pure virtual function in the base class so needs to be defined here.
  virtual void vGetWatsonData(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const;

  //New functions to compute data necessary for Watson insertion
  void compute_watson_data( const CubitVector& point,
			    const Cell* const seed_cell,
			    WatsonData& watson_data,
			    const bool test_bdry_for_encroachment = true,
			    const bool exit_on_encroached_bdry    = true ) const;
  
  void compute_watson_data( const Vert* const vertex,
			    const Cell* const seed_cell,
			    WatsonData& watson_data,
			    const bool test_bdry_for_encroachment = true,
			    const bool exit_on_encroached_bdry    = true ) const;

  //Public interface to insert a point in the mesh using Watson insertion.
  //NOTE: This call will always prevent any boundary edge from being
  //encroached. Therefore, it is possible that many vertices get
  //inserted on the boundary, even though the initial intent was to
  //insert a single vertex in the interior.
  void insert_watson(const CubitVector& insert_location,
		     Cell* seed_cell = NULL,
		     const std::set<Cell*>* const seed_guesses = NULL,
		     std::vector<Cell*>* new_cells = NULL,
		     std::vector<Face*>* new_faces = NULL);

  void vMarkCleanNeighbors (Cell * pC);
  Face *pFFaceBetween (Vert * const pV0, Vert * const pV1);
  
  //MAKE PRIVATE!
  //Inserts a new vertex in the interior.
  void insert_watson_interior(Vert* const new_vert,
			      WatsonData& watson_data,
			      std::vector<Cell*>* new_cells = NULL,
			      std::vector<Face*>* new_faces = NULL);
  //MAKE PRIVATE!
  //Inserts a new vertex on the mesh boundary. Returns a pair 
  //containing the newly created boundary edges.
  BEdgePair insert_watson_boundary(Vert* const new_vert,
				   BdryEdgeBase* const edge_to_split,
				   WatsonData& watson_data,
				   double new_param = LARGE_DBL,
				   std::vector<Cell*>* new_cells = NULL,
				   std::vector<Face*>* new_faces = NULL);

  //This function is no longer defined in 2D, it is replaced by
  //delete_interior_verts_in_ball (accepting different arguments).
  //Since it is a pure virtual function in the base class, a definition
  //is still needed.
  virtual bool qDeleteInteriorPointsInBall(const Cell*, const double[],
					   const double, int&) {
    vFatalError("This function is not defined in 2D",
		"Mesh2D::qDeleteInteriorPointsInBall");
    return false;
  }

 private:

  //Marks the set contents as deleted. Also removes face-cell connectivity.
  void delete_watson_hull(std::set<Cell*>& cells_to_remove,
			  std::set<Face*>& faces_to_remove,
			  BdryEdgeBase* const edge_to_split = NULL);

  //Rebuilds the Watson hull.
  void reconnect_watson_hull(Vert* const new_vertex,
			     const std::map<Face*, int>& hull_faces,
			     std::vector<Cell*>* new_cells,
			     std::vector<Face*>* new_faces);

  //Deletes the INTERIOR vertices located in the boundary edge's 
  //diametral ball from the mesh. 
  void delete_verts_in_edge_ball(BdryEdgeBase* const edge_to_split,
				 std::vector<Cell*>* new_cells = NULL);

  //The following two should only be used with a Delaunay triangulation
  //(not a constrained Delaunay one).

  //Finds a cell with vertex in its circumcenter among guesses.
  //If none is found, then calls find_seed_naively.
  Cell* find_seed_guesses(const Vert* const vertex,
			  const std::set<Cell*>* const guesses = NULL) const;

  //Finds a cell with vertex in its circumcenter with a cell by cell test.
  Cell* find_seed_naively(const Vert* const vertex) const;

  ///// END WATSON INSERTION DECLARATIONS ///// 

 public:
  
  //The following two are called by InsertionQueue to add encroached entities
  //at the top of the priority queue. The new mesh refinement implementation in 
  //TriMeshRefiner no longer queues encroached entities. These functions are 
  //no longer necessary. The implementation is commented out in Mesh2D.cxx

  int iQueueEncroachedBdryEntities(InsertionQueue&) const;
  virtual int iQueueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&) const {
    vFatalError("Function no longer defined in 2D",
		"Mesh2D::iQueueEncroachedBdryEntities()");
  }

  virtual int iQueueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&,
					   const double[],
					   const double) const {
    vFatalError("Function no longer defined in 2D",
		"Mesh2D::iQueueEncroachedBdryEntities()");
  }



  IntBdryEdge* pIBEIntBdryEdge(const GR_index_t i) const;

  void vSetupVerts(const GR_index_t i) {ECVerts.vSetup(i);}
  void vSetupFaces(const GR_index_t i)     {ECEdgeF .vSetup(i);}
  void vSetupBFaces(const GR_index_t i)    {ECEdgeBF.vSetup(i);}
  void vSetupIntBFaces(const GR_index_t i)    {ECIntEdgeBF.vSetup(i);}
  void vSetupTriCells(const GR_index_t i)  {ECTri   .vSetup(i);}
  void vSetupQuadCells(const GR_index_t i) {ECQuad  .vSetup(i);}

  /// Add entries to connectivity tables
  Face*    pFNewFace(const int iNV = 2);
  BFace* pBFNewBFace(const int iNBV = 2);
  IntBdryEdge* pIBENewIntBdryEdge(const int iNBV = 2);
  Cell*    pCNewCell(const int iNF = 3);

  /// Prints a summary of the patches...
  void vCheckPatches();
  /// Take cell-vert data and convert in into a 2D connectivity
/*   virtual void vConvertFromCellVert(const EntContainer<TriCellCV>& ECTriCV, */
/* 				    const EntContainer<QuadCellCV>& ECQuadCV */
/* 				    = EntContainer<QuadCellCV>(), */
/* 				    const EntContainer<EdgeBFaceCV>& ECBFCV */
/* 				    = EntContainer<EdgeBFaceCV>()); */


  /// Clear and recompute periodic face pairs.
  /// Deliberately left blank because periodic meshing is now broken.
  void vResetPeriodicData() {}

  // Mesh optimization, point insertion, etc
///  virtual void vSwap(const int iMaxPasses = 10);
  bool qBdrySmooth(Vert* const pVBdry,
		   Face* const pFBdry,
		   BdryEdge* const pBE_Init);

  int iReconfigure(Face*& pF);
  ///
  bool qRecoverEdge(const int iV0, const int iV1);
  bool qRecoverEdge(Vert* const pV0, Vert* const pV1);
  bool qRecoverEdge(Vert* const pV0, Vert* const pV1,
		    Face*& pF);
  ///
  bool qRemoveEdge(Face *& pF);

  bool qRemoveVertCheaply(Vert* const pV, int& iNewSwaps);
  ///
  void vInsertWatsonInterior(Vert* const pVNew,
			     const List<Cell*>& LpCToRemove,
			     const List<Face*>& LpFToRemove,
			     const List<Face*>& LpFHull);
public:
  /// PreProcessing for Ruppert - 1
  void vCheckForLargeAngles(const double dMaxAngle = M_PI_2); // 90 deg
  /// PreProcessing for Ruppert - 2
  void vCheckForSmallAngles();
  /// Performs Ruppert's algorithm on the mesh..
  bool qRuppert(const int iNumInsertions = 0);

  ///
  bool qCellRuppertBad(const Cell *pC, bool *qInCorner);
  //
  // The following three functions are used in the experimental
  // anisotropic meshing code.
  void vGenerateAnisotropic(const int iNStructBC, const int aiStructBC[],
			    const double dScale, const double dGrading);
  Vert *pVInsertNearVert(Vert* const pVOldVert, const double adNewPoint[]);
  void vRefineBoundaryToLengthScale(const int iNStructBC,
				    const int aiStructBC[]);

  bool qCreateQuadFromTris(Cell* const pCA, Cell* const pCB);
  bool qCreateQuadFromVerts(Vert* const pVA, Vert* const pVB,
			    Vert* const pVC, Vert* const pVD);

  void vSetLSChecking(bool qCheck);

 protected:
  
  ///The following functions are defined in Insert2D.cxx
  ///
  int iInsertOnBdryFace(Vert* const pVNew, Face* const pF,
			Cell* const pC, const bool qSwap, const bool qForce);
  ///
  int iInsertOnFace(Vert* const pVNew, Face* const pF, Cell* const pC,
		    const bool qSwap = true, const bool qForce = false);
  ///
  int iInsertInInterior(Vert* const pVNew, Cell* const pC,
			const bool qSwap);
  ///
  int iInsertOnInternalBdryFace(Vert* const pVNew, Face* const pF,
				const bool qSwap, const bool qForce);
protected:
  void vGetBdry2DInfo(const Bdry2D& B2DInfo);

  ///
 
public:

  void vWriteBdryPatchFile(const char strBaseFileName[], 
			   const char strExtraFileSuffix[]) const;

public:
  /// Iterator functions
  EntContainer<EdgeFace>::iterator edgeFace_begin() const
  { return ECEdgeF.begin(); }
  EntContainer<EdgeFace>::iterator edgeFace_end() const
  { return ECEdgeF.end(); }
};

/** Unlikely ever to be called from user code. */
/// Write as dictated by a file format template.  Deprecate?
void vWriteFile_Mesh2D(Mesh2D & Mesh,
		       const char strBaseFileName[],
		       const char strExtraFileSuffix[] = "");
/// Write a file in GRUMMP native format
void writeNative(Mesh2D& OutMesh,
		 const char strBaseFileName[],
		 const bool qHighOrder = true,
		 const char strExtraFileSuffix[] = "");
/// Write a file in generic finite element (cell-vertex) format
void writeFEA(Mesh2D& OutMesh,
	      const char strBaseFileName[],
	      const int iOrder = 2,
	      const char strExtraFileSuffix[] = "");
/// Write a file in the VTK legacy format (.vtk, uncompressed)
void writeVTKLegacy(Mesh2D& OutMesh,
		    const char strBaseFileName[],
		    const char strExtraFileSuffix[] = "");

/// Read as dictated by a file format template; needs translation backend.
void vReadFile_Mesh2D(const char * const strBaseFileName,
		      int& iNumVerts,
		      int& iNumFaces,
		      int& iNumCells,
		      int& iNumBdryFaces,
		      int& iNumIntBdryFaces,
		      bool& qFaceVert,
		      bool& qCellVert,
		      bool& qFaceCell,
		      bool& qCellFace,
		      bool& qCellRegion,
		      bool& qBFaceFace,
		      bool& qBFaceVert,
		      bool& qBFaceBC,
		      bool& qIntBFaceFace,
		      bool& qIntBFaceVert,
		      bool& qIntBFaceBC,
		      EntContainer<Vert>& ECVerts,
		      int (*&a2iFaceVert)[2],
		      int (*&a2iFaceCell)[2],
		      int (*&a2iCellVert)[3],
		      int (*&a2iCellFace)[3],
		      int *&aiCellRegion,
		      int *&aiBFaceFace,
		      int *&aiBFaceBC,
		      int (*&a2iBFaceVert)[2],
		      int (*&a2iIntBFaceFace)[2],
		      int *&aiIntBFaceBC,
		      int (*&a2iIntBFaceVert)[2]);

/// Read a file in GRUMMP native format
void readNative(Mesh2D& OutMesh,
		const char strFileName[]);

/// Read a file in generic finite element (cell-vertex) format
void readFEA(Mesh2D& OutMesh,
	     const char strFileName[]);

/// Read a file in the VTK legacy format (.vtk, uncompressed)
void readVTKLegacy(Mesh2D& OutMesh,
		   const char strFileName[]);


#endif
