#ifndef GR_Mesh
#define GR_Mesh 1

#include <map>
#include <set>

#include "GR_config.h"
#include "GR_BFace.h"
#include "GR_Cell.h"
#include "GR_EntContainer.h"
#include "GR_Face.h"
#include "GR_Observable.h"
#include "GR_Quality.h"
#include "GR_Vertex.h"
#include "GR_VertTree.h"
#include "OptMS.h"
#include "SMsmooth.h"

enum eSwap {eNone, eDelaunay, eMaxDihed, eMinSine, eFromQual, eRandom};
typedef double (*GR_LSfunc) (const double *adLoc);  // VC7

/**\brief This is the base class for all mesh data.
 *
 * Vertex data is the primary thing stored internally; connectivity data is
 * declared in the derived classes.
 */
// The publishing side of the Observer paradigm is implemented in the
// Observable class.
class Mesh : public GRUMMP::Observable {
private:
  /// Operator= disallowed.
  Mesh& operator=(const Mesh&) {assert(0); return(*this);}
protected:
  std::set<Vert*> spVUpdateLS;
  ///
  void *pvSmoothData;
  /// Variable-sized array for storing vertex data.
  EntContainer<Vert> ECVerts;
  ///
  double dLengthFactor;
  GR_LSfunc dfLengthScale;    // VC7
  /// Grading constant
  double dLipschitzAlpha;
  /// Quality measure.
  mutable Quality *pQ;
public:
  void vSetAlpha(const double dA) {dLipschitzAlpha = dA;}
  double dAlpha() const {return dLipschitzAlpha;}
protected:
  /// Resolution constant
  double dMeshResolution;
protected:
  int iIntSkip;
  bool qBdryFill:1;
  ///
  bool qSwapRecur:1;
  ///
  bool qAllowBdryChanges:1;
  ///
  bool qLengthScaleInitialized:1;
  bool qLengthScaleFromCellSizes:1;
  ///
  bool qSimplex:1;
  ///
  eSwap eSwapMeasure:3;
  ///
  eEncroachType eEncType:3;
/// Constructor and destructor
public:
  enum eMeshType {eMesh2D, eSurfMesh, eVolMesh};
  enum eInsertType {eBadCell, eBdryFaceEncroach, eBdrySegEncroach};
  ///
  Mesh() :
    spVUpdateLS(), pvSmoothData(NULL), ECVerts(),
    dLengthFactor(1), dfLengthScale(NULL), dLipschitzAlpha(1), 
    pQ(NULL), dMeshResolution(1), iIntSkip(3), qBdryFill(true),  qSwapRecur(true),
    qAllowBdryChanges(true), qLengthScaleInitialized(false),
    qLengthScaleFromCellSizes(false),
    qSimplex(true), eSwapMeasure(eDelaunay), eEncType(eLens)
    {
      // The value of iIntSkip is the correct default for all meshes.
      // The value of qBdryFill is the proper default for 2D and surface;
      // the 3D constructors override this.
      // Can't initialize Quality at the Mesh level.      
    }
  ///
  Mesh(const EntContainer<Vert>& ECPts) :
    spVUpdateLS(), pvSmoothData(NULL), ECVerts(), 
    dLengthFactor(1), dfLengthScale(NULL), dLipschitzAlpha(1),
    pQ(NULL), dMeshResolution(1), iIntSkip(3), qBdryFill(true), qSwapRecur(true),
    qAllowBdryChanges(true), qLengthScaleInitialized(false),
    qLengthScaleFromCellSizes(false),
    qSimplex(true), eSwapMeasure(eDelaunay), eEncType(eLens)
    {
      // The value of iIntSkip is the correct default for all meshes.
      // The value of qBdryFill is the proper default for 2D and surface;
      // the 3D constructors override this.
      int iDim = ECPts.getEntry(0)->iSpaceDimen();
      // The following line may be a problem for surface meshes.
      SMinitSmoothing(iDim, 'f', OPTMS_DEFAULT, OPTMS_DEFAULT, &pvSmoothData);
      for (GR_index_t i = 0; i < ECPts.lastEntry(); i++) {
	Vert *pVOld = ECPts.getEntry(i);
	Vert *pVNew = ECVerts.getNewEntry();
	pVNew->vSetCoords(iDim, pVOld->adCoords());
	pVNew->vCopyAllFlags(pVOld);
	// Don't copy vertex data any deeper than this.
      }
    }
  ///
  Mesh(const Mesh& M) :
    spVUpdateLS(M.spVUpdateLS), pvSmoothData(NULL), 
    dLengthFactor(M.dLengthFactor), dfLengthScale(M.dfLengthScale),
    dLipschitzAlpha(M.dLipschitzAlpha), pQ(NULL),
    dMeshResolution(M.dMeshResolution), iIntSkip(M.iIntSkip),
    qBdryFill(M.qBdryFill), qSwapRecur(M.qSwapRecur),
    qAllowBdryChanges(M.qAllowBdryChanges),
    qLengthScaleInitialized(M.qLengthScaleInitialized),
    qLengthScaleFromCellSizes(M.qLengthScaleFromCellSizes),
    qSimplex(M.qSimplex),
    eSwapMeasure(M.eSwapMeasure), eEncType(M.eEncType)

    {
      int iDim = M.ECVerts.getEntry(0)->iSpaceDimen();
      for (GR_index_t i = 0; i < M.ECVerts.lastEntry(); i++) {
	Vert *pVOld = M.ECVerts.getEntry(i);
	Vert *pVNew = ECVerts.getNewEntry();
	pVNew->vSetCoords(iDim, pVOld->adCoords());
	pVNew->vCopyAllFlags(pVOld);
	// Don't copy vertex data any deeper than this.
      }
      SMsmooth_data *pSMSmooth = static_cast<SMsmooth_data*>(M.pvSmoothData);
      int iFunc = pSMSmooth->smooth_param->function_id;
      int iTech = pSMSmooth->smooth_param->smooth_technique;
      double dAcceptValue = pSMSmooth->smooth_param->lap_accept_value;
      SMconvertToDegrees(static_cast<SMsmooth_data *>(pSMSmooth)->smooth_param
			 ->function_id, &dAcceptValue);
      SMinitSmoothing(iDim, iTech, iFunc, dAcceptValue, &pvSmoothData);
      SMinitGlobalMinValue(pvSmoothData);

      pQ = new Quality(*M.pQ);
      pQ->vSetMesh(this);
    }
  ///
  virtual ~Mesh()
    {
      if (pvSmoothData) SMfinalizeSmoothing(pvSmoothData);
      if (pQ) delete pQ;
    }
/// Inquiry functions
public:

  ////////////////////////////////////////////////////////
  /// Functions that directly query the mesh database. ///
  ////////////////////////////////////////////////////////
  
  ///
  const EntContainer<Vert>* pECGetVerts() const {return (&ECVerts);}
  ///checks all verts until (if) it finds pV. slow...
  bool qHasVert(const Vert* const pV) const;
  ///
  GR_index_t iVertIndex(const Vert* const pV) const
  { return (ECVerts.getIndex(pV)); }
  ///
  virtual GR_index_t iFaceIndex(const Face* const pF) const = 0;
  ///
  virtual GR_index_t iBFaceIndex(const BFace* const pBF) const = 0;
  ///
  virtual GR_index_t iCellIndex(const Cell* const pC) const = 0;
  ///
  virtual bool qIsValidEnt(void* pvEnt) const = 0;
  ///
  virtual eMeshType eType() const = 0;
  ///
  /// perimeter length or  area:
  virtual double dBoundarySize() const {assert(0); return 0;}
  /// interior   area  or volume:
  virtual double dInteriorSize() const  {assert(0); return 0;}
  virtual bool qWatertight() const  {assert(0); return 0;}
  /// 
  /// Validity checking
  virtual bool qValid() const = 0;
  ///
  int iNumFacesNonDelaunay() const;

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////
  /// Create a vertex at the given location.
  virtual Vert* createVert(const double dX, const double dY,
			   const double dZ) = 0;
  virtual Vert* createVert(const double adCoords[]) = 0;
/*   virtual Face* createFace(Vert * const apV[], const int iNVerts) = 0; */
  virtual BFace* createBFace(Face * const pF,
			     BFace * const pBF = pBFInvalidBFace) = 0;
/*   virtual Cell* createCell(Face * const apF[], const int iNFaces, */
/* 			   const int iReg = iDefaultRegion) = 0; */
/*   virtual Cell* createCell(Vert * const apV[], const int iNVerts, */
/* 			   const int iReg = iDefaultRegion) = 0; */
  virtual bool deleteVert(Vert * const pV) = 0;
  virtual bool deleteFace(Face * const pF) = 0;
  virtual bool deleteBFace(BFace * const pBF) = 0;
  virtual bool deleteCell(Cell * const pC) = 0;
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  
  /// The following routine adds bdry faces where needed after ITAPS
  /// modification.  Doesn't put BFaces on the right patches, though...
  void vCheckForITAPSBdryErrors();
  ///
  virtual void vPurgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL) = 0;
  ///
  virtual void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL) = 0;
  ///
  virtual void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL) = 0;
  ///
  virtual void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL) = 0;
  ///
  virtual void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL,
		      std::map<BFace*, BFace*>* bface_map = NULL) = 0;

  ///
  void vReorder(void) {
    vReorderVerts_RCM();
    vReorderCells();
    vReorderFaces();

    //Modified by SG July 2007:
    //The following seems to be used to keep consistent face normal orientation.
    //However, the most recent iteration of the 2D tri meshing code with curved boundaries 
    //needs to go through BdryEdge and IntBdryEdge objects to obtain normals. To achieve this,
    //the faces must be oriented in the SAME direction as their underlying curve. 
    //Interchanging the vertices will in obviously change the face orientation and
    //therefore, the normal direction will become inconsistent. Hence, the skipping of this
    //piece of code for 2D triangular meshes.

    if(eType() == Mesh::eMesh2D) return;

    for (GR_index_t iF = 0; iF < iNumFaces(); iF++) {
      Face *pF = pFFace(iF);
      if (pF->qIsBdryFace() && pF->pCCellLeft()->qIsBdryCell()) {
	pF->vInterchangeCellsAndVerts();
      }
    }

  }
 protected:
  virtual void vReorderVerts_RCM(void) = 0;
  virtual void vReorderCells(void) = 0;
  virtual void vReorderFaces(void) = 0;
 public:
  ///

  void vSetAllHintFaces();
  void vClearAllHintFaces();

  virtual void vSetVertFaceNeighbors();
  void vClearVertFaceNeighbors();

  ////////////////////////////////////////////////////////
  /// Functions that affect the behavior of algorithms ///
  ////////////////////////////////////////////////////////

  ///
  eSwap eSwapType() const {return eSwapMeasure;}
  ///
  void vSetSwapType(const eSwap eSwapIn) {eSwapMeasure = eSwapIn;}
  ///
  bool qBdryChangesAllowed() const {return qAllowBdryChanges;}
  ///
  void vAllowBdryChanges() {qAllowBdryChanges = true;}
  ///
  void vDisallowBdryChanges() {qAllowBdryChanges = false;}
  ///
  bool qSwapRecursionAllowed() const {return qSwapRecur;}
  ///
  void vAllowSwapRecursion() {qSwapRecur = true;}
  ///
  void vDisallowSwapRecursion() {qSwapRecur = false;}
  ///
//void vSetLengthFunc(double (*dfLengthFuncIn)(const double *adLoc))
  void vSetLengthFunc(GR_LSfunc dfLengthFuncIn)   // VC7
    { dfLengthScale = dfLengthFuncIn; dLengthFactor = 1.; }
  double dLengthScale(const double *adLoc) const
    { return dLengthFactor*dfLengthScale(adLoc); }
  void vInitLengthScale(const double dRes = 1, const double dGrade = 1);
  void vRecomputeLengthScale();
  void vUpdateLengthScale(Vert * const pV = pVInvalidVert);
  /// FIX ME:  The following interface is a kludge so that 2D meshing
  //  can easily use the new length scale stuff.  This should go away
  //  once 2D is also using the new insertion code.
  void vUpdateLengthScale(std::set<Vert*>& spV);
  void vSetLengthScale(Vert * const pV);
  void vSetLengthScale(const double dLen);
  void vMarkForLengthScaleCheck(Vert * const pV) {
    spVUpdateLS.insert(pV);
  }
  void vUpdateInfluence();
  void vCheckEdgeLengths() const;
  /// Return the number of vertices in the database; some may be deleted.
  GR_index_t iNumVerts() const {return ECVerts.lastEntry();}

  /// Return the number of faces in the database; some may be deleted.
  virtual GR_index_t iNumFaces() const = 0;
  ///
  virtual GR_index_t iNumBdryFaces() const = 0;
  ///
  virtual GR_index_t iNumIntBdryFaces() const = 0;
  ///
  GR_index_t iNumTotalBdryFaces() const {return iNumBdryFaces() + iNumIntBdryFaces();}

  /// Return the number of cells in the database; some may be deleted.
  virtual GR_index_t iNumCells() const = 0;

  /// Return a cell by index.
  virtual Cell* pCCell(const GR_index_t i) const = 0;

  /// Return a vertex by index.
  Vert* pVVert(const GR_index_t i) const {return ECVerts.getEntry(i);}

  /// Return a face by index.
  virtual Face* pFFace(const GR_index_t i) const = 0;

  /// Return the handle of an unused vertex in the database.
  Vert* pVNewVert()
    {
      Vert *pV = ECVerts.getNewEntry();
      pV->vSetDefaultFlags();
      return (pV);
    }
  ///
  virtual BFace* pBFBFace(const GR_index_t i) const = 0;
  /// Conversion to/from simplicial form
  bool qSimplicial() const {return qSimplex;}
  ///
  virtual void vMakeSimplicial() {assert(0);}
  ///
  void vAllowNonSimplicial() {qSimplex = false;}
  ///
  void vSetQualityMeasure(const int iQual) {
    delete pQ;
    pQ = new Quality(this, iQual);
  }
  void vEvaluateQuality() const {pQ->vEvaluate();}
  double dEvaluateQuality(const CellSkel* const pCS) const
    {return pQ->dEvaluate(pCS);}
  void vImportQualityData(const double adData[]) const
    {pQ->vImportQualityData(adData);}
  void vWriteQualityToFile(const char strQualFileName[]) const
    {pQ->vWriteToFile(strQualFileName);}
public:
  /// Mesh optimization routines
  virtual bool qDoSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE = pVInvalidVert) const = 0;
  virtual int iFaceSwap(Face*& pF) = 0;
  ///
public:
  // Generic insertion
  virtual bool qInsertPoint(const double adPoint[], Cell* const pCGuess,
			    int * const piSwaps, const bool qSwap = true,
			    const bool qForce = false,
			    Vert* pVNew = pVInvalidVert) = 0;
  virtual int iInsertPointWatson(WatsonInfo&) = 0;
  // Generic Watson hull cleanup, probably only needs to be implemented in 3D.
  virtual void vCleanupWatson(WatsonInfo&) {}
  virtual void vGetWatsonData(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const = 0;
  // Use this next function to clear out all points lying within a given
  // ball when doing insertion on / near boundaries.  Returns true iff
  // the ball has no interior points left.
  virtual bool qDeleteInteriorPointsInBall(const Cell *pCSeed,
					   const double adLoc[],
					   const double dRadius,
					   int& iNDeleted) = 0;
  int iQueueEncroachedBdryEntities(InsertionQueue&) const;
  virtual int iQueueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&) const = 0;
  virtual int iQueueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF,
					   const double adLoc[],
					   const double dOffset = 0) const = 0;
  ///
  void vSetEncroachmentType(const eEncroachType eET) { eEncType = eET; }
  eEncroachType eEncroachmentType() const {return eEncType;}

  // The worst shape quality measure (shortest edge to circumradius) allowed.
  virtual double dWorstAllowedCellShape() const = 0;
  // Mesh coarsening routines
private:
  int iMarkChain(Vert * const pVSurf, Vert * const pVFirst,
		 const VertConnect aVC[],
		 const double dMaxDist, const int iSkipNum);
  void vDeactivateChain(Vert * const pVSurf, Vert * const pVFirst,
			const VertConnect aVC[], const double dMaxDist) const;
  void vAddNormalVerts(const VertConnect aVC[],
		       const Vert::VertType VTVertTypeToStartFrom);
  void vAddToCoarseVerts(const VertConnect aVC[]) const;
  void vSelectCoarseVerts(VertConnect aVC[]);
  void vDeactivateAll() const;
  int iActivate(const Vert::VertType VT) const;
  int iInteriorSkip() const {return iIntSkip;}
  bool qBoundaryFill() const {return qBdryFill;}
  virtual Cell* pCBeginPipe(const Vert* const pVLast,
			    const Vert* const pVNew) const = 0;
public:
  void vSetInteriorSkip(const int iNewSkip)
    {
      assert(iNewSkip > 0);
      iIntSkip = iNewSkip;
    }
  void vSetBoundaryFill(const bool qNewFill) {qBdryFill = qNewFill;}
  virtual double dCoarsenConstant() const = 0;
  void vCoarsen(const double dLengthRatio = 2);
  void vCoarsenToLengthScale(const bool qHeal = false);
  virtual void vIdentifyVertexTypesGeometrically() const = 0;
  void vInitConflictGraph(VertConnect aVC[]) const;
  void vUpdateConflictGraph(VertConnect aVC[]) const;
  void vRemoveTaggedVerts();
  virtual GR_index_t iNumBdryPatches() = 0;
  virtual void vBuildBdryPatches() {}
  virtual bool qRemoveVertByContraction(Vert * const pV, int& iNewSwaps,
					Vert * apVPreferred[] = NULL,
					const int iNPref = 0) = 0;
  virtual bool qRemoveVert(Vert * const pV, int& iNewSwaps) = 0;
// Mesh smoothing routines
  virtual void vSetSmoothingGoal(const int iGoal) = 0;
  void vSetSmoothingTechnique(const int iTech)
    {
      SMsetSmoothTechnique(pvSmoothData, iTech);
    }
  void vSetSmoothingThreshold(const double dThresh)
    {
      SMsetSmoothThreshold(pvSmoothData, dThresh);
    }
  void vResetThreshold()
    {
      // For floating threshold after at least one smoothing pass, this
      // will reset the threshold using the global minimum value from
      // the last pass.  In other cases, the threshold value remains
      // unchanged.
      double dThresh =
	(static_cast<SMsmooth_data*>(pvSmoothData))->
	smooth_param->lap_accept_value;
      SMconvertToDegrees((static_cast<SMsmooth_data *>(pvSmoothData))
			 ->smooth_param->function_id, &dThresh);
      SMsetSmoothThreshold(pvSmoothData, dThresh);
    }
  virtual int iSmooth(const int iMaxPasses = 10) = 0;
  virtual int iSwap(const int iMaxPasses = 2,
		    const bool qAlreadyMarked = false) = 0;
// Mesh adaptation and related routines
  virtual bool qDelaunayize() = 0;
  virtual void vAdaptToLengthScale(const eEncroachType eET);
};

/// Return info about entities in the one-cell ball around the vertex.
void vNeighborhood(const Vert* const pVert,
		   std::set<Cell*>& spCInc,
		   std::set<Vert*>& spVNeigh,
		   std::set<BFace*>* pspBFInc = NULL,
		   bool *pqBdryVert = NULL,
		   std::set<Face*>* pspFNearby = NULL);

#endif // Done with class Mesh
