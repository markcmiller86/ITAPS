/* include/SUMAA_config.h.  Generated from SUMAA_config.h.in by configure.  */
#ifndef CONFIG_H_SUMAA
#define CONFIG_H_SUMAA

/* Whether logging is done at all is controlled by a configure-time
   option (--enable-logging).  By default, this is enabled at
   configure-time.*/  
#ifndef SUMAA_LOG
/* #undef SUMAA_LOG */
#endif

/* Lite logging is used whenever logging is done. */
#ifdef SUMAA_LOG
#ifndef SUMAA_LOG_LITE
#define SUMAA_LOG_LITE
#endif
#endif

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
/* #undef TIME_WITH_SYS_TIME */

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

#ifndef __cplusplus
/* Define to empty if the const keyword is broken in the C compiler */
/* #undef const */
#endif

/* #undef SUNOS4 */
/* #undef SOLARIS2 */
/* #undef LINUX */
/* #undef IRIX5 */
/* #undef IRIX6 */
/* #undef HPUX10 */
/* #undef OSF4 */
/* #undef AIX */

#if (defined(IRIX5) || defined(IRIX6))
#define IRIX
#endif

#if defined(SUNOS4)
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
  int fprintf(FILE*,const char*,...);
  int fflush(FILE*);
  int fclose(FILE*);
  int printf(const char *,...);
#ifdef __cplusplus
}
#endif
#endif

/*  #if defined(SUNOS4) && !defined(__cplusplus) */
/*      extern int gettimeofday(struct timeval *, struct timezone *); */
/*  #endif */

/*  #if (defined(SOLARIS2) || defined(SUNOS4)) && defined(__cplusplus) */
/*      extern "C" {extern int gettimeofday(struct timeval *, struct timezone *);} */
/*  #endif */

/*  #if defined(rs6000) */
/*  #if defined(__cplusplus) */
/*          extern "C" { extern UTP_readTime(struct timestruc_t *); } */
/*  #else */
/*          extern UTP_readTime(struct timestruc_t *); */
/*  #endif */
/*  #endif */

#endif
