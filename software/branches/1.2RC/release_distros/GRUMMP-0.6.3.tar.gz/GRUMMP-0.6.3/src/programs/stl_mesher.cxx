#include "GR_config.h"
#include "GR_misc.h"

#include "AppUtil.hpp"
#include "CGMApp.hpp"
#include "DLIList.hpp"
#include "GeometryQueryTool.hpp"
#include "FacetEvalTool.hpp"
#include "FacetQueryEngine.hpp"
#include "FacetSurface.hpp"
#include "RefFace.hpp"

#include "GR_AdaptPred.h"
#include "GR_GraphicsOut.h"
#include "GR_Subseg.h"
#include "GR_SurfMeshBuilder.h"
#include "GR_TetMeshBuilder.h"
#include "GR_TetMeshRefiner.h"
#include "GR_VolMesh.h"

int main(int argc, char** argv) {

  if(argc < 2) 
    vFatalError("No input boundary file name specified", "main2.cxx");
  
  vGRUMMPInit("stl_mesher");

  AppUtil::instance()->startup(argc, argv);
  CGMApp::instance()->startup(argc, argv);

  char* facet_filename = argv[1];
  char baseFileName[1024], qualFileName[1024];
  CubitBoolean use_feature_angle = CUBIT_TRUE;
  double feature_angle = 135.;
  double tolerance = 1.e-6;
  int interp_order = 4;
  CubitBoolean smooth_non_manifold = CUBIT_TRUE;
  CubitBoolean split_surfaces = CUBIT_FALSE;
  CubitBoolean stitch = CUBIT_TRUE;
  CubitBoolean improve = CUBIT_TRUE;
  DLIList<CubitQuadFacet*> quad_facet_list;
  DLIList<CubitFacet*> tri_facet_list;
  DLIList<Surface*> surface_list;
  FacetFileFormat file_format = STL_FILE;  

  char* baseNameEnd = strstr(facet_filename, ".stl");
  if (baseNameEnd == NULL)
    vFatalError("Input boundary file appears not to be an STL file",
		"stl_mesher.cxx");
  int len = baseNameEnd - facet_filename;
  if (len > 1023) len = 1023;
  strncpy(baseFileName, facet_filename, len);
  baseFileName[len] = 0;

  vOpenMessageFile(baseFileName);
  vMakeFileName(qualFileName, "%s.qual", baseFileName, "main() [tetra.C]");  

  if(interp_order == 0 && feature_angle < 145.) {
    printf("\n\n");
    printf("Using facetted curves and surfaces without interpolation\n");
    printf("Feature detection angle is set to %.2lf\n", feature_angle);
    printf("Tangent-based curve discretization is impossible in these conditions.\n");
    printf("Please set feature detection angle to a value less than 145 degrees.\n");
    printf("\n\n");
    abort();
  }

  //This is the call to CGM to build the geometry from
  //a facetted surface representation.

  GeometryQueryTool *gqt = GeometryQueryTool::instance();
  FacetQueryEngine  *fqe = FacetQueryEngine::instance();

  fqe->import_facets( facet_filename, use_feature_angle, feature_angle,
		      tolerance, interp_order,
		      smooth_non_manifold, split_surfaces,
		      stitch, improve,
		      quad_facet_list, tri_facet_list, surface_list,
		      file_format );

  //Set the compare tolerance to a lower value for all FacetSurface.
  //This is needed to project points onto the surface interpolated from facets.
  DLIList<RefFace*> all_surfaces;
  gqt->ref_faces(all_surfaces);
  int num_surfaces = all_surfaces.size();
  RefFace* surface;
  FacetSurface* facet_surface;
  for(int i = 0; i < num_surfaces; ++i) {
    surface = all_surfaces.get_and_step();
    facet_surface = dynamic_cast<FacetSurface*>(surface->get_surface_ptr());
    assert(facet_surface);
    facet_surface->get_eval_tool()->compare_tol(1.e-14);
  }

  GraphicsOut go_surf("surf.vtk");
  GraphicsOut go_curv("curv.vtk");
  go_surf.output_faces();
  go_curv.output_edges(); 

  //Build the quality surface mesh and then the volumetric mesh
  //from the CGM geometry.

  //Variation of tangent angle for curve discretization.
  double allowed_TVT = 0.45 * M_PI;
  //Should curvature based sampling be used?
  bool curv_sampling = true;
  //The constant is used to control the length of edges emanating from
  //a surface vertex. The radius of curvature is evaluated at this vertex.
  //Edge lengths < radius of curvature * radius_ratio.
  double radius_ratio = 0.5;

  //Build surface mesh.
  SurfMeshBuilder* SMB = new SurfMeshBuilder(SurfMeshBuilder::FACET, allowed_TVT,
					     curv_sampling, radius_ratio);
  
  //Build tetrahedral mesh.
  std::set<Subseg*> mesh_subsegs;
  TetMeshBuilder* TMB = new TetMeshBuilder(SMB, &mesh_subsegs);

  //This deletes the current quality object and 
  //builds a new one with a new quality measure.
//   TMB->get_mesh()->vSetQualityMeasure(11);

  TMB->get_mesh()->vEvaluateQuality();

  TetMeshRefiner TMR(TMB->get_mesh(), &mesh_subsegs, eBall, 
		     PriorityCalculator::EDGE_RADIUS, 1., 1.);

  TMR.refine();

  TMR.get_mesh()->vClassifyTets();
  TMR.get_mesh()->vEvaluateQuality();  
  
  int num_swaps, num_smooth, num_passes = 2;

  //Swapping and smoothing

  for(int i = 0; i < num_passes; ++i) {
    //Swapping
    TMR.get_mesh()->vAllowSwapRecursion();
    TMR.get_mesh()->vSetSwapType(eMinSine);
    //   TMR.get_mesh()->vSetSwapType(eFromQual);
    num_swaps = TMR.get_mesh()->iSwap();
  
    //Smoothing
    TMR.get_mesh()->vSetSmoothingThreshold(30.);
    TMR.get_mesh()->vSetSmoothingTechnique('f');
    if(i == 0) TMR.get_mesh()->vSetSmoothingGoal(5);
//     else TMR.get_mesh()->vSetSmoothingGoal(7);
    num_smooth = TMR.get_mesh()->iSmooth(2);
  }    

  TMR.get_mesh()->vClassifyTets();
  TMR.get_mesh()->vEvaluateQuality();  
  
  TMR.get_mesh()->vWriteQualityToFile(qualFileName);

  TMR.print_quality_data();

  vWriteFile_VolMesh(*TMR.get_mesh(), baseFileName);

  //FIX ME:
  //have to delete this after mesh refinement, the mesh in TMB::m_mesh_init 
  //gets deleted otherwise (and the pointer is passed to TMR).
  delete TMB; 
  delete SMB;

  
  return 0;

}
