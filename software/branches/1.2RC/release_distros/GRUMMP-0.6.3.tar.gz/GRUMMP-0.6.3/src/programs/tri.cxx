#ifndef WIN32
#include <unistd.h>
#else /* WIN32 defined */
int getopt(int argc, char *argv[], char *opstring);
extern char * optarg;
#endif

#include <cstdlib>
#include <cmath>
#include <cstring>
#include "GR_config.h"
#include "GR_misc.h"
#include "GR_AdaptPred.h"
#include "GR_GRGeom2D.h"
#include "GR_Length2D.h"
#include "GR_Mesh2D.h"
#include "GR_TriMeshBuilder.h"
#include "GR_TriMeshRefiner.h"
#include "GR_SwapDecider.h"
#include "GR_SwapManager.h"

#ifdef IRIX
#include <getopt.h>
#endif

typedef struct _refinementInfo_ {
  double dX, dY, dLen;
} RefinementInfo;

static char GR_tri_Usage[][80] = {
  "    -i    Base file name for input file",
  " ",
  "  Boolean options (argument of 1 for true, 0 for false):",
  "    -A    Use adaptive precision geometric predicates [0]",
  "    -b    Allow boundary changes [1]",
  "    -c    Use diametral lenses instead of diametral circles [1]",
  "          This will push the minimum angle to 30 degrees (instead of 20)",
  "    -j    Coarsen quasi-structured mesh anisotropically [0]",
  "  ",
  "  Length scale options (values < 1 don't make sense):",
  "    -g #  Grading (rate of cell size change); larger is slower [1]",
  "    -r #  Resolution (feature size / cell size); larger is finer [1]",
  "    -m #  Specifies a minimum length scale [none]",
  " ",
  "  Adaptation option: (meshopt2d and tri only)",
  "    -l filename  Refine to length scale specified (per vertex) in file",
  " ",
  "    -o filename  Base file name for output file [input file base name]",
  " ",
  "    -q #  Mesh quality measure used [2]",
  "         0  Maximum angle",
  "         1  Minimum angle",
  "         2  All angles",
  "         6  Aspect ratio I (inscribed to circum radius)",
  "         9  Aspect ratio II (based on area versus perimeter)",
  "        10  Aspect ratio III (shortest edge to circumradius)",
  " ", 
  "  Output options:",
  "    -P    Output boundary patch file (0 = no, 1 = yes) [0]",
  " ",
  ""  // Must end with a null string.
};

static void vUsage(const char strCanonName[])
{
  vMessage(0, "Usage:  %s -i basefilename [options] \n", strCanonName);
  for (int i = 0; strlen(GR_tri_Usage[i]) > 0; i++) {
    vMessage(0, "%s\n", GR_tri_Usage[i]);
  }
  exit(1);
}

#include <map>
#include <vector>


#include <list>
#include <utility>
#include "GR_GRPoint.h"
#include "GR_GRCurve.h"
#include "GR_GRCurveGeom.h"
#include "CubitVector.hpp"

// static void output_geom(const GRGeom2D* const geom,
// 			const char* const filename) {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", "");

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 2\n");

//   std::list<GRCurve*> curves;
//   std::list< std::pair<int, int> > edges;
//   std::list<Vert*> verts;

//   geom->get_curves(curves);

//   for(std::list<GRCurve*>::iterator itc = curves.begin(); itc != curves.end(); ++itc) {

//     GRCurve* my_curve = *itc;
//     Vert *v1, *v2;
//     CubitVector coords1, coords2;
//     double min_param = my_curve->get_geometry()->min_param();
//     double max_param = my_curve->get_geometry()->max_param();	
//     int idx1, idx2;

//     if(my_curve->get_geometry()->get_curve_type() == GRCurveGeom::LINE) {
//       v1 = new Vert();
//       v2 = new Vert();
//       my_curve->get_geometry()->coord_at_param(min_param, coords1);
//       my_curve->get_geometry()->coord_at_param(max_param, coords2);			       
//       v1->vSetCoords(2, coords1);
//       v2->vSetCoords(2, coords2);
//       verts.push_back(v1);
//       idx1 = static_cast<int>(verts.size());
//       verts.push_back(v2);
//       idx2 = static_cast<int>(verts.size());
//       edges.push_back( std::make_pair(idx1, idx2) );
//     }

//     else {

//       v1 = new Vert();
//       my_curve->get_geometry()->coord_at_param(min_param, coords1);
//       v1->vSetCoords(2, coords1);
//       verts.push_back(v1);
//       idx1 = static_cast<int>(verts.size());

//       for(int i = 1; i < 100; ++i) {
// 	double this_param = i * (max_param - min_param) / 100;
// 	v2 = new Vert();
// 	my_curve->get_geometry()->coord_at_param(this_param, coords2);
// 	v2->vSetCoords(2, coords2);
// 	verts.push_back(v2);
// 	idx2 = static_cast<int>(verts.size());
// 	edges.push_back( std::make_pair(idx1, idx2) );
// 	idx1 = idx2;
//       }     

//       v2 = new Vert();
//       my_curve->get_geometry()->coord_at_param(max_param, coords2);
//       v2->vSetCoords(2, coords2);
//       verts.push_back(v2);
//       idx2 = static_cast<int>(verts.size());
//       edges.push_back( std::make_pair(idx1, idx2) );

//     }

//   }

//   int num_verts = verts.size();
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", num_verts);

//   for(std::list<Vert*>::iterator itv = verts.begin(); itv != verts.end(); ++itv) {
//     Vert* vertex = *itv;
//     fprintf(out_file, "%e %e 0\n", vertex->dX(), vertex->dY());
//   }

//   int num_edges = edges.size();
//   fprintf(out_file, "Edges\n");
//   fprintf(out_file, "%d\n", num_edges);

//   for(std::list< std::pair<int, int> >::iterator ite = edges.begin(); ite != edges.end(); ++ite) {
//     std::pair<int, int> my_pair = *ite;
//     fprintf(out_file, "%d %d 1\n", my_pair.first, my_pair.second);
//   }

//   fprintf(out_file, "End\n");

//   for(std::list<Vert*>::iterator itv = verts.begin(); itv != verts.end(); ++itv) {
//     if(*itv) delete *itv;
//   }

// }

// static void output_mesh(const Mesh2D* const mesh,
// 			const char* const filename) {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", "");

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 2\n");

//   Vert* vertex;
//   int vert_index = 0;
//   std::vector<Vert*> vertices;
//   std::vector<Vert*>::iterator itv, itv_beg, itv_end;
//   std::map<Vert*, int> verts_to_print;
  
//   for(int i = mesh->iNumVerts() - 1; i >= 0; --i) {
//     vertex = mesh->pVVert(i);
//     if(vertex->qDeleted()) continue;
//     vertices.push_back(vertex);
//     verts_to_print.insert( std::make_pair(vertex, ++vert_index) );
//   }  

//   itv_beg = vertices.begin();
//   itv_end = vertices.end();
//   int num_verts = static_cast<int>(itv_end - itv_beg);

//   fprintf(out_file, "#Set of mesh vertices\n");
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", num_verts);
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e 0\n", vertex->dX(), vertex->dY());
//   }

//   Cell* cell;
//   std::vector<Cell*> cells;
//   std::vector<Cell*>::iterator itc, itc_beg, itc_end;

//   for(int i = mesh->iNumCells() - 1; i >= 0; --i) {
//     cell = mesh->pCCell(i);
//     if(cell->qDeleted()) continue;
//     cells.push_back(cell);
//   }

//   itc_beg = cells.begin();
//   itc_end = cells.end();
//   int num_cells = static_cast<int>(itc_end - itc_beg);

//   fprintf(out_file, "#Set of triangles\n");
//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", num_cells);

//   for(itc = itc_beg; itc != itc_end; ++itc) {
//     cell = *itc;
//     assert(cell->iNumVerts() == 3);
//     int idx1 = verts_to_print.find(cell->pVVert(0))->second;
//     int idx2 = verts_to_print.find(cell->pVVert(1))->second;
//     int idx3 = verts_to_print.find(cell->pVVert(2))->second;
//     fprintf(out_file, "%d %d %d 0\n", idx1, idx2, idx3);
//   }

//   fprintf(out_file, "End\n");
//   fclose(out_file);

// }

int main(int iNArg, char *apcArgs[]) {

  char strBaseFileName[FILE_NAME_LEN], 
    strQualFileName[FILE_NAME_LEN],
    strBdryFileName[FILE_NAME_LEN],  
    strBaseOutFileName[FILE_NAME_LEN],
    strLengthFileName[FILE_NAME_LEN],
    strExecName[FILE_NAME_LEN],
    strCanonicalName[20];

  bool qReadOutFileName = false, 
    qReadAuxBdryFileName = false,
    qLengthScaleGiven = false,
    qAllowBdryChanges = true,
    qAnisoCoarsening = false,
    qOutputBPatchFile = false;

  int iQualMeasure = 2, iPreviousPasses = 0;
  double dScale = 1., dGrading = 1., dMinLength = -LARGE_DBL;
 
  enum eEncroachType eET = eLens;
  enum {UNKNOWN, TRI, MESHOPT, COARSEN, HEAL} iExec = UNKNOWN;

  qAdaptPred = false;

  sprintf(strExecName, "%s", apcArgs[0]);
  if (strstr(strExecName, "coarsen2d")) {
    iExec = COARSEN;
    sprintf(strCanonicalName, "coarsen2d");
  }
  else if (strstr(strExecName, "meshopt2d")) {
    iExec = MESHOPT;
    sprintf(strCanonicalName, "meshopt2d");
  }
  else if (strstr(strExecName, "tri")) {
    iExec = TRI;
    sprintf(strCanonicalName, "tri");
  }
  else if (strstr(strExecName, "heal2d")) {
    iExec = HEAL;
    sprintf(strCanonicalName, "heal2d");
  }
  else {
    vFatalError("Invalid executable name.  Be less creative renaming files.\n",
		"tri.cxx:main()");
  }

  vGRUMMPInit(strCanonicalName);

  int iPChar, iError = 1;
  while ((iPChar = getopt(iNArg, apcArgs, "A:b:B:c:g:i:j:l:o:m:P:q:r:")) != EOF) {
    switch (iPChar) {

    case 'A':
      qAdaptPred = (optarg[0] == '1');
      break;

    case 'b':
      qAllowBdryChanges = (optarg[0] == '1');
      break;

    case 'B':
      strncpy(strBdryFileName, optarg, FILE_NAME_LEN-1);
      qReadAuxBdryFileName = true;
      {
	int iDum;
	for (iDum = 0; iDum < FILE_NAME_LEN && strBdryFileName[iDum];
	     iDum++) {}
	if (iDum == FILE_NAME_LEN) // No null; file name too long
	  vFatalError("Boundary file name too long", "command line");
      }
      break;

    case 'c':
      switch (optarg[0]) {
      case '0':
	eET = eBall;
	break;
      case '1':
      default:
	eET = eLens;
	break;
      case '2':
	eET = eNewLens;
	break;
      }
      break;

    case 'g':
      sscanf(optarg, "%lf", &dGrading);
      if (dGrading < 1) dGrading = 1;
      break;

    case 'i':
      strncpy(strBaseFileName, optarg, FILE_NAME_LEN-1);
      {
	int iDum;
	for (iDum = 0; iDum < FILE_NAME_LEN && strBaseFileName[iDum];
	     iDum++) {}
	if (iDum == FILE_NAME_LEN) // No null; file name too long
	  vFatalError("Input file name too long", "command line");
      }
      iError--;
      break;

    case 'j':
      qAnisoCoarsening = (optarg[0] == '1');
      break;

    case 'l':
      if (iExec == MESHOPT || iExec == TRI) {
	strncpy(strLengthFileName, optarg, FILE_NAME_LEN-1);
	{
	  int iDum;
	  for (iDum = 0; iDum < FILE_NAME_LEN && strLengthFileName[iDum];
	       iDum++) {}
	  if (iDum == FILE_NAME_LEN) // No null; file name too long
	    vFatalError("Lengthscale file name too long", "command line");
	}
	qLengthScaleGiven = true;
      }
      else {
	iError += 10; // Be sure to crash out.
      }
      break;

    case 'm':
      sscanf(optarg, "%lf", &dMinLength);
      if (dMinLength <= 0) dMinLength = -LARGE_DBL;
      break;

    case 'o':
      strncpy(strBaseOutFileName, optarg, FILE_NAME_LEN-1);
      {
	int iDum;
	for (iDum = 0; iDum < FILE_NAME_LEN && strBaseFileName[iDum];
	     iDum++) {}
	if (iDum == FILE_NAME_LEN) // No null; file name too long
	  vFatalError("Output file name too long", "command line");
      }
      qReadOutFileName = true;
      break;

    case 'P' :
      qOutputBPatchFile = (optarg[0] == '1');
      break;

    case 'q':
      {
	int iTmp;
	sscanf(optarg, "%d", &iTmp);
	if (iTmp == 0 || iTmp == 1 || iTmp == 2 || iTmp == 6 || iTmp == 9
	    || iTmp == 10)
	  iQualMeasure = iTmp;
	break;
      }

    case 'r':
      sscanf(optarg, "%lf", &dScale);
      break;

    default:
      iError += 10;
      break;
    }
  }

  if (iError)
    vUsage(strCanonicalName);

  // File name manipulation
  vMakeFileName(strQualFileName, "%s.qual",
		strBaseFileName, "main() [tri.C]");

  if (!qReadOutFileName)
    strncpy(strBaseOutFileName, strBaseFileName, FILE_NAME_LEN-1);
  
  // Open input and log files
  vOpenMessageFile(strBaseFileName);
  vMessage(1, "Mesh quality output file: %s\n", strQualFileName);
  
  //Pointers to the geometry and mesh objects.
  GRGeom2D* pG2D = NULL;
  Mesh2D*   pM2D = NULL;
  
  //Build objects for triangular mesh generation.
  if (iExec == TRI) {    
    pG2D = new GRGeom2D(strBaseFileName);
    pM2D = new Mesh2D(); 
  }

  else { //coarsen2d or meshopt2d

    if (qReadAuxBdryFileName)
      pG2D = new GRGeom2D(strBdryFileName);
    else 
      pG2D = new GRGeom2D();
    
    // Reading an existing mesh file
    pM2D = new Mesh2D(strBaseFileName, pG2D, iQualMeasure);
    vMessage(1, "Number of cells read: %u\n", pM2D->iNumCells());

    pM2D->vEvaluateQuality();

  }
  
  assert(pM2D->qValid());

  if (qAllowBdryChanges)
    pM2D->vAllowBdryChanges();
  else
    pM2D->vDisallowBdryChanges();
  
  int iNumPasses = 5;
  switch (iExec) {
    
  case MESHOPT: 
    {
      pM2D->vInitLengthScale(1./dScale, 1./dGrading);
      pM2D->vSetSwapType(eDelaunay);
      GRUMMP::SwapDecider2D *pSD_Delaunay = new GRUMMP::DelaunaySwapDecider2D();
      GRUMMP::SwapManager2D SM_Delaunay(pSD_Delaunay, pM2D);
      int iNSwaps;
      //       clock_t clBegin = clock();
      iNSwaps = SM_Delaunay.swapAllFaces();
      vMessage(1, "Swapped %d times.\n", iNSwaps);
      //       clock_t clEnd = clock();
      //       vMessage(1, "Elapsed time %d clocks at %d per second.\n",
      // 	       clEnd - clBegin, CLOCKS_PER_SEC);
      pM2D->vEvaluateQuality();
      if (qLengthScaleGiven) {
	// Read it and store it.
	FILE *pFLenFile = fopen(strLengthFileName, "r");
	if (NULL == pFLenFile)
	  vFatalError("Couldn't open file for reading",
		      "length scale input");
	double dLen;
	int iV, iDataRead = fscanf(pFLenFile, "%d%lf", &iV, &dLen);
	int iNV = pM2D->iNumVerts();
	while (iDataRead == 2) {
	  if (iV < 0 || iV > iNV) {
	    vFatalError("Vertex index out of range",
			"length scale input");
	  }
	  Vert *pV = pM2D->pVVert(iV);
	  pV->vSetLS(dLen);
	  pM2D->vMarkForLengthScaleCheck(pV);
	  vMessage(4, "Set length scale for vert %d.\n", iV);
	  iDataRead = fscanf(pFLenFile, "%d%lf", &iV, &dLen);
	};
	pM2D->vUpdateLengthScale();
	pM2D->vCheckEdgeLengths();
	pM2D->vAdaptToLengthScale(eET);
      }
      break;
    }
    break;

  case TRI:
    {

      pM2D->vSetEncroachmentType(eET);
      
      TriMeshBuilder* TMB = new TriMeshBuilder(pG2D, pM2D);
      TMB->build_constrained_delaunay_triangulation();
      
      pM2D->vEvaluateQuality();

      Length2D* sizing_field = NULL; 
      TriMeshRefiner* TMR = NULL;

      if (qLengthScaleGiven) {

	sizing_field = new Length2D(Length2D::TREE, dScale, dGrading, dMinLength);

	FILE *pFLenFile = fopen(strLengthFileName, "r");
 	if (NULL == pFLenFile) vFatalError("Couldn't open file for reading",
					   "length scale input");
	
	double x_loc = -LARGE_DBL, y_loc = -LARGE_DBL, length = -LARGE_DBL;

	while(1) {
 	  int iDataRead = fscanf(pFLenFile, "%lf%lf%lf",
				 &(x_loc), &(y_loc), &(length));
	  if (iDataRead != 3) break;
	  sizing_field->add_to_length_tree(x_loc, y_loc, length);
	}
	fclose(pFLenFile);

	sizing_field->init_length(pM2D);

	TMR = new TriMeshRefiner(pM2D, sizing_field, false);
	TMR->refine_mesh();
	
      }

      else {
	//Refines the mesh with an automatic sizing field.
	sizing_field = new Length2D(Length2D::AUTOMATIC, dScale, dGrading, dMinLength);
	sizing_field->init_length(pM2D);

	TMR = new TriMeshRefiner(pM2D, sizing_field, false);
	TMR->refine_mesh();
      }

      delete sizing_field;
      delete TMR;
      delete TMB;
    
      pM2D->vEvaluateQuality();

      // Smoothing parameters for later
      pM2D->vSetSmoothingThreshold(40.);
      pM2D->vSetSmoothingTechnique('o');
      
//       iNumPasses = 1;

      pM2D->vPurge();
      vMessage(1,"Number of triangles after refinement:  %u\n",
	       pM2D->iNumCells());

    }
    break;

  case COARSEN:

//     pM2D->vInitLengthScale(1.0/dScale, 1.0/dGrading);
//     pM2D->vSetSmoothingThreshold(25.);

//     if (qAnisoCoarsening) {
//       pM2D->vSetInteriorSkip(3);
//       pM2D->vSetBoundaryFill(true);
//     }
//     else {
//       pM2D->vSetInteriorSkip(1);
//       pM2D->vSetBoundaryFill(false);
//     }

//     pM2D->vCoarsen();
//     vMessage(1, "Number of cells after coarsening: %d\n", pM2D->iNumCells());

//     pM2D->vSetSwapType(eMaxDihed);
//     pM2D->iSwap();
//     pM2D->vEvaluateQuality();

//     iNumPasses = 5;
//     iPreviousPasses = 2;
    break;

  case HEAL:
//     pM2D->vSetLengthScale(7.5);

// //     {
// //       // Total hack job for simulating mesh adaptation.
// //       for (int ii = 0; ii < pM2D->iNumVerts(); ii++) {
// //	Vert *pV = pM2D->pVVert(ii);
// //	double dX = pV->dX();
// //	double dY = pV->dY();
// //	double dX_star = 250 - (dY-541)*(dY-541) / 130;
// //	double dLen;
// //	if (dX < dX_star) {
// //	  dLen = 1. / (0.125 + 10*exp(-0.5*(dX_star - dX)));
// //	}
// //	else {
// //	  dLen = 1. / (0.05 + 10*exp(-(dX-dX_star)/3.));
// //	}
// //	pV->vSetLS(dLen);
// //       }
// //     }

//     vMessage(1, "Read mesh, preparing to heal it\n");
//     pM2D->vCheckEdgeLengths();

//     pM2D->vAdaptToLengthScale(eET);

//     pM2D->vEvaluateQuality();
//     pM2D->vCheckEdgeLengths();
//     // vWriteFile_Mesh2D(*pM2D, strBaseOutFileName, ".insert");

//     vMessage(1, "Smoothing\n");
//     // Smoothing parameters for later
//     pM2D->vSetSmoothingThreshold(40.);
//     iNumPasses = 4;
    break;

  default:
    assert(0);
    break;
  }

  // The following {} pair exists to be certain that the swap manager is
  // destroyed -before- the mesh that it observes. 
  {
    GRUMMP::SwapDecider2D *pSD_Degree =
      new GRUMMP::UniformDegreeSwapDecider2D();
    GRUMMP::SwapManager2D SM_Degree(pSD_Degree, pM2D);
    SM_Degree.swapAllFaces();
    if (iNumPasses > 0) {
      // Do some smoothing if requested
      vMessage(1, "Smoothing vertices...\n");
      for (int ii = iPreviousPasses; ii < iNumPasses; ii++) {
	vMessage(2, "Pass %d of %d...\n", ii+1, iNumPasses);
	pM2D->iSmooth(1);
	if ((ii+1)%3 == 0) {
	  // After a few smoothing passes, try swapping to see if that helps any.
	  SM_Degree.swapAllFaces();
	}
      }
      pM2D->vEvaluateQuality();
    }
  }

//   // Hack for ubercoarse meshes
//   pM2D->vSetSmoothingThreshold(25.);
//   pM2D->vSetInteriorSkip(1);
//   pM2D->vSetBoundaryFill(false);
//   pM2D->vCoarsen();
//   vMessage(1, "Number of cells after coarsening: %d\n", pM2D->iNumCells());

//   pM2D->vSetSwapType(eMaxDihed);
//   pM2D->iSwap();
//   pM2D->iSmooth(1);

  // Hack for melting internal boundaries.
// #warning Hack to melt internal bdrys.
//   for (int i = pM2D->iNumIntBdryFaces() - 1; i >= 0; i--) {
//     IntBdryEdge* pIBF = pM2D->pIBEIntBdryEdge(i);
//     Face *pF0 = pIBF->pFFace(0);
//     Cell *pC0 = pF0->pCCellOpposite(pIBF);
//     assert(pC0->qValid());
//     Face *pF1 = pIBF->pFFace(1);
//     Cell *pC1 = pF1->pCCellOpposite(pIBF);
//     assert(pC1->qValid());
//     assert(pC0->iRegion() == pC1->iRegion());
//     int iReg = pC0->iRegion();
//     assert(pC0->eType() == CellSkel::eTriCell);
//     Vert *pV0 = pC0->pVVert(0);
//     Vert *pV1 = pC0->pVVert(1);
//     Vert *pV2 = pC0->pVVert(2);
//     pM2D->deleteBFace(pIBF);
//     pM2D->deleteCell(pC0);
//     pF1->vSetFaceLoc(Face::eInterior);
//     pM2D->createTriCell(pV0, pV1, pV2, iReg);
//     assert(pF1->iFullCheck() == 1);
//   }
//   pM2D->vPurge();
//   assert(pM2D->qValid());
//   // End hack

  // Quality output
  pM2D->vWriteQualityToFile(strQualFileName);
  
  // Mesh output
  vMessage(1,"Writing mesh to file(s)...\n");
  if (iExec == TRI) {
//     pM2D->vReorder();
//     assert(pM2D->qValid());
    pM2D->vPurge();
    assert(pM2D->qValid());
    writeVTKLegacy(*pM2D, strBaseOutFileName);
    writeNative(*pM2D, strBaseOutFileName, qOutputBPatchFile);
    {
      int intDegree[10], bdryDegree[10];
      for (int ii = 0; ii < 10; ii++) {
	intDegree[ii] = bdryDegree[ii] = 0;
      }
      for (GR_index_t ii = 0; ii < pM2D->iNumVerts(); ii++) {
	Vert *pV = pM2D->pVVert(ii);
	int deg = pV->iNumFaces();
	if (pV->qIsBdryVert()) {
	  bdryDegree[deg]++;
	}
	else {
	  intDegree[deg]++;
	}
      }
      for (int ii = 2; ii < 10; ii++) {
	vMessage(2, "  Degree: %d  Int count: %5d  Bdry count: %5d\n",
		 ii, intDegree[ii], bdryDegree[ii]);
      }
    }
    
    // writeFEA(*pM2D, strBaseOutFileName, 5);
  }
  else {
    //    pM2D->vReorder();
    writeNative(*pM2D, strBaseOutFileName, qOutputBPatchFile, ".out");
//     writeFEA(*pM2D, strBaseOutFileName, 5, ".out");
  }

  vMessage(1,"Done\n");

//   pM2D->vCheckEdgeLengths();

  assert(pM2D != NULL);
  delete pM2D;

  assert(pG2D != NULL);
  delete pG2D;

  return 0;
 
}
