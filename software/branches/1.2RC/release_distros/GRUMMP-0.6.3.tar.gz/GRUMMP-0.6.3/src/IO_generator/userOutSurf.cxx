#include <stdio.h>
#include "GR_misc.h"
#include "GR_events.h"
#include "GR_Face.h"
#include "GR_Cell.h"
#include "GR_BFace.h"
#include "GR_Vertex.h"
#include "GR_SurfMesh.h"
#include "GR_Bdry3D.h"
void vWriteFile_Surface(SurfMesh& OutMesh,
                        const char strBaseFileName[],
                        const char strExtraFileSuffix[])
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  assert(OutMesh.qSimplicial());
  int iVertOffset = 0, iFaceOffset = 0;
  int iCellOffset = 0, iBFaceOffset = 1;
  FILE *pFOutFile = fopen("/dev/zero", "r");
  char strFileName[1024];
  OutMesh.vPurge();
  sprintf(strFileName, "%s.pwm%s", strBaseFileName, strExtraFileSuffix);

  /*newfile pwm*/
  printf("Opening output file %s\n", strFileName);
  if (pFOutFile) fclose(pFOutFile);
  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open output file for writing",
                "surface mesh output");

  /*1994*/
  fprintf(pFOutFile, "1994\n");
  /*PWI Mesh exported from Loom*/
  fprintf(pFOutFile, "PWI Mesh exported from Loom\n");
  /*drop_int*/
  fprintf(pFOutFile, "drop_int\n");
  /*drop_int*/
  fprintf(pFOutFile, "drop_int\n");
  /*nverts*/
  fprintf(pFOutFile, "%d\n", OutMesh.iNumVerts());
  /*drop_int nfaces drop_int drop_int drop_int drop_int drop_int */
  fprintf(pFOutFile, "drop_int %d drop_int drop_int drop_int drop_int drop_int \n", OutMesh.iNumFaces());

  for (GR_index_t iV = 0; iV < OutMesh.iNumVerts(); iV++) 
    /*verts: coords*/
    fprintf(pFOutFile, "%.14g %.14g %.14g\n", OutMesh.pVVert(iV)->dX(), OutMesh.pVVert(iV)->dY(), OutMesh.pVVert(iV)->dZ());


  for (GR_index_t iF = 0; iF < OutMesh.iNumFaces(); iF++) {
    Face* pF = OutMesh.pFFace(iF);
    GR_index_t iCA, iCB;
    /*faces: verts*/
    fprintf(pFOutFile, "%d %d\n", OutMesh.iVertIndex(pF->pVVert(0))+iVertOffset, OutMesh.iVertIndex(pF->pVVert(1))+iVertOffset);
  }

  /* Make sure compilers won't complain that these variables */
  /* aren't used. */
  iVertOffset++;
  iFaceOffset++;
  iBFaceOffset++;
  iCellOffset++;
  fclose(pFOutFile);
  SUMAA_LOG_EVENT_END(OUTPUT);
}
