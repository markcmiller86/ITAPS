#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

#include <stack>

#include "GR_config.h"
#include "GR_events.h"
#include "GR_Geometry.h"
#include "GR_SurfMesh.h"
#include "GR_SwapDecider.h"
#include "GR_SwapManager.h"
#include "GR_VertTree.h"
#include "GR_VolMesh.h"
#include "GR_Constrain.h"

#define SMALL_ANGLE_RECOVERY

typedef struct _SplitEdge_ {
  Vert *pV0, *pV1, *pVVolNew, *pVSurfNew;
  bool qOnBdryCurve;
  _SplitEdge_(Vert *pV0_arg, Vert *pV1_arg,
	      Vert *pVVolNew_arg, Vert *pVSurfNew_arg,
	      bool qOnCurve) :
    pV0(pV0_arg), pV1(pV1_arg), pVVolNew(pVVolNew_arg),
    pVSurfNew(pVSurfNew_arg), qOnBdryCurve(qOnCurve) {}
} SplitEdge;
  
static std::stack<SplitEdge> stackSplitEdges;

static const int iMaxSplittings = 12;

static bool qRemoveBdrySteinerPoint(const SplitEdge& SE, VolMesh& VM,
				    int& iSwaps, bool& qDelInterior)
{
  Vert *pV = SE.pVVolNew;
  assert(pV->qValid() && pV->qDeletionRequested() && !pV->qDeleted());
  // Grab the vertex and its neighborhood.
  std::set<Vert*> spVNear;
  std::set<Face*> spFNear;
  std::set<Cell*> spCInc;
  std::set<BFace*> spBFaceInc;
  bool qBdry;
  vNeighborhood(pV, spCInc, spVNear, &spBFaceInc, &qBdry, &spFNear);

  if (spBFaceInc.size() > 4) {
    vMessage(3, "Possible panic!  Hit %zd incident bfaces; unsure how to proceed.\n",
	     spBFaceInc.size());
  }

  vMessage(3, "Trying to remove bdry Steiner point %d at (%f, %f, %f)\n",
	   VM.iVertIndex(pV), pV->dX(), pV->dY(), pV->dZ());
  std::set<BFace*>::iterator bfaceIter = spBFaceInc.begin(),
    bfaceIterEnd = spBFaceInc.end();
  double adDir[] = {0,0,0};
  for ( ; bfaceIter != bfaceIterEnd; bfaceIter++) {
    BFace *pBF = *bfaceIter;
    double adNorm[3];
    // This provides a non-normalized normal vector, pointing into the
    // domain.  Things could be tricky for interior bdry faces.
    pBF->vVecSize(adNorm);
    adDir[0] += adNorm[0];
    adDir[1] += adNorm[1];
    adDir[2] += adNorm[2];
  }
  vNORMALIZE3D(adDir);
  vMessage(3, "  Normal: (%f, %f, %f)\n", adDir[0], adDir[1], adDir[2]);

  std::set<Face*> spFHull;
  std::set<Face*>::iterator faceIter = spFNear.begin(),
    faceIterEnd = spFNear.end();
  double dDistToIntersection = 1.e300;

  for ( ; faceIter != faceIterEnd; faceIter++) {
    Face *pF = *faceIter;
    if (!pF->qHasVert(pV)) {
      spFHull.insert(pF);
      Vert *pV0 = pF->pVVert(0);
      Vert *pV1 = pF->pVVert(1);
      Vert *pV2 = pF->pVVert(2);
      // Outward normal of this face.
      double adNorm[3];
      vNormal3D(pV0->adCoords(), pV1->adCoords(), pV2->adCoords(), adNorm);
      vNORMALIZE3D(adNorm);
      vMessage(3, "  Hull face %d; verts %d, %d, %d\n",
	       VM.iFaceIndex(pF), VM.iVertIndex(pV0), 
	       VM.iVertIndex(pV1), VM.iVertIndex(pV2));
      vMessage(3, "    Vert 0:  (%f, %f, %f)\n",
	       pV0->dX(), pV0->dY(), pV0->dZ());
      vMessage(3, "    Vert 1:  (%f, %f, %f)\n",
	       pV1->dX(), pV1->dY(), pV1->dZ());
      vMessage(3, "    Vert 2:  (%f, %f, %f)\n",
	       pV2->dX(), pV2->dY(), pV2->dZ());
      
      // Distance from face to this point.
      double adDiff[] = adDIFF3D(pV0->adCoords(), pV->adCoords());
      double dDistToPlane = dDOT3D(adDiff, adNorm);
      if (dDistToPlane < 0) {
	dDistToPlane *= -1;
	vSCALE3D(adNorm, -1);
      }
      vMessage(3, "  Face normal: (%f, %f, %f); dist: %f\n",
 	       adNorm[0], adNorm[1], adNorm[2], dDistToPlane);

      // Get the cos of the angle between the normal from the surface
      // and normal from this face.
      double dCos = dDOT3D(adDir, adNorm) / dMAG3D(adNorm);
      vMessage(3, "  Cos of angle: %f; angle %f degrees\n",
	       dCos, GR_acos(dCos)*180/M_PI);
      
      // Find distance to this intersection.
      double dThisDist = 1.e300;
      if (dCos > 0) dThisDist = dDistToPlane / dCos;
      if (dThisDist < dDistToIntersection)
	dDistToIntersection = dThisDist;
      vMessage(3, "  This dist: %f; smallest so far: %f\n",
 	       dThisDist, dDistToIntersection);
    } // Done processing outer hull verts.
  } // Done checking all nearby faces.

  vMessage(3, "  Dist to interior Steiner: %f\n",
	   dDistToIntersection);
  if (dDistToIntersection < 1.e-12) return false;
  double adNewLoc[] = {pV->dX() + adDir[0]*dDistToIntersection / 2,
		       pV->dY() + adDir[1]*dDistToIntersection / 2,
		       pV->dZ() + adDir[2]*dDistToIntersection / 2};
  vMessage(4, "  inserting an interior Steiner point at (%f, %f, %f)\n",
	   adNewLoc[0], adNewLoc[1], adNewLoc[2]);

  // Check to see whether this point lies inside one of the tets.
  std::set<Cell*>::iterator cellIter;
  const std::set<Cell*>::iterator cellIterEnd = spCInc.end();

  Vert *pVIntSteiner = VM.createVert(adNewLoc);
  pVIntSteiner->vMarkToDelete();
  pVIntSteiner->vMarkIllShaped(); 
  
  // Now need to delete all the incident tets; their shared faces go
  // with them with automagically.
  for (cellIter = spCInc.begin(); cellIter != cellIterEnd; cellIter++) {
    Cell *pC = *cellIter;
    VM.deleteCell(pC);
  }
  
  // Create new tets for each hull face
  faceIterEnd = spFHull.end();
  for (faceIter = spFHull.begin(); faceIter != faceIterEnd; faceIter++) {
    bool qExist;
    VM.createTetCell(qExist, pVIntSteiner, *faceIter);
    assert(!qExist);
  }

  // And now one for each of the faces on the bdry
  bfaceIterEnd = spBFaceInc.end();
  for (bfaceIter = spBFaceInc.begin(); bfaceIter != bfaceIterEnd;
       bfaceIter++) {
    Face *pF = (*bfaceIter)->pFFace();
    bool qExist;
    VM.createTetCell(qExist, pVIntSteiner, pF);
    assert(!qExist);
  }

  bool qRes;
  int iNewSwaps = 0;
  Vert* apVTargets[] = {SE.pV0, SE.pV1};
  qRes = VM.qRemoveVertByContraction(pV, iNewSwaps, apVTargets, 2);
  iSwaps += iNewSwaps;
  if (!qRes) {
    vMessage(3, "  Bdry removal failed!\n");
    return false;
  }
  assert(qRes);
  if (qRes)
    vMessage(3, "  Bdry removal succeeded with %d swaps.\n", iNewSwaps);

  qDelInterior = VM.qRemoveVertByContraction(pVIntSteiner, iNewSwaps);
  iSwaps += iNewSwaps;
  vMessage(3, "  Interior removal %s with %d swaps.\n",
	   qDelInterior ? "succeeded" : "failed", iNewSwaps);
  return true;
}

static void vComputeEdgeAndTriStatus(const SurfMesh& SM,
				     std::set<ConstrainEdge> sCESubSegs,
				     std::set<ConstrainEdge> sCEInFacets,
				     std::set<ConstrainFace> sCFSubFacets,
				     int aiTriStatus[],
				     int aiEdgeStatus[])
{
  for (GR_index_t iC = 0; iC < SM.iNumCells(); iC++) {
    aiTriStatus[iC] = 0;
  }

  for (GR_index_t iF = 0; iF < SM.iNumFaces(); iF++) {
    aiEdgeStatus[iF] = 0;
  }

  vMessage(2, "Missing %zd (sub)facets\n", sCFSubFacets.size());
  for (std::set<ConstrainFace>::iterator iter = sCFSubFacets.begin();
       iter != sCFSubFacets.end(); iter++) {
    ConstrainFace CF = *iter;
    Vert *pV0 = SM.pVVert(CF.iV0);
    Vert *pV1 = SM.pVVert(CF.iV1);
    Vert *pV2 = SM.pVVert(CF.iV2);
    Face *pF01 = findCommonFace(pV0, pV1, true);
    Face *pF12 = findCommonFace(pV1, pV2, true);
    assert(pF01 && pF12);
    Cell *pC = pCCommonCell(pF01, pF12);
    assert(pC);
    int iC = SM.iCellIndex(pC);
    aiTriStatus[iC] = 1; // Face is missing
  }

  vMessage(2, "Missing %zd segments\n", sCESubSegs.size());
  for (std::set<ConstrainEdge>::iterator iter = sCESubSegs.begin();
       iter != sCESubSegs.end(); iter++) {
    // Missing input edges.
    ConstrainEdge CE = *iter;
    Vert *pV0 = SM.pVVert(CE.iV0);
    Vert *pV1 = SM.pVVert(CE.iV1);
    Face *pF01 = findCommonFace(pV0, pV1, true);
    assert(pF01);
    int iF = SM.iFaceIndex(pF01);
    aiEdgeStatus[iF] = 2;
    int iCL = SM.iCellIndex(pF01->pCCellLeft());
    int iCR = SM.iCellIndex(pF01->pCCellRight());
    aiTriStatus[iCL] += 4;
    aiTriStatus[iCR] += 4;
  }

  vMessage(2, "Missing %zd in-facet edges\n", sCEInFacets.size());
  for (std::set<ConstrainEdge>::iterator iter = sCEInFacets.begin();
       iter != sCEInFacets.end(); iter++) {
    // Missing edges created in input n-gons, n>3.
    ConstrainEdge CE = *iter;
    Vert *pV0 = SM.pVVert(CE.iV0);
    Vert *pV1 = SM.pVVert(CE.iV1);
    Face *pF01 = findCommonFace(pV0, pV1, true);
    assert(pF01);
    int iF = SM.iFaceIndex(pF01);
    aiEdgeStatus[iF] = 1;
    int iCL = SM.iCellIndex(pF01->pCCellLeft());
    int iCR = SM.iCellIndex(pF01->pCCellRight());
    aiTriStatus[iCL] += 1;
    aiTriStatus[iCR] += 1;
  }
}

static void vWriteFile_AnnotatedSurface(SurfMesh& OutMesh,
					const char strBaseFileName[],
					const char strExtraFileSuffix[],
					std::set<ConstrainEdge> sCESubSegs,
					std::set<ConstrainEdge> sCEInFacets,
					std::set<ConstrainFace> sCFSubFacets,
					VolMesh *pVM = NULL)
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  assert(OutMesh.qSimplicial());
  FILE *pFOutFile = fopen("/dev/zero", "r");
  char strFileName[1024];
  OutMesh.vPurge();
  sprintf(strFileName, "%s.vtk%s", strBaseFileName, strExtraFileSuffix);

  /*newfile vtk*/
  printf("Opening output file %s\n", strFileName);
  if (pFOutFile) fclose(pFOutFile);
  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open output file for writing",
                "surface mesh output");

  /*"# vtk DataFile Version" discard_float*/
  fprintf(pFOutFile, "# vtk DataFile Version 1.1.1\n");
  /*discard_line*/
  fprintf(pFOutFile, "GRUMMP-generated surface mesh file\n");
  /*ASCII*/
  fprintf(pFOutFile, "ASCII\n");
  /*DATASET UNSTRUCTURED_GRID*/
  fprintf(pFOutFile, "DATASET UNSTRUCTURED_GRID\n");
  /*POINTS nverts float*/
  fprintf(pFOutFile, "POINTS %u float\n", OutMesh.iNumVerts());

  for (GR_index_t iV = 0; iV < OutMesh.iNumVerts(); iV++) 
    /*verts: coords*/
    fprintf(pFOutFile, "%.14g %.14g %.14g\n", OutMesh.pVVert(iV)->dX(), OutMesh.pVVert(iV)->dY(), OutMesh.pVVert(iV)->dZ());

  /*"CELLS" ncells discard_integer*/
  fprintf(pFOutFile, "CELLS %u %u\n", OutMesh.iNumCells(),
	  OutMesh.iNumCells()*4);

  for (GR_index_t iC = 0; iC < OutMesh.iNumCells(); iC++) {
    Cell* pC = OutMesh.pCCell(iC);
    fprintf(pFOutFile, "3 ");
    for (int iV = 0; iV < pC->iNumVerts(); iV++) {
      fprintf(pFOutFile, "%u ", OutMesh.iVertIndex(pC->pVVert(iV)));
    }
    /*cells: 3 verts*/
    fprintf(pFOutFile, "\n");
  }

  /*CELL_TYPES ncells*/
  fprintf(pFOutFile, "CELL_TYPES %u\n", OutMesh.iNumCells());

  for (GR_index_t iC = 0; iC < OutMesh.iNumCells(); iC++) {
    /*cells: 5*/
    fprintf(pFOutFile, "5\n");
  }

  int *aiTriStatus = new int[OutMesh.iNumCells()];
  int *aiEdgeStatus = new int[OutMesh.iNumFaces()];

  vComputeEdgeAndTriStatus(OutMesh, sCESubSegs, sCEInFacets, sCFSubFacets,
			   aiTriStatus, aiEdgeStatus);

  // More diagnostics: this time, identifying blisters (small parts of
  // the surface mesh that have a different triangulation, but the right
  // number of triangles covering them).  Blisters should, I think,
  // prove easy to remove with a surface edge swap after ditching the
  // exterior.
  if (pVM) {
    for (GR_index_t iF = 0; iF < OutMesh.iNumFaces(); iF++) {
      if (aiEdgeStatus[iF] != 0) {
	Face *pF = OutMesh.pFFace(iF);
	Cell *pCL = pF->pCCellLeft();
	Cell *pCR = pF->pCCellRight();
	int iCL = OutMesh.iCellIndex(pCL);
	int iCR = OutMesh.iCellIndex(pCR);
	int iStatL = aiTriStatus[iCL];
	int iStatR = aiTriStatus[iCR];
	if ((iStatL == 2 || iStatL == 5) &&
	    (iStatR == 2 || iStatR == 5)) {
	  // Each has only one missing edge: the easiest case.
	  // So only four verts:
	  Vert *pVA = pF->pVVert(0);
	  Vert *pVB = pF->pVVert(1);
	  Vert *pVL = pCL->pVVertOpposite(pF);
	  Vert *pVR = pCR->pVVertOpposite(pF);
	  // Those are the surface verts.  Now get the volume verts.
	  Vert *pVA_vol = pVM->pVVert(OutMesh.iVertIndex(pVA));
	  Vert *pVB_vol = pVM->pVVert(OutMesh.iVertIndex(pVB));
	  Vert *pVL_vol = pVM->pVVert(OutMesh.iVertIndex(pVL));
	  Vert *pVR_vol = pVM->pVVert(OutMesh.iVertIndex(pVR));
	  // The two faces you have to have here are known:
	  Face *pFCand1 = findCommonFace(pVA_vol, pVL_vol, pVR_vol, NULL, true);
	  Face *pFCand2 = findCommonFace(pVB_vol, pVL_vol, pVR_vol, NULL, true);
	  if (pFCand1->qValid() && pFCand2->qValid()) {
	    aiTriStatus[iCL] = aiTriStatus[iCR] = -2;

	    // How many faces are incident on the bad edge here?
	    int iNFaces_Left = pVL_vol->iNumFaces();
	    int iCommon = 0;
	    for (int ii = 0; ii < iNFaces_Left; ii++) {
	      Face *pFTmp = pVL_vol->pFFace(ii);
	      if (pFTmp->qHasVert(pVR_vol)) iCommon++;
	    }
// 	    vMessage(2, "Two-tri blister; %d common faces\n", iCommon);
	  }
	  else if (pFCand1->qValid() || pFCand2->qValid()) {
	    aiTriStatus[iCL] = aiTriStatus[iCR] = -1;
	  }
	}	
      }
    }
  }

  fprintf(pFOutFile, "CELL_DATA %u\n", OutMesh.iNumCells());
  fprintf(pFOutFile, "SCALARS tri_status int 1\n");
  fprintf(pFOutFile, "LOOKUP_TABLE default\n");
  for (GR_index_t iC = 0; iC < OutMesh.iNumCells(); iC++) {
    fprintf(pFOutFile, "%d\n", aiTriStatus[iC]);
  }

  delete [] aiTriStatus;
  delete [] aiEdgeStatus;

  /* Make sure compilers won't complain that these variables */
  /* aren't used. */
  fclose(pFOutFile);
  SUMAA_LOG_EVENT_END(OUTPUT);
}


void VolMesh::vSplitEdge(const Vert* const pV0, const Vert* const pV1,
			 SurfMesh& SM)
{
  // Force a split of the given surface edge within both the surface and
  // volume meshes.
  int iV0 = iVertIndex(pV0);
  int iV1 = iVertIndex(pV1);
  Vert *pVS0 = SM.pVVert(iV0);
  Vert *pVS1 = SM.pVVert(iV1);
  assert(dDIST3D(pVS0->adCoords(), pV0->adCoords()) < 1.e-12);
  assert(dDIST3D(pVS1->adCoords(), pV1->adCoords()) < 1.e-12);
  Face *pFS = pFInvalidFace;
  {
    std::set<Vert*> spVNear;
    std::set<Face*> spFNear;
    std::set<Cell*> spCTmp;
    std::set<BFace*> spBFTmp;
    bool qTmp;
    vNeighborhood(pVS0, spCTmp, spVNear, &spBFTmp, &qTmp, &spFNear);
    if (spVNear.count(pVS1) == 0) return;
    std::set<Face*>::iterator iterF;
    for (iterF = spFNear.begin(); iterF != spFNear.end(); iterF++) {
      pFS = *iterF;
      if (pFS->qHasVert(pVS0) && pFS->qHasVert(pVS1)) break;
    }
    assert(pFS->qHasVert(pVS0));
    assert(pFS->qHasVert(pVS1));
  }

  // Edge swap failed; have to solve this by splitting.
  double adNewLoc[3];
#ifdef SMALL_ANGLE_RECOVERY
  bool qSmall0 = pVS0->qIsSmallAngleCorner();
  bool qSmall1 = pVS1->qIsSmallAngleCorner();
  if ((qSmall0 && qSmall1) ||
      (!qSmall0 && !qSmall1)) {
#endif
    // Bisect
    adNewLoc[0] = 0.5*(pV0->dX() + pV1->dX());
    adNewLoc[1] = 0.5*(pV0->dY() + pV1->dY());
    adNewLoc[2] = 0.5*(pV0->dZ() + pV1->dZ());
    vMessage(3, "Splitting edge at midpoint: %12.6f %12.6f %12.6f\n",
	     adNewLoc[0], adNewLoc[1], adNewLoc[2]);
#ifdef SMALL_ANGLE_RECOVERY
  }
  else if (qSmall0) {
    // Split near pVS0.
    double dSplitDist = pVS0->dLS();
    double adVec[] = adDIFF3D(pV1->adCoords(), pV0->adCoords());
    double dEdgeLen = dMAG3D(adVec);
    while (dSplitDist > dEdgeLen/1.5) dSplitDist /= 2;
    assert(dSplitDist < 2./3. * dEdgeLen);

    vNORMALIZE3D(adVec);

    adNewLoc[0] = pV0->dX() + adVec[0] * dSplitDist;
    adNewLoc[1] = pV0->dY() + adVec[1] * dSplitDist;
    adNewLoc[2] = pV0->dZ() + adVec[2] * dSplitDist;
    vMessage(3, "Splitting edge near vert %4d: (%12.6f, %12.6f, %12.6f) %f\n",
	     iV0, adNewLoc[0], adNewLoc[1], adNewLoc[2], dSplitDist);
  }
  else {
    assert(qSmall1);
    // Split near pVS1.
    double dSplitDist = pVS1->dLS();
    double adVec[] = adDIFF3D(pV0->adCoords(), pV1->adCoords());
    double dEdgeLen = dMAG3D(adVec);
    while (dSplitDist > dEdgeLen/1.5) dSplitDist /= 2;
    assert(dSplitDist < 2./3. * dEdgeLen);

    vNORMALIZE3D(adVec);

    adNewLoc[0] = pV1->dX() + adVec[0] * dSplitDist;
    adNewLoc[1] = pV1->dY() + adVec[1] * dSplitDist;
    adNewLoc[2] = pV1->dZ() + adVec[2] * dSplitDist;
    vMessage(3, "Splitting edge near vert %4d: (%12.6f, %12.6f, %12.6f) %f\n",
	     iV0, adNewLoc[0], adNewLoc[1], adNewLoc[2], dSplitDist);
  }
#endif

  Vert *pVNewSurf = SM.createVert(adNewLoc[0], adNewLoc[1], adNewLoc[2]);
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
  bool qInsertOnCurve;
  // FIX ME  What about non-manifold edges?  Subsequent recovery of the
  // original surface is significantly harder then... 
  int iSwaps =  SM.iInsertOnFace(pVNewSurf, pFS, pFS->pCCellLeft(), 
				 true, &qInsertOnCurve);
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);

  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
  qInsertPoint(adNewLoc, pCBeginPipe(pV0, pV1), &iSwaps, true, true);
  Vert *pVNew = pVVert(iNumVerts() - 1);
  // This vertex was added during bdry recovery, along a curve.  Mark it
  // as a bdry curve point, and tag for possible deletion, in the case
  // that we're interested in removing as many constraining verts as possible.
  pVNew->vSetType( qInsertOnCurve ? Vert::eBdryCurve : Vert::eBdry );
  pVNew->vMarkToDelete();
  stackSplitEdges.push
    (SplitEdge(const_cast<Vert*>(pV0), const_cast<Vert*>(pV1),
	       pVNew, pVNewSurf, qInsertOnCurve));
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
}

static void vRecoverEdges(VolMesh * const pVM,
			  SurfMesh * const pSM,
			  std::set<ConstrainEdge>& sCE,
			  int& iRecovered, int& iOtherChanges)
{
  iRecovered = iOtherChanges = 0;
  std::set<ConstrainEdge>::iterator iter, iterEnd = sCE.end(); 
  for (iter = sCE.begin(); iter != iterEnd; ) {
    Vert *pV0 = pVM->pVVert(iter->iV0);
    Vert *pV1 = pVM->pVVert(iter->iV1);
    int iGotIt = pVM->iRecoverEdge(pV0, pV1, *pSM, false);
    std::set<ConstrainEdge>::iterator iterTmp = iter++;
    switch (iGotIt) {
    case 1: // Edge recovered
      sCE.erase(iterTmp);
      iRecovered ++;
      break;
    case -1:
      iOtherChanges ++;
      break;
    }
  } // Done checking non-constrained segments
}

static bool qSplitEdges(VolMesh * const pVM,
			SurfMesh * const pSM,
			std::set<ConstrainEdge>& sCESubSegs,
			std::set<ConstrainEdge>& sCEInFacets,
			std::set<ConstrainFace>& sCF,
			int& iSplittings)
{
#ifndef NDEBUG
  vWriteFile_AnnotatedSurface(*pSM, "presplit", ".surf",
			      sCESubSegs, sCEInFacets, sCF,
			      pVM);
#endif
//   // Change the swapping type.  Insertion into the volume mesh sometimes
//   // fails with flat tets otherwise.  Since faces that have been
//   // recovered are locked, this shouldn't hurt things too much.
//   eSwap eSwapTmp = pVM->eSwapType();
//   pVM->vSetSwapType(eMinSine);

  vMessage(2, "Splitting all unconstrained edges (%dth time).\n",
	   iSplittings);
  vMessage(2, "  Constraint stats before:\n");
  qIsBdryConstrained(pVM, pSM, sCESubSegs, sCEInFacets, sCF);
  // Always recover subsegments first, then work on edges
  // within subfacets.
  std::set<ConstrainEdge> sCE(sCESubSegs);
//   if (sCE.empty()) {
    sCE.insert(sCEInFacets.begin(), sCEInFacets.end());
//   }
  // Since allowing insertion wasn't enough, force a split of
  // all edges not yet constrained.  Enable swap recursion in
  // the volume mesh while splitting.
  pVM->vAllowSwapRecursion();
  // ENCROACHMENT CHECK BEGIN
  VertTree VT(*(pVM->pECGetVerts()));
  int iNumEncroached = 0;
  // ENCROACHMENT CHECK END
  int iSmallVerts = 0, iSmallEdges = 0, iTotalEdges = sCE.size();
  std::set<ConstrainEdge>::iterator iter;
  int iE = 0;
  for (iter = sCE.begin(); iter != sCE.end(); iter++, iE++) {
    ConstrainEdge CE = *iter;
    Vert *pV0 = pVM->pVVert(CE.iV0);
    Vert *pV1 = pVM->pVVert(CE.iV1);
    vMessage(3, "   Edge %d.  Vert %d: %s.  Vert %d: %s.\n",
	     iE, CE.iV0, (pV0->qIsSmallAngleCorner() ? "small" : " okay"),
	     CE.iV1, (pV1->qIsSmallAngleCorner() ? "small" : " okay"));
    iSmallVerts += (pV0->qIsSmallAngleCorner() ? 1 : 0) +
      (pV1->qIsSmallAngleCorner() ? 1 : 0);
    iSmallEdges += (pV0->qIsSmallAngleCorner() ||
		    pV1->qIsSmallAngleCorner() ? 1 : 0);
    // ENCROACHMENT CHECK BEGIN
    // Check edges for encroachment; if the edge isn't
    // encroached, we should be able to avoid getting here.
    {
      double adMid[] = {(pV0->dX() + pV1->dX()) * 0.5,
			(pV0->dY() + pV1->dY()) * 0.5,
			(pV0->dZ() + pV1->dZ()) * 0.5};
      double dRad = dDIST3D(pV0->adCoords(), pV1->adCoords()) * 0.5001;
      std::vector<int> veciTmp = VT.veciBallQuery(adMid, dRad);
      assert(veciTmp.size() >= 2);
      // Will confirm later that the endpoint are included.
      bool qGot0 = false, qGot1 = false;
      if (veciTmp.size() > 2) {
	iNumEncroached++;
	// What's the actual radius ratio?
	vMessage(4, "  Edge from %d to %d is encroached %zd times.\n",
		 CE.iV0, CE.iV1, veciTmp.size() - 2);
	double adEdge[] = adDIFF3D(pV0->adCoords(), pV1->adCoords());
	for (int ii = veciTmp.size() - 1; ii >= 0; ii--) {
	  int iVert = veciTmp[ii];
	  if (iVert == CE.iV0) {
	    qGot0 = true;
	  }
	  else if (iVert == CE.iV1) {
	    qGot1 = true;
	  }
	  else {
	    double adDiff[] =
	      adDIFF3D(pVM->pVVert(iVert)->adCoords(), adMid);
	    vMessage(4, "    Vert %4d is %5.2f%%r; angle wrt edge is %5.2f deg.\n",
		     iVert, dMAG3D(adDiff) / dRad * 100,
		     GR_acos(dDOT3D(adEdge, adDiff)/
			     (dMAG3D(adDiff)*dMAG3D(adEdge)))*180/M_PI);
	  }
	}
	assert(qGot0 && qGot1);
      }
    }
    // ENCROACHMENT CHECK END
    pVM->vSplitEdge(pV0, pV1, *pSM);
  }
  vMessage(2, "  Out of %d edges, %d had a small angle vert (%d verts)\n",
	   iTotalEdges, iSmallEdges, iSmallVerts);
  // ENCROACHMENT CHECK BEGIN
  vMessage(2, "  %d edges were encroached.\n", iNumEncroached);
  // ENCROACHMENT CHECK END
  pVM->vDisallowSwapRecursion();
  
  vMessage(2, "  Constraint stats after:\n");
  // Reset the list of stuff to recover
  bool retVal = qIsBdryConstrained(pVM, pSM, sCESubSegs, sCEInFacets, sCF);
#ifndef NDEBUG
  vWriteFile_AnnotatedSurface(*pSM, "postsplit", ".surf",
			      sCESubSegs, sCEInFacets, sCF,
			      pVM);
#endif
//   exit(110);

//   // Reset the swap type.
//   pVM->vSetSwapType(eSwapTmp);

  return retVal;
}

static void vRecoverFaces(VolMesh * const pVM,
			  SurfMesh * const pSM,
			  std::set<ConstrainFace> sCF,
			  int& iFacesRecovered,
			  int& iFaceRec3To2, int& iFaceRecEdge,
			  const bool qSplitBadFaces)
{
  iFacesRecovered = 0;
  std::set<ConstrainFace>::iterator iter, iterEnd = sCF.end();
  for (iter = sCF.begin(); iter != iterEnd; ) {
    ConstrainFace CF = *iter;
    int aiVerts[] = {CF.iV0, CF.iV1, CF.iV2};
    int ii = pVM->iRecoverFace(aiVerts);
    std::set<ConstrainFace>::iterator iterTmp = iter++;
    if (ii) {
      iFacesRecovered ++;
      sCF.erase(iterTmp);
      // This is an ugly hack, but it works.
      iFaceRec3To2 += ii % 1000;
      iFaceRecEdge += ii / 1000;
    }
    else if (qSplitBadFaces) {
      vMessage(3, "Splitting all edges of bad face.\n");
      // Didn't get it, so split its edges.  Yes, it's overkill to split
      // all three probably... 
      pVM->vSplitEdge(pVM->pVVert(CF.iV0), pVM->pVVert(CF.iV1),
		      *pSM);
      pVM->vSplitEdge(pVM->pVVert(CF.iV1), pVM->pVVert(CF.iV2),
		      *pSM);
      pVM->vSplitEdge(pVM->pVVert(CF.iV2), pVM->pVVert(CF.iV0),
		      *pSM);
    }
  }
}

// static void vRecoverAllEdges(VolMesh * const pVM,
// 			     SurfMesh * const pSM,
// 			     std::set<ConstrainEdge>& sCESubSegs,
// 			     std::set<ConstrainEdge>& sCEInFacets,
// 			     std::set<ConstrainFace>& sCF)
// {
//   std::set<ConstrainEdge> sCE(sCESubSegs);
//   if (sCE.empty()) sCE.insert(sCEInFacets.begin(), sCEInFacets.end());

//   int iSplittings = 0;
//   if (!sCE.empty()) {
//     //@@ Recover edges
//     // Verts added to the volume mesh to constrain it; must be added to
//     // surface mesh on return for constraint checking to work properly.

//     int iChange, iRecovered;
//     bool qDoInsertion = false;
//     int iTotalPasses;
//     do { // Begin recovering edges
//       iTotalPasses = 0;
//       int iNFruitlessPasses = 0;
//       do { // Begin a pass to check all unconstrained edges
// 	vMessage(3, "Recovery pass %d (%d fruitless); insertion %s\n",
// 		 iTotalPasses, iNFruitlessPasses,
// 		 (qDoInsertion ? "allowed" : "not allowed"));
// 	iTotalPasses ++;
// 	iNFruitlessPasses ++;
// 	int iVertsBefore = pVM->iNumVerts();
// 	vRecoverEdges(pVM, pSM, sCE, iRecovered, iChange);
// 	std::set<ConstrainEdge>::iterator iter; 
// 	if (iRecovered) iNFruitlessPasses = 0;
// 	int iVertsAfter = pVM->iNumVerts();
// 	vMessage(2, "Status:%2d passes (%sinserting; last %d fruitless). Changes: %3d Left: %3d\n",
// 		 iTotalPasses, qDoInsertion ? "" : "not ",
// 		 iNFruitlessPasses, iRecovered, static_cast<int>(sCE.size()));
// 	if (sCE.empty()) {
// 	  qIsBdryConstrained(pVM, pSM, sCESubSegs, sCEInFacets, sCF);
// 	  // Always recover subsegments first, then work on edges
// 	  // within subfacets.
// 	  assert(sCE.empty());
// 	  if (!sCESubSegs.empty()) {
// 	    sCE.insert(sCESubSegs.begin(), sCESubSegs.end());
// 	  }
// 	  else {
// 	    sCE.insert(sCEInFacets.begin(), sCEInFacets.end());
// 	  }
// 	  // If swapping fixed all the edges, don't turn off insertion,
// 	  // or you could loop forever trying to do surface recovery.
// 	  if (qDoInsertion && (iVertsAfter != iVertsBefore)) {
// 	    qDoInsertion = false;
// 	    assert(iNFruitlessPasses == 0);
// 	    iTotalPasses = 0;
// 	  }
// 	}
// 	for (iter = sCE.begin(); iter != sCE.end(); iter++) {
// 	  ConstrainEdge CE = *iter;
// 	  Vert *pV0 = pVM->pVVert(CE.iV0);
// 	  Vert *pV1 = pVM->pVVert(CE.iV1);
// 	  vMessage(4, "Bad edge:\n");
// 	  vMessage(4, "%d %12.6f %12.6f %12.6f\n",
// 		   CE.iV0, pV0->dX(), pV0->dY(),
// 		   pV0->dZ());
// 	  vMessage(4, "%d %12.6f %12.6f %12.6f\n\n",
// 		   CE.iV1, pV1->dX(), pV1->dY(),
// 		   pV1->dZ());
// 	}
//       } while (iNFruitlessPasses < 2 && iChange && (!sCE.empty())
// 	       && iTotalPasses < 10); // Done with edge recovery, at
// 				      // least for now

//       // We might even be totally done...
//       if (sCE.empty()) return;
//       // Don't insert verts onto boundaries that are immutable.
//       if (pVM->qBdryChangesAllowed()) {
// 	if (qDoInsertion) {
// 	  iSplittings++;
// 	  if (iSplittings <= iMaxSplittings) {
// 	    qSplitEdges(pVM, pSM, sCESubSegs, sCEInFacets, sCF, iSplittings);
// 	    qDoInsertion = false;
// 	    // Always recover subsegments first, then work on edges
// 	    // within subfacets.
// 	    sCE.clear();
// 	    if (!sCESubSegs.empty()) {
// 	      sCE.insert(sCESubSegs.begin(), sCESubSegs.end());
// 	    }
// 	    else {
// 	      sCE.insert(sCEInFacets.begin(), sCEInFacets.end());
// 	    }
// 	  }
// 	} // Done splitting all missing edges
// 	else {
// 	  // Some diagnostic output, to see what sorts of patterns there
// 	  // are in unrecovered edges.
//  	  qIsBdryConstrained(pVM, pSM, sCESubSegs, sCEInFacets, sCF);
// 	  // Now find all the SurfMesh Face's that are missing.
// 	  std::set<Face*> spFMissingFaces;
// 	  {
// 	    std::set<ConstrainEdge>::iterator iter, end = sCESubSegs.end();
// 	    for (iter = sCESubSegs.begin(); iter != end; iter++) {
// 	      ConstrainEdge CE = *iter;
// 	      Vert *pV0 = pSM->pVVert(CE.iV0);
// 	      Vert *pV1 = pSM->pVVert(CE.iV1);
// 	      Face* pF = findCommonFace(pV0, pV1, true);
// 	      assert(pF->qValid());
// 	      spFMissingFaces.insert(pF);
// 	    }
// 	    // Now again for edges in facets.
// 	    end = sCEInFacets.end();
// 	    for (iter = sCEInFacets.begin(); iter != end; iter++) {
// 	      ConstrainEdge CE = *iter;
// 	      Vert *pV0 = pSM->pVVert(CE.iV0);
// 	      Vert *pV1 = pSM->pVVert(CE.iV1);
// 	      Face* pF = findCommonFace(pV0, pV1, true);
// 	      assert(pF->qValid());
// 	      spFMissingFaces.insert(pF);
// 	    }
// 	  }
// 	  std::set<Cell*> spCMissingCells;
// 	  {
// 	    std::set<ConstrainFace>::iterator iter, end = sCF.end();
// 	    for (iter = sCF.begin(); iter != end; iter++) {
// 	      ConstrainFace CF = *iter;
// 	      Vert *pV0 = pSM->pVVert(CF.iV0);
// 	      Vert *pV1 = pSM->pVVert(CF.iV1);
// 	      Vert *pV2 = pSM->pVVert(CF.iV2);
// 	      Face *pF01 = findCommonFace(pV0, pV1, true);
// 	      Face *pF12 = findCommonFace(pV1, pV2, true);
// 	      Face *pF20 = findCommonFace(pV2, pV0, true);
// 	      assert(pF01->qValid() && pF12->qValid() && pF20->qValid());
// 	      Cell *pC = pCCommonCell(pF01, pF12);
// 	      assert(pC->qHasFace(pF20));
// 	      spCMissingCells.insert(pC);
// 	    }
// 	  }
// 	  int *aiMissingData = new int[pSM->iNumCells()];
// 	  for (int ii = pSM->iNumCells() - 1; ii >= 0; ii--)
// 	    aiMissingData[ii] = 0;
// 	  {
// 	    std::set<Face*>::iterator iter, end = spFMissingFaces.end();
// 	    for (iter = spFMissingFaces.begin(); iter != end; iter++) {
// 	      Face *pF = *iter;
// 	      int iCL = pSM->iCellIndex(pF->pCCellLeft());
// 	      int iCR = pSM->iCellIndex(pF->pCCellRight());
// 	      aiMissingData[iCL]++;
// 	      aiMissingData[iCR]++;
// 	    }
// 	  }
// 	  {
// 	    std::set<Cell*>::iterator iter, end = spCMissingCells.end();
// 	    for (iter = spCMissingCells.begin(); iter != end; iter++) {
// 	      Cell *pC = *iter;
// 	      int iC = pSM->iCellIndex(pC);
// 	      if (aiMissingData[iC] == 0) aiMissingData[iC] = 4;
// 	    }
// 	  }
// 	  int aiCounts[] = {0,0,0,0,0};
// 	  for (GR_index_t i = 0; i < pSM->iNumCells(); i++) {
// 	    aiCounts[aiMissingData[i]] ++;
// // 	    if (aiMissingData[i] != 0) {
// // 	      vMessage(2, "Cell %5d:  %d\n", i, aiMissingData[i]);
// // 	    }
// 	  }
// 	  vMessage(2, "Tris fully present: %d\n", aiCounts[0]);
// 	  vMessage(2, "Tris w/ one missing edge: %d\n", aiCounts[1]);
// 	  vMessage(2, "Tris w/ two missing edge: %d\n", aiCounts[2]);
// 	  vMessage(2, "Tris w/ three missing edge: %d\n", aiCounts[3]);
// 	  vMessage(2, "Tris w/ all edges, but missing: %d\n", aiCounts[4]);
// 	  // Try insertion if you haven't recently.
// 	  qDoInsertion = true;
// 	}
//       }
//     } while (iSplittings <= iMaxSplittings && (!sCE.empty()));
//     // Done recovering edges
//   } // Edges only need to be recovered if they are any missing in the first
//     // place.
// }

void vNewSurfaceRecovery(VolMesh * const pVM,
			 SurfMesh * const pSM)
{
  //@@ Take a census to see which edges and faces need work to recover
  std::set<ConstrainEdge> sCESubSegs;
  std::set<ConstrainEdge> sCEInFacets;
  std::set<ConstrainFace> sCFSubFacets;

#ifndef NDEBUG
  for (unsigned int i = 0; i < pSM->iNumVerts(); i++) {
    Vert *pVS = pSM->pVVert(i);
    Vert *pVV = pVM->pVVert(i);
    if ((pVS->dX() != pVV->dX()) ||
	(pVS->dY() != pVV->dY()) ||
	(pVS->dZ() != pVV->dZ())) {
      vMessage(2, "(%10f, %10f, %10f)   (%10f, %10f, %10f)\n",
	       pVS->dX(), pVS->dY(), pVS->dZ(),
	       pVV->dX(), pVV->dY(), pVV->dZ());
    }
  }
#endif

  // Find out how many bdry (sub)segments are not currently in the mesh.
  bool qOK = qIsBdryConstrained(pVM, pSM, sCESubSegs,
				sCEInFacets, sCFSubFacets);
#ifndef NDEBUG
  vWriteFile_AnnotatedSurface(*pSM, "init", ".surf",
			      sCESubSegs, sCEInFacets, sCFSubFacets,
			      pVM);
#endif

  int iOuterPasses = 0;
  int iFaceRec3To2 = 0, iFaceRecEdge = 0;
  int iSplittings = 0;
  bool qRecoveredAllEdges = (sCESubSegs.empty() && sCEInFacets.empty());
  bool qTriedFacesBefore = false;
  while (!qOK && iOuterPasses < 10) {
    iOuterPasses++;
    vMessage(2, "Recovering surface edges (outer pass %d)...\n", iOuterPasses);
    int iInnerPasses = 0, iTotalRec;
    do {
      int iRecovered = 0, iOtherChanges;
      
      int iInitSubSegs = sCESubSegs.size();
      int iInitInFacets = sCEInFacets.size();
      int iInitSubFacets = sCFSubFacets.size();
      
      if (!sCESubSegs.empty()) {
	vRecoverEdges(pVM, pSM, sCESubSegs, iRecovered, iOtherChanges);
	vMessage(2, "Recovered %d missing subsegments; "
		 "made %d other changes.\n",
		 iRecovered, iOtherChanges);
	if (iRecovered) qTriedFacesBefore = false;
      }

      if (iRecovered == 0 && !sCEInFacets.empty()) {
	vRecoverEdges(pVM, pSM, sCEInFacets, iRecovered, iOtherChanges);
	vMessage(2, "Recovered %d missing in-facet edges; "
		 "made %d other changes.\n",
		 iRecovered, iOtherChanges);
	if (iRecovered) qTriedFacesBefore = false;
      }
      
      if (iRecovered == 0) {
	vRecoverFaces(pVM, pSM, sCFSubFacets, iRecovered, iFaceRec3To2,
		      iFaceRecEdge, 
		 qRecoveredAllEdges && qTriedFacesBefore);
	qTriedFacesBefore = true;
	vMessage(2, "Recovered %d missing faces; "
		 "%d 3-to-2 swaps, %d full edge swaps total.\n",
		 iRecovered, iFaceRec3To2, iFaceRecEdge);
	if (iRecovered) qTriedFacesBefore = false;
      }
      
      qOK = qIsBdryConstrained(pVM, pSM, sCESubSegs,
			       sCEInFacets, sCFSubFacets);
      qRecoveredAllEdges = (sCESubSegs.empty() && sCEInFacets.empty());

      iTotalRec = ((iInitSubSegs - sCESubSegs.size()) +
			(iInitInFacets - sCEInFacets.size()) +
			(iInitSubFacets - sCFSubFacets.size()));
      vMessage(2, "Total recoveries this pass: %d\n", iTotalRec);
      iInnerPasses++;
    } while (iInnerPasses < 5 && iTotalRec > 0);

    if (!qOK) {
      // Split edges.
      iSplittings++;
      qOK = qSplitEdges(pVM, pSM, sCESubSegs, sCEInFacets, sCFSubFacets,
			iSplittings);
    }
  }
  if (!qOK) {
#ifndef NDEBUG
    vWriteFile_AnnotatedSurface(*pSM, "failed", ".surf",
				sCESubSegs, sCEInFacets, sCFSubFacets,
				pVM);
#endif
    vFoundBug("creation of constrained 3D mesh from boundary data");
    exit(111);
  }
}

// static void vOldSurfaceRecovery(VolMesh * const pVM,
// 				SurfMesh * const pSM)
// {
//   //@@ Take a census to see which edges and faces need work to recover
//   std::set<ConstrainEdge> sCESubSegs;
//   std::set<ConstrainEdge> sCEInFacets;
//   std::set<ConstrainFace> sCFSubFacets;

//   // Find out how many bdry (sub)segments are not currently in the mesh.
//   bool qOK = qIsBdryConstrained(pVM, pSM, sCESubSegs,
// 				sCEInFacets, sCFSubFacets);

//   int iOuterPasses = 0;
//   int iFaceRec3To2 = 0, iFaceRecEdge = 0;
//   while (!qOK && iOuterPasses < 1) {
//     iOuterPasses++;
//     vMessage(2, "Recovering surface edges...\n");
//     vRecoverAllEdges(pVM, pSM, sCESubSegs, sCEInFacets, sCFSubFacets);

//     if (!sCESubSegs.empty()) {
//       vWriteFile_AnnotatedSurface(*pSM, "failed", ".surf",
// 				  sCESubSegs, sCEInFacets, sCFSubFacets,
// 				  pVM);
//       vMessage(0, "Failed to recover an input bdry edge.\n");
//       vFatalError("Increasing iMaxSplittings in " __FILE__ " -may- help.",
//  		  "3D constrained Delaunay tetrahedralization.");
//     }

//     if (!sCEInFacets.empty()) {
//       vMessage(2, "%d %s\n", static_cast<int>(sCEInFacets.size()),
// 	       "generated surface edges within input facets are not present.");
//       vMessage(2, "If all goes well, facet recovery will recover these.\n");
//     }

//     if (!sCFSubFacets.empty()) {
//       vMessage(2, "Recovering surface facets...\n");
//       // If all edges weren't recovered, there's a definite problem
//       assert(sCESubSegs.empty());
//       //@@ Recover faces
//       pVM->vDisallowEdgeSwapping();
//       int iTotalPasses = 0, iChange;
// #ifndef NDEBUG
//       vMessage(4, "Faces before attempt to recover: \n");
//       for (GR_index_t i_ = 0; i_ < pVM->iNumFaces(); i_++) {
// 	Face *pF = pVM->pFFace(i_);
// 	GR_index_t iVA = pVM->iVertIndex(pF->pVVert(0));
// 	GR_index_t iVB = pVM->iVertIndex(pF->pVVert(1));
// 	GR_index_t iVC = pVM->iVertIndex(pF->pVVert(2));
// 	vMessage(4, "%4u %4u %4u %4u\n", i_, iVA, iVB, iVC);
//       }
// #endif

//       do {
// 	iTotalPasses++;
// 	do {
// 	  iChange = 0;
// 	  vRecoverFaces(pVM, pSM, sCFSubFacets, iChange, iFaceRec3To2,
// 			iFaceRecEdge, false);
// 	} while (iChange && !sCFSubFacets.empty());
// 	if (iChange == 0) pVM->vAllowEdgeSwapping();
// 	qOK = qIsBdryConstrained(pVM, pSM, sCESubSegs, sCEInFacets,
// 				 sCFSubFacets);
//       } while ((!sCFSubFacets.empty()) &&
// 	       (sCESubSegs.empty() && sCEInFacets.empty()) &&
// 	       iTotalPasses < 10);
//     } // Had to recover faces as a separate pass
//   }
//   vMessage(2, "Face recovery required %d 3-to-2 swaps and %d full edge swaps.\n",
// 	   iFaceRec3To2, iFaceRecEdge);
//   if (!sCFSubFacets.empty() || !sCEInFacets.empty() || !sCESubSegs.empty()) {
//     vWriteFile_AnnotatedSurface(*pSM, "failed", ".surf",
// 				sCESubSegs, sCEInFacets, sCFSubFacets,
// 				pVM);
//     vFoundBug("creation of constrained 3D mesh from boundary data");
//   }
// }

void VolMesh::vRecoverConstrainedSurface(SurfMesh& SM, const int iNumOrigVerts,
					 const int iNumBBoxVerts)
{
  // You can't clear a std::stack, so this is the alternative.
  while (!stackSplitEdges.empty()) stackSplitEdges.pop();

  vNewSurfaceRecovery(this, &SM);

  //@@ Strip stuff outside the domain
  vMessage(1, "Removing extraneous tets and cleaning up...\n");

  vDeleteExternal(&SM, iNumOrigVerts, iNumBBoxVerts);
  if (!qValid())
    vFoundBug("creation of constrained 3D mesh from boundary data");

  // Mark vertices on internal boundaries.
  // Changed by SG 09/2008. Previous version commented out below.
  for(GR_index_t iIntBFace = 0; iIntBFace < iNumIntBdryFaces(); ++iIntBFace) {
    BFace* pBF = pBFIntBFace(iIntBFace);
    if (pBF->qDeleted()) continue;
    assert(pBF->eType() == Cell::eIntTriBFace);
    assert(pBF->iNumFaces() == 2 && pBF->iNumVerts() == 3);
    pBF->pFFace(0)->vSetFaceLoc(Face::eBdryTwoSide);
    pBF->pFFace(1)->vSetFaceLoc(Face::eBdryTwoSide);
    for(int iVert = 0; iVert < 3; ++iVert) {
      Vert* pV = pBF->pVVert(iVert);
      if(pV->iVertType() == Vert::eBdry) pV->vSetType(Vert::eBdryTwoSide);
    }    
  }

  // The old piece of code which messes up vertices of type eBdryApex and eBdryCurve
//   for (int iFace = 0; iFace < iNumFaces(); iFace++) {
//     Face *pF = pFFace(iFace);
//     if (pF->iFaceLoc() == Face::eBdryTwoSide) {
//       pF->pVVert(0)->vSetType(Vert::eBdryTwoSide);
//       pF->pVVert(1)->vSetType(Vert::eBdryTwoSide);
//       pF->pVVert(2)->vSetType(Vert::eBdryTwoSide);
//     }
//   }

  // Mark vertices on external boundaries.  Must be done after internal
  // boundaries.
  for (GR_index_t iBFace = 0; iBFace < iNumBdryFaces(); iBFace++) {
    BFace *pBF = pBFBFace(iBFace);
    if (pBF->qDeleted()) continue;
    if (pBF->eType() == Cell::eTriBFace ||
	pBF->eType() == Cell::eQuadBFace) {
      Face *pF = pBF->pFFace();
      pF->vSetFaceLoc(Face::eBdryFace);
      assert(pF->qLocked());
      for (int iV = 0; iV < 3; iV++) {
	Vert *pV = pF->pVVert(iV);
	if (pV->iVertType() == Vert::eBdryTwoSide) {
	  pV->vSetType(Vert::eBdryCurve);
	}
	int iVertInd = iVertIndex(pV);
	if (iVertInd < iNumOrigVerts) {
	  // Original verts can be tagged with the type that they have
	  // in the surface mesh.
	  pV->vSetType(SM.pVVert(iVertInd)->iVertType());
	}
	assert(pV->iVertType() != Vert::eInterior &&
	       pV->iVertType() != Vert::eUnknown &&
	       pV->iVertType() != Vert::eInvalid);
      } // end loop over this face
    } // Done dealing with external BFace's
  } // end loop over BFace's

  if (qBdryChangesAllowed()) {
    // Unlock all the bdry faces, which were presumably locked before this.
    for (int iFace = iNumFaces() - 1; iFace >= 0; iFace--) {
      pFFace(iFace)->vUnlock();
    }
  }

//   vSetSwapType(eMinSine);
//   iSwap();

  vMessage(2, "Surface recovery added %zd bdry Steiner points.\n",
	   stackSplitEdges.size());
  int iRemoved = -1, iRemoved2 = -1, iPass = 0, iRemainingInt = 0;
  while (!stackSplitEdges.empty() && (iRemoved != 0 || iRemoved2 != 0)) {
    iPass++;
    iRemoved = iRemoved2 = 0;
    int iAttempted = 0, iTotalSwaps = 0, iRemovedInt = 0;
    std::stack<SplitEdge> stackSplitEdgesTemp;
    while (!stackSplitEdges.empty()) {
      SplitEdge SE = stackSplitEdges.top();
      stackSplitEdges.pop();
      Vert *pV = SE.pVVolNew;
      assert(!pV->qDeleted() && pV->qDeletionRequested());

      // Remove as many vertices as possible by simple contraction.
      iAttempted++;
      int iNewSwaps = 0;
      Vert *apVTargets[] = {SE.pV0, SE.pV1};
      bool qSucc = qRemoveVertByContraction(pV, iNewSwaps, apVTargets, 2);
      iTotalSwaps += iNewSwaps;
      if (qSucc) {
	// This would be the place to remove the surface point if we cared.
// #ifndef NDEBUG
//        // This assertion is incorrect occasionally, depending on the
//        // order in which vertices are removed.
// 	Face *pF = findCommonFace(SE.pV0, SE.pV1, true);
// 	assert(pF->qValid());
// #endif
	iRemoved++;
      }
      else {
	// Since the simple thing failed, try something more
	// sophisticated.
	bool qDelInt;
	qSucc = qRemoveBdrySteinerPoint(SE, *this, iNewSwaps, qDelInt);
	iTotalSwaps += iNewSwaps;
	if (qSucc) {
	  // This would be the place to remove the surface point if we cared.
// #ifndef NDEBUG
//        // This assertion is incorrect occasionally, depending on the
//        // order in which vertices are removed.
// 	  Face *pF = findCommonFace(SE.pV0, SE.pV1, true);
// 	  assert(pF->qValid());
// #endif
	  iRemoved2++;
	  if (qDelInt) iRemovedInt++;
	  else iRemainingInt++;
	}
	else {
	  // Re-queue this point so we don't lose it.
	  stackSplitEdgesTemp.push(SE);
	}
      }
    }
    stackSplitEdges = stackSplitEdgesTemp;
    if (iAttempted > 0) {
      vMessage(2, "Removed %4d verts by contraction\n", iRemoved);
      vMessage(2, "        %4d verts using interior Steiner points\n",
	       iRemoved2);
      vMessage(2, "        %4zd boundary Steiner points left\n",
	       stackSplitEdges.size());
      vMessage(2, "        %4d of the resulting interior Steiner points\n",
	       iRemovedInt);
      vMessage(2, "        %4d interior Steiner points left\n",
	       iRemainingInt);
      vMessage(2, "Performed %d swaps in the process.\n", iTotalSwaps);
    }
  }
  
//   vAllowSwapRecursion();
//   vSetSwapType(eMinSine);
//   iSwap();
//   iSmooth(3);
//   iSwap();

//   int iTotalSwaps = 0;
//   int iAddlRemovals = 0;
//   for (GR_index_t i = 0; i < iNumVerts(); i++) {
//     Vert *pV = pVVert(i);
//     if (pV->qDeletionRequested() && !pV->qDeleted()) {
//       // Found an interior Steiner point to remove.
//       int iRecentSwaps;
//       if (qRemoveVert(pV, iRecentSwaps)) {
// 	iTotalSwaps += iRecentSwaps;
// 	iAddlRemovals++;
// 	iRemainingInt--;
//       }
//     }
//   }
//   vMessage(2, "Removed %d addl interior Steiner points (%d swaps); %d remaining\n",
// 	   iAddlRemovals, iTotalSwaps, iRemainingInt);
}

//@ Triangulation of a generalized boundary geometry
VolMesh::VolMesh(SurfMesh& SM, const int iQualMeas,
		 const double dRes, const double dGrade,
		 const double dMaxAngle)
  : Mesh(*(SM.pECGetVerts())),
    qOKToChangeSurfaceEdges(true), qDoEdgeSwapping(true),
    qStrictPatchChecking(true), 
    dMaxAngleForSurfSwap(dMaxAngle),
    ECTriF(), ECQuadF(), ECTriBF(),
    ECQuadBF(), ECTet(), ECPyr(), ECPrism(), ECHex(), ECIntTriBF(),
    ECIntQuadBF(), pB3D(),  qBdryFromMesh(false)
{
  SUMAA_LOG_EVENT_BEGIN(INIT_TETRA);
  dMeshResolution = dRes;
  dLipschitzAlpha = dGrade;
  pB3D = SM.pBoundaryData();
  qBdryFill = false;
  pQ = new Quality(this, iQualMeas);

  // Set up an outer triangulation of a big brick
  double dXMin, dXMax, dYMin, dYMax, dZMin, dZMax;
  dXMin = dYMin = dZMin =  1.e100;
  dXMax = dYMax = dZMax = -1.e100;

  int iVert, iNVerts = iNumVerts();
  for (iVert = 0; iVert < iNVerts; iVert++) {
    double dX = pVVert(iVert)->dX();
    double dY = pVVert(iVert)->dY();
    double dZ = pVVert(iVert)->dZ();
    dXMin = min(dXMin, dX);
    dXMax = max(dXMax, dX);
    dYMin = min(dYMin, dY);
    dYMax = max(dYMax, dY);
    dZMin = min(dZMin, dZ);
    dZMax = max(dZMax, dZ);
  }

  double dXMean = 0.5 * (dXMin + dXMax);
  double dYMean = 0.5 * (dYMin + dYMax);
  double dZMean = 0.5 * (dZMin + dZMax);
  double dDX = dXMax - dXMin;
  double dDY = dYMax - dYMin;
  double dDZ = dZMax - dZMin;

  // Make the region roughly cubical
  double dMaxAspect = 0.1;
  if (dDX < dMaxAspect * dDY) dDX = dMaxAspect*dDY;
  if (dDX < dMaxAspect * dDZ) dDX = dMaxAspect*dDZ;

  if (dDY < dMaxAspect * dDX) dDY = dMaxAspect*dDX;
  if (dDY < dMaxAspect * dDZ) dDY = dMaxAspect*dDZ;

  if (dDZ < dMaxAspect * dDX) dDZ = dMaxAspect*dDX;
  if (dDZ < dMaxAspect * dDY) dDZ = dMaxAspect*dDY;

  double dXLo = dXMean - 3*dDX;
  double dXHi = dXMean + 3*dDX;
  double dYLo = dYMean - 3*dDY;
  double dYHi = dYMean + 3*dDY;
  double dZLo = dZMean - 3*dDZ;
  double dZHi = dZMean + 3*dDZ;

  int iNumOrigVerts = iNumVerts();
  vMeshInBrick(dXLo, dXHi, dYLo, dYHi, dZLo, dZHi);

  vMessage(1, "Inserting surface points to create unconstrained volume mesh.\n");
  // Do Delaunay insertion of all the existing verts in the mesh.  This
  // is a little weird, because the vert data is already -stored- in the
  // mesh, it just isn't currently connected to anything.
  vSetSwapType(eDelaunay);
  int iNumSwaps = 0;
  int iStatusInterval = max(25, iNumOrigVerts / 10);
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
  std::set<Vert*> spVInsertLater;
  for (iVert = 0; iVert < iNumOrigVerts; iVert++) {
    Vert *pV = pVVert(iVert);
    // Don't insert this point yet if it isn't connected to anything in
    // the surface mesh.
    Vert *pVS = SM.pVVert(iVert);
    if (!pVS->pFHintFace()->qValid()) {
      spVInsertLater.insert(pVS);
      continue;
    }

    // Make sure that the small angle flag is copied over from the
    // surface mesh.
    pV->vSetSmallAngleCorner(pVS->qIsSmallAngleCorner());

    // Insert, then swap.  Force insertion at the specified point and
    // use the existing vertex location.
    int iNewSwaps;
    int iC = 0;

    while (pCCell(iC)->qDeleted()) iC++;

    const double * adCoords = pV->adCoords();

#ifndef NDEBUG
    bool qSuccess = qInsertPoint(adCoords, pCCell(iC), &iNewSwaps, true,
				 true, pV);
    assert(qSuccess);
#else
    (void) qInsertPoint(adCoords, pCCell(iC), &iNewSwaps, true,
			true, pV);
#endif
    iNumSwaps += iNewSwaps;
    if ((iVert+1) % iStatusInterval == 0) {
      vMessage(2, "Inserted %5d verts out of %5d; made %5d swaps.\n",
	       iVert+1, iNumOrigVerts, iNumSwaps);
    }
  }
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
  vSetAllHintFaces();
  assert(qValid());

  bool qRealRecur = qSwapRecursionAllowed();
  vDisallowSwapRecursion();
//   vSetSwapType(eMinSine);
//   iNumSwaps = iSwap();
//   vMessage(2, "Made %d swaps for min sine\n", iNumSwaps);
//   vSetSwapType(eDelaunay);
//   iNumSwaps = iSwap();
//   vMessage(2, "Made %d swaps for Delaunay\n", iNumSwaps);

  vMessage(1, "Recovering surface mesh...\n");
  // Add some dummy verts to surface mesh so that identical surface and
  // volume mesh indices are identical points.  Mark them for cleanup
  // before we exit.  These can be marked as already deleted, since
  // nothing will ever connect to them anyway.
  for (int ii = 0; ii < 8; ii++) {
    (void) SM.createVert(0,0,0);
  }

  vRecoverConstrainedSurface(SM, iNumOrigVerts);

  // No purge has taken place at all yet so that the previous recovery
  // stuff would work.  Here it is.
  vPurge();

  // Swap to ensure (?) a Delaunay mesh!
  vMessage(3, "Swapping towards a Delaunay mesh.\n");
  GRUMMP::DelaunaySwapDecider3D SDDel(true);
  GRUMMP::SwapManager3D DelSwap(&SDDel, this);
  DelSwap.swapAllFaces();

//   // Now try again to remove interior vertices.
//   vRemoveTaggedVerts();

  // Now insert all the vertices that were removed from the bdry rep
  // before meshing, as well as verts that were extras to begin with.

  iStatusInterval = max(25, int(spVInsertLater.size()/10));
  int iStatusValue = iStatusInterval;
  int iVertsInserted = 0;
  iNumSwaps = 0;
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
  std::set<Vert*>::iterator iter = spVInsertLater.begin();
  std::set<Vert*>::iterator iterEnd = spVInsertLater.end();

  while (iter != iterEnd) {
    Vert *pVS = *iter;
    iter++;

    assert(!pVS->pFHintFace()->qValid() && !pVS->qDeleted());

    const double * adCoords = pVS->adCoords();
    vMessage(4, "Attempting to insert a vertex at (%10G %10G %10G)\n",
	     adCoords[0], adCoords[1], adCoords[2]);

    // This is a slow way to do the re-insertion, but it -will- work.
    bool qHit = false;
    Cell *pC;
    double adBary[4], dBestBary = -1.e20;
    for (GR_index_t iC = 0; !qHit && iC < iNumTetCells(); iC++) {
      pC = pCCell(iC);
      if (pC->qDeleted()) continue;
      TetCell* pTC = dynamic_cast<TetCell*>(pC);
      assert(pTC != NULL);
      pTC->vBarycentrics(adCoords, adBary);
      double dMinBary = min(min(adBary[0], adBary[1]),
			     min(adBary[2], adBary[3]));
      if (dMinBary > dBestBary) dBestBary = dMinBary;
      qHit = (iFuzzyComp(dMinBary, 0) != -1);
    }
    if (!qHit) {
      vMessage(0, "Best bary: %f\n", dBestBary);
      vFatalError("Tried to insert a point outside the mesh",
		  "VolMesh constructor");
    }

    // This vertex may already have been inserted during surface
    // recovery, in which case we don't need to worry about it.
    double dMaxBary = max(max(adBary[0], adBary[1]),
			  max(adBary[2], adBary[3]));
    if (iFuzzyComp(dMaxBary, 1) == 0) {
      continue;
    }

    int iNewSwaps = 0;

#ifndef NDEBUG
    bool qSuccess =
#endif
      qInsertPoint(adCoords, pC, &iNewSwaps, true, true);
#ifndef NDEBUG
    assert(qSuccess);
#endif
    iVertsInserted++;
    iNumSwaps += iNewSwaps;
    if (iVertsInserted > iStatusValue) {
      vMessage(2, "Inserted %5d extra verts from the surface mesh, and made %5d swaps.\n",
	       iVertsInserted, iNumSwaps);
      iStatusValue += iStatusInterval;
    }
  }
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
  if (iVertsInserted > 0) DelSwap.swapAllFaces();

  vSetAllHintFaces();
  assert(qValid());
  SUMAA_LOG_EVENT_END(INIT_TETRA);


  if (qRealRecur) {
    vAllowSwapRecursion();
  }
  else {
    vDisallowSwapRecursion();
  }

  // Set up length scale
  vInitLengthScale(dMeshResolution, dLipschitzAlpha);

  // Clean up
  vPurge();
#ifndef NDEBUG
  vWriteVTK_ASCII(*this, "succeeded");
#endif
  SM.vPurge();
}
