#include "GR_TetMeshBuilder.h"
#include "GR_Constrain.h"
#include "GR_events.h"
#include "GR_Geometry.h"
#include "GR_Mesh.h"
#include "GR_SurfaceSampler.h"
#include "GR_Subseg.h"
#include "GR_SurfMeshBuilder.h"
#include "GR_SwapDecider.h"
#include "GR_SwapManager.h"
#include "GR_TetMeshInitializer.h"
#include "GR_TetMeshRefiner.h"
#include "GR_Vec.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

#include "GR_AdaptPred.h"

#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "FacetEvalTool.hpp"
#include "FacetSurface.hpp"
#include "GeometryQueryTool.hpp"
#include "RefVertex.hpp"
#include "RefEdge.hpp"
#include "RefFace.hpp"
#include "RefVolume.hpp"

#include <algorithm>
#include <deque>
#include <iterator>
#include <map>
#include <set>
#include <vector>
#include <utility>

using std::deque;
using std::map;
using std::multimap;
using std::pair;
using std::set;
using std::vector;

//The following three are private:
TetMeshBuilder::
TetMeshBuilder() 
  : m_mesh_init(NULL), m_surf_mesh(NULL), 
    m_sample_vert_dict(), m_subseg_vert_dict() { assert(0); }

TetMeshBuilder::
TetMeshBuilder(const TetMeshBuilder&)
  : m_mesh_init(NULL), m_surf_mesh(NULL), 
    m_sample_vert_dict(), m_subseg_vert_dict() { assert(0); }

TetMeshBuilder& TetMeshBuilder::
operator=(const TetMeshBuilder&) { assert(0); return *this; }

//Only public constructor
TetMeshBuilder::
TetMeshBuilder(SurfMeshBuilder* surf_mesh, 
	       set<Subseg*>* subsegs) 
  : m_mesh_init(NULL), m_surf_mesh(surf_mesh),
    m_sample_vert_dict(), m_subseg_vert_dict() {

  SUMAA_LOG_EVENT_BEGIN(BDRY_RECOVER);

  init_mesh();

  insert_sample_verts();
  
  recover_boundary();

  assert(m_mesh_init->get_mesh()->qValid());
  vMessage(2, "Passed validity check.\n");

  //m_surf_mesh->output_stitched_surface("surf.mesh");

#ifndef NDEBUG
  int bef_num_verts = m_mesh_init->get_mesh()->iNumVerts();
  m_mesh_init->get_mesh()->vPurge();
  int aft_num_verts = m_mesh_init->get_mesh()->iNumVerts();
  assert(bef_num_verts == aft_num_verts);
  assert(m_mesh_init->get_mesh()->qValid());
  vMessage(2, "Passed validity check.\n");
#endif

  clean_exterior();

  SUMAA_LOG_EVENT_END(BDRY_RECOVER);

  //After the boundary is recovered, swap the interior
  //to obtain constrained Delaunay tets. We are not sure
  //this is guaranteed to work in theory, but in practice,
  //it never failed.

  //NOTE: The global swap below implies a call to vPurge which
  //screws up the vertex dictionaries. Therefore a vPurge
  //must be made and the dictionaries must be updated BEFORE
  //calling iSwap to keep the dict. valid.

#ifndef NDEBUG
  //If the number of verts does not change during swap, we are safe.
  GR_index_t dbg_num_verts = m_mesh_init->get_mesh()->iNumVerts();
#endif

  VolMesh* mesh = m_mesh_init->get_mesh();
  GRUMMP::DelaunaySwapDecider3D SDDel(false);
  GRUMMP::SwapManager3D DelSwap(&SDDel, mesh);
  DelSwap.swapAllFaces();

#ifndef NDEBUG
  assert(dbg_num_verts == m_mesh_init->get_mesh()->iNumVerts());
#endif

  vWriteVTK_ASCII(*(m_mesh_init->get_mesh()), "tetmesh.vtk");

#ifndef NDEBUG

  //I want to make sure that all the pointers to vertices 
  //remain constant through the mesh purge. If the purge is called, then 
  //the pointers to the vertices in m_subseg_vert_dict will
  //remain valid i.e. they will still point to the correct object.

  std::map<Vert*, Vert*> vert_map;
  mesh->vPurge(&vert_map);
  std::map<Vert*, Vert*>::const_iterator 
    it = vert_map.begin(), it_end = vert_map.end();
  for( ; it != it_end; ++it) assert(it->first == it->second);

#else

  mesh->vPurge();

#endif
  
  assert(mesh->qValid());
  assert(mesh_is_const_delaunay());

  //If we want to get the subsegments, then output them.
  if(subsegs) get_subseg_copy(subsegs);
  
}

//Destructor
TetMeshBuilder::
~TetMeshBuilder() {

  if(m_mesh_init) delete m_mesh_init;
 
}

bool TetMeshBuilder::mesh_is_const_delaunay() const {

  //still have to figure out how to reliably detect 
  //unswappable configs so that they do not affect refinement.
  return true; 

  //Check that the mesh is truely constrained Delaunay at this point.
  //For every cell, check the neighboring cells to see if the vertex
  //opposing the face they share is inside the cell's circumsphere.

  VolMesh* mesh = m_mesh_init->get_mesh();
  assert(mesh->qValid());

  Cell* dbg_cell1, *dbg_cell2;
  Face* dbg_face;
  Vert* dbg_vert;

  for(int i = mesh->iNumCells() - 1; i >= 0; --i) {

    dbg_cell1 = mesh->pCCell(i);
    if(dbg_cell1->qDeleted()) continue;
    assert(dbg_cell1->eType() == Cell::eTet);

    for(int j = 0; j < 4; ++j) {

      dbg_face  = dbg_cell1->pFFace(j);
      assert(!dbg_face->qDeleted());
      assert(dbg_face->qHasCell(dbg_cell1));
      dbg_cell2 = dbg_face->pCCellLeft() == dbg_cell1 ?
	dbg_face->pCCellRight() : dbg_face->pCCellLeft();
      assert(dbg_face->qHasCell(dbg_cell2));
      assert(dbg_cell1 != dbg_cell2);
      if(dbg_cell2->eType() != Cell::eTet) continue;
      dbg_vert = dbg_cell2->pVVertOpposite(dbg_face);
	
      //Check if the vertex is in the circumsphere.
      if( TetCell::vert_inside_sphere(dbg_vert, dbg_cell1) ) {

	//Because of tie-break procedure in the swapping routines, it is possible that
	//if the vertex is close enough to the circumsphere, the predicate used
	//in TetCell does not provide the expected result, bail out if this is the case.
	if(iInsphere(dbg_cell1->pVVert(0), dbg_cell1->pVVert(0),
		     dbg_cell1->pVVert(0), dbg_cell1->pVVert(0), dbg_vert) == 0) continue;

	Vert* pVVertA, *pVVertB, *pVVertC, *pVVertD, *pVVertE, 
	  *pVPivot0, *pVPivot1, *pVOther;
	TetCell* apTCTets[4];
	int iNTets;
	printf("Face category = %d\n", 
	       dynamic_cast<TriFace*>(dbg_face)->eCategorizeFace
	       (pVVertA, pVVertB, pVVertC, pVVertD, pVVertE, 
		apTCTets, iNTets, pVPivot0, pVPivot1, pVOther));

	vFatalError("Could not build a constrained Delaunay Tetrahedralization",
		    "TetMeshBuilder::mesh_is_const_delaunay()");
	abort();

      }
	
    }

  }
 
  printf("The tetrahedralization is constrained Delaunay\n");
  return true;

}

VolMesh* TetMeshBuilder::
get_mesh() const { return m_mesh_init->get_mesh(); }

void TetMeshBuilder::
insert_sample_verts() {

  assert(m_mesh_init);

  //Stick all the sampling vertices into the mesh. 
  
  typedef pair< VertexDict::iterator, bool > InsertResult;
  
  { //We begin with subseg vertices   

    vector<Subseg*> subsegs; m_surf_mesh->get_subsegs(subsegs);
    vector<Subseg*>::iterator it_sub     = subsegs.begin(), 
                              it_sub_end = subsegs.end();

    for( ; it_sub != it_sub_end;  ++it_sub) {
 
      Subseg* subseg = *it_sub;
      Vert *sub_beg_vert = subseg->get_beg_vert(), *sub_end_vert = subseg->get_end_vert();

      InsertResult ins_beg = m_subseg_vert_dict.insert
	( std::make_pair(sub_beg_vert, static_cast<Vert*>(NULL)) );
      InsertResult ins_end = m_subseg_vert_dict.insert
	( std::make_pair(sub_end_vert, static_cast<Vert*>(NULL)) ); 

      //if(!ins_beg.second && !ins_end.second) continue; //both verts have already been inserted.

      Vert *new_beg_vert = ins_beg.first->second, *new_end_vert = ins_end.first->second;

      if(ins_beg.second) {

	if(ins_end.second) {
	  assert(!new_beg_vert && !new_end_vert);
	  new_beg_vert = ins_beg.first->second = 
	    m_mesh_init->insert_vert_in_mesh(sub_beg_vert);
	  new_end_vert = ins_end.first->second = 
	    m_mesh_init->insert_vert_in_mesh(sub_end_vert, new_beg_vert);
	}
	else {
	  assert(!new_beg_vert && new_end_vert);
	  new_beg_vert = ins_beg.first->second = 
	    m_mesh_init->insert_vert_in_mesh(sub_beg_vert, new_end_vert);
	}
	
      }

      else {

	if(ins_end.second) {
	  assert(new_beg_vert && !new_end_vert);
	  new_end_vert = ins_end.first->second = 
	    m_mesh_init->insert_vert_in_mesh(sub_end_vert, new_beg_vert);
	}
	else {
	  assert(new_beg_vert && new_end_vert);
	}

      }      

      assert(new_beg_vert && new_end_vert); //makes sure that vertices exist for the subseg.

      vector<SubsegBridge*> subseg_bridges; subseg->get_children(subseg_bridges);    
      vector<SubsegBridge*>::iterator it_bridge     = subseg_bridges.begin(),
                                      it_bridge_end = subseg_bridges.end();
    
      for( ; it_bridge != it_bridge_end; ++it_bridge) {

	SubsegBridge* bridge = *it_bridge;
	Vert* bridge_beg_vert = bridge->get_vert(0);
	Vert* bridge_end_vert = bridge->get_vert(1);
      
	assert( iFuzzyComp( dDIST3D(sub_beg_vert->adCoords(), 
				    bridge_beg_vert->adCoords() ), 0.) == 0 );
	assert( iFuzzyComp( dDIST3D(sub_end_vert->adCoords(), 
				    bridge_end_vert->adCoords() ), 0.) == 0 );
      
	m_sample_vert_dict.insert( std::make_pair(bridge_beg_vert, new_beg_vert) );
	m_sample_vert_dict.insert( std::make_pair(bridge_end_vert, new_end_vert) );
	
      }

    }

  }
  
  {  //Proceed with face samplers, being careful not to insert the same vertex twice.

    typedef vector<SurfaceSampler*> SamplerVec;
    typedef vector<Face*> SurfTriVec;

    SamplerVec face_samplers; m_surf_mesh->get_face_samplers(face_samplers);
    SamplerVec::iterator it_sampler     = face_samplers.begin(),
                         it_sampler_end = face_samplers.end();

    for( ; it_sampler != it_sampler_end; ++it_sampler) {

      SurfaceSampler* sampler = *it_sampler;

      SurfTriVec surf_tri; sampler->get_restricted_faces(surf_tri);
      SurfTriVec::iterator it_tri     = surf_tri.begin(),
	                   it_tri_end = surf_tri.end();

      for( ; it_tri != it_tri_end; ++it_tri) {

	Face* face = *it_tri;
	assert(face->iNumVerts() == 3);
	InsertResult ins_res[3];
	
	for(int i = 0; i < 3; ++i)
	  ins_res[i] = m_sample_vert_dict.insert
	    ( std::make_pair(face->pVVert(i), static_cast<Vert*>(NULL)) );
	
	if(!ins_res[0].second && !ins_res[1].second && !ins_res[2].second) continue;

	Vert* new_vert[] = { ins_res[0].first->second, 
			     ins_res[1].first->second,
			     ins_res[2].first->second };

	if(!new_vert[0]) {	 
	  if(!new_vert[1]) {	   
	    if(!new_vert[2]) {
	      assert(!new_vert[0] && !new_vert[1] && !new_vert[2]);
	      new_vert[2] = ins_res[2].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(2));
	      new_vert[1] = ins_res[1].first->second = 	
		m_mesh_init->insert_vert_in_mesh(face->pVVert(1), new_vert[2]);
	      new_vert[0] = ins_res[0].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(0), new_vert[2], new_vert[1]);
	    }
	    else {
	      assert(!new_vert[0] && !new_vert[1] && new_vert[2]);
	      new_vert[1] = ins_res[1].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(1), new_vert[2]);
	      new_vert[0] = ins_res[0].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(0), new_vert[2], new_vert[1]);
	    }
	  }
	  else {
	    if(!new_vert[2]) {
	      assert(!new_vert[0] && new_vert[1] && !new_vert[2]);
	      new_vert[2] = ins_res[2].first->second =
		m_mesh_init->insert_vert_in_mesh(face->pVVert(2), new_vert[1]);
	      new_vert[0] = ins_res[0].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(0), new_vert[1], new_vert[2]);
	    }
	    else {
	      assert(!new_vert[0] && new_vert[1] && new_vert[2]);
	      new_vert[0] = ins_res[0].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(0), new_vert[1], new_vert[2]);
	    }	
	  }
	}
	else {
	  if(!new_vert[1]) {
	    if(!new_vert[2]) {
	      assert(new_vert[0] && !new_vert[1] && !new_vert[2]);
	      new_vert[2] = ins_res[2].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(2), new_vert[0]);
	      new_vert[1] = ins_res[1].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(1), new_vert[2], new_vert[0]);
	    }
	    else {
	      assert(new_vert[0] && !new_vert[1] && new_vert[2]);
	      new_vert[1] = ins_res[1].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(1), new_vert[2], new_vert[0]);
	    }
	  }
	  else {
	    if(!new_vert[2]) {
	      assert(new_vert[0] && new_vert[1] && !new_vert[2]);
	      new_vert[2] = ins_res[2].first->second = 
		m_mesh_init->insert_vert_in_mesh(face->pVVert(2), new_vert[1], new_vert[0]);
	    }
	    else {
	      assert(new_vert[0] && new_vert[1] && new_vert[2]);
	    }
	  }
	}	  
      
	assert(new_vert[0] && new_vert[1] && new_vert[2]);

      }
	
    }

  }

}

void TetMeshBuilder::
init_mesh() {

  assert(m_surf_mesh);

  //Obtain all sampling vertices, compute a bounding box and build an initial mesh

  CubitBox box = GeometryQueryTool::instance()->model_bounding_box();

  CubitVector mini(box.minimum()), maxi(box.maximum()),
              mean(0., 0., 0.), diff(0., 0., 0.);

  vector<Vert*> subseg_verts, sample_verts;
  m_surf_mesh->get_subseg_verts(subseg_verts);
  m_surf_mesh->get_sample_verts(sample_verts);

//   printf("number of subseg verts = %d\n", static_cast<int>(subseg_verts.size()) ); 

  std::for_each(subseg_verts.begin(), subseg_verts.end(), ComputeBoundingBox(&mini, &maxi));
  std::for_each(sample_verts.begin(), sample_verts.end(), ComputeBoundingBox(&mini, &maxi));

  mean.set( 0.5 * (mini + maxi) );
  diff.set( maxi - mini );

  // Make the region roughly cubical
  double max_aspect = 0.1;
  if (diff.x() < max_aspect * diff.y()) diff.x(max_aspect * diff.y());
  if (diff.x() < max_aspect * diff.z()) diff.x(max_aspect * diff.z());
  if (diff.y() < max_aspect * diff.x()) diff.y(max_aspect * diff.x());
  if (diff.y() < max_aspect * diff.z()) diff.y(max_aspect * diff.z());
  if (diff.z() < max_aspect * diff.x()) diff.z(max_aspect * diff.x());
  if (diff.z() < max_aspect * diff.y()) diff.z(max_aspect * diff.y());

  mini.set( mean - diff );
  maxi.set( mean + diff );

//   printf("mini: %lf %lf %lf\n", mini.x(), mini.y(), mini.z());
//   printf("maxi: %lf %lf %lf\n", maxi.x(), maxi.y(), maxi.z());

  m_mesh_init = new TetMeshInitializer(CubitBox(mini, maxi));

  assert(m_mesh_init->get_mesh()->qSimplicial());

}

bool TetMeshBuilder::
recover_boundary() {

  vMessage(1, "Recovering surface mesh...\n");

  set<RecoverEdge> subcurves, surface_edges;
  set<RecoverFace> subfacets;
  set<RecoverFace>::iterator it_facet;
  
  RecoverFace my_face;
  vector<RecoverFace> faces_not_recovered;

  if( is_bdry_constrained(subcurves, surface_edges, subfacets) ) return true;
 
  while( !subcurves.empty() || !surface_edges.empty() || 
	 !subfacets.empty() ) {

    if(!subcurves.empty() || !surface_edges.empty()) {
      if( recover_all_edges(subcurves, surface_edges) ) return true;
      if( is_bdry_constrained(subcurves, surface_edges, subfacets) ) return true;
      assert(subcurves.empty() && surface_edges.empty());
    }
    else if(subfacets.empty()) {
      assert(subcurves.empty() && surface_edges.empty());
      return true;
    }
    
    for(it_facet = subfacets.begin(); it_facet != subfacets.end(); ++it_facet) {
      my_face = *it_facet;
      if(recover_face_flip(my_face) == -1) faces_not_recovered.push_back(my_face);
    }

    //If we get here, face flipping alone has failed to recover the boundary
    //so let's try inserting for get the missing faces back.

    while(!faces_not_recovered.empty()) {
      my_face = faces_not_recovered.back();
      recover_face_split(my_face);
      faces_not_recovered.pop_back();
    }
    
    if( is_bdry_constrained(subcurves, surface_edges, subfacets) ) return true;
 
//     //If we get here, face flipping alone has failed to recover the boundary
//     //Go over the same routine again, but this time split the missing faces
//     //instead of try flips.

//     if(!subcurves.empty() || !surface_edges.empty()) {
//       if( recover_all_edges(subcurves, surface_edges) ) return true;
//       if( is_bdry_constrained(subcurves, surface_edges, subfacets) ) return true;
//       assert(subcurves.empty() && surface_edges.empty());
//     }
//     else if(subfacets.empty()) {
//       assert(subcurves.empty() && surface_edges.empty());
//       return true;
//     }

//     for(it_facet = subfacets.begin(); it_facet != subfacets.end(); ++it_facet) {
//       if(!( (*it_facet).get_face()->is_restricted_delaunay() )) continue;
//       recover_face_split(*it_facet);
//     }
    
//     if( is_bdry_constrained(subcurves, surface_edges, subfacets) ) return true;

  }

  return true;

}

bool TetMeshBuilder::
recover_all_edges(set<RecoverEdge>& bdry_edges_to_recover,
		  set<RecoverEdge>& face_edges_to_recover) {

  if(bdry_edges_to_recover.empty() &&
     face_edges_to_recover.empty()) return false;

  typedef set<RecoverEdge> EdgeSet;
  typedef set<RecoverFace> FaceSet;
  typedef EdgeSet::iterator ItRE;

  EdgeSet edges(bdry_edges_to_recover);
  FaceSet faces; //this is a dummy set.

  bool allow_insertion = false;
  int num_passes, num_fruitless_passes, num_inserts, num_changes;
  int edge_recovered;

  m_mesh_init->get_mesh()->vDisallowSwapRecursion();

  if( edges.empty() )
    edges.insert( face_edges_to_recover.begin(), 
		  face_edges_to_recover.end() );

  do {

    num_passes = 0;
    num_fruitless_passes = 0;

    do {

      assert(!edges.empty());

      ++num_passes; 
      ++num_fruitless_passes; 
      num_changes = 0; 
      num_inserts = 0;

      ItRE it_edge = edges.begin(), it_edge_end = edges.end(), it_edge_tmp;

      for( ; it_edge != it_edge_end; ) {

	if(allow_insertion) {
	  edge_recovered = 0;
// 	  edge_recovered = recover_edge_split(*it_edge);
// 	  ++num_inserts;
	}
	else
	  edge_recovered = recover_edge_flip(*it_edge);


	switch(edge_recovered) {
	case 1: //Recovered
	  num_fruitless_passes = 0;
	  it_edge_tmp = it_edge++;
	  edges.erase(it_edge_tmp);
	  ++num_changes; 
	  break;
	case -1:
	  ++num_changes;
	default: // Deliberate fallthrough
	  ++it_edge;
	  break;
	}

      } // Done checking non-constrained segments
    
      if(edges.empty()) {

	if( is_bdry_constrained(bdry_edges_to_recover, face_edges_to_recover, faces) ) return true;
	
	edges.clear();
	if(bdry_edges_to_recover.empty())
	  edges.insert( face_edges_to_recover.begin(), 
			face_edges_to_recover.end() );
	else
	  edges.insert( bdry_edges_to_recover.begin(), 
			bdry_edges_to_recover.end() );
	
	// If swapping fixed all the edges, don't turn off insertion,
	// or you could loop forever trying to do surface recovery.
	if(allow_insertion && num_inserts != 0) {
	  assert(num_fruitless_passes == 0);
	  num_passes =  0;
	  allow_insertion = false;
	}
	
      }

    } while(num_fruitless_passes < 2 && num_changes &&  
	    (!edges.empty()) && num_passes < 10); 

    if(edges.empty()) return false;
    if(!m_mesh_init->get_mesh()->qBdryChangesAllowed()) { assert(0); }
    
    if(allow_insertion) {
      
      // Since allowing insertion wasn't enough, force a split of
      // all edges not yet constrained.  Enable swap recursion in
      // the volume mesh while splitting.

      ItRE it_edge = edges.begin(), it_edge_end = edges.end(), it_edge_tmp;
      
      m_mesh_init->get_mesh()->vAllowSwapRecursion();
      
      for( ; it_edge != it_edge_end; ++it_edge)
	recover_edge_split(*it_edge);
      

      m_mesh_init->get_mesh()->vDisallowSwapRecursion();

      allow_insertion = false;
      
      if( is_bdry_constrained(bdry_edges_to_recover, face_edges_to_recover, faces) ) 
	return true;
      
      edges.clear();
      if(bdry_edges_to_recover.empty())
	edges.insert(face_edges_to_recover.begin(), face_edges_to_recover.end());
      else
	edges.insert(bdry_edges_to_recover.begin(), bdry_edges_to_recover.end());

    }
    
    else { allow_insertion = true; }

  } while(!edges.empty() && num_passes < 20);

  if(!edges.empty())
    vFatalError("Failed to recover edges\n", "Edge recovery");

  return false;

}

int TetMeshBuilder::
recover_edge_flip(const RecoverEdge& edge_to_recover) {
  
  VolMesh* mesh = m_mesh_init->get_mesh();
  Vert* v0 = edge_to_recover.get_v0();
  Vert* v1 = edge_to_recover.get_v1();
  
  int num_passes = 0, change, num_skips, ret_value;
  Face* faces_skipped[20];

  do {
    
    ++num_passes;
    vMessage(4, "Pass %d to remove edge from v0 = %p to v1 = %p\n", num_passes, v0, v1);

    bool hit_edge = false;
    int ream_result = mesh->iReamPipe(v0, v1, hit_edge, faces_skipped, num_skips);

    if(ream_result == 1) return 1; // Pipe is unclogged
    if(ream_result == 0) { change = 1; ret_value = -1; } //change made
    else { assert(ream_result == -1); ret_value = -1; }

    if(hit_edge) { //try from the other end
      hit_edge = false;
      num_skips = 0;

      //pasto here???
      ream_result = mesh->iReamPipe(v0, v1, hit_edge, faces_skipped, num_skips);

      if(ream_result == 1) return 1; // Pipe is unclogged; not bloody likely
      if(ream_result == 0) { change = 1; ret_value = -1; } //change made
      else { assert(ream_result == -1); ret_value = -1; }
    }

    // If an edge was hit, try to remove it
    if(hit_edge) vMessage(3, "Unresolved edge hit!  Edge not recovered.\n");    

  } while(change && num_passes < 5);

  return ret_value;

}

int TetMeshBuilder::
recover_edge_split(const RecoverEdge& edge_to_recover) {

  //printf("SPLIT EDGE\n");

  static int global_num_splits = 0;
  
  //First, split the subseg in m_surf_mesh. One (or possibly many) vertices
  //will be inserted. These will also correspond to sample verts inserted in
  //corresponding samplers. We have to make sure that all these vertices are
  //properly put in our dictionaries.

  VertVec new_verts;

  Subseg* subseg_to_split = edge_to_recover.get_subseg();
  TriFace* face_to_split; RefFace* insert_surf;
  
  if(!subseg_to_split) { //Case of an in-surface edge

    face_to_split = edge_to_recover.get_face();
    insert_surf = edge_to_recover.get_surface();
    assert(face_to_split && insert_surf);
    
    if(!face_to_split->is_restricted_delaunay()) return 0;
    if(face_to_split->qDeleted()) return 0;

    global_num_splits += m_surf_mesh->split_face_and_sample(face_to_split, insert_surf, &new_verts);
    
  }

  else { //Case of a subsegment or subcurve.

    assert(subseg_to_split);

    if(subseg_to_split->is_deleted()) return 0;

    global_num_splits += m_surf_mesh->split_subseg_and_sample(subseg_to_split, &new_verts);

  }

  insert_new_verts(new_verts);
    
  printf("Needed to split edge to recover, total number of edge insertions = %d\n", 
	 global_num_splits);

  return 1;

}

int TetMeshBuilder::
recover_face_flip(const RecoverFace& face_to_recover) {

  VolMesh* mesh = m_mesh_init->get_mesh();

  //@@ Find all faces and edges violating the given surface face.
  Vert* vert0 = face_to_recover.get_v0();
  Vert* vert1 = face_to_recover.get_v1();
  Vert* vert2 = face_to_recover.get_v2();
  assert(vert0 && vert1 && vert2);
  
  // First, make sure that all the edges of the surface face are
  // present.  If they aren't, this means that they are interior edges
  // to a surface facet (and so weren't recovered earlier when doing
  // bdry subsegments); and that there is a vertex encroaching on them
  // (which makes it so that the Delaunay tetrahedralization doesn't
  // match the constrained DT).  If the edge is missing, recover it
  // without point insertion (this should always be possible, but note
  // that there's still a check to be sure that it works).
  int edge_a_ok = recover_edge_flip( RecoverEdge(vert0, vert1) );
  int edge_b_ok = recover_edge_flip( RecoverEdge(vert1, vert2) );
  int edge_c_ok = recover_edge_flip( RecoverEdge(vert2, vert0) );
  if ( edge_a_ok != 1 || edge_b_ok != 1 || edge_c_ok != 1 ) {
    printf("cannot recover edge: %d %d %d\n", edge_a_ok, edge_b_ok, edge_c_ok);
    return recover_face_split(face_to_recover);
//     printf("cannot recover edge: %d %d %d\n", edge_a_ok, edge_b_ok, edge_c_ok);
//     return -1;
//     vFatalError("Failed to recover a non-subsegment bdry edge.",
// 		"3D constrained Delaunay tetrahedralization.");

  }

  set<BadEdge> bad_edges; set<Face*> bad_faces;
  mesh->vIdentifyBadEdgesAndFaces(vert0, vert1, vert2, bad_edges, bad_faces);

  //@@ For each face in the list, swap it if possible.
  // Swap only if the face is of type T32 and all of its equatorial
  // points are on the same side of or in the plane of the surface face.
  bool change, global_change = false;

  do {

    change = false;

    deque<Face*> bad_face_queue;
    std::copy(bad_faces.begin(), bad_faces.end(), 
	      std::back_inserter(bad_face_queue));

    while (!bad_face_queue.empty()) {

      Face* face = bad_face_queue.front(); bad_face_queue.pop_front();
      if(face->qDeleted()) continue;

      TriFace* triface = dynamic_cast<TriFace*>(face);
      assert(triface);    

      Vert *vertA, *vertB, *vertC, *vertD, *vertE, *vertJ0, *vertJ1, *vertJ2;
      
      int num_tets;
      TetCell* tet_cells[4];
      
      eFaceCat face_cat = triface->eCategorizeFace(vertA, vertB, vertC,
						   vertD, vertE, tet_cells, num_tets,
						   vertJ0, vertJ1, vertJ2);

      if(face_cat == eT32) {

	assert(num_tets == 3);
	
	Face *face_delete[3];
	face_delete[0] = pFCommonFace(tet_cells[0], tet_cells[1]);
	face_delete[1] = pFCommonFace(tet_cells[1], tet_cells[2]);
	face_delete[2] = pFCommonFace(tet_cells[2], tet_cells[0]);
	assert(face_delete[0]->qValid());
	assert(face_delete[1]->qValid());
	assert(face_delete[2]->qValid());

	int orient_D = iOrient3D(vert0, vert1, vert2, vertD);
	int orient_E = iOrient3D(vert0, vert1, vert2, vertE);
	if(orient_D * orient_E != -1) continue;
	
	assert(triface == face_delete[0] || 
	       triface == face_delete[1] || 
	       triface == face_delete[2]);

	change = global_change = true;

#ifndef NDEBUG
	assert( mesh->iReconfTet32(tet_cells, triface, vertA, vertB, vertC, vertD, vertE) == 1 );
#else
	mesh->iReconfTet32(tet_cells, triface, vertA, vertB, vertC, vertD, vertE);
#endif

	// Check each of the three faces to be sure that either
	// they've been deleted or all of their verts lie on the
	// same side of the target face (including ties).

	for(int i = 0; i < 3; i++) {

	  Face *face_test = face_delete[i];

	  if (face_test->qDeleted())
	    bad_faces.erase(face_test);
	  else {
	    Vert *vert_test[] = { face_test->pVVert(0), face_test->pVVert(1), 
				  face_test->pVVert(2) };
	    int orient[] = { iOrient3D(vert0, vert1, vert2, vert_test[0]), 
			     iOrient3D(vert0, vert1, vert2, vert_test[1]),
			     iOrient3D(vert0, vert1, vert2, vert_test[2]) };

	    if( (orient[0] * orient[1] != -1) &&
		(orient[1] * orient[2] != -1) &&
		(orient[2] * orient[0] != -1) )
	      bad_faces.erase(face_test);
	  }

	}

      } // T32 face

    } // End loop over all bad faces

    mesh->vIdentifyBadEdgesAndFaces(vert0, vert1, vert2, bad_edges, bad_faces);
    
    // Do this until no more progress can be made by simple swapping or
    // until all offending edges are removed
  
  } while(change && !bad_faces.empty());

  if(bad_faces.empty()) return 1;
  else return -1;

}

int TetMeshBuilder::
recover_face_split(const RecoverFace& face_to_recover) {
 
  //printf("SPLIT FACE\n");

  static int global_num_splits = 0;

  RefFace* insert_surf = face_to_recover.get_surface();
  TriFace* face_to_split = face_to_recover.get_face();
  assert(insert_surf && face_to_split);

  if(face_to_split->qDeleted()) return 0;

  VertVec new_verts;
  global_num_splits += m_surf_mesh->split_face_and_sample(face_to_split, insert_surf, &new_verts);
  
  insert_new_verts(new_verts);  
  
  vMessage(1, "Needed to split face to recover, total number of face insertions = %d\n", 
	   global_num_splits);

  return 1;

}

void TetMeshBuilder::
insert_new_verts(const VertVec& new_verts) {
  
  VolMesh* mesh = m_mesh_init->get_mesh();
  assert(mesh->qSimplicial());
  
  typedef multimap<Vert*, Vert*> VertMap;
  VertMap new_sub_verts;

  Vert *new_vert, *sub_vert, *sam_vert;

  VertVec::const_iterator itv     = new_verts.begin(), 
                          itv_end = new_verts.end();

  for( ; itv != itv_end; ++itv) {

    sub_vert = itv->first;
    sam_vert = itv->second;
    assert(sam_vert);

    if(sub_vert) 
      new_sub_verts.insert( std::make_pair(sub_vert, sam_vert) );

    else {
      new_vert = mesh->createVert(sam_vert);

      m_sample_vert_dict.insert( std::make_pair(sam_vert, new_vert) );
      insert_vert_and_swap(new_vert);

      new_vert->vSetType(Vert::ePseudoSurface);

      assert( dDIST3D(sam_vert->adCoords(), new_vert->adCoords()) < 1.e-12 );
      assert( sam_vert->get_parent_topology() == new_vert->get_parent_topology() );
      assert( sam_vert->iVertType() == new_vert->iVertType() );
      assert( new_vert->iVertType() == Vert::ePseudoSurface );
    }

  }

  VertMap::iterator itm, itm_beg, itm_end;

  while(!new_sub_verts.empty()) {

    itm_beg = new_sub_verts.begin();
    itm_end = new_sub_verts.upper_bound(itm_beg->first);

    sub_vert = itm_beg->first;
    new_vert = mesh->createVert(sub_vert);
   
    m_subseg_vert_dict.insert( std::make_pair(sub_vert, new_vert) );
    insert_vert_and_swap(new_vert);

    new_vert->vSetType(Vert::eBdryCurve);

    for( itm = itm_beg; itm != itm_end; itm++) {
      
      sam_vert = itm->second;
      assert(sub_vert && sam_vert);
      m_sample_vert_dict.insert( std::make_pair(sam_vert, new_vert) );

      assert( dDIST3D(sub_vert->adCoords(), sam_vert->adCoords()) < 1.e-12 );
      assert( sub_vert->iVertType() == sam_vert->iVertType());
      assert( sub_vert->get_parent_topology() == sam_vert->get_parent_topology() );
    
    }

    assert( dDIST3D(sub_vert->adCoords(), new_vert->adCoords()) < 1.e-12 );
    assert( sub_vert->get_parent_topology() == new_vert->get_parent_topology() );
    assert( sub_vert->iVertType() == new_vert->iVertType() );
    assert( new_vert->iVertType() == Vert::eBdryCurve );

    new_sub_verts.erase(itm_beg, itm_end);

  }

}

bool TetMeshBuilder::
insert_vert_and_swap(Vert* const vertex) {

  VolMesh* mesh = m_mesh_init->get_mesh();
  assert(mesh->eSwapType() == eDelaunay);

  //vertex is created and initialized, but has not been inserted in the mesh yet.
  //Well, now is the time to insert it. With all the swaps, our mesh is probably
  //no longer Delaunay, so we cannot use our favorite Watson insertion scheme.
  //We will insert and swap (locally) to obtain a (locally) Delaunay mesh. 

  assert(vertex->get_parent_topology());

  double new_coords[] = { vertex->dX(), vertex->dY(), vertex->dZ() };

  int num_swaps = 0, cell_idx = 0;
  Cell *cell = mesh->pCCell(cell_idx);

  while(!cell->iFullCheck()) 
    cell = mesh->pCCell(++cell_idx);

  // Any live tet will do, since the domain is concave.
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
  bool insert_ok =
    mesh->qInsertPoint(new_coords, cell, &num_swaps, true, true, vertex);
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
 
  return insert_ok;

}

bool TetMeshBuilder::
is_bdry_constrained(set<RecoverEdge>& bdry_edges_to_recover,
		    set<RecoverEdge>& face_edges_to_recover,
		    set<RecoverFace>& faces_to_recover) const {

  //Clear all containers
  bdry_edges_to_recover.clear();
  face_edges_to_recover.clear();
  faces_to_recover.clear();

  //Fill these sets based on current mesh configuration:
  std::set<RecoverEdge> tet_mesh_edges, surf_mesh_bdry_edges, surf_mesh_face_edges;
  std::set<RecoverFace> tet_mesh_faces, surf_mesh_faces;

  VolMesh* tet_mesh = m_mesh_init->get_mesh();
  int num_cells = tet_mesh->iNumCells();

  //Start by filling the two tetrahedral mesh containers:
  for(int i = 0 ; i < num_cells; i++) {
    
    Cell* cell = tet_mesh->pCCell(i);
    if(cell->qDeleted()) continue;
    
    assert(cell->qValid());
    assert(cell->iNumFaces() == 4);
    assert(cell->iNumVerts() == 4);

    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(0), cell->pVVert(1)) );
    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(0), cell->pVVert(2)) );
    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(0), cell->pVVert(3)) );
    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(1), cell->pVVert(2)) );
    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(1), cell->pVVert(3)) );
    tet_mesh_edges.insert( RecoverEdge(cell->pVVert(2), cell->pVVert(3)) );

    for(int j = 0; j < 4; j++) {

      Face* face = cell->pFFace(j);
      assert(face->qValid());
      assert(face->iNumVerts() == 3);

      tet_mesh_faces.insert( RecoverFace(face->pVVert(0), face->pVVert(1), 
					 face->pVVert(2)) );
      
    }

  }

  //Now do the same with the surface mesh:
  typedef vector<Subseg*> SubsegVector; SubsegVector subsegs; 
  typedef vector< pair<Face*, RefFace*> > FaceVec; FaceVec rest_faces; 

  m_surf_mesh->get_subsegs(subsegs);
  m_surf_mesh->get_restricted_faces(rest_faces);

  SubsegVector::iterator its = subsegs.begin(), its_end = subsegs.end();
  FaceVec::iterator itf = rest_faces.begin(), itf_end = rest_faces.end();

  for( ; its != its_end; ++its) {
    
    Subseg* sub = *its;
    assert(!sub->is_deleted());
    Vert *v0 = sub->get_beg_vert(), *v1 = sub->get_end_vert();

    assert(m_subseg_vert_dict.count(v0) == 1 &&
	   m_subseg_vert_dict.count(v1) == 1);

    RecoverEdge recover_edge(m_subseg_vert_dict.find(v0)->second,
			     m_subseg_vert_dict.find(v1)->second);
    //Keeping track of which subseg is represented by recover_edge for subsequent splits.
    recover_edge.set_subseg(sub);

    surf_mesh_bdry_edges.insert( recover_edge );

  }
  
  for( ; itf != itf_end; ++itf) {

    Face* face = itf->first;
    RefFace* ref_face = itf->second;

    assert(!face->qDeleted());
    assert(face->iNumVerts() == 3);

    Vert *v0 = face->pVVert(0), 
         *v1 = face->pVVert(1), 
         *v2 = face->pVVert(2);

    assert(m_sample_vert_dict.count(v0) == 1 &&
	   m_sample_vert_dict.count(v1) == 1 &&
	   m_sample_vert_dict.count(v2) == 1);
    
#ifndef NDEBUG
    if(v0->iVertType() == Vert::eBdryApex)
      assert(dynamic_cast<RefVertex*>(v0->get_parent_topology()));
    else if(v0->iVertType() == Vert::eBdryCurve)
      assert(dynamic_cast<RefEdge*>(v0->get_parent_topology()));
    else if(v0->iVertType() == Vert::ePseudoSurface)
      assert(dynamic_cast<RefFace*>(v0->get_parent_topology()));
    else
      assert(0);

    if(v1->iVertType() == Vert::eBdryApex)
      assert(dynamic_cast<RefVertex*>(v1->get_parent_topology()));
    else if(v1->iVertType() == Vert::eBdryCurve)
      assert(dynamic_cast<RefEdge*>(v1->get_parent_topology()));
    else if(v1->iVertType() == Vert::ePseudoSurface)
      assert(dynamic_cast<RefFace*>(v1->get_parent_topology()));
    else
      assert(0);

    if(v2->iVertType() == Vert::eBdryApex)
      assert(dynamic_cast<RefVertex*>(v2->get_parent_topology()));
    else if(v2->iVertType() == Vert::eBdryCurve)
      assert(dynamic_cast<RefEdge*>(v2->get_parent_topology()));
    else if(v2->iVertType() == Vert::ePseudoSurface)
      assert(dynamic_cast<RefFace*>(v2->get_parent_topology()));
    else
      assert(0);
#endif

    TriFace* triface = dynamic_cast<TriFace*>(face);
    assert(triface);

    RecoverEdge edge1(m_sample_vert_dict.find(v0)->second,
		      m_sample_vert_dict.find(v1)->second);
    RecoverEdge edge2(m_sample_vert_dict.find(v0)->second,
		      m_sample_vert_dict.find(v2)->second);
    RecoverEdge edge3(m_sample_vert_dict.find(v1)->second,
		      m_sample_vert_dict.find(v2)->second);

    if(surf_mesh_bdry_edges.find(edge1) == surf_mesh_bdry_edges.end()) {
      edge1.set_face(triface); edge1.set_surface(ref_face);
      surf_mesh_face_edges.insert(edge1);
    }
    if(surf_mesh_bdry_edges.find(edge2) == surf_mesh_bdry_edges.end()) {
      edge2.set_face(triface); edge2.set_surface(ref_face);
      surf_mesh_face_edges.insert(edge2);
    }    
    if(surf_mesh_bdry_edges.find(edge3) == surf_mesh_bdry_edges.end()) {
      edge3.set_face(triface); edge3.set_surface(ref_face);
      surf_mesh_face_edges.insert(edge3);
    }
 
    RecoverFace face_to_recover(m_sample_vert_dict.find(v0)->second, 
				m_sample_vert_dict.find(v1)->second, 
				m_sample_vert_dict.find(v2)->second);

    face_to_recover.set_surface(ref_face);
    face_to_recover.set_face(triface);

    surf_mesh_faces.insert( face_to_recover );

  }

  std::set_difference(surf_mesh_bdry_edges.begin(), surf_mesh_bdry_edges.end(), 
		      tet_mesh_edges.begin(), tet_mesh_edges.end(),
		      std::inserter(bdry_edges_to_recover, bdry_edges_to_recover.begin()));

  std::set_difference(surf_mesh_face_edges.begin(), surf_mesh_face_edges.end(),
		      tet_mesh_edges.begin(), tet_mesh_edges.end(),
		      std::inserter(face_edges_to_recover, face_edges_to_recover.begin()));

  std::set_difference(surf_mesh_faces.begin(), surf_mesh_faces.end(),
		      tet_mesh_faces.begin(), tet_mesh_faces.end(),
		      std::inserter(faces_to_recover, faces_to_recover.begin()));

  printf("Number of bdry edges = %d\n", static_cast<int>(surf_mesh_bdry_edges.size()));
  printf("Number of face edges = %d\n", static_cast<int>(surf_mesh_face_edges.size()));

  //Issue a report on the results
  if (bdry_edges_to_recover.empty() && face_edges_to_recover.empty() &&
      faces_to_recover.empty()) {
    vMessage(1, "All edges and faces are properly constrained.\n");
    return true;
  }
  else {
    vMessage(1, "Missing %d input subcurves, %d/%d total edges, %d/%d faces.\n",
	     static_cast<int>(bdry_edges_to_recover.size()),
	     static_cast<int>(bdry_edges_to_recover.size()) + 
	     static_cast<int>(face_edges_to_recover.size()),
	     static_cast<int>(surf_mesh_bdry_edges.size()) +
	     static_cast<int>(surf_mesh_face_edges.size()), 
	     static_cast<int>(faces_to_recover.size()), 
	     static_cast<int>(rest_faces.size()));
    return false;
  }

}

void TetMeshBuilder::
clean_exterior() {

  VolMesh* mesh = m_mesh_init->get_mesh();

  //Must start with a purge because new vertices might
  //have been inserted and faces flipped during boundary 
  //recovery. This leads to deleted faces that might
  //correspond to a restricted face (basically, there
  //are more than one copy of the face, one is valid, the
  //others are deleted).

  mesh->vPurge();
  assert(m_mesh_init->get_mesh()->qValid());
  vMessage(2, "Passed validity check.\n");

  //Mark all the cells with an invalid region tag.
  for(int i = mesh->iNumCells() - 1; i >=0 ; i--) {
    mesh->pCCell(i)->vSetRegion(iInvalidRegion);
#ifndef NDEBUG
    if(!mesh->pCCell(i)->qDeleted())
      assert(mesh->pCCell(i)->iFullCheck());
#endif
  }

  //The first 8 vertices are the ones connected to the 
  //outside bounding box. They need to be deleted.
  for(int i = 0; i < 8; i++)
    mesh->pVVert(i)->vMarkDeleted();

  //Mark the outside boundary faces for deletion.
  assert(mesh->iNumBdryFaces() == 12);
  for(int i = mesh->iNumBdryFaces() - 1; i >= 0; i--) {
    BFace *bface = mesh->pBFBFace(i);
    bface->pFFace()->vSetFaceLoc(Face::eBdryFace);
    bface->vSetRegion(iInvalidRegion);
    mesh->deleteBFace(bface);
  }

  //Build the set of restricted faces. These faces, which should
  //appear in the initial tetrahedralization, will become the boundary
  //faces of the mesh.

  map<Face*, RefFace*> face_surface_map;

  {
    
    Face* face;
    map<RecoverFace, RefFace*> restrict_faces;
    map<RecoverFace, RefFace*>::iterator itrf;

    typedef vector< pair<Face*, RefFace*> > FaceVec; FaceVec rest_faces; 
    m_surf_mesh->get_restricted_faces(rest_faces);
    FaceVec::iterator itf = rest_faces.begin(), itf_end = rest_faces.end();
  
    for( ; itf != itf_end; ++itf) {

      face = itf->first;
      assert(!face->qDeleted());
      assert(face->iNumVerts() == 3);

      Vert *v0 = face->pVVert(0), *v1 = face->pVVert(1), *v2 = face->pVVert(2);
      assert(m_sample_vert_dict.count(v0) == 1 && m_sample_vert_dict.count(v1) == 1 &&
	     m_sample_vert_dict.count(v2) == 1);
 
      restrict_faces.insert( std::make_pair(RecoverFace(m_sample_vert_dict.find(v0)->second, 
							m_sample_vert_dict.find(v1)->second, 
							m_sample_vert_dict.find(v2)->second), 
					    itf->second) );

    }

#ifndef NDEBUG
    GR_index_t num_restrict = 0;
#endif
    
    for(int i = mesh->iNumFaces() - 1; i >=0 ; i--) {

      face = mesh->pFFace(i);
      if(face->qDeleted()) {
	assert(restrict_faces.count(RecoverFace(face->pVVert(0), face->pVVert(1), 
						face->pVVert(2))) == 0);
	continue;
      }

      face->unset_restricted_delaunay();

      RecoverFace rec_face(face->pVVert(0), face->pVVert(1), face->pVVert(2));
      itrf = restrict_faces.find(rec_face);

      if( itrf != restrict_faces.end() ) {
	face->set_restricted_delaunay();
	set_surf_compare_tol(itrf->second, 1.e-14);
	face_surface_map.insert(std::make_pair(face, itrf->second));
#ifndef NDEBUG
	++num_restrict;
#endif
      }

    }

    assert(num_restrict == restrict_faces.size());
    assert(restrict_faces.size() == face_surface_map.size());

  }  

  //Find cells to delete by walking. Do not cross boundary
  //faces and restricted faces. Each visited set will have
  //the cells from an entire region.

  {

    bool found_exterior = false;
    int region_tag = 0, this_region_tag;

    Cell* cell, *next_cell;
    Face* face;

    set<Cell*> all_cells, visited;
    set<Cell*>::iterator itc, itc_end;
    deque<Cell*> to_visit;
    
#ifndef NDEBUG
    GR_index_t num_valid_cells = 0, num_visited_cells = 0;
#endif

    for(int i = mesh->iNumCells() - 1; i >=0 ; i--) {
      cell = mesh->pCCell(i);
      assert(cell->iRegion() == iInvalidRegion);
      if(cell->qDeleted()) continue;
      all_cells.insert(cell);      
    }

#ifndef NDEBUG
    num_valid_cells = all_cells.size();
#endif

    while(!all_cells.empty()) {
      
      cell = *(all_cells.begin());
      to_visit.push_back(cell);

      while(!to_visit.empty()) {

	cell = to_visit.front();
	to_visit.pop_front();

	assert(!cell->qDeleted());
	assert(cell->eType() == Cell::eTet);
	assert(cell->iNumFaces() == 4);

	if(!visited.insert(cell).second) continue;
	all_cells.erase(cell);

	for(int i = 0; i < 4; ++i) {

	  face = cell->pFFace(i);
	  assert(!face->qDeleted());

	  if(face->is_restricted_delaunay()) continue; //do not cross restrict delaunay faces.
	  next_cell = cell == face->pCCellRight() ? face->pCCellLeft() : face->pCCellRight();

	  if(next_cell->qValid() &&
	     next_cell->eType() == Cell::eTet ) to_visit.push_back(next_cell);
	  
	}

      }

      if(!found_exterior) {
	BFace* bface = mesh->pBFBFace(0);
	assert(bface->qDeleted());
	assert(bface->iNumFaces() == 1);
	cell = bface->pFFace(0)->pCCellRight() == bface ? 
	  bface->pFFace(0)->pCCellLeft() : bface->pFFace(0)->pCCellRight();
	if(visited.count(cell) == 1) {
	  found_exterior = true;
	  this_region_tag = iOutsideRegion;
	}
	else {
	  this_region_tag = ++region_tag;
	}
      }
      else this_region_tag = ++region_tag;
      
      itc_end = visited.end();
      for(itc = visited.begin(); itc != itc_end; ++itc) {
	assert(this_region_tag != iMaxRegion);
	cell = *itc;
	cell->vSetRegion(this_region_tag);
      }      
      
#ifndef NDEBUG
      num_visited_cells += visited.size();
#endif

      visited.clear();

    }

    if(region_tag == 0) {
      vFatalError("I recovered the surface triangulation properly\n"
		  "but I cannot find a watertight model. Must abort.",
		  "TetMeshBuilder::clean_exterior()");
    }

    assert(num_valid_cells == num_visited_cells);
    assert(found_exterior);

  }

  //Mark faces for deletion. All the faces between two deleted
  //tets must be deleted. Then add the boundary faces where
  //they are needed.

  {

    Face* face;
    Cell* lcell, *rcell, *cell;

  // This next loop appears to be completely unnecessary.
//     //First pass over the faces. Identify and mark 
//     //those that must be deleted.
    
//     for(int i = mesh->iNumFaces() - 1; i >= 0; --i) {

//       face = mesh->pFFace(i);
//       if(face->qDeleted()) continue;
//       lcell = face->pCCellLeft();
//       rcell = face->pCCellRight();

//       if(lcell->eType() == Cell::eTet && rcell->eType() == Cell::eTet) {
// 	if(lcell->iRegion() == iOutsideRegion && 
// 	   rcell->iRegion() == iOutsideRegion) face->vMarkDeleted();
//       }
//       else face->vMarkDeleted();
      
//     }

    //Second pass over the faces. Those marked restricted 
    //will become boundary faces (either interior or exterior).
    //As new faces get created in the loop, make sure we do not
    //over the original number of faces.

    int num_faces = mesh->iNumFaces();
#ifndef NDEBUG
    GR_index_t num_restrict_faces = 0;
#endif

    for(int i = 0; i < num_faces; ++i) {

      face = mesh->pFFace(i);
      if(face->qDeleted()) continue;

      //If the face is tagged restricted, 
      //create the boundary face for it.
      if(face->is_restricted_delaunay()) {

	assert(!face->qDeleted());
	assert(face_surface_map.count(face) == 1);
	face->unset_restricted_delaunay();
#ifndef NDEBUG
	++num_restrict_faces;
#endif
	lcell = face->pCCellLeft();
	rcell = face->pCCellRight();
	// It's possible that one of the cells has been deleted.  That's
	// okay; that side is the exterior.
	assert(rcell->qValid() || lcell->qValid());
	assert((!rcell->qValid() || rcell->eType() == Cell::eTet) &&
	       (!lcell->qValid() || lcell->eType() == Cell::eTet));
		
	//Internal boundary.  Need to duplicate the face and add an
	//internal bdry face between the two.
	if(lcell->qValid() && (lcell->iRegion() != iOutsideRegion) &&
	   rcell->qValid() && (rcell->iRegion() != iOutsideRegion)) {
	  
	  //Create a new internal tri boundary face

	  // FIX ME  CFOG, 19 Oct, 2010
	  // This is a bit of a hack:  create a fake internal BFace to
	  // attach the patch to, then clone this face and stick an internal
	  // bdry face in between.  Really should be able to create a bface,
	  // then classify it onto a piece of the geometry; or pass the
	  // geometry info to the creation routine directly instead of
	  // attached to a bdry face.

	  BFace *bfaceTmp = mesh->pBFNewBFace(3, true);
	  bfaceTmp->set_topological_parent(face_surface_map.find(face)->second);

	  BFace *bface = mesh->createBFace(face, bfaceTmp);
	  mesh->deleteBFace(bfaceTmp);

	  //Set the vertex type correctly for surface verts 
	  //(should now be ePseudoSurface, we want eBdryTwoSide)
	  assert(bface->iNumVerts() == 3);
	  for(int ii = 0; ii < 3; ++ii) {
	    assert( bface->pVVert(ii)->iVertType() == Vert::eBdryApex ||
		    bface->pVVert(ii)->iVertType() == Vert::eBdryCurve ||
		    bface->pVVert(ii)->iVertType() == Vert::eBdryTwoSide || //this case if already changed
		    bface->pVVert(ii)->iVertType() == Vert::ePseudoSurface );
	    if(bface->pVVert(ii)->iVertType() == Vert::ePseudoSurface)
	      bface->pVVert(ii)->vSetType(Vert::eBdryTwoSide);
	  }

	  assert(lcell->iFullCheck() == 1);
	  assert(rcell->iFullCheck() == 1);
	  assert(bface->iFullCheck() == 1);
	  assert(face->iFullCheck());
	}

	//A regular boundary face.
	else {
	  bool qLeftIsOutside =
	    rcell->qValid() && rcell->iRegion() != iOutsideRegion;
	  assert(qLeftIsOutside ||
		 (lcell->qValid() && lcell->iRegion() != iOutsideRegion));
	  	  
	  cell = (qLeftIsOutside) ? lcell : rcell;
	  if (cell) mesh->deleteCell(cell);

	  BFace* bface = mesh->createBFace(face);
	  bface->set_topological_parent(face_surface_map.find(face)->second);
	  assert(bface->eType() == Cell::eTriBFace);

	  //Set the vertex types correctly for surface verts 
	  //(should now be ePseudoSurface, we want eBdry)
	  assert(bface->iNumVerts() == 3);
	  for(int ii = 0; ii < 3; ++ii) {
	    assert( bface->pVVert(ii)->iVertType() == Vert::eBdryApex ||
		    bface->pVVert(ii)->iVertType() == Vert::eBdryCurve ||
		    bface->pVVert(ii)->iVertType() == Vert::eBdry || //this case if already changed
		    bface->pVVert(ii)->iVertType() == Vert::ePseudoSurface );
	    if(bface->pVVert(ii)->iVertType() == Vert::ePseudoSurface)
	      bface->pVVert(ii)->vSetType(Vert::eBdry);
	  }

	}

      }

    }

#ifndef NDEBUG
    //Making sure I created the same number of boundary faces 
    //as there were restricted faces. 
    GR_index_t count = 0;
    for(int i = mesh->iNumTotalBdryFaces() - 1; i>= 0; --i) {
      BFace* bface = mesh->pBFBFace(i);
      if(!bface->qDeleted()) { 
	++count;
	assert(bface->get_topological_parent());
      }
    }
    assert(count == num_restrict_faces);
#endif

  }

#ifndef NDEBUG

  //Some post-verification to make sure everything is correct.

  {

    for(int i = mesh->iNumCells() - 1; i >= 0; --i) {
      Cell* cell = mesh->pCCell(i);
      if (cell->iRegion() == iOutsideRegion) mesh->deleteCell(cell);
      if(cell->qDeleted()) continue;
      assert(cell->eType() == Cell::eTet);
      assert(cell->iFullCheck() == 1);
      for(int j = 0; j < 4; ++j) assert(!cell->pFFace(j)->qDeleted());
    }
    
    for(int i = mesh->iNumFaces() - 1; i >= 0; --i) {

      Face* face = mesh->pFFace(i);
      if(face->qDeleted()) continue;
    
      face->unset_restricted_delaunay();
      assert(!face->pCCellLeft()->qDeleted());
      assert(!face->pCCellRight()->qDeleted());

      if(face->iNumCells() == 1) {
	assert(face->iFaceLoc() == Face::eBdryFace ||
	       face->iFaceLoc() == Face::eBdryTwoSide);
	if(face->pCCellLeft()->eType() == Cell::eTet) {
	  assert(face->pCCellRight()->eType() == Cell::eTriBFace ||
		 face->pCCellRight()->eType() == Cell::eIntTriBFace);
	}
	else {
	  assert(face->pCCellRight()->eType() == Cell::eTet);
	  assert(face->pCCellLeft()->eType() == Cell::eTriBFace ||
		 face->pCCellLeft()->eType() == Cell::eIntTriBFace);
	}
      }
      else {
	assert(face->iNumCells() == 2);
	assert(face->iFaceLoc() == Face::eInterior);
	assert(face->pCCellLeft()->eType() == Cell::eTet &&
	       face->pCCellRight()->eType() == Cell::eTet);
      }
      
      assert(face->iFullCheck() == 1);      

    }

  }

#endif
  
  //Finally, let's purge the deleted entities

  map<Vert*, Vert*> vert_map;
  m_mesh_init->get_mesh()->vPurge(&vert_map);
  assert(m_mesh_init->get_mesh()->qValid());

  update_vert_dict(vert_map);

}

void TetMeshBuilder::update_vert_dict(const std::map<Vert*, Vert*>& verts_old_to_new) {

  Vert *old_vert;
  VertexDict::iterator it, it_end;

  for(int i = 0; i < 2; ++i) {

    switch(i) {
    case 0: it = m_subseg_vert_dict.begin(), it_end = m_subseg_vert_dict.end(); break;
    case 1: it = m_sample_vert_dict.begin(), it_end = m_sample_vert_dict.end(); break;
    default: assert(0);
    }

    for( ; it != it_end; ++it) {

      old_vert = it->second;
      assert(verts_old_to_new.count(old_vert) == 1);
    
      it->second = verts_old_to_new.find(old_vert)->second;
      assert(!it->second->qDeleted());

    }

  }

}

void TetMeshBuilder::get_subseg_copy(std::set<Subseg*>* subseg_copy) const {

  if(!subseg_copy) return;

  assert(m_surf_mesh);
  
  std::vector<Subseg*> subsegs;
  m_surf_mesh->get_subsegs(subsegs);
  
  Subseg* my_subseg;
  Vert *v0, *v1;

  std::vector<Subseg*>::iterator it = subsegs.begin(), it_end = subsegs.end();

  for( ; it != it_end; ++it) {
    
    my_subseg = *it;
   
    //The vertex of my_subseg are not in the tet mesh, but those in SubsegManager.
    //The correspondance is stored in m_subseg_vert_dict.
    //Find the replacements.
    v0 = my_subseg->get_beg_vert();
    v1 = my_subseg->get_end_vert();

    assert(v0 != v1);
    assert(m_subseg_vert_dict.count(v0) == 1 &&
	   m_subseg_vert_dict.count(v1) == 1);

    v0 = m_subseg_vert_dict.find(v0)->second;
    v1 = m_subseg_vert_dict.find(v1)->second;

    //Now, create the subseg copy and store it in the set.
    //We do not care about the SubsegBridges... they are 
    //no longer useful for boundary-recovered tet meshes.
    subseg_copy->insert( new Subseg(v0, v1, 
				    my_subseg->get_beg_param(), 
				    my_subseg->get_end_param(), 
				    my_subseg->get_ref_edge()) );

  }

}

void TetMeshBuilder::ComputeBoundingBox::
operator()(const Vert* const vertex) {

  m_mini->x( std::min(m_mini->x(), vertex->dX()) );
  m_mini->y( std::min(m_mini->y(), vertex->dY()) );
  m_mini->z( std::min(m_mini->z(), vertex->dZ()) );

  m_maxi->x( std::max(m_maxi->x(), vertex->dX()) );
  m_maxi->y( std::max(m_maxi->y(), vertex->dY()) );
  m_maxi->z( std::max(m_maxi->z(), vertex->dZ()) );

}

CubitVector TetMeshBuilder::
surf_normal_at_point(RefFace* const surface,
		     const CubitVector& point,
		     const double tolerance) const {

  Surface* surf = surface->get_surface_ptr();
  CubitVector dummy, normal;

  FacetSurface* facet_surf = dynamic_cast<FacetSurface*>(surf);
  if(facet_surf) {
     facet_surf->get_eval_tool()->compare_tol(tolerance);
     facet_surf->closest_point(point, &dummy, &normal);
  }
  else {
    vFatalError("Only support for facet modeler is implemented at the moment",
		"TetMeshBuilder::surf_normal_at_point()");
  }

  return normal;  

}

void TetMeshBuilder::
set_surf_compare_tol(RefFace* const surface, const double tolerance) const {

  Surface* surf = surface->get_surface_ptr();
  FacetSurface* facet_surf = dynamic_cast<FacetSurface*>(surf);

  if(facet_surf)
     facet_surf->get_eval_tool()->compare_tol(tolerance);
  else
    vFatalError("Only support for facet modeler is implemented at the moment",
		"TetMeshBuilder::surf_normal_at_point()");

}

void TetMeshBuilder::
print_markings() const {
 
  VolMesh* mesh = m_mesh_init->get_mesh();

  double sum = 0.;
  double region_sum[iOutsideRegion + 1];
  std::fill(region_sum, region_sum + iOutsideRegion + 1, 0.);

  for(GR_index_t i = 0; i < mesh->iNumCells(); i++) {

    Cell* cell = mesh->pCCell(i);
    if(cell->qDeleted()) continue;

    double size = cell->dSize();
    int region  = cell->iRegion();
    region_sum[region] += size;

    if( !(region == iOutsideRegion || 
	  region == iInvalidRegion) ) sum += size;
        
    vMessage(1, "Cell %3u. Verts %3u, %3u, %3u, %3u.  Size: %10.4g (%10.4g) Region %3d (%10.4g).\n",
	     i, mesh->iVertIndex(cell->pVVert(0)),
	     mesh->iVertIndex(cell->pVVert(1)), 
	     mesh->iVertIndex(cell->pVVert(2)),
	     mesh->iVertIndex(cell->pVVert(3)), 
	     size, sum, region, region_sum[region]);
  
  }

}

// void TetMeshBuilder::
// output_faces(const char* const filename,
// 	     const set<Face*>& faces) const {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_faces(const char* const)"); 

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   set<Vert*> vert_set;
//   vector<Vert*> vert_vec;
//   set<Face*>::iterator itf = faces.begin(), itf_end = faces.end();

//   for( ; itf != itf_end; ++itf) {
//     Face* face = *itf;
//     vert_set.insert(face->pVVert(0));
//     vert_set.insert(face->pVVert(1));
//     vert_set.insert(face->pVVert(2));
//   }

//   std::copy(vert_set.begin(), vert_set.end(),
// 	    std::back_inserter(vert_vec));

//   vector<Vert*>::iterator itv_beg = vert_vec.begin(), 
//                           itv_end = vert_vec.end(), itv;
  
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(itv_end - itv_beg));

//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     Vert* vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vertex->dX(), vertex->dY(), vertex->dZ());
//   }
    
//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", static_cast<int>(faces.size()));

//   itf = faces.begin(), itf_end = faces.end();
//   for( ; itf != itf_end; ++itf) {
//     Face* face = *itf;
//     int idx1 = std::find(itv_beg, itv_end, face->pVVert(0)) - itv_beg + 1;
//     int idx2 = std::find(itv_beg, itv_end, face->pVVert(1)) - itv_beg + 1;
//     int idx3 = std::find(itv_beg, itv_end, face->pVVert(2)) - itv_beg + 1;
//     fprintf(out_file, "%d %d %d 0\n", idx1, idx2, idx3);
//   }

//   fprintf(out_file, "End\n");

// }


