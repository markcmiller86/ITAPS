#include <stdio.h>
#include "GR_misc.h"
#include "GR_events.h"
#include "GR_VolMesh.h"
#include "GR_Geometry.h"

//-----------------------------------------------------------------------------
void vWriteFile_PWM
(
  VolMesh& OutMesh,
  const char strBaseFileName[],
  const char strExtraSuffix[]
)
//-----------------------------------------------------------------------------
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  FILE *pFOutFile = NULL;
  char strFileName[1024];
  OutMesh.vPurge();
  if (strcasecmp(strBaseFileName + strlen(strBaseFileName) - 4, ".pwm")) {
    // File name doesn't end in .pwm
    sprintf(strFileName, "%s.pwm.%s", strBaseFileName, strExtraSuffix);
  }
  else {
    // File name ends in .pwm
    sprintf(strFileName, "%s.%s", strBaseFileName, strExtraSuffix);
  }

  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open output file for writing",
                "3d Pointwise mesh output");

  //-------------------------------------------------------
  // Write the PWM header details
  //-------------------------------------------------------

  // File magic
  fprintf(pFOutFile, "1994\n");

  // File authorship info
  fprintf(pFOutFile, "PWM written by GRUMMP\n");

  // Skip a couple of integers (size of int and real, I believe)
  fprintf(pFOutFile, "4\n8\n");

  // Now read the mesh size data.
  int nVerts = OutMesh.iNumVerts();
  int nTets = OutMesh.iNumTetCells();
  fprintf(pFOutFile, "%d\n 0 0 0 %d 0 0 0 0\n", nVerts, nTets);


  //-------------------------------------
  // write 3d vertex data
  //-------------------------------------
  for (int i=0; i< nVerts; ++i)
  {
    Vert *pV = OutMesh.pVVert(i);
    fprintf(pFOutFile, "%20.16f %20.16f %20.16f\n", 
	    pV->dX(), pV->dY(), pV->dZ());
  }

  for (int i = 0; i < nTets; i++) {
    Cell *pC = OutMesh.pCCell(i);
    fprintf(pFOutFile, "%d %d %d %d\n", 
	    OutMesh.iVertIndex(pC->pVVert(0)), 
	    OutMesh.iVertIndex(pC->pVVert(1)), 
	    OutMesh.iVertIndex(pC->pVVert(2)), 
	    OutMesh.iVertIndex(pC->pVVert(3)));
    assert(iOrient3D(pC->pVVert(0), pC->pVVert(1), 
		     pC->pVVert(2), pC->pVVert(3)) == 1);
  }

  fclose(pFOutFile);
  SUMAA_LOG_EVENT_END(OUTPUT);
}
