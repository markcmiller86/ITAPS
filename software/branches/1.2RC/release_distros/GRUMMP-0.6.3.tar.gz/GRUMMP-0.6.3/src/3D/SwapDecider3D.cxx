#include <cmath>

#include "GR_EdgeCanon.h"
#include "GR_FaceSwapInfo.h"
#include "GR_Geometry.h"
#include "GR_SwapDecider.h"
#include "GR_Util.h"

using std::min;

using namespace GRUMMP;

#ifdef SIM_ANNEAL_TEST
double simAnnealTemp = 1;
static bool simAnnealComp(const double a, const double b)
{
  assert(0 <= a && a <= 1);
  assert(0 <= b && b <= 1);
  double diff = 1/b - 1/a + 1.e-10;
  diff /= (simAnnealTemp);
  diff = (diff + 1) / 2;
  double rand = drand48();
  return (rand < diff);
}
#endif

/// Unless overridden in a derived class, this function decides whether
/// the current configuration is preferable to the alternate
/// configuration by seeking to maximize the minimum value of the
/// quality function for the current or speculative tets.
bool SwapDecider3D::doFaceSwap(const FaceSwapInfo3D& FC) const
{
  if (!m_pQM) {
    // How could we have gotten here?  The subclasses that don't set a
    // specific shape quality measure are supposed to override this
    // function.  This is definitely a library bug, if it occurs.
    assert(0);
    return false;
  }
  // If we've gotten this far, we know for sure that it's topologically
  // valid to do the reconfiguration.  But is it advisable in terms of
  // mesh quality?

  // First, make sure that the verts that are definitely supposed to be
  // here actually are.  
  Vert *pVA = FC.getVertA();
  Vert *pVB = FC.getVertB();
  Vert *pVC = FC.getVertC();
  Vert *pVD = FC.getVertD();
  Vert *pVE = FC.getVertE();
  VALIDATE_INPUT(pVA->qValid() && pVB->qValid() &&
		 pVC->qValid() && pVD->qValid() &&
		 pVE->qValid());
  // Can't check whether they belong to a mesh; we don't have one, and
  // they might be verts that aren't in a mesh yet anyway.

  // Verts are ordered like this:
  //
  // 2->3, 3->2 swaps: verts A, B, C are always the ones on the internal
  // triangle in the two tet state.
  //
  // 2->2, 4->4 swaps: verts A, B, C are always the ones on the (a, for
  // 4->4) current internal triangle.  A and B are two of the four
  // coplanar verts (D and E are the others).
  //
  // Vert D is to the left of tri ABC (orientation(ABCD) is inverted).
  // Vert E is to the right (orientation(ABCE) is correct).
  //
  // Vert F (only for 4->4 swaps) is the analog to vert C, but on the
  // other side of plane ABDE.

  // If these values never get changed, there'll never be any face swaps.
  double qualBefore = 1, qualAfter = 0; 
  switch (FC.getFaceCat()) {
  case eT23:
    {
      // Old configuration
      double qualACBD = m_pQM->eval(pVA, pVC, pVB, pVD);
      double qualABCE = m_pQM->eval(pVA, pVB, pVC, pVE);
      qualBefore = min(qualACBD, qualABCE);

      // New configuration
      double qualDEAB = m_pQM->eval(pVD, pVE, pVA, pVB);
      double qualDEBC = m_pQM->eval(pVD, pVE, pVB, pVC);
      double qualDECA = m_pQM->eval(pVD, pVE, pVC, pVA);
      qualAfter = min(qualDEAB, min(qualDEBC, qualDECA));
      break;
    }
  case eT32:
    {
      // Old configuration
      double qualDEAB = m_pQM->eval(pVD, pVE, pVA, pVB);
      double qualDEBC = m_pQM->eval(pVD, pVE, pVB, pVC);
      double qualDECA = m_pQM->eval(pVD, pVE, pVC, pVA);
      qualBefore = min(qualDEAB, min(qualDEBC, qualDECA));

      // New configuration
      double qualACBD = m_pQM->eval(pVA, pVC, pVB, pVD);
      double qualABCE = m_pQM->eval(pVA, pVB, pVC, pVE);
      qualAfter = min(qualACBD, qualABCE);
      break;
    }
  case eT22:
    {
      // Can't swap T22 if the bdry is precious.
      if (!m_allowBdryChanges) return false;
      // Old configuration
      double qualACBD = m_pQM->eval(pVA, pVC, pVB, pVD);
      double qualABCE = m_pQM->eval(pVA, pVB, pVC, pVE);
      qualBefore = min(qualACBD, qualABCE);

      // New configuration
      double qualDEBC = m_pQM->eval(pVD, pVE, pVB, pVC);
      double qualDECA = m_pQM->eval(pVD, pVE, pVC, pVA);
      qualAfter = min(qualDEBC, qualDECA);
      break;
    }
  case eT44:
    {
      Vert *pVF = FC.getVertF();
      VALIDATE_INPUT(pVF->qValid());
      // Old configuration
      double qualABDC = m_pQM->eval(pVA, pVB, pVD, pVC);
      double qualABCE = m_pQM->eval(pVA, pVB, pVC, pVE);
      double qualABEF = m_pQM->eval(pVA, pVB, pVE, pVF);
      double qualABFD = m_pQM->eval(pVA, pVB, pVF, pVD);
      qualBefore = min( min(qualABDC, qualABCE), min(qualABEF, qualABFD));

      // New configuration
      double qualDEBC = m_pQM->eval(pVD, pVE, pVB, pVC);
      double qualDECA = m_pQM->eval(pVD, pVE, pVC, pVA);
      double qualDEAF = m_pQM->eval(pVD, pVE, pVA, pVF);
      double qualDEFB = m_pQM->eval(pVD, pVE, pVF, pVB);
      qualAfter = min( min(qualDEBC, qualDECA), min(qualDEAF, qualDEFB));
      break;
    }
  default:
    return false;
  }
  // In cases of (near) tie, don't do anything; this will help termination. 
#ifdef SIM_ANNEAL_TEST
  return simAnnealComp(qualAfter, qualBefore);
#else
  return (fuzzyGreater(qualAfter, qualBefore));
#endif
}

bool DelaunaySwapDecider3D::doFaceSwap(const FaceSwapInfo3D& FC) const
{
  int iInSphereRes = iInsphere(FC.getVertA(), FC.getVertB(), FC.getVertC(),
			       FC.getVertD(), FC.getVertE());

  switch (FC.getFaceCat()) {
  case eT32:
    // Current tets are ABDE, BCDE, CADE.  Swap if pVVertE is on (0) or
    // outside (-1) the circumsphere of ABCD.  This is an arbitrary
    // tie-break; configurations which are co-spherical go to the two
    // tet configuration.
    return (iInSphereRes != 1);
  case eT23:
  case eT22:
  case eT44: // This one is the same as eT22 for all situations.
    // Current tets are ABCD, CBAE.  Swap if pVVertE is inside (1) the
    // circumsphere of ABCD.  Again, configurations which are
    // co-spherical go to the two-tet configuration.  For T22 and T44,
    // ties remain unchanged.
    return (iInSphereRes == 1);
  default:
    return(false);
  }
}

//@@ Determines whether swapping will improve the maximum face angle.
// Returns true to swap, false to remain the same.
bool MinMaxDihedSwapDecider3D::doFaceSwap(const FaceSwapInfo3D& FC) const
{
#ifdef SIM_ANNEAL_TEST
  return SwapDecider3D::doFaceSwap(FC);
#endif
  Vert* pVVertA = FC.getVertA();
  Vert* pVVertB = FC.getVertB();
  Vert* pVVertC = FC.getVertC();
  Vert* pVVertD = FC.getVertD();
  Vert* pVVertE = FC.getVertE();

  FaceSwapInfo3D::faceCat eFC = FC.getFaceCat();

  // This algorithm finds face angles between adjacent faces by dotting
  // their unit normals.  The largest magnitude loses.
  //
  // To prevent pairs from flopping back and forth, a swap is only
  // authorized if the inequality is bigger than eps.

  double dEps = 1.e-10;
  switch (eFC) {
  case eT23:
  case eT32:
    {
      //@@@ The case where the five pVVerts form a genuinely convex set
      double adNormABD[3], adNormABE[3], adNormADE[3];
      double adNormBCD[3], adNormBCE[3], adNormBDE[3];
      double adNormCAD[3], adNormCAE[3], adNormCDE[3];
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertD->adCoords(), adNormABD);
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertE->adCoords(), adNormABE);
      vUnitNormal(pVVertA->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormADE);

      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertD->adCoords(), adNormBCD);
      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertE->adCoords(), adNormBCE);
      vUnitNormal(pVVertB->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormBDE);

      vUnitNormal(pVVertC->adCoords(), pVVertA->adCoords(),
		  pVVertD->adCoords(), adNormCAD);
      vUnitNormal(pVVertC->adCoords(), pVVertA->adCoords(),
		  pVVertE->adCoords(), adNormCAE);
      vUnitNormal(pVVertC->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormCDE);

      double dLastDot, dWorst2 = -1., dWorst3 = -1.;

      // Care must be taken to be certain that I'm taking the dot
      // product of two vectors that both point into the enclosed angle
      // or both point out, or correct the sign.

      dLastDot = dDOT3D(adNormABD, adNormBCD);   /* Both in */
      dWorst2 = max(dWorst2, dLastDot);
      dLastDot = dDOT3D(adNormBCD, adNormCAD);   /* Both in */
      dWorst2 = max(dWorst2, dLastDot);
      dLastDot = dDOT3D(adNormCAD, adNormABD);   /* Both in */
      dWorst2 = max(dWorst2, dLastDot);

      dLastDot = dDOT3D(adNormABE, adNormBCE);   /* Both out */
      dWorst2 = max(dWorst2, dLastDot);
      dLastDot = dDOT3D(adNormBCE, adNormCAE);   /* Both out */
      dWorst2 = max(dWorst2, dLastDot);
      dLastDot = dDOT3D(adNormCAE, adNormABE);   /* Both out */
      dWorst2 = max(dWorst2, dLastDot);

      dLastDot = - dDOT3D(adNormABD, adNormABE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);
      dLastDot = - dDOT3D(adNormBCD, adNormBCE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);
      dLastDot = - dDOT3D(adNormCAD, adNormCAE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);

      dLastDot = - dDOT3D(adNormADE, adNormBDE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);
      dLastDot = - dDOT3D(adNormBDE, adNormCDE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);
      dLastDot = - dDOT3D(adNormCDE, adNormADE); /* One in, one out */
      dWorst3 = max(dWorst3, dLastDot);

      if      (dWorst3 > dWorst2 + dEps) return(eFC == FaceSwapInfo3D::eT32);
      else if (dWorst2 > dWorst3 + dEps) return(eFC == FaceSwapInfo3D::eT23);
      else                               return(false);
    }
  case eT22:
    {
      double adNormACE[3], adNormECB[3], adNormBCD[3], adNormDCA[3];
      double adNormABC[3], adNormCDE[3], adNormABE[3];
      vUnitNormal(pVVertA->adCoords(), pVVertC->adCoords(),
		  pVVertE->adCoords(), adNormACE);
      vUnitNormal(pVVertE->adCoords(), pVVertC->adCoords(),
		  pVVertB->adCoords(), adNormECB);
      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertD->adCoords(), adNormBCD);
      vUnitNormal(pVVertD->adCoords(), pVVertC->adCoords(),
		  pVVertA->adCoords(), adNormDCA);

      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertC->adCoords(), adNormABC);
      vUnitNormal(pVVertC->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormCDE);
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertE->adCoords(), adNormABE);

      double dLastDot, dWorstNow = -1., dWorstSwapped = -1.;

      dLastDot = dDOT3D(adNormACE, adNormECB);
      dWorstNow = max(dWorstNow, dLastDot);
      dLastDot = dDOT3D(adNormBCD, adNormDCA);
      dWorstNow = max(dWorstNow, dLastDot);
      dLastDot = fabs(dDOT3D(adNormABC, adNormABE));
      dWorstNow = max(dWorstNow, dLastDot);

      dLastDot = dDOT3D(adNormACE, adNormDCA);
      dWorstSwapped = max(dWorstSwapped, dLastDot);
      dLastDot = dDOT3D(adNormBCD, adNormECB);
      dWorstSwapped = max(dWorstSwapped, dLastDot);
      dLastDot = fabs(dDOT3D(adNormCDE, adNormABE));
      dWorstSwapped = max(dWorstSwapped, dLastDot);

      if   (dWorstNow > dWorstSwapped + dEps) return(true);
      else                                    return(false);
    }
  case eT44:
    return(false);
  default:
    assert2(0, "Bad face type in finding max dihedral angle");
    return(false);
  }
}

//@@ Determines whether swapping will improve the maximum face angle.
// Returns true to swap, false to remain the same.
bool MaxMinSineSwapDecider3D::doFaceSwap(const FaceSwapInfo3D& FC) const
{
#ifdef SIM_ANNEAL_TEST
  return SwapDecider3D::doFaceSwap(FC);
#endif
  Vert* pVVertA = FC.getVertA();
  Vert* pVVertB = FC.getVertB();
  Vert* pVVertC = FC.getVertC();
  Vert* pVVertD = FC.getVertD();
  Vert* pVVertE = FC.getVertE();

  FaceSwapInfo3D::faceCat eFC = FC.getFaceCat();

  // This algorithm finds sine of face angles between adjacent faces by
  // crossing their unit normals.  The idea is to pick the configuration
  // which maximizes this value.
  //
  // To prevent pairs from flopping back and forth, a swap is only
  // authorized if the inequality is bigger than eps.

  double dEps = 1.e-10;
  switch (eFC) {
  case eT23:
  case eT32:
    {
      double adNormABD[3], adNormABE[3], adNormADE[3], adNormABC[3];
      double adNormBCD[3], adNormBCE[3], adNormBDE[3];
      double adNormCAD[3], adNormCAE[3], adNormCDE[3];
      //@@@ The case where the five pVVerts form a genuinely convex set
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertD->adCoords(), adNormABD);
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertE->adCoords(), adNormABE);
      vUnitNormal(pVVertA->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormADE);

      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertC->adCoords(), adNormABC); // Points to E

      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertD->adCoords(), adNormBCD);
      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertE->adCoords(), adNormBCE);
      vUnitNormal(pVVertB->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormBDE);

      vUnitNormal(pVVertC->adCoords(), pVVertA->adCoords(),
		  pVVertD->adCoords(), adNormCAD);
      vUnitNormal(pVVertC->adCoords(), pVVertA->adCoords(),
		  pVVertE->adCoords(), adNormCAE);
      vUnitNormal(pVVertC->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormCDE);

      double dWorst2 = 1., dWorst3 = 1.;

      // Because I'm taking the MAGNITUDE of the cross product, the
      // actual sign of the result doesn't matter (vector can be
      // reversed).  This means that normal orientation doesn't matter.

      // Sines of dihedral angles of tet ABCD
      double adTemp[3], dMag;

      vCROSS3D(adNormABD, adNormBCD, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormBCD, adNormCAD, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormCAD, adNormABD, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormABD, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormBCD, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormCAD, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      // Sines of dihedral angles of tet ABCE
      vCROSS3D(adNormABE, adNormBCE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormBCE, adNormCAE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormCAE, adNormABE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormABE, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormBCE, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      vCROSS3D(adNormCAE, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst2 = min(dWorst2, dMag);

      // Now have the smallest sine of dihedral angle in tet ABCD and ABCE

      //Sines of dihedral angles of tet ABDE
      vCROSS3D(adNormABD, adNormABE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormABD, adNormADE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormABD, adNormBDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormABE, adNormADE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormABE, adNormBDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormADE, adNormBDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      //Sines of dihedral angles of tet BCDE
      vCROSS3D(adNormBCD, adNormBCE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormBCD, adNormBDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormBCD, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormBCE, adNormBDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormBCE, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormBDE, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      //Sines of dihedral angles of tet CADE
      vCROSS3D(adNormCAD, adNormCAE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormCAD, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormCAD, adNormADE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormCAE, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormCAE, adNormADE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);

      vCROSS3D(adNormCDE, adNormADE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorst3 = min(dWorst3, dMag);
      // Now have the smallest sine of dihedral in tets ABDE, BCDE, CADE

      if      (dWorst3 > dWorst2 + dEps) return(eFC == FaceSwapInfo3D::eT23);
      else if (dWorst2 > dWorst3 + dEps) return(eFC == FaceSwapInfo3D::eT32);
      else                               return(false);
    }
  case eT22:
    {
      double adNormACE[3], adNormECB[3], adNormBCD[3], adNormDCA[3];
      double adNormABC[3], adNormCDE[3], adNormABE[3];
      vUnitNormal(pVVertA->adCoords(), pVVertC->adCoords(),
		  pVVertE->adCoords(), adNormACE);
      vUnitNormal(pVVertE->adCoords(), pVVertC->adCoords(),
		  pVVertB->adCoords(), adNormECB);
      vUnitNormal(pVVertB->adCoords(), pVVertC->adCoords(),
		  pVVertD->adCoords(), adNormBCD);
      vUnitNormal(pVVertD->adCoords(), pVVertC->adCoords(),
		  pVVertA->adCoords(), adNormDCA);

      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertC->adCoords(), adNormABC);
      vUnitNormal(pVVertC->adCoords(), pVVertD->adCoords(),
		  pVVertE->adCoords(), adNormCDE);
      vUnitNormal(pVVertA->adCoords(), pVVertB->adCoords(),
		  pVVertE->adCoords(), adNormABE);

      double dWorstNow = 1., dWorstSwap = 1.;
      double adTemp[3], dMag;

      // Sines of dihedral angles of tet ABCD, except those that are the
      // same both ways
      vCROSS3D(adNormBCD, adNormDCA, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);

      vCROSS3D(adNormBCD, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);

      vCROSS3D(adNormDCA, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);


      // Sines of dihedral angles of tet ABCE, except those that are the
      // same both ways
      vCROSS3D(adNormECB, adNormACE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);

      vCROSS3D(adNormECB, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);

      vCROSS3D(adNormACE, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);


      // Only check the center face once; the sine is the same on both
      // sides
      vCROSS3D(adNormABE, adNormABC, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstNow = min(dWorstNow, dMag);

      // Now have the smallest sine of dihedral angle in tet ABCD and ABCE

      // Sines of dihedral angles of tet DECA, except those that are the
      // same both ways
      vCROSS3D(adNormDCA, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);

      vCROSS3D(adNormACE, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);

      vCROSS3D(adNormDCA, adNormACE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);


      // Sines of dihedral angles of tet DECB, except those that are the
      // same both ways
      vCROSS3D(adNormBCD, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);

      vCROSS3D(adNormECB, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);

      vCROSS3D(adNormBCD, adNormECB, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);


      // Only check the center face once; the sine is the same on both
      // sides
      vCROSS3D(adNormABE, adNormCDE, adTemp);
      dMag = dMAG3D(adTemp);
      dWorstSwap = min(dWorstSwap, dMag);

      // Now have the smallest sine of dihedral angle in tet DECA and DECB

      if   (dWorstNow + dEps < dWorstSwap) return(true);
      else                                 return(false);
    }
  case eT44:
    return(false);
  default:
    assert2(0, "Bad face type in finding max dihedral angle");
    return(false);
  }
}

double SwapDecider3D::calcOrigQuality(const EdgeSwapInfo& ES) const
{
  double origQual = DBL_MAX;
  
  // Compute the quality of the current configuration.  This is the
  // smallest quality for any of the existing cells.
  for (int i = ES.getNumOrigCells() - 1; i >= 0; --i) {
    Cell *pC = ES.getOrigCell(i);
    // Evaluate quality, depending on the swap criterion in use.
    assert(1 == iOrient3D(pC->pVVert(0), pC->pVVert(1),
			  pC->pVVert(2), pC->pVVert(3)));
    double qual = m_pQM->eval(pC->pVVert(0), pC->pVVert(1),
			      pC->pVVert(2), pC->pVVert(3));
    origQual = std::min(qual, origQual);
  }
  return origQual;
}

bool SwapDecider3D::doEdgeSwap(EdgeSwapInfo& ES,
			       Vert *pVWant0, Vert *pVWant1) const
{
#ifdef SIM_ANNEAL_TEST
  return false;
#endif
  if (!m_pQM || !ES.isSwappableEdge()) {
    // If there's no cell-by-cell quality measure, call the whole thing off.
    return false;
  }

  // If there's a particular edge that's desired, to force it into the
  // mesh, then all configurations with this edge get a bonus that
  // will make it so they're better than the original config, while
  // configs without the new edge get a penalty that ensures they'll
  // be worse.  Since we're looking for the best config that has the
  // given edge, the original quality is irrelevant and that
  // calculation gets skipped.
  bool qEdgePresent = false,
    qBonusPossible = (pVWant0->qValid() && pVWant1->qValid());
  double origQual = qBonusPossible ? 0 : calcOrigQuality(ES);
  int numOrigVerts = ES.getNumOrigVerts();
  if (numOrigVerts < 3) return false;
  int numOrigCells = ES.getNumOrigCells();
  const double invalidPenalty = -10000;
  const double edgeBonus = 1000;
  bool qReturnVal = false;
  
  Vert *northVert = ES.getNorthVert();
  Vert *southVert = ES.getSouthVert();
    
  // Compute quality for each possible tet pair (one pair per possible
  // triangle). 
  double a3dNewQual[10][10][10];
  int iSign = iOrient3D(ES.getVert(0), ES.getVert(1), southVert, northVert);
  int iV0, iV1, iV2;
#ifndef NDEBUG
  for (iV0 = 0; iV0 < 10; iV0++)
    for (iV1 = 0; iV1 < 10; iV1++)
      for (iV2 = 0; iV2 < 10; iV2++)
	a3dNewQual[iV0][iV1][iV2] = 0;
  for (int iDum = 0; iDum < numOrigCells; iDum++) 
    assert(iSign == iOrient3D(ES.getVert(iDum),
			      ES.getVert((iDum+1)%numOrigVerts),
			      southVert, northVert));
#endif
  for (iV0 = 0; iV0 < numOrigVerts; iV0++) {
    Vert *pV0 = ES.getVert(iV0);
    for (iV1 = iV0+1; iV1 < numOrigVerts; iV1++) {
      Vert *pV1 = ES.getVert(iV1);
      for (iV2 = iV1+1; iV2 < numOrigVerts; iV2++) {
	Vert *pV2 = ES.getVert(iV2);
	if (iOrient3D(pV0, pV1, pV2, northVert) == iSign) 
	  // Evaluate quality
	  a3dNewQual[iV0][iV1][iV2] = m_pQM->eval(pV0, pV1, pV2, northVert);
	else
	  a3dNewQual[iV0][iV1][iV2] = invalidPenalty; 

	// Don't bother evaluating for the other tet if this one is
	// worse that the worst in the original config, because this tet
	// pair can never be in a final config anyway.
	if (a3dNewQual[iV0][iV1][iV2] >= origQual) {
	  double dDummyQual = invalidPenalty;
	  if (iOrient3D(pV0, pV2, pV1, southVert) == iSign)
	    dDummyQual = m_pQM->eval(pV0, pV2, pV1, southVert);
	  a3dNewQual[iV0][iV1][iV2] = std::min(a3dNewQual[iV0][iV1][iV2],
					       dDummyQual);
	}

	// Copy things around symmetrically
	a3dNewQual[iV2][iV1][iV0] = a3dNewQual[iV2][iV0][iV1] =
	  a3dNewQual[iV1][iV2][iV0] = a3dNewQual[iV1][iV0][iV2] =
	  a3dNewQual[iV0][iV2][iV1] = a3dNewQual[iV0][iV1][iV2];
	
      } // Loop over third vert
    } // Loop over second vert
  } // Loop over first vert
  
    // Find the new configuration with the highest quality.
  double dMaxQual = origQual;
  int iCanon, iPerm;
  const ConfSet& CS = EdgeConfigs::getInstance().getConfSet(numOrigVerts);
  for (iCanon = 0; iCanon < CS.getNumCanon(); iCanon++) {
    const EdgeConfig& Conf = CS.getConfig(iCanon);
    int iNPerm = Conf.getNumPerm();
    for (iPerm = 0; iPerm < iNPerm; iPerm++) {
      double dConfQual = 1000;
      // Once this config is known to be worse than the best one we know
      // about, we can give up on it.
      for (int iTri = 0;
	   iTri < numOrigVerts-2 && (dConfQual >= dMaxQual || qBonusPossible);
	   iTri++) {
	iV0 = (Conf.getFaceVert(iTri, 0) + iPerm) % numOrigVerts;
	iV1 = (Conf.getFaceVert(iTri, 1) + iPerm) % numOrigVerts;
	iV2 = (Conf.getFaceVert(iTri, 2) + iPerm) % numOrigVerts;
	// Give a bonus if a particular edge is desired and that edge
	// is included in the configuration.
	if (qBonusPossible && !qEdgePresent) {
	  Vert * pV0 = ES.getVert(iV0);
	  Vert * pV1 = ES.getVert(iV1);
	  Vert * pV2 = ES.getVert(iV2);
	  if ((pVWant0 == pV0 || pVWant0 == pV1 || pVWant0 == pV2) &&
	      (pVWant1 == pV0 || pVWant1 == pV1 || pVWant1 == pV2))
	    qEdgePresent = true;
	}
	dConfQual = min(dConfQual, a3dNewQual[iV0][iV1][iV2]);
      }
      // Only give a bonus to valid configurations
      if (qBonusPossible)
	dConfQual += qEdgePresent ? edgeBonus : -edgeBonus;
      if (dConfQual > dMaxQual) {
	ES.setNewConfig(iCanon, iPerm);
	qReturnVal = true;
      }   
    } // Loop over permutations
  } // Loop over canonical configurations
  return qReturnVal;
}

bool SwapDecider3D::doBdryEdgeSwap(EdgeSwapInfo& ES) const
{
  // If strict patch checking is on, the following call checks that
  // the two bfaces are on the same patch.  Otherwise, it uses a
  // weaker check:  are the bdry conditions the same and the faces
  // nearly coplanar. 
  BFace *bdryFace0 = ES.getBFace(0);
  BFace *bdryFace1 = ES.getBFace(1);
  if (!areBdryFacesOKToSwap(bdryFace0, bdryFace1)) {
    return false;
  }

  // Do the two boundary triangles form a convex quad?  If so, the
  // orientation of the tets formed by these triangles and any
  // non-coplanar point (i.e., any other member of m_outerVerts) will be the
  // same.  This exit is redundant (no swapping would occur for this
  // case anyway), but saves a lot of quality computations.
  unsigned numOrigVerts = ES.getNumOrigVerts();

  // Grab the first and last verts on the "equator".
  Vert *firstVert = ES.getVert(0);
  Vert *lastVert  = ES.getVert(numOrigVerts-1);
  Vert *northVert = ES.getNorthVert();
  Vert *southVert = ES.getSouthVert();
  Vert *interVert = ES.getVert(1);
  if (iOrient3D(firstVert, lastVert, northVert, interVert)
      !=
      iOrient3D(firstVert, southVert, lastVert, interVert)) {
    return false;
  }

  return doEdgeSwap(ES);
}

bool SwapDecider3D::areBdryFacesOKToSwap(const BFace * const pBF0,
					 const BFace * const pBF1) const
{
  //     if (qStrictPatchChecking) {
  //       return (pBF0->pPatchPointer() == pBF1->pPatchPointer());
  //     }
  //     else {
  // Check that the BC's are the same and that the normals are more or
  // less aligned (within the tolerances of dMaxAngleForSurfSwap).
  if (pBF0->iBdryCond() == pBF1->iBdryCond()) {
    double adNorm0[3], adNorm1[3];
    pBF0->vUnitNormal(adNorm0);
    pBF1->vUnitNormal(adNorm1);
    double dDot = dDOT3D(adNorm0, adNorm1);
    return (dDot >= cos(m_maxBdryAngle * M_PI/180));
  }
  else {
    return false;
  }
  //     }
}

double SwapDecider3D::evalTetQual(const Cell* const pC) const
{
  VALIDATE_INPUT(pC->qValid() && !pC->qDeleted());
  VALIDATE_INPUT(pC->eType() == CellSkel::eTet);
  if (!m_pQM) {
    return 0;
  }
  return m_pQM->eval(pC->pVVert(0), pC->pVVert(1),
		     pC->pVVert(2), pC->pVVert(3));
}
