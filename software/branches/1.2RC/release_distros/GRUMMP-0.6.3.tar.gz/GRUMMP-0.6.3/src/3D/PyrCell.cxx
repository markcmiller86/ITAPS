#include <math.h>
#include "GR_misc.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Vertex.h"
#include "GR_Vec.h"

const Vert* PyrCell::pVVert(const int i) const
{
  assert(iFullCheck());
  assert(i >= 0 && i <= 4); // Vertex index out of range
  const Face* const pFBase = ppFFaces[4];
  switch (i) {
  case 0:
  case 2:
    return pFBase->pVVert(i);
  case 1:
  case 3:
    if (pFBase->pCCellRight() == static_cast<const Cell*>(this))
      return pFBase->pVVert(i);
    else
      return pFBase->pVVert(4-i);
  case 4:
    {
      const Face *pF0 = pFFace(0);
      for (int ii = 0; ii < 3; ii++) {
	const Vert *pV = pF0->pVVert(ii);
	if (!pFBase->qHasVert(pV))
	  return pV;
      }
    }
    assert(0); // Should never get here.
    break;
  }
  return pVInvalidVert;
}

double PyrCell::dSize() const
{
  assert2(0, "Volume calculation not supported for pyramids");
  assert(iFullCheck());
//   const Vert *pV0, *pV1, *pV2;
//   const Face* const pFBase = ppFFaces[0];
//   pV0 = pFBase->pVVert(0);
//   if (pFBase->pCCellRight() == (const Cell*)this) {
//     pV1 = pFBase->pVVert(1);
//     pV2 = pFBase->pVVert(2);
//   }
//   else {
//     pV1 = pFBase->pVVert(2);
//     pV2 = pFBase->pVVert(1);
//   }

  return (0);
}

void PyrCell::vAllVertHandles(GRUMMP_Entity* aHandles[]) const
{
  assert(iFullCheck());
  for (int i = 0; i < 5; i++) {
    aHandles[i] = const_cast<Vert*>(pVVert(i));
  }
}

bool PyrCell::qIsClosed() const
{
#ifndef NDEBUG
  #warning Pyramid closure check is weak!
#endif
  for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
    const Face *pF = pFFace(iF);
    for (int iV = pF->iNumVerts() - 1; iV >= 0; iV--) {
      if (!qHasVert(pF->pVVert(iV)))
	return false;
    }
  }
  return true;
}
  
