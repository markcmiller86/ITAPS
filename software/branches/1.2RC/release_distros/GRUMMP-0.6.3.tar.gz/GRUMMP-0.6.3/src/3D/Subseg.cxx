#include "GR_Subseg.h"
#include "GR_Functors.h"
#include "GR_misc.h"
#include "GR_Vector.h"
#include "GR_Vertex.h"

#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "RefEdge.hpp"
#include "RefVertex.hpp"

#include <algorithm>

SubsegBridge::
~SubsegBridge() { m_parent = static_cast<Subseg*>(NULL); }

Subseg::
~Subseg() {

  if(m_vd1) delete m_vd1;
  if(m_vd2) delete m_vd2;
    
  std::for_each(m_children.begin(), m_children.end(),
		GRUMMP::DeleteObject());

}

double Subseg::
get_length() const { 

  double vector[] = { m_vd2->vertex->dX() - m_vd1->vertex->dX(),
		      m_vd2->vertex->dY() - m_vd1->vertex->dY(),
		      m_vd2->vertex->dZ() - m_vd1->vertex->dZ() };
  return dMAG3D(vector);

}

double Subseg::
param_at_distance_from_vert(const double distance,
			    const Vert* const vert) const {

  assert(distance >= 0.);
  assert(distance <= get_length());
  assert(vert == m_vd1->vertex ||
	 vert == m_vd2->vertex);
  assert(m_vd1->param < m_vd2->param);
  assert(m_parent_edge);
  
  bool from_lo = vert == m_vd1->vertex; 
  CubitVector from_vert_coord(vert->dX(), vert->dY(), vert->dZ());

  double param_lo = m_vd1->param, param_up = m_vd2->param;
  CubitVector coord_lo, coord_up, current_coord;
  m_parent_edge->position_from_u(param_lo, coord_lo);
  m_parent_edge->position_from_u(param_up, coord_up);
  double dist_lo = (coord_lo - from_vert_coord).length();
  double dist_up = (coord_up - from_vert_coord).length();

  assert( (dist_lo <= distance && dist_up >= distance) ||
	  (dist_lo >= distance && dist_up <= distance) );

  double current_param = -LARGE_DBL, current_dist = LARGE_DBL;
  
  // FIX ME!
  //Having a fixed tolerance like this is likely to cause problems.
  while( fabs(current_dist - distance) > 1.e-12 ) {

    current_param = 0.5 * (param_lo + param_up);
    m_parent_edge->position_from_u(current_param, current_coord);
    current_dist = (current_coord - from_vert_coord).length();

    if(from_lo) {
      if(current_dist > distance) param_up = current_param;
      else                        param_lo = current_param;
    }
    else {
      if(current_dist > distance) param_lo = current_param;
      else                        param_up = current_param;
    }

//     printf("current_param = %lf, error = %.5e\n", 
// 	   current_param, fabs(current_dist - distance));

  }
  
//   printf("current param = %lf - m_vd1->param = %lf - m_vd2->param = %lf - distance = %e - current_dist = %e\n",
// 	 current_param, m_vd1->param, m_vd2->param, distance, current_dist);

  return current_param;

}

RefVertex* Subseg::
get_beg_ref_vert() const {

  return dynamic_cast<RefVertex*>(get_beg_vert()->get_parent_topology());

}

RefVertex* Subseg::
get_end_ref_vert() const { 

  return dynamic_cast<RefVertex*>(get_end_vert()->get_parent_topology());

}

void Subseg::compute_refinement_split_data(double split_coords[3], double& split_param) {

  assert(m_vd1 && m_vd2);

  Vert* vert1 = m_vd1->vertex, *vert2 = m_vd2->vertex;
  assert( vert1 && !vert1->qDeleted() && vert1->iSpaceDimen() == 3 );
  assert( vert2 && !vert2->qDeleted() && vert2->iSpaceDimen() == 3 );

  assert( vert1->iVertType() == Vert::eBdryApex ||
	  vert1->iVertType() == Vert::eBdryCurve );
  assert( vert2->iVertType() == Vert::eBdryApex ||
	  vert2->iVertType() == Vert::eBdryCurve );

  //This is the regular split case. The split point will
  //be at the mid parameter (or at the mid point if there is no parent curve)
  if( vert1->iVertType() == vert2->iVertType() ) {

    //No parent curve defined, split at mid point.
    if( !m_parent_edge ) {
      
      //Compute the split coordinates
      split_coords[0] = 0.5 * (vert1->dX() + vert2->dX());
      split_coords[1] = 0.5 * (vert1->dY() + vert2->dY());
      split_coords[2] = 0.5 * (vert1->dZ() + vert2->dZ());

      //Set the parameter manually to some dummy value.
      split_param = -LARGE_DBL;

    }

    //Split at middle parameter between 
    else {
      
      //Compute the split parameter.
      assert( m_vd1->param >= m_parent_edge->start_param() &&
	      m_vd1->param <= m_parent_edge->end_param() );
      assert( m_vd2->param >= m_parent_edge->start_param() &&
	      m_vd2->param <= m_parent_edge->end_param() );

      split_param = 0.5 * ( m_vd1->param + m_vd2->param );

      assert( split_param >  m_vd1->param && split_param < m_vd2->param );
      assert( split_param >= m_parent_edge->start_param() &&
	      split_param <= m_parent_edge->end_param() );

      //Compute the split coordinates
      CubitVector tmp_coord;
      m_parent_edge->position_from_u(split_param, tmp_coord);
      tmp_coord.get_xyz( split_coords );

    }

  }

  //In this case, exactly one of the verts is a BdryApex.
  //To make sure all edges with small incident surface angles get
  //split safely, split all such segments in power of 2 lengths,
  //using the biggest power of 2 less than 2/3 of current edge
  //length.  This will ensure a split between 1/3 and 2/3.
  else {
    
    assert( (vert1->iVertType() == Vert::eBdryApex &&
	     vert2->iVertType() == Vert::eBdryCurve) ||
	    (vert2->iVertType() == Vert::eBdryApex &&
	     vert1->iVertType() == Vert::eBdryCurve) );
        
    //Compute the log_e of 2/3 the length, then convert to log_2 by
    //multiplying by log_2(e) (equivalent to dividing by
    //log_e(2)).  Then take the largest integer below this.
    
    double length = get_length();
    double split_power = floor( log(length / 1.5) * M_LOG2E );
    double split_dist  = pow(2., split_power);
    assert( length <= 3. * split_dist && 1.5 * split_dist <= length );

    //No parent curve defined, split at split_dist from apex vertex.
    if( !m_parent_edge ) {
      
      double subseg_vec[] = adDIFF3D( vert2->adCoords(), vert1->adCoords() );
      vNORMALIZE3D(subseg_vec);

      if (vert1->iVertType() == Vert::eBdryApex) {
	split_coords[0] = vert1->dX() + split_dist * subseg_vec[0];
	split_coords[1] = vert1->dY() + split_dist * subseg_vec[1];
	split_coords[2] = vert1->dZ() + split_dist * subseg_vec[2];
      }
      else {
	split_coords[0] = vert2->dX() - split_dist * subseg_vec[0];
	split_coords[1] = vert2->dY() - split_dist * subseg_vec[1];
	split_coords[2] = vert2->dZ() - split_dist * subseg_vec[2];
      }

      //Set the parameter manually to some dummy value.
      split_param = -LARGE_DBL;

    }

    //We have a parent curve attached, so find the parameter on the curve
    //that is at split_dist from the apex vertex.
    else {

      //Compute the split parameter.
      assert( m_vd1->param >= m_parent_edge->start_param() &&
	      m_vd1->param <= m_parent_edge->end_param() );
      assert( m_vd2->param >= m_parent_edge->start_param() &&
	      m_vd2->param <= m_parent_edge->end_param() );

      split_param = vert1->iVertType() == Vert::eBdryApex ? 
	param_at_distance_from_vert(split_dist, vert1) : 
	param_at_distance_from_vert(split_dist, vert2);

      assert( split_param >  m_vd1->param && split_param < m_vd2->param );
      assert( split_param >= m_parent_edge->start_param() &&
	      split_param <= m_parent_edge->end_param() );

      //Compute the split coordinates
      CubitVector tmp_coord;
      m_parent_edge->position_from_u(split_param, tmp_coord);
      tmp_coord.get_xyz( split_coords );

    }

  }

}

void Subseg::refinement_split(const double split_coords[3],
			      const double split_param,
			      Vert* const new_vert,
			      Subseg* const new_subseg1, 
			      Subseg* const new_subseg2) {

  //Set the new subsegments param.
  new_subseg1->m_vd1->param = m_vd1->param;
  new_subseg1->m_vd2->param = new_subseg2->m_vd1->param = split_param;
  new_subseg2->m_vd2->param = m_vd2->param;

  //Perform the split
  split( split_coords, new_vert, new_subseg1, new_subseg2 );

#ifndef NDEBUG

  if( new_subseg1->m_parent_edge ) {
    assert( new_subseg1->m_vd1->param >= m_parent_edge->start_param() &&
	    new_subseg1->m_vd1->param <= m_parent_edge->end_param() );
    assert( new_subseg1->m_vd2->param >= m_parent_edge->start_param() &&
	    new_subseg1->m_vd2->param <= m_parent_edge->end_param() );
  }
  if( new_subseg2->m_parent_edge ) {
    assert( new_subseg2->m_vd1->param >= m_parent_edge->start_param() &&
	    new_subseg2->m_vd1->param <= m_parent_edge->end_param() );
    assert( new_subseg2->m_vd2->param >= m_parent_edge->start_param() &&
	    new_subseg2->m_vd2->param <= m_parent_edge->end_param() );
  }

#endif

}

void Subseg::refinement_split( Vert* const new_vert, 
			       Subseg* const new_subseg1,
			       Subseg* const new_subseg2 ) {
  
  double split_coords[3], split_param;
  compute_refinement_split_data(split_coords, split_param);
  refinement_split(split_coords, split_param, new_vert, new_subseg1, new_subseg2);

}

void Subseg::split_at_param(const double  split_param,
			    Subseg* const new_subseg1, 
			    Subseg* const new_subseg2,
			    Vert*   const new_vert) {

  assert( m_parent_edge );
  assert( is_not_deleted() );

  //Make sure this param is within a valid range.
  assert( split_param > m_vd1->param && 
	  split_param < m_vd2->param );
  
  //Obtain the split coordinates from the param. 
  CubitVector tmp_coords;
  m_parent_edge->position_from_u(split_param, tmp_coords);

  double split_coords[3];
  tmp_coords.get_xyz( split_coords );

  //Perform the split with the info we gathered.
  split( split_coords, new_vert, new_subseg1, new_subseg2 );

  //We know the split param, so set it in the new subsegments.
  new_subseg1->m_vd1->param  = m_vd1->param;
  new_subseg1->m_vd2->param  = split_param;
  new_subseg2->m_vd1->param  = split_param;
  new_subseg2->m_vd2->param  = m_vd2->param;

}

void Subseg::split_at_coords(const CubitVector& split_coords,
			     Vert* const new_vert,
			     Subseg* const new_subseg1, Subseg* const new_subseg2) { 
 
  double split_loc[3];
  split_coords.get_xyz(split_loc);
  
  split( split_loc, new_vert, new_subseg1, new_subseg2 ); 

}

void Subseg::split( const double split_coords[3], 
		    Vert* const new_vert,
		    Subseg* const new_subseg1,
		    Subseg* const new_subseg2 ) {

  assert( new_vert && !new_vert->qDeleted() );
  assert( new_subseg1 && new_subseg1->is_not_deleted() );
  assert( new_subseg2 && new_subseg2->is_not_deleted() );

  mark_deleted();

  new_vert->vSetCoords(3, split_coords);
  new_vert->vSetType(Vert::eBdryCurve);
  new_vert->set_parent_topology(m_parent_edge);

  assert(new_subseg1->m_vd1);
  assert(new_subseg1->m_vd2);
  assert(new_subseg2->m_vd1);
  assert(new_subseg2->m_vd2);

  new_subseg1->m_vd1->vertex = m_vd1->vertex;
  new_subseg1->m_vd2->vertex = new_vert;
  new_subseg2->m_vd1->vertex = new_vert;
  new_subseg2->m_vd2->vertex = m_vd2->vertex;

  new_subseg1->m_parent_edge = m_parent_edge;
  new_subseg2->m_parent_edge = m_parent_edge;

  new_subseg1->m_deleted = false;
  new_subseg2->m_deleted = false;

}

CubitVector Subseg::
mid_point() const {

  return CubitVector( 0.5 * (m_vd1->vertex->dX() + m_vd2->vertex->dX()),
		      0.5 * (m_vd1->vertex->dY() + m_vd2->vertex->dY()),
		      0.5 * (m_vd1->vertex->dZ() + m_vd2->vertex->dZ()) );

}

double Subseg::
ball_radius() const {

  return 0.5 * dDistanceBetween(m_vd1->vertex, m_vd2->vertex);

}

CubitBox Subseg::
bounding_box() const {

  CubitVector midpoint = mid_point();
  double radius = ball_radius();

  double x1 = midpoint.x() - radius, x2 = midpoint.x() + radius;
  double y1 = midpoint.y() - radius, y2 = midpoint.y() + radius;
  double z1 = midpoint.z() - radius, z2 = midpoint.z() + radius;

  CubitVector max_coord( std::max(x1, x2), std::max(y1, y2), std::max(z1, z2) );
  CubitVector min_coord( std::min(x1, x2), std::min(y1, y2), std::min(z1, z2) );

  return CubitBox(min_coord, max_coord);

}

void Subseg::
closest_on_subseg(const double pt[3], double close[3]) const {

  Vert *vert0 = get_beg_vert(), *vert1 = get_end_vert();
  
  double diff0[] = adDIFF3D(vert0->adCoords(), pt);
  double diff1[] = adDIFF3D(vert1->adCoords(), vert0->adCoords());
  double param = - dDOT3D(diff0, diff1) / dMAG3D_SQ(diff1);
  
  if(param <= 0.) {
    close[0] = vert0->dX();
    close[1] = vert0->dY();
    close[2] = vert0->dZ();
    return; //no need to project.
  }

  else if(param >= 1.) {
    close[0] = vert1->dX();
    close[1] = vert1->dY();
    close[2] = vert1->dZ();
    return; //no need to project.
  }

  else {

    close[0] = vert0->dX() + param * diff1[0]; 
    close[1] = vert0->dY() + param * diff1[1];
    close[2] = vert0->dZ() + param * diff1[2];    

    if(m_parent_edge) { //project onto curve
      CubitVector close_pt(close), closest;
      m_parent_edge->closest_point(close_pt, closest);
      closest.get_xyz(close);
    }

  }

}
