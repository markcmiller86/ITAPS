#include "GR_SurfaceSampler.h"
#include "GR_events.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_FacetSurfIntersect.h"
#include "GR_Geometry.h"
#include "GR_Mesh.h"
#include "GR_SamplingQueue.h"
#include "GR_Subseg.h"
#include "GR_SurfIntersect.h"
#include "GR_SurfMeshBuilder.h"
#include "GR_TetMeshInitializer.h" 
#include "GR_Vec.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h" 

#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "FacetEvalTool.hpp"
#include "FacetSurface.hpp"
#include "GeometryDefines.h"
#include "RefEdge.hpp"
#include "RefFace.hpp"
#include "RefVertex.hpp"

#include <map>
#include <queue>
#include <set>
#include <vector>
#include <algorithm>
#include <functional>
#include <numeric>
#include <iterator>

using std::map;
using std::multimap;
using std::multiset;
using std::pair;
using std::queue;
using std::set;
using std::vector;

SurfaceSampler::
SurfaceSampler(RefFace* const surface,
	       const SurfMeshBuilder::ModelerType modeler_type) 
  : m_modeler_type(modeler_type),
    m_mesh(NULL), m_surface(surface),
    m_surf_intersect(NULL),
    m_sample_verts(), m_restricted_faces(),
    m_restrict_initialized(false) {
 
  assert(modeler_type != SurfMeshBuilder::UNKNOWN);
  assert(modeler_type == SurfMeshBuilder::FACET); //temporary
 
  if(modeler_type == SurfMeshBuilder::FACET) {
    m_surf_intersect = new FacetSurfIntersect(surface);
  }
  else { //temporary... I hope.
    vFatalError("Only facet based modeler supported for now.",
		"SurfaceSampler::SurfaceSampler()");
  }

  //Initialize the mesh used by the sampler.
  initialize_mesh();

}

SurfaceSampler::
~SurfaceSampler() {

  RestrictedFaceDict::iterator 
    itf     = m_restricted_faces.begin(), 
    itf_end = m_restricted_faces.end();

  for( ; itf != itf_end; ++itf)
    if(itf->second) delete itf->second;

  SampleVertDict::iterator 
    itv     = m_sample_verts.begin(), 
    itv_end = m_sample_verts.end();

  for( ; itv != itv_end; ++itv) 
    if(itv->second) delete itv->second;
  
  m_restricted_faces.clear();
  m_sample_verts.clear();
  
  //Delete what has been instantiated here.
  if(m_mesh)           delete m_mesh;
  if(m_surf_intersect) delete m_surf_intersect;

}

void SurfaceSampler::
initialize_mesh() {

  //Computes the bouding box of the surface.
  //Builds a tetrahedral inside a rectangular prism
  //roughly the size of this box. 

  assert(!m_mesh);
   
  CubitBox box = m_surface->bounding_box();

  CubitVector box_dim = box.maximum() - box.minimum();
  assert( iFuzzyComp(box_dim.x(), 0.) != -1 && 
	  iFuzzyComp(box_dim.y(), 0.) != -1 &&
	  iFuzzyComp(box_dim.z(), 0.) != -1 );

  double large_dim = MAX3( box_dim.x(), box_dim.y(), box_dim.z() );

  CubitVector tolerance(large_dim, large_dim, large_dim);

  CubitVector mini = box.minimum() - tolerance;
  CubitVector maxi = box.maximum() + tolerance;

  m_mesh = new TetMeshInitializer( CubitBox(mini, maxi) );

}

//This is an initialization function. As such, it first deletes all 
//existing restricted triangulation data (if any exists). It populates
//the two vectors with the restricted faces and the sample vertices
//currently in the sampler.

void SurfaceSampler::
init_restricted_delaunay(vector<VertWithTag>& sample_verts,
			 vector<RestrictFace>& restricted_faces) {

  assert(m_mesh);
  assert(!m_restrict_initialized);
  assert(sample_verts.empty());
  assert(restricted_faces.empty());

  //Remove all existing restricted data.
  for(int i = m_mesh->get_mesh()->iNumFaces() - 1; i >= 0; i--) 
    m_mesh->get_mesh()->pFFace(i)->unset_restricted_delaunay();
  
  RestrictedFaceDict::iterator 
    itf     = m_restricted_faces.begin(), 
    itf_end = m_restricted_faces.end();

  for( ; itf != itf_end; ++itf)
    if(itf->second) delete itf->second;

  m_restricted_faces.clear();
  
  //(re)Compute restricted triangulation.
  Face* face;
#ifndef NDEBUG
  int num_bdry_faces = 0;
#endif

  for(int i = m_mesh->get_mesh()->iNumFaces() - 1; i >= 0; i--) {

    face = m_mesh->get_mesh()->pFFace(i);
    if(face->qDeleted()) continue;
    if(face->iFaceLoc() == Face::eBdryFace) {
#ifndef NDEBUG
      assert( face->pVVert(0)->iVertType() == Vert::eBBox &&
	      face->pVVert(1)->iVertType() == Vert::eBBox &&
	      face->pVVert(2)->iVertType() == Vert::eBBox );
      ++num_bdry_faces;
#endif
      continue;
    }

    VoronoiEdge edge(face->pCCellLeft(), face->pCCellRight());
    compute_restricted_data( edge, restricted_faces );
    
  }

  //We should have twelve boundary faces (TWELVE ONLY) 
  //on the boundary of the bounding box.
  assert(num_bdry_faces == 12);

  //The restricted triangulation is now initialized.
  m_restrict_initialized = true;

  //If no restricted faces were found, and if there are no subsegments
  //i.e. a smooth surface without initial restricted faces, then need to insert
  //arbitrary points on the surface to initializing sampling algo.
  if(restricted_faces.empty() && m_sample_verts.empty()) { 
    seed_surface(restricted_faces);
  }
 
  sample_verts.reserve(m_sample_verts.size());
  std::copy( m_sample_verts.begin(), m_sample_verts.end(), 
	     std::back_inserter(sample_verts) );

}

void SurfaceSampler::
split_box_attached(vector<RestrictFace>& restrict_faces) {

  //I don't think this is necessary. 
  //Plus this is more of a guideline implementation, I think 
  //pieces are still missing, so it might not even work.
  assert(0);

  Face* face;
  bool  split_occured = false;
  vector<RestrictFace> new_restrict_faces;
  vector<RestrictFace>::const_iterator it, it_end;

  do {

    it     = restrict_faces.begin();
    it_end = restrict_faces.end();

    for( ; it != it_end; ++it) {

      face = it->first;
      if(face->qDeleted()) continue;
    
      if( face->pVVert(0)->iVertType() == Vert::eBBox ||
	  face->pVVert(1)->iVertType() == Vert::eBBox ||
	  face->pVVert(2)->iVertType() == Vert::eBBox ) {

	//Face is connected to the bounding box, needs to be split.
	split_occured = true;
	new_restrict_faces.clear();

	assert(!it->second.empty()); //it->second is the set of intersections.
	TriFace* tri_face = dynamic_cast<TriFace*>(face); assert(tri_face);
	SurfIntersect::Intersection far_intersect;
	std::for_each(it->second.begin(), it->second.end(),
		      SurfIntersect::FarthestIntersect(tri_face->circumcenter(), &far_intersect));

	CubitVector insert_coord;
	far_intersect.get_triangle()->
	  project_to_surface( far_intersect.get_intersect_coord(), &insert_coord );

	Vert dummy_vert;
	dummy_vert.vSetCoords(3, insert_coord);
	insert_sample_point(&dummy_vert, face->pVVert(0), NULL, NULL, 
			    &new_restrict_faces);
     
      }

    }

    std::copy( new_restrict_faces.begin(), new_restrict_faces.end(), 
	       std::back_inserter(restrict_faces) );

  } while(!new_restrict_faces.empty());

  if(!split_occured) return;
  
  assert(new_restrict_faces.empty());
  
  it = restrict_faces.begin();
  it_end = restrict_faces.end();

  for( ; it != it_end; ++it) 
    if(!it->first->qDeleted()) 
      new_restrict_faces.push_back( std::make_pair(it->first, it->second) );
 
  restrict_faces.swap(new_restrict_faces);

}

//To accelerate intersection search, we only intersect the Voronoi edge with 
//the facetted model (there should always be a facetted model available in CGM,
//independently of what modeler is used). Once this is done, we eliminate double 
//(triple, quadruple, ...) entries (this will occur if an edge intersects a 
//triangle on its boundary).

//The function returns all the faces whose Voronoi edge intersects the surface
//once or more, accompanied by at set of these intersections.

void SurfaceSampler::
compute_restricted_data(const VoronoiEdge& voronoi_edge,
			vector<RestrictFace>& new_restrict_faces) {
  
  assert(m_surf_intersect);
  assert(!voronoi_edge.get_face()->qDeleted());
  assert(!voronoi_edge.get_face()->pCCellLeft() ->qDeleted());
  assert(!voronoi_edge.get_face()->pCCellRight()->qDeleted());

  //Get face associated with Voronoi edge.
  Face* face = voronoi_edge.get_face();
  RestrictedFaceTag* face_tag = NULL;
  assert(face->iNumVerts() == 3);

  //Finds intersection with Voronoi edge and surface.
  SurfIntersect::IntersectSet intersections; 
  m_surf_intersect->intersect_with_voronoi_edge(voronoi_edge, intersections);

  //Sets tags and intersection info depending on face's current status.
  switch (face->is_restricted_delaunay() ) {

  case true: { //Face was restricted Delaunay.

    RestrictedFaceDict::iterator it_rest_face = m_restricted_faces.find(face);    
    assert(it_rest_face != m_restricted_faces.end());
    face_tag = it_rest_face->second;

    if(!intersections.empty()) { //Face remains restricted Delaunay.
      face_tag->reset_tag();
      new_restrict_faces.push_back( std::make_pair(face, intersections) );
    }
    
    else { //Face no longer restricted Delaunay.
      for(int i = 0; i < 3; i++) {
	assert( m_sample_verts.count(face->pVVert(i)) == 1 );
	m_sample_verts.find(face->pVVert(i))->second->remove_ring_face(face);
      }
      if(face_tag) { delete face_tag; }
      m_restricted_faces.erase(it_rest_face);
      face->unset_restricted_delaunay();
      return;
    }

    break;

  }

  case false: { //Face was not restricted Delaunay.

    assert(m_restricted_faces.count(face) == 0);

    if(!intersections.empty()) { //Face becomes restricted Delaunay.
      face->set_restricted_delaunay();
      face_tag = new RestrictedFaceTag(face);
      m_restricted_faces.insert( std::make_pair(face, face_tag) );
      new_restrict_faces.push_back( std::make_pair(face, intersections) );
      
      for(int i = 0; i < 3; i++) { //Face does not change status.
	SampleVertDict::iterator it_vert; it_vert = m_sample_verts.find(face->pVVert(i));
	if(it_vert != m_sample_verts.end()) it_vert->second->add_ring_face(face);
      }      
    }

    else {
#ifndef NDEBUG
      for(int i = 0; i < 3; i++) {
	SampleVertDict::iterator it_v = m_sample_verts.find(face->pVVert(i));
	if(it_v != m_sample_verts.end()) assert(!it_v->second->get_ring_faces().count(face));	
      }
#endif
      return;
    }
  
    break;

  }

  }

  //Set intersection data.
  //It is possible that many intersections were found for the Voronoi edge.
  //If that is the case, use the farthest from face's circumcenter and set 
  //accordingly in the face tag.
  assert(face_tag);
  assert(face_tag->get_face() == face);
  
  TriFace* tri_face = dynamic_cast<TriFace*>(face); assert(tri_face);

  SurfIntersect::Intersection far_intersect;
  std::for_each(intersections.begin(), intersections.end(),
		SurfIntersect::FarthestIntersect(tri_face->circumcenter(), &far_intersect));

  face_tag->set_intersect(far_intersect);

}

void SurfaceSampler::
seed_surface(vector<RestrictFace>& restrict_faces) {

  assert(m_surface);
  assert(m_surf_intersect);

  SurfTri* triangle;
  Vert insert_vert, *vertex;
  SampleVertTag* vertex_tag;
  CubitVector insert_coord, insert_normal, triangle_centroid;
  
  SurfIntersect::SurfTriSet surf_tris;
  m_surf_intersect->get_triangles(surf_tris);

  SurfIntersect::SurfTriSet::iterator 
    it_tri = surf_tris.begin(),
    it_tri_end = surf_tris.end();

  SampleVertDict::iterator itv, itv_end;

  vector<RestrictFace> tmp_vec;

  while(it_tri != it_tri_end) {

    tmp_vec.clear();

    triangle = *it_tri;
    triangle_centroid = triangle->get_centroid();
    triangle->project_to_surface( triangle_centroid, 
				  &insert_coord, &insert_normal );
    
    insert_vert.vSetCoords(3, insert_coord);
    insert_vert.set_parent_topology(m_surface);
    insert_vert.vSetType(Vert::ePseudoSurface);

    vertex = insert_sample_point(&insert_vert, NULL, NULL, NULL, &tmp_vec);
    vertex_tag = get_vert_tag(vertex);
    vertex_tag->set_normal(insert_normal);
    vertex_tag->set_curvature( triangle->curvature_at_coord(triangle_centroid) ); 

    std::copy(tmp_vec.begin(), tmp_vec.end(),
	      std::back_inserter(restrict_faces));

    itv = m_sample_verts.begin();
    itv_end = m_sample_verts.end();
    for( ; itv != itv_end; ++itv)       
      if( itv->second->num_ring_faces() == 0 ) { ++it_tri; break; }

    if( itv != itv_end ) continue;
    if( !restrict_faces.empty() ) break;

  }

  assert(!restrict_faces.empty());

}

Vert* SurfaceSampler::
insert_sample_point(const Vert* const vertex,
		    const Vert* const guess1,
		    const Vert* const guess2,
		    const Vert* const guess3,
		    vector<RestrictFace>* new_restrict_faces) {

  set<const Vert*> vert_guesses;
  if(guess1) vert_guesses.insert(guess1);
  if(guess2) vert_guesses.insert(guess2);
  if(guess3) vert_guesses.insert(guess3);

  return insert_sample_point(vertex, vert_guesses, new_restrict_faces);

}

Vert* SurfaceSampler::
insert_sample_point(const Vert* const vertex,
		    const SubsegBridge* const bridge,
		    vector<RestrictFace>* new_restrict_faces) {

  set<const Vert*> vert_guesses;

  vert_guesses.insert( const_cast<const Vert*>( bridge->get_vert(0) ) );
  vert_guesses.insert( const_cast<const Vert*>( bridge->get_vert(1) ) );

  return insert_sample_point(vertex, vert_guesses, new_restrict_faces);

}

Vert* SurfaceSampler::
insert_sample_point(const Vert* const vertex, 
		    const Face* const face,
		    vector<RestrictFace>* new_restrict_faces) {

  Vert* new_vert = NULL;
  vector<Cell*> new_cells;

  set<const Cell*> guesses;
  guesses.insert(face->pCCellLeft());
  guesses.insert(face->pCCellRight());

  new_vert = insert_sample_point(vertex, guesses, true, new_restrict_faces);

  if(new_vert) return new_vert;

  assert(face->iNumVerts() == 3);

  std::set<const Vert*> vert_guesses;
  vert_guesses.insert(face->pVVert(0));
  vert_guesses.insert(face->pVVert(1));
  vert_guesses.insert(face->pVVert(2));
    
  return insert_sample_point(vertex, vert_guesses, new_restrict_faces);

}

Vert* SurfaceSampler::
insert_sample_point(const Vert* const vertex,
		    const set<const Vert*>& vert_guesses,
		    vector<RestrictFace>* new_restrict_faces) {

  set<const Cell*> seed_guesses;
  set<Cell*> cells_tmp;
  set<Vert*> verts_tmp;

  set<const Vert*>::iterator 
    vert     = vert_guesses.begin(),
    vert_end = vert_guesses.end();

  for( ; vert != vert_end; ++vert) {

    Vert* guess_vert = const_cast<Vert*>(*vert);
    assert( m_sample_verts.find(guess_vert) != m_sample_verts.end() );

    cells_tmp.clear(); verts_tmp.clear();
    vNeighborhood(guess_vert, cells_tmp, verts_tmp);

    std::copy( cells_tmp.begin(), cells_tmp.end(),
	       std::inserter(seed_guesses, seed_guesses.begin()) );
    
  }

  return insert_sample_point(vertex, seed_guesses, false, new_restrict_faces);

}

Vert* SurfaceSampler::
insert_sample_point(const Vert* const vertex,
		    const set<const Cell*>& seed_guesses,
		    const bool bail_on_bad_guesses,
		    vector<RestrictFace>* new_restrict_faces) {

  vector<Cell*> new_cells;
  Vert* new_vert = NULL;

  //Find if there is a valid Watson seed among the guesses.
  Cell* seed = NULL;

  set<const Cell*>::iterator 
    cell     = seed_guesses.begin(),
    cell_end = seed_guesses.end();

  for( ; cell != cell_end; ++cell) {
    const Cell* guess = *cell;
    assert(guess); assert(!guess->qDeleted());

    if(TetMeshInitializer::cell_is_seed(vertex, guess)) 
      { seed = const_cast<Cell*>(guess); break; }
  }

  //Can choose to bail if no valid seed is found in the set.
  //In this case, return a NULL pointer.
  if(bail_on_bad_guesses && !seed) 
    return static_cast<Vert*>(NULL);
  
  //If a seed was found, use it for insertion,
  //If not, we will have to find a seed naively.
  if(seed)
    new_vert = m_mesh->insert_vert_in_mesh(vertex, seed, &new_cells);
  else
    new_vert = m_mesh->insert_vert_in_mesh(vertex, &new_cells);

  //Vertex was inserted, now update the other data structures.

  assert(new_vert);
  assert(m_sample_verts.count(new_vert) == 0);

  //Create the sample vertex tag and insert it into the dictionary.
  SampleVertTag* vertex_tag = new SampleVertTag(new_vert);
  m_sample_verts.insert( std::make_pair(new_vert, vertex_tag) );

  //Update the Voronoi diag and obtain new edges.
  vector<VoronoiEdge> new_voronoi_edges;
  build_voronoi_edges(new_cells, new_voronoi_edges);

  //Update restricted triangulation data based 
  //on the new Voronoi edges. Gets new restricted faces.
  
  vector<RestrictFace> rest_faces;

  if(m_restrict_initialized) {
    vector<VoronoiEdge>::iterator 
      edge     = new_voronoi_edges.begin(),
      edge_end = new_voronoi_edges.end();
    for( ; edge != edge_end; ++edge)
      compute_restricted_data(*edge, rest_faces);
  }

  if(new_restrict_faces) {
    assert(new_restrict_faces->empty());
    new_restrict_faces->swap(rest_faces);
  }

  return new_vert;

}

void SurfaceSampler::
get_sample_verts(vector<Vert*>& sample_verts) const {
 
  //Note that the first 8 vertices are always 
  //the corner of the bounding box. We do not want them.

  Vert* vertex;
  
  for(int i = m_mesh->get_mesh()->iNumVerts() - 1; i >= 8; i--) {

    vertex = m_mesh->get_mesh()->pVVert(i);
    if( vertex->qDeleted() ) continue;

    assert(m_sample_verts.count(vertex) == 1);
    sample_verts.push_back(vertex);

  }

}

void SurfaceSampler::
get_restricted_faces(vector<Face*>& restricted_faces) const {
  
  Face* face;

  for(int i = m_mesh->get_mesh()->iNumFaces() - 1; i >= 0; i--) {

    face = m_mesh->get_mesh()->pFFace(i);
    if(face->qDeleted()) continue;

    if(face->is_restricted_delaunay()) {
      assert(m_restricted_faces.count(face) == 1);
      restricted_faces.push_back(face);
    }
#ifndef NDEBUG
    else {
      assert(m_restricted_faces.count(face) == 0);
    }
#endif

  }

}

SampleVertTag* SurfaceSampler::
get_vert_tag(Vert* const vertex) const {

  assert(m_sample_verts.count(vertex) == 1);
  return m_sample_verts.find(vertex)->second;

}

RestrictedFaceTag* SurfaceSampler::
get_face_tag(Face* const face) const {

#ifndef NDEBUG
  assert(face->is_restricted_delaunay());
  assert(m_restricted_faces.count(face) == 1);
#endif

  return m_restricted_faces.find(face)->second;

}

CubitVector SurfaceSampler::
normal_at(const Vert* const vertex,
	  const double tolerance) const {

  assert(m_surface);
  assert(m_sample_verts.count(const_cast<Vert*>(vertex)) == 1);

  Surface* surf = m_surface->get_surface_ptr();
  CubitVector normal, dummy;

  FacetSurface* facet_surf;

  switch(m_modeler_type) {
  
  case SurfMeshBuilder::FACET:
    facet_surf = dynamic_cast<FacetSurface*>(surf); assert(facet_surf);
    facet_surf->get_eval_tool()->compare_tol(tolerance);
    facet_surf->closest_point(CubitVector(vertex->adCoords()), &dummy, &normal);
    break;
  
  case SurfMeshBuilder::UNKNOWN:
    vFatalError("Modeler type not set properly.",
		"SurfaceSampler::normal_at()");
    break;

  case SurfMeshBuilder::ACIS:
  case SurfMeshBuilder::OCC:
  default:
    vFatalError("Only support for facet modeler is currently implemented.",
		"SurfaceSampler::normal_at()");
    break;
  
  }

  return normal;

}

void SurfaceSampler::
project_to_surface(const CubitVector& point, 
		   CubitVector& point_on_surf,
		   CubitVector& normal_at_point,
		   const double tolerance) const {

  Surface* surf = m_surface->get_surface_ptr();

  FacetSurface* facet_surf;

  switch(m_modeler_type) {
  
  case SurfMeshBuilder::FACET:
    facet_surf = dynamic_cast<FacetSurface*>(surf); assert(facet_surf);
    facet_surf->get_eval_tool()->compare_tol(tolerance);
    facet_surf->closest_point(point, &point_on_surf, &normal_at_point);
    break;

  case SurfMeshBuilder::UNKNOWN:
    vFatalError("Modeler type not set properly.",
		"SurfaceSampler::normal_at()");
    break;

  case SurfMeshBuilder::ACIS:
  case SurfMeshBuilder::OCC:
  default:
    vFatalError("Only support for facet modeler is currently implemented.",
		"SurfaceSampler::project_to_surface()");
    break;
  
  }

}

void SurfaceSampler::
restricted_neighborhood(const Vert* const vertex,
			vector<Face*>* const neigh_faces,
			vector<Vert*>* const neigh_verts) const {

  //computes the 1-star of vertex in the restricted triangulation.
  //Not really used anymore since the star is stored in the vertex tag.

  assert(neigh_faces);
  neigh_faces->clear();

  int i;

  Face* face = vertex->pFHintFace();
  assert(face->qValid() && face->qHasVert(vertex));

  Cell* cell = face->pCCellLeft(); 
  if(cell->qIsBdryCell()) cell = face->pCCellRight();
  assert(!cell->qIsBdryCell());
  assert(cell->iNumFaces() == 4);
  
  queue< std::pair<Face*, Cell*> > face_to_traverse;
  set<Face*>                       face_traversed;
  
  for(i = 0; i < 4; i++) {
    face = cell->pFFace(i);
    if(face->qHasVert(vertex) && face_traversed.insert(face).second)
      face_to_traverse.push( std::make_pair(face, face->pCCellOpposite(cell)) );    
  }

  while(!face_to_traverse.empty()) {

    face = face_to_traverse.front().first;
    cell = face_to_traverse.front().second;
    assert(face->qHasVert(vertex));
    assert(cell->qHasFace(face));
    assert(!cell->qIsBdryCell());
    assert(cell->iNumFaces() == 4);

    face_to_traverse.pop();
        
    if(face->is_restricted_delaunay())
      neigh_faces->push_back(face);

    for(i = 0; i < 4; i++) { 
      face = cell->pFFace(i);
      if(face->qHasVert(vertex) && face_traversed.insert(face).second) 
	face_to_traverse.push( std::make_pair(face, face->pCCellOpposite(cell)) );
    }

  }

  if(neigh_verts) {

    Vert* vert;
    set<Vert*> dummy;

    vector<Face*>::iterator 
      it     = neigh_faces->begin(),
      it_end = neigh_faces->end();

    for( ; it != it_end; ++it) {

      face = *it;
      assert(face->iNumVerts() == 3);

      for(i = 0; i < 3; i++) {
	vert = face->pVVert(i);
	if(vert != vertex && dummy.insert(vert).second)
	  neigh_verts->push_back(vert);
      }

    }

  }

}

void SurfaceSampler::
build_voronoi_edges(const vector<Cell*>& new_cells,
		    vector<VoronoiEdge>& new_voronoi_edges) {

  int i;
  Face* face;
  Cell *cell, *cell1, *cell2;
  CubitVector dummy;

  set<Face*> faces_visited;

  typedef map<Cell*, CubitVector> VisitedCells;
  VisitedCells cells_visited;

  typedef std::pair< VisitedCells::iterator, bool > InsertData; 
  InsertData ID1, ID2;

  vector<Cell*>::const_iterator 
    it_cell     = new_cells.begin(),
    it_cell_end = new_cells.end();

  for( ; it_cell != it_cell_end; ++it_cell) {

    cell = *it_cell; assert(!cell->qDeleted());
    
    for(i = cell->iNumFaces() - 1; i >= 0; i--) {

      face = cell->pFFace(i);
      
      if( faces_visited.insert(face).second ) {

	cell1 = face->pCCellLeft();
	cell2 = face->pCCellRight();

	ID1 = cells_visited.insert( std::make_pair(cell1, dummy) );	
	ID2 = cells_visited.insert( std::make_pair(cell2, dummy) );

	if(ID1.second)
	  VoronoiEdge::voronoi_vert_coord(cell1, ID1.first->second); 
	if(ID2.second) 
	  VoronoiEdge::voronoi_vert_coord(cell2, ID2.first->second); 

	new_voronoi_edges.push_back( VoronoiEdge(face, ID1.first->second, 
						 ID2.first->second) );

      }

    }
      
  }

}

void SurfaceSampler::
attach_bridge(Vert* const vertex,
	      SubsegBridge* const bridge) {

  assert(m_sample_verts.count(vertex) == 1);
  m_sample_verts.find(vertex)->second->add_bridge(bridge);

}

void SurfaceSampler::
remove_bridge(Vert* const vertex,
	      SubsegBridge* const bridge) {

  assert(m_sample_verts.count(vertex) == 1);
  m_sample_verts.find(vertex)->second->remove_bridge(bridge);

}

void SurfaceSampler::
clean_vert_tags() {

  //Removes all tags whose Vert is deleted.
  //Also removes the deleted faces from the 1-star stored in the tag.

  Vert* vertex;
  SampleVertTag* vertex_tag;
  SampleVertDict dummy_map;

  SampleVertDict::iterator 
    itv     = m_sample_verts.begin(),
    itv_end = m_sample_verts.end();

  for( ; itv != itv_end; ++itv) {

    vertex     = itv->first;
    vertex_tag = itv->second;

    if(vertex->qDeleted()) {
      if(vertex_tag) delete vertex_tag;
    }
    else { 
      vertex_tag->clean_tag();
      dummy_map.insert( std::make_pair(vertex, vertex_tag) );
    }

  }

  m_sample_verts.swap(dummy_map);

#ifndef NDEBUG

  Face* face;

  itv     = m_sample_verts.begin();
  itv_end = m_sample_verts.end();

  for( ; itv != itv_end; ++itv) {

    vertex     = itv->first;
    vertex_tag = itv->second;
    assert(vertex == vertex_tag->get_vertex());

    set<Face*>::iterator
      itf     = vertex_tag->get_ring_faces().begin(),
      itf_end = vertex_tag->get_ring_faces().end();

    for( ; itf != itf_end; ++itf) {
      face = *itf;
      assert(face && face->qValid());
      assert(!face->qDeleted());
      assert(face->qHasVert(vertex));
      assert(face->is_restricted_delaunay());
      assert(m_restricted_faces.count(face) == 1);
    }

  }

#endif

}

void SurfaceSampler::
clean_face_tags() {

  //Removes all tags whose Face is deleted.

  Face* face;
  RestrictedFaceTag* face_tag;
  RestrictedFaceDict dummy_map;

  RestrictedFaceDict::iterator 
    it     = m_restricted_faces.begin(),
    it_end = m_restricted_faces.end();

  for( ; it != it_end; ++it) {

    face     = it->first;
    face_tag = it->second;

    if(face->qDeleted()) { 
      if(face_tag) delete face_tag;
    }
    else { 
      face_tag->clean_tag();
      dummy_map.insert( std::make_pair(face, face_tag) );
    }
      
  }

  m_restricted_faces.swap(dummy_map);

}

void SurfaceSampler::
purge_sampler() {

  VertMap vert_map;
  FaceMap face_map;
  CellMap cell_map;

  purge_sampler(vert_map, face_map, cell_map);

}

void SurfaceSampler::
purge_sampler(VertMap& vert_map, FaceMap& face_map, 
	      CellMap& cell_map) {

  //Removes deleted entities from the dictionaries
  //as well as deleted entities from tags.
  clean_vert_tags();
  clean_face_tags();

#ifndef NDEBUG
 
  //Making sure tag cleaning went well.

  int num_faces = m_mesh->get_mesh()->iNumFaces(), num_undeleted = 0;
  
  for(int i = 0; i < num_faces; i++) {

    Face* face = m_mesh->get_mesh()->pFFace(i);
    assert(face->qValid());

    if( face->qDeleted() ) {
      assert( m_restricted_faces.count(face) == 0 );
      continue;
    }
    
    ++num_undeleted;
    Vert* vert0 = face->pVVert(0), *vert1 = face->pVVert(1), *vert2 = face->pVVert(2);
    SampleVertTag *tag0, *tag1, *tag2; 

    if( vert0->iVertType() == Vert::eBBox ||
	vert1->iVertType() == Vert::eBBox ||
	vert2->iVertType() == Vert::eBBox ) {
      assert( !face->is_restricted_delaunay() );
      assert( m_restricted_faces.count(face) == 0 );
      continue;
    }
    else {
      tag0 = get_vert_tag(vert0);
      tag1 = get_vert_tag(vert1);
      tag2 = get_vert_tag(vert2);
    }
    
    if(face->is_restricted_delaunay()) {
      assert( m_restricted_faces.count(face) == 1 );
      assert( tag0->has_ring_face(face) );
      assert( tag1->has_ring_face(face) );
      assert( tag2->has_ring_face(face) );
    }
    else {
      assert( m_restricted_faces.count(face) == 0 );
      assert( !tag0->has_ring_face(face) );
      assert( !tag1->has_ring_face(face) );
      assert( !tag2->has_ring_face(face) );
    }
  }

#endif

  //Make sure the containers are empty then, 
  //PURGE deleted entities in the Tet mesh, mapping old pointers to new pointers.
  vert_map.clear(); face_map.clear(); cell_map.clear();
  m_mesh->get_mesh()->vPurge(&vert_map, &face_map, &cell_map);

  assert( m_mesh->get_mesh()->iNumVerts() == vert_map.size() );
  assert( m_mesh->get_mesh()->iNumFaces() == face_map.size() );
  assert( m_mesh->get_mesh()->iNumCells() == cell_map.size() );

  VertMap::iterator itv, itv_end = vert_map.end();
  FaceMap::iterator itf, itf_end = face_map.end();

#ifndef NDEBUG
  
  for(itv = vert_map.begin(); itv != itv_end; ++itv) {

    Vert* this_vert = itv->first;
    int vert_count = m_sample_verts.count(this_vert), vert_index;

    switch(vert_count) {
    case 0:
      //The first 8 vertices should be the corner of the bounding
      //box and as such, do not appear in the vertex dictionary.
      assert(this_vert->iVertType() == Vert::eBBox);
      vert_index = m_mesh->get_mesh()->iVertIndex(this_vert);
      assert( vert_index >= 0 && vert_index < 8 );
      break;
    case 1:
      break;
    default:
      assert(0);
    }

  }

#endif

  //Based on the maps, UPDATE THE DATA STRUCTURES.

  //Update the sample vert dictionary and the associated tags.

  Vert* old_vert, *new_vert;
  Face* old_face, *new_face;
  SampleVertTag*     vertex_tag;
  RestrictedFaceTag* face_tag;

  SampleVertDict::iterator     itvdict;
  RestrictedFaceDict::iterator itfdict;

  set<Face*> new_ring_faces;
  set<Face*>::iterator itface, itface_end;
  set<SubsegBridge*>::iterator itbridge, itbridge_end;

  //Start by updating the vertices and their tags: 
  //the ring faces in the tag, then the bridges.

  for(itv = vert_map.begin(); itv != itv_end; ++itv) {

    old_vert = itv->first;
    if(old_vert->iVertType() == Vert::eBBox) continue;

    new_vert = itv->second;
    
    itvdict = m_sample_verts.find(old_vert);
    assert(itvdict != m_sample_verts.end());
    assert(itvdict->first == old_vert);
        
    vertex_tag = itvdict->second;
    assert(vertex_tag->get_vertex() == old_vert);
    vertex_tag->set_vertex(new_vert);

    //Replace the ring faces with their new post-purge address.
    itface     = vertex_tag->get_ring_faces().begin();
    itface_end = vertex_tag->get_ring_faces().end();
    new_ring_faces.clear();

    for( ; itface != itface_end; ++itface) {
      
      itf = face_map.find( *itface );
      assert( itf != face_map.end() );

      new_face = itf->second;
      assert( new_face->qHasVert(new_vert) );
      assert( new_face->is_restricted_delaunay() );
      new_ring_faces.insert(itf->second);

    }
    
    assert( vertex_tag->get_ring_faces().size() == new_ring_faces.size() );
    vertex_tag->replace_all_ring_faces(new_ring_faces);

    //If the vertex address did not change, nothing more to do.
    if( old_vert == new_vert ) continue;

    //Update vertex address in the subseg bridges.
    itbridge     = vertex_tag->get_bridges().begin();
    itbridge_end = vertex_tag->get_bridges().end();
    
    for( ; itbridge != itbridge_end; ++itbridge)
      (*itbridge)->replace_vert(old_vert, new_vert);

    //Finally, replace the entry in the vertex dictionnary.
    m_sample_verts.erase(itvdict);
    m_sample_verts.insert( std::make_pair(new_vert, vertex_tag) );

  }

  //Now, update the face dictonary and tags.

  for(itf = face_map.begin(); itf != itf_end; ++itf) {

    old_face = itf->first;
    new_face = itf->second;
    if(old_face == new_face) continue;
    
    itfdict = m_restricted_faces.find(old_face);
    
    //Should only happen if face is NOT restricted Delaunay
    if(itfdict == m_restricted_faces.end()) { 
      assert(!new_face->is_restricted_delaunay());
      continue;
    }

    assert(new_face->is_restricted_delaunay());
    face_tag = itfdict->second;
    face_tag->set_face(new_face);

    //We only have to replace the face tag.
    m_restricted_faces.erase(itfdict);
    m_restricted_faces.insert( std::make_pair(new_face, face_tag) );
    
  }
  
}

void SurfaceSampler::
output_restricted_delaunay(const char* const filename) const {

  FILE* out_file = fopen(filename, "w");
  if(!out_file) vFatalError("Cannot open output file for writing", 
			    "RefFaceSampler::output_restricted_delaunay"); 
 
  typedef vector<Face*>   FacePrint;
  typedef vector<Vert*>   VertPrint;
  typedef map<Vert*, int> VertIndex;

  FacePrint faces_to_print;
  VertPrint verts_to_print;
  VertIndex vert_indices;
  FacePrint::iterator itf, itf_end;
  VertPrint::iterator itv, itv_end;

  //Compute the faces intersected by Voronoi edges. Also obtain vertices to print.

  int counter = 1;
 
  get_restricted_faces(faces_to_print);
  itf     = faces_to_print.begin();
  itf_end = faces_to_print.end();

  for( ; itf != itf_end; ++itf) {

    Face* face = *itf;

    for(int i = 0; i < face->iNumVerts(); i++) {

      Vert* vert = face->pVVert(i);

      if( vert_indices.insert( std::make_pair(vert, counter) ).second ) {
	verts_to_print.push_back(vert);
	++counter;
      }

    }

  }
    
  fprintf(out_file, "MeshVersionFormatted 1\n");
  fprintf(out_file, "Dimension 3\n");

  fprintf(out_file, "Vertices\n");
  fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()));

  itv     = verts_to_print.begin();
  itv_end = verts_to_print.end();
  
  for( ; itv != itv_end; ++itv) {

    Vert* vert = *itv;

    fprintf(out_file, "%lf %lf %lf 2\n", 
	    vert->dX(), vert->dY(), vert->dZ());

  }

  itf = faces_to_print.begin();  

  fprintf(out_file, "Triangles\n");
  fprintf(out_file, "%d\n", static_cast<int>(itf_end - itf));

  for( ; itf != itf_end; ++itf) {

    Face* face = *itf;

    fprintf(out_file, "%d %d %d 2\n", 
	    vert_indices.find(face->pVVert(0))->second,
	    vert_indices.find(face->pVVert(1))->second,
	    vert_indices.find(face->pVVert(2))->second);

  }

  //The following code outputs normals at every vertex.
  //For this to work, the normal must be properly set in 
  //the SampleVertTag, something that is not done anymore.
  //Code is therefore commented out for now.

//   fprintf(out_file, "Normals\n");
//   fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()));

//   itv     = verts_to_print.begin();
//   itv_end = verts_to_print.end();
  
//   for( ; itv != itv_end; ++itv) {

//     Vert* vert = *itv;
//     assert(m_sample_verts.count(vert) == 1);

//     SampleVertTag* vert_tag = (m_sample_verts.find(vert))->second;
//     CubitVector* normal = vert_tag->get_normal();

//     fprintf(out_file, "%lf %lf %lf\n", 
// 	    normal->x(), normal->y(), normal->z());

//   }
  
//   fprintf(out_file, "NormalAtVertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()));
 
//   itv     = verts_to_print.begin();
//   itv_end = verts_to_print.end();
//   counter = 0;

//   for( ; itv != itv_end; ++itv) {
//     ++counter;
//     fprintf(out_file, "%d %d\n", counter, counter);
//   }

  fprintf(out_file, "End\n");

  fclose(out_file);

}

void SurfaceSampler::
output_faces(const char* const filename,
	     const set<Face*>& faces_to_print) const {

  vector<Face*> faces;
  std::copy(faces_to_print.begin(), faces_to_print.end(),
	    std::back_inserter(faces));

  output_faces(filename, faces);

}

void SurfaceSampler::
output_faces(const char* const filename,
	     const vector<Face*>& faces_to_print) const {

  FILE* out_file = fopen(filename, "w");
  if(!out_file) vFatalError("Cannot open output file for writing", 
			    "RefFaceSampler::output_restricted_delaunay"); 
 
  typedef vector<Face*>   FacePrint;
  typedef vector<Vert*>   VertPrint;
  typedef map<Vert*, int> VertIndex;
  
  VertPrint verts_to_print;
  VertIndex vert_indices;
  FacePrint::const_iterator itf, itf_end;
  VertPrint::const_iterator itv, itv_end;

  //Compute the faces intersected by Voronoi edges. Also obtain vertices to print.

  int counter = 1;
   
  itf     = faces_to_print.begin();
  itf_end = faces_to_print.end();

  for( ; itf != itf_end; ++itf) {

    Face* face = *itf;

    for(int i = 0; i < face->iNumVerts(); i++) {

      Vert* vert = face->pVVert(i);

      if( vert_indices.insert( std::make_pair(vert, counter) ).second ) {
	verts_to_print.push_back(vert);
	++counter;
      }

    }

  }
    
  fprintf(out_file, "MeshVersionFormatted 1\n");
  fprintf(out_file, "Dimension 3\n");

  fprintf(out_file, "Vertices\n");
  fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()));

  itv     = verts_to_print.begin();
  itv_end = verts_to_print.end();
  
  for( ; itv != itv_end; ++itv) {

    Vert* vert = *itv;

    fprintf(out_file, "%lf %lf %lf 2\n", 
	    vert->dX(), vert->dY(), vert->dZ());

  }

  itf = faces_to_print.begin();  

  fprintf(out_file, "Triangles\n");
  fprintf(out_file, "%d\n", static_cast<int>(itf_end - itf));

  for( ; itf != itf_end; ++itf) {

    Face* face = *itf;

    fprintf(out_file, "%d %d %d 2\n", 
	    vert_indices.find(face->pVVert(0))->second,
	    vert_indices.find(face->pVVert(1))->second,
	    vert_indices.find(face->pVVert(2))->second);

  }

  fprintf(out_file, "End\n");

  fclose(out_file);

}

////////////

VoronoiEdge::
VoronoiEdge(Face* const face,
	    Cell* const cell1, Cell* const cell2) 
  : m_face( face ) {

  assert( m_face == pFCommonFace(cell1, cell2) );
  voronoi_vert_coord(cell1, m_beg);
  voronoi_vert_coord(cell2, m_end);

}

VoronoiEdge::
VoronoiEdge(Cell* const cell1, Cell* const cell2) 
  : m_face( pFCommonFace(cell1, cell2) ) {

  assert( m_face );
  voronoi_vert_coord(cell1, m_beg);
  voronoi_vert_coord(cell2, m_end);

}

void VoronoiEdge::
voronoi_vert_coord(Cell* const cell, CubitVector& coord) {
    
  double circum_coord[3];

  switch (cell->eType()) {

  case Cell::eTet: {
    TetCell* tet_cell = dynamic_cast<TetCell*>(cell);
    assert(tet_cell);
    tet_cell->vCircumcenter(circum_coord);
    break;
  }
  case Cell::eTriBFace: {
    TriBFace* tri_face = dynamic_cast<TriBFace*>(cell);
    assert(tri_face);
    tri_face->vCircumcenter(circum_coord);
    break;
  }
  default:
    vFatalError("Unexpected cell type\n",
		"VoronoiEdge::VoronoiEdge(const Cell* const, const Cell* const)");
    break;
  } 

  coord.set(circum_coord);

}
