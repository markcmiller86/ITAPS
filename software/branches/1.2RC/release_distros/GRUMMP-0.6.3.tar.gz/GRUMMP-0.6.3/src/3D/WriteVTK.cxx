
#include <stdio.h>
#include "GR_misc.h"
#include "GR_events.h"
#include "GR_VolMesh.h"

//-----------------------------------------------------------------------------
void vWriteVTK_ASCII
(
  VolMesh& OutMesh,
  const char strBaseFileName[]
)
//-----------------------------------------------------------------------------
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  FILE *pFOutFile = NULL;
  char strFileName[1024];
  OutMesh.vPurge();
  if (strcasecmp(strBaseFileName + strlen(strBaseFileName) - 4, ".vtk")) {
    // File name doesn't end in .vtk
    sprintf(strFileName, "%s.vtk", strBaseFileName);
  }
  else {
    // File name ends in .vtk
    sprintf(strFileName, "%s", strBaseFileName);
  }

  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open output file for writing",
                "3d Vtk mesh output");

  int nno = OutMesh.iNumVerts();   // number of nodes

  //-------------------------------------------------------
  // Write the VTK header details
  //-------------------------------------------------------

  fprintf(pFOutFile, "# vtk DataFile Version 2\n");
  fprintf(pFOutFile, "GRUMMP Tetra example\n");
  fprintf(pFOutFile, "ASCII\n");
  fprintf(pFOutFile, "DATASET UNSTRUCTURED_GRID\n");
  fprintf(pFOutFile, "POINTS %d float\n", nno);

  //-------------------------------------
  // write 3d vertex data
  //-------------------------------------
  for (int i=0; i<nno; ++i)
  {
    Vert *pV = OutMesh.pVVert(i);
    fprintf(pFOutFile, "%16.8f %16.8f %16.8f\n", pV->dX(), pV->dY(), pV->dZ());
  }

  // How much topology data is there?
  const int numTris = OutMesh.iNumTriFaces();
  const int numQuads = OutMesh.iNumQuadFaces();
  const int numTets = OutMesh.iNumTetCells();
  const int numPyrs = OutMesh.iNumPyrCells();
  const int numPrisms = OutMesh.iNumPrismCells();
  const int numHexes = OutMesh.iNumHexCells();

  const int numEnts = numTris + numQuads + numTets + numPyrs
    + numPrisms + numHexes;
  const int dataSize = 4*numTris + 5*(numQuads + numTets) + 6*numPyrs
    + 7*numPrisms + 9*numHexes;
  
  fprintf(pFOutFile, "CELLS %d %d\n", numEnts, dataSize);

  int h, globalNodeNum;
  // First all the faces.
  for (int iF=0; iF < numTris + numQuads; iF++) {
    Face *pF = OutMesh.pFFace(iF);
    h  = pF->iNumVerts();
    fprintf(pFOutFile, "%d  ", h);
    for (int idx=0; idx<h; ++idx)
    {
      globalNodeNum = OutMesh.iVertIndex(pF->pVVert(idx));
      fprintf(pFOutFile, " %10d", globalNodeNum);
    }
    fprintf(pFOutFile, "\n");
  }

  // Now all the cells.
  for (int iC=0; iC < numTets + numPyrs + numPrisms + numHexes; iC++) {
    Cell *pC = OutMesh.pCCell(iC);
    h  = pC->iNumVerts();
    fprintf(pFOutFile, "%d  ", h);
    for (int idx=0; idx<h; ++idx)
    {
      globalNodeNum = OutMesh.iVertIndex(pC->pVVert(idx));
      fprintf(pFOutFile, " %10d", globalNodeNum);
    }
    fprintf(pFOutFile, "\n");
  }


  //-------------------------------------
  // write cell type (VTK_TRIANGLE = 5, VTK_QUAD = 9,
  // VTK_TETRA = 10, VTK_HEXAHEDRON = 12, VTK_WEDGE = 13,
  // VTK_PYRAMID = 14)
  //-------------------------------------
  fprintf(pFOutFile, "CELL_TYPES %d\n", numEnts);
  for (int ct = 0; ct < numTris; ++ct) 
    fprintf(pFOutFile, "5\n"); 
  for (int ct = 0; ct < numQuads; ++ct) 
    fprintf(pFOutFile, "9\n"); 
  for (int ct = 0; ct < numTets; ++ct) 
    fprintf(pFOutFile, "10\n"); 
  for (int ct = 0; ct < numPyrs; ++ct) 
    fprintf(pFOutFile, "14\n"); 
  for (int ct = 0; ct < numPrisms; ++ct) 
    fprintf(pFOutFile, "13\n"); 
  for (int ct = 0; ct < numHexes; ++ct) 
    fprintf(pFOutFile, "12\n"); 

  fclose(pFOutFile);
  SUMAA_LOG_EVENT_END(OUTPUT);
}
