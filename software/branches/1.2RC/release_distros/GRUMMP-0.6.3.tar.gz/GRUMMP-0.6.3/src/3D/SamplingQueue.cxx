#include "GR_SamplingQueue.h"
#include "GR_events.h"
#include "GR_Functors.h"
#include "GR_Subseg.h"
#include "GR_SurfaceSampler.h"

#include <algorithm>
#include <map>
#include <queue>
#include <vector>

using std::map;
using std::vector;

bool SubsegSamplingEntry::
entry_deleted() const { return m_bridge->get_parent()->is_deleted(); }

FaceSamplingEntry::
FaceSamplingEntry(EntryType entry_type, RefFace* const ref_face, 
		  Face* const face, const double priority) 
 : SamplingEntry(ref_face, priority), m_entry_type(entry_type), 
   m_face(face), m_cell_left(face->pCCellLeft()), m_cell_right(face->pCCellRight()) {

  assert(m_entry_type != SUBSEG); 
  assert(!m_face->qDeleted());
  assert(!m_cell_left->qDeleted());
  assert(!m_cell_right->qDeleted());

}

bool FaceSamplingEntry::
entry_deleted() const { 

  return ( (m_face->qDeleted() ||
	    m_cell_left->qDeleted() || m_cell_right->qDeleted()) ); 

}

void FaceTopoSamplingEntry::
set_vertex(Vert* const vertex) { 

    m_offending_vert = vertex; 
    assert(m_offending_vert == m_offending_vert_tag->get_vertex()); 

}

bool FaceTopoSamplingEntry::
entry_deleted() const {

  if( m_face == pFInvalidFace || 
      m_cell_left == pCInvalidCell || m_cell_right == pCInvalidCell) return true;

  return ( (m_face->qDeleted() || 
	    m_cell_left->qDeleted() || m_cell_right->qDeleted()) );

}

void SamplingPriorityQueue::
clean_queue() {

    if( empty() ) return;
    assert( std::__is_heap(c.begin(), c.end(), SamplingEntry::QueueOrder()) );

#ifndef NDEBUG
    GR_index_t num_total = size();
#endif

    SamplingEntry* entry;
    EntryVec valid_entries, deleted_entries;
    EntryVec::iterator it = c.begin(), it_end = c.end();

    for( ; it != it_end; ++it) {
      entry = *it;
      if( entry->remove_entry() ) deleted_entries.push_back(entry);
      else                        valid_entries.push_back(entry);
    }

#ifndef NDEBUG
    GR_index_t num_valid   = valid_entries.size(),
      num_deleted = deleted_entries.size();
    assert(num_total = num_valid + num_deleted);
#endif

    c.swap(valid_entries);
    std::make_heap(c.begin(), c.end(), SamplingEntry::QueueOrder());
    assert( std::__is_heap(c.begin(), c.end(), SamplingEntry::QueueOrder()) );

#ifndef NDEBUG
    assert(size() == num_valid);
#endif

    std::for_each( deleted_entries.begin(), deleted_entries.end(),
		   GRUMMP::DeleteObject() );
   
}

void SamplingPriorityQueue::
rebuild_queue(const map<Vert*, Vert*>& vert_map,
	      const map<Face*, Face*>& face_map,
	      const map<Cell*, Cell*>& cell_map) {

  SamplingEntry::EntryType entry_type;
  
  SamplingEntry         *entry;
  FaceSamplingEntry     *face_entry;
  FaceTopoSamplingEntry *face_topo_entry;

  map<Vert*, Vert*>::const_iterator itv;
  map<Face*, Face*>::const_iterator itf;
  map<Cell*, Cell*>::const_iterator itc1, itc2;

  vector<SamplingEntry*>::iterator it = c.begin(), it_end = c.end();

  for( ; it != it_end; ++it) {

    entry = *it;
    entry_type = entry->get_entry_type();

    //nothing to change for a subseg entry
    if(entry_type == SamplingEntry::SUBSEG) continue;
      
    face_entry = dynamic_cast<FaceSamplingEntry*>(entry); assert(face_entry);
    itf  = face_map.find(face_entry->get_face());
    itc1 = cell_map.find(face_entry->get_cell_left());
    itc2 = cell_map.find(face_entry->get_cell_right());

    //update the data in bad topo entries.
    if(entry_type == SamplingEntry::BAD_TOPO) {

      face_topo_entry = dynamic_cast<FaceTopoSamplingEntry*>(face_entry); 
      assert(face_topo_entry);

      itv = vert_map.find(face_topo_entry->get_vertex());
      assert( itv != vert_map.end() );
      face_topo_entry->set_vertex(itv->second);

      if(itf == face_map.end()) face_topo_entry->set_face(pFInvalidFace);
      else                      face_topo_entry->set_face(itf->second);

      if(itc1 == cell_map.end()) face_topo_entry->set_cell_left (pCInvalidCell);
      else                       face_topo_entry->set_cell_left (itc1->second);
      if(itc2 == cell_map.end()) face_topo_entry->set_cell_right(pCInvalidCell);
      else                       face_topo_entry->set_cell_right(itc2->second);

    }

    //update all other face sampling entries
    else {

      assert(itf  != face_map.end());
      face_entry->set_face(itf->second);
      
      assert(itc1 != cell_map.end()); 
      face_entry->set_cell_left(itc1->second);
      assert(itc2 != cell_map.end()); 
      face_entry->set_cell_right(itc2->second);

      assert(!face_entry->entry_deleted());

    }

#ifndef NDEBUG
    if(!face_entry->entry_deleted()) {
      
      assert(face_entry->get_face()->qValid());
      assert(!face_entry->get_face()->qDeleted());
      
      assert(face_entry->get_cell_left()->qValid());
      assert(face_entry->get_cell_right()->qValid());
      assert(!face_entry->get_cell_left()->qDeleted());
      assert(!face_entry->get_cell_right()->qDeleted());

      assert(face_entry->get_cell_left()  == face_entry->get_face()->pCCellLeft());
      assert(face_entry->get_cell_right() == face_entry->get_face()->pCCellRight());

    }
#endif
    
  }

}

SamplingEntry* SamplingQueue::
top_entry() const {

    if(!m_multiple.empty()) return(m_multiple.top());
    if(!m_subseg.empty())   return(m_subseg.top());
    if(!m_bad_topo.empty()) return(m_bad_topo.top());
    if(!m_size.empty())     return(m_size.top());
    if(!m_quality.empty())  return(m_quality.top());

    return static_cast<SamplingEntry*>(NULL);

}

bool SamplingQueue::
pop_top_entry() {

  if(!m_multiple.empty()) {
    if(m_multiple.top()) delete m_multiple.top();
    m_multiple.pop();
    return true;
  }
  if(!m_subseg.empty()) {
    if(m_subseg.top()) delete m_subseg.top();
    m_subseg.pop();
    return true;
  }
  if(!m_bad_topo.empty()) {
    if(m_bad_topo.top()) delete m_bad_topo.top();
    m_bad_topo.pop();
    return true;
  }
  if(!m_size.empty()) {
    if(m_size.top()) delete m_size.top();
    m_size.pop();
    return true;
  }
  if(!m_quality.empty()) {
    if(m_quality.top()) delete m_quality.top();
    m_quality.pop();
    return true;
  }

  return false;
  
}

void SamplingQueue::
add_to_queue(SamplingEntry* const sampling_entry) {
 
  switch(sampling_entry->get_entry_type()) {
    
  case SamplingEntry::MULTIPLE:
    m_multiple.push(sampling_entry);
    break;
  case SamplingEntry::SUBSEG:
    m_subseg.push(sampling_entry);
    break;
  case SamplingEntry::BAD_TOPO:
    m_bad_topo.push(sampling_entry);
    break;
  case SamplingEntry::SIZE:
    m_size.push(sampling_entry);
    break;
  case SamplingEntry::QUALITY:
    m_quality.push(sampling_entry);
    break;
  default:
    vFatalError("Unknown sampling entry type",
		"SamplingQueue::add_to_queue()");
    break;
    
  }

}

void SamplingQueue::
print_queue() {

  SamplingEntry* entry = top_entry();
      
  while(entry) {
    printf("type = %d, priority = %lf, deleted = %d\n",
	   entry->get_entry_type(), entry->get_priority(), entry->entry_deleted());
    pop_top_entry();
    entry = top_entry();
  }

  assert(0);

}
