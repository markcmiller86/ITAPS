#include <cmath>
#include "GR_assert.h"
#include "GR_events.h"
#include "GR_misc.h"
#include "GR_BFace.h"
#include "GR_Geometry.h"
#include "GR_Quality.h"
#include "GR_Sort.h"
#include "GR_TetMeshRefiner.h"
#include "GR_Vec.h"
#include "GR_VolMesh.h"
#include "GR_Watson.h"
#include "GR_WatsonInfo.h"

#include "GR_Vertex.h"
#include "GR_Face.h"
#include "GR_Cell.h"
#include "GR_AdaptPred.h"

#include <set>
#include <map>
#include <queue>
#include <vector>
#include <utility>

using std::queue;
using std::map;
using std::set;
using std::multiset;
using std::vector;

#ifdef IRIX6
#include <values.h>
#endif

//  bool operator==(const SEdgeSort& SA, const SEdgeSort& SB) {
//    return (SA.pV0 == SB.pV0 &&
//	  SA.pV1 == SB.pV1 &&
//	  SA.iF  == SB.iF );
//  }

static FaceSort* aFSEdges = static_cast<FaceSort*> (NULL);
static int iMaxNumEdges = 0;

//  //@@ A function to compare one edge to another, with no ties allowed
//  extern "C" {
//    static int iEdgeComp(const void * pSEdge1, const void * pSEdge2)
//    {
//      struct SEdgeSort {Vert *pV0, *pV1; int iF;};
//      const SEdgeSort *pSE1 = (const SEdgeSort*) pSEdge1;
//      const SEdgeSort *pSE2 = (const SEdgeSort*) pSEdge2;
//      Vert *pVMin1, *pVMax1, *pVMin2, *pVMax2;
//      if (pSE1->pV0 < pSE1->pV1) {
//        pVMin1 = pSE1->pV0;
//        pVMax1 = pSE1->pV1;
//      }
//      else {
//        pVMin1 = pSE1->pV1;
//        pVMax1 = pSE1->pV0;
//      }
//      if (pSE2->pV0 < pSE2->pV1) {
//        pVMin2 = pSE2->pV0;
//        pVMax2 = pSE2->pV1;
//      }
//      else {
//        pVMin2 = pSE2->pV1;
//        pVMax2 = pSE2->pV0;
//      }
//      if ( (pVMin1 < pVMin2) ||
//	 ((pVMin1 == pVMin2) && (pVMax1 < pVMax2)) ||
//	 ((pVMin1 == pVMin2) && (pVMax1 == pVMax2)
//	  && (pSE1->iF < pSE2->iF)) )  return (-1);
//      else return (1);
//    }
//  }

static void vSetUpEdgeList(const std::set<Face*> spFHull)
{
  int iNumHullFaces = spFHull.size();
  // Figure out the connectivity of the hull so that new faces can be
  // built.  This requires making and sorting a list of edges.

  // First make sure there's enough space to store them all; if not,
  // make it so there is.  The last 'new' here leaks memory, but we
  // aren't talking about very much, and it only happens once per
  // invocation of the -program- (not once per subroutine call).  So who
  // cares?
  if (iNumHullFaces*3 > iMaxNumEdges) {
    if (aFSEdges != static_cast<FaceSort*>(NULL))
      delete [] aFSEdges;
    aFSEdges = new FaceSort[iNumHullFaces*3];
    iMaxNumEdges = iNumHullFaces*3;
  }
  int i = 0;
  for (std::set<Face*>::iterator iterF = spFHull.begin();
       iterF != spFHull.end(); iterF++, i++) {
    Face *pF = *iterF;
    aFSEdges[3*i  ] = FaceSort(pF->pVVert(0), pF->pVVert(1), i, pF);
    aFSEdges[3*i+1] = FaceSort(pF->pVVert(1), pF->pVVert(2), i, pF);
    aFSEdges[3*i+2] = FaceSort(pF->pVVert(2), pF->pVVert(0), i, pF);
  }
  sort(aFSEdges, aFSEdges + 3*iNumHullFaces);
}

void
vCheckBdryFragmentForSubsegEncroachment(const std::set<BFace*>& spBF,
					std::set<FaceSort>& sFSEncSubseg,
					const double * const adPoint)
{
  sFSEncSubseg.clear();
  std::set<Face*> spFHull;
  std::set<BFace*>::iterator iterBF;
  for (iterBF = spBF.begin(); iterBF != spBF.end(); iterBF++) {
    if ((*iterBF)->qDeleted()) continue;
    spFHull.insert((*iterBF)->pFFace());
  }
  SUMAA_LOG_EVENT_BEGIN(SHEWCHUK_HULL);
  vSetUpEdgeList(spFHull);
  int iNumHullFaces = spFHull.size();
  SUMAA_LOG_EVENT_END(SHEWCHUK_HULL);

  SUMAA_LOG_EVENT_BEGIN(SHEWCHUK_SUBSEG);
  for (int iEdge = 0; iEdge < 3*iNumHullFaces; iEdge ++) {
    Vert *pV0 = aFSEdges[iEdge].pVVert(0);
    Vert *pV1 = aFSEdges[iEdge].pVVert(1);
    if (!(iEdge == 3*iNumHullFaces - 1) &&
	((aFSEdges[iEdge].pVVert(0) == aFSEdges[iEdge+1].pVVert(0) &&
	  aFSEdges[iEdge].pVVert(1) == aFSEdges[iEdge+1].pVVert(1))
	 ||
	 (aFSEdges[iEdge].pVVert(1) == aFSEdges[iEdge+1].pVVert(0) &&
	  aFSEdges[iEdge].pVVert(0) == aFSEdges[iEdge+1].pVVert(1)))) {
      // Interior edge in bdry fragment
      assert(aFSEdges[iEdge].iLeftCell()  != aFSEdges[iEdge+1].iLeftCell() );
      iEdge++; // Skip over both halves of the pair.
    }
    vMessage(4, "Checking for bdry subseg encroachments between:\n");
    vMessage(4, "  Vert %p (type %d):  (%12.6g, %12.6g, %12.6g)\n",
	     pV0, pV0->iVertType(), pV0->dX(), pV0->dY(),
	     pV0->dZ());
    vMessage(4, "  Vert %p (type %d):  (%12.6g, %12.6g, %12.6g)\n",
	     pV1, pV1->iVertType(), pV1->dX(), pV1->dY(),
	     pV1->dZ());
    vMessage(4, "Checking whether both fall on bdry segments...");
    if ((pV0->iVertType() != Vert::eBdryApex &&
	 pV0->iVertType() != Vert::eBdryCurve)
	||
	(pV1->iVertType() != Vert::eBdryApex &&
	 pV1->iVertType() != Vert::eBdryCurve)
	) {
      // Can't possibly be a bdry subsegment, because one or both verts
      // don't fall on bdry segments.
      vMessage(4, "no.\n");
      continue;
    }
    vMessage(4, "yes.\n");

    // Now check to see if this really is a bdry subsegment.
    // For now, take the easiest possible way out, by finding out
    // everything about the neighborhood of pV0, and then determining
    // which BFace's also contain pV1.  If there are more than two such
    // BFace's, then pV0-pV1 is the intersection of more than two
    // BdryPatch's.  If there are precisely two, then the critical
    // question is whether the BFace's lie on the same patch.
    std::set<Cell*> spCInc;
    {
      vMessage(4, "  Checking whether this is really a bdry subseg...");
      std::set<Vert*> spVNeigh;
      std::set<BFace*> spBFInc;
      bool qBdryVert;
      vNeighborhood(pV0, spCInc, spVNeigh, &spBFInc, &qBdryVert);
      assert(qBdryVert);
      std::set<BFace*> spBFCommon;
      for (iterBF = spBFInc.begin(); iterBF != spBFInc.end(); iterBF++) {
	BFace *pBF = *iterBF;
	assert(pBF->qHasVert(pV0));
	if (pBF->qHasVert(pV1))
	  spBFCommon.insert(pBF);
      }
      switch (spBFCommon.size()) {
      case 0:
	// No common BFaces; connected across the interior of the mesh.
	vMessage(4, "not even on the bdry.\n");
	continue;
      case 1:
	// Should never happen.
	vFatalError("Exactly one common bdry face between two points?!?",
		    "bdry subseg encroachment check during insertion");
	break;
      case 2:
	// Are the two BFace's on the same or different BdryPatch's?
	{
	  std::set<BFace*>::iterator iter = spBFCommon.begin();
	  BFace *pBF0 = *iter;
	  iter++;
	  BFace *pBF1 = *iter;
	  assert(pBF0->eType() == Cell::eTriBFace ||
		 pBF0->eType() == Cell::eIntTriBFace);
	  assert(pBF1->eType() == Cell::eTriBFace ||
		 pBF1->eType() == Cell::eIntTriBFace);
	  BdryPatch* pPatch0 = pBF0->pPatchPointer();
	  BdryPatch* pPatch1 = pBF1->pPatchPointer();
	  if (pPatch0 == pPatch1) {
	    vMessage(4, "no.\n");
	    continue;
	  }
	}
	// Deliberate fallthrough, because this and all subsequent cases
	// add an encroached subseg to the list.
      default:
	vMessage(4, "yes (%zd common BFace's)\n", spBFCommon.size());
      } // Done with switch over # of common BFace's
    } // Done checking whether it's really a bdry subseg

    double dRadius = 0.5 * dDIST3D(pV0->adCoords(), pV1->adCoords());
    double adMid[] = {0.5 * (pV0->dX() + pV1->dX()),
		      0.5 * (pV0->dY() + pV1->dY()),
		      0.5 * (pV0->dZ() + pV1->dZ())};
    if (adPoint) {
      // Check to see whether this particular point encroaches on the
      // subsegment.
      vMessage(4, "  Checking whether the edge is encroached...");
      double dDistance = dDIST3D(adMid, adPoint);
      if (iFuzzyComp(dDistance, dRadius) == -1) {
	vMessage(4, "yes.\n");
	sFSEncSubseg.insert(aFSEdges[iEdge]);
	vMessage(4, "  Added to encroached subseg list\n");
	break;
      } // Done checking this neighboring vert
    } // Done checking for encroachment when a location is given
    else {
      // Check to see if the segment pV0-pV1 is really encroached by
      // some point in one of the tets incident on each when no point is given
      vMessage(4, "  Checking whether the edge is encroached...");
      // First, make a list of all the verts in all the tets incident on
      // both pV0 and pV1.
      std::set<Vert*> spVCommonNeigh;
      std::set<Cell*>::iterator iterC;
      for (iterC = spCInc.begin(); iterC != spCInc.end(); iterC++) {
	Cell *pC = *iterC;
	assert(pC->qHasVert(pV0));
	if (pC->qHasVert(pV1)) {
	  spVCommonNeigh.insert(pC->pVVert(0));
	  spVCommonNeigh.insert(pC->pVVert(1));
	  spVCommonNeigh.insert(pC->pVVert(2));
	  spVCommonNeigh.insert(pC->pVVert(3));
	}
      }
      spVCommonNeigh.erase(pV0);
      spVCommonNeigh.erase(pV1);

      for (std::set<Vert*>::iterator iterV = spVCommonNeigh.begin();
	   iterV != spVCommonNeigh.end(); iterV++) {
	Vert *pV = *iterV;
	double dDistance = dDIST3D(adMid, pV->adCoords());
	if (iFuzzyComp(dDistance, dRadius) == -1) {
	  vMessage(4, "yes.\n");
	  sFSEncSubseg.insert(aFSEdges[iEdge]);
	  vMessage(4, "  Added to encroached subseg list\n");
	  break;
	} // Done checking this neighboring vert
      } // Done with loop over common neighbors
    } // Done checking for actual encroachment
  } // Done looping over all edges in the hull
  SUMAA_LOG_EVENT_END(SHEWCHUK_SUBSEG);
}


//  bool qInsertInThisTet(Cell* const pC)
//  {
//    SUMAA_LOG_EVENT_BEGIN(STEINER_CELL_QUAL);
//    assert(pC->iFullCheck());
//    assert(pC->eType() == Cell::eTet);

//    if (!pC->qWellSized()) {
//      double dLengthScale = 0.25 * (+ pC->pVVert(0)->dLS()
//				  + pC->pVVert(1)->dLS()
//				  + pC->pVVert(2)->dLS()
//				  + pC->pVVert(3)->dLS());
//      double dDiam = 2 * ((TetCell*)pC)->dCircumradius();

//      if (dDiam > dLengthScale) {
//        SUMAA_LOG_EVENT_END(STEINER_CELL_QUAL);
//        return true;
//      }

//      pC->vMarkWellSized();
//    }

//    if (pC->iShapeClass() != Cell::eWellShaped) {
//      int i;
//      double adQual[1];
//      vShortestToRadius(pC, &i, adQual);
//      if (adQual[0] < 0.5) {
//        SUMAA_LOG_EVENT_END(STEINER_CELL_QUAL);
//        return true;
//      }
//      else {
//        pC->vSetShapeClass(Cell::eWellShaped);
//        SUMAA_LOG_EVENT_END(STEINER_CELL_QUAL);
//        return false;
//      }
//    }
//    return false;
//  }

static void vBuildHull(const std::set<Cell*>& spC,
		       std::set<Face*>& spFInterior,
		       std::set<Face*>& spFHull)
{
  spFInterior.clear();
  spFHull.clear();
  std::multiset<Face*> mspFTemp;
  for (std::set<Cell*>::iterator iterC = spC.begin();
       iterC != spC.end(); iterC++) {
    Cell* pC = *iterC;
    for (int iF = 0; iF < 4; iF ++)
      mspFTemp.insert(pC->pFFace(iF));
  }

  for (std::multiset<Face*>::iterator iterF = mspFTemp.begin();
       iterF != mspFTemp.end(); iterF++) {
    Face *pFTmp = *iterF;
    int iCount = mspFTemp.count(pFTmp);
    assert(iCount == 1 || iCount == 2);
    if (iCount == 1) spFHull.insert(pFTmp);
    else             spFInterior.insert(pFTmp);
  }
}


void VolMesh::vGetWatsonData(const double adPoint[3],
			     Cell* const pCSeed,
			     std::set<Cell*>& spCSearch,
			     std::set<Face*>& spFHull,
			     std::set<Face*>& spFToRemove,
			     std::set<BFace*>& spBFEncroached) const
{
  static int iHullsChecked = 0, iTotalHullSize = 0;
  SUMAA_LOG_EVENT_BEGIN(WATSON_NEIGHBORS);
  Vert VDummy;
  VDummy.vSetCoords(3, adPoint);

  spCSearch.clear();
  spFHull.clear();
  spFToRemove.clear();
  // Don't clear LpBFEncroached, as the first entry is set elsewhere and
  // has meaning.  The others may not need to be zeroed either, but this
  // does no harm.

  // This assertion is always true in principle, although some
  // particularly bizarrely-shaped tets cause problems in practice, even
  // if VDummy is at an edge midside.
//    assert(iInsphere(pCSeed->pVVert(0), pCSeed->pVVert(1), pCSeed->pVVert(2),
//		   pCSeed->pVVert(3), &VDummy) == 1);

  // **** Find Watson neighborhood ****
  // Set initial cell search list
  std::queue<Cell*> qpC;
  spCSearch.insert(pCSeed);
  qpC.push(pCSeed);
  int iF;
  for (iF = 0; iF < 4; iF++) {
    Face *pF = pCSeed->pFFace(iF);
    spCSearch.insert(pF->pCCellOpposite(pCSeed));
    qpC.push(pF->pCCellOpposite(pCSeed));
  }

  // Until all cells have been checked...
  while (!qpC.empty()) {
    Cell *pCCand = qpC.front();
    qpC.pop();
    if (pCCand->eType() == Cell::eTet) {
      // For tets:
      if (iInsphere(pCCand->pVVert(0), pCCand->pVVert(1),
		    pCCand->pVVert(2), pCCand->pVVert(3), &VDummy)
	  != -1) {
	// If new point is in circumsphere, add neighbors to search list
	for (iF = 0; iF < 4; iF++) {
	  Face *pF = pCCand->pFFace(iF);
	  Cell *pCTmp = pF->pCCellOpposite(pCCand);
	  if (spCSearch.count(pCTmp) == 0) {
	    spCSearch.insert(pCTmp);
	    qpC.push(pCTmp);
	  }
	}
      }
      // Else delete this cell from search list
      else {
	spCSearch.erase(pCCand);
      }
    }
    else {
      assert(pCCand->eType() == Cell::eTriBFace ||
	     pCCand->eType() == Cell::eIntTriBFace);
      TriBFaceBase* pTBFCand = dynamic_cast<TriBFaceBase*> (pCCand);
      // For bdry faces:
      // If new point encroaches, add bface to encroached list.  In this
      // case, we need to tag the BFace as encroached in case of ties.
      if (pTBFCand->eIsPointEncroaching(adPoint, eEncroachmentType(), true)
	  != eClean) {
	spBFEncroached.insert(pTBFCand);
      }
      // Delete bface from search list
      spCSearch.erase(pTBFCand);
      // Add the cells adjacent to the BFace on each side, if this is an
      // internal BFace.
      if (pTBFCand->eType() == Cell::eIntTriBFace &&
	  !pTBFCand->pPatchPointer()->qDisjointFrom(&VDummy)) {
	Cell *pCTmp = pTBFCand->pFFace(0)->pCCellOpposite(pCCand);
	if (spCSearch.count(pCTmp) == 0) {
	  spCSearch.insert(pCTmp);
	  qpC.push(pCTmp);
	}
	pCTmp = pTBFCand->pFFace(1)->pCCellOpposite(pCCand);
	if (spCSearch.count(pCTmp) == 0) {
	  spCSearch.insert(pCTmp);
	  qpC.push(pCTmp);
	}
      }
    } // Done with BFace case...
  }

  // Ensure that there will be no offset insertion when multiple BFaces
  // are encroached, as this can lead to odd exterior insertion cases.
  switch (spBFEncroached.size()) {
  case 0:
    break;
  case 1:
    {
      BFace *pBFCand = *(spBFEncroached.begin());
      if (pBFCand->eType() == Cell::eTriBFace &&
	  pBFCand->qOffsetInsertionRequested()) {
	// For this case, make certain that there won't be insertion in
	// the wrong region, as this will create inverted cells and other
	// disasters.  The "wrongness" test makes sure the new point and
	// the centroid of the cell that started it all are on the same
	// side of an internal bdry edge.
	double adCent[3];
	pCSeed->vCentroid(adCent);
	if (iOrient3D(pBFCand->pVVert(0)->adCoords(),
		      pBFCand->pVVert(1)->adCoords(),
		      pBFCand->pVVert(2)->adCoords(), adCent) !=
	    iOrient3D(pBFCand->pVVert(0)->adCoords(),
		      pBFCand->pVVert(1)->adCoords(),
		      pBFCand->pVVert(2)->adCoords(), adPoint)) {
	  // Rig things so that this internal bdry face will be split.
	  double adTmp[3];
	  (dynamic_cast<TriBFaceBase*>(pBFCand))->vCircumcenter(adTmp);
	  pBFCand->vSetInsertionLocation(adTmp);
	  pBFCand->vForbidOffsetInsertion();
	}
      }
    }
    break;
  default:
    for (std::set<BFace*>::iterator iterBF = spBFEncroached.begin();
	 iterBF != spBFEncroached.end(); iterBF++) {
      (*iterBF)->vForbidOffsetInsertion();
    }
    break;
  }

  vBuildHull(spCSearch, spFToRemove, spFHull);

  vMessage(4, "Watson: Done sorting faces into hull and interior.\n");

  vMessage(4, "Watson: # cells to delete: %zd\n", spCSearch.size());
  vMessage(4, "Watson: # faces to delete: %zd\n", spFToRemove.size());
  vMessage(4, "Watson: # faces in hull: %zd\n", spFHull.size());
  iTotalHullSize += spCSearch.size();
  iHullsChecked ++;
  vMessage(3, "Watson: Total cells deleted: %5d in %5d tries.\n",
	   iTotalHullSize, iHullsChecked);
  assert(4*spCSearch.size() - 2*spFToRemove.size() ==
	 spFHull.size());
  SUMAA_LOG_EVENT_END(WATSON_NEIGHBORS);
}

void VolMesh::vCleanupWatson(WatsonInfo &WI)
  // This is a member function so that a polymorphic call in
  // InsertionQueue::vQualityRefine() will work properly.
{
  Vert VDummy;
  VDummy.vSetCoords(3, WI.adCoords());

  std::set<Cell*>::iterator iterC;
  std::set<Face*>::iterator iterF;
  std::set<BFace*>::iterator iterBF;
    
#ifndef NDEBUG
  for (iterC = WI.spCToRemove.begin(); iterC != WI.spCToRemove.end();
       iterC++) {
    Cell *pC = *iterC;
    assert(iInsphere(pC->pVVert(0), pC->pVVert(1), pC->pVVert(2),
		     pC->pVVert(3), &VDummy) != -1);
  }
  for (iterBF = WI.spBFEncroached.begin(); iterBF != WI.spBFEncroached.end();
       iterBF++) {
    BFace *pBF = *iterBF;
    assert(pBF->eIsPointEncroaching(WI.adCoords(), eEncroachmentType(), true)
	   != eClean);
  }
#endif

  bool qChanged, qRecomputeHull = false;
  do {
    qChanged = false;

    // Are there any faces in the hull that are coplanar with the new
    // vertex?  If there are, they necessarily fall into one of two
    // categories: boundary faces and interior faces.

    // For boundary coplanar hull faces, there are two subcases: faces
    // on patches containing the new vertex, and faces not on patches
    // containing the new vertex.  In the former case, all is well:
    // these boundary faces will be removed from the mesh and new
    // boundary faces substituted.  In the latter case, these boundary
    // faces are separated from the new vertex by a bdry curve, so there
    // is no encroachment on the BFace by this vert (nor on the cell
    // built on the BFace).  So each such must be -DELETED- from the
    // list of BFaces to remove, and the cells opposite them must be
    // -DELETED- from the list of Cells to remove.

    // Also, in some circumstances the angle at the bdry curve can be
    // reflex --- this totally precludes attaching to those BFace's, so
    // the same action should be taken.

    for (iterBF = WI.spBFEncroached.begin(); iterBF != WI.spBFEncroached.end();
	 iterBF++) {
      BFace *pBF = *iterBF;
      // This test is probably wrong for internal boundary faces.
      if (iOrient3D(pBF->pVVert(0), pBF->pVVert(1), pBF->pVVert(2),
		    &VDummy) != 1 &&
	  pBF->pPatchPointer()->qDisjointFrom(&VDummy)) {
	// This is the bad case...
	vMessage(4, "Found a coplanar or reflex BFace in a disjoint patch... removing\n");
	Face *pF = pBF->pFFace();
	Cell *pC = pF->pCCellOpposite(pBF);
	WI.spBFEncroached.erase(pBF);
	WI.spCToRemove.erase(pC);
	qChanged = true;
      }
    }

    // Now remove any "orphaned" BFaces from the encroached list.  Any
    // BFace that is connected to a cell that no longer is slated for
    // removal must be removed from the encroached list, since
    // constraints don't allow us to fix this encroachment.
    for (iterBF = WI.spBFEncroached.begin(); iterBF != WI.spBFEncroached.end();
	 iterBF++) {
      BFace *pBF = *iterBF;
      if (pBF->eType() == Cell::eTriBFace) {
	Face *pF = pBF->pFFace();
	Cell *pC = pF->pCCellOpposite(pBF);
	if (WI.spCToRemove.count(pC) == 0) {
	  WI.spBFEncroached.erase(pBF);
	  qChanged = true;
	}
      }
      else {
	Cell *pC0 = pBF->pFFace(0)->pCCellOpposite(pBF);
	Cell *pC1 = pBF->pFFace(1)->pCCellOpposite(pBF);
	if (WI.spCToRemove.count(pC0) == 0 &&
	    WI.spCToRemove.count(pC1) == 0) {
	  WI.spBFEncroached.erase(pBF);
	  qChanged = true;
	}
      }
    }

    // Now find all the faces that bound the set of tets to be removed,
    // and the faces that are shared by two tets that will be removed.
    // The former will have new tets build on them; the latter will be
    // removed from the mesh.
    if (qChanged || qRecomputeHull) vBuildHull(WI.spCToRemove,
					       WI.spFToRemove, WI.spFHull);

    // After deleting cells adjacent to flat/reflex BFaces (above),
    // there may be orphaned cells, which are still tagged for removal
    // but which have non-removable cells between them and the new
    // vertex.  These will show up as badly-oriented faces in the hull
    // and must be cleaned up; this is accomplished by tagging the
    // adjacent cells to -not- be removed from the mesh and re-building
    // the hull.
    for (iterF = WI.spFHull.begin(); iterF != WI.spFHull.end(); iterF++) {
      Face *pF = *iterF;
      Cell *pCL = pF->pCCellLeft();
      if (pF->qIsBdryFace()) {
	// We shouldn't mess with encroached bdry faces, but we do need
	// to check non-encroached bdry faces.
	BFace *pBF;
	if (pCL->eType() != Cell::eTet) {
	  pBF = dynamic_cast<BFace*>(pCL);
	}
	else {
	  pBF = dynamic_cast<BFace*>(pF->pCCellRight());
	}
	if (WI.spBFEncroached.count(pBF) == 1)
	  continue;
      }
      int iOrient = iOrient3D(pF->pVVert(0), pF->pVVert(1),
			      pF->pVVert(2), &VDummy);
      bool qLeftCellInList = (WI.spCToRemove.count(pCL) != 0);
      if (qLeftCellInList) iOrient *= -1;
      // Now orientation should be 1 for proper hull faces, unless those
      // faces are on the boundary and will be coplanar.
      if (iOrient != 1) {
	// Must be sure to remove the offending cell from the removal
	// list.  Any cells that are now offensive as a result of this
	// will be taken care of on a subsequent pass.
	vMessage(4, "Found a mis-oriented Face in insertion hull... fixing\n");
	qChanged = qRecomputeHull = true;
	if (qLeftCellInList)
	  WI.spCToRemove.erase(pCL);
	else
	  WI.spCToRemove.erase(pF->pCCellRight());
      }
    }
  } while (qChanged);

  vMessage(4, "Watson cleanup: Done sorting faces into hull and interior.\n");
  vMessage(4, "Watson cleanup: # cells to delete: %zd\n", WI.spCToRemove.size());
  vMessage(4, "Watson cleanup: # faces to delete: %zd\n", WI.spFToRemove.size());
  vMessage(4, "Watson cleanup: # faces in hull: %zd\n", WI.spFHull.size());
  assert(4*WI.spCToRemove.size() - 2*WI.spFToRemove.size() ==
	 WI.spFHull.size());
}

void WatsonInfo::vStrip3DHull()
{
  assert(eType() == InsertionQueueEntry::eSubSeg);

  // Retain only cells and bdry faces that contain both of the verts in
  // the subseg.
  for (std::set<Cell*>::iterator iterC = spCToRemove.begin();
       iterC != spCToRemove.end(); ) {
    Cell *pC = *iterC;
    if (pC->qHasVert(IQE.pVVert(0)) && pC->qHasVert(IQE.pVVert(1))) {
      iterC++;
    }
    else {
      std::set<Cell*>::iterator iterTmp = iterC++;
      spCToRemove.erase(iterTmp);
    }
  }

  for (std::set<BFace*>::iterator iterBF = spBFEncroached.begin();
       iterBF != spBFEncroached.end(); ) {
    BFace* pBF = *iterBF;
    if (pBF->qHasVert(IQE.pVVert(0)) && pBF->qHasVert(IQE.pVVert(1))) {
      iterBF++;
    }
    else {
      std::set<BFace*>::iterator iterTmp = iterBF++;
      spBFEncroached.erase(iterTmp);
    }
  }

  vBuildHull(spCToRemove, spFToRemove, spFHull);

  vMessage(4, "Watson Strip3D: Done sorting faces into hull and interior.\n");
  vMessage(4, "Watson Strip3D: # cells to delete: %zd\n", spCToRemove.size());
  vMessage(4, "Watson Strip3D: # faces to delete: %zd\n", spFToRemove.size());
  vMessage(4, "Watson Strip3D: # faces in hull: %zd\n", spFHull.size());
  assert(4*spCToRemove.size() - 2*spFToRemove.size() ==
	 spFHull.size());
}

bool WatsonInfo::qIs3DHullOkay(const enum eEncroachType eET) const
{
  Vert VDummy;
  VDummy.vSetCoords(3, adCoords());

  std::set<Cell*>::iterator iterC;
  std::set<Face*>::iterator iterF;
  std::set<BFace*>::iterator iterBF;
    
#ifndef NDEBUG
  for (iterC = spCToRemove.begin(); iterC != spCToRemove.end();
       iterC++) {
    Cell *pC = *iterC;
    assert(iInsphere(pC->pVVert(0), pC->pVVert(1), pC->pVVert(2),
		     pC->pVVert(3), &VDummy) != -1);
  }
  for (iterBF = spBFEncroached.begin(); iterBF != spBFEncroached.end();
       iterBF++) {
    BFace *pBF = *iterBF;
    assert(pBF->eIsPointEncroaching(adCoords(), eET, true)
	   != eClean);
  }
#endif

  // Are there any faces in the hull that are coplanar with the new
  // vertex?  If there are, they necessarily fall into one of two
  // categories: boundary faces and interior faces.

  // For boundary coplanar hull faces, there are two subcases: faces
  // on patches containing the new vertex, and faces not on patches
  // containing the new vertex.  In the former case, all is well:
  // these boundary faces will be removed from the mesh and new
  // boundary faces substituted.  In the latter case, these boundary
  // faces are separated from the new vertex by a bdry curve, which can
  // cause serious insertion problems.

  // Also, in some circumstances the angle at the bdry curve can be
  // reflex --- this totally precludes attaching to those BFace's, so
  // the same action should be taken.

  for (iterBF = spBFEncroached.begin(); iterBF != spBFEncroached.end();
       iterBF++) {
    BFace *pBF = *iterBF;
    // This test is probably wrong for internal boundary faces.
    if (iOrient3D(pBF->pVVert(0), pBF->pVVert(1), pBF->pVVert(2),
		  &VDummy) != 1 &&
	pBF->pPatchPointer()->qDisjointFrom(&VDummy)) {
      // This is the bad case...
      vMessage(4, "Found a coplanar or reflex BFace in a disjoint patch...\n");
      return false;
    }
  }

  // Now remove any "orphaned" BFaces from the encroached list.  Any
  // BFace that is connected to a cell that no longer is slated for
  // removal must be removed from the encroached list, since
  // constraints don't allow us to fix this encroachment.
  for (iterBF = spBFEncroached.begin(); iterBF != spBFEncroached.end();
       iterBF++) {
    BFace *pBF = *iterBF;
    if (pBF->eType() == Cell::eTriBFace) {
      Cell *pC = pBF->pFFace()->pCCellOpposite(pBF);
      if (spCToRemove.count(pC) == 0) {
	return false;
      }
    }
    else {
      assert(pBF->eType() == Cell::eIntTriBFace);
      Cell *pC0 = pBF->pFFace(0)->pCCellOpposite(pBF);
      Cell *pC1 = pBF->pFFace(1)->pCCellOpposite(pBF);
      if (spCToRemove.count(pC0) == 0 &&
	  spCToRemove.count(pC1) == 0) {
	return false;
      }
    }
  } // Done checking BFace's

  // Are there any badly-oriented faces in the hull?  If so, bail out.
  
  for (iterF = spFHull.begin(); iterF != spFHull.end();
       iterF++) {
    Face *pF = *iterF;
    Cell *pCL = pF->pCCellLeft();
    if (pF->qIsBdryFace()) {
      // We shouldn't mess with encroached bdry faces, but we do need
      // to check non-encroached bdry faces.
      BFace *pBF;
      if (pCL->eType() != Cell::eTet) {
	pBF = dynamic_cast<BFace*>(pCL);
      }
      else {
	pBF = dynamic_cast<BFace*>(pF->pCCellRight());
      }
      if (spBFEncroached.count(pBF) != 0)
	continue;
    }
    int iOrient = iOrient3D(pF->pVVert(0), pF->pVVert(1),
			    pF->pVVert(2), &VDummy);
    bool qLeftCellInList = (spCToRemove.count(pCL) != 0);
    if (qLeftCellInList) iOrient *= -1;
    // Now orientation should be 1 for proper hull faces, unless those
    // faces are on the boundary and will be coplanar.
    if (iOrient != 1) {
      // Must be sure to remove the offending cell from the removal
      // list.  Any cells that are now offensive as a result of this
      // will be taken care of on a subsequent pass.
      vMessage(4, "Found a mis-oriented Face in insertion hull...\n");
      return false;
    }
  }

  return true;
}

bool VolMesh::
qDeleteInteriorPointsInBall(const Cell *pCBdry, const double adLoc[],
			    const double dRadius, int& iNDeleted)
{
  // Delete all the points that are located inside the given
  // ball. pBFBdry is a BFace that contains or is very close to adLoc,
  // so it can be used as a starting point.

  // Here is the idea:
  // 1) Find the cell on the other side of the face, put it in the list of
  //    cells to check.
  // 2) Get all the neighbor cells too, put them in the list.
  // 3) Go through the list. Check the verts. Mark the ones to be
  //    deleted as we go. Put the ones outside the diametral circle in
  //    another list.
  // 4) If a vertex is inside the diametral circle (to be deleted), the
  //    cells next to the cell who owned the vertex have to be put in
  //    the list too.
  // 5) Stops when there are no more cells to check.
  // 6) Delete all the vertex that were marked for deletion.
  // 7) Done.

  iNDeleted = 0;

  assert(pCBdry->eType() == Cell::eTriBFace ||
	 pCBdry->eType() == Cell::eIntTriBFace);
  const Face *pF = pCBdry->pFFace(0);

  std::set<Cell*> spCCheck;
  std::set<Vert*> spVDelete;
  std::set<const Vert*> spVOk;

  int i, j, k; // counters

  Cell *pCOpp, *pCOther, *pCCheck; // Cell pointers
  Vert *pVCheck;

  const Vert *pV0 = pF->pVVert(0); // The face endpoints -- never put them
  const Vert *pV1 = pF->pVVert(1); // in the list
  const Vert *pV2 = pF->pVVert(2);

  double adTestPt[3]; // Used to calculate

  // These are not considered part of the diametral circle
  spVOk.insert(pV0);
  spVOk.insert(pV1);
  spVOk.insert(pV2);

  pCOpp = pF->pCCellOpposite(pCBdry);

  // Add the first cells to check to the list
  spCCheck.insert(pCOpp);

  // Add its neighbors too...
  for (i = 0; i < 4; i++) {
    Face *pFCell = pCOpp->pFFace(i);
    if (pFCell != pF) {
      pCOther = pFCell->pCCellOpposite(pCOpp);
      // Add to list if it's not a boundary face
      if (pCOther->eType() == Cell::eTet) {
	spCCheck.insert(pCOther);
      }
    }
  }

  // spVOk contains three items: pV0, pV1, and pV2.
  // spVDelete is still empty
  assert(spVOk.size() == 3);
  assert(spVDelete.size() == 0);

  // Now go through the list of cells, and check the verts..
  for (std::set<Cell*>::iterator iterC = spCCheck.begin();
       iterC != spCCheck.end(); iterC++) {
    // Get the cell
    pCCheck = *iterC;
    // Check the four verts
    for (j = 0; j < 4; j++) {
      // Get the vert
      pVCheck = pCCheck->pVVert(j);
      if ( (pVCheck->iVertType() == Vert::eInterior) &&
	   (spVDelete.count(pVCheck) == 0) &&
	   (spVOk.count(pVCheck) == 0) ) {
	// If the vert has not been checked yet..
	adTestPt[0] = pVCheck->dX();
	adTestPt[1] = pVCheck->dY();
	adTestPt[2] = pVCheck->dZ();
	if ( iFuzzyComp(dDIST3D(adTestPt, adLoc), dRadius) < 0 ) {
	  // The point is inside the diametral circle.
	  // 1) add the vert to the delete list
	  // 2) add the cell's neighbors to the list of cells..
	  spVDelete.insert(pVCheck);
	  for (k = 0; k < 4; k++) {
	    Face *pFCell = pCCheck->pFFace(k);
	    pCOpp = pFCell->pCCellOpposite(pCCheck);
	    if (pCOpp->eType() == Cell::eTet) {
	      spCCheck.insert(pCOpp);
	    }
	  } // Loop over all the faces of the cell
	} // inside diametral circle
	else {
	  // Vert is outside. Add it to the "OK" list
	  spVOk.insert(pVCheck);
	} // if it's inside the diametral circle
      } // if the vert has not been checked yet
    } // loop over the four verts of a cell
  } // loop over the list of cells

  // Now delete all the verts that are in the list of verts to be deleted
  bool qSuccess = true;
  if (spVDelete.size() > 0) {
    vMessage(3, "Have %zd verts to delete\n", spVDelete.size());
    for (std::set<Vert*>::iterator iterV = spVDelete.begin();
	 iterV != spVDelete.end(); iterV++) {
      // Get the vert
      pVCheck = *iterV;
      // Make sure we can delete it
      assert(pVCheck->iVertType() == Vert::eInterior);
      // Delete it
      int iNSwaps;
      qSuccess = qRemoveVert(pVCheck, iNSwaps);
      iNDeleted ++;
    }
  } // there are verts to delete
  return qSuccess;
}

//A different interface to compute Watson data for insertion.
//This function uses Shewchuk's adaptive predicates. It does
//not attempt to call the function to "correct" erronous
//in-sphere test results.

void VolMesh::
compute_watson_data(const Vert* const vertex,
		    const Cell* const seed_cell,
		    WatsonData& watson_data,
		    const bool test_bdry_for_encroachment,
		    const bool exit_on_encroached_bdry) const {

#ifndef NDEBUG
  
  if(exit_on_encroached_bdry) {

    assert(test_bdry_for_encroachment);
    assert(seed_cell->eType() == Cell::eTet); //For now...

  }

  //Making sure point is inside seed_cell's circumcircle

  if(seed_cell->eType() == Cell::eTet) { 

    assert( iInsphere(seed_cell->pVVert(0)->adCoords(), 
		      seed_cell->pVVert(1)->adCoords(), 
		      seed_cell->pVVert(2)->adCoords(), 
		      seed_cell->pVVert(3)->adCoords(),
		      vertex->adCoords()) == 1 );  
  }

  else { assert(0); } //For now...

#endif

  SUMAA_LOG_EVENT_BEGIN(WATSON_INFO);

  //Making sure Watson data containers are empty.

  watson_data.hull_faces.clear();
  watson_data.faces_to_remove.clear();
  watson_data.cells_to_remove.clear();
  watson_data.encroached_bfaces.clear();

  //Declaring some of the variables

  const Cell *cell;
  const Face *face, *next_face;

  int i = 0;

  set<const Cell*> cells_tested, cells_to_delete;
  multiset<const Face*> all_faces; //will contain the 4 faces of every cells_to_delete. 
  queue<const Cell*> cells_to_test;

  //Initializing the containers with data from seed_cell. Queue is initialized
  //differently depending on seed_cell's type.

  if(seed_cell->eType() == Cell::eTet)
    cells_to_test.push(seed_cell);
 
  else {

    assert( seed_cell->eType() == Cell::eTriBFace ||
	    seed_cell->eType() == Cell::eIntTriBFace );

    assert(0); //will implement later.

  }

  //The method performs a march from seed_cell, 
  //which must contain new_vert in its circumcenter.
  //Marching out from seed_cell, it finds all the cells
  //having vertex in its circumcenter and boundary faces
  //encroached by vertex

  do {

    cell = cells_to_test.front();
    cells_to_test.pop();

    if( !cells_tested.insert(cell).second ) continue;

    if( cell->eType() != Cell::eTet )  {

      if(test_bdry_for_encroachment) {
	
	//implement encroachment test here.
	assert(0); //for now.

      }

      continue;

    }

    assert( cell->eType() == Cell::eTet );
  
    //Performing insphere test here. If positive, then 
    //the tet will be deleted during Watson insertion.

    if( iInsphere(cell->pVVert(0)->adCoords(), 
		  cell->pVVert(1)->adCoords(), 
		  cell->pVVert(2)->adCoords(), 
		  cell->pVVert(3)->adCoords(),
		  vertex->adCoords()) >= 0 ) {

      watson_data.cells_to_remove.insert( const_cast<Cell*>(cell) );

      for(i = 0; i < 4; i++) {

	face = cell->pFFace(i);

	all_faces.insert(face);
	cells_to_test.push(face->pCCellOpposite(cell));

      }

    }
    
  } while(!cells_to_test.empty());

  assert(!watson_data.cells_to_remove.empty());
  assert(!all_faces.empty());

  //The following looks awful, but does a simple job.
  //It iterates through all_faces. Split the set into 
  //two sets: faces_of_hull, faces_to_delete based on 
  //the following rule:

  //- The entries of faces_of_hull   have one entry   in all_faces.
  //- The entries of faces_to_delete have two entries in all_faces. 

  //Tried implementing using algorithms but could not find a way to
  //match the performance of the following code.

  std::multiset<const Face*>::iterator it     = all_faces.begin(), 
                                       it_end = all_faces.end();

  next_face = *it;
  
  do {
        
    face = next_face;

    if(++it == it_end) { 
      watson_data.hull_faces.insert( watson_data.hull_faces.end(), 
				     const_cast<Face*>(face) );
      break;
    }
    else { 
      next_face = *it;
    }

    if( face == next_face ) {
      watson_data.faces_to_remove.insert( watson_data.faces_to_remove.end(), 
					  const_cast<Face*>(face) );
      next_face = *(++it);
    }
    else {
      watson_data.hull_faces.insert( watson_data.hull_faces.end(), 
				     const_cast<Face*>(face) );
      continue;
    }    

  } while(it != it_end);

  SUMAA_LOG_EVENT_END(WATSON_INFO);

}



//@ Generic interface to point insertion via Watson's method.  A virtual
//  function in the Mesh class.
int VolMesh::iInsertPointWatson(WatsonInfo& WI)
{
  assert(qSimplicial());

  Vert *pVNew;
  int iCellsBefore = iNumCells();
  int iBFacesBefore = iNumBdryFaces();
  int iIntBFacesBefore = iNumIntBdryFaces();

  assert(WI.vecpCNew.empty());
  assert(WI.vecpBFNew.empty());

  switch (WI.eType()) {
  case InsertionQueueEntry::eTetCell:
    {
      assert(WI.qIs3DHullOkay(eEncroachmentType()));
      pVNew = createVert(WI.adCoords());

      vInsertWatsonInterior(pVNew, WI.spCToRemove,
			    WI.spFToRemove, WI.spFHull, &WI.vecpCNew);
      break;
    }
  case InsertionQueueEntry::eSubSeg:
    if (!qAllowBdryChanges) return 0;
    if (!WI.qIs3DHullOkay(eEncroachmentType())) {
      WI.vStrip3DHull();
    }
    {
      pVNew = createVert(WI.adCoords());
      vInsertWatsonBoundary(pVNew, WI.spCToRemove,
			    WI.spFToRemove, WI.spFHull,
			    WI.spBFEncroached, &WI.vecpCNew,
			    &WI.vecpBFNew);
      break;
    }
  case InsertionQueueEntry::eTriBFace:
    assert(WI.qIs3DHullOkay(eEncroachmentType()));
    {
      BFace *pBF = WI.IQE.pBFBFace();

      if (pBF->qOffsetInsertionRequested()  && pBF->qOffsetInsertionAllowed()) {
	Vert *pV = createVert(WI.adCoords());
	vMessage(3, "Attempting offset point insertion at (%f, %f, %f).\n",
		 pV->dX(), pV->dY(), pV->dZ());

	// First, delete all verts inside the ball with center at pV
	// passing through the points of the face.
	int iNDeleted = 0;
	bool qSuccess = qDeleteInteriorPointsInBall
	  (pBF, pV->adCoords(),
	   dDIST3D(pV->adCoords(), pBF->pVVert(0)->adCoords()),
	   iNDeleted);
	if (qSuccess) {
	  vMessage(3, "Deleted %d points to clear ball for offset bdry insertion.\n",
		   iNDeleted);
	  if (0 == iNDeleted) {
	    // If nothing was deleted, just go ahead and insert the point.
	    vInsertWatsonInterior(pV, WI.spCToRemove, WI.spFToRemove,
				  WI.spFHull, &WI.vecpCNew);
	  }
	  else {
	    // Need to re-compute the neighborhood of this point, because
	    // the old one just got trashed.  Fortunately, the interior
	    // cell opposite the BFace that we're trying to insert for is
	    // guaranteed to circumscribe the new vertex.
	    Face *pFBdry = pBF->pFFace();
	    Cell *pCSeed = pFBdry->pCCellOpposite(pBF);
	    assert(iInsphere(pCSeed->pVVert(0), pCSeed->pVVert(1),
			     pCSeed->pVVert(2), pCSeed->pVVert(3), pV) == 1);
	    std::set<Cell*> spCToRemove;
	    std::set<Face*> spFToRemove, spFHull;
	    std::set<BFace*> spBFDummy;
	    vGetWatsonData(pV->adCoords(), pCSeed, spCToRemove,
			   spFHull, spFToRemove, spBFDummy);
	    assert(spBFDummy == WI.spBFEncroached);
	    // The encroached BFaces will the same as they were the last
	    // time we checked for this point, and they've already been
	    // queued, so ignore them.
	    vInsertWatsonInterior(pV, spCToRemove, spFToRemove, spFHull,
				  &WI.vecpCNew);
	  }
	}
	else {
	  // Failed to remove all the points that needed removal for
	  // this insertion.
	  return 0;
	}
      }
      else {
	// Split the face instead.

	// If bdry changes aren't allowed, then don't insert.
	if (!qAllowBdryChanges) return 0;

	// Must be sure to get the right insertion point here.
	double adNewLoc[3];
	(dynamic_cast<TriBFaceBase*>(pBF))->vCircumcenter(adNewLoc);

	// First, delete all verts inside the ball with center at pV
	// passing through the points of the face.
	int iNDeleted = 0;
	bool qSuccess = true;
	if (eEncroachmentType() != eBall) {
	  qSuccess = qDeleteInteriorPointsInBall
	    (pBF, adNewLoc, dDIST3D(adNewLoc, pBF->pVVert(0)->adCoords()),
	     iNDeleted);
	}
	if (qSuccess) {
	  vMessage(3, "Deleted %d points to clear ball for bdry insertion.\n",
		   iNDeleted);
	  // If nothing was deleted, just go ahead and insert the point.
	  // Otherwise, recompute the neighborhood.
	  if (iNDeleted != 0) {
	    Face *pFBdry = pBF->pFFace();
	    Cell *pCSeed = pFBdry->pCCellOpposite(pBF);
	    assert(iInsphere(pCSeed->pVVert(0)->adCoords(),
			     pCSeed->pVVert(1)->adCoords(),
			     pCSeed->pVVert(2)->adCoords(),
			     pCSeed->pVVert(3)->adCoords(), adNewLoc) == 1);
	    std::set<BFace*> spBFDummy;
	    vGetWatsonData(adNewLoc, pCSeed, WI.spCToRemove,
			   WI.spFHull, WI.spFToRemove, spBFDummy);
	    assert(spBFDummy == WI.spBFEncroached);
	    // The encroached BFaces will the same as they were the last
	    // time we checked for this point, and they've already been
	    // queued, so ignore them.
	  }
	  Face *pF = pBF->pFFace();
	  Cell *pCInit = pF->pCCellOpposite(WI.IQE.pBFBFace());

	  int iFaceIdx;
	  for (iFaceIdx = 0; (iFaceIdx < pCInit->iNumFaces() &&
			      pCInit->pFFace(iFaceIdx) != pF); iFaceIdx++) {}

	  pVNew = createVert(adNewLoc);
	  vInsertWatsonBoundary(pVNew, WI.spCToRemove,
				WI.spFToRemove, WI.spFHull,
				WI.spBFEncroached, &WI.vecpCNew,
				&WI.vecpBFNew);
	} // Done with successful vertex deletion
	else {
	  // Couldn't remove all the necessary points.
	  return 0;
	}
      } // Done with insertion to split a face.
    }
    break;
  default:
    // Should never have any other cases for VolMesh insertion.
    vFatalError("impossible insertion attempt",
		"VolMesh::qInsertPointWatson(WatsonInfo&)");
  }
  int iCellsAfter = iNumCells();
  int iBFacesAfter = iNumBdryFaces();
  int iIntBFacesAfter = iNumIntBdryFaces();

  vMessage(4, "Started with %d cells,  now have %d.\n", iCellsBefore,
	   iCellsAfter);
  vMessage(4, "Started with %d bfaces, now have %d.\n", iBFacesBefore,
	   iBFacesAfter);
  vMessage(4, "Started with %d interior bfaces, now have %d.\n",
	   iIntBFacesBefore, iIntBFacesAfter);

  // If we inserted on a bdry subseg, then we already know explicitly
  // what entities were changed, so this implicit approach is
  // unnecessary.

  // This whole hack will be unnecessary once insertion is factored and
  // using the Observer base class.
  for (int iC = iCellsBefore; iC < iCellsAfter; iC++) {
    WI.vecpCNew.push_back(pCCell(iC));
  }
  
  for (int iBF = iBFacesBefore; iBF < iBFacesAfter; iBF++) {
    WI.vecpBFNew.push_back(pBFBFace(iBF));
  }

  for (int iIBF = iIntBFacesBefore; iIBF < iIntBFacesAfter; iIBF++) {
    WI.vecpBFNew.push_back(pBFIntBFace(iIBF));
  }

  vUpdateLengthScale(pVNew);
  return 1;
}

//@ The visible interface to point insertion via Watson's method.
// Calls qInsertWatsonInterior, qInsertWatsonBoundary, or
// qInsertWatsonBdryCurve as appropriate, and with appropriate data.
bool VolMesh::qInsertPointWatson(const double adPoint[3],
				 Cell* const pCSeed)
{
  assert(qSimplicial());
  assert(pCSeed->eType() == Cell::eTet);

  Vert *pVNew = createVert(adPoint);

  return qInsertPointWatson(pVNew, pCSeed);
}

bool VolMesh::qInsertPointWatson(Vert* const pVNew,
				 Cell* const pCSeed)
{
  SUMAA_LOG_EVENT_BEGIN(WATSON);
  const double *adPoint = pVNew->adCoords();

  std::set<Cell*> spCToDelete;
  std::set<BFace*> spBFEncroached, spBFUseOffset;
  std::set<Face*> spFHull, spFToRemove;

  vGetWatsonData(adPoint, pCSeed, spCToDelete, spFHull, spFToRemove,
		 spBFEncroached);

  // Don't pass value judgements on whether this point -should- be
  // inserted, just -do- it.

  // Is the point on the bdry?
  bool qOnBdry = false;
  int iLen = spBFEncroached.size();
  if (iLen > 0) {
    // Can't be on the bdry without encroaching something...
    std::set<TriBFaceBase*> spTBFHasPoint;
    for (std::set<BFace*>::iterator iterBF = spBFEncroached.begin();
	 iterBF != spBFEncroached.end(); iterBF++) {
      TriBFaceBase* pTBF = dynamic_cast<TriBFaceBase*>(*iterBF);
      Face *pF = pTBF->pFFace(0);
      double adPointTemp[] = {adPoint[0], adPoint[1], adPoint[2]};
      pF->vProjOntoFace(adPointTemp);
      if (iFuzzyComp(0, dDIST3D(adPointTemp, adPoint)) == 0 &&
	  pTBF->qPointProjectsInside(adPoint))
	spTBFHasPoint.insert(pTBF);
    }
    switch (spTBFHasPoint.size()) {
    case 0:
      // Not a bdry vert;
      break;
    case 1:
      // A bdry vert, but not on a bdry curve
      qOnBdry = true;
      vMessage(3, "WatsonInsert: On a bdry facet\n");
      break;
    case 2:
      {
	// Have to check whether the two BFace's the point is on are part
	// of the same patch.
	qOnBdry = true;
	std::set<TriBFaceBase*>::iterator iter = spTBFHasPoint.begin();
	// Yes, I'm conservative about sprinkling ++ amongst other code;
	// why do you ask? CFO-G
	BdryPatch *pBP0 = (*iter)->pPatchPointer();
	iter++;
	BdryPatch *pBP1 = (*iter)->pPatchPointer();
	if (pBP0 != pBP1) {
	  vMessage(3, "WatsonInsert: Hit a bdry curve (2 BFace's)\n");
	}
	else {
	  vMessage(3, "WatsonInsert: Two BFace's, but inside a facet\n");
	}
      }
      break;
    default: // More than three BFace's contain the point.
      // Definitely a bdry curve.
      qOnBdry = true;
      vMessage(3, "WatsonInsert: Hit a bdry curve (>2 BFace's)\n");
      break;
    } // Done checking whether it's a bdry vert.
    if (qOnBdry) {
      vInsertWatsonBoundary(pVNew, spCToDelete, spFToRemove, spFHull,
			    spBFEncroached);
      SUMAA_LOG_EVENT_END(WATSON);
      return true;
    }
  } // End cases where one or more bdry faces are encroached.

  // Insert in the interior.
  vInsertWatsonInterior(pVNew, spCToDelete, spFToRemove, spFHull);
  SUMAA_LOG_EVENT_END(WATSON);
  return true;
}

//@ Add a vertex using Watson's method when only interior cells are involved
void VolMesh::vInsertWatsonInterior(Vert* const pVNew,
				    const std::set<Cell*>& spCToRemove,
				    const std::set<Face*>& /*spFToRemove*/,
				    const std::set<Face*>& spFHull,
				    std::vector<Cell*>* const new_cells)
{
  SUMAA_LOG_EVENT_BEGIN(WATSON_INSERT);
  int i, iRegion = (*spCToRemove.begin())->iRegion();
  assert(iRegion != iInvalidRegion);

  // The new topology change operators make this really, really easy.
  std::set<Cell*>::iterator iterC;
  for (iterC = spCToRemove.begin(); iterC != spCToRemove.end(); iterC++) {
    deleteCell(*iterC);
  }

  std::set<Face*>::iterator iterF;
  for (iterF = spFHull.begin(); iterF != spFHull.end(); iterF++, i++) {
    Face *pF = *iterF;
    bool qExist;
    Cell *pC = createTetCell(qExist, pVNew, pF, iRegion);
    assert(!qExist);

#ifndef NDEBUG
    SUMAA_LOG_EVENT_BEGIN(WATSON_CHECK);
    assert(pC->iFullCheck());
    assert(iOrient3D(pC->pVVert(0), pC->pVVert(1), pC->pVVert(2),
		     pC->pVVert(3)) == 1);
    SUMAA_LOG_EVENT_END(WATSON_CHECK);
#endif

    if(new_cells) new_cells->push_back(pC);
  }
  assert(!new_cells || spFHull.size() == new_cells->size());

  // assert(qIsLocallyDelaunay());
  SUMAA_LOG_EVENT_END(WATSON_INSERT);

}

///// *** New insertion code by SG starts here *** /////

void VolMesh::strip_cavity( const set<Cell*>& cells_to_remove,
			    const set<Face*>& faces_to_remove,
			    const set<BFace*>* bfaces_to_remove) {

  //Start by marking the cells to remove as deleted,
  //Disconnect these cells from the faces attached to them.
  
  Cell* cell;
  
  set<Cell*>::iterator 
    itc = cells_to_remove.begin(), itc_end = cells_to_remove.end();

  for( ; itc != itc_end; ++itc) {
    
    cell = *itc;
    assert( cell->eType() == Cell::eTet );
    assert( cell->iNumFaces() == 4 );
  
    deleteCell(cell);  
  }

  //The following only be called for boundary insertions.
   
  if( bfaces_to_remove ) {

    //We have a set of boundary faces that need to be removed,
    //go ahead and mark them for deletion.
 
    BFace* bface;
    set<BFace*>::iterator 
      itbf = bfaces_to_remove->begin(), itbf_end = bfaces_to_remove->end();

    for( ; itbf != itbf_end; ++itbf) {

      bface = *itbf;
      assert( bface->eType() == Cell::eTriBFace || 
	      bface->eType() == Cell::eIntTriBFace );

#ifndef NDEBUG
      //These assertions are here to make sure that the faces attached
      //to the boundary faces to delete really made there way into
      //the set of faces to delete.
      switch( bface->iNumFaces() ) {
      case 2: assert( faces_to_remove.count(bface->pFFace(1)) == 1 );
      case 1: assert( faces_to_remove.count(bface->pFFace(0)) == 1 ); break;
      default: assert(0);
      }
#endif

      deleteBFace(bface);

    }

  }

  //Also, delete the faces.  This should already have happened
  //automagically. 

//   set<Face*>::iterator iter = faces_to_remove.begin(),
//     iterEnd = faces_to_remove.end();
//   for ( ; iter != iterEnd; iter++) {
//     Face* pF = *iter;
//     deleteFace(pF);
//   }
}

void VolMesh::reconnect_cavity( Vert* const new_vert,
			        const map<Face*, int>& faces_of_hull,
			        vector<Cell*>*  new_cells,
				vector<BFace*>* new_bfaces, 
				set<TetRefinerEdge>* edges_with_bface,
				bool insert_on_subsegment ) {

  assert( new_vert && new_vert->qValid() && !new_vert->qDeleted() );

  //Every hull face has three edges, each of these edges will correspond
  //to a new face in the mesh. Furthermore, each hull face will correspond
  //to a new cell in the mesh. All these new entites will be connected to 
  //new_vert.

  int region;

  Cell *cell;
  Face *face;

  map<Face*, int>::const_iterator 
    itfh = faces_of_hull.begin(), itfh_end = faces_of_hull.end();

  vector<Face*> tmp_faces;

  for( ; itfh != itfh_end; ++itfh ) {

    face   = itfh->first;  //this is the hull face.
    region = itfh->second; //this is the new cell's region. 
    assert( face->eType() == Face::eTriFace );
    assert( face->iNumVerts() == 3 );
    assert( face->pCCellLeft()  == pCInvalidCell || 
	    face->pCCellRight() == pCInvalidCell );
    assert( face->pCCellLeft()  != pCInvalidCell ||
	    face->pCCellRight() != pCInvalidCell );

    //For each hull face, there will be a new cell. We can create it
    //right now.  At this point, the faces to attach to this cell might
    //not exist yet, but they'll be created as needed.
    bool qExist;
    cell = createTetCell(qExist, new_vert, face, region);
    assert(!qExist);
    if(new_cells) new_cells->push_back(cell);

  }

  if( edges_with_bface ) { //if pointer not NULL -> boundary insertion

#ifndef NDEBUG
    bool interior_insert = false, regular_insert = false;
#endif

    //Now that the cavity have been retriangulated, we need to add
    //the boundary faces. Fortunately, we have a set of (hull) edges
    //that needs to be attached to bdry faces (these edges are computed
    //in TetMeshRefiner). If all went well, these edges should already be 
    //connected to a newly created face and this face should correctly
    //point to its neighboring cells. If everything is correctly
    //assigned, then an interior boundary face have two cells already
    //assigned, while a regular boundary face will still have a free
    //slot for an adjacent face.
    
    Cell *cell1, *cell2;
    BFace *bface, *old_bface;
    bool insert_on_intern_bdry = false;

    set<TetRefinerEdge>::iterator 
      ite = edges_with_bface->begin(), ite_end = edges_with_bface->end();
 
    for( ; ite != ite_end; ++ite) {
      TetRefinerEdge TRE = *ite;
      Vert *pV0 = TRE.vert(0);
      Vert *pV1 = TRE.vert(1);
      old_bface = TRE.get_bface();
      assert(old_bface);

      face = findCommonFace(pV0, pV1, new_vert);
      assert(face);

      cell1 = face->pCCellLeft();
      cell2 = face->pCCellRight();

      if( cell1 != pCInvalidCell && cell2 != pCInvalidCell ) {

#ifndef NDEBUG
	interior_insert = true;
	if(!insert_on_subsegment) assert(!regular_insert);
#endif

	//face1 has two adjacent cells: this is an internal boundary face. 
	//An interior BFace needs to be adjacent to two Face's. One one them 
	//has already been created, but we need to create another one before 
	//sticking the internal boundary in there.
	insert_on_intern_bdry = true;

      }

      else {

#ifndef NDEBUG
	regular_insert = true;
	if(!insert_on_subsegment) assert(!interior_insert);
#endif

	//face only has one adjacent cell: this is a regular boundary face.
	assert( insert_on_subsegment || !insert_on_intern_bdry ); 
	assert( cell1 == pCInvalidCell || cell2 == pCInvalidCell );
	assert( cell1 != pCInvalidCell || cell2 != pCInvalidCell );
	

      }

      //Add the patch (both GRUMMP and CGM calls).
      bface = createBFace(face, old_bface);
      if(new_bfaces) new_bfaces->push_back(bface);
      
      assert( bface->iFullCheck() );
      assert( bface->qHasVert(new_vert) );
      assert( face->iFullCheck() );
    }

    //Set the vertex location tag.  
    if( insert_on_subsegment )        new_vert->vSetType(Vert::eBdryCurve);
    else if( insert_on_intern_bdry )  new_vert->vSetType(Vert::eBdryTwoSide);
    else                              new_vert->vSetType(Vert::eBdry);
  }
}

//Only called in debugging mode:
void VolMesh::post_check_cavity( const vector<Cell*>& new_cells ) {

  SUMAA_LOG_EVENT_BEGIN(WATSON_BDRY_CHECK);
						
  int ii;
  Vert* vert;
  Face* face;
  Cell *cell1, *cell2;

  vector<Cell*>::const_iterator 
    it_cell = new_cells.begin(), it_cell_end = new_cells.end();

  for( ; it_cell != it_cell_end; ++it_cell ) {

    cell1 = *it_cell;
    assert(cell1->qValid());

    //Make sure orientation is correct.
    assert( iOrient3D(cell1->pVVert(0)->adCoords(),
		      cell1->pVVert(1)->adCoords(),
		      cell1->pVVert(2)->adCoords(),
		      cell1->pVVert(3)->adCoords()) == 1);

    //Now make sure that the cell is locally Delaunay. That implies checking
    //that the vertex opposite each of its face lies outside its circumsphere.

    assert( cell1->eType() == Cell::eTet );
    assert( cell1->iNumFaces() == 4 );

    for(ii = 0; ii < 4; ++ii) {

      face = cell1->pFFace(ii);
      cell2 = face->pCCellOpposite(cell1);

      //If it is a boundary face, nothing to do.
      if(cell2->eType() != Cell::eTet) continue;

      assert( cell1->qHasFace(face) && cell2->qHasFace(face) );
      
      //Check from both sides (they should always be mutually Delaunay).
      vert = cell1->pVVertOpposite(face);
      assert( !face->qHasVert(vert) );
      assert( cell1->qHasVert(vert) );
      assert( !TetCell::vert_inside_sphere(vert, cell1) );
      
      vert = cell2->pVVertOpposite(face);
      assert( !face->qHasVert(vert) );
      assert( cell2->qHasVert(vert) );
      assert( !TetCell::vert_inside_sphere(vert, cell2) );

    }

  }

  SUMAA_LOG_EVENT_END(WATSON_BDRY_CHECK);

}

//New interior insertion function.
void VolMesh::insert_watson_interior( Vert* const new_vert,
				      const set<Cell*>& cells_to_remove,
				      const set<Face*>& faces_to_remove,
				      const map<Face*, int>& faces_of_hull,
				      vector<Cell*>* const new_cells ) {

  SUMAA_LOG_EVENT_BEGIN(WATSON_INSERT);

  //Start by stripping the mesh of the entities that form
  //the Watson cavity.

  strip_cavity( cells_to_remove, faces_to_remove );

  //Reconnect the cavity and post check the reconnection.
  //Calls are made slightly differently in debugging mode.

#ifndef NDEBUG
  
  if( !new_cells ) {
    vector<Cell*> new_cells_local;
    reconnect_cavity( new_vert, faces_of_hull, &new_cells_local, NULL );
    post_check_cavity( new_cells_local );
  }
  else {
    reconnect_cavity( new_vert, faces_of_hull, new_cells, NULL );
    post_check_cavity( *new_cells );
  }

#else

  reconnect_cavity( new_vert, faces_of_hull, new_cells, NULL );

#endif

  //That's it, we are done.

  SUMAA_LOG_EVENT_END(WATSON_INSERT);

}

//A new version of boundary insertion designed to be called from TetMeshRefiner
//More a priori info is required when compared to the other function.
void VolMesh::insert_watson_boundary( Vert* const new_vert,
				      set<Cell*>& cells_to_remove,
				      set<Face*>& faces_to_remove,
				      set<BFace*>& bfaces_to_remove,
				      map<Face*, int>& faces_of_hull,
				      set<TetRefinerEdge>& edges_with_bface,
				      bool insert_on_subsegment,
				      vector<Cell*>*  const new_cells,
				      vector<BFace*>* const new_bfaces) {
  
  SUMAA_LOG_EVENT_BEGIN(WATSON_BDRY_INSERT);

  //Start by stripping the mesh of the entities that form
  //the Watson cavity.

  strip_cavity( cells_to_remove, faces_to_remove, &bfaces_to_remove );

  //Reconnect the cavity and post check the reconnection.
  //Calls are made slightly differently in debugging mode.

#ifndef NDEBUG
  
  vector<Cell*> new_cells_local;
  reconnect_cavity( new_vert, faces_of_hull, &new_cells_local, new_bfaces,
		    &edges_with_bface, insert_on_subsegment );
  post_check_cavity( new_cells_local );
  
//   vector<Cell*>::iterator it = new_cells_local.begin(), it_end = new_cells_local.end();

//   printf("new_vert = %.16e %.16e %.16e\n", new_vert->dX(), new_vert->dY(), new_vert->dZ());
//   for( ; it != it_end; ++it) {
//     Cell* cell = *it;
//     printf("cell = %p, size = %.20e\n", cell, cell->dSize());
//     printf(" vert0 : %.16e %.16e %.16e\n", cell->pVVert(0)->dX(), cell->pVVert(0)->dY(), cell->pVVert(0)->dZ() );
//     printf(" vert1 : %.16e %.16e %.16e\n", cell->pVVert(1)->dX(), cell->pVVert(1)->dY(), cell->pVVert(1)->dZ() );
//     printf(" vert2 : %.16e %.16e %.16e\n", cell->pVVert(2)->dX(), cell->pVVert(2)->dY(), cell->pVVert(2)->dZ() );
//     printf(" vert3 : %.16e %.16e %.16e\n", cell->pVVert(3)->dX(), cell->pVVert(3)->dY(), cell->pVVert(3)->dZ() );
//   }

  if(new_cells) new_cells->swap( new_cells_local );
  
#else

  reconnect_cavity( new_vert, faces_of_hull, new_cells, new_bfaces,
		    &edges_with_bface, insert_on_subsegment );

#endif

  SUMAA_LOG_EVENT_END(WATSON_BDRY_INSERT);

}

//@ Add a vertex using Watson's method along the boundary
void VolMesh::vInsertWatsonBoundary(Vert* const pVNew,
				    std::set<Cell*>& spCToRemove,
				    std::set<Face*>& spFToRemove,
				    std::set<Face*>& spFHull,
				    const std::set<BFace*>& spBFEncroached,
				    std::vector<Cell*>* const new_cells,
				    std::vector<BFace*>* const new_bfaces)
{
  // Update for Periodic?
  SUMAA_LOG_EVENT_BEGIN(WATSON_BDRY_INSERT);

  std::set<Face*>::iterator iterF;
  std::set<BFace*>::iterator iterBF;
  std::set<Cell*>::iterator iterC;

  bool qIsInternalBdry = false;
  int iReg = (*spCToRemove.begin())->iRegion();
  {
    for (iterC = spCToRemove.begin(); iterC != spCToRemove.end(); iterC++) {
      if ((*iterC)->iRegion() != iReg) {
	qIsInternalBdry = true;
      }
    }
  }

  // The difference between boundary and interior insertion is that when
  // inserting on the boundary, some of the hull faces are on the
  // boundary and mutually co-planar (or nearly so, for curved
  // surfaces).  These faces are deleted and replaced, as are the
  // BFace's attached to them.

  // To identify these faces, simply find all BFace's in the encroached
  // list that lie on the same BdryPatch as the BFace that triggered the
  // insertion (pBFTarget).  If this point is being inserted on a
  // boundary curve, then there will be two possible BdryPatch's.  These
  // have to be identified, and stored in spBPCand (by adding all
  // encroached BdryPatches, and then weeding out those not containing
  // the new vertex.

  std::set<BdryPatch*> spBPCand;
  for (iterBF = spBFEncroached.begin(); iterBF != spBFEncroached.end();
       iterBF++) {
    spBPCand.insert((*iterBF)->pPatchPointer());
  }

  // This loop is needed even for insertion on a patch interior, because
  // the new vertex may encroach on a triangle on some other patch.
  for (std::set<BdryPatch*>::iterator iterBP = spBPCand.begin();
       iterBP != spBPCand.end(); ) {
    BdryPatch *pBP = *iterBP;
    iterBP++;
    if (pBP->qDisjointFrom(pVNew)) {
      std::set<BdryPatch*>::iterator iterTmp(iterBP);
      spBPCand.erase(--iterTmp);
    }
  }

  assert(spBPCand.size() >= 1);
  vMessage(4, "Number of patches incident on new vert: %d\n",
	   static_cast<int>(spBPCand.size()));
  if (spBPCand.size() == 1) {
    if (qIsInternalBdry) {
      pVNew->vSetType(Vert::eBdryTwoSide);
    }
    else {
      pVNew->vSetType(Vert::eBdry);
    }
  }
  else {
    pVNew->vSetType(Vert::eBdryCurve);
  }


  std::set<BFace*> spBFToRemove;
  for (iterBF = spBFEncroached.begin(); iterBF != spBFEncroached.end();
       iterBF++) {
    BFace* pBF = *iterBF;
    if (spBPCand.count(pBF->pPatchPointer()) != 0) {
      // This bdry face must go.
      spBFToRemove.insert(pBF);
      // The face attached to the bdry face is removed from the hull,
      // because the hull, for this purpose, is the faces to which new
      // cells must be attached.   For internal bdry faces, always do
      // this for the faces on -both- sides.
      for (int ii = 0; ii < pBF->iNumFaces(); ii++) {
	spFHull.erase(pBF->pFFace(ii));
	spFToRemove.insert(pBF->pFFace(ii));
      }
    }
  }


  // Ditto for the bdry faces that are being deleted.  For each edge,
  // keep track of the patch it lies on, so that the new bdry faces will
  // be attached to the correct patch.  Of course, many of these edges
  // will have a deleted BFace on each side of them, and the duplicates
  // aren't of interest to us, so they'll be removed on the fly.
  //
  // In the end, we have a list of all edges that lie on bdrys (internal
  // or regular bdrys) and also lie on the hull of faces to which new
  // cells will be attached.
  //
  // There's some extra gymnastics here so that things will work
  // properly with non-manifold edges (three or more regions meeting at
  // a single edge.

  std::multiset<EdgeToBFace> sEBFAllEdges;
  for (iterBF = spBFToRemove.begin(); iterBF != spBFToRemove.end(); iterBF++) {
    BFace *pBF = *iterBF;
    // This assertion will have to be accompanied by one for the other
    // side for internal boundaries.
    Face *pF = pBF->pFFace(0);
    assert(spFToRemove.count(pF) != 0);
    assert(pBF->iNumFaces() == 1 || spFToRemove.count(pBF->pFFace(1)) != 0);

    EdgeToBFace aEBF[3];
    aEBF[0] = EdgeToBFace(pF->pVVert(0), pF->pVVert(1), pBF);
    aEBF[1] = EdgeToBFace(pF->pVVert(1), pF->pVVert(2), pBF);
    aEBF[2] = EdgeToBFace(pF->pVVert(2), pF->pVVert(0), pBF);
    for (int ii = 0; ii < 3; ii++) {
      sEBFAllEdges.insert(aEBF[ii]);
    }
  }

  std::set<EdgeToBFace> sEBFSingleEdges;
  {
    std::multiset<EdgeToBFace>::iterator iterEBF, endEBF = sEBFAllEdges.end();
    for (iterEBF = sEBFAllEdges.begin(); iterEBF != endEBF; iterEBF++) {
      if (sEBFAllEdges.count(*iterEBF) == 1)
	sEBFSingleEdges.insert(*iterEBF);
    }
  }

  // Before it's too late, we need to make a note of what the actual
  // regions are for faces in the multiregion case.
  std::map<Face*, int> mFaceRegion;

  // Delete faces; force removal, since those on the bdry will still
  // have a BFace attached at this point.
  for (iterF = spFHull.begin(); iterF != spFHull.end(); iterF++) {
    Face *pF = *iterF;
    // Before it's too late, we need to make a note of what the actual
    // regions are for faces in the multiregion case.
    int iThisReg = iInvalidRegion;
    if (qIsInternalBdry) {
      Cell *pCL = pF->pCCellLeft();
      Cell *pCR = pF->pCCellRight();
      assert(pCL->qValid() && pCR->qValid());
      if (pCL->eType() == CellSkel::eTet) {
	iThisReg = pCL->iRegion();
	assert(pCR->eType() != CellSkel::eTet ||
	       iThisReg == pCR->iRegion());
      }
      else {
	assert(pCR->eType() == CellSkel::eTet);
	iThisReg = pCR->iRegion();
      }
    }
    else {
      iThisReg = iReg;
    }
    mFaceRegion.insert(std::pair<Face*, int>(pF, iThisReg));
  }
  
  // Delete cells
  for (iterC = spCToRemove.begin(); iterC != spCToRemove.end(); iterC++) {
    deleteCell(*iterC);
  }

  // Now create a cell for each face of the hull.
  std::map<Face*, int>::iterator mIter, mEnd = mFaceRegion.end();
  for (mIter = mFaceRegion.begin(); mIter != mEnd; mIter++) {
    Face *pF = mIter->first;
    // Get the appropriate region...
    int iThisReg = mIter->second;
    assert(iThisReg != iInvalidRegion);
    bool qExist;
    Cell *pC = createTetCell(qExist, pVNew, pF, iThisReg);
    assert(!qExist);

#ifndef NDEBUG
    SUMAA_LOG_EVENT_BEGIN(WATSON_CHECK);
    assert(pC->iFullCheck());
    SUMAA_LOG_EVENT_END(WATSON_CHECK);
#endif

    if(new_cells) new_cells->push_back(pC);
  }

  // Now grab the face for every hull edge on the bdry and create
  // BFaces to go with them.
  std::set<EdgeToBFace>::iterator iterEBF, endEBF = sEBFSingleEdges.end();
  for (iterEBF = sEBFSingleEdges.begin(); iterEBF != endEBF; iterEBF++) {
    EdgeToBFace EBF = *iterEBF;
    Face *pF = findCommonFace(EBF.pVVert(0), EBF.pVVert(1), pVNew, NULL, true);
    assert(pF->qValid());
    BFace *pBF = createBFace(pF, EBF.pBFace());
    if(new_bfaces) new_bfaces->push_back(pBF);
    assert(pBF->iFullCheck());
    assert(pF->iFullCheck());
  }

  // Now it's finally safe to delete the old BFace's.
  for (iterBF = spBFToRemove.begin(); iterBF != spBFToRemove.end();
       iterBF++) {
    BFace* pBF = *iterBF;
    deleteBFace(pBF);
  }

  // Must swap all hull faces, because with boundary insertion, there
  // could be a face that -needs- to be swapped.  Its untouched cell has
  // a visibility problem with the inserted vertex, so the mesh can't be
  // made (even constrained) Delaunay by Watson insertion alone.
  int iNSwaps = 0;
  for (iterF = spFHull.begin(); iterF != spFHull.end(); iterF++) {
    Face *pF = *iterF;
    iNSwaps += iFaceSwap(pF);
  }
  if (iNSwaps != 0)
    vMessage(3, "Made %d swaps for hull faces (bdry insertion).\n",
	     iNSwaps);

  // assert(qIsLocallyDelaunay());

  SUMAA_LOG_EVENT_END(WATSON_BDRY_INSERT);
}

