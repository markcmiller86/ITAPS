#include "GR_assert.h"
#include <math.h>
#include <stdlib.h>
#include "GR_misc.h"
#include "GR_Geometry.h"
#include "GR_VolMesh.h"
#include "GR_events.h"
#include "SMsmooth.h"
#include "GR_BFace.h"
#include "GR_Vec.h"

#ifdef IRIX6
#include <values.h>
#endif

static int iOnEdge = 0;
static int iOnBdryEdge = 0;
static int iOnBdryEdge2 = 0;
static int iOnFace = 0;
static int iOnBdryFace = 0;
static int iInterior = 0;
// These two cases aren't handled properly anyway.
// static int iOnIntBdryEdge = 0;
// static int iOnIntBdryFace = 0;

static bool qInsertInThisCell(Cell* const pC,
			     double dfLengthScale(const double adCoord[3]))
{
  assert(pC->iFullCheck());
  assert(pC->eType() == Cell::eTet);
  double dRad = dynamic_cast<TetCell*>(pC)->dCircumradius();
  double dLength = 0.25 * (+ dfLengthScale(pC->pVVert(0)->adCoords())
			   + dfLengthScale(pC->pVVert(1)->adCoords())
			   + dfLengthScale(pC->pVVert(2)->adCoords())
			   + dfLengthScale(pC->pVVert(3)->adCoords()));
//    double dCorrectSize = dLength*dLength*dLength * dFactor;

//   double dMinSize = dCorrectSize / 4;
  if (dRad > sqrt(3.)*dLength/2.) return true;
  pC->vMarkWellSized();
  return false;
}

//@ Insert a point on an edge
int VolMesh::iInsertOnEdge(Vert* const pVNew, Vert* const pV0,
			   Vert* const pV1, Face* const pF, const int qSwap)
     // If the edge is actually a boundary edge, iInsertOnBdryEdge will
     // be called when that fact is discovered.
{
#ifdef SUMAA_LOG
  assert(SUMAA_LOG_current == INSERT_VERTEX);
#endif
  assert(qSimplicial());
  assert(pF->iFullCheck());
  assert(pF->qHasVert(pV0));
  assert(pF->qHasVert(pV1));

  //@@ Check to see if the face containing this edge is a boundary face
  // If it is, we can cut right the chase, calling iInsertOnBdryEdge
  // immediately.
  if (pF->pCCellLeft ()->eType() == Cell::eTriBFace ||
      pF->pCCellRight()->eType() == Cell::eTriBFace) {
    iOnBdryEdge++;
    return iInsertOnBdryEdge(pVNew, pV0, pV1, pF, qSwap);
  }

  //@@ Likewise, check to see if the given face is an internal bdry face
  bool qIntBdryEdge = false;
  if (pF->iFaceLoc() == Face::eBdryTwoSide)
    qIntBdryEdge = true;
  else {
    assert(pF->pCCellLeft()->iRegion() == pF->pCCellRight()->iRegion());
  }

  //@@ Preamble to walking around the edge
  assert(pF->pCCellLeft()->eType() == Cell::eTet);
  TetCell* pTC = dynamic_cast<TetCell*>(pF->pCCellLeft());

  Vert* pVA = pTC->pVVertOpposite(pF);
  Vert* pVB = pV0;
  Vert* pVC = pV1;
  Vert* pVD;
  if (pF->pVVert(0) != pVB && pF->pVVert(0) != pVC)
    pVD = pF->pVVert(0);
  else if (pF->pVVert(1) != pVB && pF->pVVert(1) != pVC)
    pVD = pF->pVVert(1);
  else {
    assert(pF->pVVert(2) != pVB && pF->pVVert(2) != pVC);
    pVD = pF->pVVert(2);
  }
  if (iOrient3D(pVA, pVB, pVC, pVD) != 1) {
    Vert* pV = pVC; pVC = pVB; pVB = pV;
  }

  //@@ Make lists of cells divided and their faces and verts
  //@@ Create new faces and cell for each original cell
  const int iMaxWrapCells = 25;
  // This is the chain of verts around the perimeter of the shape (Verts
  // B and C are constant).  The extra one at the end will contain a
  // copy of the first one.
  Vert* apVert[iMaxWrapCells+1];
  // Current and new cells
  Cell *apCell[iMaxWrapCells], *apCNew[2*iMaxWrapCells];
  // apFace contains the original faces separating cells around the edge.
  // Again, a copy is used at the end.
  Face* apFace[iMaxWrapCells+1];
  // These are faces opposite verts B and C, respectively
  Face *apFaceB[iMaxWrapCells], *apFaceC[iMaxWrapCells];

  apVert[0] = pVD;
  apCell[0] = pTC;
  apFace[0] = pF;
  apFaceB[0] = pTC->pFFaceOpposite(pVB);
  apFaceC[0] = pTC->pFFaceOpposite(pVC);

  int i = 0, iReg = pTC->iRegion();
  Cell* pC;
  Face* pFStart = pF;
  //@@@ Walk around the edge, gathering info and setting up new entities
  while (1) {
    i++;
    // These are things that get set up regardless of whether there's
    // another interior cell
    apVert[i] = pTC->pVVertOpposite(apFace[i-1]);
    apFace[i] = pTC->pFFaceOpposite(apVert[i-1]);

    // Continue until returned to starting point...
    if (apFace[i] == pFStart) break;
    if (apFace[i]->iFaceLoc() == Face::eBdryTwoSide) {
      qIntBdryEdge = true;
      // Panic!  This code can't handle this case!
      assert(0);
      return 0;
    }
    // ...or until a boundary is hit
    pC = apFace[i]->pCCellOpposite(pTC);
    if (pC->eType() == Cell::eTriBFace) {
      // Abandon this attempt as a bad idea, and call the bdry edge
      // specific insertion code instead.
      iOnBdryEdge2++;
      return (iInsertOnBdryEdge(pVNew, pV0, pV1, apFace[i], qSwap));
    }
    assert(pC->eType() == Cell::eTet);
    pTC = dynamic_cast<TetCell*>(pC);

    // Record existing stuff
    apCell[i] = pTC;
    apFaceB[i] = pTC->pFFaceOpposite(pVB);
    apFaceC[i] = pTC->pFFaceOpposite(pVC);
  }

  iOnEdge++;
  int iNWrapCells = i;
  assert(iNWrapCells <= iMaxWrapCells);

  //@@ Reconnect everything properly
  // Delete old cells incident on the edge.
  for (i = 0; i < iNWrapCells; i++) 
    deleteCell(apCell[i]);

  // Create new cells.
  for (i = 0; i < iNWrapCells; i++) {
    // Check cell orientation
    assert(iOrient3D(apVert[i+1], apVert[i], pVNew, pVC) == 1);
    assert(iOrient3D(apVert[i], apVert[i+1], pVNew, pVB) == 1);
    // Actually create them.
    bool qJunk;
    apCNew[2*i  ] = createTetCell(qJunk, apVert[i+1], apVert[i], pVNew, pVC,
				  iReg);
    assert(!qJunk);
    apCNew[2*i+1] = createTetCell(qJunk, apVert[i], apVert[i+1], pVNew, pVB,
				  iReg);
    assert(!qJunk);
  }
  
  for (i = 0; i < iNWrapCells; i++) {
    // Check cell connectivity
    assert(apCNew[2*i  ]->iFullCheck());
    assert(apCNew[2*i+1]->iFullCheck());
    // Check all faces
    assert(apFaceB[i]->iFullCheck());
    assert(apFaceC[i]->iFullCheck());
  }

  //@@ Do face swapping for all the external faces
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
  SUMAA_LOG_EVENT_BEGIN(NET_SWAPPING);
  int iRetVal = 0;
  if (qSwap) {
    for (i = 0; i < iNWrapCells; i++) {
      iRetVal += iFaceSwap(apFaceB[i]);
      iRetVal += iFaceSwap(apFaceC[i]);
    }
  }
  SUMAA_LOG_EVENT_END(NET_SWAPPING);
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
//   assert(qValid());
  return (iRetVal);
}

//@ Insert a point on a boundary edge
int VolMesh::iInsertOnBdryEdge(Vert* const pVNew, Vert* const pV0,
			       Vert* const pV1, Face* const pF,
			       const int qSwap)
{
  // Update for Periodic?
#ifdef SUMAA_LOG
  assert(SUMAA_LOG_current == INSERT_VERTEX);
#endif
  assert(qSimplicial());
  assert(pF->iFullCheck());
  assert(pF->qHasVert(pV0));
  assert(pF->qHasVert(pV1));
  assert(pF->pCCellLeft ()->eType() == Cell::eTriBFace ||
	 pF->pCCellRight()->eType() == Cell::eTriBFace);

  if (!qAllowBdryChanges) return (-1);

  //@@ Identify the boundary face and the interior cell
  BFace* pBF0;
  TetCell* pTC;
  if (pF->pCCellLeft ()->eType() == Cell::eTriBFace) {
    assert(pF->pCCellRight()->eType() == Cell::eTet);
    pBF0 = dynamic_cast<TriBFace*>(pF->pCCellLeft());
    pTC  = dynamic_cast<TetCell*> (pF->pCCellRight());
  }
  else {
    assert(pF->pCCellLeft ()->eType() == Cell::eTet);
    pBF0 = dynamic_cast<TriBFace*>(pF->pCCellRight());
    pTC  = dynamic_cast<TetCell*> (pF->pCCellLeft());
  }

  Vert* pVA = pTC->pVVertOpposite(pF);
  Vert* pVB = pV0;
  Vert* pVC = pV1;
  Vert* pVD;
  if (pF->pVVert(0) != pVB && pF->pVVert(0) != pVC)
    pVD = pF->pVVert(0);
  else if (pF->pVVert(1) != pVB && pF->pVVert(1) != pVC)
    pVD = pF->pVVert(1);
  else {
    assert(pF->pVVert(2) != pVB && pF->pVVert(2) != pVC);
    pVD = pF->pVVert(2);
  }
  if (iOrient3D(pVA, pVB, pVC, pVD) != 1) {
    Vert* pV = pVC; pVC = pVB; pVB = pV;
  }

  int iReg = pTC->iRegion();

  //@@ Make lists of cells divided and their faces and verts
  //@@ Create new faces and cell for each original cell
  const int iMaxWrapCells = 25;
  // This is the chain of verts around the perimeter of the shape (Verts
  // B and C are constant)
  Vert* apVert[iMaxWrapCells+1];
  // Current and new cells
  Cell *apCell[iMaxWrapCells], *apCNew[2*iMaxWrapCells];
  // apFace contains the original faces separating cells around the edge
  Face* apFace[iMaxWrapCells+1];
  // These are faces opposite verts B and C, respectively
  Face *apFaceB[iMaxWrapCells], *apFaceC[iMaxWrapCells];

  //@@@ Prolog:  set stuff up for the boundary face at this end
  apCell[0] = pTC;
  apVert[0] = pVD;
  apFace[0] = pF;
  apFaceB[0] = pTC->pFFaceOpposite(pVB);
  apFaceC[0] = pTC->pFFaceOpposite(pVC);

  int i = 0;
  Cell* pC;
  //@@@ Walk around the edge, gathering info and setting up new entities
  while (1) {
    i++;
    // These are things that get set up regardless of whether there's
    // another interior cell
    apVert[i] = pTC->pVVertOpposite(apFace[i-1]);
    apFace[i] = pTC->pFFaceOpposite(apVert[i-1]);

    // Go on to the next cell, if and only if it's an interior cell
    // rather than a boundary face
    pC = apFace[i]->pCCellOpposite(pTC);
    if (pC->eType() == Cell::eTriBFace) break;
    assert(pC->eType() == Cell::eTet);
    pTC = dynamic_cast<TetCell*>(pC);
    apCell[i] = pTC;
    apFaceB[i] = pTC->pFFaceOpposite(pVB);
    apFaceC[i] = pTC->pFFaceOpposite(pVC);
  }
  BFace* pBF1 = dynamic_cast<TriBFace*>(pC);
  int iNWrapCells = i;
  assert(iNWrapCells <= iMaxWrapCells);

  //@@ Reconnect everything properly

  // Delete old cells and faces incident on the edge
  for (i = 0; i < iNWrapCells; i++)     
    deleteCell(apCell[i]);

  // Create new cells.
  for (i = 0; i < iNWrapCells; i++) {
    // Check cell orientation
    assert(iOrient3D(apVert[i+1], apVert[i], pVNew, pVC) == 1);
    assert(iOrient3D(apVert[i], apVert[i+1], pVNew, pVB) == 1);
    // Actually create them.
    bool qJunk;
    apCNew[2*i  ] = createTetCell(qJunk, apVert[i+1], apVert[i], pVNew, pVC,
				  iReg);
    assert(!qJunk);
    apCNew[2*i+1] = createTetCell(qJunk, apVert[i], apVert[i+1], pVNew, pVB,
				  iReg);
    assert(!qJunk);
  }
  
  // Find the new faces on the bdry.
  Face* pFBdry0A = apCNew[0]->pFFaceOpposite(apVert[1]);
  Face* pFBdry0B = apCNew[1]->pFFaceOpposite(apVert[1]);
  Face* pFBdry1A = apCNew[2*iNWrapCells - 2]->
    pFFaceOpposite(apVert[iNWrapCells-1]);
  Face* pFBdry1B = apCNew[2*iNWrapCells - 1]->
    pFFaceOpposite(apVert[iNWrapCells-1]);

  // For each of these faces, there should be an unassigned cell at this
  // point. 
  assert(!pFBdry0A->pCCellLeft()->qValid() ||
	 !pFBdry0A->pCCellRight()->qValid());
  assert(!pFBdry0B->pCCellLeft()->qValid() ||
	 !pFBdry0B->pCCellRight()->qValid());
  assert(!pFBdry1A->pCCellLeft()->qValid() ||
	 !pFBdry1A->pCCellRight()->qValid());
  assert(!pFBdry1B->pCCellLeft()->qValid() ||
	 !pFBdry1B->pCCellRight()->qValid());
  
  // Create two new boundary faces at each end
  BFace *pBFNew0A = createBFace(pFBdry0A, pBF0);
  BFace *pBFNew0B = createBFace(pFBdry0B, pBF0);
  BFace *pBFNew1A = createBFace(pFBdry1A, pBF1);
  BFace *pBFNew1B = createBFace(pFBdry1B, pBF1);
  
  // Check to see whether this bdry edge is on a bdry segment, by
  // checking whether the BFace's on either side of the original edge
  // lie in the same bdry patch.
  BdryPatch* pBP0 = pBFNew0A->pPatchPointer();
  BdryPatch* pBP1 = pBFNew1A->pPatchPointer();
  assert(pBFNew0B->pPatchPointer() == pBP0);
  assert(pBFNew1B->pPatchPointer() == pBP1);
  if (pBP0 == pBP1) {
    pVNew->vSetType(Vert::eBdry);
  }
  else {
    pVNew->vSetType(Vert::eBdryCurve);
  }

  deleteBFace(pBF0);
  deleteBFace(pBF1);

  //@@@ Loop over cells
  for (i = 0; i < iNWrapCells; i++) {
    assert(apCNew[2*i  ]->iFullCheck());
    assert(apCNew[2*i+1]->iFullCheck());
    // Check all faces
    assert(apFaceB[i]->iFullCheck());
    assert(apFaceC[i]->iFullCheck());
  }

  //@@ Do face swapping for all the external faces
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
  SUMAA_LOG_EVENT_BEGIN(NET_SWAPPING);
  int iRetVal = 0;
  if (qSwap) {
    for (i = 0; i < iNWrapCells; i++) {
      iRetVal += iFaceSwap(apFaceB[i]);
      iRetVal += iFaceSwap(apFaceC[i]);
    }
  }
  SUMAA_LOG_EVENT_END(NET_SWAPPING);
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
//   assert(qValid());
  return (iRetVal);
}

//@ Insert a point on a face, either interior or boundary
int VolMesh::iInsertOnFace(Vert* const pVNew, Face * const pF,
			   Cell * const pC, const int qSwap)
     // Note: Geometrically, pVNew may not fall exactly on pF because
     // of round-off.  Once things are done, though, the connectivity will
     // be the same as if it had.
{
  assert(pC->iFullCheck());
  assert(pF->iFullCheck());
  assert(pF->pCCellLeft() == pC || pF->pCCellRight() == pC);
  assert(pC->qHasFace(pF));

  if (pF->eType() != Face::eTriFace) return 0;

  Vert * pVA = pF->pVVert(0);
  Vert * pVB = pF->pVVert(1);
  Vert * pVC = pF->pVVert(2);

  Cell* pCD = pF->pCCellLeft ();
  Cell* pCE = pF->pCCellRight();

  //@@ Boundary face case
  if (pCD->eType() == Cell::eTriBFace ||
      pCE->eType() == Cell::eTriBFace) {
    // Update for Periodic?
    // Don't insert on precious boundaries.
    if (!qAllowBdryChanges) return (-1);

    iOnBdryFace++;
    Vert *pVD = pC->pVVertOpposite(pF);
    BFace* pBF;
    if (pCD == pC) {
      assert(pCE->eType() == Cell::eTriBFace);
      pBF = dynamic_cast<TriBFace*>(pCE);
      pVB = pF->pVVert(2), pVC = pF->pVVert(1);
    }
    else { // The verts are already okay.
      assert(pCD->eType() == Cell::eTriBFace);
      pBF = dynamic_cast<TriBFace*>(pCD);
    }
    // Everything had better be right-handed.
    assert(iOrient3D(pVA, pVB, pVC, pVD) == 1);
    assert(iOrient3D(pVA, pVB, pVNew, pVD) == 1);
    assert(iOrient3D(pVA, pVNew, pVC, pVD) == 1);
    assert(iOrient3D(pVNew, pVB, pVC, pVD) == 1);

    Face *pFA, *pFB, *pFC;
    if (qSwap) {
      pFA = pC->pFFaceOpposite(pVA);
      pFB = pC->pFFaceOpposite(pVB);
      pFC = pC->pFFaceOpposite(pVC);
    }

    // Now delete the old cell and face.
    int iReg = pC->iRegion();
    deleteCell(pC);

    // Create three new cells.
    Cell *apCNew[3];
    bool qJunk;
    apCNew[0] = createTetCell(qJunk, pVA, pVB, pVNew, pVD, iReg);
    assert(!qJunk);
    apCNew[1] = createTetCell(qJunk, pVB, pVC, pVNew, pVD, iReg);
    assert(!qJunk);
    apCNew[2] = createTetCell(qJunk, pVC, pVA, pVNew, pVD, iReg);
    assert(!qJunk);

    pVNew->vSetType(Vert::eBdry); // Can't be a BdryApex or BdryCurve

    for (int iC = 0; iC < 3; iC++) {
      Cell *pCTmp = apCNew[iC];
       
      // Identify the face on the bdry in the tet and create a BFace for it.
      Face *pFOnBdry = apCNew[iC]->pFFaceOpposite(pVD);
      BFace *pBFNew = createBFace(pFOnBdry, pBF);

      assert(pCTmp->iFullCheck());
      assert(pBFNew->iFullCheck());
      assert(pFOnBdry->iFullCheck());
    }

    // Nuke the old bdry face.
    deleteBFace(pBF);

    assert(pFA->iFullCheck());
    assert(pFB->iFullCheck());
    assert(pFC->iFullCheck());

    //@@@ Swap locally
    SUMAA_LOG_EVENT_END(INSERT_VERTEX);
    SUMAA_LOG_EVENT_BEGIN(NET_SWAPPING);
    int iRetVal = 0;
    if (qSwap) {
      iRetVal += iFaceSwap(pFA);
      iRetVal += iFaceSwap(pFB);
      iRetVal += iFaceSwap(pFC);
    }
    SUMAA_LOG_EVENT_END(NET_SWAPPING);
    SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
//     assert(qValid());
    return(iRetVal);
  } // Done with insertion on boundary face
  //@@ Something other than tets
  else if (pCD->eType() != Cell::eTet ||
	   pCE->eType() != Cell::eTet) {
    // This spot includes insertion on internal bdry faces.
    return 0;
  }
  //@@ Insertion on an interior face
  else {
    assert(pF->iFaceLoc() == Face::eInterior);
    iOnFace++;

    Vert *pVD = pCD->pVVertOpposite(pF);
    Vert *pVE = pCE->pVVertOpposite(pF);
    assert(iOrient3D(pVA, pVC, pVB, pVD) == 1);
    assert(iOrient3D(pVA, pVB, pVC, pVE) == 1);

    Face* pFA1 = pCE->pFFaceOpposite(pVA);
    Face* pFB1 = pCE->pFFaceOpposite(pVB);
    Face* pFC1 = pCE->pFFaceOpposite(pVC);

    Face* pFA2 = pCD->pFFaceOpposite(pVA);
    Face* pFB2 = pCD->pFFaceOpposite(pVB);
    Face* pFC2 = pCD->pFFaceOpposite(pVC);

    assert(iOrient3D(pVA, pVE, pVB, pVNew) == 1);
    assert(iOrient3D(pVB, pVE, pVC, pVNew) == 1);
    assert(iOrient3D(pVC, pVE, pVA, pVNew) == 1);
    assert(iOrient3D(pVA, pVB, pVD, pVNew) == 1);
    assert(iOrient3D(pVB, pVC, pVD, pVNew) == 1);
    assert(iOrient3D(pVC, pVA, pVD, pVNew) == 1);

    int iReg = pCD->iRegion();
    assert(pCE->iRegion() == iReg);

    // Out with the old.
    deleteCell(pCD);
    deleteCell(pCE);

    // In with the new.
    bool qJunk;
    Cell* pCA1 = createTetCell(qJunk, pVA, pVE, pVB, pVNew, iReg);
    assert(!qJunk);
    Cell* pCB1 = createTetCell(qJunk, pVB, pVE, pVC, pVNew, iReg);
    assert(!qJunk);
    Cell* pCC1 = createTetCell(qJunk, pVC, pVE, pVA, pVNew, iReg);
    assert(!qJunk);
    Cell* pCA2 = createTetCell(qJunk, pVA, pVB, pVD, pVNew, iReg);
    assert(!qJunk);
    Cell* pCB2 = createTetCell(qJunk, pVB, pVC, pVD, pVNew, iReg);
    assert(!qJunk);
    Cell* pCC2 = createTetCell(qJunk, pVC, pVA, pVD, pVNew, iReg);
    assert(!qJunk);


    // Check cells
    assert(pCA1->iFullCheck());
    assert(pCB1->iFullCheck());
    assert(pCC1->iFullCheck());
    assert(pCA2->iFullCheck());
    assert(pCB2->iFullCheck());
    assert(pCC2->iFullCheck());

    // Check faces
    assert(pFA1->iFullCheck());
    assert(pFB1->iFullCheck());
    assert(pFC1->iFullCheck());
    assert(pFA2->iFullCheck());
    assert(pFB2->iFullCheck());
    assert(pFC2->iFullCheck());

    //@@@ Swap locally
    SUMAA_LOG_EVENT_END(INSERT_VERTEX);
    SUMAA_LOG_EVENT_BEGIN(NET_SWAPPING);
    int iRetVal = 0;
    if (qSwap) {
      iRetVal += iFaceSwap(pFA1);
      iRetVal += iFaceSwap(pFB1);
      iRetVal += iFaceSwap(pFC1);
      iRetVal += iFaceSwap(pFA2);
      iRetVal += iFaceSwap(pFB2);
      iRetVal += iFaceSwap(pFC2);
    }
    SUMAA_LOG_EVENT_END(NET_SWAPPING);
    SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
//     assert(qValid());
    return(iRetVal);
  } // End of interior face insertion
}

//@ Insert a point inside a cell
int VolMesh::iInsertInInterior(Vert* const  pVNew, Cell* const pC,
			       const int qSwap)
{
#ifdef SUMAA_LOG
  assert(SUMAA_LOG_current == INSERT_VERTEX);
#endif
  assert(pC->iFullCheck());
  iInterior++;

  // Verts ABCD are ordered in a right-handed way.
  Vert* pVA = pC->pVVert(0);
  Vert* pVB = pC->pVVert(1);
  Vert* pVC = pC->pVVert(2);
  Vert* pVD = pC->pVVert(3);

  // The order of the faces is unimportant; they're needed only for
  // swapping, if that's requested.
  Face *pFA, *pFB, *pFC, *pFD;
  if (qSwap) {
    pFA = pC->pFFace(0);
    pFB = pC->pFFace(1);
    pFC = pC->pFFace(2);
    pFD = pC->pFFace(3);
  }
  
  // The tet must be right-handed.
  assert(iOrient3D(pVA, pVB, pVC, pVD) == 1);

  // The vert has to fall inside it.
  assert(iOrient3D(pVA, pVB, pVC, pVNew) == 1);
  assert(iOrient3D(pVA, pVD, pVB, pVNew) == 1);
  assert(iOrient3D(pVB, pVD, pVC, pVNew) == 1);
  assert(iOrient3D(pVC, pVD, pVA, pVNew) == 1);

  // With the new topology handling, this is trivial: delete one tet,
  // create four, and move on with your life.

  // Need to know which region first...
  int iReg = pC->iRegion();

  deleteCell(pC);

  Cell *apCNew[4];
  bool qJunk;
  apCNew[0] = createTetCell(qJunk, pVA, pVB, pVC, pVNew, iReg);
  assert(!qJunk);
  apCNew[1] = createTetCell(qJunk, pVB, pVA, pVD, pVNew, iReg);
  assert(!qJunk);
  apCNew[2] = createTetCell(qJunk, pVC, pVB, pVD, pVNew, iReg);
  assert(!qJunk);
  apCNew[3] = createTetCell(qJunk, pVA, pVC, pVD, pVNew, iReg);
  assert(!qJunk);
  
  for (int iC = 0; iC < 4; iC++) {
    Cell *pCTmp = apCNew[iC];

    assert(pCTmp->iFullCheck());
    // All the new tets will be right-handed, too.
    assert(iOrient3D(pCTmp->pVVert(0), pCTmp->pVVert(1),
		     pCTmp->pVVert(2), pCTmp->pVVert(3)) == 1);
  }

  // Do some local swapping to clean up
  SUMAA_LOG_EVENT_END(INSERT_VERTEX);
  SUMAA_LOG_EVENT_BEGIN(NET_SWAPPING);
  int iRetVal = 0;
  if (qSwap) {
    iRetVal += iFaceSwap(pFA);
    iRetVal += iFaceSwap(pFB);
    iRetVal += iFaceSwap(pFC);
    iRetVal += iFaceSwap(pFD);
  }
  SUMAA_LOG_EVENT_END(NET_SWAPPING);
  SUMAA_LOG_EVENT_BEGIN(INSERT_VERTEX);
//   assert(qValid());
  return (iRetVal);
}

//@ Add a site (or some variant if it lies outside the mesh) to the mesh
// Return value indicates success
bool VolMesh::qInsertPoint(const double adPointIn[3], Cell* const pCGuess,
			   int * const piSwaps, const bool qSwap,
			   const bool qForce, Vert* pVNew)
  // pVNew is non-pVInvalidVert if and only if the point being
  // inserted already belongs to the point set of the mesh; in this
  // case, pVNew->adCoords() == adPointIn.
{
#ifdef SUMAA_LOG
  assert(SUMAA_LOG_current == INSERT_VERTEX);
#endif
  assert(qSimplicial());
  assert(qForce || dfLengthScale);
  *piSwaps = 0;
  Cell* pC = pCGuess;
  if (pC->eType() == Cell::eTriBFace) {
    Face *pFTmp = pC->pFFace(0);
    pC = pFTmp->pCCellOpposite(pC);
  }
  double adPoint[] = {adPointIn[0], adPointIn[1], adPointIn[2]};

  if (pVNew->qValid()) {
    assert(qForce); // Can't twiddle the point location if it's an
		    // existing vertex.
    // Check that the points coincide
    assert(dDIST3D(pVNew->adCoords(), adPointIn) < 1.e-12);
  }

  //@@ Compute barycentric coordinates
  double adBary[4];
  dynamic_cast<TetCell*>(pC)->vBarycentrics(adPoint, adBary);
  int iNegBary = ((adBary[0] < -1.e-10 ? 1 : 0) +
		  (adBary[1] < -1.e-10 ? 1 : 0) +
		  (adBary[2] < -1.e-10 ? 1 : 0) +
		  (adBary[3] < -1.e-10 ? 1 : 0));

  if (iNegBary) {
    //@@ Find which cell the site falls within (or near, if outside the mesh)
    assert(pCGuess->iFullCheck());
    Cell *pCNew = pCGuess, *pCOld = pCGuess;
    int iOrient = 0;
    int iSteps = 0;
    bool qDone;
    Face *pF;
    do {
      qDone = true;
      iSteps ++;
      int i;
      double adCent[3];
      pC->vCentroid(adCent);
      for (i = 0; i < 4; i++) {
	pF = pC->pFFace(i);
	// If the face is pointing away from this cell, then signs need to
	// be reversed to walk in the proper direction
	int iSign = (pF->pCCellLeft() == pC) ? -1 : 1;
	iOrient = iOrient3D(pF, adPoint) * iSign;
	// If the vertex lies outside the current cell and behind the
	// current face, walk in that direction.  If the walk would
	// involve going outside the boundary, continue checking to try to
	// find another face to walk across; this improves behavior of
	// walks which try to insert a boundary point.
	if (iOrient == -1) {
	  if (iSteps < 2000) {
	    pCNew = pF->pCCellOpposite(pC);
	    qDone = false;
	    if (pCNew->eType() != Cell::eTriBFace)
	      break;
	  }
	  else {
	    // Assume that we may be entering orbit...
	    int iOrient01 = iOrient3D(adCent, pF->pVVert(0)->adCoords(),
				      pF->pVVert(1)->adCoords(),
				      adPoint);
	    int iOrient12 = iOrient3D(adCent, pF->pVVert(1)->adCoords(),
				      pF->pVVert(2)->adCoords(),
				      adPoint);
	    int iOrient20 = iOrient3D(adCent, pF->pVVert(2)->adCoords(),
				      pF->pVVert(0)->adCoords(),
				      adPoint);
	    // If the target point lies on or inside the infinite
	    // triangular pyramid defined by the cell centroid and the
	    // vertices of pF, then stepping through this face
	    // definitely moves us in the direction of the target.
	    if (iOrient01*iOrient12 != -1 &&
		iOrient12*iOrient20 != -1 &&
		iOrient20*iOrient01 != -1) {
	      pCNew = pF->pCCellOpposite(pC);
	      qDone = false;
	      if (pCNew->eType() != Cell::eTriBFace)
		break;
	    }
	  }
	}
      }
      pCOld = pC;
      pC = pCNew;
    } while (iOrient == -1 && pC->eType() != Cell::eTriBFace &&
	     iSteps < 5000);

    if (!qDone && pC->eType() != Cell::eTriBFace) {
      return 0;
    }

    // Restore identity of last interior cell visited, if needed
    pC = pCOld;
    //@@ Check for near-coincidence with existing verts

    if ((!qForce) && (qInsertInThisCell(pC, dfLengthScale) != 1)) {
      return 0;
    }
    //@@ Re-compute barycentric coordinates
    dynamic_cast<TetCell*>(pC)->vBarycentrics(adPoint, adBary);
  }

  if (!qForce) {
    double dMinDist = 0.6 * dLengthScale(adPoint);
    if (dDIST3D(adPoint, pC->pVVert(0)->adCoords()) < dMinDist ||
	dDIST3D(adPoint, pC->pVVert(1)->adCoords()) < dMinDist ||
	dDIST3D(adPoint, pC->pVVert(2)->adCoords()) < dMinDist ||
	dDIST3D(adPoint, pC->pVVert(3)->adCoords()) < dMinDist) {
      return (0);
    }
  }
  //@@ Snap to face/edge

  // Define the threshold of barycentric coordinate that will induce
  // snap to face/edge
  double dBaryThresh;
  if (qForce) dBaryThresh = 1.e-10;
  else        dBaryThresh = 0.1;

  double dSum = 0.;
  int i, iLowBary = 0;
  for (i = 0; i <= 3; i ++)
    if (adBary[i] < dBaryThresh) {
      adBary[i] = 0;
      iLowBary++;
    }
    else
      dSum += adBary[i];
  assert(iFuzzyComp(dSum, 0) != 0);
  assert(iLowBary <= 3);
  switch (iLowBary) {
  case 0:
    { // Insertion squarely inside a cell
      if (!(pVNew->qValid()))
	pVNew = createVert(adPoint);
      else {
	pVNew->vSetCoords(3, adPoint);
      }
      *piSwaps = iInsertInInterior(pVNew, pC, qSwap);
      return (1);
    }
  case 1:
    { // Insertion on a face (possibly a boundary face; let the
      // callee deal with that question)
      // Find the face opposite the zero barycentric coordinate
      const Vert *pVZero;
      if      (adBary[0] < dBaryThresh)
	pVZero = pC->pVVert(0);
      else if (adBary[1] < dBaryThresh)
	pVZero = pC->pVVert(1);
      else if (adBary[2] < dBaryThresh)
	pVZero = pC->pVVert(2);
      else
	pVZero = pC->pVVert(3); // (adBary[3] == 0)
      Face *pF = pC->pFFaceOpposite(pVZero);
      // Project the proposed point onto this face; this will give the
      // face circumcenter
      assert(pF->eType() == Face::eTriFace);
      if (! qForce) dynamic_cast<TriFace*>(pF)->vCircumcenter(adPoint);

      // Check barycentrics again.
      dynamic_cast<TetCell*>(pC)->vBarycentrics(adPoint, adBary);
      double dFaceBaryThresh;
      if (qForce) dFaceBaryThresh = 1.e-10;
      else        dFaceBaryThresh = 0.2;

      iLowBary = ((adBary[0] < dFaceBaryThresh ? 1 : 0) +
		  (adBary[1] < dFaceBaryThresh ? 1 : 0) +
		  (adBary[2] < dFaceBaryThresh ? 1 : 0) +
		  (adBary[3] < dFaceBaryThresh ? 1 : 0));
      if (iLowBary == 1) { // In the interior of the face
	if (!(pVNew->qValid()))
	  pVNew = createVert(adPoint);
	else
	  pVNew->vSetCoords(3, adPoint);
	*piSwaps = iInsertOnFace(pVNew, pF, pC, qSwap);
	if (*piSwaps == -1) {
	  // Tried to insert on a bdry face when bdry's are not allowed
	  // to be changed.
	  deleteVert(pVNew);
	  *piSwaps = 0;
	  return 0;
	}
	else
	  return 1;
      }
      for (int iBary = 0; iBary <= 3; iBary ++)
	if (adBary[iBary] < dFaceBaryThresh) adBary[iBary] = 0;

      assert(iLowBary == 2);
    }
    // Deliberate fallthrough if the face case becomes an edge case
  case 2:
    {
      // Must be insertion on an edge (possibly a boundary edge)
      // As with face insertion, let the callee handle the boundary case

      // Find the two verts w/ non-zero barycentrics; the new vert falls
      // on the edge between them
      Vert *pV0, *pV1;
      Face *pF;

      // Not a very elegant way to identify these things, but so what?
      if (adBary[0] < dBaryThresh) {
	if (adBary[1] < dBaryThresh) {
	  pV0 = pC->pVVert(2);
	  pV1 = pC->pVVert(3);
	}
	else if (adBary[2] < dBaryThresh) {
	  pV0 = pC->pVVert(1);
	  pV1 = pC->pVVert(3);
	}
	else {
	  pV0 = pC->pVVert(2);
	  pV1 = pC->pVVert(1);
	}
	pF  = pC->pFFaceOpposite(pC->pVVert(0));
      }
      else if (adBary[1] < dBaryThresh) {
	if (adBary[2] < dBaryThresh) {
	  pV0 = pC->pVVert(0);
	  pV1 = pC->pVVert(3);
	}
	else {
	  pV0 = pC->pVVert(2);
	  pV1 = pC->pVVert(0);
	}
	pF  = pC->pFFaceOpposite(pC->pVVert(1));
      }
      else {
	pV0 = pC->pVVert(0);
	pV1 = pC->pVVert(1);
	pF  = pC->pFFaceOpposite(pC->pVVert(2));
      }
      assert(pV0->qValid());
      assert(pV1->qValid());
      assert(pF->qValid());

      double adActual[3];
      if (qForce) {
	adActual[0] = adPoint[0];
	adActual[1] = adPoint[1];
	adActual[2] = adPoint[2];
      }
      else {
	adActual[0] = 0.5 * (pV0->dX() + pV1->dX());
	adActual[1] = 0.5 * (pV0->dY() + pV1->dY());
	adActual[2] = 0.5 * (pV0->dZ() + pV1->dZ());
      }
      if (!(pVNew->qValid()))
	pVNew = createVert(adActual);
      else 
	pVNew->vSetCoords(3, adActual);

      *piSwaps = iInsertOnEdge(pVNew, pV0, pV1, pF, qSwap);
      if (*piSwaps == -1) {
	// Tried to insert on a bdry edge when bdry's are not allowed
	// to be changed.
	deleteVert(pVNew);
	*piSwaps = 0;
	return 0;
      }
      return (1);
    } // End edge insertion case
  case 3:
    // Inserting a point that's already in the mesh; this can occur when
    // re-inserting interior structured verts if one wasn't deleted in
    // the first place.  Bail out quietly, after marking the new vertex
    // (which is the attempted duplicate) as deleted.
    if (pVNew->qValid())
      deleteVert(pVNew);
    return (0);
  default:
    assert2(0, "Invalid number of small barycentrics");
    return (0);
  } // End switch on the number of small barycentrics
} // End of point insertion
