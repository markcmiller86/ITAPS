#include "GR_config.h"
#include "GR_Classes.h"

#include "GR_BFace.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"
#include "GR_Geometry.h"

// The semantics of these calls are essentially identical to the ITAPS
// createEnt calls.
//   createFace returns a face with verts pV0 and pV1; if the face
//     already existed it might be opposite in sense, but that's OK.
//   createCell returns a cell with given faces.  In GRUMMP (though not
//     in ITAPS) that cell can't have existed already.
//   createCell returns a cell with given verts.  Faces are created as
//     needed.
//
// At present, canonical ordering of the input data is assumed for faces
// and vert->tri.  For vert->quad, it's mandatory, to prevent
// awkwardness like introducing edges on diagonals of a quad.

Face* VolMesh::createFace(bool &qAlreadyExisted,
			  Vert * const pV0, Vert * const pV1,
			  Vert * const pV2, Vert * const pV3,
			  bool qForceDuplicate)
{
  // Edge3D: For now, this happens directly.  Once edges are added,
  // Edge3D: it'll look a lot more like Mesh2D::createCell.

  // iMesh merge: need to return both the face ptr and a flag indicating
  // whether the face already existed.
  assert(pV0->qValid());
  assert(pV1->qValid());
  assert(pV2->qValid());
  Face *pF = pFInvalidFace;
  if (!pV3->qValid()) {
    // Creating a tri.
    // Check for prior existence.
    pF = findCommonFace(pV0, pV1, pV2, NULL, qForceDuplicate);
    qAlreadyExisted = (pF != pFInvalidFace);
    // If we're forcing a duplicate, we'd better have a copy already!
    assert((!qForceDuplicate) || (qAlreadyExisted));
    if (qForceDuplicate == qAlreadyExisted) {
      // Only do this if we've got a correct duplication case or a
      // correct creation case. 
      pF = pFNewFace(3);
      pF->vSetVerts(pV0, pV1, pV2);
      pF->vSetLeftCell(NULL);
      pF->vSetRightCell(NULL);
      createFaceEvent(pF);
    }
  }
  else {
    // Creating a quad.
    qSimplex = false;
    // Check for prior existence.
    pF = findCommonFace(pV0, pV1, pV2, pV3);
    qAlreadyExisted = (pF != pFInvalidFace);
    // If we're forcing a duplicate, we'd better have a copy already!
    assert((!qForceDuplicate) || (qAlreadyExisted));
    if (qForceDuplicate == qAlreadyExisted) {
      // Only do this if we've got a correct duplication case or a
      // correct creation case. 
      pF = pFNewFace(4);
      pF->vSetVerts(pV0, pV1, pV2, pV3);
      pF->vSetLeftCell(NULL);
      pF->vSetRightCell(NULL);
      createFaceEvent(pF);
    }
  }
  // No checking possible here, since the face is created before the cell...
  return pF;
}

BFace* VolMesh::createBFace(Face * const pF, BFace * const pBFOld)
{
  // Face must already exist
  assert(pF->qValid());
  BFace *pBF = pBFInvalidBFace;
  
  if (!pBFOld->qValid() || (pBFOld->eType() == Cell::eTriBFace ||
			    pBFOld->eType() == Cell::eQuadBFace)) {
    // Must have exactly one open connectivity slot for the face!
    assert((pF->pCCellLeft()->qValid() ||
	    pF->pCCellRight()->qValid()) &&
	   !(pF->pCCellLeft()->qValid() &&
	     pF->pCCellRight()->qValid()));
    
    pBF = pBFNewBFace(pF->iNumVerts());
    
    pBF->vAssign(pF);
    pF->vAddCell(pBF);
    pF->vSetFaceLoc(Face::eBdryFace);
    assert(pBF->iFullCheck());
    assert(pBF->pFFace() == pF);
    assert(pF->pCCellLeft() == pBF ||
	   pF->pCCellRight() == pBF);
  }
  else {
    // This is an internal bdry face.  The face must have cells on both sides.
    assert(pBFOld->eType() == Cell::eIntTriBFace ||
	   pBFOld->eType() == Cell::eIntQuadBFace);
    assert(pF->pCCellLeft()->qValid() &&
	   pF->pCCellRight()->qValid());

    bool qExists;
    Face *pFDup;
    if (pF->iNumVerts() == 3) {
      pFDup = createFace(qExists, pF->pVVert(0), pF->pVVert(1),
			 pF->pVVert(2), pVInvalidVert, true);
    }
    else {
      pFDup = createFace(qExists, pF->pVVert(0), pF->pVVert(1),
			 pF->pVVert(2), pF->pVVert(3), true);
    }
    assert(qExists);
    pBF = pBFNewBFace(pF->iNumVerts(), true);
    pBF->vAssign(pF, pFDup);

    Cell *pCR = pF->pCCellRight();

    pFDup->vSetLeftCell(pBF);
    pFDup->vSetRightCell(pCR);
    pF->vSetRightCell(pBF);
    pCR->vReplaceFace(pF, pFDup);

    pF->vSetFaceLoc(Face::eBdryTwoSide);
    pFDup->vSetFaceLoc(Face::eBdryTwoSide);
    assert(pBF->iFullCheck());
    assert(pCR->iFullCheck());
    assert(pF->pCCellLeft()->iFullCheck());
    assert(pFDup->pCCellRight()->iFullCheck());
  }
  
#ifndef OMIT_VERTEX_HINTS
  // Make sure that bdry verts have bdry hints
  for (int ii = pF->iNumVerts() - 1; ii >= 0; ii--) {
    pF->pVVert(ii)->vSetHintFace(pF);
  }
#endif

  // This is a really stinky way to copy bdry data, but that's what
  // works currently.

  if (pBFOld->qValid()) {
    if(pBFOld->pPatchPointer()) {
      pBF->vSetPatch (pBFOld->pPatchPointer());
    }
    else if( pBFOld->get_topological_parent() ) {
      pBF->set_topological_parent( pBFOld->get_topological_parent() );
    }
//     else {
//       vFatalError("No surface geometry stored for this boundary face",
// 		  "VolMesh::createBFace");
//     }
  }

  createBFaceEvent(pBF);
  return pBF;
}

TetCell* VolMesh::createTetCell(bool &qExistedAlready,
				Face * const pF0, Face * const pF1,
				Face * const pF2, Face * const pF3,
				const int iReg)
// This call creates a tet.
//
// Faces are stored in canonical order, even if they aren't passed that
// way.  Also, face->cell connectivity is set up as part of this
// function.
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());
  assert(pF3->qValid());

  // Set up the face->cell connectivity properly.  The canonical tet
  // looks like this, where face 3 is the bottom (see ITAPS docs):
  //
  //                3
  //               /|\         .
  //              / | \        .
  //             /  |2 \       .
  //            /   |   \      .
  //           0 - - - - 2
  //            \ 0 | 1 /
  //             \ (3) /
  //              \ | /
  //               \|/
  //                1

  assert(pF0->iNumVerts() == 3);
  assert(pF1->iNumVerts() == 3);
  assert(pF2->iNumVerts() == 3);
  assert(pF3->eType() == Face::eTriFace);

  Cell *pCCom01 = pCCommonCell(pF0, pF1);
  if (pCCom01->qValid()) {
    Cell *pCCom23 = pCCommonCell(pF2, pF3);
    if (pCCom23->qValid() && pCCom23 == pCCom01) {
      qExistedAlready = true;
      TetCell* pTC = dynamic_cast<TetCell*>(pCCom01);
      assert(pTC->qValid()); // It'd better be a tet!
      return pTC;
    }
  }
  qExistedAlready = false;

  // Each trio of faces  must have a common vert.
  Vert *apV[4];
  apV[0] = pVCommonVert(pF0, pF2, pF3);
  apV[1] = pVCommonVert(pF0, pF1, pF3);
  apV[2] = pVCommonVert(pF1, pF2, pF3);
  apV[3] = pVCommonVert(pF0, pF1, pF2);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());
  assert(apV[3]->qValid());

  TetCell *pTC = dynamic_cast<TetCell*>(pCNewCell(4));
  pTC->vSetRegion(iReg);

  int iOrient = iOrient3D(apV[0], apV[1], apV[2], apV[3]);
  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pTC->vAssign(pF0, pF1, pF2, pF3);
  }
  else {
    // Left-handed (faces 2 and 3 reversed above)
    pTC->vAssign(pF0, pF1, pF3, pF2);
  }

  if (XOR(iOrient,
	  dynamic_cast<TriFace*>(pF0)->qRightHanded(apV[0], apV[3], apV[1])))
    { 
      assert(!pF0->pCCellLeft()->qValid());
      pF0->vSetLeftCell(pTC); 
    }
  else
    { 
      assert(!pF0->pCCellRight()->qValid());
      pF0->vSetRightCell(pTC); 
    }

  if (XOR(iOrient,
	  dynamic_cast<TriFace*>(pF1)->qRightHanded(apV[1], apV[3], apV[2])))
    { 
      assert(!pF1->pCCellLeft()->qValid());
      pF1->vSetLeftCell(pTC); 
    }
  else
    { 
      assert(!pF1->pCCellRight()->qValid());
      pF1->vSetRightCell(pTC); 
    }

  if (XOR(iOrient,
	  dynamic_cast<TriFace*>(pF2)->qRightHanded(apV[2], apV[3], apV[0])))
    { 
      assert(!pF2->pCCellLeft()->qValid());
      pF2->vSetLeftCell(pTC); 
    }
  else
    {
      assert(!pF2->pCCellRight()->qValid());
      pF2->vSetRightCell(pTC); 
    }

  if (XOR(iOrient,
	  dynamic_cast<TriFace*>(pF3)->qRightHanded(apV[0], apV[1], apV[2])))
    { 
      assert(!pF3->pCCellLeft()->qValid());
      pF3->vSetLeftCell(pTC);
    }
  else
    { 
      assert(!pF3->pCCellRight()->qValid());
      pF3->vSetRightCell(pTC); 
    }

  pF0->vMarkForSwap();
  pF1->vMarkForSwap();
  pF2->vMarkForSwap();
  pF3->vMarkForSwap();

  assert(pTC->iFullCheck());
  assert(pTC->qHasFace(pF0));
  assert(pTC->qHasFace(pF1));
  assert(pTC->qHasFace(pF2));
  assert(pTC->qHasFace(pF3));
  assert(pF0->pCCellLeft() == pTC ||
	 pF0->pCCellRight() == pTC);
  assert(pF1->pCCellLeft() == pTC ||
	 pF1->pCCellRight() == pTC);
  assert(pF2->pCCellLeft() == pTC ||
	 pF2->pCCellRight() == pTC);
  assert(pF3->pCCellLeft() == pTC ||
	 pF3->pCCellRight() == pTC);

  createCellEvent(pTC);
  return pTC;
}

// Cell* VolMesh::createCell(bool &qExistedAlready,
// 			  Face * const pF0, Face * const pF1,
// 			  Face * const pF2, Face * const pF3,
// 			  Face * const pF4, const int iReg)
// // This one would be for pyramids / prisms.  Faces must be canonically
// // ordered. 
// {
//   // Faces must already exist
//   assert(pF0->qValid());
//   assert(pF1->qValid());
//   assert(pF2->qValid());
//   assert(pF3->qValid());
//   assert(pF4->qValid());

//   Cell *pC;
//   if (pF0->eType() == Face::eTriFace) {
//     // This must be a pyramid
//     assert(pF0->eType() == Face::eTriFace);
//     assert(pF1->eType() == Face::eTriFace);
//     assert(pF2->eType() == Face::eTriFace);
//     assert(pF3->eType() == Face::eTriFace);
//     assert(pF4->eType() == Face::eQuadFace);

//     pC = pCNewCell(5, 5);

//     // The pyramid looks like this:
//     //
//     //                  4
//     //                 /|\               .
//     //                / | \              .
//     //               / |\  \             .
//     //              /  / |  \            .
//     //             /  |  |   \           .
//     //            /   /  \    \          .
//     //           /   |_---3-_  \         .
//     //          0--- /       ---2        .
//     //           \_ |    ---
//     //             \1---
//     //
//     // Okay, so it's a crappy pyramid; so what?  Faces are:
//     //  0:  014
//     //  1:  124
//     //  2:  234
//     //  3:  304
//     //  4:  0123

//     Vert *apV[5];
//     pF4->vAllVertHandles(reinterpret_cast<GRUMMP_Entity**>(apV));
//     apV[4] = pF0->pVVert(0);
//     if (pF4->qHasVert(apV[4])) {
//       apV[4] = pF0->pVVert(1);
//       if (pF4->qHasVert(apV[4])) {
// 	apV[4] = pF0->pVVert(2);
//       }
//     }
//     assert(!pF4->qHasVert(apV[4]));

//     // If this orientation is negative, then surely it means that the
//     // bottom face is oriented out.
//     int iOrient = iOrient3D(apV[0], apV[1], apV[2], apV[4]);
//     assert(iOrient3D(apV[0], apV[2], apV[3], apV[4]) == iOrient);

//     if (iOrient == 1) {
//       pF4->vSetRightCell(pC);
//     }
//     else {
//       pF4->vSetLeftCell(pC);
//       Vert *pVTmp = apV[3];
//       apV[3] = apV[0];
//       apV[0] = pVTmp;
//       pVTmp = apV[2];
//       apV[2] = apV[1];
//       apV[1] = pVTmp;
//     }

//     assert(pF0->qHasVert(apV[0]) && pF0->qHasVert(apV[1]));
//     assert(pF1->qHasVert(apV[1]) && pF1->qHasVert(apV[2]));
//     assert(pF2->qHasVert(apV[2]) && pF2->qHasVert(apV[3]));
//     assert(pF3->qHasVert(apV[3]) && pF3->qHasVert(apV[0]));

//     // Assignment for the cell is invariant w/ the orientation; this is
//     // different from createTetCell, which doesn't require faces in
//     // canonical order.

//     if (dynamic_cast<TriFace*>(pF0)->qRightHanded(apV[0], apV[4], apV[1]))
//       { pF0->vSetRightCell(pC); }
//     else
//       { pF0->vSetLeftCell(pC); }

//     if (dynamic_cast<TriFace*>(pF1)->qRightHanded(apV[1], apV[4], apV[2]))
//       { pF1->vSetRightCell(pC); }
//     else
//       { pF1->vSetLeftCell(pC); }

//     if (dynamic_cast<TriFace*>(pF2)->qRightHanded(apV[2], apV[4], apV[3]))
//       { pF2->vSetRightCell(pC); }
//     else
//       { pF2->vSetLeftCell(pC); }
    
//     if (dynamic_cast<TriFace*>(pF3)->qRightHanded(apV[3], apV[4], apV[0]))
//       { pF3->vSetRightCell(pC); }
//     else
//       { pF3->vSetLeftCell(pC); }
    
//   }

//   else {
//     // This must be a prism
//     assert(pF0->eType() == Face::eQuadFace);
//     assert(pF1->eType() == Face::eQuadFace);
//     assert(pF2->eType() == Face::eQuadFace);
//     assert(pF3->eType() == Face::eTriFace);
//     assert(pF4->eType() == Face::eTriFace);

//     pC = pCNewCell(5, 6);
//   }

//   pC->vSetRegion(iReg);
  
//   // Be sure to assign these with canonical ordering.
//   pC->vAssign(pF0, pF1, pF2, pF3, pF4);
//   assert(pC->iFullCheck());
//   assert(pC->qHasFace(pF0));
//   assert(pC->qHasFace(pF1));
//   assert(pC->qHasFace(pF2));
//   assert(pC->qHasFace(pF3));
//   assert(pC->qHasFace(pF4));
//   assert(pF0->pCCellLeft() == pC ||
// 	 pF0->pCCellRight() == pC);
//   assert(pF1->pCCellLeft() == pC ||
// 	 pF1->pCCellRight() == pC);
//   assert(pF2->pCCellLeft() == pC ||
// 	 pF2->pCCellRight() == pC);
//   assert(pF3->pCCellLeft() == pC ||
// 	 pF3->pCCellRight() == pC);
//   assert(pF4->pCCellLeft() == pC ||
// 	 pF4->pCCellRight() == pC);
//   return pC;
// }

TetCell* VolMesh::createTetCell(bool &qAlreadyExisted,
				Vert * const pV, Face * const pF,
				const int iReg)
{
  // This function first creates or finds existing faces connecting the
  // vert to the three edges of the face, then uses those faces to build
  // a tet.  Orientation tests are done in assignment anyway, so doing
  // it here is a waste of time.  The only existing orientation check is
  // there to ensure that we produce canonical ordering. 
  Vert *pV0 = pF->pVVert(0);
  Vert *pV1 = pF->pVVert(1);
  Vert *pV2 = pF->pVVert(2);

  bool qExist02, qExist10, qExist21; // These values are ignored.
  Face *pF02, *pF10, *pF21;
  TetCell *pC;
  if (iOrient3D(pV, pV0, pV1, pV2) == 1) {
    pF02 = createFace(qExist02, pV0, pV2, pV);
    pF10 = createFace(qExist10, pV1, pV0, pV);
    pF21 = createFace(qExist21, pV2, pV1, pV);
    pC = createTetCell(qAlreadyExisted, pF, pF02, pF10, pF21, iReg);
  }
  else {
    pF02 = createFace(qExist02, pV2, pV0, pV);
    pF10 = createFace(qExist10, pV0, pV1, pV);
    pF21 = createFace(qExist21, pV1, pV2, pV);
    pC = createTetCell(qAlreadyExisted, pF, pF21, pF10, pF02, iReg);
  }

  // Now confirm that we've got orientation right
  Vert *apV[] = {pC->pVVert(0), pC->pVVert(1), pC->pVVert(2), pC->pVVert(3)};
  assert(iOrient3D(apV[0], apV[1], apV[2], apV[3]) == 1);
  assert(!qExist02 || (pF02->pCCellLeft()->qValid() &&
		       pF02->pCCellRight()->qValid()));
  assert(!qExist10 || (pF10->pCCellLeft()->qValid() &&
		       pF10->pCCellRight()->qValid()));
  assert(!qExist21 || (pF21->pCCellLeft()->qValid() &&
		       pF21->pCCellRight()->qValid()));
  assert(pF->pCCellLeft()->qValid() &&
	 pF->pCCellRight()->qValid());

  // Already registered the event in the low-level create tet call.
  return pC;
}

TetCell* VolMesh::createTetCell(bool &qAlreadyExisted,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3,
				const int iReg)
// This one creates tets from verts via faces.
{
  bool qExist103, qExist213, qExist023, qExist012;
  Face *pF023 = createFace(qExist023, pV0, pV2, pV3);
  Face *pF103 = createFace(qExist103, pV1, pV0, pV3);
  Face *pF213 = createFace(qExist213, pV2, pV1, pV3);
  Face *pF012 = createFace(qExist012, pV0, pV1, pV2);

  TetCell *pTC = createTetCell(qAlreadyExisted,
			       pF023, pF103, pF213, pF012, iReg);

#ifndef NDEBUG
  assert(pTC->qHasVert(pV0));
  assert(pTC->qHasVert(pV1));
  assert(pTC->qHasVert(pV2));
  assert(pTC->qHasVert(pV3));

  // Now confirm that we've got orientation right
  Vert *apV[] = {pTC->pVVert(0), pTC->pVVert(1), pTC->pVVert(2), pTC->pVVert(3)};
  assert(iOrient3D(apV[0], apV[1], apV[2], apV[3]) == 1);
#endif
  // Already registered the event in the low-level create tet call.
  return (pTC);
}

static void vQuadSetCellWithOrientation(Cell * const pC, Face * const pF,
					const Vert * const pVRef)
{
  assert(pF->eType() == Face::eQuadFace);
  // The quad, if it already exists, may be in either orientation.
  // This could also be checked topologically, and maybe should be.
  Vert *apV[4];
  pF->vAllVertHandles(reinterpret_cast<GRUMMP_Entity**>(apV));
  
  // If this orientation is negative, then surely it means that the
  // bottom face is oriented out.
  int iOrient = iOrient3D(apV[0], apV[1], apV[2], pVRef);
  assert(iOrient3D(apV[0], apV[2], apV[3], pVRef) == iOrient);

  if (iOrient == 1) {
    pF->vSetRightCell(pC);
  }
  else {
    pF->vSetLeftCell(pC);
  }
}

static void vTriSetCellWithOrientation(Cell * const pC, Face * const pF,
				       const Vert * const pVRef)
{
  assert(pF->eType() == Face::eTriFace);
  // The tri, if it already exists, may be in either orientation.
  // This could also be checked topologically, and maybe should be.
  Vert *apV[3];
  pF->vAllVertHandles(reinterpret_cast<GRUMMP_Entity**>(apV));
  
  // If this orientation is negative, then surely it means that the
  // bottom face is oriented out.
  int iOrient = iOrient3D(apV[0], apV[1], apV[2], pVRef);
  assert(iOrient != 0);

  if (iOrient == 1) {
    assert(!pF->pCCellRight()->qValid());
    pF->vSetRightCell(pC);
  }
  else {
    assert(!pF->pCCellLeft()->qValid());
    pF->vSetLeftCell(pC);
  }

  // This failed to work in some cases.
  //   // If the verts are in cyclic order for the tri face, then pC is the
  //   // right cell, otherwise the left cell.
  //   if (dynamic_cast<TriFace*>(pF)->qRightHanded(pVA, pVB, pVC))
  //     { pF->vSetRightCell(pC); }
  //   else
  //     { pF->vSetLeftCell(pC); }
}

PyrCell* VolMesh::createPyrCell(bool& qExistedAlready,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3,
				Vert * const pV4, const int iReg)
// This one creates pyramids from verts via faces.
{
  bool qExist014, qExist124, qExist234, qExist304, qExist0123;
  Face *pF014 = createFace(qExist014, pV0, pV1, pV4);
  Face *pF124 = createFace(qExist124, pV1, pV2, pV4);
  Face *pF234 = createFace(qExist234, pV2, pV3, pV4);
  Face *pF304 = createFace(qExist304, pV3, pV0, pV4);
  Face *pF0123 = createFace(qExist0123, pV0, pV1, pV2, pV3);
  assert(pF014->qValid());
  assert(pF124->qValid());
  assert(pF234->qValid());
  assert(pF304->qValid());
  assert(pF0123->qValid());

  // The pyramid looks like this:
  //
  //                  4
  //                 /|\               .
  //                / | \              .
  //               / |\  \             .
  //              /  / |  \            .
  //             /  |  |   \           .
  //            /   /  \    \          .
  //           /   |_---3-_  \         .
  //          0--- /       ---2        .
  //           \_ |    ---
  //             \1---
  //
  // Okay, so it's a crappy pyramid; so what?  Faces are:
  //  0:  014
  //  1:  124
  //  2:  234
  //  3:  304
  //  4:  0123

  // This check is a bit awkwardly written, but it tries to minimize the
  // number of calls to pCCommonCell that are actually made.
  if (qExist014 && qExist124 && qExist234 && qExist304 && qExist0123) {
    // Cell might exist already
    Cell *pCCom04 = pCCommonCell(pF014, pF304);
    if (pCCom04->qValid()) {
      Cell *pCCom24 = pCCommonCell(pF124, pF234);
      if (pCCom24->qValid() && pCCom04 == pCCom24) {
	Cell *pCCom01 = pCCommonCell(pF014, pF0123);
	if (pCCom01->qValid() && pCCom04 == pCCom01) {
	  PyrCell *pPC = dynamic_cast<PyrCell*>(pCCom01);
	  if (pPC->qValid()) {
	    qExistedAlready = true;
	    return pPC;
	  }
	}
      }
    }
  }

  qExistedAlready = false;

  PyrCell *pPC = dynamic_cast<PyrCell*>(pCNewCell(5, 5));
  assert(pPC);
  pPC->vSetRegion(iReg);
  // Be sure to assign these with canonical ordering.
  pPC->vAssign(pF014, pF124, pF234, pF304, pF0123);

  vQuadSetCellWithOrientation(pPC, pF0123, pV4);

  vTriSetCellWithOrientation(pPC, pF014, pV2);
  vTriSetCellWithOrientation(pPC, pF124, pV3);
  vTriSetCellWithOrientation(pPC, pF234, pV0);
  vTriSetCellWithOrientation(pPC, pF304, pV1);

#ifndef NDEBUG
  assert(pPC->qHasVert(pV0));
  assert(pPC->qHasVert(pV1));
  assert(pPC->qHasVert(pV2));
  assert(pPC->qHasVert(pV3));
  assert(pPC->qHasVert(pV4));

  // Now confirm that we've got orientation right
  Vert *apV[] = {pPC->pVVert(0), pPC->pVVert(1), pPC->pVVert(2), pPC->pVVert(3),
		 pPC->pVVert(4)};
  assert(iOrient3D(apV[0], apV[1], apV[2], apV[4]) == 1);
  assert(iOrient3D(apV[0], apV[2], apV[3], apV[4]) == 1);
  assert(iOrient3D(apV[0], apV[4], apV[1], apV[2]) == 1);
  assert(iOrient3D(apV[1], apV[4], apV[2], apV[3]) == 1);
  assert(iOrient3D(apV[2], apV[4], apV[3], apV[0]) == 1);
  assert(iOrient3D(apV[3], apV[4], apV[0], apV[1]) == 1);
  
  assert(pF014->pCCellLeft() == pPC ||
	 pF014->pCCellRight() == pPC);
  assert(pF124->pCCellLeft() == pPC ||
	 pF124->pCCellRight() == pPC);
  assert(pF234->pCCellLeft() == pPC ||
	 pF234->pCCellRight() == pPC);
  assert(pF304->pCCellLeft() == pPC ||
	 pF304->pCCellRight() == pPC);
  assert(pF0123->pCCellLeft() == pPC ||
	 pF0123->pCCellRight() == pPC);
#endif
  
  createCellEvent(pPC);
  return (pPC);
}

PrismCell* VolMesh::createPrismCell(bool &qExistedAlready,
				    Vert * const pV0, Vert * const pV1,
				    Vert * const pV2, Vert * const pV3,
				    Vert * const pV4, Vert * const pV5,
				    const int iReg)
// This one creates prisms from verts via faces.
{
  // Verts 0, 1, 2 form a ring around the bottom.
  // Verts 3, 4, 5 form a ring around the top.
  
  bool qExist0143, qExist1254, qExist2035, qExist012, qExist543;
  Face *pF0143 = createFace(qExist0143, pV0, pV1, pV4, pV3);
  Face *pF1254 = createFace(qExist1254, pV1, pV2, pV5, pV4);
  Face *pF2035 = createFace(qExist2035, pV2, pV0, pV3, pV5);
  Face *pF012 = createFace(qExist012, pV0, pV1, pV2);
  Face *pF543 = createFace(qExist543, pV5, pV4, pV3);

  if (qExist0143 && qExist1254 && qExist2035 && qExist012 && qExist543) {
    // Cell might exist already
    Cell *pCCom03 = pCCommonCell(pF0143, pF2035);
    if (pCCom03->qValid()) {
      Cell *pCCom12 = pCCommonCell(pF1254, pF012);
      if (pCCom12->qValid() && pCCom03 == pCCom12) {
	Cell *pCCom45 = pCCommonCell(pF1254, pF543);
	if (pCCom45->qValid() && pCCom03 == pCCom45) {
	  PrismCell *pPC = dynamic_cast<PrismCell*>(pCCom03);
	  if (pPC->qValid()) {
	    qExistedAlready = true;
	    return pPC;
	  }
	}
      }
    }
  }

  qExistedAlready = false;

  PrismCell *pPC = dynamic_cast<PrismCell*>(pCNewCell(5, 6));
  assert(pPC);
  pPC->vSetRegion(iReg);
  // Be sure to assign these with canonical ordering.
  pPC->vAssign(pF0143, pF1254, pF2035, pF012, pF543);

  vQuadSetCellWithOrientation(pPC, pF0143, pV2);
  vQuadSetCellWithOrientation(pPC, pF1254, pV0);
  vQuadSetCellWithOrientation(pPC, pF2035, pV1);

  vTriSetCellWithOrientation(pPC, pF012, pV3);
  vTriSetCellWithOrientation(pPC, pF543, pV0);

  assert(pF0143->pCCellLeft() == pPC ||
	 pF0143->pCCellRight() == pPC);
  assert(pF1254->pCCellLeft() == pPC ||
	 pF1254->pCCellRight() == pPC);
  assert(pF2035->pCCellLeft() == pPC ||
	 pF2035->pCCellRight() == pPC);
  assert(pF012->pCCellLeft() == pPC ||
	 pF012->pCCellRight() == pPC);
  assert(pF543->pCCellLeft() == pPC ||
	 pF543->pCCellRight() == pPC);

  assert(pPC->qHasVert(pV0));
  assert(pPC->qHasVert(pV1));
  assert(pPC->qHasVert(pV2));
  assert(pPC->qHasVert(pV3));
  assert(pPC->qHasVert(pV4));
  assert(pPC->qHasVert(pV5));

  createCellEvent(pPC);
  return pPC;
}

HexCell* VolMesh::createHexCell(bool &qExistedAlready,
				Vert * const pV0, Vert * const pV1,
				Vert * const pV2, Vert * const pV3,
				Vert * const pV4, Vert * const pV5,
				Vert * const pV6, Vert * const pV7,
				const int iReg)
// This one creates prisms from verts via faces.
{
  // Verts 0, 1, 2, 3 form a ring around the bottom.
  // Verts 4, 5, 6, 7 form a ring around the top.
  
  bool qExist0123, qExist7654, qExist0154, qExist1265, qExist2376, qExist3047;
  Face *pF0123 = createFace(qExist0123, pV0, pV1, pV2, pV3);
  Face *pF7654 = createFace(qExist7654, pV7, pV6, pV5, pV4);
  Face *pF0154 = createFace(qExist0154, pV0, pV1, pV5, pV4);
  Face *pF1265 = createFace(qExist1265, pV1, pV2, pV6, pV5);
  Face *pF2376 = createFace(qExist2376, pV2, pV3, pV7, pV6);
  Face *pF3047 = createFace(qExist3047, pV3, pV0, pV4, pV7);

  if (qExist0123 && qExist7654 && qExist0154 &&
      qExist1265 && qExist2376 && qExist3047) {
    // Cell might exist already.
    Cell *pCCom01 = pCCommonCell(pF0123, pF0154);
    if (pCCom01->qValid()) {
      Cell *pCCom26 = pCCommonCell(pF1265, pF2376);
      if (pCCom26->qValid() && pCCom01 == pCCom26) {
	Cell *pCCom47 = pCCommonCell(pF7654, pF3047);
	if (pCCom47->qValid() && pCCom01 == pCCom47) {
	  HexCell *pHC = dynamic_cast<HexCell*>(pCCom01);
	  if (pHC->qValid()) {
	    qExistedAlready = true;
	    return pHC;
	  }
	}
      }
    }
  }

  qExistedAlready = false;

  HexCell *pHC = dynamic_cast<HexCell*>(pCNewCell(6, 8));
  assert(pHC);
  pHC->vSetRegion(iReg);
  // Be sure to assign these with canonical ordering.
  pHC->vAssign(pF0123, pF0154, pF1265, pF2376, pF3047, pF7654);

  vQuadSetCellWithOrientation(pHC, pF0123, pV4);
  vQuadSetCellWithOrientation(pHC, pF7654, pV0);
  vQuadSetCellWithOrientation(pHC, pF0154, pV2);
  vQuadSetCellWithOrientation(pHC, pF1265, pV3);
  vQuadSetCellWithOrientation(pHC, pF2376, pV4);
  vQuadSetCellWithOrientation(pHC, pF3047, pV1);

  assert(pF0123->qHasCell(pHC));
  assert(pF7654->qHasCell(pHC));
  assert(pF0154->qHasCell(pHC));
  assert(pF1265->qHasCell(pHC));
  assert(pF2376->qHasCell(pHC));
  assert(pF3047->qHasCell(pHC));

  assert(pHC->qHasVert(pV0));
  assert(pHC->qHasVert(pV1));
  assert(pHC->qHasVert(pV2));
  assert(pHC->qHasVert(pV3));
  assert(pHC->qHasVert(pV4));
  assert(pHC->qHasVert(pV5));
  assert(pHC->qHasVert(pV6));
  assert(pHC->qHasVert(pV7));

  createCellEvent(pHC);
  return pHC;
}

bool VolMesh::deleteCell(Cell * const pC)
{
  if (pC->qDeleted()) return true;
  isOKToSend(false);
  // Free up connectivity for faces.
  for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pC->pFFace(i);
    if (pF->qValid())
      pF->vRemoveCell(pC);
    if (!pF->pCCellLeft()->qValid() &&
	!pF->pCCellRight()->qValid()) {
      deleteFace(pF);
    }
  }
  // Under the old data structures, just mark it.
  pC->vMarkDeleted();
  // With the new (2010) containers, also register the deletion with the
  // container.
  switch (pC->eType()) {
  case CellSkel::eTet:
    ECTet.deleteEntry(static_cast<TetCell*>(pC));
    break;
  case CellSkel::ePyr:
    ECPyr.deleteEntry(static_cast<PyrCell*>(pC));
    break;
  case CellSkel::ePrism:
    ECPrism.deleteEntry(static_cast<PrismCell*>(pC));
    break;
  case CellSkel::eHex:
    ECHex.deleteEntry(static_cast<HexCell*>(pC));
    break;
  default:
    assert(0);
    break;
  }
  isOKToSend(true);
  deleteCellEvent(pC);
  return true;
}

// This function is not technically necessary, under the old data
// structures; deleteCell would work fine, too.
bool VolMesh::deleteBFace(BFace * const pBF)
{
  // Under the old data structures, just mark it.
  Face *pF = pBF->pFFace();
  if (pF->qValid()) {
    pF->vRemoveCell(pBF);
    if (!pF->pCCellLeft()->qValid() &&
	!pF->pCCellRight()->qValid()) {
      deleteFace(pF);
    }
  }

  if (pBF->iNumFaces() == 2 && pBF->pFFace(1)->qValid()) {
    pF = pBF->pFFace(1);
    pF->vRemoveCell(pBF);
    if (!pF->pCCellLeft()->qValid() &&
	!pF->pCCellRight()->qValid()) {
      deleteFace(pF);
    }
  }
    
  pBF->vMarkDeleted();
  // With the new (2010) containers, also register the deletion with the
  // container.
  switch (pBF->eType()) {
  case CellSkel::eTriBFace:
    ECTriBF.deleteEntry(static_cast<TriBFace*>(pBF));
    break;
  case CellSkel::eQuadBFace:
    ECQuadBF.deleteEntry(static_cast<QuadBFace*>(pBF));
    break;
  case CellSkel::eIntTriBFace:
    ECIntTriBF.deleteEntry(static_cast<IntTriBFace*>(pBF));
    break;
  case CellSkel::eIntQuadBFace:
    ECIntQuadBF.deleteEntry(static_cast<IntQuadBFace*>(pBF));
    break;
  default:
    assert(0);
    break;
  }
  deleteBFaceEvent(pBF);
  return true;
}

// Like ITAPS, faces that are in use can't be deleted.
bool VolMesh::deleteFace(Face * const pF)
{
  assert(!pF->qDeleted());
  // Make sure that verts whose hint is going away realize it...
  for (int iV = pF->iNumVerts() - 1; iV >= 0; iV--) {
    Vert *pV = pF->pVVert(iV);
    if (pV->qDeleted()) continue;
    pV->vRemoveFace(pF);
#ifndef OMIT_VERTEX_HINTS
    if (pV->pFHintFace() == pF) {
      pV->vUpdateHintFace();
    }
#endif
  }

  // Under the old data structures, just mark it.
  if (!pF->pCCellLeft()->qValid() && !pF->pCCellRight()->qValid()) {
    pF->vMarkDeleted();
    // With the new (2010) containers, also register the deletion with the
    // container.
    switch (pF->eType()) {
    case Face::eTriFace:
      ECTriF.deleteEntry(static_cast<TriFace*>(pF));
      break;
    case Face::eQuadFace:
      ECQuadF.deleteEntry(static_cast<QuadFace*>(pF));
      break;
    default:
      assert(0);
      break;
    }
    deleteFaceEvent(pF);
    return true;
  }
  else {
    return false;
  }
}

Vert* VolMesh::createVert(const double dX, const double dY, const double dZ)
{
  double adData[] = {dX, dY, dZ};
  return createVert(adData);
}

Vert* VolMesh::createVert(const double adCoords[])
{
  Vert *pV = pVNewVert();
  pV->vClearHintFace();
  pV->vClearFaceConnectivity();
  pV->vSetDefaultFlags();
  pV->vSetCoords(3, adCoords);
  createVertEvent(pV);
  return pV;
}

Vert* VolMesh::createVert(const Vert* pVIn)
{
  Vert *pV = pVNewVert();
  *pV = *pVIn;
  pV->vClearHintFace();
  pV->vClearFaceConnectivity();
  createVertEvent(pV);
  return pV;
}

bool VolMesh::deleteVert(Vert * const pV)
// Again, verts that are in use can't be deleted without forcing that.
{
  if (pV->iNumFaces() == 0) {
    // Under the old data structures, just mark it.
    pV->vMarkDeleted();
    ECVerts.deleteEntry(pV);
    deleteVertEvent(pV);
    return true;
  }
  else {
    return false;
  }
}
