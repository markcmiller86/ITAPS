#include "GR_TetMeshRefiner.h"

#include "GR_config.h"
#include "GR_BFace.h"
#include "GR_BFace3D.h"
#include "GR_Cell.h"
#include "GR_events.h"
#include "GR_Functors.h"
#include "GR_GeomComp.h"
#include "GR_Geometry.h"
#include "GR_Length3D.h"
#include "GR_Mesh.h"
#include "GR_Subseg.h"
#include "GR_SubsegManager.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

#include <algorithm>
#include <functional>
#include <iterator>
#include <map>
#include <queue>
#include <set>
#include <utility>
#include <vector>

using std::deque;
using std::map;
using std::multimap;
using std::pair;
using std::queue;
using std::set;
using std::vector;

SubsegMap::~SubsegMap() {

  //If the m_to_release vector is not empty, start by releasing its content.
  release_deleted_subsegs();

  //The subsegments left in the map must be deleted.
  //They were instantiated elsewhere. Subseg entries appear
  //in more than one key, we need to filter these first.

  SubsegSet to_delete;  
  SubsegMapType::iterator it = m_map.begin(), it_end = m_map.end();

  for( ; it != it_end; ++it)
    std::copy( it->second.begin(), it->second.end(), 
	       std::inserter(to_delete, to_delete.begin()) );

  //All remaining subsegs are in the to_delete set. Let's delete.
  std::for_each( to_delete.begin(), to_delete.end(), GRUMMP::DeleteObject() );

  m_map.clear();

}

void SubsegMap::release_deleted_subsegs() { 

#ifndef NDEBUG  
  vector<Subseg*>::iterator it = m_to_release.begin(), it_end = m_to_release.end();
  for( ; it != it_end; ++it) assert( (*it)->is_deleted() );
#endif

  std::for_each(m_to_release.begin(), m_to_release.end(), GRUMMP::DeleteObject());
  m_to_release.clear();

}

void SubsegMap::add_subseg(Subseg* const subseg) {

  assert( subseg );
  Vert *vert0 = subseg->get_beg_vert(), *vert1 = subseg->get_end_vert();

#ifndef NDEBUG

  assert( vert0 && vert1 );
  assert( vert0 != vert1 );
  assert( !vert0->qDeleted() );
  assert( !vert1->qDeleted() );
  assert( vert0->iVertType() == Vert::eBdryApex ||
	  vert0->iVertType() == Vert::eBdryCurve );
  assert( vert1->iVertType() == Vert::eBdryApex ||
	  vert1->iVertType() == Vert::eBdryCurve );
  
  set<Cell*> neigh_cells; set<Vert*> neigh_verts;
  vNeighborhood(vert0, neigh_cells, neigh_verts);
  assert(neigh_verts.count(vert1) == 1);

#endif

  SubsegMapType::iterator 
    it0 = m_map.insert( std::make_pair( vert0, SubsegSet() ) ).first,
    it1 = m_map.insert( std::make_pair( vert1, SubsegSet() ) ).first;

  it0->second.insert(subseg);
  it1->second.insert(subseg);

  assert( it0->first == vert0 );
  assert( it1->first == vert1 );
  assert( it0->second.count(subseg) == 1 );
  assert( it1->second.count(subseg) == 1 );

}

void SubsegMap::remove_subseg(Subseg* const subseg) {

  assert( subseg );
  Vert *vert[] = { subseg->get_beg_vert(), subseg->get_end_vert() };

  assert( vert[0] && vert[1] );
  assert( vert[0] != vert[1] );
  assert( vert[0]->iVertType() == Vert::eBdryApex ||
	  vert[0]->iVertType() == Vert::eBdryCurve );
  assert( vert[1]->iVertType() == Vert::eBdryApex ||
	  vert[1]->iVertType() == Vert::eBdryCurve );

  //Erase the two entries:
  SubsegMapType::iterator it;

  for(int i = 0; i < 2; ++i) {

    it = m_map.find( vert[i] );
    assert( it != m_map.end() );             //vertex must be in map.
    assert( it->second.count(subseg) == 1 ); //subseg must be connected to vert.

    it->second.erase(subseg);
    if( it->second.empty() ) m_map.erase(it);

  }

  //Finally, move the subseg into the m_to_release vector. We do
  //not want to release the memory right now as the Subseg might still
  //be stored in the TetMeshRefiner::m_subseg_queue.
  assert(subseg->is_deleted());
  m_to_release.push_back(subseg);

//   for(vector<Subseg*>::iterator its = m_to_release.begin(); its != m_to_release.end(); ++its) {
//     Subseg* my_sub = *its;
//     printf("Subseg %p, deleted = %d\n", my_sub, my_sub->is_deleted());
//   }

}

bool SubsegMap::vert_has_subseg(Vert* const vertex, 
				Subseg* const subseg) const {

  assert( vertex);
  assert( !vertex->qDeleted() );
  assert( vertex->iVertType() == Vert::eBdryApex ||
	  vertex->iVertType() == Vert::eBdryCurve );

  SubsegMapType::const_iterator it = m_map.find(vertex);
  assert( it != m_map.end() );

  return ( it->second.count(subseg) == 1 );

}

Subseg* SubsegMap::verts_are_connected(Vert* const vert0, 
				       Vert* const vert1) const {
    
  assert( vert0 && vert1 );
  assert( vert0 != vert1 );
  assert( !vert0->qDeleted() );
  assert( !vert1->qDeleted() );

  //If either of the vertices is not at an apex or on 
  //a curve, then it definitely cannot be part of a subsegment.
  if( vert0->iVertType() != Vert::eBdryApex &&
      vert0->iVertType() != Vert::eBdryCurve ) {
    assert( m_map.find(vert0) == m_map.end() );
    return static_cast<Subseg*>(NULL);
  }
  else if( vert1->iVertType() != Vert::eBdryApex &&
	   vert1->iVertType() != Vert::eBdryCurve ) {
    assert( m_map.find(vert1) == m_map.end() );
    return static_cast<Subseg*>(NULL);
  }
  
  //If we get to this point, then both vertices must be at 
  //an apex or on a curve.
  assert( (vert0->iVertType() == Vert::eBdryApex ||
	   vert0->iVertType() == Vert::eBdryCurve) &&
	  (vert1->iVertType() == Vert::eBdryApex ||
	   vert1->iVertType() == Vert::eBdryCurve) ); 

  SubsegMapType::const_iterator it = m_map.find(vert0);
  
  //If vert0 is not in the map, then for sure there are
  //no subsegment connecting vert0 to vert1;
  if( it == m_map.end() ) {
#ifndef NDEBUG 
    it = m_map.find(vert1);
    if(it != m_map.end() ) 
      assert( std::find_if( it->second.begin(), it->second.end(),
			    SubsegHasVert(vert0) ) == it->second.end() );
#endif
    return static_cast<Subseg*>(NULL);
  }

  SubsegSet::const_iterator its = std::find_if( it->second.begin(), it->second.end(),
						SubsegHasVert(vert1) );

  Subseg* ret_subseg = its != it->second.end() ? *its : static_cast<Subseg*>(NULL);

#ifndef NDEBUG

  if(ret_subseg) {

    assert( ret_subseg->has_vert(vert0) );
    assert( ret_subseg->has_vert(vert1) );
    //Make sure these two verts are connected in the mesh.
    set<Cell*> neigh_cells; set<Vert*> neigh_verts;
    vNeighborhood( vert0, neigh_cells, neigh_verts );
    assert( neigh_verts.count(vert1) == 1 );

  }

#endif

  return ret_subseg;

}

const set<Subseg*>& SubsegMap::get_subsegs(Vert* const vert0) const {

  assert( vert0 );
  assert( !vert0->qDeleted() );
  assert( vert0->iVertType() == Vert::eBdryApex ||
	  vert0->iVertType() == Vert::eBdryCurve );
   
  assert( m_map.count(vert0) == 1 );
  return m_map.find(vert0)->second;
 
} 

pair<SubsegMap::SubsegSet::const_iterator, 
     SubsegMap::SubsegSet::const_iterator> SubsegMap::get_subseg_range(Vert* const vert0) const {

  assert( vert0 );
  assert( !vert0->qDeleted() );
  assert( vert0->iVertType() == Vert::eBdryApex ||
	  vert0->iVertType() == Vert::eBdryCurve );

  SubsegMapType::const_iterator it = m_map.find(vert0);
  assert( it != m_map.end() );

  return std::make_pair(it->second.begin(), it->second.end());

}

void SubsegMap::get_all_subsegs(set<Subseg*>& all_subsegs) const {

  all_subsegs.clear();

  SubsegMapType::const_iterator it = m_map.begin(), it_end = m_map.end();

  for( ; it != it_end; ++it)
    all_subsegs.insert( it->second.begin(), it->second.end() ); 

}

void SubsegMap::get_connected_verts( Vert* const vert0, 
				     vector<Vert*>& verts ) const {

  assert( vert0 );
  assert( !vert0->qDeleted() );
  assert( vert0->iVertType() == Vert::eBdryApex ||
	  vert0->iVertType() == Vert::eBdryCurve );
  
  assert( m_map.count(vert0) == 1);
  
  Subseg* subseg;
  const SubsegSet subseg_set = get_subsegs(vert0);
  SubsegSet::const_iterator it = subseg_set.begin(), it_end = subseg_set.end();

  for( ; it != it_end; ++it) {

    subseg = *it;
    assert( subseg->has_vert(vert0) );
    
    verts.push_back( vert0 == subseg->get_beg_vert() ? 
		     subseg->get_end_vert() : subseg->get_beg_vert() );

  }
    
}

void SubsegMap::update_vert_data_after_purge(const map<Vert*, Vert*>& vert_map) {

  //Start by releasing the deleted subsegments, if any.
  release_deleted_subsegs();

  //Since all (or most of) the keys in the map changed,
  //we might as well rebuild the entire map.
  Subseg* subseg;
  Vert* old_vert, *new_vert;
  SubsegSet::iterator its, its_end;
  SubsegMapType updated_map;
  SubsegMapType::iterator itm = m_map.begin(), itm_end = m_map.end();

  for( ; itm != itm_end; ++itm) {

    old_vert = itm->first;
    assert(vert_map.count(old_vert) == 1);
    new_vert = vert_map.find(old_vert)->second;

    its = itm->second.begin();
    its_end = itm->second.end();

    for( ; its != its_end; ++its) {
      subseg = *its;
      assert(subseg->is_not_deleted());
      subseg->replace_vert(old_vert, new_vert);      
    }

    updated_map.insert( std::make_pair(new_vert, itm->second) );

  }

  //Swap the updated map with the old map and check validity.
  updated_map.swap(m_map);
  assert(valid());

}

//Checks the validity of the map entries.
bool SubsegMap::valid() const {

  Vert *vert0, *vert1;
  Subseg* subseg;
  SubsegMapType::const_iterator it = m_map.begin(), it_end = m_map.end(), it_tmp;
  SubsegSet::const_iterator its, its_end;

  set<Cell*> neigh_cells;
  set<Vert*> neigh_verts;

  //Go through all vertices stored in the map.

  for( ; it != it_end; ++it) {

    vert0 = it->first;
    
    //The 
    switch ( vert0->iVertType() ) {
    case Vert::eBdryApex:
      break;
    case Vert::eBdryCurve:
      if( it->second.size() != 2 ) return false;
      break;
    default:
      return false;
    }

    vNeighborhood(vert0, neigh_cells, neigh_verts);

    ///Check all subsegs connected to vert0 for validity.

    its     = it->second.begin();
    its_end = it->second.end();
    
    for( ; its != its_end; ++its ) {
 
      subseg = *its;
      assert( subseg->get_beg_vert() );
      assert( subseg->get_end_vert() );

      if( !subseg->has_vert(vert0) ) return false;
      
      //Obviously, the two vertices stored in the subseg 
      //must be different.
      vert1 = vert0 == subseg->get_beg_vert() ? 
	subseg->get_end_vert() : subseg->get_beg_vert();
      if( vert0 == vert1 ) return false;

      //The same subseg must have an entry in the map both
      //for vert0 and vert1.
      it_tmp = m_map.find(vert1);
      if( it_tmp == m_map.end() ) return false;
      if( it_tmp->second.count(subseg) != 1 ) return false;

      //If there is a subseg, then the two verts must 
      //also be connected in the mesh.
      if( neigh_verts.count(vert1) != 1 ) return false;

    }

  }

  return true;

}

void SubsegMap::print() const {

  Vert* vert;
  Subseg* subseg;
  SubsegMapType::const_iterator it = m_map.begin(), it_end = m_map.end();
  SubsegSet::const_iterator its, its_end;

  for( ; it != it_end; ++it) {
    
    vert = it->first;
    printf("Vert: %p - type = %d\n", vert, vert->iVertType());

    its = it->second.begin();
    its_end = it->second.end();

    for( ; its != its_end; ++its) {

      subseg = *its;
      printf("    Subseg: %p   Verts: %p %p, deleted: %d\n", subseg, 
	     subseg->get_beg_vert(), subseg->get_end_vert(), subseg->is_deleted());

    }
    
  }

}

PriorityCalculator::~PriorityCalculator() { }

void PriorityCalculator::set_length_calculator(Length3D* const length) {

  assert( length );
  m_length = length;
  
}

void PriorityCalculator::compute_priority(const Cell* const cell,
					  double& length_prio, double& shape_prio) const {

  //Start by computing the size priority.
  length_prio = compute_length_priority(cell);

  //If length_prio == 0, then we will queue based on
  //shape quality (i.e. size is correct). Otherwise, cell is either
  //too big (length_prio > 0.), or too small (this should only
  //happens around small angles, length_prio < 0.).

  if( iFuzzyComp(length_prio, 0.) != 0 ) {
    shape_prio = -LARGE_DBL;
    return;
  }

  switch( m_type ) {
  
  case EDGE_RADIUS:

    //The inverse of the classical circumradius-to-shortest edge ratio.
    //Use the inverse so that the lowest value will be the worst quality (not the inverse).
    //Leaves slivers behind, but comes with a termination guarantee.

    //For a regular tetrahedron, the ratio is 1. / sqrt(3./8.), 
    //which is the maximum achievable value (and best possible quality). 
    //The value returned by the function is scaled by this number 
    //so that it is between 0 and 1.

    shape_prio = edge_radius_ratio(cell);
    break;

  case SIN_DIHED:

    //The minimum sine of a tet's six dihedreal angles.
    //Leaves behind needle tets.

    //Obviously, returns values between 0 and 1, so no need to normalize.
    //Best possible quality is sin(arccos(1./3.)).

    shape_prio = min_sin_dihed(cell);
    break;

  case BIAS_SIN_DIHED:

    //A biased version of the minimum sine of a tet's dihedral angles neasure. 
    //Exactly like the minimum sine measure, but if a dihedral angle is obtuse, 
    //multiply its sine by 0.7, therefore penalizing large dihedral angles 
    //without affecting small diheds.

    //Values are between 0 and 1.

    shape_prio = bias_min_sin_dihed(cell);
    break;

  case VOLUME_LENGTH:

    //The volume-length measure: (6*sqrt(2)) * Volume / (length(rms))^3
    //Proposed by Parthasarathy, Graichen and Hathaway.
    //Values are between 0 and 1.

    shape_prio = volume_length(cell);
    break;

  case NORMALIZED_SHAPE_RATIO:

    //This is basically the inradius to circumradius ratio
    //with a normalization factor.
    //Returns 3 * inradius / circumradius. Scaled this way, the ratio
    //is always between 0 and 1 ( == 1 for a regular tet).
    //Proposed by Cavendish, Field and Frey...
    //or is it David A. Field, A generic Delaunay triangulation algorithm 
    //for finite element meshes. (1991)

    shape_prio = normalized_shape_ratio(cell);
    break;

  case MIN_SOLID:

    //The minimum solid angle of a tetrahedron.
    //A regular tet has a min solid angle of 3 * acos(1./3.) - M_PI
    //and the value returned is scaled with this ideal value so that the
    //return value is between 0 an 1.

    shape_prio = min_solid(cell);
    break;

  case MEAN_RATIO:

    //The mean ratio as defined by Liu and Joe.
    //Value is between 0 and 1.

    shape_prio = mean_ratio(cell);
    break;

  case VOLUME_AREA_RATIO:

    //A measure that relates the volume of the tet 
    //to the area of its faces. Proposed by 
    //Cougny, Shephard and Georges, Explicit node point 
    //smoothing within the octree mesh generator (1990)

    shape_prio = volume_area_ratio(cell);
    break;

  case INRAD_ALTITUDE:

    //Ratio of the inradius to the longest altitude. Might
    //be a bit costly to compute.

    shape_prio = inrad_altitude_ratio(cell);
    break;

  case INRAD_LENGTH:
    
    //Ratio of the inradius to the longest edge.

    shape_prio = inrad_longest_edge_ratio(cell);
    break;

  default: 
    vFatalError("Invalid priority type", 
		"PriorityCalculator::compute_priority");
    return;
  
  }

}

double PriorityCalculator::compute_length_priority(const Cell* const cell) const {

  if( !m_length ) return 0.;

  assert(cell && cell->qValid() && !cell->qDeleted());
  assert(cell->eType() == Cell::eTet);
  assert(cell->iNumVerts() == 4);

  double current_size = (2. / sqrt(3.)) * cell->dCircumradius();
  double target_size = 0.;

  const Vert* vert;
  double vert_ls;

  for(int ii = 0; ii < 4; ++ii) {

    vert = cell->pVVert(ii);
    //If vert is at the apex of a small angle, bail out right now.
    if(vert->small_angle_vert()) {
      assert(vert->iVertType() == Vert::eBdryApex);
      return -LARGE_DBL;
    }

    vert_ls = vert->dLS();
    assert( vert_ls > 0. );

    target_size += vert_ls;
	  
  }

  //divide it by the number of vertices.
  target_size *= 0.25;

  if (current_size > target_size)
    return current_size / target_size;
  
  else if ( current_size < target_size / 15. )
    //This hack to prevent cascading refinement
    //near small angle in the input. 
    return -LARGE_DBL;
  
  else //Size is correct, returns 0. so we do not queue solely based on size.
    return 0.;
  
}

double PriorityCalculator::edge_radius_ratio(const Cell* const cell) {

  //Scale the ratio by sqrt(3/8) so that it is between 0 and 1.

  assert(cell->eType() == Cell::eTet);

  return ( sqrt(0.375) * cell->dShortestEdgeLength() / cell->dCircumradius() );
  
}

double PriorityCalculator::min_sin_dihed(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);
  double all_diheds[6], mini_sin_dihed = LARGE_DBL;
  int i, num_diheds;

  //Get the dihedral angles in radians.
  cell->vAllDihed(all_diheds, &num_diheds, false);
  
  for(i = 0; i < num_diheds; ++i)
    mini_sin_dihed = std::min( mini_sin_dihed, sin(all_diheds[i]) );

  return mini_sin_dihed;

}

double PriorityCalculator::bias_min_sin_dihed(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);
  double all_diheds[6], mini_sin_dihed = LARGE_DBL;
  int i, num_diheds;

  //Get the dihedral angles in radians.
  cell->vAllDihed(all_diheds, &num_diheds, false);
  
  for(i = 0; i < num_diheds; ++i) {
    if(all_diheds[i] > 90.)
      mini_sin_dihed = std::min( mini_sin_dihed, 0.7 * sin(all_diheds[i]) );
    else
      mini_sin_dihed = std::min( mini_sin_dihed, sin(all_diheds[i]) );
  }

  return mini_sin_dihed;

}

double PriorityCalculator::volume_length(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);

  double 
    edge0[] = adDIFF3D(cell->pVVert(0)->adCoords(), cell->pVVert(1)->adCoords()),
    edge1[] = adDIFF3D(cell->pVVert(0)->adCoords(), cell->pVVert(2)->adCoords()),
    edge2[] = adDIFF3D(cell->pVVert(0)->adCoords(), cell->pVVert(3)->adCoords()), 
    edge3[] = adDIFF3D(cell->pVVert(1)->adCoords(), cell->pVVert(2)->adCoords()),
    edge4[] = adDIFF3D(cell->pVVert(1)->adCoords(), cell->pVVert(3)->adCoords()),
    edge5[] = adDIFF3D(cell->pVVert(2)->adCoords(), cell->pVVert(3)->adCoords());

  double length = sqrt( (1./6.) * (dMAG3D_SQ(edge0) + dMAG3D_SQ(edge1) + dMAG3D_SQ(edge2) + 
				   dMAG3D_SQ(edge3) + dMAG3D_SQ(edge4) + dMAG3D_SQ(edge5)) );

  return ( (6. * sqrt(2.) * cell->dSize()) / (length * length * length) );

}

double PriorityCalculator::min_solid(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);
  double all_solids[4], mini_solid = LARGE_DBL;
  int i, num_solids;
  
  //Get the solid angles in steradians.
  cell->vAllSolid(all_solids, &num_solids, false);

  for(i = 0; i < num_solids; ++i)
    mini_solid = std::min(mini_solid, all_solids[i]);

  //Scale by 3 * GR_acos(1./3.) - M_PI, the min solid for a regular tet.
  double scale = 3 * GR_acos(1./3.) - M_PI;

  return (mini_solid / scale);

}

double PriorityCalculator::normalized_shape_ratio(const Cell* const cell) {

  //Returns 3 * inradius / circumradius. Scaled this way, the ratio
  //is always between 0 and 1 ( == 1 for a regular tet).
  //Proposed by Cavendish, Field and Frey.

  assert(cell->eType() == Cell::eTet);
  return 3. * cell->dInradius() / cell->dCircumradius();

}

double PriorityCalculator::mean_ratio(const Cell* const cell) {

  //This measure is proposed in A. Liu and B. Joe (1994)

  assert(cell->eType() == Cell::eTet);
  double volume = cell->dSize();
  double sum_length_squared = 0.;
  const Vert *v0, *v1;

  for(int i = 0; i < 6; ++i) {

    switch(i) {
    case 0: v0 = cell->pVVert(0); v1 = cell->pVVert(1); break;
    case 1: v0 = cell->pVVert(0); v1 = cell->pVVert(2); break;
    case 2: v0 = cell->pVVert(0); v1 = cell->pVVert(3); break;
    case 3: v0 = cell->pVVert(1); v1 = cell->pVVert(2); break;
    case 4: v0 = cell->pVVert(1); v1 = cell->pVVert(3); break;
    case 5: v0 = cell->pVVert(2); v1 = cell->pVVert(3); break;
    }

    sum_length_squared += dDIST_SQ_3D(v0->adCoords(), v1->adCoords());

  }

  return ( 12. * ( pow(3. * volume, 2./3.) ) / sum_length_squared );

}

double PriorityCalculator::volume_area_ratio(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);
  
  double volume = cell->dSize();
  double sum_area_sq = 0., area;

  const Face* face;

  for(int i = 0; i < 4; ++i) {
    face = cell->pFFace(i);
    assert(face->qValid() && !face->qDeleted());
    area = face->dSize();
    sum_area_sq += area*area;
  }

  return ( 2187. * (volume*volume*volume*volume) / (sum_area_sq*sum_area_sq*sum_area_sq) );

}

double PriorityCalculator::inrad_altitude_ratio(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);

  double altitude = -LARGE_DBL;
  double proj[3], diff[3];

  const Face* face;
  const Vert* vert0, *vert1, *vert2, *vert3;

  for(int i = 0; i < 4; ++i) {

    face = cell->pFFace(i);
    assert(face->qValid() && !face->qDeleted());

    vert0 = cell->pVVertOpposite(face);
    vert1 = face->pVVert(0);
    vert2 = face->pVVert(1);
    vert3 = face->pVVert(2);

    project_point_to_plane(vert0->adCoords(), vert1->adCoords(), 
			   vert2->adCoords(), vert3->adCoords(), proj);

    diff[0] = vert0->dX() - proj[0];
    diff[1] = vert0->dY() - proj[1];
    diff[2] = vert0->dZ() - proj[2];
    altitude = std::max(altitude, dMAG3D(diff));

  }

  return (4. * cell->dInradius() / altitude);

}

double PriorityCalculator::inrad_longest_edge_ratio(const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);

  double long_edge = -LARGE_DBL;
  const Vert *v0, *v1;

  for(int i = 0; i < 6; ++i) {

    switch(i) {
    case 0: v0 = cell->pVVert(0); v1 = cell->pVVert(1); break;
    case 1: v0 = cell->pVVert(0); v1 = cell->pVVert(2); break;
    case 2: v0 = cell->pVVert(0); v1 = cell->pVVert(3); break;
    case 3: v0 = cell->pVVert(1); v1 = cell->pVVert(2); break;
    case 4: v0 = cell->pVVert(1); v1 = cell->pVVert(3); break;
    case 5: v0 = cell->pVVert(2); v1 = cell->pVVert(3); break;
    }

    long_edge = std::max(long_edge, dDIST_SQ_3D(v0->adCoords(), v1->adCoords()));

  }

  return (2. * sqrt(6.) * cell->dInradius() / sqrt(long_edge));

}

RefinementQueue::~RefinementQueue() {

  if(m_calculator) delete m_calculator;
  empty_queue();

}

Cell* RefinementQueue::get_top_valid_cell() {

  if(empty()) return static_cast<Cell*>(NULL);

  while( top()->deleted() ) {
    if( !pop_top_entry() ) return static_cast<Cell*>(NULL);
  }

  assert( !top()->get_cell()->qDeleted() );
  return top()->get_cell();    

}

bool RefinementQueue::pop_top_entry() {

  if( !empty() ) {
    if( top() ) delete top();
    pop();
    return true;
  }

  return false;

}

void RefinementQueue::add_entry(Cell* const cell) {

  double length_prio, shape_prio;
  m_calculator->compute_priority(cell, length_prio, shape_prio);

  //We do something different depending on the value of length_prio:
  // - If negative: Never queue the cell (probably in a small angle corner).
  // - If zero: Cell is small enough w/r to sizing field.
  // - If positive: Cell is too big, need to be split regardless of shape.
  int length_comp = iFuzzyComp(length_prio, 0.);

  if( length_comp == 1 ) {
    if(comp.max_on_top()) push( new CellQueueEntry(cell, 1.e4 + length_prio) );
    else push( new CellQueueEntry(cell, -length_prio) );
    return;
  }
  else if( length_comp == 0 ) assert(iFuzzyComp(shape_prio, 0.) == 1 );
  else return; //if the length_prio is negative, we do not want to queue this cell.
  
  //If cell is within the acceptable shape priority range, 
  //we do not want to queue it.
  if(shape_prio < m_min_shape_priority ||
     shape_prio > m_max_shape_priority) return;

#ifndef NDEBUG
  //I added this just to make sure the minimal length priority
  //is always bigger than the maximum shape priority. (see a few
  //lines above where I add 1.e4 to the length_prio when queueing).
  //This is not absolutely necessary, just more like a sanity check.
  if(comp.max_on_top()) assert( shape_prio < 1.e4 );
#endif

  push( new CellQueueEntry(cell, shape_prio) ); 

}

void RefinementQueue::clean_queue() {

  //Removes the deleted entities from the priority queue.

  if( empty() ) return;

  CellQueueEntry* entry;
  EntryVec valid, deleted;
  EntryVec::iterator it = c.begin(), it_end = c.end();

  GR_index_t num_total = size();
  valid.reserve(num_total);
  deleted.reserve(num_total);

  for( ; it != it_end; ++it) {
    entry = *it;
    if(entry->deleted()) deleted.push_back(entry);
    else                 valid.push_back(entry);
  }

#ifndef NDEBUG
  GR_index_t num_valid   = valid.size(),
         num_deleted = deleted.size();
  assert(num_total = num_valid + num_deleted);
#endif

  //Put the valid entries in the queue container and sort.
  c.swap(valid);
  std::make_heap(c.begin(), c.end(), CellQueueEntry::PrioOrder());

  //Delete the deleted entries.
  std::for_each(deleted.begin(), deleted.end(), GRUMMP::DeleteObject());

#ifndef NDEBUG
  assert(size() == num_valid);
#endif

}

void RefinementQueue::update_entries_after_purge(const std::map<Cell*, Cell*>& cell_map) {

  //The map contains pairs of (old cell addresses - new cell addresses).
  //Go through the queue entries and update the cell pointers according to the map.
  //Note that clean_queue() must be called before this function to remove
  //all deleted entries from the queue.

  if( empty() ) return;

  Cell* old_cell, *new_cell;
  CellQueueEntry* entry;
  EntryVec::iterator it = c.begin(), it_end = c.end();

  for( ; it != it_end; ++it) {
    entry = *it;
    old_cell = entry->get_cell();
    assert(cell_map.count(old_cell) == 1);
    new_cell = cell_map.find(old_cell)->second;
    assert(!new_cell->qDeleted());
    entry->set_cell(new_cell);
  }

}

void RefinementQueue::print_queue() {

  //Prints the queue, but must empty it while doing so.
  //Calling this function aborts the program run.

  CellQueueEntry* entry;
  
  do {
    entry = top();
    printf("cell = %p, priority = %e, deleted = %d\n", 
	   entry->get_cell(), entry->get_priority(), entry->deleted());
  } while( pop_top_entry() );
  
  vFatalError("Printing the priority queue emptied it, cannot do anything else",
	      "RefinementQueue::print_queue()");

}

////////////////////////////////////////////////////////////////
///// Declaration of TetMeshRefiner functions starts here //////
////////////////////////////////////////////////////////////////

TetMeshRefiner::TetMeshRefiner() 
  : m_mesh(NULL), m_length(NULL), 
    m_subseg_queue(), m_subface_queue(), m_cell_queue(NULL), m_subseg_map() { assert(0); }

TetMeshRefiner::TetMeshRefiner(const TetMeshRefiner&) 
  : m_mesh(NULL), m_length(NULL),
    m_subseg_queue(), m_subface_queue(), m_cell_queue(NULL), m_subseg_map() { assert(0); }

TetMeshRefiner& TetMeshRefiner::operator=(const TetMeshRefiner&) { assert(0); return *this; }

TetMeshRefiner::TetMeshRefiner( VolMesh* const mesh,
				const std::set<Subseg*>* const subsegs,
				const eEncroachType encroach_type,
				const PriorityCalculator::PrioType prio_type,
				double refine_coeff, double grade_coeff ) 
  : m_mesh(mesh), m_length(NULL), m_subseg_queue(), m_subface_queue(), 
    m_cell_queue(NULL), m_subseg_map() {

  assert(m_mesh);
  assert(m_mesh->qValid());
  assert(m_mesh->qSimplicial());

  //Only support ball encroachment for now. In fact, I am not sure I am going
  //to implement lens encroachment. It complicates things enormously
  //(deleting the vertices inside a subsegment's ball might lead to a mesh
  //that is not constrained Delaunay causing an algorithm's failure). In practice,
  //I believe the same quality bounds can be reached, maybe with a few more insertions.
  assert(encroach_type == eBall);

  //Initializing some of the mesh parameter.
  m_mesh->vSetSwapType(eDelaunay);
  m_mesh->vSetEncroachmentType(encroach_type);

  //Initialize the subsegment map.
  initialize_subsegs(subsegs);

  //Create the length scale object which depends on two user-defined coefficients.
  //Set the subseg map in the length scale object.
  //Initialize the length scale for the vertices already in the mesh.
  //Note that the m_length pointer will be passed to the refinement queue 
  //(used to compute length priority and prevent overrefinement near small angles).
  assert(!m_length);
  m_length = new Length3D(refine_coeff, grade_coeff);
  m_length->set_subseg_map(&m_subseg_map);
  m_length->init_length(m_mesh);

  //Create the priority queue object.
  //Set the ordering as well as the bounds based on the priority type.
  bool max_prio_on_top;
  double min_shape_prio, max_shape_prio;

  switch (prio_type) {

  case PriorityCalculator::EDGE_RADIUS:
    max_prio_on_top = false;
    min_shape_prio  = 0.;
    max_shape_prio  = 3.*sqrt(2.)/8.;
    break;
  case PriorityCalculator::SIN_DIHED:
  case PriorityCalculator::BIAS_SIN_DIHED:
    max_prio_on_top = false;
    min_shape_prio  = 0.;
    max_shape_prio  = sin( (M_PI/180.) * 14. );
    break;
  case PriorityCalculator::MIN_SOLID:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.2;
    break;
  case PriorityCalculator::VOLUME_LENGTH:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.35;
    break;
  case PriorityCalculator::NORMALIZED_SHAPE_RATIO:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.3;
    break;
  case PriorityCalculator::MEAN_RATIO:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.45;
    break;
  case PriorityCalculator::VOLUME_AREA_RATIO:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.02;
    break;
  case PriorityCalculator::INRAD_ALTITUDE:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.6;
    break;
  case PriorityCalculator::INRAD_LENGTH:
    max_prio_on_top = false;
    min_shape_prio = 0.;
    max_shape_prio = 0.35;
    break;
  default:
    assert(0);
    break;

  }

  //Create an empty queue.
  m_cell_queue = new RefinementQueue(prio_type, max_prio_on_top,
				     min_shape_prio, max_shape_prio);  
  //Pass the length scale pointer to the refinement queue.
  m_cell_queue->set_length_calculator(m_length);
 
  //We are done. The queues will be filled when calling the refine() function.
 
}

TetMeshRefiner::~TetMeshRefiner() {

  //Deleted m_length and m_cell_queue, that's it...
  if(m_length) delete m_length; 
  if(m_cell_queue) delete m_cell_queue; 

}

//This function initializes the subsegment map. It acts differently depending
//on which geometry type is used. For GRUMMP's native geometry, no subsegments
//are given, therefore they must be infered from the geometry and the mesh that
//is passed to the TetMeshRefiner. Unfortunately, because of that, some topological
//configurations, such as scratch curves or dangling edges cannot be supported. A
//subsegment can only be recognized along the boundary of two surfaces.

//For other geometry types, subsegments are built during the surface sampling phase
//and should be explicitely available. This is the easy case.

void TetMeshRefiner::initialize_subsegs(const set<Subseg*>* const given_subsegs) {

  assert( m_mesh );
  assert( m_subseg_map.empty() );
  
  if( given_subsegs ) {

    //The case where subsegments are given. This is easy...
    //Note that only the pointer gets added to m_subseg_map (not a copy of the object).
    //The memory gets de-allocated only when the subsegment gets deleted from m_mesh.
    //Be careful with that... (should maybe create a local copy if the subsegs 
    //in the map must be used somewhere else, in another object).

    Subseg* subseg;
    set<Subseg*>::const_iterator 
      it = given_subsegs->begin(), it_end = given_subsegs->end();

    for( ; it != it_end; ++it ) {

      subseg = *it;

#ifndef NDEBUG
      assert( subseg->get_beg_vert()->qValid() );
      assert( subseg->get_end_vert()->qValid() );
      assert( subseg->get_beg_vert() != subseg->get_end_vert() ); 
      assert( !subseg->get_beg_vert()->qDeleted() );
      assert( !subseg->get_end_vert()->qDeleted() );
      m_mesh->qHasVert( subseg->get_beg_vert() );
      m_mesh->qHasVert( subseg->get_end_vert() );
#endif

      m_subseg_map.add_subseg( subseg );

    }

  }

  else {

    //Subsegments are not given. We must infer them from 
    //the mesh and the underlying geometry.

    //This case should only happen with GRUMMP's native
    //geometry interface (and the following code is 
    //designed as such). The code does not store geometric
    //entity pointers for vertices (makes it impossible to
    //identify orphaned subsegments inside a boundary surface).
    
    assert( !given_subsegs );

    //To be a subsegment, an edge must have both its vertices
    //either on a curve, or at an apex point.

    //Go through all the mesh boundary faces and identify all
    //the edges satisfying this condition. Store them in a set 
    //as TetRefinerEdge's, this way each edge is stored
    //once and only once.

    BFace* bface;
    Vert*  vert[2];
   
    TetRefinerEdgeBFace edge;
    set<TetRefinerEdgeBFace> all_edges;
    set<TetRefinerEdgeBFace>::iterator it, it_end;

    GR_index_t i, j, num_bfaces = m_mesh->iNumTotalBdryFaces();

#ifndef NDEBUG
    int num_bdry_verts = 0;
    for(i = 0; i < m_mesh->iNumVerts(); ++i) {
      Vert* my_vert = m_mesh->pVVert(i);
      if(my_vert->qDeleted()) continue;
      if( my_vert->iVertType() == Vert::eBdryApex ||
	  my_vert->iVertType() == Vert::eBdryCurve ) ++num_bdry_verts;
    }
#endif
    
    for(i = 0; i < num_bfaces; ++i) {
      
      bface = m_mesh->pBFBFace(i);
      if(bface->qDeleted()) continue;

      assert( bface->eType() == Cell::eTriBFace ||
	      bface->eType() == Cell::eIntTriBFace );
      assert( bface->iNumVerts() == 3 );

      for(j = 0; j < 3; ++j) {

	switch( j ) {
	case 0:
	  vert[0] = bface->pVVert(0);
	  vert[1] = bface->pVVert(1);
	  break;
	case 1:
	  vert[0] = bface->pVVert(1);
	  vert[1] = bface->pVVert(2);
	  break;
	case 2:
	  vert[0] = bface->pVVert(2);
	  vert[1] = bface->pVVert(0);
	  break;
	default:
	  assert(0);
	}

	if( (vert[0]->iVertType() == Vert::eBdryApex ||
	     vert[0]->iVertType() == Vert::eBdryCurve) &&
	    (vert[1]->iVertType() == Vert::eBdryApex ||
	     vert[1]->iVertType() == Vert::eBdryCurve) ) {

	  edge = TetRefinerEdgeBFace(vert[0], vert[1]);
	  it = all_edges.find( edge );

	  if( it == all_edges.end() ) { //edge not in the set.
	    edge.add_bface( bface );
	    all_edges.insert( edge );
	  }
	  else { //edge already in set.
	    edge = *it;
	    assert( !edge.get_bfaces().empty() );
	    edge.add_bface(bface);
	    all_edges.erase( it );	    
	    all_edges.insert( edge );
	  }

	}

	else continue; //definitely not a subseg, move on!

      }

    }

    //Now we have a set of unique edges that are potentially
    //subsegments. Go through this set and identify which edges
    //are truly subsegments.
    
    Subseg* subseg;
    it     = all_edges.begin();
    it_end = all_edges.end();

    for( ; it != it_end; ++it) {

      subseg = NULL;
      vert[0] = it->vert(0);
      vert[1] = it->vert(1);
      
      //This piece of code should only be used when using GRUMMP
      //without an external geometry library (i.e. CGM). As such,
      //there should not be geometry entity stored with the vertices.
      assert( !vert[0]->get_parent_topology() );
      assert( !vert[1]->get_parent_topology() );

      switch( it->get_bfaces().size() ) {

      case 0: //These two cases should never happen with GRUMMP's native geometry,
      case 1: //otherwise something is wrong.
	assert(0);
	break;

      case 2: {
	BFace* bface0 = *(   (it->get_bfaces().begin()) );
	BFace* bface1 = *( ++(it->get_bfaces().begin()) );
	assert( bface0 && bface1 );
	assert( bface0 != bface1 );
	assert( !bface0->qDeleted() && !bface1->qDeleted() );
	assert( bface0->pPatchPointer() );
	assert( bface1->pPatchPointer() );
	if( bface0->pPatchPointer() != bface1->pPatchPointer() )
	  subseg = new Subseg(vert[0], vert[1]);
	break;
      }

      default: //If there are more than 2 distinct bfaces, we definitely have a subseg.
	subseg = new Subseg(vert[0], vert[1]);
	break;

      }

      if(subseg) m_subseg_map.add_subseg(subseg);      

    } 

    //Must make sure that every vertex on a curve or at an apex 
    //has an entry in the subseg map.
    assert( num_bdry_verts == m_subseg_map.size() );
    
  } //End case where subsegments are not given.

  //Assert that the entries in the subseg map are consistent.
  assert( m_subseg_map.valid() );

}

bool TetMeshRefiner::clear_top_subseg_queue() {

  //Clears deleted subsegs from the top of the queue.
  //Returns true if there is still something in the queue.
  //Otherwise, returns false.

  while(!m_subseg_queue.empty()) {

    if(m_subseg_queue.front()->is_deleted())
      m_subseg_queue.pop_front();
    else
      return true;

  }

  m_subseg_map.release_deleted_subsegs();
  return false;

}

bool TetMeshRefiner::clear_top_subface_queue() {

  //Clears deleted subfaces from the top of the queue.
  //Also removes subfaces that are considered too small with
  //respect to the length scale.

  BFace* bface;

  while(!m_subface_queue.empty()) {
    
    bface = m_subface_queue.front();
    
    if(bface->qDeleted()) 
      m_subface_queue.pop_front();

    else {
      //To prevent infinitely recursive insertion, don't split
      //BFace's that are too small relative to the local length
      //scale (at this point, 15 times smaller is counted as "too
      //small"). In this situation, the face is removed from the queue.
      bface = m_subface_queue.front();
      double circ_cent[3];
      bface->vCircumcenter(circ_cent);
      double circ_rad = dDIST3D(bface->pVVert(0)->adCoords(), circ_cent),
	     size_now = (2. / sqrt(2.)) * circ_rad, size_limit = 0.;
      for(int ii = 0; ii < 3; ++ii) size_limit += bface->pVVert(ii)->dLS(); 
     
      if(size_now < size_limit / 45.) //45 == 15 * 3 ; 3 = num verts; 15 = size factor
	m_subface_queue.pop_front();
      else //if we get here, then the subface can safely be split.
	return true;
    }

  }

  return false;

}

int TetMeshRefiner::refine_subsegs_for_length() {

  assert(m_length);
  assert(m_subseg_queue.empty());

  Subseg* subseg;
  double length, vert0_ls, vert1_ls;
  std::pair<Subseg*, Subseg*> new_subsegs;

  set<Subseg*> all_subsegs;
  m_subseg_map.get_all_subsegs(all_subsegs);

  //Start by stuffing all the subsegments into m_subseg_queue.
  //Will pop those deleted and those short enough in the loop.
  std::copy( all_subsegs.begin(), all_subsegs.end(), 
	     std::back_inserter(m_subseg_queue) );

  int num_inserts = 0, num_buff_inserts = 0;

  //The refinement loop. Split subsegments until they are short enough.
  
  do {

    if(clear_top_subseg_queue()) {

      subseg = m_subseg_queue.front();
      assert(!subseg->is_deleted());

      length = subseg->get_length();
      vert0_ls = subseg->get_beg_vert()->dLS();
      vert1_ls = subseg->get_end_vert()->dLS();

      if(length > vert0_ls + vert1_ls) {

	split_subseg(subseg, &new_subsegs);
	m_subseg_queue.push_back(new_subsegs.first);
	m_subseg_queue.push_back(new_subsegs.second);
	if(++num_inserts == 30000) 
	  { num_buff_inserts += num_inserts; num_inserts = 0; purge(); }

      }

      else m_subseg_queue.pop_front();

    }

  } while(!m_subseg_queue.empty());
    
  purge();  

  return (num_inserts + num_buff_inserts);

}

int TetMeshRefiner::refine_subfaces_for_length() {

  assert(m_length);
  //These should be empty in the grand scheme of things,
  //although the function should still work if they are not...
  assert(m_subseg_queue.empty());
  assert(m_subface_queue.empty());

  Subseg* subseg;
  int num_inserts = 0, num_buff_inserts = 0;
  
  //Start by fixing subsegment's encroachement.
  //Note that subsegs getting encroached by the splits
  //will be queued automagically in the split_subseg function.

  queue_encroached_subsegs();

  while( !m_subseg_queue.empty() ) {

    subseg = m_subseg_queue.front();
    m_subseg_queue.pop_front();
    if(subseg->is_deleted()) continue;
    split_subseg(subseg);
    if(++num_inserts == 30000) 
      { num_buff_inserts += num_inserts; num_inserts = 0; purge(); }

  }
  
  assert(m_mesh->qValid());

  //Empty the subface queue. It currently contains subfaces that 
  //were found to be encroached while fixing subsegment's encroachment.
  //We do not want to fix subface's encroachment here, just split the
  //subfaces that are too big.

  m_subface_queue.clear();
  assert(m_subseg_queue.empty()); //we just fixed encroachment.

  //Refine subfaces for length.
  BFace* bface;
  vector<BFace*> new_bfaces;
  int ii, num_bfaces = m_mesh->iNumTotalBdryFaces();
  double center[3], radius, current_size, target_size, 
    sqrt_of_two = sqrt(2.), one_third = 1./3.;

  //Put all the valid subfaces in the queue.
  for(ii = 0; ii < num_bfaces; ++ii) {
    bface = m_mesh->pBFBFace(ii);
    if(bface->qDeleted()) continue;
    m_subface_queue.push_back(bface);
  }

  TetMeshRefiner::SplitType split_type;

  //Refinement loop.
  while(true) {

    //Fix subsegment encroachment.
    if( !m_subseg_queue.empty() ) {
      subseg = m_subseg_queue.front();
      m_subseg_queue.pop_front();
      if(subseg->is_deleted()) continue;
      split_type =split_subseg(subseg);
      assert(split_type == TetMeshRefiner::SUBSEG);
      if(++num_inserts == 30000) 
	{ num_buff_inserts += num_inserts; num_inserts = 0; purge(); }
    }

    else if( !m_subface_queue.empty() ) {

      bface = m_subface_queue.front();
      if(bface->qDeleted()) {
	m_subface_queue.pop_front();
	continue;
      }

      //Start by computing the current size and the target size.
      assert(bface->iNumVerts() == 3);
      bface->vCircumcenter(center);
      radius = dDIST3D(center, bface->pVVert(0)->adCoords());
      current_size = sqrt_of_two * radius;
      target_size  = one_third * (bface->pVVert(0)->dLS() +
				  bface->pVVert(1)->dLS() + bface->pVVert(2)->dLS());

      //If the subface is too big, then split it and queue the newly created subfaces.
      if( current_size > target_size ) {

	new_bfaces.clear();
	split_type = split_subface(bface, &new_bfaces);

	if(split_type == TetMeshRefiner::SUBFACE) {
	  //A split actually occured (no encroachment on subsegs).
	  //Pop the subface and queue the newly created subfaces for further size check.
	  m_subface_queue.pop_front();
	  std::copy( new_bfaces.begin(), new_bfaces.end(), 
		     std::back_inserter(m_subface_queue) );
	  if(++num_inserts == 30000) 
	    { num_buff_inserts += num_inserts; num_inserts = 0; purge(); }
	}

      }

      //The subface is small enough, pop it and forget about it for now.
      else m_subface_queue.pop_front();

    }

    else break;

  }

  purge();

  //The queues should definitely be empty at this point.
  //Note that the some boundary faces can still be encroached,
  //as we made no attempt to fix their encroachment.
  assert(m_subseg_queue.empty());
  assert(m_subface_queue.empty());

  return (num_inserts + num_buff_inserts);

}

int TetMeshRefiner::run_refinement_loop(int inserts_since_purge) {

  bool initial_clean = false;
  int num_inserts = 0;

  SplitType split_type;

  Subseg* subseg;
  BFace* bface, *last_bface = NULL;
  Cell* last_cell = NULL;
  CellQueueEntry* entry;

  while(true) {
    
    if(clear_top_subseg_queue()) {

      subseg = m_subseg_queue.front();
      assert(!subseg->is_deleted());

      split_type = split_subseg(subseg);
      assert(split_type == SUBSEG);
      assert(subseg->is_deleted());
      last_bface = NULL; last_cell = NULL;

      ++num_inserts;
      if(++inserts_since_purge == 30000) 
	{ inserts_since_purge = 0; purge(); }	

    }

    else if(clear_top_subface_queue()) { 
     
      bface = m_subface_queue.front();
      assert(!bface->qDeleted());      

      if(bface == last_bface) {
	m_subface_queue.pop_front();
	last_bface = NULL;
	continue;
      }

      split_type = split_subface(bface);
      
      if(split_type == SUBFACE) {
	++num_inserts;
	if(++inserts_since_purge == 30000) 
	  { inserts_since_purge = 0; purge(); }
	last_bface = NULL; last_cell = NULL;
      }
      else { 
	assert(split_type == NONE);
	assert(!m_subseg_queue.empty()); //at least one subseg must have been encroached.
	last_bface = bface;
      }

    }

    else if(!m_cell_queue->empty()) {

      if(!initial_clean) {
	initial_clean = true;
	m_cell_queue->clean_queue();
      }
      if (m_cell_queue->empty()) break;
      entry = m_cell_queue->top();
      
      if(entry->deleted() || entry->get_cell() == last_cell) {
	m_cell_queue->pop();
	last_cell = NULL;
	continue;
      }

      split_type = split_tetra(entry->get_cell()); 

      if(split_type == CELL) {
	last_bface = NULL; last_cell = NULL;
	++num_inserts;
	if(++inserts_since_purge == 30000) 
	  { inserts_since_purge = 0; purge(); }
      }
      else if(split_type == TetMeshRefiner::LOCKED) {
	assert(m_subseg_queue.empty() && m_subface_queue.empty());
	m_cell_queue->pop();
	last_cell = NULL;
	continue;
      }
      else {
	assert(split_type = TetMeshRefiner::NONE);
	assert(!m_subseg_queue.empty() || !m_subface_queue.empty());
	last_cell = entry->get_cell();
      }

    }
    
    else break; //all queues are empty, stop here!
      
  }

  return num_inserts;

}

void TetMeshRefiner::refine_for_quality() {

  SUMAA_LOG_EVENT_BEGIN(QUALITY_REFINE);

  //The queues should be empty as we have
  //not done anything yet to the mesh.

  assert(m_cell_queue);
  assert(m_subseg_queue.empty());
  assert(m_subface_queue.empty());

  //The first step is to split all the tets we can currently split.
  //That is all the tets that have circumcenters inside  
  //the domain and that do not encroach on any subfaces 
  //or subsegments. Experience showed us that proceeding this
  //way greatly improves robustness of what comes next (boundary
  //splits mainly). So we proceed this way.

//   set<double> all_orients;
//   {
//     for(int i = 0; i < m_mesh->iNumCells(); ++i) {
//       Cell* cell = m_mesh->pCCell(i);
//       all_orients.insert(orient3d_shew(cell->pVVert(0)->adCoords(), cell->pVVert(1)->adCoords(), 
// 				       cell->pVVert(2)->adCoords(), cell->pVVert(3)->adCoords()));
//     }
//     while(!all_orients.empty()) {
//       printf("%e\n", *all_orients.begin());
//       all_orients.erase(all_orients.begin());
//     }
//     abort();
//   }

  queue_cells();

  CellQueueEntry* entry;
  SplitType split_type;
  int num_inserts = 0;

  printf("Running interior pre-refinement... ");

  while(!m_cell_queue->empty()) {
    
    entry = m_cell_queue->top();
    
    if(entry->deleted()) {
      m_cell_queue->pop();
      continue;
    }

    split_type = split_tetra(entry->get_cell(), NULL); 

    if(split_type == CELL) {
      if(++num_inserts == 30000) { num_inserts = 0; purge(); }
    }
    else m_cell_queue->pop();
   
  } 

  printf("done - inserted %d vertices.\n", num_inserts);

  //Next, we fix encroachment and refine the interior for quality
  //and size. Note however than until the boundaries have not been
  //refined for size, the interior will not achieve the desired
  //size targets because we average a tet's four vertices to determine
  //its size.

  printf("Fixing initial encroachment and running first refinement stage... ");

  m_subseg_queue.clear();
  m_subface_queue.clear();
  assert(m_cell_queue->empty());

  queue_encroached_subsegs();
  queue_encroached_subfaces();
  queue_cells();

  num_inserts = run_refinement_loop(num_inserts);

  printf("done - inserted %d vertices.\n", num_inserts);

  //Now that the boundary is not encroached and the mesh is of high quality,
  //we refine the boundary until it achieves the desired length scale.

  assert(m_subseg_queue.empty());
  assert(m_subface_queue.empty());
  assert(m_cell_queue->empty());

  printf("Refining subsegments to match the sizing field... ");
  num_inserts = refine_subsegs_for_length();
  printf("done - inserted %d vertices.\n", num_inserts);

  printf("Refining subfaces to match the sizing field... ");
  num_inserts = refine_subfaces_for_length();
  printf("done - inserted %d vertices.\n", num_inserts);

  num_inserts = 0; //refine_subfaces terminates with a purge() call.

  //Finally, refine the mesh for size and quality while keeping the 
  //the boundary entities unencroached.

  assert(m_subseg_queue.empty());
  assert(m_subface_queue.empty());

  queue_cells();

  printf("Final refinement to achieve quality bound... ");
  num_inserts = run_refinement_loop(num_inserts);
  printf("done - inserted %d vertices.\n", num_inserts);

  purge();
  
  SUMAA_LOG_EVENT_END(QUALITY_REFINE);

  print_quality_data();
//   output_mesh_to_file(m_mesh, "refined.mesh");

}

void TetMeshRefiner::refine() {

  refine_for_quality();
  return;

//   //Starting by sticking all the cells inside the priority queue.
//   queue_cells();

//   //First step is to refining the subsegments and subfacets for length.
//   //Then identify small angles and fix encroachment.

//   refine_subsegs_for_length();
//   refine_subfaces_for_length();

//   assert(m_subseg_queue.empty());
//   queue_encroached_subsegs();
//   assert(m_subface_queue.empty());
//   queue_encroached_subfaces();
 
//   //Defining some variables.
//   CellQueueEntry* entry;
//   Subseg* subseg;
//   BFace* bface, *last_bface = NULL;
//   Cell* last_cell = NULL;

//   bool initial_clean = false;
//   int num_inserts = 0;
//   TetMeshRefiner::SplitType split_type;

//   printf("Refining the to achieve desired quality bound...\n");

//   while(1) {

//     //if( num_inserts == 1000 ) break;

//     //If the subseg queue is empty, it is safe to release
//     //the deleted subsegments from memory.
//     if(m_subseg_queue.empty())
//       m_subseg_map.release_deleted_subsegs();
    
//     //If the subseg queue is not empty, then 
//     //try to split the first entry.
    
//     if(clear_top_subseg_queue()) {

//       subseg = m_subseg_queue.front();
//       assert(!subseg->is_deleted());

//       SUMAA_LOG_EVENT_BEGIN(PROBE1);
//       split_type = split_subseg(subseg);
//       SUMAA_LOG_EVENT_END(PROBE1);

//       if(split_type == TetMeshRefiner::SUBSEG) {
// 	assert(subseg->is_deleted());
// 	last_bface = NULL; last_cell = NULL;
// 	if(++num_inserts == 30000) { num_inserts = 0; purge(); }	
//       }
// #ifndef NDEBUG
//       else assert(0);
// #endif

//     }

//     else if(clear_top_subface_queue()) {
      
//       bface = m_subface_queue.front();
//       assert(!bface->qDeleted());      
      
//       if(bface == last_bface) {
// 	m_subface_queue.pop_front();
// 	last_bface = NULL;
// 	continue;
//       }

//       SUMAA_LOG_EVENT_BEGIN(PROBE2);
//       split_type = split_subface(bface);
//       SUMAA_LOG_EVENT_END(PROBE2);

//       if(split_type == TetMeshRefiner::SUBFACE) {
// 	if(++num_inserts == 30000) { num_inserts = 0; purge(); }
// 	last_bface = NULL; last_cell = NULL;
//       }
//       else { 
// 	assert(split_type == TetMeshRefiner::NONE);
// 	assert(!m_subseg_queue.empty()); //at least one subseg added to the queue.
// 	last_bface = bface;
//       }

//     }   

//     else if(!m_cell_queue->empty()) {

//       if(!initial_clean) {
// 	initial_clean = true;
// 	m_cell_queue->clean_queue();
//       }

//       entry = m_cell_queue->top();
      
//       if(entry->deleted() || entry->get_cell() == last_cell) {
// 	m_cell_queue->pop();
// 	last_cell = NULL;
// 	continue;
//       }
      
//       SUMAA_LOG_EVENT_BEGIN(PROBE3);
//       split_type = split_tetra(entry->get_cell()); 
//       SUMAA_LOG_EVENT_END(PROBE3);

//       if(split_type == TetMeshRefiner::CELL) {
// 	last_bface = NULL; last_cell = NULL;
// 	if(++num_inserts == 30000) { num_inserts = 0; purge(); }
//       }
//       else if(split_type == TetMeshRefiner::LOCKED) {
// 	assert(m_subseg_queue.empty() && m_subface_queue.empty());
// 	m_cell_queue->pop();
// 	last_cell = NULL;
// 	continue;
//       }
//       else {
// 	assert(split_type = TetMeshRefiner::NONE);
// 	assert(!m_subseg_queue.empty() || !m_subface_queue.empty());
// 	last_cell = entry->get_cell();
//       }

//     }
    
//     else break; //all queues are empty, stop here!
      
//   }
   
//   printf(" done.\nExiting refinement loop\n");

//   purge();
//   output_mesh_to_file(m_mesh, "after.mesh");

}

void TetMeshRefiner::print_quality_data() const {

  Cell* cell;
  int num_cells = m_mesh->iNumCells();

  int num_real_cells = 0;
  double dummy;

  int num_diheds, total_num_diheds = 0;
  double min_dihed = LARGE_DBL, max_dihed = -LARGE_DBL, sum_dihed = 0, all_diheds[6];
  
  int num_solids, total_num_solids = 0;
  double min_solid = LARGE_DBL, max_solid = -LARGE_DBL, sum_solid = 0, all_solids[4];

  double min_vol_length_ratio = LARGE_DBL, sum_vol_length_ratio = 0.;
  double min_radius_ratio = LARGE_DBL, sum_radius_ratio = 0.;

  double radius_edge = LARGE_DBL, max_radius_edge = -LARGE_DBL, sum_radius_edge = 0.;

  for(int i = 0; i < num_cells; ++i) {

    cell = m_mesh->pCCell(i);
    if(cell->qDeleted()) continue;

    ++num_real_cells;

    { //dihedral angles
      cell->vAllDihed(all_diheds, &num_diheds);
      for(int j = 0; j < num_diheds; ++j) {
	++total_num_diheds;
	min_dihed = std::min(min_dihed, all_diheds[j]);
	max_dihed = std::max(max_dihed, all_diheds[j]);
	sum_dihed += all_diheds[j];
      }
    }

    { //solid angles
      cell->vAllSolid(all_solids, &num_solids);
      for(int j = 0; j < num_solids; ++j) {
	++total_num_solids;
	min_solid = std::min(min_solid, all_solids[j]);
	max_solid = std::max(max_solid, all_solids[j]);
	sum_solid += all_solids[j];
      }
    }
    
    { //volume length
      dummy = PriorityCalculator::volume_length(cell);
      min_vol_length_ratio = std::min(min_vol_length_ratio, dummy);
      sum_vol_length_ratio += dummy;
    }


    { //inradius:circumradius.
      dummy = PriorityCalculator::normalized_shape_ratio(cell);
      min_radius_ratio = std::min(min_radius_ratio, dummy);
      sum_radius_ratio += dummy;
    }

    { //circumradius-to-shortest edge ratio.
      dummy = PriorityCalculator::edge_radius_ratio(cell);
      radius_edge = sqrt(0.375) / dummy;
      max_radius_edge = std::max(max_radius_edge, radius_edge);
      sum_radius_edge += radius_edge;
    }

  }

  printf("\n--- Quality statistics ---\n\n");

  printf("Number of cells in the mesh = %d\n\n", num_real_cells);

  printf("***Dihedral angles***\n");
  printf("min = %lf, max = %lf, average = %lf\n", min_dihed, max_dihed, sum_dihed/total_num_diheds);

  printf("***Solid angles***\n");
  printf("min = %lf, max = %lf, average = %lf\n", min_solid, max_solid, sum_solid/total_num_solids);

  printf("***Volume-length ration\n");
  printf("min = %e, average = %e\n", min_vol_length_ratio, sum_vol_length_ratio/num_real_cells);

  printf("***Aspect ratio***\n");
  printf("min = %e, average = %e\n", min_radius_ratio, sum_radius_ratio/num_real_cells);

  printf("***Circumradius-to-shortest edge***\n");
  printf("max = %e, average = %e\n", max_radius_edge, sum_radius_edge/num_real_cells);

  printf("--- ------------------ ---\n");

}

TetMeshRefiner::SplitType TetMeshRefiner::
split_subseg(Subseg* const subseg_to_split, 
	     pair<Subseg*, Subseg*>* new_subsegs,
	     vector<BFace*>* new_subfaces,
	     vector<Cell*>* new_tets) {

  assert( m_mesh );
  assert( subseg_to_split && subseg_to_split->is_not_deleted() );

  // 1 - Compute insertion coordinates: 

  Vert vertex;
  double insert_coords[3], insert_param;
  subseg_to_split->compute_refinement_split_data(insert_coords, insert_param);
  vertex.vSetCoords(3, insert_coords);
 
  // 2 - Compute the Watson cavity:
  
  //Find the seed cells (start point for cavity computation).
  vector<Cell*> seed_cells;
  find_seed_cells( &vertex, subseg_to_split, seed_cells );
  assert( !seed_cells.empty() ); //might not be true for curves.
  
  //Compute the cavity itself. March out from the seeds finding
  //cells containing vertex in their circumsphere. Never cross boundary faces.
  // -> Find the cells to remove from the (constrained Delaunay) mesh.
  // -> Find the boundary faces hit during the march (but not crossed).
  // -> Find the subsegments encroached by vertex.
  set<Cell*> cells_to_remove; set<BFace*> bfaces_hit; set<Subseg*> encroached_subsegs;
  compute_watson_cavity(&vertex, seed_cells, 
			cells_to_remove, bfaces_hit, 
			encroached_subsegs, false);
  assert( !cells_to_remove.empty() ); //might not be true for curves.

  // 3 - Classify the boundary faces based on the effect vertex insertion has:

  //Find the seed bfaces: among the bdry faces hit during cavity computation, find all
  //those sharing the subseg_to_split. These will be the seeds to start the boundary
  //face classification (will march out from the seeds along the surface).
  set<BFace*> bfaces_seed;
  std::remove_copy_if( bfaces_hit.begin(), bfaces_hit.end(), 
		       std::inserter(bfaces_seed, bfaces_seed.begin()),
		       std::not1( BFaceHasTwoVerts(subseg_to_split->get_beg_vert(),
						   subseg_to_split->get_end_vert()) ) );

  //Two groups of boundary faces are considered:
  // -> Those getting deleted by the insertion of vertex.
  // -> Those remaining in the mesh, but encroached upon by vertex.
  //Also, the edges forming a polygon around the union of boundary
  //faces to remove are found. They are needed to correctly reconnect the cavity.
  set<BFace*> bfaces_to_remove, bfaces_encroached;
  set<TetRefinerEdge> edges_with_bface;
  classify_bfaces(&vertex, cells_to_remove, bfaces_hit, bfaces_seed, 
		  bfaces_to_remove, bfaces_encroached, 
		  edges_with_bface, subseg_to_split);

  // 4 - Build the Watson hull.

  //The faces of the cells_to_remove are classified in two type:
  // -> Those that will get removes,
  // -> Those that form the periphery of the Watson hull.
  //So based on the cells_to_remove, classify them (NOTE that the faces of the hull,
  //are returned paired with the region of the adjacent cell to be removed: needed for reconnexion).
  set<Face*> faces_to_remove; map<Face*, int> faces_of_hull;
  build_watson_hull( cells_to_remove,
		     faces_to_remove, faces_of_hull, &bfaces_to_remove );

  //It is possible that the insphere predicate got mistaken while computing
  //the Watson cavity, resulting in an non-reconnectable hull. The following
  //call attempts to repair the mistake.
  correct_cavity(&vertex, cells_to_remove, faces_to_remove, faces_of_hull, 
		 &bfaces_to_remove, &edges_with_bface);

  // 5 - Insertion.

  //At this point, we know that the vertex will be inserted and the subsegment split.
  //Create the new vertex and the two new subsegments and proceed with insertion.
  Vert* new_vert = m_mesh->createVert(insert_coords);
  Subseg *new_subseg0 = new Subseg(), *new_subseg1 = new Subseg();
  subseg_to_split->refinement_split(insert_coords, insert_param, 
				    new_vert, new_subseg0, new_subseg1);

  //Insert new_vert in m_mesh, updating connectivity table for
  //all new entities. Obtain the newly created cells and bdry faces.
  vector<Cell*> new_cells; vector<BFace*> new_bfaces;
  m_mesh->insert_watson_boundary( new_vert, cells_to_remove, faces_to_remove, bfaces_to_remove,
				  faces_of_hull, edges_with_bface, true, 
				  &new_cells, &new_bfaces );

  assert( new_vert->iVertType() == Vert::eBdryCurve );
  assert( !new_cells.empty() );

  // 6 - Update the subsegment map.

  assert( new_subseg0->is_not_deleted() );
  assert( new_subseg1->is_not_deleted() );
  assert( subseg_to_split->is_deleted() );

  m_subseg_map.add_subseg( new_subseg0 );
  m_subseg_map.add_subseg( new_subseg1 );  
  m_subseg_map.remove_subseg( subseg_to_split );

  // 7 - Compute and set the new vertex length scale.

  assert(m_length);
  m_length->set_curv_vert_length(new_vert, new_subseg0, new_subseg1);
  
  // 8 - Update the queues. 

  //Queue the encroached subsegments at the FRONT of m_subseg_queue.
  std::copy( encroached_subsegs.begin(), encroached_subsegs.end(), 
	     std::front_inserter(m_subseg_queue) );

  //Queue the encroached boundary faces at the FRONT of m_subface_queue.
  std::copy( bfaces_encroached.begin(), bfaces_encroached.end(),
	     std::front_inserter(m_subface_queue) );

  //Do not forget to check the new subsegs and subfaces for encroachment.
  if(subseg_is_encroached(new_subseg1)) m_subseg_queue.push_front(new_subseg1);
  if(subseg_is_encroached(new_subseg0)) m_subseg_queue.push_front(new_subseg0);

  for(vector<BFace*>::iterator ittmp = new_bfaces.begin(); ittmp != new_bfaces.end(); ++ittmp) {
    BFace* tmp_bface = *ittmp;
    if(subface_is_encroached(tmp_bface)) m_subface_queue.push_front(tmp_bface);
  }
  // would like to replace the above with something more elegant like:
//   std::remove_copy_if( new_bfaces.begin(), new_bfaces.end(), std::front_inserter(m_subface_queue),
// 		       GRUMMP::extern_mem_fun(&TetMeshRefiner::subface_is_encroached, this) );

  //Queue the new cells in the priority queue (if the queue object is instantiated).
  if(m_cell_queue)
    std::for_each( new_cells.begin(), new_cells.end(),
		   GRUMMP::extern_mem_fun(&RefinementQueue::add_entry, m_cell_queue) );
  
  //If we want to return the new subsegments:
  if(new_subsegs) *new_subsegs = std::make_pair(new_subseg0, new_subseg1);
  if(new_subfaces) std::copy(new_bfaces.begin(), new_bfaces.end(), std::back_inserter(*new_subfaces));
  if(new_tets) std::copy(new_cells.begin(), new_cells.end(), std::back_inserter(*new_tets));

  return SUBSEG;

}
 
TetMeshRefiner::SplitType TetMeshRefiner::
split_subface(BFace* const subface_to_split, 
	      vector<BFace*>* new_subfaces,
	      vector<Cell*>* new_tets) {

  //printf("SPLITTING A BFACE - %p\n", subface_to_split);

  assert( m_mesh );
  assert( subface_to_split && subface_to_split->qValid() && !subface_to_split->qDeleted() );
  assert( subface_to_split->eType() == Cell::eTriBFace ||
	  subface_to_split->eType() == Cell::eIntTriBFace );
  
  // 1 - Compute insertion coordinates (circumcenter of the TriBFace): 

  double insert_coord[3];
  subface_to_split->compute_split_point(insert_coord);

  //The vertex to be inserted cannot be added to the mesh data structure now,
  //since it is not yet know if it will get inserted (does not encroach on subsegments).
  //I create a dummy vertex for now.
  Vert vertex;
  vertex.vSetCoords(3, insert_coord);

  // 2 - Compute the Watson cavity:

  //Find the seed cells for this boundary face.
  vector<Cell*> seed_cells;
  find_seed_cells( &vertex, subface_to_split, seed_cells );
  assert( !seed_cells.empty() ); //this might not be true for curves.

  //Compute the cavity itself. March out from the seeds finding
  //cells containing new_vert in their circumsphere. Never cross boundary faces.
  // -> Find the cells to remove from the (constrained Delaunay) mesh.
  // -> Find the boundary faces hit during the march (but not crossed).
  // -> Find the subsegments encroached by new_vert.
  //Set it to stop right away when an encroached subsegment is detected.  
  set<Cell*> cells_to_remove; set<BFace*> bfaces_hit; set<Subseg*> encroached_subsegs;
  compute_watson_cavity(&vertex, seed_cells, 
			cells_to_remove, bfaces_hit, 
			encroached_subsegs, true);

  //If an encroached subsegment was found, we cannot go ahead 
  //with the subface split. Queue the first offending subseg and exit.
  if( !encroached_subsegs.empty() ) {
    assert( encroached_subsegs.size() == 1 );
    m_subseg_queue.push_back( *encroached_subsegs.begin() );
    return NONE;
  }

  //The BFace getting split should find its way into the
  //set of boundary faces hit during hull computation.
  assert( bfaces_hit.count(subface_to_split) == 1 );
  assert( !cells_to_remove.empty() ); //might not be true for curves.

  // 3 - Classify the boundary faces based on the effect new_vert insertion has:

  //Only one seed to start the classification: the BFace getting split.
  set<BFace*> seed_bfaces;
  seed_bfaces.insert(subface_to_split);

  //Two sets of boundary faces are considered:
  // -> Those getting deleted ( are on the same surface as the bface getting split ).
  // -> Those remaining in the mesh, but encroached upon by new_vert.
  //Also, the edges forming a polygon around the union of boundary
  //faces to remove are found. They are needed to correctly reconnect the cavity.
  set<BFace*> bfaces_to_remove, bfaces_encroached;
  set<TetRefinerEdge> edges_with_bface;
  classify_bfaces(&vertex, cells_to_remove, bfaces_hit, seed_bfaces, 
		  bfaces_to_remove, bfaces_encroached, 
		  edges_with_bface);

  // 4 - Build the Watson hull.

  //The faces of the cells_to_remove are classified in two type:
  // -> Those that will get removed,
  // -> Those that form the periphery of the Watson hull.
  //So based on the cells_to_remove, classify them (NOTE that the faces of the hull,
  //are returned paired with the region of the adjacent cell to be removed: needed for reconnexion).
  set<Face*> faces_to_remove; map<Face*, int> faces_of_hull;
  build_watson_hull( cells_to_remove, 
		     faces_to_remove, faces_of_hull, &bfaces_to_remove );

  //It is possible that the insphere predicate got mistaken while computing
  //the Watson cavity, resulting in an non-reconnectable hull. The following
  //call attempts to repair the mistake.
  correct_cavity(&vertex, cells_to_remove, faces_to_remove, faces_of_hull, 
		 &bfaces_to_remove, &edges_with_bface);

  // 5 - Insertion.

  //At this point we know that the vertex will be inserted. 
  //Create it and insert it in m_mesh data structure. 
  Vert* new_vert = m_mesh->createVert(insert_coord);

  //Insert new_vert in m_mesh, updating connectivity table for
  //all new entities. Obtain the newly created cells and bdry faces.
  vector<Cell*> new_cells; vector<BFace*> new_bfaces;
  m_mesh->insert_watson_boundary( new_vert, cells_to_remove, faces_to_remove, bfaces_to_remove,
				  faces_of_hull, edges_with_bface, 
				  false, &new_cells, &new_bfaces );

  assert( new_vert->iVertType() == Vert::eBdry ||
	  new_vert->iVertType() == Vert::eBdryTwoSide );
  assert( !new_cells.empty() ); 

  // 6 - Compute new vertex length scale.

  //If the length scale object is not yet created (during the encroachment fixing phase
  //for instance, then skip this step)
  assert(m_length);
  m_length->set_surf_vert_length(new_vert);

  // 7 - Update the queues. 

  //Queue the encroached boundary faces at the FRONT of m_subface_queue.
  //Obviously, there should not be any encroached subsegs, otherwise I would
  //have bailed out before getting to this point.  
  std::copy( bfaces_encroached.begin(), bfaces_encroached.end(),
	     std::front_inserter(m_subface_queue) );
  
  //Do not forget to check the new subfaces for encroachment.
  //(once I figure out how, this should be replaced by a more elegant algorithm call...)
  for(vector<BFace*>::iterator ittmp = new_bfaces.begin(); ittmp != new_bfaces.end(); ++ittmp) {
    BFace* tmp_bface = *ittmp;
    if(subface_is_encroached(tmp_bface)) m_subface_queue.push_front(tmp_bface);
  }
//   std::remove_copy_if( new_bfaces.begin(), new_bfaces.end(), 
// 		       std::front_inserter(m_subface_queue),
// 		       GRUMMP::extern_mem_fun(&TetMeshRefiner::subface_is_encroached, this) );
  
  //Queue the new cells in the priority queue (if the queue object is instantiated).
  if(m_cell_queue)
    std::for_each( new_cells.begin(), new_cells.end(),
		   GRUMMP::extern_mem_fun(&RefinementQueue::add_entry, m_cell_queue) );
  
  //If the new boundary faces are needed outside this function, 
  //then copy them into the container.
  if(new_subfaces) std::copy(new_bfaces.begin(), new_bfaces.end(), std::back_inserter(*new_subfaces) );
  if(new_tets) std::copy(new_cells.begin(), new_cells.end(), std::back_inserter(*new_tets));

  return SUBFACE;

}

TetMeshRefiner::SplitType TetMeshRefiner::
split_tetra(Cell* const tetra, vector<Cell*>* new_tets) {

  assert( m_mesh );
  assert( tetra && tetra->qValid() && !tetra->qDeleted() );

  //Compute the insertion location:
  double insert_coord[3];
  TetCell* tet_cell = dynamic_cast<TetCell*>(tetra);
  assert(tet_cell);
  
  //The circumcenter of a flat tet (most probably made of 4 (close to) cocircular vertices)
  //is hard to compute. In fact, a perfectly flat tet has an infinite number of circumspheres,
  //therefore an infinite number of circumcenters. In these conditions, we insert the new
  //vertex at the centroid of the flat tet.
  if(iOrient3D(tetra->pVVert(1), tetra->pVVert(2), tetra->pVVert(3), tetra->pVVert(0)) == 0)
    tet_cell->vCentroid(insert_coord);
  else
    tet_cell->vCircumcenter(insert_coord);

  //Do not create a vertex in the mesh right away since we do not know
  //at this point if the vertex will actually get inserted.  
  Vert vertex;
  vertex.vSetCoords(3, insert_coord);

  //The circumcenter of the tet must necessarily be inside the circumsphere.
  vector<Cell*> seed_cells;
  seed_cells.push_back(tetra); 
  assert( TetCell::vert_inside_sphere(&vertex, tetra) );

  //Compute the Watson cavity: Set it to stop right away when an
  //encroached subsegment is detected.
  set<Cell*> cells_to_remove; 
  set<BFace*> bfaces_hit; 
  set<Subseg*> encroached_subsegs;

  compute_watson_cavity(&vertex, seed_cells, cells_to_remove, 
			bfaces_hit, encroached_subsegs, true);
  assert( !cells_to_remove.empty() || !encroached_subsegs.empty() );

  //The iOrient3D used above to detect flat tets is not sensitive enough
  //to catch all "degenerate" tets (in the sense that they cannot correctly
  //compute a correct insertion coord). The following hack takes advantage
  //of the fact that when only one cell was found to contain the new vertex
  //in its circumcenter, then the vertex must be strictly inside the cell.
  //If not, then the insertion coord must be incorrect.
  if(cells_to_remove.size() == 1 &&
     encroached_subsegs.empty()) {
    if(iIsInTet(&vertex, 
		tet_cell->pVVert(0), tet_cell->pVVert(1), 
		tet_cell->pVVert(2), tet_cell->pVVert(3)) != 4) {
      tet_cell->vCentroid(insert_coord);
      vertex.vSetCoords(3, insert_coord);
      cells_to_remove.clear();
      bfaces_hit.clear();
      compute_watson_cavity(&vertex, seed_cells, cells_to_remove, 
			    bfaces_hit, encroached_subsegs, true);
    }
  }

  //If an encroached subsegment was found, queue it and exit.
  if( !encroached_subsegs.empty() ) {
    assert( encroached_subsegs.size() == 1 );
    m_subseg_queue.push_back( *encroached_subsegs.begin() );
    return TetMeshRefiner::NONE;
  }

  //Must now check the boundary faces 
  //hit during the walk for encroachment.
  if( !bfaces_hit.empty() ) {

    BFace* bface;
    set<BFace*>::iterator it = bfaces_hit.begin(), it_end = bfaces_hit.end();

    for( ; it != it_end; ++it) {
      
      bface = *it;

      if( BFaceIsEncroached(&vertex, m_mesh->eEncroachmentType())(bface) ) {
	m_subface_queue.push_back(bface);
	return TetMeshRefiner::NONE;
      }

      //If the boundary face we hit is still encroached,
      //inserting the point will likely cause an orientation problem
      //in the mesh (should fail an assertion in correct_cavity).
      //This situation occurs when encroachment could not be fixed due
      //to a small angle and we had to bail out. Just refuse to split
      //the tet and move on.
      //This is also caught when we "pre-refine" the interior before 
      //starting the real refinement.
      else if(bface->eIsEncroached(m_mesh->eEncroachmentType())) {
	return TetMeshRefiner::LOCKED;      
      }
      
    }

  }

  //If we got to this point, then the tetrahedron can safely be split.
  //First, compute the faces to remove and faces of hull from the set
  //of cells to remove.

  set<Face*> faces_to_remove; map<Face*, int> faces_of_hull;
  vector<Cell*> new_cells;

  build_watson_hull(cells_to_remove, faces_to_remove, faces_of_hull);
  correct_cavity(&vertex, cells_to_remove, faces_to_remove, faces_of_hull);

  //Create the new vertex in the mesh data structures and
  //insert it using watson insertion.
  Vert* new_vert = m_mesh->createVert(insert_coord);

  m_mesh->insert_watson_interior( new_vert, cells_to_remove, faces_to_remove,
				  faces_of_hull, &new_cells );

  assert( new_vert->iVertType() == Vert::eInterior );
  assert( !new_cells.empty() );

  // 6 - Compute new vertex length scale.

  m_length->set_volu_vert_length(new_vert);

  //Queue the new cells in the priority queue.
  //printf("Number of new cells = %d\n", new_cells.size());
  //printf("Queue size before = %d\n", m_cell_queue.size());
  //Queue the new cells in the priority queue.
  std::for_each( new_cells.begin(), new_cells.end(),
		 GRUMMP::extern_mem_fun(&RefinementQueue::add_entry, m_cell_queue) );
  
  if(new_tets) std::copy(new_cells.begin(), new_cells.end(), std::back_inserter(*new_tets));

  return CELL;

}

void TetMeshRefiner::initialize_queues() {

  queue_encroached_subsegs();
  queue_encroached_subfaces();
  queue_cells();

}

void TetMeshRefiner::queue_encroached_subfaces() {

  //Go through all boundary faces and check if they are encroached.

  SUMAA_LOG_EVENT_BEGIN(INIT_SUBFACE_ENCROACH);

  int num_bfaces = m_mesh->iNumTotalBdryFaces();
  BFace* bface;

  for(int i = 0; i < num_bfaces; ++i) {
    bface = m_mesh->pBFBFace(i);
    if(bface->qDeleted()) continue;
    if(subface_is_encroached(bface)) m_subface_queue.push_back(bface);
  }

  SUMAA_LOG_EVENT_END(INIT_SUBFACE_ENCROACH);

}

bool TetMeshRefiner::subface_is_encroached(const BFace* const bface) const {
  
  assert( m_mesh );
  assert( bface && !bface->qDeleted() );
  assert( m_mesh->eEncroachmentType() == eBall ||
	  m_mesh->eEncroachmentType() == eLens );

  return ( bface->eIsEncroached(m_mesh->eEncroachmentType()) != eClean );

}

void TetMeshRefiner::queue_encroached_subsegs() {

  SUMAA_LOG_EVENT_BEGIN(INIT_SUBSEG_ENCROACH);

  assert( m_mesh );
  assert( !m_subseg_map.empty() );
  
  //Go through all the subsegments and check cells attached to
  //them for a vertex that is inside the subsegment's diametral sphere.  

  Subseg* subseg;
  set<Subseg*> all_subsegs;
  set<Subseg*>::iterator it, it_end;

  m_subseg_map.get_all_subsegs(all_subsegs);
  it     = all_subsegs.begin();
  it_end = all_subsegs.end();

  for( ; it != it_end; ++it) {
    subseg = *it;
    if(subseg->is_deleted()) continue;
    if(subseg_is_encroached(subseg)) m_subseg_queue.push_back(subseg);
  }

  SUMAA_LOG_EVENT_END(INIT_SUBSEG_ENCROACH);

}

void TetMeshRefiner::queue_cells() {

  assert( m_mesh );
  assert( m_cell_queue );

  Cell* cell;
  int num_cells = m_mesh->iNumCells();

  for( int i = 0; i < num_cells; ++i) {
    cell = m_mesh->pCCell(i);
    if(cell->qDeleted()) continue;
    assert(cell->eType() == Cell::eTet);
    m_cell_queue->add_entry(cell);
  }

}

bool TetMeshRefiner::subseg_is_encroached(const Subseg* const subseg) const {

  //This is designed to work with constrained Delaunay tetrahedra only!

  assert( subseg && subseg->is_not_deleted() );
  
  Vert *vert0 = subseg->get_beg_vert(), *vert1 = subseg->get_end_vert(), *this_vert;
  set<Cell*> neigh_cells; set<Vert*> neigh_verts, test_verts;
  vNeighborhood(vert0, neigh_cells, neigh_verts);
  assert( neigh_verts.count(vert1) == 1 );
  
  int i;
  Cell* cell;
  set<Cell*>::iterator itc = neigh_cells.begin(), itc_end = neigh_cells.end();
  
  for( ; itc != itc_end; ++itc) {

    cell = *itc;
    if(!cell->qHasVert(vert1)) continue;
    assert( cell->eType() == Cell::eTet && cell->iNumVerts() == 4);
    assert( cell->qHasVert(vert0) && cell->qHasVert(vert1) );

    for(i = 0; i < 4; ++i) {
      this_vert = cell->pVVert(i);
      if( this_vert == vert0 || this_vert == vert1 ) continue;
      if( test_verts.insert(this_vert).second &&
	  SubsegManager::vert_inside_subseg_ball(this_vert, subseg) ) return true;
    }

  }

  return false;

}

bool TetMeshRefiner::compute_watson_cavity( Vert* const vertex,
					    const vector<Cell*>& seed_cells, 
					    set<Cell*>& cells_to_remove,
					    set<BFace*>& bfaces_hit,
					    set<Subseg*>& encroached_subsegs,
					    bool exit_on_encroachment ) const {
  
  //Performs a march starting from the seed cells (which MUST contain
  //vertex inside their circumsphere) and identifies the cells having
  //vertex inside their circumsphere. Never crosses a boundary face
  //(interior or not).

  //Make sure these containers are empty.
  cells_to_remove.clear();
  bfaces_hit.clear();
  encroached_subsegs.clear();

  //If we do not have a seed, we cannot start the march.
  assert(!seed_cells.empty());
   
  //We must first initialize the march, based on the seeds:

  Cell* cell;
  queue<Cell*> cells_to_visit;
  GR_set<Cell*> cells_visited;

  //We store the edges we already tested for encroachment.
  //Since each edge might be shared by many tets, we do not
  //want to test them many times.
  set<TetRefinerEdge> edges_visited;
    
  //This is where the march is initialized, based on the
  //seed cells provided in the seed_cells vector.
  vector<Cell*>::const_iterator 
    it = seed_cells.begin(), it_end = seed_cells.end();

  for( ; it != it_end; ++it) cells_to_visit.push(*it);

#ifndef NDEBUG
  //We would like the seed cells to exhibit these properties:
  for(it = seed_cells.begin(); it != it_end; ++it) {    
    cell = *it;
    assert(!cell->qDeleted());
    assert(cell->eType() == Cell::eTet);
    assert(TetCell::vert_inside_sphere(vertex, cell));
  }
#endif

  //Now perform the march itself.  
  while( !cells_to_visit.empty() ) {

    cell = cells_to_visit.front();
    assert(cell->eType() == Cell::eTet);

    cells_to_visit.pop();

    //If we already visited this cell, skip to the next.
    if( !cells_visited.insert(cell).second ) continue;
    
    //Check the cell's edges for encroachment.
    if( has_encroached_subseg(cell, vertex, edges_visited, 
			      encroached_subsegs, exit_on_encroachment) ) {
      if(exit_on_encroachment) return true;
    }
    
    //If this cell has the vertex in its circumsphere, 
    //mark cell for deletion and update the search queue.
    if( TetCell::vert_inside_sphere(vertex, cell) ) {
      cells_to_remove.insert(cell);
      update_visit_queue(cell, cells_to_visit, bfaces_hit);
    }

  }
 
  return true;

}

bool TetMeshRefiner::has_encroached_subseg( Cell* const cell,
					    Vert* const vertex,
					    set<TetRefinerEdge>& edges_visited,
					    set<Subseg*>& encroached_subsegs,
					    bool exit_on_encroachment ) const {

  assert( vertex && vertex->qValid() && !vertex->qDeleted() );
  assert( cell && cell->qValid() && !cell->qDeleted() );
  assert( cell->eType() == Cell::eTet );
  assert( cell->iNumVerts() == 4 );

  Vert* vert[2];
  Subseg* subseg;

  bool encroached_subseg = false;

  //Check the six edges for the presence of a subsegment.
  for(int i = 0; i < 6; ++i) {
    
    switch( i ) {
    case 0: vert[0] = cell->pVVert(0); vert[1] = cell->pVVert(1); break;
    case 1: vert[0] = cell->pVVert(0); vert[1] = cell->pVVert(2); break;
    case 2: vert[0] = cell->pVVert(0); vert[1] = cell->pVVert(3); break;
    case 3: vert[0] = cell->pVVert(1); vert[1] = cell->pVVert(2); break;
    case 4: vert[0] = cell->pVVert(1); vert[1] = cell->pVVert(3); break;
    case 5: vert[0] = cell->pVVert(2); vert[1] = cell->pVVert(3); break;
    default: assert(0);
    }

    if( edges_visited.insert( TetRefinerEdge(vert[0], vert[1]) ).second ) {
      
      subseg = m_subseg_map.verts_are_connected(vert[0], vert[1]);

#ifndef NDEBUG
      if( subseg ) assert( (vert[0]->iVertType() == Vert::eBdryApex ||
			    vert[0]->iVertType() == Vert::eBdryCurve) &&
			   (vert[1]->iVertType() == Vert::eBdryApex ||
			    vert[1]->iVertType() == Vert::eBdryCurve) );
#endif

      if( subseg && SubsegManager::vert_inside_subseg_ball(vertex, subseg) ) {
	encroached_subsegs.insert(subseg);
	if( exit_on_encroachment ) return true;
	else encroached_subseg = true;

      }

    }

  }

  return encroached_subseg;

}

void TetMeshRefiner::update_visit_queue( Cell* const cell,
					 queue<Cell*>& cells_to_visit,
					 set<BFace*>& bfaces_hit ) const {

  assert( cell->eType() == Cell::eTet );
  assert( cell->iNumFaces() == 4 );

  Cell* next_cell;
  BFace* bface;

  for(int i = 0; i < 4; i++) {

    next_cell = cell->pFFace(i)->pCCellOpposite(cell);

    switch( next_cell->eType() ) {
    case Cell::eTet:
      cells_to_visit.push(next_cell);
      break;
    case Cell::eTriBFace:
    case Cell::eIntTriBFace: {
      bface = dynamic_cast<BFace*>(next_cell); assert(bface);
      bfaces_hit.insert(bface);
      break;
    }
    default:
      assert(0);
    }

  }

}

void TetMeshRefiner::find_seed_cells( Vert* const vertex, 
				      Subseg* const subseg,
				      vector<Cell*>& seeds ) const {

  seeds.clear();
  Vert *vert0 = subseg->get_beg_vert(), *vert1 = subseg->get_end_vert();

  assert( vert0 && vert1 );
  assert( vert0->qValid() && !vert0->qDeleted() );
  assert( vert1->qValid() && !vert1->qDeleted() );
  assert( vert0 != vert1 );

  //Find all tets sharing vert0 and vert1
  set<Cell*> neigh_cells; set<Vert*> neigh_verts;
  vNeighborhood(vert0, neigh_cells, neigh_verts);
  assert(neigh_verts.count(vert1) == 1);

  seeds.clear();

  Cell* cell;
#ifndef NDEBUG
  GR_index_t num_adjacent = 0;
#endif

  set<Cell*>::iterator 
    it = neigh_cells.begin(), it_end = neigh_cells.end();
  
//   printf("%e %e %e\n", vert0->dX(), vert0->dY(), vert0->dZ());
//   printf("%e %e %e\n", vert1->dX(), vert1->dY(), vert1->dZ());
//   printf("%e %e %e\n\n", vertex->dX(),vertex->dY(),vertex->dZ() );
  

  for( ; it != it_end; ++it) {

    cell = *it;
    assert(cell->qHasVert(vert0));

    if(cell->qHasVert(vert1)) {

#ifndef NDEBUG
      ++num_adjacent;
      assert(cell->eType() == Cell::eTet);

//       printf("%e %e %e\n", cell->pVVert(0)->dX(), cell->pVVert(0)->dY(), cell->pVVert(0)->dZ() );
//       printf("%e %e %e\n", cell->pVVert(1)->dX(), cell->pVVert(1)->dY(), cell->pVVert(1)->dZ() );
//       printf("%e %e %e\n", cell->pVVert(2)->dX(), cell->pVVert(2)->dY(), cell->pVVert(2)->dZ() );
//       printf("%e %e %e\n", cell->pVVert(3)->dX(), cell->pVVert(3)->dY(), cell->pVVert(3)->dZ() );
#endif

      if( TetCell::vert_inside_sphere(vertex, cell) )
	seeds.push_back(cell);

    }

  }

#ifndef NDEBUG

//   printf("number of neighbords = %d, num_adjacent = %d\n", neigh_cells.size(), num_adjacent);
//   printf("number of cells = %d\n", seeds.size());

  //An edge that is attached to at least one cell, there
  //should be at least one of these cells having the new
  //vertex in this circumcenter. Otherwise, modifications
  //will be needed to the current scheme.

  assert(!seeds.empty());

  //There should be as many Tets having the new vertex
  //in their circumsphere as there are Tets connected
  //to this subsegment (that is assuming that the insertion
  //location is not outside any of the adjacent tets' circumsphere). 
  //In practice, that might not be true - at least for curved boundaries.
  //If this criteria is not met, then modifications will 
  //have to be made to the insertion scheme... at a later stage.

  //assert( num_adjacent == seeds.size() );

#endif

}

void TetMeshRefiner::find_seed_cells( Vert* const vertex,
				      BFace* const bface,
				      vector<Cell*>& seeds ) const {

  assert(!bface->qDeleted());
  
  seeds.clear();

  int num_faces = bface->iNumFaces();
  assert(num_faces == 1 || num_faces == 2);

  Cell* cell[] = { static_cast<Cell*>(NULL), 
		   static_cast<Cell*>(NULL) };

  switch(num_faces) {

  case 2:
    assert( bface->eType() == Cell::eIntTriBFace );
    cell[0] = bface->pFFace(0)->pCCellOpposite(bface);
    cell[1] = bface->pFFace(1)->pCCellOpposite(bface);
    break;    
  case 1:
    assert( bface->eType() == Cell::eTriBFace );
    cell[0] = bface->pFFace(0)->pCCellOpposite(bface);
    break;
  default:
    assert(0);    

  }

  for(int i = 0; i < num_faces; ++i) {

    assert( cell[i] );
    assert( cell[i]->qValid() && !cell[i]->qDeleted() ); 
    assert( cell[i]->eType() == Cell::eTet );
    if( TetCell::vert_inside_sphere(vertex, cell[i]) ) 
      seeds.push_back(cell[i]);

  }

#ifndef NDEBUG

  //In the case of a regular boundary, especially in the presence of
  //curved surfaces, it is possible that the new vertex be inserted
  //outside the circumspheres of all the tets existing in the mesh.
  //In such situation, one tetrahedron is added to the exterior of
  //the boundary face (the boundary face becomes an interior face
  //and three new boundary faces are created), without deleting anything
  //in the interior.

  //Do not worry about this for now:
  //if(num_cells == 1) assert(seeds.size() == 0 || seeds.size() == 1);
  
  //If we have an internal boundary, Then the tetrahedra on both
  //sides must get deleted if the boundary face is split. Both
  //tets must therefore have the new vertex in their circumsphere.
  //If that is not the case, I am not sure we can apply Watson
  //insertion...
  
  //else assert( seeds.size() == 2);
 
  if(seeds.empty()) {

    printf("%e %e %e 0\n", bface->pVVert(0)->dX(), bface->pVVert(0)->dY(), bface->pVVert(0)->dZ());
    printf("%e %e %e 0\n", bface->pVVert(1)->dX(), bface->pVVert(1)->dY(), bface->pVVert(1)->dZ());
    printf("%e %e %e 0\n", bface->pVVert(2)->dX(), bface->pVVert(2)->dY(), bface->pVVert(2)->dZ());

    double circ_cent[3];
    bface->vCircumcenter(circ_cent);
    printf("%e %e %e 0\n", vertex->dX(), vertex->dY(), vertex->dZ());
    printf("%e %e %e 0\n", circ_cent[0], circ_cent[1], circ_cent[2]);

    bface->compute_split_point(circ_cent);
    printf("%e %e %e 0\n", circ_cent[0], circ_cent[1], circ_cent[2]);

    printf("seeds size = %d\n", static_cast<int>(seeds.size()));
    int num_cells = m_mesh->iNumCells();
    for(int i = 0; i < num_cells; ++i) {
      Cell* this_cell = m_mesh->pCCell(i);
      if(this_cell->qDeleted()) continue;
      if( TetCell::vert_inside_sphere(vertex, this_cell) ) printf("found a seed\n");
    }

  }

  //Right now, assume that the cell(s) connected to the bface are
  //located have vertex in their circumsphere.
  assert( seeds.size() == (bface->eType() == Cell::eTriBFace ? 1 : 2) );

#endif

}

bool TetMeshRefiner::classify_bfaces( Vert* const vertex,
				      const set<Cell*>& cells_to_remove,
				      const set<BFace*>& cavity_bfaces,
				      const set<BFace*>& seed_bfaces,
				      set<BFace*>& bfaces_to_remove,
				      set<BFace*>& bfaces_encroached,
				      set<TetRefinerEdge>& edges_with_bface,
				      const Subseg* const subseg_to_split ) const {

  //This function should only be called for a boundary insertion.

  //Among the boundary faces hit during the Watson cavity computation
  //(stored in cavity_bfaces), we want to identify 
  // 1 - those that are on the (or the many, in case of a subsegment split) 
  //     surface(s) connected to vertex.
  // 2 - those that are encroached, but on disjoint surfaces.

  //The former will get deleted when performing the insertion, the latter
  //will be queued for subsequent split. The rest of the boundary faces
  //are left untouched and their corresponding face will be part of the hull.

  //The function will also find the edges attached to boundary faces that
  //must be removed and to which new boundary faces will need to be attached

  assert( vertex && vertex->qValid() && !vertex->qDeleted() );
  assert( !seed_bfaces.empty() );
  assert( !cavity_bfaces.empty() );

  bfaces_to_remove.clear();
  bfaces_encroached.clear();

  set<BFace*> cavity_copy = cavity_bfaces; //make a copy of the boundary faces part of the cavity.
  set<TetRefinerEdge> edges_visited;       //keep track of the edges already traversed.
  queue<TetRefinerEdge> edges_to_visit;    //queue edges that potentially will be traversed.
  
  Subseg* subseg;
  BFace* bface;  
  TetRefinerEdge edge;

  Cell *cell0, *cell1;

  //Initialize the walk along the surface.

  //The boundary faces contained in seed_bfaces either get split (seed_bfaces.size() == 1),  
  //or are connected to a subsegment getting split. In any case, they will be removed from
  //the mesh and must be added to bfaces_to_remove.

  set<BFace*>::const_iterator 
    it = seed_bfaces.begin(), it_end = seed_bfaces.end();

  for( ; it != it_end; ++it) {

    bface = *it;
    assert( cavity_copy.count(bface) == 1 );

    cavity_copy.erase(bface);
    bfaces_to_remove.insert(bface);

#ifndef NDEBUG
    if(bface->eType() == Cell::eIntTriBFace) {
      cell0 = bface->pFFace(0)->pCCellLeft()->eType() == Cell::eTet ? 
	bface->pFFace(0)->pCCellLeft() : bface->pFFace(0)->pCCellRight();
      cell1 = bface->pFFace(1)->pCCellLeft()->eType() == Cell::eTet ? 
	bface->pFFace(1)->pCCellLeft() : bface->pFFace(1)->pCCellRight();
      assert(cell0->eType() == Cell::eTet && cell1->eType() == Cell::eTet);
      assert(cells_to_remove.count(cell0) == 1 &&
	     cells_to_remove.count(cell1) == 1);
    }
#endif

    assert( bface->iNumVerts() == 3 );
    edges_to_visit.push( TetRefinerEdge(bface->pVVert(0), bface->pVVert(1), bface) );
    edges_to_visit.push( TetRefinerEdge(bface->pVVert(1), bface->pVVert(2), bface) );
    edges_to_visit.push( TetRefinerEdge(bface->pVVert(2), bface->pVVert(0), bface) );

  }

  //Perform the walk.

  //Run through the queue and traverse the edges until the queue is empty. An
  //edge should should not get traversed more than once (hence the set to keep track
  //of what has been checked) AND subsegments should NEVER be crossed.
  
  while( !edges_to_visit.empty() ) {

    edge = edges_to_visit.front();
    edges_to_visit.pop();

    //If we already traversed this edge, keep going elsewhere.
    if( !edges_visited.insert(edge).second ) continue;

    //If this edge is a subsegment, do not cross it.
    subseg = m_subseg_map.verts_are_connected( edge.vert(0), edge.vert(1) );

    if( subseg ) {
      
      if( subseg != subseg_to_split ) { 
	//Make sure the subseg is not encroached 
	//Subsegment encroachment should be detected elsewhere, upstream of this call
	//(unless of course we are currently splitting another subseg).
#ifndef NDEBUG
	//if( subseg_to_split )
	assert( subseg_to_split || !SubsegManager::vert_inside_subseg_ball(vertex, subseg) );
#endif

	//This edge will be attached to a boundary face when the cavity is reconnected,
	//unless it corresponds to the subsegment getting split.
	edges_with_bface.insert(edge);
	
      }

      continue;

    }

    //If the edge we are looking at is not a subsegment, then we can
    //safely traverse it (along the surface). This edge must have
    //two boundary faces attached to it (otherwise, it would necessarily
    //be a subsegment). If we got here, one of these faces has found its way 
    //into the bfaces_to_remove set and has been erased from cavity_copy.
    //We need to look for the presence of the other boundary face in cavity_copy.
    //If it is in there, then it needs to be added to bfaces_to_remove and removed
    //from cavity_copy.

    it = std::find_if( cavity_copy.begin(), cavity_copy.end(), 
		       BFaceHasTwoVerts(edge.vert(0), edge.vert(1)) );

    if( it != cavity_copy.end() ) {
      
      //We need to cross an edge and go to the next boundary face.

      bface = *it;
      assert( bface->qHasVert(edge.vert(0)) &&
	      bface->qHasVert(edge.vert(1)) );
      assert( bfaces_to_remove.count(bface) == 0 );

      if(bface->eType() == Cell::eIntTriBFace) {

	cell0 = bface->pFFace(0)->pCCellLeft()->eType() == Cell::eTet ? 
	  bface->pFFace(0)->pCCellLeft() : bface->pFFace(0)->pCCellRight();
	cell1 = bface->pFFace(1)->pCCellLeft()->eType() == Cell::eTet ? 
	  bface->pFFace(1)->pCCellLeft() : bface->pFFace(1)->pCCellRight();
	assert(cell0->eType() == Cell::eTet && cell1->eType() == Cell::eTet);
	assert(cells_to_remove.count(cell0) == 1 || 
	       cells_to_remove.count(cell1) == 1);

	if(cells_to_remove.count(cell0) == 1 && cells_to_remove.count(cell1) == 1) {
	  cavity_copy.erase(it);
	  bfaces_to_remove.insert(bface);
	  edges_to_visit.push( TetRefinerEdge(bface->pVVert(0), bface->pVVert(1), bface) );
	  edges_to_visit.push( TetRefinerEdge(bface->pVVert(1), bface->pVVert(2), bface) );
	  edges_to_visit.push( TetRefinerEdge(bface->pVVert(2), bface->pVVert(0), bface) );
	}
	else {
	  edges_with_bface.insert(edge);
	}

      }

      else {
	assert(bface->eType() == Cell::eTriBFace);
	cavity_copy.erase(it);
	bfaces_to_remove.insert(bface);
	//Since a boundary face that needs to be removed was found, its three edges
	//are added to the queue so that we can continue the walk.
	edges_to_visit.push( TetRefinerEdge(bface->pVVert(0), bface->pVVert(1), bface) );
	edges_to_visit.push( TetRefinerEdge(bface->pVVert(1), bface->pVVert(2), bface) );
	edges_to_visit.push( TetRefinerEdge(bface->pVVert(2), bface->pVVert(0), bface) );
      }

    }

    else { 
      //We found the limit of the boundary faces to be removed. 
      //This edge will therefore be connected to a new boundary face.
      edges_with_bface.insert(edge);
    }

  }

#ifndef NDEBUG

  //Try to detect a failure mechanism:

  //Imagine a cylinder with a coarse surface discretization.
  //If the surface triangulation is coarse enough, it is possible
  //that 

//   Vert *vert0, *vert1;
//   if(subseg_to_split) {
//     vert0 = subseg_to_split->get_beg_vert();
//     vert1 = subseg_to_split->get_end_vert();
//   }

//   multimap<Vert*, TetRefinerEdge> edge_map;
//   set<TetRefinerEdge>::const_iterator it_dbg, it_dbg_end = edges_with_bfaces.end();
  
//   typedef multimap<Vert*, TetRefinerEdge> EdgeMap;
//   EdgeMap edge_map;
//   EdgeMap::iterator it_map;

//   for(it_dbg = edges_with_bfaces.begin(); it_dbg != it_dbg_end; ++it_dbg) {
//     vert0 = it_dbg->vert(0);
//     vert1 = it_dbg->vert(1);
//     edge_map.insert(vert0, *it_dbg);
//     edge_map.insert(vert1, *it_dbg);    
//   }

#endif

  //All the boundary faces that need to be removed from the mesh have now been
  //identified AND removed from cavity_copy, which now contains the rest of the
  //boundary faces hit during the Watson cavity computation. All that is left to 
  //do is to go through these and identify those that are encroached, and copy
  //them into bfaces_encroached (they will be queue for subsequent split).

  std::remove_copy_if( cavity_copy.begin(), cavity_copy.end(),
		       std::inserter( bfaces_encroached, bfaces_encroached.begin() ),
		       std::not1( BFaceIsEncroached(vertex, m_mesh->eEncroachmentType()) ) );

  return true;

}

bool TetMeshRefiner::BFaceHasTwoVerts::operator()(const BFace* const bface) const {

  assert( bface->eType() == Cell::eTriBFace ||
	  bface->eType() == Cell::eIntTriBFace );
  assert( bface->iNumVerts() == 3 );

  return ( ( m_vert0 == bface->pVVert(0) && ( m_vert1 == bface->pVVert(1) || m_vert1 == bface->pVVert(2) ) ) ||
	   ( m_vert0 == bface->pVVert(1) && ( m_vert1 == bface->pVVert(0) || m_vert1 == bface->pVVert(2) ) ) ||
	   ( m_vert0 == bface->pVVert(2) && ( m_vert1 == bface->pVVert(0) || m_vert1 == bface->pVVert(1) ) ) );

}

bool TetMeshRefiner::BFaceHasVert::operator()(const BFace* const bface) const {

  assert( bface->eType() == Cell::eTriBFace ||
	  bface->eType() == Cell::eIntTriBFace );
  assert( bface->iNumVerts() == 3 );

  return ( m_vert == bface->pVVert(0) ||
	   m_vert == bface->pVVert(1) || m_vert == bface->pVVert(2) );

}

void TetMeshRefiner::build_watson_hull( const set<Cell*>& cells_to_remove,
					set<Face*>& faces_to_remove,
					map<Face*, int>& faces_of_hull,
					const set<BFace*>* bfaces_to_remove ) const {

  //Make sure these are empty.
  faces_to_remove.clear();
  faces_of_hull.clear();

  //The faces attached to the boundary faces to remove 
  //have to be removed from the mesh.
//   if(bfaces_to_remove)
//     std::for_each( bfaces_to_remove->begin(), bfaces_to_remove->end(), 
// 		   BFace::GetFaces(&faces_to_remove) );

  if(bfaces_to_remove) {

    BFace* bface;
    set<BFace*>::const_iterator 
      itbf = bfaces_to_remove->begin(), itbf_end = bfaces_to_remove->end();

    for( ; itbf != itbf_end; ++itbf) {

      bface = *itbf;

      if(bface->iNumFaces() == 1) 
	faces_to_remove.insert(bface->pFFace(0));

      else { 

	assert(bface->iNumFaces() == 2);
	assert(bface->pFFace(0)->pCCellLeft()  == static_cast<Cell*>(bface) ||
	       bface->pFFace(0)->pCCellRight() == static_cast<Cell*>(bface));
	assert(bface->pFFace(1)->pCCellLeft()  == static_cast<Cell*>(bface) ||
	       bface->pFFace(1)->pCCellRight() == static_cast<Cell*>(bface));

	set<Cell*>::const_iterator itc0, itc1, itc_end = cells_to_remove.end();

	Face *face0 = bface->pFFace(0), *face1 = bface->pFFace(1);
	Cell* cell0 = static_cast<Cell*>(bface) == face0->pCCellLeft() ? 
	  face0->pCCellRight() : face0->pCCellLeft();
	Cell* cell1 = static_cast<Cell*>(bface) == face1->pCCellLeft() ? 
	  face1->pCCellRight() : face1->pCCellLeft();
	itc0 = cells_to_remove.find(cell0);
	itc1 = cells_to_remove.find(cell1);
	assert(itc0 != itc_end || itc1 != itc_end);

	if(itc0 == itc_end && itc1 != itc_end) {
	  faces_of_hull.insert(std::make_pair(face0, cell0->iRegion()));
	  faces_to_remove.insert(face1);
	}
	else if(itc0 != itc_end && itc1 == itc_end) {
	  faces_to_remove.insert(face0);
	  faces_of_hull.insert(std::make_pair(face1, cell1->iRegion()));
	}
	else {
	  faces_to_remove.insert(face0);
	  faces_to_remove.insert(face1);
	}

      }

    }

  }

  //For each cell to remove, store the 4 faces inside a multiset.
  //However, skip the faces that are already stored in faces to remove
  //(which correspond to boundary faces).

  typedef multimap<Face*, int> FaceMap;
  
  int i;
  Face* face;
  Cell* cell;
  FaceMap all_faces;

  set<Cell*>::const_iterator 
    itc = cells_to_remove.begin(), itc_end = cells_to_remove.end();
 
  for( ; itc != itc_end; ++itc) {
    cell = *itc;
    assert(cell->eType() == Cell::eTet);
    assert(cell->iNumFaces() == 4);
    for(i = 0; i < 4; ++i) { 
      face = cell->pFFace(i);
      if(faces_to_remove.count(face) == 0) 
	all_faces.insert( std::make_pair(face, cell->iRegion()) );
#ifndef NDEBUG
      else assert( face->qIsBdryFace() );
#endif
    }
  }

  //A face that appears once in all_faces is part of the hull.
  //A face that appears twice will be deleted.
  
  pair<FaceMap::iterator, FaceMap::iterator> it_pair;

  while( !all_faces.empty() ) {

    face = all_faces.begin()->first;
    it_pair = all_faces.equal_range(face);

    switch( std::distance(it_pair.first, it_pair.second) ) {

    case 1: faces_of_hull.insert( std::make_pair(face, it_pair.first->second) ); break;
    case 2: faces_to_remove.insert(face); break;
    default: assert(0);  //there should be one or two faces.

    }

    all_faces.erase(it_pair.first, it_pair.second);

  }

}

bool correct_cavity(const Vert* const vertex,
				    set<Cell*>& cells_to_remove,
				    set<Face*>& faces_to_remove,
				    map<Face*, int>& faces_of_hull,
				    set<BFace*>* const bfaces_to_remove,
				    set<TetRefinerEdge>* const edges_with_bface) {
  
  //If we fail this assertion, we are in the caca.
  assert(!cells_to_remove.empty());

  Face* face0;
  Cell* cell0 = NULL;

  set<Cell*>::const_iterator itc, itc_end = cells_to_remove.end();
  map<Face*, int>::const_iterator itfh = faces_of_hull.begin(), itfh_end = faces_of_hull.end();

  double orient;

  for( ; itfh != itfh_end && !cell0; ++itfh) {
    
    face0 = itfh->first;

    orient = orient3d_shew( face0->pVVert(0)->adCoords(),
			    face0->pVVert(1)->adCoords(),
			    face0->pVVert(2)->adCoords(),
			    vertex->adCoords() );
   
    //The new vertex must be on the same side of the hull face as
    //the cell to remove. If that is not the case, then the hull face
    //is not visible from the vertex.

    itc = cells_to_remove.find(face0->pCCellLeft());
    
    if(itc != itc_end) {
      if(orient <= 0.) {
 	cell0 = face0->pCCellLeft();
 	cells_to_remove.erase(itc);
      }
    }

    else {
      assert(cells_to_remove.find(face0->pCCellRight()) != itc_end);
      if(orient >= 0.) {
 	cell0 = face0->pCCellRight();
 	cells_to_remove.erase(cell0);
      }
    }

  }

  //If an offending cell was found, remove it from the cavity, with what it
  //implies regarding the faces_to_remove, etc. Different cases depending
  //on the type of neighboring cells.

  if(cell0) {

    //cell0 is the cell we want to add back in the cavity.   
    assert(cell0->eType() == Cell::eTet);

    //cell1 is the cells neighboring cell0 through a given face.
    Cell* cell1;
    set<Face*>::const_iterator itfr;

    for(int i = 0; i < 4; ++i) {

      face0 = cell0->pFFace(i);
      assert( faces_of_hull.count(face0) == 1 ||
	      faces_to_remove.count(face0) == 1 );

      cell1 = face0->pCCellLeft() == cell0 ? face0->pCCellRight() : face0->pCCellLeft();

      //The case of an interior face (neighbor is a tet).
      //if face in faces_to_remove -> face transfered to faces_of_hull.
      //else face gets removed from faces_of_hull.

      if(cell1->eType() == Cell::eTet) {
	
	itfr = faces_to_remove.find(face0);
	if(itfr != faces_to_remove.end()) {
	  assert(faces_of_hull.count(face0) == 0);
	  faces_to_remove.erase(itfr);
	  faces_of_hull.insert( std::make_pair(face0, cell0->iRegion()) );
	}
	else {
	  assert(faces_of_hull.count(face0) == 1);
	  faces_of_hull.erase(face0);
	}

      }

      else {

	assert(cell1->eType() == Cell::eTriBFace ||
	       cell1->eType() == Cell::eIntTriBFace);

	//if this is an interior insertion, 1 face of hull gets removed.
	if(!bfaces_to_remove) {
	  assert(faces_to_remove.count(face0) == 0);
	  assert(faces_of_hull.count(face0) == 1);
	  faces_of_hull.erase(face0);
	}

	//case of a boundary insertion:
	else {
	  
	  assert(edges_with_bface);
	  BFace* bface = dynamic_cast<BFace*>(cell1); assert(bface);
	  set<BFace*>::const_iterator itbf = bfaces_to_remove->find(bface);

	  //regular boundary face
	  if(cell1->eType() == Cell::eTriBFace) {
	    
	    if(itbf != bfaces_to_remove->end()) { 
	      assert(faces_to_remove.count(face0) == 1);
	      assert(faces_of_hull.count(face0) == 0);
	      faces_to_remove.erase(face0);
	      bfaces_to_remove->erase(itbf);
	    }
	    else {
	      assert(faces_to_remove.count(face0) == 0);
	      assert(faces_of_hull.count(face0) == 1);
	      faces_of_hull.erase(face0);
	      bface = NULL; 
	    }

	  }

	  //interior boundary face
	  else {

	    assert(cell1->iNumFaces() == 2);
	    assert(face0 == pFCommonFace(cell0, cell1));
	    
	    Face* face1 = cell1->pFFace(0) == face0 ? cell1->pFFace(1) : cell1->pFFace(0);
	    cell1 = face1->pCCellRight() == cell1 ? face1->pCCellLeft() : face1->pCCellRight();

	    assert(cell0 != cell1);
	    assert(face0 == pFCommonFace(cell0, bface));
	    assert(face1 == pFCommonFace(bface, cell1));
	    assert(cell1->eType() == Cell::eTet);

	    if(itbf != bfaces_to_remove->end()) {	      
	      assert(cells_to_remove.count(cell1) == 1);
	      assert(faces_of_hull.count(face0) == 0);
	      assert(faces_of_hull.count(face1) == 0);
	      assert(faces_to_remove.count(face0) == 1);
	      assert(faces_to_remove.count(face1) == 1);
	      faces_to_remove.erase(face0);
	      faces_to_remove.erase(face1);
	      faces_of_hull.insert( std::make_pair(face1, cell1->iRegion()) );
	      bfaces_to_remove->erase(itbf);
	    }
	    else {
	      assert(cells_to_remove.count(cell1) == 0);
	      assert(faces_of_hull.count(face0) == 1);
	      assert(faces_of_hull.count(face1) == 0);
	      assert(faces_to_remove.count(face0) == 0);
	      assert(faces_to_remove.count(face1) == 0);
	      faces_of_hull.erase(face0);
	      bface = NULL; 
	    }

	  } //end interior boundary face

	  //If bface != NULL, then bface was removed from bfaces_to_remove.
	  //Update edges_with_bface accordingly.

	  if(bface) {

	    TetRefinerEdge edge;
	    set<TetRefinerEdge>::const_iterator ittre;
#ifndef NDEBUG
	    int num_remove = 0;
#endif
	    int jj, kk;
	    for(jj = 0; jj < 3; ++jj) {
	      kk = jj + 1 == 3 ? 0 : jj + 1;
	      edge = TetRefinerEdge(bface->pVVert(jj), bface->pVVert(kk), bface);
	      ittre = edges_with_bface->find(edge);
	      if(ittre != edges_with_bface->end()) {
		edges_with_bface->erase(ittre);
#ifndef NDEBUG
		++num_remove;
#endif
	      }
	      else 
		edges_with_bface->insert(edge);
	    }

	    //It should not be possible to remove 0 or 3 edges.
	    assert(num_remove == 1 || num_remove == 2);
	
	  } //end bface removal.

	} //end case boundary insertion.

      } //end case boundary face.

    } //end face loop

    //Recursively check if more cells must be removed from the cavity.
    correct_cavity(vertex, cells_to_remove, faces_to_remove, faces_of_hull,
		   bfaces_to_remove, edges_with_bface);

  }

  return true;

}

void TetMeshRefiner::purge() {

  //Remove the deleted entities from m_susbeg_queue and m_subface_queue
  Subseg* subseg;
  deque<Subseg*> new_subseg_queue;
  deque<Subseg*>::iterator 
    its = m_subseg_queue.begin(), its_end = m_subseg_queue.end();
  for( ; its != its_end; ++its) {
    subseg = *its;
    if(subseg->is_not_deleted()) new_subseg_queue.push_back(subseg);
  }
  new_subseg_queue.swap(m_subseg_queue);

  BFace* bface, *old_bface;
  deque<BFace*> new_subface_queue;
  deque<BFace*>::iterator 
    itbf = m_subface_queue.begin(), itbf_end = m_subface_queue.end();
  for( ; itbf != itbf_end; ++itbf) {
    bface = *itbf;
    if(!bface->qDeleted()) new_subface_queue.push_back(bface);
  }
  new_subface_queue.swap(m_subface_queue);

  //Clean the cell priority queue from deleted entries.
  assert(m_cell_queue);
  m_cell_queue->clean_queue();
  
  //The pointers to mesh entities (verts, faces, cells, bfaces) 
  //are going to change after the purge (garbage collection). 
  //We therefore need to update all the data structures contained
  //in this class. That means updating subsegments (and m_subseg_map)
  //as well as the queues.

  //Perform the purge.
  map<Vert*, Vert*> vert_map;
  map<Cell*, Cell*> cell_map;
  map<BFace*, BFace*> bface_map;
  m_mesh->vPurge(&vert_map, NULL, &cell_map, &bface_map);

  //Update m_subface_queue.
  new_subface_queue.clear();
  itbf     = m_subface_queue.begin();
  itbf_end = m_subface_queue.end();
  
  for( ; itbf != itbf_end; ++itbf) {
    old_bface = *itbf;
    assert(bface_map.count(old_bface) == 1);
    bface = bface_map.find(old_bface)->second;
    new_subface_queue.push_back(bface);
  }
  new_subface_queue.swap(m_subface_queue);
  
  //Update m_cell_queue
  m_cell_queue->update_entries_after_purge(cell_map);  

  //Update the vertices in the subseg map. All the subsegment
  //objects will also get updated (no need to do anything with
  //m_subseg_queue as the subsegs are managed by m_subseg_map).
  m_subseg_map.update_vert_data_after_purge(vert_map);

  //Done!

}

















// //The following are a bunch of functions that output stuff to file,
// //mostly to see what I doing doing while debugging the code...

// void TetMeshRefiner::
// output_cavity(const char* const filename,
// 	      const set<Cell*>& cells_to_remove,
// 	      const set<BFace*>& bfaces_to_remove,
// 	      const set<BFace*>& bfaces_encroached) const {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshRefiner::output_cavity(const char* const)");

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   Cell* cell;
//   set<Cell*>::const_iterator 
//     itc = cells_to_remove.begin(), itc_end = cells_to_remove.end();
//   vector<Vert*> verts_to_print;

//   for( ; itc != itc_end; ++itc) {    
//     cell = *itc;
//     assert(!cell->qDeleted());
//     assert(cell->iNumVerts() == 4);
//     verts_to_print.push_back(cell->pVVert(0));
//     verts_to_print.push_back(cell->pVVert(1));
//     verts_to_print.push_back(cell->pVVert(2));
//     verts_to_print.push_back(cell->pVVert(3));
//   }

//   std::sort( verts_to_print.begin(), verts_to_print.end() );
//   verts_to_print.erase( std::unique(verts_to_print.begin(), verts_to_print.end()), 
// 			verts_to_print.end() );

//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()) );

//   Vert* vertex;
//   vector<Vert*>::iterator 
//     itv, itv_beg = verts_to_print.begin(), itv_end = verts_to_print.end();
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vertex->dX(), vertex->dY(), vertex->dZ());
//   }

//   fprintf(out_file, "Tetrahedra\n");
//   fprintf(out_file, "%d\n", static_cast<int>(cells_to_remove.size()) );

//   for(itc = cells_to_remove.begin(); itc != itc_end; ++itc) {
//     cell = *itc;
//     int idx1 = std::find(itv_beg, itv_end, cell->pVVert(0)) - itv_beg + 1;
//     int idx2 = std::find(itv_beg, itv_end, cell->pVVert(1)) - itv_beg + 1;
//     int idx3 = std::find(itv_beg, itv_end, cell->pVVert(2)) - itv_beg + 1;
//     int idx4 = std::find(itv_beg, itv_end, cell->pVVert(3)) - itv_beg + 1;
//     fprintf(out_file, "%d %d %d %d 1\n", idx1, idx2, idx3, idx4);
//   }

//   fprintf(out_file, "End\n");

//   fclose(out_file);

//   /////////////////////////////////////////////////////////////////////////////

//   out_file = fopen("bface_delete.mesh", "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshRefiner::output_cavity(const char* const)");

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   verts_to_print.clear();

//   BFace* bface;
//   set<BFace*>::const_iterator 
//     itbf = bfaces_to_remove.begin(), itbf_end = bfaces_to_remove.end();

//   for( ; itbf != itbf_end; ++itbf) {    
//     bface = *itbf;
//     assert(!bface->qDeleted());
//     assert(bface->iNumVerts() == 3);
//     verts_to_print.push_back(bface->pVVert(0));
//     verts_to_print.push_back(bface->pVVert(1));
//     verts_to_print.push_back(bface->pVVert(2));
//   }

//   std::sort(verts_to_print.begin(), verts_to_print.end());
//   verts_to_print.erase( std::unique(verts_to_print.begin(), verts_to_print.end()), verts_to_print.end() );

//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()) );
  
//   itv_beg = verts_to_print.begin(); itv_end = verts_to_print.end();
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vertex->dX(), vertex->dY(), vertex->dZ());
//   }  

//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", static_cast<int>(bfaces_to_remove.size()) );

//   for(itbf = bfaces_to_remove.begin() ; itbf != itbf_end; ++itbf) {
//     bface = *itbf;
//     assert(bface->iNumVerts() == 3);
//     int idx1 = std::find(itv_beg, itv_end, bface->pVVert(0)) - itv_beg + 1;
//     int idx2 = std::find(itv_beg, itv_end, bface->pVVert(1)) - itv_beg + 1;
//     int idx3 = std::find(itv_beg, itv_end, bface->pVVert(2)) - itv_beg + 1;
//     fprintf(out_file, "%d %d %d 1\n", idx1, idx2, idx3);
//   }

//   fclose(out_file);

//   /////////////////////////////////////////////////////////////////////////////


//   out_file = fopen("bface_encroach.mesh", "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshRefiner::output_cavity(const char* const)");

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   verts_to_print.clear();
//   itbf = bfaces_encroached.begin(), itbf_end = bfaces_encroached.end();

//   for( ; itbf != itbf_end; ++itbf) {    
//     bface = *itbf;
//     assert(!bface->qDeleted());
//     assert(bface->iNumVerts() == 3);
//     verts_to_print.push_back(bface->pVVert(0));
//     verts_to_print.push_back(bface->pVVert(1));
//     verts_to_print.push_back(bface->pVVert(2));
//   }

//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(verts_to_print.size()) );
  
//   itv_beg = verts_to_print.begin(); itv_end = verts_to_print.end();
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vertex->dX(), vertex->dY(), vertex->dZ());
//   }  

//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", static_cast<int>(bfaces_encroached.size()) );

//   for(itbf = bfaces_encroached.begin() ; itbf != itbf_end; ++itbf) {
//     bface = *itbf;
//     assert(bface->iNumVerts() == 3);
//     int idx1 = std::find(itv_beg, itv_end, bface->pVVert(0)) - itv_beg + 1;
//     int idx2 = std::find(itv_beg, itv_end, bface->pVVert(1)) - itv_beg + 1;
//     int idx3 = std::find(itv_beg, itv_end, bface->pVVert(2)) - itv_beg + 1;
//     fprintf(out_file, "%d %d %d 1\n", idx1, idx2, idx3);
//   }

//   fclose(out_file);

// }

// void TetMeshRefiner::
// output_mesh_to_file(const VolMesh* const mesh,
// 		    const char* const filename) {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_mesh_to_file(const char* const)"); 

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   Vert* vertex;
//   int vert_index = 0;
//   std::vector<Vert*> vertices;
//   std::vector<Vert*>::iterator itv, itv_beg, itv_end;
//   GR_map<Vert*, int> verts_to_print;
  
//   for(int i = mesh->iNumVerts() - 1; i >= 0; i--) {
//     vertex = mesh->pVVert(i);
//     if(vertex->qDeleted()) continue;
//     vertices.push_back(vertex);
//     verts_to_print.insert( std::make_pair(vertex, ++vert_index) );
//   }  

//   itv_beg = vertices.begin();
//   itv_end = vertices.end();
//   int num_verts = static_cast<int>(itv_end - itv_beg);

//   fprintf(out_file, "#Set of mesh vertices\n");
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", num_verts);
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", vertex->dX(), vertex->dY(), vertex->dZ());
//   }

//   Face* face;
//   vector<Face*> faces;
//   vector<Face*>::iterator itf, itf_beg, itf_end;
  
//   for(int i = mesh->iNumFaces() - 1; i >= 0; i--) {
//     face = mesh->pFFace(i);
//     if(face->qDeleted()) continue;
//     faces.push_back(face);
//   }

//   itf_beg = faces.begin();
//   itf_end = faces.end();
//   int num_faces = static_cast<int>(itf_end - itf_beg);

//   fprintf(out_file, "#Set of triangles\n");
//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", num_faces);

//   for(itf = itf_beg; itf != itf_end; ++itf) {
//     face = *itf;
//     assert(face->iNumVerts() == 3);
//     int idx1 = verts_to_print.find(face->pVVert(0))->second;
//     int idx2 = verts_to_print.find(face->pVVert(1))->second;
//     int idx3 = verts_to_print.find(face->pVVert(2))->second;
//     fprintf(out_file, "%d %d %d 0\n", idx1, idx2, idx3);
//   }

//   Cell* cell;
//   vector<Cell*> cells;
//   vector<Cell*>::iterator itc, itc_beg, itc_end;

//   for(int i = mesh->iNumCells() - 1; i >= 0; i--) {
//     cell = mesh->pCCell(i);
//     if(cell->qDeleted()) continue;
//     cells.push_back(cell);
//   }

//   itc_beg = cells.begin();
//   itc_end = cells.end();
//   int num_cells = static_cast<int>(itc_end - itc_beg);

//   fprintf(out_file, "#Set of tetrahedra\n");
//   fprintf(out_file, "Tetrahedra\n");
//   fprintf(out_file, "%d\n", num_cells);

//   for(itc = itc_beg; itc != itc_end; ++itc) {
//     cell = *itc;
//     assert(cell->iNumVerts() == 4);
//     int idx1 = verts_to_print.find(cell->pVVert(0))->second;
//     int idx2 = verts_to_print.find(cell->pVVert(1))->second;
//     int idx3 = verts_to_print.find(cell->pVVert(2))->second;
//     int idx4 = verts_to_print.find(cell->pVVert(3))->second;
//     fprintf(out_file, "%d %d %d %d 0\n", idx1, idx2, idx3, idx4);
//   }

//   //COULD ALSO ADD EDGES AND CORNERS

//   fprintf(out_file, "End\n");

//   fclose(out_file);

// }

// void TetMeshRefiner::output_bfaces(const char* const filename,
// 				   const set<BFace*>* const bfaces_to_print) const {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_mesh_to_file(const char* const)"); 

//   VolMesh* mesh = m_mesh;

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   BFace* bface;
//   Vert* vertex;
//   set<Vert*> verts_to_print;
//   vector<Vert*> verts;
//   vector<BFace*> bfaces;

//   if(bfaces_to_print) {
//     set<BFace*>::const_iterator 
//       it = bfaces_to_print->begin(), it_end = bfaces_to_print->end();
//     for( ; it != it_end; ++it) {
//       bface = *it;
//       if(bface->qDeleted()) continue;
//       bfaces.push_back(bface);
//       verts_to_print.insert(bface->pVVert(0));
//       verts_to_print.insert(bface->pVVert(1));
//       verts_to_print.insert(bface->pVVert(2));   
//     }
//   } 
//   else {
//     for(int i = mesh->iNumTotalBdryFaces() - 1; i >= 0; --i) {
//       bface = mesh->pBFBFace(i);
//       if(bface->qDeleted()) continue;
//       bfaces.push_back(bface);
//       verts_to_print.insert(bface->pVVert(0));
//       verts_to_print.insert(bface->pVVert(1));
//       verts_to_print.insert(bface->pVVert(2));    
//     }
//   }
  
//   std::copy(verts_to_print.begin(), verts_to_print.end(),
// 	    std::back_inserter(verts));

//   vector<Vert*>::iterator itv, itv_beg, itv_end;
//   itv_beg = verts.begin();
//   itv_end = verts.end();
//   int num_verts = itv_end - itv_beg;
  
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", num_verts);
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vertex->dX(), vertex->dY(), vertex->dZ());
//   }
  
//   vector<BFace*>::iterator itb = bfaces.begin(), itb_end = bfaces.end();
//   int num_bfaces = itb_end - itb;

//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", num_bfaces);

//   int idx0, idx1, idx2;

//   for( ; itb != itb_end; ++itb) {
    
//     bface = *itb;
//     idx0 = std::find(itv_beg, itv_end, bface->pVVert(0)) - itv_beg + 1;
//     idx1 = std::find(itv_beg, itv_end, bface->pVVert(1)) - itv_beg + 1;
//     idx2 = std::find(itv_beg, itv_end, bface->pVVert(2)) - itv_beg + 1;

//     fprintf(out_file, "%d %d %d 1\n", idx0, idx1, idx2);

//   }

//   fprintf(out_file, "End\n");

//   fclose(out_file);

// }

// void TetMeshRefiner::output_subsegs(const char* const filename) const {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_mesh_to_file(const char* const)"); 
  
//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   Vert* vert;
//   vector<Vert*> verts_to_print;
  
//   Subseg* subseg;
//   int num_subsegs = 0;
//   set<Subseg*> all_subsegs;
//   m_subseg_map.get_all_subsegs(all_subsegs);
//   set<Subseg*>::iterator its = all_subsegs.begin(), its_end = all_subsegs.end();
  
//   for( ; its != its_end; ++its) {
//     subseg = *its;
//     if(subseg->is_deleted()) continue;
//     ++num_subsegs;
//     verts_to_print.push_back(subseg->get_beg_vert());
//     verts_to_print.push_back(subseg->get_end_vert());
//   }

//   std::sort(verts_to_print.begin(), verts_to_print.end());
//   verts_to_print.erase( std::unique(verts_to_print.begin(), verts_to_print.end()), 
// 			verts_to_print.end() );

//   vector<Vert*>::iterator itv, itv_beg = verts_to_print.begin(), itv_end = verts_to_print.end(); 

//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(itv_end - itv_beg));

//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vert = *itv;
//     fprintf(out_file, "%e %e %e 0\n", 
// 	    vert->dX(), vert->dY(), vert->dZ());
//   }

//   fprintf(out_file, "Edges\n");
//   fprintf(out_file, "%d\n", num_subsegs);

//   int idx0, idx1;
//   int color = 0;

//   for(its = all_subsegs.begin(); its != its_end; ++its) {
//     subseg = *its;
//     if(subseg->is_deleted()) continue;
//     idx0 = std::find(itv_beg, itv_end, subseg->get_beg_vert()) - itv_beg + 1;
//     idx1 = std::find(itv_beg, itv_end, subseg->get_end_vert()) - itv_beg + 1;
//     fprintf(out_file, "%d %d %d\n", idx0, idx1, ++color); 
//   }

//   fprintf(out_file, "End\n"); 

//   fclose(out_file);

// }

// void TetMeshRefiner::output_cells(const char* const filename,
// 				  const set<Cell*>& cells_to_print) {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_cells(const char* const, set<Cell*>&)"); 

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   Vert* vert;
//   Face* face;
//   Cell* cell;
//   int vert_index = 0;
//   vector<Vert*> verts;
//   set<Vert*> vert_set;
//   set<Face*> face_set;
//   vector<Vert*>::const_iterator itv, itv_end;
//   set<Face*>::const_iterator itf, itf_end;
//   set<Cell*>::const_iterator itc, itc_end;
//   GR_map<Vert*, int> verts_to_print;
  
//   itc = cells_to_print.begin();
//   itc_end = cells_to_print.end();

//   for( ; itc != itc_end; ++itc) {
//     cell = *itc;
//     if(cell->qDeleted()) continue;
//     assert(cell->iNumVerts() == 4);
//     assert(cell->iNumFaces() == 4);
//     for(int i = 0; i < 4; ++i) {
//       vert = cell->pVVert(i);
//       face = cell->pFFace(i);
//       if(vert_set.insert(vert).second) {
// 	verts.push_back(vert);
// 	verts_to_print.insert(std::make_pair(vert, ++vert_index));
//       }
//       face_set.insert(face);
//     }
//   }

//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", static_cast<int>(vert_set.size()));
  
//   itv = verts.begin();
//   itv_end = verts.end();

//   for( ; itv != itv_end; ++itv) {
//     vert = *itv;
//     fprintf(out_file, "%e %e %e 0\n", vert->dX(), vert->dY(), vert->dZ());
//   }

//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", static_cast<int>(face_set.size()));

//   itf = face_set.begin();
//   itf_end = face_set.end();
//   int color;

//   for( ; itf != itf_end; ++itf) {
//     face = *itf;
//     if(face->pCCellLeft()->eType() == Cell::eTet &&
//        face->pCCellRight()->eType() == Cell::eTet) color = 0;
//     else color = 1;
//     assert(face->iNumVerts() == 3);
//     assert(verts_to_print.count(face->pVVert(0)) == 1);
//     assert(verts_to_print.count(face->pVVert(1)) == 1);
//     assert(verts_to_print.count(face->pVVert(2)) == 1);
//     int idx1 = verts_to_print.find(face->pVVert(0))->second;
//     int idx2 = verts_to_print.find(face->pVVert(1))->second;
//     int idx3 = verts_to_print.find(face->pVVert(2))->second;
//     fprintf(out_file, "%d %d %d %d\n", idx1, idx2, idx3, color);
//   }
  
// //   fprintf(out_file, "Tetrahedra\n");
// //   fprintf(out_file, "%d\n", static_cast<int>(cells_to_print.size()));

// //   itc = cells_to_print.begin();
// //   itc_end = cells_to_print.end();

// //   for( ; itc != itc_end; ++itc) {
// //     cell = *itc;
// //     assert(cell->iNumVerts() == 4);
// //     int idx1 = verts_to_print.find(cell->pVVert(0))->second;
// //     int idx2 = verts_to_print.find(cell->pVVert(1))->second;
// //     int idx3 = verts_to_print.find(cell->pVVert(2))->second;
// //     int idx4 = verts_to_print.find(cell->pVVert(3))->second;
// //     fprintf(out_file, "%d %d %d %d 0\n", idx1, idx2, idx3, idx4);
// //   }

//   fprintf(out_file, "End\n");
//   fclose(out_file);

// }

// void TetMeshRefiner::output_faces(const char* const filename,
// 				  set<Face*>& faces_to_print) const {

//   FILE* out_file = fopen(filename, "w");
//   if(!out_file) vFatalError("Cannot open output file for writing", 
// 			    "TetMeshBuilder::output_faces(const char* const)"); 

//   fprintf(out_file, "MeshVersionFormatted 1\n");
//   fprintf(out_file, "Dimension 3\n");

//   Vert* vertex;
//   Face* face;
//   int vert_index = 0, i, num_faces = 0;
//   std::vector<Vert*> vertices;
//   std::vector<Vert*>::iterator itv, itv_beg, itv_end;
//   GR_map<Vert*, int> verts_to_print;
  
//   set<Face*>::iterator itf = faces_to_print.begin(), itf_end = faces_to_print.end();

//   for( ; itf != itf_end; ++itf) {
//     face = *itf;
//     if(face->qDeleted()) continue;
//     ++num_faces;
//     for(i = 0; i < face->iNumVerts(); ++i) {
//       vertex = face->pVVert(i);
//       assert(!vertex->qDeleted());
//       vertices.push_back(vertex);
//       verts_to_print.insert( std::make_pair(vertex, ++vert_index) );
//     }
//   }  

//   itv_beg = vertices.begin();
//   itv_end = vertices.end();
//   int num_verts = static_cast<int>(itv_end - itv_beg);

//   fprintf(out_file, "#Set of mesh vertices\n");
//   fprintf(out_file, "Vertices\n");
//   fprintf(out_file, "%d\n", num_verts);
  
//   for(itv = itv_beg; itv != itv_end; ++itv) {
//     vertex = *itv;
//     fprintf(out_file, "%e %e %e 0\n", vertex->dX(), vertex->dY(), vertex->dZ());
//   }

//   fprintf(out_file, "#Set of triangles\n");
//   fprintf(out_file, "Triangles\n");
//   fprintf(out_file, "%d\n", num_faces);

//   itf = faces_to_print.begin();
//   itf_end = faces_to_print.end();

//   for( ; itf != itf_end; ++itf) {
//     face = *itf;
//     assert(face->iNumVerts() == 3);
//     int idx1 = verts_to_print.find(face->pVVert(0))->second;
//     int idx2 = verts_to_print.find(face->pVVert(1))->second;
//     int idx3 = verts_to_print.find(face->pVVert(2))->second;
//     fprintf(out_file, "%d %d %d 0\n", idx1, idx2, idx3);
//   }

//   fprintf(out_file, "End\n");
//   fclose(out_file);

// }
