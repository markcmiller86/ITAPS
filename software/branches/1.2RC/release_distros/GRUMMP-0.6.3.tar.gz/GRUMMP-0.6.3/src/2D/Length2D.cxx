#include <set>
#include <queue>
#include <utility>
#include "GR_Length2D.h"
#include "GR_events.h"
#include "GR_misc.h"
#include "GR_Functors.h"
#include "GR_Mesh2D.h"
#include "GR_Entity.h"
#include "GR_Vertex.h"
#include "GR_Face.h"
#include "GR_Cell.h"
#include "GR_GRPoint.h"
#include "GR_GRCurve.h"
#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "DLIList.hpp"
#include "RTree.hpp"

using std::queue;
using std::set;
using std::pair;
using std::make_pair;

Length2D::
Length2D(const LengthType& length_type, 
	 double refine, double grading,
	 double min_length) 
  : m_length_type(length_type), m_refine(refine), 
    m_grade(grading), m_min_length(min_length), 
    m_length_tree(NULL), m_tree_entries(), 
    m_length_check_queue() {
  
  assert(m_refine > 0.);
  assert(m_grade  > 0.);

  switch(m_length_type) {

  case SPECIFIED:
    break;

  case AUTOMATIC:
    break;
    
  case TREE:    
    m_length_tree = new RTree<LengthTreeEntry*>();
    break;

  default:
    assert(0);
    break;

  }

}

Length2D::
~Length2D() {

  std::for_each(m_tree_entries.begin(), 
		m_tree_entries.end(),
		GRUMMP::DeleteObject());

  m_tree_entries.clear();

  if(m_length_tree) 
    delete m_length_tree;

  m_length_tree = NULL;

}

void Length2D::
init_length(const Mesh2D* const mesh) {

  int num_verts = mesh->iNumVerts();
  Vert* vertex;

  for(int i = 0; i < num_verts; i++) {

    vertex = mesh->pVVert(i);
    if(vertex->qDeleted()) continue;

    assert(vertex->qValid());
    
    switch(m_length_type) {

    case SPECIFIED:
      assert(0);
      break;

    case AUTOMATIC:
      init_length_automatic(vertex);
      break;
      
    case TREE:    
      init_length_tree(vertex);
      break;

    default:
      assert(0);
      break;
      
    }

  }

  set_graded_length();

}

void Length2D::
init_length_automatic(Vert* const vertex) {

  assert( vertex->qValid() );
  assert( !vertex->qDeleted() );
  assert( vertex->qIsBdryVert() );
  assert( dynamic_cast<GRPoint*>(vertex->get_parent_entity()) ||
	  dynamic_cast<GRCurve*>(vertex->get_parent_entity()) );
  
  SUMAA_LOG_EVENT_BEGIN(INIT_LENGTH);

  CubitVector vert_coord(vertex->dX(), vertex->dY(), 0.);
  CubitVector closest_coord(LARGE_DBL, LARGE_DBL, LARGE_DBL);
  double beg_param, end_param;

  get_neighborhood(vertex);
  
  assert( !m_neigh.verts.empty() );
  assert( !m_neigh.cells.empty() ); 

  //Closest to boundary vertex is always itself.
  //Must find second closest entities among nearby verts and bfaces.

  //Firstly, neighbor vertices:

  Vert* vert_neigh = NULL;
  double dist_squared, diff_x, diff_y, min_dist_squared = LARGE_DBL;
    
  set<Vert*>::iterator itv     = m_neigh.verts.begin(),
                       itv_end = m_neigh.verts.end();
	  
  for( ; itv != itv_end; ++itv) {
      
    vert_neigh = *itv;
    
    diff_x = vert_neigh->dX() - vertex->dX();
    diff_y = vert_neigh->dY() - vertex->dY();
    
    dist_squared = (diff_x * diff_x) + (diff_y * diff_y);	                    
    min_dist_squared = std::min(dist_squared, min_dist_squared);

  }

  //Now, boundary faces:

  set<Cell*>::iterator itc     = m_neigh.cells.begin(),
                       itc_end = m_neigh.cells.end();

  for( ; itc != itc_end; ++itc) {

    Cell* cell = *itc;
    Face* face = cell->pFFaceOpposite(vertex);
    BdryEdgeBase* bedge = dynamic_cast<BdryEdgeBase*>(face->pCCellOpposite(cell));
    
    if(bedge) {
      
      GRCurve* curve = dynamic_cast<GRCurve*>(bedge->get_curve());
      
      if(bedge->is_forward()) {
	beg_param = bedge->vert0_param();
	end_param = bedge->vert1_param();
      }
      else {
	beg_param = bedge->vert1_param();
	end_param = bedge->vert0_param();
      }
	
      assert( curve );
      assert( m_neigh.bfaces.find(bedge) == m_neigh.bfaces.end() );
      assert( iFuzzyComp(beg_param, end_param) == -1 );

      curve->geom_ptr()->closest_coord_on_curve(vert_coord, closest_coord, 
						beg_param, end_param);

      diff_x = closest_coord.x() - vert_coord.x();
      diff_y = closest_coord.y() - vert_coord.y();

      dist_squared = diff_x * diff_x + diff_y * diff_y;
      min_dist_squared = std::min(dist_squared, min_dist_squared);

    }
      
  }

  vertex->vSetLS( sqrt(min_dist_squared) / m_refine);
  m_length_check_queue.push(vertex);

  SUMAA_LOG_EVENT_END(INIT_LENGTH);

}

void Length2D::
init_length_tree(Vert* const vertex) {

  SUMAA_LOG_EVENT_BEGIN(INIT_LENGTH);

  get_neighborhood(vertex);

  assert( !m_neigh.verts.empty() );
  assert( !m_neigh.cells.empty() ); 

  //Sets an upper on the length scale by computing the distance
  //to the nearest neighbor. Then queries the tree with the 
  //vertex coordinates. If one or more hits are obtained, sets
  //the length scale to the smallest m_length among the hits.

  double length_scale = evaluate_length_from_neighbors(vertex, m_neigh.verts);

  //Now querying the tree, if more than one intersection is found, pick
  //the one with the smallest length scale.

  length_scale = std::min(length_scale, evaluate_length_from_tree(vertex));
  
  vertex->vSetLS(length_scale);

  m_length_check_queue.push(vertex);

  SUMAA_LOG_EVENT_END(INIT_LENGTH);

}

void Length2D::
set_length_scale(Vert* const vertex) {

  assert( vertex->qValid() );
  assert( !vertex->qDeleted() );

  switch(m_length_type) {

  case SPECIFIED:
    assert(0);
    break;

  case AUTOMATIC:
    set_length_scale_automatic(vertex);
    set_graded_length();
    break;
    
  case TREE:    
    set_length_scale_tree(vertex);
    set_graded_length();
    break;
    
  default:
    assert(0);
    break;
      
  }

}

void Length2D::
set_length_scale(Vert* const vertex, 
		 double length_scale) {

  assert(length_scale > 0.);
  assert(vertex->qValid());

  if(m_min_length > 0. && length_scale > m_min_length)
    length_scale = m_min_length;

  vertex->vSetLS(length_scale);

}

void Length2D::
set_length_scale_automatic(Vert* const vertex) {

  SUMAA_LOG_EVENT_BEGIN(LENGTH_SCALE);

  assert( vertex->qValid() );
  assert( !vertex->qDeleted() );

  switch(vertex->iVertType()) {

  case Vert::eBdryApex:
    assert(0);
    break;
  
  case Vert::eBdryCurve: {

    get_neighborhood(vertex);
    assert(m_neigh.bfaces.size() == 2);

    BdryEdgeBase* bedge[] = { dynamic_cast<BdryEdgeBase*>( *(  m_neigh.bfaces.begin()) ),
			      dynamic_cast<BdryEdgeBase*>( *(++m_neigh.bfaces.begin()) ) };

    assert(bedge[0] && bedge[1]);

    Vert *vert[] = { static_cast<Vert*>(NULL), 
		     static_cast<Vert*>(NULL) };

    double param[] = { LARGE_DBL, LARGE_DBL, LARGE_DBL };

    for(int i = 0; i < 2; i++) {

      if(bedge[i]->pVVert(0) == vertex) {
	vert[i]  = bedge[i]->pVVert(1);
	param[2] = bedge[i]->vert0_param();
	param[i] = bedge[i]->vert1_param();
      }
      else {
	assert(bedge[i]->pVVert(1) == vertex);
	vert[i]  = bedge[i]->pVVert(0);
	param[2] = bedge[i]->vert1_param();
	param[i] = bedge[i]->vert0_param();
      }

    }

    //Just interpolate length scale linearly in parametric space for now.

    double slope = ( vert[1]->dLS() - vert[0]->dLS() ) / ( param[1] - param[0] );

    vertex->vSetLS( (param[2] - param[0]) * slope + vert[0]->dLS() );
    m_length_check_queue.push(vertex);
    
    break;

  }
  
  case Vert::eInterior:
    m_length_check_queue.push(vertex);
    break;
  
  }

  SUMAA_LOG_EVENT_END(LENGTH_SCALE);

}

void Length2D::
set_length_scale_tree(Vert* const vertex) {

  SUMAA_LOG_EVENT_BEGIN(LENGTH_SCALE);

  double length_scale = evaluate_length_from_tree(vertex);
  vertex->vSetLS(length_scale);

  m_length_check_queue.push(vertex);

  SUMAA_LOG_EVENT_END(LENGTH_SCALE);

}

void Length2D::
set_graded_length() {

  Vert *vertex = NULL, *neigh_vertex = NULL;
  double length_scale, lip_length, neigh_ls, neigh_dist;

  while(!m_length_check_queue.empty()) {

    lip_length = LARGE_DBL;

    vertex = m_length_check_queue.front();
    m_length_check_queue.pop();
    
    get_neighborhood(vertex);
    
    length_scale = vertex->dLS();
    
    set<Vert*>::iterator it     = m_neigh.verts.begin(),
                         it_end = m_neigh.verts.end();
    
    for(; it != it_end; ++it) {

      neigh_vertex = *it;
      neigh_ls     = neigh_vertex->dLS();
      neigh_dist   = dDistanceBetween(vertex, neigh_vertex);
     
      assert(iFuzzyComp(neigh_ls,   0.) == 1);
      assert(iFuzzyComp(neigh_dist, 0.) == 1);
    
      lip_length = std::min(lip_length, neigh_ls + (neigh_dist / m_grade) );

    }

    assert(iFuzzyComp(lip_length, 0.) == 1);

    length_scale = MIN3( m_min_length < 0. ? LARGE_DBL : m_min_length, lip_length, length_scale);
    vertex->vSetLS(length_scale);  

  }
  
}

void Length2D::
add_to_length_tree(double x_loc, double y_loc, double length) {

  assert(m_length_type == TREE);
  assert(m_length_tree);

  LengthTreeEntry* tree_entry = new LengthTreeEntry(x_loc, y_loc, length);

  m_length_tree->add(tree_entry);
  m_tree_entries.push_back(tree_entry);
    
}

double Length2D::
evaluate_length_from_neighbors(Vert* const vertex, 
			       const set<Vert*>& neigh_verts) const {

  Vert* vert_neigh = NULL;
  double length_scale = LARGE_DBL, dist_squared, diff_x, diff_y;
    
  set<Vert*>::iterator itv     = neigh_verts.begin(),
                       itv_end = neigh_verts.end();
	  
  for( ; itv != itv_end; ++itv) {
      
    vert_neigh = *itv;
    
    diff_x = vert_neigh->dX() - vertex->dX();
    diff_y = vert_neigh->dY() - vertex->dY();
    
    dist_squared = (diff_x * diff_x) + (diff_y * diff_y);
    length_scale = std::min(dist_squared, length_scale);

  }

  return ( sqrt(length_scale) / m_refine );

}

double Length2D::
evaluate_length_from_tree(Vert* const vertex) const {
  
  assert(m_length_type == TREE);
  assert(m_length_tree);

  CubitVector vert_coord( vertex->dX(), vertex->dY(), 0.);
  CubitBox bbox( vert_coord, vert_coord );

  DLIList<LengthTreeEntry*> query_return;

  m_length_tree->find(bbox, query_return);
  int size = query_return.size();

  double length_scale = LARGE_DBL;

  for(int i = 0; i < size; i++) 
    length_scale = std::min( length_scale, 
    			     query_return.next(i)->get_length() / m_refine );
  
  return length_scale;

}

void Length2D::
get_neighborhood(Vert* const vertex) {

  m_neigh.cells.clear();
  m_neigh.verts.clear();
  m_neigh.bfaces.clear();

  if(vertex->qIsBdryVert()) {

    assert( vertex->iVertType() == Vert::eBdryApex ||
	    vertex->iVertType() == Vert::eBdryCurve );
    assert( dynamic_cast<GRPoint*>(vertex->get_parent_entity()) ||
	    dynamic_cast<GRCurve*>(vertex->get_parent_entity()) );
    
    bool bdry_vert = true;
    vNeighborhood(vertex, m_neigh.cells, m_neigh.verts, 
		  &m_neigh.bfaces, &bdry_vert);

  }

  else 
    vNeighborhood(vertex, m_neigh.cells, m_neigh.verts);

}


