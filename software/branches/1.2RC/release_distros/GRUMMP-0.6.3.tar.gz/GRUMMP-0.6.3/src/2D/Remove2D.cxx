#include "GR_assert.h"
#include "GR_Mesh2D.h"
#include "GR_Geometry.h"
#include "GR_events.h"
#include "GR_BFace.h"
#include "GR_Vec.h"

static int iDelReq, iBdryDelReq, iBdryApexDelReq;
static int iDelDone, iBdryDelDone;

struct RemCell {
  Cell *pC;
  Face *pFOnlyV, *pFOnlyV1;
  RemCell() : pC(pCInvalidCell), pFOnlyV(pFInvalidFace),
	      pFOnlyV1(pFInvalidFace) {}
  RemCell(Cell * const pCIn, Face * const pF0, Face * const pF1)
    : pC(pCIn), pFOnlyV(pF0), pFOnlyV1(pF1) {}
};

// To remove a given vertex V from a mesh, there must be a vertex V1
// adjacent to V which is visible from all other vertices adjacent to
// V.  (Note that this specifically does NOT require that the
// neighborhood be convex.)  If this requirement is met, then all faces
// and all cells incident on both V and V1 can be removed from the mesh.
// The faces in the deleted cells which are incident on only one of V
// and V1 occur in pairs and can be matched up and reconnected to ensure
// a valid mesh on output.

bool Mesh2D::
qRemoveVertByContraction (Vert * const pV, int& iNewSwaps,
	     Vert * apVPreferred[], const int iNPref)
  // Remove vertex *pV from the mesh.  Decisions about whether *pV
  // SHOULD be removed are made elsewhere.  The vertices listed in
  // apVPreferred are given a weak preference in determining to which
  // vertex pV should be moved.  This preference takes the form of
  // checking these vertices first in making removal choices.
{
  iNewSwaps = 0;
  iDelReq++;

  if (pV->iVertType () == Vert::eBdryTwoSide) {
    vMessage (4, "Deletion of verts on internal boundaries not yet supported.\n");
    return false;
  }

  if (pV->iVertType () == Vert::eBdryApex) {
    vMessage (2, "Deletion of boundary apexes is forbidden.\n");
    iBdryApexDelReq++;
    return false;
  }
  vMessage (4, "Deleting vertex at (%10f, %10f)\n", pV->dX (), pV->dY ());

//   if (qRemoveVertCheaply(pV, iNewSwaps))
//     return true;

  // List all incident cells on *pV and all vertices in those cells.  As
  // a side effect, find out whether this is a boundary vertex.
  std::set<Cell*> spCIncident;
  std::set<Vert*> spVCand;
  std::set<BFace*> spBFIncident;
  std::set<Face*> spFUpdate;

  std::set<Cell*>::iterator iterC;
  std::set<Vert*>::iterator iterV;
  std::set<BFace*>::iterator iterBF;
  std::set<Face*>::iterator iterF;

  // Put the preferred verts at the head of the list.
  for (int ii = 0; ii < iNPref; spVCand.insert (apVPreferred[ii++])) {}
  bool qBdryVert = false;

  vNeighborhood (pV, spCIncident, spVCand, &spBFIncident, &qBdryVert,
		 &spFUpdate);

  iterC = spCIncident.begin();
  int iReg = (*iterC)->iRegion();
  for ( ; iterC != spCIncident.end(); iterC++) {
    if ((*iterC)->iRegion() != iReg) return false;
  }

  if (qBdryVert) {
    // Abort if boundaries are precious
    if (!qBdryChangesAllowed ())
      return false;

    spVCand.clear ();
    for (iterBF = spBFIncident.begin(); iterBF != spBFIncident.end();
	 iterBF++) {
      BFace *pBF = *iterBF;
      spVCand.insert (pBF->pVVert (0));
      spVCand.insert (pBF->pVVert (1));
    }
    spVCand.erase (pV);
    assert (spVCand.size() == spBFIncident.size());
    iBdryDelReq++;
  }
  else {
    assert (spVCand.size() == spCIncident.size());
    assert (2 * spVCand.size() == spFUpdate.size());
  }

  // List all faces in incident cells that are opposite *pV
  std::vector<Face*> vecpFOpposite;
  for (iterC = spCIncident.begin(); iterC != spCIncident.end(); iterC++) {
    Cell *pC = *iterC;
    if (pC->eType() == Cell::eQuadCell) return false;
    Face *pFOpp = dynamic_cast<TriCell *>(pC)->pFFaceOpposite (pV);
    vecpFOpposite.push_back(pFOpp);
    spFUpdate.erase(pFOpp);
  }
  // For each neighboring vertex, determine whether it is a valid target
  // for edge contraction.  Keep track of which faces affect which
  // vertices.  If no vertices are okay, start with the one with the
  // fewest interfering faces and try to remove that face from the hull
  // by using edge removal to break the connection from *pV to any of
  // the vertices of the face.  If that succeeds, call this routine
  // recursively to do the contraction; otherwise continue until an
  // attempt has been made to remove each problematic face.

  bool qVertOK;
  bool qAnyVertOK = false;
  double dMinDihed;
  double dMaxMinDihed = 0;
  Vert *pV1 = pVInvalidVert, *pVBest = pVInvalidVert;
  for (iterV = spVCand.begin(); iterV != spVCand.end(); iterV++) {
    qVertOK = true;
    dMinDihed = 180;
    pV1 = *iterV;
    for (GR_index_t iF = 0; iF < vecpFOpposite.size() && qVertOK; iF++) {
      Face *pF = vecpFOpposite[iF];
      if (!pF->qHasVert (pV1)) {
	// Determine whether a given face has the correct orientation
	// for the candidate contraction target.  If the orientation
	// test fails, pV1 can't see the correct side of the face pF.
	bool qResult;
	if ((pF->pCCellLeft ())->qHasVert (pV)) {
	  // For this case, the right-hand rule applies for orientation.
	  assert (iOrient2D (pF->pVVert (0), pF->pVVert (1), pV) != -1);
	  qResult = (iOrient2D (pF->pVVert (0), pF->pVVert (1),
				pV1) == 1);
	  if (qResult) {
	    Vert* apV[] = {pF->pVVert (0), pF->pVVert (1), pV1};
	    TriCellCV FT (apV);
	    double dMin = FT.dMinDihed ();
	    double dMax = FT.dMaxDihed ();
	    dMinDihed = min (dMinDihed, min (dMin, 180 - dMax));
	    vMessage (4, "Min dihed (face): %10.6f  (vert): %10.6f\n",
		      FT.dMinDihed (), dMinDihed);
	  }
	}
	else {
	  // Otherwise, the left-hand rule applies for orientation.
	  assert (iOrient2D (pF->pVVert (1), pF->pVVert (0),
			     pV) != -1);
	  qResult = (iOrient2D (pF->pVVert (1), pF->pVVert (0),
				pV1) == 1);
	  if (qResult) {
	    Vert *apV[] = {pF->pVVert (1), pF->pVVert (0), pV1};
	    TriCellCV FT (apV);
	    double dMin = FT.dMinDihed ();
	    double dMax = FT.dMaxDihed ();
	    dMinDihed = min (dMinDihed, min (dMin, 180 - dMax));
	    vMessage (4, "Min dihed (face): %10.6f  (vert): %10.6f\n",
		      FT.dMinDihed (), dMinDihed);
	  }
	}
	if (!qResult) {
	  qVertOK = false;
	}
      }
    }
    if (qVertOK) {
      qAnyVertOK = true;
      if (dMinDihed > dMaxMinDihed) {
	vMessage (4, "Best min dihedral yet.  Old: %10.6f  New: %10.6f\n",
		  dMaxMinDihed, dMinDihed);
	dMaxMinDihed = dMinDihed;
	pVBest = pV1;
      }
    }
  }

  if (!qAnyVertOK) {
    return false;
  }

  // If we get to here, we know we CAN remove *pV by contracting edge
  // (*pV, *pVBest), and that this gives the largest minimum dihedral
  // angle of any possible contraction.
  assert (qAnyVertOK);
  assert (pVBest->qValid ());
  // If the best you can do is really lousy, don't do it.  This will
  // need careful modification for structured meshes.
  // if (dMaxMinDihed < 3.) return false;
  vMessage (4, "%s %u, with min dihedral of %5.2f degrees after.\n",
	    "Contracting to remove vertex", iVertIndex (pV), dMaxMinDihed);

  // At this point:
  //   spCIncident is a list of cells incident on *pV.
  //   spFUpdate contains all the faces incident on pV
  //   vecpFOpposite contains all the faces opposite pV

  // So:
  //   Delete all the cells in spCIncident
  //   For faces in vecpFOpposite that aren't incident on pVBest, create
  //     a new cell connecting them to pVBest
  //   For bdry verts, delete both BFace's incident on pV, identify the
  //     new face on the bdry incident on pVBest, and create a new BFace
  //     for it.
  //   Note that faces get deleted automagically.


  for (iterC = spCIncident.begin(); iterC != spCIncident.end(); iterC++) {
    Cell *pC = *iterC;
    deleteCell(pC);
  }

#ifndef NDEBUG
  std::set<Cell*> spCCheck;
#endif
  for (GR_index_t iF = 0; iF < vecpFOpposite.size() && qVertOK; iF++) {
    Face *pF = vecpFOpposite[iF];
    if (pF->qHasVert(pVBest)) continue;
#ifndef NDEBUG
    Cell *pCNew =
#endif
      createTriCell(pF->pVVert(0), pF->pVVert(1), pVBest, iReg);
#ifndef NDEBUG
    spCCheck.insert(pCNew);
#endif
  }
  
  if (qBdryVert) {
    // Remove from the list of bfaces incident on *pV those not also
    // incident on *pVBest, to get a list of bfaces which will be
    // deleted.
    Vert *pVOtherBdry = pVInvalidVert;
    BFace *pBFOld = pBFInvalidBFace;
    for (iterBF = spBFIncident.begin(); iterBF != spBFIncident.end();
	 iterBF++) {
      BFace *pBF = *iterBF;
      if (pBF->qHasVert(pV)) {
	if (!pBF->qHasVert(pVBest)) {
	  pVOtherBdry = pBF->pVVert(0) == pV ?
	    pBF->pVVert(1) : pBF->pVVert(0);
	  pBFOld = pBF;
	}
      }
    }
    Face *pF = pFFaceBetween(pV, pVOtherBdry);
    (void) createBFace(pF, pBFOld);
    for (iterBF = spBFIncident.begin(); iterBF != spBFIncident.end();
	 iterBF++) {
      BFace *pBF = *iterBF;
      if (pBF->qHasVert(pV)) {
	deleteBFace(pBF);
      }
    }
  }

#ifndef NDEBUG
  for (iterC = spCCheck.begin();
       iterC != spCCheck.end(); iterC++) {
    Cell *pC = *iterC;
    assert (pC->qHasVert (pVBest));
    assert (!pC->qHasVert (pV));
    assert (pC->iFullCheck () == 1);
    assert (iOrient2D (pC->pVVert (0), pC->pVVert (1), pC->pVVert (2)) == 1);
  }
#endif

  // Delete *pV.
  deleteVert(pV);

  int iNumSwaps = 0;
  // Swap every face that was incident to the deleted vertex that survived
  for (iterF = spFUpdate.begin(); iterF != spFUpdate.end(); iterF++) {
    Face *pF = *iterF;
    if (!pF->qDeleted()) {
      iNumSwaps += iFaceSwap(pF);
    }
  }
  
  // Success!
  iDelDone++;
  if (qBdryVert)
    iBdryDelDone++;

  vUpdateLengthScale();

  return true;
}

// Yet another removal method: this one deleted everything in the
// neighborhood of the vertex being deleted, then remeshes the resulting
// star-shaped region.  (For 2D, this is guaranteed to work, so there's
// no problem with this.)  The remeshing uses a front (implemented as a
// set of faces), with each face in the front used to create a Delaunay
// triangle.  When creating triangles, new faces are created iff they
// don't already exist in the front.

// This code fails for boundary verts.

// class FrontFace2D {
//   Vert *pV0, *pV1;
//   Face *pF;
// public:
//   FrontFace2D(Vert * const pVA, Vert * const pVB,
// 	    Face * const pFIn = pFInvalidFace) 
//     : pV0(pVA), pV1(pVB), pF(pFIn) {
//     assert(pV0 != pV1);
//   }
//   Vert *pVVert(const int i) const {
//     assert(i == 0 || i == 1);
//     return (i == 0 ? pV0 : pV1);
//   }
//   Face *pFFace() const {return pF;}
//   bool operator==(const FrontFace2D& FF) const {
//     return ((pV0 == FF.pV0 && pV1 == FF.pV1) ||
// 	    (pV0 == FF.pV1 && pV1 == FF.pV0));
//   }
//   bool operator<(const FrontFace2D& FF) const {
//     Vert *pVMinThis, *pVMaxThis, *pVMinOther, *pVMaxOther;
//     if (pV0 < pV1) {
//       pVMinThis = pV0; pVMaxThis = pV1;
//     }
//     else {
//       pVMinThis = pV1; pVMaxThis = pV0;
//     }
//     if (FF.pV0 < FF.pV1) {
//       pVMinOther = FF.pV0; pVMaxOther = FF.pV1;
//     }
//     else {
//       pVMinOther = FF.pV1; pVMaxOther = FF.pV0;
//     }
//     return ((pVMinThis < pVMinOther) ||
// 	    ((pVMinThis == pVMinOther) && (pVMaxThis < pVMaxOther)));
//   }
// };

bool Mesh2D::qRemoveVert(Vert * const pV, int& iNSwaps)
{
  iNSwaps = 0;
  // Find the neighborhood of pV.

  std::set<Cell*> spCInc;
  std::set<Vert*> spVNeigh;
  std::set<Face*> spFNearby;

  {
    std::set<BFace*> spBFDummy;
    bool qBdryVert;
    vNeighborhood (pV, spCInc, spVNeigh, &spBFDummy, &qBdryVert,
		   &spFNearby);
    
    
    if (qBdryVert) {
      assert(pV->qIsBdryVert());
      assert(spBFDummy.size() >= 2); // Could be greater for a corner
      // where regions meet.
      return false;
    }
    else {
      assert(!pV->qIsBdryVert());
      assert(spBFDummy.empty());
    }
  }

  std::set<Cell*>::iterator iterC = spCInc.begin();
  int iReg = (*iterC)->iRegion();
  for ( ; iterC != spCInc.end(); iterC++) {
    if ((*iterC)->iRegion() != iReg) return false;
  }
  
  // Rip out all the cells in the neighborhood...
  for (iterC = spCInc.begin(); iterC != spCInc.end(); iterC++) {
    Cell *pC = *iterC;
    deleteCell(pC);
  }
  
  // For faces, rip out those incident, and add the other to the set of
  // front faces.
  std::set<Face*> sFF;
  for (std::set<Face*>::iterator iterF = spFNearby.begin();
       iterF != spFNearby.end(); ) {
    Face *pF = *iterF;
    std::set<Face*>::iterator iterTmp = iterF++;
    if (pF->qHasVert(pV)) {
      assert(pF->qDeleted());
      spFNearby.erase(iterTmp);
    }
    else {
      Vert *pV0 = pF->pVVert(0);
      Vert *pV1 = pF->pVVert(1);
      // Update the vertex hints for all vertices in the hull, since
      // their hints may currently be faces that are being deleted.
      pV0->vSetHintFace(pF);
      pV1->vSetHintFace(pF);

      sFF.insert(pF);
    }
  } // Done with loop over faces.

  // Mark the vertex as deleted.
  deleteVert(pV);
  int iNumNewCells = 0;

  // For each face in the hull, build the Delaunay triangle that belongs
  // on it.
  do {
    assert(sFF.size() >= 3);
    // Maintaining this list correctly is easier if you just rebuild it
    // every time.
    std::set<Vert*> spVCand;
    {
      std::set<Face*>::iterator iter;
      for (iter = sFF.begin(); iter != sFF.end(); iter++) {
	spVCand.insert((*iter)->pVVert(0));
	spVCand.insert((*iter)->pVVert(1));
      }
      assert(spVCand.size() <= sFF.size());
    }

    Face *pF = *sFF.begin();
    Vert *pV0, *pV1;
    if (pF->pCCellLeft() == pCInvalidCell) {
      pV0 = pF->pVVert(0);
      pV1 = pF->pVVert(1);
    }
    else {
      pV0 = pF->pVVert(1);
      pV1 = pF->pVVert(0);
    }

    // Find the right vertex: the one on the correct side of the face
    // with no point in the resulting circumcircle.  In case of ties
    // between candidate verts, pick the one nearest the face midpoint.
    std::set<Vert*>::iterator iterV;
    for (iterV = spVCand.begin();
	 iterV != spVCand.end() && iOrient2D(pV0, pV1, *iterV) != 1;
	 iterV++) {}
    assert(iterV != spVCand.end());
    Vert *pVBest = *iterV++;
    for ( ; iterV != spVCand.end(); iterV++) {
      Vert *pVCand = *iterV;
      if (pVCand == pV0 || pVCand == pV1) continue;
      if (iOrient2D(pV0, pV1, pVCand) == 1) {
	int iIncircleResult = iIncircle(pV0, pV1, pVBest, pVCand);
	if (iIncircleResult == 1) {
	  pVBest = pVCand;
	}
	else if (iIncircleResult == 0) {
	  double adMid[] = {0.5 * (pV0->dX() + pV1->dX()),
			    0.5 * (pV0->dY() + pV1->dY())};
	  if (dDIST2D(adMid, pVCand->adCoords()) <
	      dDIST2D(adMid, pVBest->adCoords()))
	    pVBest = pVCand;
	}
      }
    }
    // At this point, pVBest is definitely the one.
    
    // Create the new cell 
    iNumNewCells++;
    Cell *pCNew = createTriCell(pV0, pV1, pVBest, iReg);
    for (int i = 0; i < 3; i++) {
      pF = pCNew->pFFace(i);
      if (sFF.find(pF) != sFF.end()) {
	sFF.erase(pF);
      }
      else {
	sFF.insert(pF);
      }
    }
  } while (!sFF.empty());

  assert(iNumNewCells == int(spFNearby.size()) - 2);
  
  // Always succeeds.
  return true;
}

