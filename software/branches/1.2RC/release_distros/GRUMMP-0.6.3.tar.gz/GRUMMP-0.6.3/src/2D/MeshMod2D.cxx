#include "GR_config.h"
#include "GR_Classes.h"

#include "GR_BFace.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Geometry.h"
#include "GR_GRCurve.h"
#include "GR_Mesh2D.h"
#include "GR_Vertex.h"

// The semantics of these calls are essentially identical to the ITAPS
// createEnt calls.
//   createFace returns a face with verts pV0 and pV1; if the face
//     already existed it might be opposite in sense, but that's OK.
//   createCell returns a cell with given faces.  In GRUMMP (though not
//     in ITAPS) that cell can't have existed already.
//   createCell returns a cell with given verts.  Faces are created as
//     needed.
//
// At present, canonical ordering of the input data is assumed for faces
// and vert->tri.  For vert->quad, it's mandatory, to prevent
// awkwardness like introducing edges on diagonals of a quad.

// Face* Mesh2D::createFace(Vert * const apV[], const int iNVerts)
// {
//   assert(iNVerts == 2);
//   Vert *pV0 = apV[0];
//   Vert *pV1 = apV[1];
//   assert(pV0->qValid());
//   assert(pV1->qValid());
//   return (createFace(pV0, pV1));
// }

Face* Mesh2D::createFace(bool& qExistedAlready,
			 Vert * const pV0, Vert * const pV1)
{
  assert(pV0->qValid());
  assert(pV1->qValid());
  // Check for prior existence.
  Face *pF = findCommonFace(pV0, pV1, true);
  if (pF == pFInvalidFace) {
    // Face doesn't exist yet.
    pF = pFNewFace();
    pF->vSetVerts(pV0, pV1);
    pF->vSetLeftCell(NULL);
    pF->vSetRightCell(NULL);
    qExistedAlready = false;
    createFaceEvent(pF);
  }
  else {
    qExistedAlready = true;
  }
#ifndef OMIT_VERTEX_HINTS
  // Make sure verts always have a valid hint face...
  if (!pV0->pFHintFace()->qValid())
    pV0->vSetHintFace(pF);
  if (!pV1->pFHintFace()->qValid())
    pV1->vSetHintFace(pF);
#endif

  assert(pF->iFullCheck());

  return pF;
}

BFace* Mesh2D::createBFace(Face * const pF, BFace * const pBFOld)
{
  // Faces must already exist
  assert(pF->qValid());
  // Must have exactly one open connectivity slot for the face!
  assert(XOR(pF->pCCellLeft()->qValid(), pF->pCCellRight()->qValid()));

  BFace *pBF = pBFNewBFace();

  pBF->vAssign(pF);
  pF->vAddCell(pBF);
  pF->vSetFaceLoc(Face::eBdryFace);
  assert(pBF->iFullCheck());
  assert(pBF->pFFace() == pF);
  assert(pF->pCCellLeft() == pBF ||
	 pF->pCCellRight() == pBF);

#ifndef OMIT_VERTEX_HINTS
  // Make sure that bdry verts have bdry hints
  pF->pVVert(0)->vSetHintFace(pF);
  pF->pVVert(1)->vSetHintFace(pF);
#endif

  // This is a really stinky way to copy bdry data, but that's what
  // works currently in 2D.
  if (pBFOld->qValid()) {
    dynamic_cast<BdryEdge *>(pBF)->
      vSetPatch (reinterpret_cast<BdryPatch*>(0x1)); // NULL would trigger an assertion...
  }

  return pBF;
}
  
BFace* Mesh2D::createBFace(Face * const pF, const int i)
{
  // Faces must already exist
  assert(pF->qValid());
  // Must have exactly one open connectivity slot for the face!
  assert(XOR(pF->pCCellLeft()->qValid(), pF->pCCellRight()->qValid()));

  BFace *pBF = pBFNewBFace();

  pBF->vAssign(pF);
  pF->vAddCell(pBF);
  pF->vSetFaceLoc(Face::eBdryFace);
  assert(pBF->iFullCheck());
  assert(pBF->pFFace() == pF);
  assert(pF->pCCellLeft() == pBF ||
	 pF->pCCellRight() == pBF);

#ifndef OMIT_VERTEX_HINTS
  // Make sure that bdry verts have bdry hints
  pF->pVVert(0)->vSetHintFace(pF);
  pF->pVVert(1)->vSetHintFace(pF);
#endif

  dynamic_cast<BdryEdge*>(pBF)->vSetBdryCond(abs(i));

  return pBF;
}
  
IntBdryEdge* Mesh2D::createIntBdryEdge(Face* const pFA, Face* const pFB,
				       BFace* const pIBEOld)
{
  // Faces must already exist
  assert(pFA->qValid());
  assert(pFB->qValid());
  // Must have exactly one open connectivity slot for the face!
  assert(XOR(pFA->pCCellLeft()->qValid(), pFA->pCCellRight()->qValid()));
  assert(XOR(pFB->pCCellLeft()->qValid(), pFB->pCCellRight()->qValid()));

  IntBdryEdge* pIBE = pIBENewIntBdryEdge();
  pIBE->vAssign(pFA, pFB);
  pFA->vAddCell(pIBE);
  pFB->vAddCell(pIBE);
  pFA->vSetFaceLoc(Face::eBdryTwoSide);
  pFB->vSetFaceLoc(Face::eBdryTwoSide);
  assert(pIBE->iFullCheck());
  assert(pIBE->pFFace(0) == pFA);
  assert(pIBE->pFFace(1) == pFB);
  assert(pFA->pCCellLeft() == pIBE ||
	 pFA->pCCellLeft() == pIBE);
  assert(pFB->pCCellLeft() == pIBE ||
	 pFB->pCCellLeft() == pIBE);

#ifndef OMIT_VERTEX_HINTS
  // Make sure that bdry verts have bdry hints
  pFA->pVVert(0)->vSetHintFace(pFA);
  pFA->pVVert(1)->vSetHintFace(pFA);
#endif

  // This is a really stinky way to copy bdry data, but that's what
  // works currently in 2D.
  if (pIBEOld->qValid()) {
    dynamic_cast<BdryEdge *>(pIBE)->
      vSetPatch (reinterpret_cast<BdryPatch*>(0x1)); // NULL would trigger an assertion...
  }

  return pIBE;
}

// Cell* Mesh2D::createCell(Face * const apF[], const int iNFaces, const int iReg)
// // Faces are stored in canonical order.  Also, face->cell connectivity
// // is set up as part of this function.
// {
//   assert(iNFaces == 3 || iNFaces == 4);
//   if (iNFaces == 3) {
//     // Faces must already exist
//     return createTriCell(apF[0], apF[1], apF[2], iReg);
//   }
//   else {
//     return createQuadCell(apF[0], apF[1], apF[2], apF[3], iReg);
//   }
// }

TriCell* Mesh2D::createTriCell(Face * const pF0, Face * const pF1,
			    Face * const pF2, const int iReg)
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());

  // Set up the face->cell connectivity properly.  The canonical tri
  // looks like this:
  //
  //                2
  //               / \         .
  //              /   \        .
  //             2     1       .
  //            /       \      .
  //           0 - -0- - 1


  // Each pair of faces  must have a common vert.
  Vert *apV[3];
  apV[0] = pVCommonVert(pF0, pF2);
  apV[1] = pVCommonVert(pF0, pF1);
  apV[2] = pVCommonVert(pF1, pF2);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());

  TriCell *pC = dynamic_cast<TriCell*>(pCNewCell(3));
  pC->vSetRegion(iReg);

  int iOrient = iOrient2D(apV[0], apV[1], apV[2]);
  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pC->vAssign(pF0, pF1, pF2);
  }
  else {
    // Left-handed (faces 1 and 2 reversed above)
    pC->vAssign(pF0, pF2, pF1);
  }
  
  if (XOR(iOrient == 1, (pF0->pVVert(0) == apV[0])))
    { pF0->vSetRightCell(pC); }
  else
    { pF0->vSetLeftCell(pC); }
  
  if (XOR(iOrient == 1, (pF1->pVVert(0) == apV[1])))
    { pF1->vSetRightCell(pC); }
  else
    { pF1->vSetLeftCell(pC); }
  
  if (XOR(iOrient == 1, (pF2->pVVert(0) == apV[2])))
    { pF2->vSetRightCell(pC); }
  else
    { pF2->vSetLeftCell(pC); }

  assert(pC->iFullCheck());
  assert(pC->qHasFace(pF0));
  assert(pC->qHasFace(pF1));
  assert(pC->qHasFace(pF2));
  assert(pF0->iFullCheck());
  assert(pF1->iFullCheck());
  assert(pF2->iFullCheck());

  createCellEvent(pC);
  return pC;
}


TriCell* Mesh2D::createTriCell(Vert * const pV0, Vert * const pV1,
			    Vert * const pV2, const int iReg)
{
  bool qExist;
  Face *pF01 = createFace(qExist, pV0, pV1);
  Face *pF12 = createFace(qExist, pV1, pV2);
  Face *pF20 = createFace(qExist, pV2, pV0);
  // Some faces will exist; others won't.

  TriCell *pC = createTriCell(pF01, pF12, pF20, iReg);
  assert(pC->qHasVert(pV0));
  assert(pC->qHasVert(pV1));
  assert(pC->qHasVert(pV2));
  return (pC);
}


QuadCell* Mesh2D::createQuadCell(Vert * const pV0, Vert * const pV1,
				 Vert * const pV2, Vert * const pV3,
				 const int iReg)
{
  bool qExist;
  Face *pF01 = createFace(qExist, pV0, pV1);
  Face *pF12 = createFace(qExist, pV1, pV2);
  Face *pF23 = createFace(qExist, pV2, pV3);
  Face *pF30 = createFace(qExist, pV3, pV0);
  // Some faces will exist; others won't.

  QuadCell *pC = createQuadCell(pF01, pF12, pF23, pF30, iReg);
  assert(pC->qHasVert(pV0));
  assert(pC->qHasVert(pV1));
  assert(pC->qHasVert(pV2));
  assert(pC->qHasVert(pV3));
  return (pC);
}


QuadCell* Mesh2D::createQuadCell(Face * const pF0, Face * const pF1,
				 Face * const pF2, Face * const pF3,
				 const int iReg)
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());
  assert(pF3->qValid());

  // Set up the face->cell connectivity properly.  The canonical quad
  // looks like this (see ITAPS docs):
  //
  //      3 - -2- - 2
  //       \         \         .
  //        \         \        .
  //         3         1       .
  //          \         \      .
  //           0 - -0- - 1


  // Each pair of faces  must have a common vert.
  Vert *apV[4];
  apV[0] = pVCommonVert(pF0, pF3);
  apV[1] = pVCommonVert(pF0, pF1);
  apV[2] = pVCommonVert(pF1, pF2);
  apV[3] = pVCommonVert(pF2, pF3);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());
  assert(apV[3]->qValid());

  QuadCell *pC = dynamic_cast<QuadCell*>(pCNewCell(4));
  pC->vSetRegion(iReg);

  int iOrient = iOrient2D(apV[0], apV[1], apV[2]);
  assert(iOrient2D(apV[0], apV[2], apV[3]) == iOrient);

  if (XOR(iOrient == 1, (pF0->pVVert(0) == apV[0])))
    { pF0->vSetRightCell(pC); }
  else
    { pF0->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF1->pVVert(0) == apV[1])))
    { pF1->vSetRightCell(pC); }
  else
    { pF1->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF2->pVVert(0) == apV[2])))
    { pF2->vSetRightCell(pC); }
  else
    { pF2->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF3->pVVert(0) == apV[3])))
    { pF3->vSetRightCell(pC); }
  else
    { pF3->vSetLeftCell(pC); }

  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pC->vAssign(pF0, pF1, pF2, pF3);
  }
  else {
    // Left-handed (faces 2 and 3 reversed above)
    pC->vAssign(pF0, pF3, pF2, pF1);
  }

  assert(pC->iFullCheck());
  assert(pC->qHasFace(pF0));
  assert(pC->qHasFace(pF1));
  assert(pC->qHasFace(pF2));
  assert(pC->qHasFace(pF3));
  assert(pF0->iFullCheck());
  assert(pF1->iFullCheck());
  assert(pF2->iFullCheck());
  assert(pF3->iFullCheck());

  createCellEvent(pC);
  return pC;
}

// Cell* Mesh2D::createCell(Vert* const apV[], const int iNVerts, const int iReg)
// {
//   if (iNVerts == 3) {
//     return (createTriCell(apV[0], apV[1], apV[2], iReg));
//   }
//   else {
//     assert(iNVerts == 4);
//     return (createQuadCell(apV[0], apV[1], apV[2], apV[3], iReg));
//   }
// }  

bool Mesh2D::deleteCell(Cell * const pC)
{
  if (pC->qDeleted()) return true;
  // Free up connectivity for faces.
  for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pC->pFFace(i);
    if (pF->qValid()) {
      pF->vRemoveCell(pC);
      if (!pF->pCCellLeft()->qValid() &&
	  !pF->pCCellRight()->qValid()) deleteFace(pF);
    }
  }
  // Under the old data structures, just mark it.
  pC->vMarkDeleted();
  // With the new (2010) containers, also register the deletion with the
  // container.
  switch (pC->eType()) {
  case CellSkel::eTriCell:
    ECTri.deleteEntry(static_cast<TriCell*>(pC));
    break;
  case CellSkel::eQuadCell:
    ECQuad.deleteEntry(static_cast<QuadCell*>(pC));
    break;
  default:
    assert(0);
    break;
  }
  deleteCellEvent(pC);
  return true;
}

// This function is not technically necessary, under the old data
// structures. 
bool Mesh2D::deleteBFace(BFace * const pBF)
{
  if (pBF->qDeleted()) return true;
  Face *pF = pBF->pFFace();
  if (pF->qValid()) {
    pF->vRemoveCell(pBF);
    if (!pF->pCCellLeft()->qValid() &&
	!pF->pCCellRight()->qValid()) deleteFace(pF);
  }

  if (pBF->iNumFaces() == 2 && pBF->pFFace(1)->qValid()) {
    pF = pBF->pFFace(1);
    pF->vRemoveCell(pBF);
    if (!pF->pCCellLeft()->qValid() &&
	!pF->pCCellRight()->qValid()) {
      deleteFace(pF);
    }
  }
    
  // Under the old data structures, just mark it.
  pBF->vMarkDeleted();
  // With the new (2010) containers, also register the deletion with the
  // container.
  switch (pBF->eType()) {
  case CellSkel::eBdryEdge:
    ECEdgeBF.deleteEntry(static_cast<BdryEdge*>(pBF));
    break;
  case CellSkel::eIntBdryEdge:
    ECIntEdgeBF.deleteEntry(static_cast<IntBdryEdge*>(pBF));
    break;
  default:
    assert(0);
    break;
  }
  deleteBFaceEvent(pBF);
  return true;
}

// Like ITAPS, faces that are in use can't be deleted.
bool Mesh2D::deleteFace(Face * const pF)
{
  if (pF->qDeleted()) return true;
  if ((pF->pCCellRight()->qValid() || pF->pCCellLeft()->qValid()))
    return false;
  pF->pVVert(0)->vRemoveFace(pF);
  pF->pVVert(1)->vRemoveFace(pF);
#ifndef OMIT_VERTEX_HINTS
  // Make sure that verts whose hint is going away realize it...
  if (pF->pVVert(0)->pFHintFace() == pF) {
    pF->pVVert(0)->vUpdateHintFace();
  }
  if (pF->pVVert(1)->pFHintFace() == pF) {
    pF->pVVert(1)->vUpdateHintFace();
  }
#endif

  // Under the old data structures, just mark it.
  pF->vMarkDeleted();
  // With the new (2010) containers, also register the deletion with the
  // container.
  ECEdgeF.deleteEntry(static_cast<EdgeFace*>(pF));
  deleteFaceEvent(pF);
  return true;
}

Vert* Mesh2D::createVert(const double dX, const double dY, const double )
{
  double adData[] = {dX, dY};
  return createVert(adData);
}

Vert* Mesh2D::createVert(const double adCoords[2])
{
  Vert *pV = pVNewVert();
  pV->vClearHintFace();
  pV->vClearFaceConnectivity();
  pV->vSetDefaultFlags();
  pV->vSetCoords(2, adCoords);
  createVertEvent(pV);
  return pV;
}

// For verts, it's non-trivial to keep the hint face up to date as faces
// are deleted, so there's no reliable test for when these are safe to
// delete.  So just mark it, and caveat emptor.
bool Mesh2D::deleteVert(Vert * const pV)
{
  if (pV->qDeleted()) return true;
  if (pV->iNumFaces() == 0) {
    pV->vClearFaceConnectivity();
    // Under the old data structures, just mark it.
    pV->vMarkDeleted();
    // With the new (2010) containers, also register the deletion with the
    // container.
    ECVerts.deleteEntry(pV);
    deleteVertEvent(pV);
    return true;
  }
  else {
    return false;
  }
}

void Mesh2D::vResetVertexConnectivity()
{
  for (int i = iNumVerts() - 1; i >= 0; i--) {
    Vert *pV = pVVert(i);
    if (pV->qDeleted()) continue;
    pV->vClearFaceConnectivity();
  }

  for (int i = iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pFFace(i);
    if (pF->qDeleted()) continue;
    for (int ii = pF->iNumVerts() - 1; ii >= 0 ; ii--) {
      pF->pVVert(ii)->vAddFace(pF);
    }
  }
}

//Private call used by TriMeshBuilder and Watson boundary insertion
IntBdryEdge* Mesh2D::createIntBdryEdge(Vert* const pVBeg, 
				       Vert* const pVEnd,
				       GRCurve* const curve,
				       double dBegParam,
				       double dEndParam )
{
  int iRegLeft  = curve->region_left();
  int iRegRight = curve->region_right();

  assert(iRegRight != 0 && iRegLeft != 0);

  // Find the face connecting the two verts, if it exists
  Face *pF = pFFaceBetween(pVBeg, pVEnd);
  
  Cell *pCLeft, *pCRight;

  if(pF->pVVert(0) == pVEnd) {
    pF->vInterchangeCellsAndVerts();
  }
  
  assert(pF->pVVert(0) == pVBeg);
  assert(pF->pVVert(1) == pVEnd);
  pCLeft  = pF->pCCellLeft();
  pCRight = pF->pCCellRight();

  assert(pCLeft->iRegion() == iRegLeft);
  assert(pCRight->iRegion() == iRegRight);
  pCLeft->vSetRegion(iRegLeft);
  pCRight->vSetRegion(iRegRight);
  
  IntBdryEdge* pIBENew = pIBENewIntBdryEdge();
  Face* pFNew = pFNewFace();
  
  pF->vSetFaceLoc(Face::eBdryTwoSide);
  pFNew->vSetFaceLoc(Face::eBdryTwoSide);
  
  pF   ->vReplaceCell(pCRight, pIBENew);

  pFNew->vAssign(pIBENew, pCRight, pVBeg, pVEnd);
  
  pCRight->vReplaceFace(pF, pFNew);
  
  pIBENew->vAssign(pF, pFNew);
  pIBENew->set_curve(curve);
  pIBENew->set_vert0_param(dBegParam);
  pIBENew->set_vert1_param(dEndParam);
    
  pVBeg->vSetHintFace(pF);
  pVEnd->vSetHintFace(pF);

  assert(pIBENew->pVVert(0) == pVBeg &&
	 pIBENew->pVVert(1) == pVEnd);

  createBFaceEvent(pIBENew);
  return pIBENew;
}

BdryEdge* Mesh2D::createBdryEdge(Vert* const pVBeg, 
				 Vert* const pVEnd,
				 GRCurve* const curve,
				 double dBegParam,
				 double dEndParam )
{
  int iRegLeft  = curve->region_left();
  int iRegRight = curve->region_right();

  assert(XOR(iRegRight != iInvalidRegion, iRegLeft != iInvalidRegion));
  //"Regular" boundary edge.

  Face* pF = pFFaceBetween(pVBeg, pVEnd);
  assert(pF->qHasVert(pVBeg) && pF->qHasVert(pVEnd));
  pF->vSetFaceLoc(Face::eBdryFace);
    
  BdryEdge* pBENew = dynamic_cast<BdryEdge*>(pBFNewBFace());
  assert(pBENew);
  pBENew->set_curve(curve);
  pBENew->vAssign(pF);

#ifndef OMIT_VERTEX_HINTS
  // Make sure that bdry verts have bdry hints
  pF->pVVert(0)->vSetHintFace(pF);
  pF->pVVert(1)->vSetHintFace(pF);
#endif

  // Ensure that the edge and curve have the same orientation
  if ((dBegParam < dEndParam && pVBeg == pF->pVVert(1)) ||
      (dBegParam > dEndParam && pVBeg == pF->pVVert(0))) {
    pF->vInterchangeCellsAndVerts();
  }
  
  if (iRegRight == iInvalidRegion) {
    // Domain is on the left.
    Cell *pC = pF->pCCellRight();
    if (pC != pCInvalidCell) {
      pC->vRemoveFace(pF);
      pC->vSetRegion(iOutsideRegion);
    }
    pF->vSetRightCell(pBENew);
    
  }
  else {
    // Domain is on the right.
    Cell *pC = pF->pCCellLeft();
    if (pC != pCInvalidCell) {
      pC->vRemoveFace(pF);
      pC->vSetRegion(iOutsideRegion);
    }
    pF->vSetLeftCell(pBENew);
  }
  if (pBENew->pVVert(0) == pF->pVVert(0)) {
    pBENew->set_vert0_param(dBegParam);
    pBENew->set_vert1_param(dEndParam);
  }
  else {
    pBENew->set_vert0_param(dEndParam);
    pBENew->set_vert1_param(dBegParam);
  }

  assert((pF->pVVert(0) == pBENew->pVVert(0) &&
	  pBENew->vert0_param() < pBENew->vert1_param()) ||
	 (pF->pVVert(0) == pBENew->pVVert(1) &&
	  pBENew->vert0_param() > pBENew->vert1_param()));

  assert(pF->iFullCheck() == 1);
  assert(pBENew->iFullCheck() == 1);
  assert(pBENew->pFFace() == pF);
  assert(pF->pCCellLeft() == pBENew ||
	 pF->pCCellRight() == pBENew);

  createBFaceEvent(pBENew);
  return pBENew;
}
