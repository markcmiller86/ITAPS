#include <cstdio>
#include <set>
#include <list>
#include <deque>

#include "GR_events.h"
#include "GR_GRCurve.h"
#include "GR_GRGeom2D.h"
#include "GR_GRPoint.h"
#include "GR_Mesh2D.h"

/// Read 2D mesh file and coordinate bdry entities with a geometry.
Mesh2D::Mesh2D(const char strFileName[],
	       GRGeom2D* const geometry,
	       const int iQualMeas)
  : Mesh(), ECEdgeF(), ECEdgeBF(), ECTri(), ECQuad(), ECIntEdgeBF(), 
    iOnEdge(0), iOnBdryEdge(0), iOnBdryEdge2(0),
    iInterior(0), iInternalBdry(0), iInternalBdry2(0)
{

  SUMAA_LOG_EVENT_BEGIN (INIT_TRI);
  SUMAA_LOG_EVENT_BEGIN (READ_MESH_2D);

  // These will both be factored out eventually.
  pQ = new Quality(this, iQualMeas);
  SMinitSmoothing(2, 'f', OPTMS_DEFAULT, OPTMS_DEFAULT, &pvSmoothData);

  // Read the actual data

  readMeshFile(strFileName);
  vSetAllHintFaces ();

  relateMeshToGeometry(geometry);


  SUMAA_LOG_EVENT_END (READ_MESH_2D);
  SUMAA_LOG_EVENT_END (INIT_TRI);
}

void Mesh2D::readMeshFile(const char strFileName[])
{
  if (strcasestr(strFileName, ".vtk") != NULL) {
    // Read a VTK legacy file
#ifndef NDEBUG
  #warning Need an actual clearMeshData function, at some point...
#endif
//     clearMeshData();
    readVTKLegacy(*this, strFileName);
  }
  else if (strcasestr(strFileName, ".mesh") != NULL) {
    // Read a GRUMMP native file
//     clearMeshData();
    readNative(*this, strFileName);
  }
  else {
    // File format not currently recognized
    vFatalError("File format not recognized",
		"Mesh2D::readMeshFile");
  }
}

void Mesh2D::relateMeshToGeometry(GRGeom2D* const geometry)
{
  if (!geometry) return;

  if (geometry->initialized()) {
    std::list<GRCurve*> curve_list; geometry->get_curves(curve_list);
    std::list<GRCurve*>::iterator it_curve, it_curve_end;
    std::list<GRPoint*> point_list; geometry->get_points(point_list);
    std::list<GRPoint*>::iterator it_point, it_point_end;

    BdryEdgeBase* bedge;
    std::set<BdryEdgeBase*> all_bedges;

    for(size_t i = 0; i < iNumBdryFaces(); i++) {
      bedge = dynamic_cast<BdryEdgeBase*>(pBFBFace(i)); assert(bedge);
      all_bedges.insert(bedge);
    }
    for(GR_index_t i = 0; i < iNumIntBdryFaces(); i++) {
      bedge = dynamic_cast<BdryEdgeBase*>(pIBEIntBdryEdge(i)); assert(bedge);
      all_bedges.insert(bedge);
    }

    std::deque<BdryEdgeBase*> bedge_chain;
    std::deque<BdryEdgeBase*>::iterator it_chain;

    GRPoint* point;
    GRCurve* curve;

    Vert*       vert[2];
    Face*       face;
    double      vert_param[2];
    CubitVector vert_coord[2];

    BdryEdgeBase* bdry_edge[2];


    while(!all_bedges.empty()) {

      //Finding the first bdry edge of the chain.

      bdry_edge[0] = bdry_edge[1] = *(all_bedges.begin());
      all_bedges.erase(all_bedges.begin());

      vert[0]     = bdry_edge[0]->pVVert(0);
      vert[1]     = bdry_edge[1]->pVVert(1);
      vert_coord[0].set(vert[0]->dX(), vert[0]->dY(), 0.);
      vert_coord[1].set(vert[1]->dX(), vert[1]->dY(), 0.);

      it_curve     = curve_list.begin();
      it_curve_end = curve_list.end();

      do {
	curve = *it_curve;
	vert_coord[0].set(vert[0]->dX(), vert[0]->dY(), 0.);
	vert_coord[1].set(vert[1]->dX(), vert[1]->dY(), 0.);
	if( curve->geom_ptr()->coord_on_curve(vert_coord[0], &vert_param[0]) &&
	    curve->geom_ptr()->coord_on_curve(vert_coord[1], &vert_param[1]) )
	  break;
      } while(++it_curve != it_curve_end); assert(it_curve != it_curve_end);

      curve_list.erase(it_curve);

      bdry_edge[0]->set_curve(curve);
      bdry_edge[0]->set_vert0_param(vert_param[0]);
      bdry_edge[0]->set_vert1_param(vert_param[1]);

      assert(bedge_chain.empty());
      bedge_chain.push_back(bdry_edge[0]);

      //Building the chain.

      do {
	assert( vert[0] || vert[1] );
	for(int i = 0; i < 2; i++) {
	  if(!vert[i]) continue;
	  
	  if( iFuzzyComp(vert_param[i], curve->geom_ptr()->min_param()) == 0 ||
	      iFuzzyComp(vert_param[i], curve->geom_ptr()->max_param()) == 0 ) {
	    // A curve end point
	    if(!vert[i]->get_parent_entity()) {
	      it_point     = point_list.begin();
	      it_point_end = point_list.end();
	      do {
		point = *it_point;
		if( iFuzzyComp(vert[i]->dX(), point->X()) == 0 &&
		    iFuzzyComp(vert[i]->dY(), point->Y()) == 0 )
		  { vert[i]->set_parent_entity(point); break;}
	      } while(++it_point != it_point_end);
	      if(it_point != it_point_end)
		point_list.erase(it_point);
	    }
	    // Done getting parent entity for vert at curve end point.
	    vert[i] = NULL;
	  }
	  else {
	    // Interior to a curve
	    if(!vert[i]->get_parent_entity()) vert[i]->set_parent_entity(curve);

	    std::set<BFace*> neigh_bfaces;
	    std::set<BFace*>::iterator it_bface;
	    {
	      bool is_bdry_vert;
	      std::set<Cell*> dummy_cell_set;
	      std::set<Vert*> dummy_vert_set;
	      
	      vNeighborhood(vert[i], dummy_cell_set, dummy_vert_set,
			    &neigh_bfaces, &is_bdry_vert); assert(is_bdry_vert);
	    }
	    if(neigh_bfaces.size() != 2) {
	      // Can this ever happen?
	      vert[i] = NULL; continue;
	    }
	    
	    it_bface = neigh_bfaces.begin();

	    // I'm nervous about *++it_bface evaluating to
	    // *(++it_bface).  Also, does C++ guarantee the order in
	    // which a series of variables are initialized in a single
	    // statement?  Not sure.  So I'm splitting what used to be
	    // one statement into several here. 
	    BdryEdgeBase *edge_cand1, *edge_cand2;
	    edge_cand1 = dynamic_cast<BdryEdgeBase*>(*it_bface);
	    it_bface++;
	    edge_cand2 = dynamic_cast<BdryEdgeBase*>(*it_bface);
	    assert(edge_cand1 && edge_cand2);
	    assert(edge_cand1 == bdry_edge[i] || edge_cand2 == bdry_edge[i]);

	    bdry_edge[i] = (bdry_edge[i] == edge_cand1 ?
			    edge_cand2 : edge_cand1);
	    assert( bdry_edge[i]->qHasVert(vert[i]) );

	    all_bedges.erase(bdry_edge[i]);

	    if (i == 0) bedge_chain.push_front(bdry_edge[i]);
	    else        bedge_chain.push_back (bdry_edge[i]);

	    bdry_edge[i]->set_curve(curve);
	    
	    vert[i] = (vert[i] == bdry_edge[i]->pVVert(0) ?
		       bdry_edge[i]->pVVert(1) : bdry_edge[i]->pVVert(0));
	    
	    vert_coord[i].set(vert[i]->dX(), vert[i]->dY(), 0.);

	    double this_param = vert_param[i];
	    assert(curve->geom_ptr()->coord_on_curve(vert_coord[i],
						     &vert_param[i]));

	    if(vert[i] == bdry_edge[i]->pVVert(0)) {
	      bdry_edge[i]->set_vert0_param(vert_param[i]);
	      bdry_edge[i]->set_vert1_param(this_param);
	    }
	    else {
	      bdry_edge[i]->set_vert0_param(this_param);
	      bdry_edge[i]->set_vert1_param(vert_param[i]);
	    }
	  } // Done with the case of a vert inside the curve
	} // Done checking both ends of the current chain
      } while(vert[0] || vert[1]);
      // Exit from the loop when the chain covers an entire curve

      assert(!vert[0] && !vert[1]);
      
      BdryEdgeBase *bedge1, *bedge2;
      double min1, min2, max1, max2;
      int param_compare;

      for(int i = 0; i < 2; i++) {
	switch(i) {
	case 0:
	  it_chain = bedge_chain.begin();
	  bedge1   = *it_chain;
	  bedge2   = *(++it_chain);
	  break;
	case 1:
	  it_chain = --bedge_chain.end();
	  bedge1   = *it_chain;
	  bedge2   = *(--it_chain);
	  break;
	default: assert(0);
	}

	min1 = std::min(bedge1->vert0_param(false), bedge1->vert1_param(false));
	max1 = std::max(bedge1->vert0_param(false), bedge1->vert1_param(false));
	min2 = std::min(bedge2->vert0_param(false), bedge2->vert1_param(false));
	max2 = std::max(bedge2->vert0_param(false), bedge2->vert1_param(false));

	if( iFuzzyComp(max1, max2) == 0 ) {
	  assert( iFuzzyComp(min1, max1) == -1 );
	  if( iFuzzyComp(max1, bedge1->vert0_param(false)) == 0 )
	    bedge1->set_vert1_param(curve->geom_ptr()->max_param());
	  else
	    bedge1->set_vert0_param(curve->geom_ptr()->max_param());
	}
	if( iFuzzyComp(min1, min2) == 0 ) {
	  assert( iFuzzyComp(min1, max1) == -1 );
	  if( iFuzzyComp(min1, bedge1->vert0_param(false)) == 0 )
	    bedge1->set_vert1_param(curve->geom_ptr()->min_param());
	  else
	    bedge1->set_vert0_param(curve->geom_ptr()->min_param());
	}
      }

      for(it_chain = bedge_chain.begin(); it_chain != bedge_chain.end();
	  ++it_chain) {
	bedge = *it_chain;
	vert_param[0] = bedge->vert0_param();
	vert_param[1] = bedge->vert1_param();
	param_compare = iFuzzyComp( vert_param[0], vert_param[1] );
	
	for(int i = 0; i < bedge->iNumFaces(); i++) {
	  face = bedge->pFFace(i);

	  if( (face->pVVert(0) == bedge->pVVert(0) && param_compare ==  1) ||
	      (face->pVVert(0) == bedge->pVVert(1) && param_compare == -1) ) {

	    //face is inverted with respect to curve.
	    Cell *cell_left  = face->pCCellLeft(),
	      *cell_right = face->pCCellRight();
	    Vert *beg_vert   = face->pVVert(0),
	      *end_vert   = face->pVVert(1);
	    
	    face->vInterchangeCellsAndVerts();
	    
#ifndef NDEBUG
	    assert(face->qValid());
	    assert(cell_left->qValid());
	    assert(cell_right->qValid());
	    assert(beg_vert->qValid());
	    assert(end_vert->qValid());
#endif
	  }
	  
	  if(param_compare == -1)
	    assert(bedge->is_forward());
	  else if(param_compare == 1)
	    assert(!bedge->is_forward());
	  else
	    assert(0);
	  
	} // Done checking orientation of faces for this bdry edge
      } // Done checking the whole chain for this curve
      
      vMessage(4, "curve = %p, min_param = %lf, max_param = %lf\n",
      	       curve, curve->geom_ptr()->min_param(),
	       curve->geom_ptr()->max_param());
      
      for(std::deque<BdryEdgeBase*>::iterator it_deque = bedge_chain.begin();
	  it_deque != bedge_chain.end(); ++it_deque) {
	BFace* my_bface = *it_deque;
	BdryEdgeBase* my_bedge = dynamic_cast<BdryEdgeBase*>(my_bface);
	vMessage(4, "bdry_edge = %p, curve = %p, vert0_param = %lf, vert1_param = %lf, parent0 = %p, parent1 = %p\n",
		 my_bedge, my_bedge->get_curve(),
		 my_bedge->vert0_param(), my_bedge->vert1_param(),
		 my_bedge->pVVert(0)->get_parent_entity(),
		 my_bedge->pVVert(1)->get_parent_entity());
      }
      vMessage(2, "\n");
      
      bedge_chain.clear();

    } // Done assigning all bdry edges to a curve

    qLengthScaleFromCellSizes = false;
  } // Done matching up the mesh to an existing geometry

  else {
    // Recreate boundary data by inference.

    typedef std::map<Vert*, GRPoint*> VertToPoint;
    typedef VertToPoint::iterator itVTP;
    VertToPoint vert_to_point;

    // Now the internal bdry faces, if any.

    assert(iNumIntBdryFaces() == 0);
//     if (qIntBFaceFace) {
//       for (int iIBF = 0; iIBF < iNIntBFaces; iIBF++) {
// 	// This array has to have live data, or we wouldn't be here.
// 	Face *pF0 = pFFace(a2iIntBFaceFace[iIBF][0]);
// 	Face *pF1 = pFFace(a2iIntBFaceFace[iIBF][1]);

// 	IntBdryEdge *pIBE = pIBEIntBdryEdge(iIBF);

// 	// Need this both for checking and for setting up patches.
// 	Vert *pV0 = pIBE->pVVert(0);
// 	Vert *pV1 = pIBE->pVVert(1);

// 	GRPoint* point0 = static_cast<GRPoint*>(NULL);
// 	GRPoint* point1 = static_cast<GRPoint*>(NULL);

// 	pair<itVTP, bool> ins_pair0
// 	  = vert_to_point.insert( std::make_pair(pV0, point0) );
// 	pair<itVTP, bool> ins_pair1
// 	  = vert_to_point.insert( std::make_pair(pV1, point1) );

// 	if( ins_pair0.second ) {
// 	  point0 = geometry->build_point(pV0->dX(), pV0->dY());
// 	  ins_pair0.first->second = point0;
// 	}
// 	else {
// 	  point0 = ins_pair0.first->second;
// 	  assert(point0);
// 	}

// 	if( ins_pair1.second ) {
// 	  point1 = geometry->build_point(pV1->dX(), pV1->dY());
// 	  ins_pair1.first->second = point1;
// 	}
// 	else {
// 	  point1 = ins_pair1.first->second;
// 	  assert(point1);
// 	}

// 	// Grab both region tags, working from IBF -> face -> cell.
// 	Cell *pCL = pF0->pCCellOpposite(pIBE);
// 	int iLeftReg = pCL->iRegion();
// 	Cell *pCR = pF1->pCCellOpposite(pIBE);
// 	int iRightReg = pCR->iRegion();

// 	//Create new polyline between point0 and point1.
// 	GRCurve* curve = geometry->build_line(point0, point1,
// 					      iLeftReg, iRightReg,
// 					      0, 0);
// 	pIBE->set_curve(curve);
// 	pIBE->set_vert0_param(curve->geom_ptr()->min_param());
// 	pIBE->set_vert1_param(curve->geom_ptr()->max_param());

//       }

//     } // Done with setting up internal bdry faces w/ face links

      // Now turn to regular bdry faces
    for (GR_index_t iBF = 0; iBF < iNumBdryFaces(); iBF++) {
      BFace *pBF = pBFBFace(iBF);
      Face *pF = pBF->pFFace(0);
      Vert *pV0 = pF->pVVert(0), *pV1 = pF->pVVert(1);

      GRPoint* point0 = static_cast<GRPoint*>(NULL);
      GRPoint* point1 = static_cast<GRPoint*>(NULL);

      std::pair<itVTP, bool> ins_pair0
	= vert_to_point.insert( std::make_pair(pV0, point0) );
      std::pair<itVTP, bool> ins_pair1
	= vert_to_point.insert( std::make_pair(pV1, point1) );

      if( ins_pair0.second ) {
	point0 = geometry->build_point(pV0->dX(), pV0->dY());
	ins_pair0.first->second = point0;
      }
      else {
	point0 = ins_pair0.first->second;
	assert(point0);
      }

      if( ins_pair1.second ) {
	point1 = geometry->build_point(pV1->dX(), pV1->dY());
	ins_pair1.first->second = point1;
      }
      else {
	point1 = ins_pair1.first->second;
	assert(point1);
      }

      // Grab the BC from the incoming data; this info will get
      // transfered to the new curve.
      int iBC = pBF->iBdryCond();
      assert(iBC > 0);

      // Find the adjacent region.
      Cell *pC = pF->pCCellOpposite(pBF);
      int iReg = pC->iRegion();

      GRCurve* curve = NULL;

      if (pF->pCCellLeft() == pC)
	// Cell is on the left, bdry on the right.
	curve = geometry->build_line(point0, point1, iReg, 0, 0, iBC);
      else
	// Cell is on the right, bdry on the left.
	curve = geometry->build_line(point0, point1, 0, iReg, iBC, 0);

      BdryEdgeBase* bedge = dynamic_cast<BdryEdgeBase*>(pBF);
      assert(bedge);

      bedge->set_curve(curve);
      bedge->set_vert0_param(curve->geom_ptr()->min_param());
      bedge->set_vert1_param(curve->geom_ptr()->max_param());

    } // Done setting up all BFace stuff, including building patches.

    assert (geometry->num_curves() == iNumBdryFaces() + iNumIntBdryFaces());
    geometry->set_initialized();
    qLengthScaleFromCellSizes = true;
  }

} // Done relating mesh to geometry


