#include <cstdio>

#include "GR_events.h"
#include "GR_Mesh2D.h"

#define checkRead(b, a) do {						\
    int _res_ = (a);							\
    lineNum++;								\
    if (_res_ != b) {							\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("File format error", __func__);			\
    }									\
  } while(0)

#define setCellToFace(cell_) do {					\
    if (cell_ >= 0) {							\
      if (GR_index_t(cell_) < nTris) {					\
	int ind_ = triFaces[cell_]++;					\
	if (ind_ >= 3) {						\
	  vMessage(0, "At input line %d: ", lineNum);			\
	  vFatalError("Tri with four faces", "__func__");	\
	}								\
	triToFace[cell_][ind_] = pF;					\
      }									\
      else {								\
	assert(GR_index_t(cell_) >= nTris && GR_index_t(cell_) < nCells);	\
	GR_index_t q_ = cell_ - nTris;					\
	int ind_ = quadFaces[q_]++;					\
	if (ind_ >= 4) {						\
	  vMessage(0, "At input line %d: ", lineNum);			\
	  vFatalError("Quad with five faces", "__func__");	\
	}								\
	quadToFace[q_][ind_] = pF;					\
      }									\
    }									\
  } while(0)

#define checkRange(val_, min_, max_) do {				\
    if (val_ < min_ || val_ > GR_sindex_t(max_)) {				\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("Index range error", __func__);			\
    }									\
  } while(0)

#define checkPosRange(val_, max_) do {					\
    if (val_ > max_) {							\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("Index range error", __func__);			\
    }									\
  } while(0)

#define checkVertexRange(val_) checkPosRange(val_, nVerts)
#define checkFaceRange(val_) checkPosRange(val_, nFaces)
#define checkCellRange(val_) checkPosRange(val_, int(nCells))
      

void readNative(Mesh2D& M2D, const char strFileName[])
{
  //@@ Read data from a GRUMMP native file and set up the data in the
  //Mesh2D data structure. 
  FILE *pFInFile = fopen(strFileName, "r");
  if (NULL == pFInFile) {
    vFatalError("Couldn't open input file for reading",
		"__func__");
  }

  GR_index_t nVerts, nFaces, nCells, nBFaces;
  GR_index_t lineNum = 1;

  checkRead(4, (fscanf(pFInFile, "%u %u %u %u\n",
		       &nCells, &nFaces, &nBFaces, &nVerts)));

  if (nVerts == 0 || nCells == 0 || nFaces == 0 || nBFaces == 0)
    vFatalError("Number of entities is specified to be 0!",
		"__func__");

  if (2*nFaces < nBFaces + 3*nCells ||
      4*nCells + nBFaces < 2*nFaces)
    vFatalError("Impossible combination of entity counts!",
		"__func__");
  
  GR_index_t nQuads = 2*nFaces - nBFaces - 3*nCells;
  GR_index_t nTris = nCells - nQuads;

  for (GR_index_t v = 0; v < nVerts; v++) {
    double dXX, dYY;
    checkRead(2, fscanf(pFInFile, "%lf%lf\n", &dXX, &dYY));
    (void) M2D.createVert(dXX, dYY);
  }

  // Set up some temporary storage for tri and quad data
  Face* (*triToFace)[3] = NULL, *(*quadToFace)[4] = NULL;
  int *triFaces = NULL, *quadFaces = NULL;

  if (nTris > 0) {
    triToFace = new Face*[nTris][3];
    triFaces = new int[nTris];
  }
  if (nQuads > 0) {
    quadToFace = new Face*[nQuads][4];
    quadFaces = new int[nQuads];
  }

  for (GR_index_t t = 0; t < nTris; t++) {
    triFaces[t] = 0;
    triToFace[t][0] = triToFace[t][1] = triToFace[t][2] = pFInvalidFace;
  }

  for (GR_index_t q = 0; q < nQuads; q++) {
    quadFaces[q] = 0;
    quadToFace[q][0] = quadToFace[q][1] = quadToFace[q][2] =
      quadToFace[q][3] = pFInvalidFace;
  }

  // Read face-vert and face-cell connectivity; store cell-face
  // connectivity for later.
  for (GR_index_t f = 0; f < nFaces; f++) {
    GR_sindex_t cellA, cellB;
    GR_index_t vertA, vertB;
    checkRead(4, fscanf(pFInFile, "%d%d %u%u\n",
			&cellA, &cellB, &vertA, &vertB));
    checkVertexRange(vertA);
    checkVertexRange(vertB);
    checkCellRange(cellA);
    checkCellRange(cellB);

    bool qExist;
    Face *pF = M2D.createFace(qExist, M2D.pVVert(vertA), M2D.pVVert(vertB));
    assert(!qExist);
    
    // These next two are macros
    setCellToFace(cellA);
    setCellToFace(cellB);
  }

  // We'll create cells in a moment; right now, we don't have region
  // data yet.

  // First, read bdry face data.  Don't create bdry faces until after
  // cells already exist, though...

  int *bfaceToFace = new int[nBFaces];
  int *bdryConds = new int[nBFaces];
  for (GR_index_t bf = 0; bf < nBFaces; bf++) {
    /*bdryfaces: face bc verts*/
    GR_index_t face, vertA, vertB;
    int iBC;
    // Read and check data
    checkRead(4, fscanf(pFInFile, "%u %d %u%u\n",
			&face, &iBC, &vertA, &vertB));
    checkVertexRange(vertA);
    checkVertexRange(vertB);
    checkFaceRange(face);

    bfaceToFace[bf] = face;
    bdryConds[bf] = iBC;
  }

  // Now read region data and create cells
  for (GR_index_t c = 0; c < nCells; c++) {
    int iReg;
    /*cells: region*/
    checkRead(1, fscanf(pFInFile, "%d\n", &iReg));
    if (c < nTris) {
      if (triFaces[c] != 3)
	vFatalError("Triangle doesn't have three faces",
		    "__func__");
      (void) M2D.createTriCell(triToFace[c][0], triToFace[c][1],
				 triToFace[c][2], iReg);
    }
    else {
      GR_index_t q = c - nTris;
      if (quadFaces[q] != 4)
	vFatalError("Quadrilateral doesn't have four faces",
		    "__func__");
      (void) M2D.createQuadCell(quadToFace[q][0], quadToFace[q][1],
				  quadToFace[q][2], quadToFace[q][3], iReg);
    }
  }

  for (GR_index_t bf = 0; bf < nBFaces; bf++) {
    (void) M2D.createBFace(M2D.pFFace(bfaceToFace[bf]),
			   bdryConds[bf]);
  }

  assert(M2D.iNumVerts() == nVerts);
  assert(M2D.iNumFaces() == nFaces);
  assert(M2D.iNumCells() == nCells);
  assert(M2D.iNumBdryFaces() == nBFaces);
  delete [] bfaceToFace;
  delete [] bdryConds;
  if (nTris > 0) {
    assert(triFaces && triToFace);
    delete [] triFaces;
    delete [] triToFace;
  }
  if (nQuads > 0) {
    assert(quadFaces && quadToFace);
    delete [] quadFaces;
    delete [] quadToFace;
  }
  
  if (!M2D.qValid ())
    vFatalError ("Mesh was invalid.", "2D native mesh read");
}
