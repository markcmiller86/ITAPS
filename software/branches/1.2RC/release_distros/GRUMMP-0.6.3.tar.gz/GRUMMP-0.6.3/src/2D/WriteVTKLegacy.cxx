#include <stdio.h>
#include "GR_events.h"
#include "GR_Mesh2D.h"


//-----------------------------------------------------------------------------
void writeVTKLegacy
(
  Mesh2D& OutMesh,
  const char strBaseFileName[],
  const char strFileNameExt[]
)
//-----------------------------------------------------------------------------
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  
  FILE *pFOutFile = NULL;
  char strFileName[1024];
  OutMesh.vPurge();
  sprintf(strFileName, "%s.vtk%s", strBaseFileName, strFileNameExt);
  
  /*newfile mesh*/
  vMessage(2, "Opening output file %s\n\n", strFileName);

  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open Vtk output file for writing",
                "2d mesh output");

  int nno = OutMesh.iNumVerts();   // number of nodes
//int nel = OutMesh.iNumCells();
  int ntri = OutMesh.iNumTriCells();// number of Tri cells
  int nquad = OutMesh.iNumQuadCells(); // numbers of quad cells
  int nel = ntri + nquad;

  //-------------------------------------------------------
  // Write the VTK header details
  //-------------------------------------------------------

  fprintf(pFOutFile, "# vtk DataFile Version 2");
  fprintf(pFOutFile, "\nOVMesh Tri example");
  fprintf(pFOutFile, "\nASCII\n");
  fprintf(pFOutFile, "\nDATASET UNSTRUCTURED_GRID");
  fprintf(pFOutFile, "\nPOINTS %d float", nno);

  //-------------------------------------
  // write 2d vertex data
  //-------------------------------------
  Vert* pV = NULL;
  for (int iV = 0; iV < nno; ++iV)
  {
    /*verts: coords*/
    pV = OutMesh.pVVert(iV);
    fprintf(pFOutFile, "\n%16.8f %16.8f %16.8f", pV->dX(), pV->dY(),
	    pV->dZ());
  }


  //-------------------------------------
  // write cell data as:
  //
  //    CELLS  n  size
  //    3          v1  v2  v3
  //    3          v1  v2  v3
  //    3          v1  v2  v3
  //
  // (#verts)     (vertex list)
  //   
  //-------------------------------------
  
  //                      n size         no. ints to build connectivity
  fprintf(pFOutFile, "\n\nCELLS %d %d", nel, (nel+ntri*3+nquad*4));

  int h,globalNodeNum;
  Cell* pC = NULL;
  for (int e=0; e<nel; ++e)
  {
    pC = OutMesh.pCCell(e);
    h  = pC->iNumVerts();
    fprintf(pFOutFile, "\n%d  ", h);
    for (int idx=0; idx<h; ++idx)
    {
      globalNodeNum = OutMesh.iVertIndex(pC->pVVert(idx));
      fprintf(pFOutFile, " %10d", globalNodeNum);
    }
  }
  fprintf(pFOutFile, "\n");


  //-------------------------------------
  // write cell type (VTK_TRIANGLE == 5, VTK_QUAD == 9)
  //-------------------------------------
  fprintf(pFOutFile, "\nCELL_TYPES %d\n", nel);
  for (int iC = 0; iC < nel; ++iC) 
  {
    int iNV = OutMesh.pCCell(iC)->iNumVerts();
    fprintf(pFOutFile, "%d\n", iNV == 3 ? 5 : 9);
  }
  fprintf(pFOutFile, "\n");

  fclose(pFOutFile); 
  SUMAA_LOG_EVENT_END(OUTPUT);

  vMessage(2, "-----------------------------------------------------------------------------\n");
  vMessage(2, "Finished writing VTK dataFfile, %s\n", strFileName);
  vMessage(2, "The mesh has %5u vertices\n", OutMesh.iNumVerts());
  vMessage(2, "             %5u faces\n", OutMesh.iNumFaces());
  vMessage(2, "             %5u bdry faces\n", OutMesh.iNumBdryFaces());
  vMessage(2, "        and: %5u cells\n", OutMesh.iNumCells());
  vMessage(2, "   of which: %5u are triangles\n", OutMesh.iNumTriCells());
  vMessage(2, "             %5u are quads\n", OutMesh.iNumQuadCells());
}
