#include "GR_BFace2D.h"
#include "GR_events.h"
#include "GR_Geometry.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Vertex.h"
#include "GR_GRCurve.h"
#include "CubitVector.hpp"
#include "CubitBox.hpp"
#include "GeometryEntity.hpp"
#include <algorithm>

BdryEdgeBase::
BdryEdgeBase( const bool qIsInternal, 
	      Face* const pFLeft, 
	      Face* const pFRight, 
	      GRCurve* const parent_curve, 
	      double param_vert0,
	      double param_vert1 ) 
  : BFace(qIsInternal, pFLeft, pFRight),
    iBdryCond_(-1),
    m_curve(parent_curve), 
    m_vert0_param(param_vert0),
    m_vert1_param(param_vert1),
    pBPBdryPatch(NULL) { 

  vForbidOffsetInsertion(); 

}

BdryEdgeBase& BdryEdgeBase::
operator=(const BdryEdgeBase& BEB) {
  
  if(this != &BEB) {

    this->BFace::operator=(BEB);
    iBdryCond_ = BEB.iBdryCond_;
    m_curve = BEB.m_curve;
    m_vert0_param = BEB.m_vert0_param;
    m_vert1_param = BEB.m_vert1_param;
 
    pBPBdryPatch = BEB.pBPBdryPatch;

  }

  return *this;

}

void BdryEdgeBase::
set_curve(GRCurve* const curve) {
  m_curve = curve;
  iBdryCond_ = -1;
}
  
GRCurve* BdryEdgeBase::
get_curve() const { assert(m_curve); return m_curve; }

void BdryEdgeBase::
set_vert0_param(double param) { 
 
  assert(m_curve);

  assert( iFuzzyComp(param, m_curve->geom_ptr()->min_param()) != -1 &&
	  iFuzzyComp(param, m_curve->geom_ptr()->max_param()) !=  1 );

  m_vert0_param = param; 

}

void BdryEdgeBase::
set_vert1_param(double param) { 

  assert(m_curve);

  assert( iFuzzyComp(param, m_curve->geom_ptr()->min_param()) != -1 &&
	  iFuzzyComp(param, m_curve->geom_ptr()->max_param()) !=  1 );

  m_vert1_param = param; 

}
 
double BdryEdgeBase::
vert0_param(bool run_debug_code) const {
 
#ifndef NDEBUG
  
  assert(m_curve);

  if(run_debug_code) {

    assert( iFuzzyComp(m_vert0_param, m_curve->geom_ptr()->min_param()) != -1 &&
	    iFuzzyComp(m_vert0_param, m_curve->geom_ptr()->max_param()) !=  1 );
    assert( iFuzzyComp(m_vert1_param, m_curve->geom_ptr()->min_param()) != -1 &&
	    iFuzzyComp(m_vert1_param, m_curve->geom_ptr()->max_param()) !=  1 );

    int compare = iFuzzyComp(m_vert0_param, m_vert1_param);

    if(is_forward()) assert( compare == -1 );
    else             assert( compare ==  1 );

  }
#else
  //prevents compiler from complaining
  assert(run_debug_code == false || run_debug_code == true);
#endif

  return m_vert0_param;

}

double BdryEdgeBase::
vert1_param(bool run_debug_code) const {

#ifndef NDEBUG
  
  assert(m_curve);

  if(run_debug_code) {

    assert( iFuzzyComp(m_vert0_param, m_curve->geom_ptr()->min_param()) != -1 &&
	    iFuzzyComp(m_vert0_param, m_curve->geom_ptr()->max_param()) !=  1 );
    assert( iFuzzyComp(m_vert1_param, m_curve->geom_ptr()->min_param()) != -1 &&
	    iFuzzyComp(m_vert1_param, m_curve->geom_ptr()->max_param()) !=  1 );

    int compare = iFuzzyComp(m_vert0_param, m_vert1_param);
    
    if(is_forward()) assert( compare == -1 );
    else             assert( compare ==  1 );

  }
#else
  //prevents compiler from complaining
  assert(run_debug_code == false || run_debug_code == true);
#endif

  return m_vert1_param;

}

int BdryEdgeBase::
bdry_cond(const bool left) const {

  assert(qValid());

  if(left) return bdry_left();
  else     return bdry_right();

}

int BdryEdgeBase::
bdry_left() const {

  if(iNumFaces() == 2) {
    assert(dynamic_cast<IntBdryEdge*>(const_cast<BdryEdgeBase*>(this)));
    return iInvalidBC;
  }

  assert(iNumFaces() == 1);

  if(is_forward())
    return m_curve->boundary_left();
  else
    return m_curve->boundary_right();

}

int BdryEdgeBase::
bdry_right() const {

  if(iNumFaces() == 2) {
    assert(dynamic_cast<IntBdryEdge*>(const_cast<BdryEdgeBase*>(this)));
    return iInvalidBC;
  }

  assert(iNumFaces() == 1);

  if(is_forward())
    return m_curve->boundary_right();
  else
    return m_curve->boundary_left();

}

double BdryEdgeBase::
length() const { 
    
  const Vert *vert0 = pVVert(0), *vert1 = pVVert(1);

  double vector[] = { vert1->dX() - vert0->dX(),
		      vert1->dY() - vert0->dY() };

  return dMAG2D(vector);
  
}

CubitVector BdryEdgeBase::
mid_point() const {

  const Vert *vert0 = pVVert(0), 
             *vert1 = pVVert(1);

  return CubitVector( 0.5 * (vert0->dX() + vert1->dX()), 
		      0.5 * (vert0->dY() + vert1->dY()), 
		      0. );

}

double BdryEdgeBase::
get_split_data(const SplitType split_type,
	       CubitVector& split_coord,
	       bool& concentric_shell_split) const {
  
  const Vert *vert0 = pVVert(0), *vert1 = pVVert(1);

  bool vert0_small = vert0->small_angle_vert(),
       vert1_small = vert1->small_angle_vert(),
       vert0_shell = vert0->shell_vert(),
       vert1_shell = vert1->shell_vert();

  bool forward = is_forward();

  if( vert0_small && vert1_shell ) {
    
    concentric_shell_split = true;
    
    if(forward)
      return m_curve->geom_ptr()->coord_at_dist(0.5 * length(), true, split_coord);
    else 
      return m_curve->geom_ptr()->coord_at_dist(0.5 * length(), false, split_coord);

  }
  
  if( vert1_small && vert0_shell ) {
    
    concentric_shell_split = true;

    if(forward)
      return m_curve->geom_ptr()->coord_at_dist(0.5 * length(), false, split_coord);
    else
      return m_curve->geom_ptr()->coord_at_dist(0.5 * length(), true, split_coord);

  }
  
  if( vert0_shell && vert1_shell) {

    double param_vert0 = forward ? vert0_param() : vert1_param();
    double param_vert1 = forward ? vert1_param() : vert0_param();

    concentric_shell_split = true;
    return m_curve->geom_ptr()->coord_at_mid_dist(param_vert0, param_vert1, split_coord);

  }

  concentric_shell_split = false;

  double split_param;
  double lo_param = forward ? vert0_param() : vert1_param();
  double hi_param = forward ? vert1_param() : vert0_param();

  switch(split_type) {

  case MID_TVT:
    split_param = m_curve->geom_ptr()->mid_TVT(lo_param, hi_param);
    break;
    
  case MID_PARAM:
    split_param = 0.5 * (lo_param + hi_param);
    break;

  default:
    vFatalError("Unknown split type specified",
		"BdryEdgeBase::get_split_data()");

  }

  m_curve->geom_ptr()->coord_at_param(split_param, split_coord);

  return split_param;

}

CubitBox BdryEdgeBase::
bounding_box() const {

  CubitVector mini, maxi;
    
  const Vert* vert0 = pVVert(0);
  const Vert* vert1 = pVVert(1);

  mini.set( std::min(vert0->dX(), vert1->dX()),
	    std::min(vert0->dY(), vert1->dY()), 0.);
  maxi.set( std::max(vert0->dX(), vert1->dX()),
	    std::max(vert0->dY(), vert1->dY()), 0.);

  return CubitBox(mini, maxi);

}

void BdryEdgeBase::
vCentroid(double centroid[]) const {

  assert(qValid());
  const Vert *vert0 = pVVert(0), *vert1 = pVVert(1);
  
  centroid[0] = 0.5 * (vert0->dX() + vert1->dX());
  centroid[1] = 0.5 * (vert0->dY() + vert1->dY());
  
}
 
void BdryEdgeBase::
vCircumcenter(double circcenter[]) const {

  vCentroid(circcenter);

}

void BdryEdgeBase::
set_geometry(GeometryEntity* const geom_ent) { 

  m_curve = dynamic_cast<GRCurve*>(geom_ent); 
  assert(m_curve); 

}

GeometryEntity* BdryEdgeBase::
get_geometry() {
  
  return get_curve(); 

}

eEncroachResult BdryEdgeBase::
eIsEncroached(const eEncroachType enc_type) const {
  
  // Works for both regular and internal bdry edges.
  for (int iF = 0; iF < iNumFaces(); iF++) {
    const Face *pF = pFFace(iF);
    Cell *pC = pF->pCCellOpposite(this);
    // This cell could be a quad and we can still tell whether the bdry
    // edge is encroached on.
    for (int iV = 0; iV < pC->iNumVerts(); iV++) {
      Vert *pV = pC->pVVert(iV);
      if (!qHasVert(pV)) {
	enum eEncroachResult eER = eIsPointEncroaching(pV->adCoords(), enc_type, false);
        if (eER != eClean) return eER;
      }
    }
  }
  return eClean;

}

eEncroachResult BdryEdgeBase::
eIsPointEncroachingBall(const double coord[],
			const bool tie_break) const {
  
  const Vert *v1 = pVVert(0), *v2 = pVVert(1);
  double c1[] = {v1->dX(), v1->dY()};
  double c2[] = {v2->dX(), v2->dY()};

  double center[] = {0.5 * (c1[0] + c2[0]),
		     0.5 * (c1[1] + c2[1])};
  double radius = 0.5 * hypot(c2[0] - c1[0], c2[1] - c1[1]);
  double dist = hypot(coord[0] - center[0], coord[1] - center[1]);

  switch(iFuzzyComp(dist, radius)) {
  case -1:
    return eSplit;
  case 1:
    return eClean;
  case 0:
    if(tie_break) return eSplit;
    else          return eClean;
  default:
    assert(0);
    return eClean;
  }
		
}

eEncroachResult BdryEdgeBase::
eIsPointEncroachingLens(const double coord[],
			const bool tie_break) const {
  return encroaching_lens(coord, tie_break, eLens);
}

eEncroachResult BdryEdgeBase::
eIsPointEncroachingNewLens(const double coord[],
			   const bool tie_break) const {
  return encroaching_lens(coord, tie_break, eNewLens);
}

eEncroachResult BdryEdgeBase::
encroaching_lens(const double coord[], 
		 const bool tie_break,
		 const enum eEncroachType enc_type) const {

  const Vert *v1 = pVVert(0), *v2 = pVVert(1);
  assert( v1->iSpaceDimen() == 2 && v2->iSpaceDimen() == 2 );  
  assert( enc_type == eLens || enc_type == eNewLens );

  double mid[]   = { 0.5 * (v1->dX() + v2->dX()), 0.5 * (v1->dY() + v2->dY()) };
  double norm[]  = { v1->dY() - v2->dY(), v2->dX() - v1->dX() };
  double mag     = dMAG2D(norm);
  double rad     = mag / sqrt(3.);
  norm[0] /= mag; norm[1] /= mag;

  double cent1[] = { mid[0] + 0.5 * rad * norm[0], mid[1] + 0.5 * rad * norm[1] };
  double cent2[] = { mid[0] - 0.5 * rad * norm[0], mid[1] - 0.5 * rad * norm[1] };

  int in1 = iFuzzyComp(dDIST2D(coord, cent1), rad); 
  int in2 = iFuzzyComp(dDIST2D(coord, cent2), rad);
  
  
  
  //Both negative, definitely encroaching
  if(in1 == -1 && in2 == -1) return eSplit;
  // If one is negative and one zero, then use the tiebreaker
  else if( (in1 == -1 && in2 ==  0) ||
	   (in1 ==  0 && in2 == -1)) return tie_break ? eSplit : eClean;
  else return eClean;

}  

bool BdryEdgeBase::
qValid() const {
  
  if(!this) {
    vMessage(0, "ERROR: The BdryEdgeBase object is defined but not initialized.\n");
    return false;
  }
 
  if(qDeleted()) {
    vMessage(0, "ERROR: The BdryEdgeBase object is marked as deleted.\n");
    return false;
  }

  if(!pFFace(0)->qValid()) {
    vMessage(0, "ERROR: The first Face of this BdryEdgeBase is invalid\n");
    return false;
  }  

  if(iNumFaces() == 2) {
    if(!is_forward()) {
      vMessage(0, "ERROR: Faces not correctly oriented\n"); 
    }
    if(!pFFace(1)->qValid()) {
      vMessage(0, "ERROR: The second Face of this BdryEdgeBase is invalid\n");
      return false;
    }
  }
  
  if(pVVert(0)->iSpaceDimen() != 2 ||
     pVVert(1)->iSpaceDimen() != 2) {
    vMessage(0, "ERROR: One of the vertices is three dimensional\n");
    return false;
  }

  return true;

}



// CubitVector BdryEdgeBase::
// get_offset_loc(const CubitVector&) const {

//   assert(0);

//   CubitVector v;

//   switch(pVVert(0)->iSpaceDimen()) {

//   case 2: {
//     Vert dummy_vert;
//     double dummy_coord[] = { trigger.x(), trigger.y() };
//     dummy_vert.vSetCoords(2, dummy_coord );
    
//     int left = iOrient2D(pVVert(0), pVVert(1), &dummy_vert);
//     if(left == 1) 
//       v = get_offset_loc(true);
//     else if(left == -1)
//       v = get_offset_loc(false);
//     else
//       v = get_split_loc();
//     break;
//   }

//   case 3: { //not implemented yet
//     vFatalError("This function is not implemented in 3D", 
// 		"BdryEdge::get_offset_loc(const double*)");
//     v.set(-LARGE_DBL, -LARGE_DBL, -LARGE_DBL);
//     break;  
//   }  
//   default: {
//     assert(0);
//     v.set(-LARGE_DBL, -LARGE_DBL, -LARGE_DBL);
//     break;
//   }

//   }

//   return v;

// }

// CubitVector BdryEdgeBase::
// get_offset_loc(const bool) const {

//   assert(0);

//   CubitVector offset_loc;

//   switch(pVVert(0)->iSpaceDimen()) {

//   case 2: {
//     GRCurve* c = dynamic_cast<GRCurve*>(curve);

//     int reg_left, reg_right;
//     if(sense == CUBIT_FORWARD) {
//       reg_left  = c->region_left();
//       reg_right = c->region_right();
//     }
//     else {
//       assert(sense == CUBIT_REVERSED);
//       reg_right = c->region_left();
//       reg_left  = c->region_right();
//     }
    
//     if(left && reg_left == 0) 
//       vFatalError("There is no region on the left side of this curve",
//  		  "BdryEdge::get_offset_loc(const bool)");
//     if(!left && reg_right == 0) 
//       vFatalError("There is no region on the right side of this curve",
//  		  "BdryEdge::get_offset_loc(const bool)");

//     if(left) assert(bdry_cond(false) != 0);
//     else     assert(bdry_cond(true)  != 0);

//     const Vert *v1 = pVVert(0), *v2 = pVVert(1);
//     double mid[]   = { 0.5 * (v1->dX() + v2->dX()), 0.5 * (v1->dY() + v2->dY()) };
//     double norm[]  = { v1->dY() - v2->dY(), v2->dX() - v1->dX() };
//     double mag     = dMAG2D(norm);
//     double rad     = mag / sqrt(3.);
//     norm[0] /= mag; norm[1] /= mag;

//     if(left) offset_loc.set( mid[0] + 0.50010001 * rad * norm[0], 
// 			     mid[1] + 0.50010001 * rad * norm[1],
// 			     0. );
//     else     offset_loc.set( mid[0] - 0.50010001 * rad * norm[0], 
// 			     mid[1] - 0.50010001 * rad * norm[1],
// 			     0 );
//     break;
//   }


//   return offset_loc;
  
// }
