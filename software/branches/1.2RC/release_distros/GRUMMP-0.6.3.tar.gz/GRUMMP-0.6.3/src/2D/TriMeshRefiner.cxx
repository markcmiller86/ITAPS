#include "GR_TriMeshRefiner.h"
#include "GR_events.h"
#include "GR_BFace2D.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Geometry.h"
#include "GR_InsertionQueue.h"
#include "GR_InsertionQueueEntry.h"
#include "GR_Length2D.h"
#include "GR_Mesh2D.h"
#include "GR_Vertex.h"
#include "GR_GRCurve.h"
#include "CubitVector.hpp"
#include "GeometryEntity.hpp"
#include <deque>
#include <vector>
#include <utility>
#include <iostream>

using std::vector;

TriMeshRefiner::
TriMeshRefiner(Mesh2D* const mesh, 
	       bool check_for_encroachment) :
  m_mesh(mesh), 
  m_sizing_field(NULL), 
  m_edge_split_queue(), 
  m_IQ(NULL) {

  init_tri_mesh_refiner(check_for_encroachment);
  m_IQ = new InsertionQueue(m_mesh, InsertionQueueEntry::dInvalidPriority, true);

}

TriMeshRefiner::
TriMeshRefiner(Mesh2D* const mesh,
	       Length2D* const sizing_field,
	       bool check_for_encroachment) : 
  m_mesh(mesh), 
  m_sizing_field(sizing_field), 
  m_edge_split_queue(), 
  m_IQ(NULL) {

  init_tri_mesh_refiner(check_for_encroachment);  
  m_IQ = new InsertionQueue(m_mesh, InsertionQueueEntry::dInvalidPriority, true);

}

void TriMeshRefiner::
init_tri_mesh_refiner(bool check_for_encroachment) {

  assert(m_mesh->qValid());

  if(check_for_encroachment) fix_boundary_encroachment();

#ifndef NDEBUG

  else {
    assert(m_edge_split_queue.empty());
    queue_encroached_bdry_edges();
    assert(m_edge_split_queue.empty());
  }

#endif

}

TriMeshRefiner::  
~TriMeshRefiner() {
 
  if(m_IQ) { 
    delete m_IQ; 
    m_IQ = NULL; 
  } 

}

void TriMeshRefiner::
fix_boundary_encroachment() {

  BdryEdgeBase* bedge;
  queue_encroached_bdry_edges();

  while(!m_edge_split_queue.empty()) {
    bedge = m_edge_split_queue.front();
    if(bedge->qDeleted())           m_edge_split_queue.pop_front();
    else if(split_bdry_edge(bedge)) m_edge_split_queue.pop_front();
  }

}

void TriMeshRefiner::
refine_boundary_for_length() {

  if(!m_sizing_field) return;

  BdryEdgeBase* bdry_edge = NULL;

  //for(int i = m_mesh->iNumBdryFaces() - 1; i >= 0; i--) {
  GR_index_t i;
  for(i = 0; i < m_mesh->iNumBdryFaces(); i++) {
    bdry_edge = dynamic_cast<BdryEdgeBase*>(m_mesh->pBFBFace(i));
    assert(bdry_edge);
    m_edge_split_queue.push_back(bdry_edge);
  }
  for(i = 0; i < m_mesh->iNumIntBdryFaces(); i++) {
    bdry_edge = dynamic_cast<BdryEdgeBase*>(m_mesh->pIBEIntBdryEdge(i));
    assert(bdry_edge);      
    m_edge_split_queue.push_back(bdry_edge);
  }

  if(m_edge_split_queue.empty()) return;

  std::cout << "Refining boundary for length" << std::endl;

  std::pair<BdryEdgeBase*, BdryEdgeBase*> new_bedges;

  while(!m_edge_split_queue.empty()) {

    bdry_edge = m_edge_split_queue.front();
    if(bdry_edge->qDeleted()) { m_edge_split_queue.pop_front(); continue; }

    //half the circumradius > average length scale,
    //or if the boundary edge is encroached.
    if( bdry_edge->length() > bdry_edge->pVVert(0)->dLS() + bdry_edge->pVVert(1)->dLS() ||
	bdry_edge->eIsEncroached(m_mesh->eEncroachmentType()) != eClean ) {
      
      bool inserted = split_bdry_edge(bdry_edge, &new_bedges);

      if(inserted) {
	m_edge_split_queue.pop_front();
	m_edge_split_queue.push_back(new_bedges.first);
	m_edge_split_queue.push_back(new_bedges.second);
      }
      else {
	assert(!new_bedges.first);
	assert(!new_bedges.second);	
      }

    }

    else m_edge_split_queue.pop_front();

  }
  
#ifndef NDEBUG
  //There should not be any encroached edges here.
  queue_encroached_bdry_edges();
  assert(m_edge_split_queue.empty());
#endif

}

void TriMeshRefiner::
refine_mesh() {

  refine_boundary_for_length();
  
  printf("Refining for quality\n");
  SUMAA_LOG_EVENT_BEGIN(SHEWCHUK);
  
  static int counter = 0;
  BdryEdgeBase* bedge;
  m_IQ->vCleanQueue();

  while(!m_IQ->qIsQueueEmpty()//  && m_mesh->iNumVerts() < 100
	) {

    if(!m_edge_split_queue.empty()) {
      bedge = m_edge_split_queue.front();
      if(bedge->qDeleted()) { m_edge_split_queue.pop_front(); }
      else if(split_bdry_edge(bedge)) { m_edge_split_queue.pop_front(); }
    }
    else {
      InsertionQueueEntry IQE = m_IQ->IQETopValidEntry();
      assert(IQE.eType() == InsertionQueueEntry::eTriCell);
      split_triangle( dynamic_cast<TriCell*>(IQE.pCCell()) );
    }

    m_IQ->vCleanQueue();

    if(++counter > 100000 && m_edge_split_queue.empty()) {
      m_mesh->vPurge();
      delete m_IQ;
      m_IQ = new InsertionQueue(m_mesh, InsertionQueueEntry::dInvalidPriority, true);
      counter = 0;
    }

  }

  //  assert(m_IQ->qIsQueueEmpty());

  SUMAA_LOG_EVENT_END(SHEWCHUK);

  m_mesh->vPurge();
  output_triangulation_to_file("Refined.mesh");

}

void TriMeshRefiner::
split_triangle(TriCell* const cell_to_split) {

  assert(cell_to_split);

  //Find circumcenter.
  CubitVector insert_location = cell_to_split->circumcenter();
    
  //Compute watson hull.
  Mesh2D::WatsonData watson_data;
  m_mesh->compute_watson_data(insert_location, cell_to_split, watson_data);
    
  //If point is encroaching, queue ONE encroached edge and return.
  if(!watson_data.encroached_bdry_edges.empty()) {
    m_edge_split_queue.push_back( *(watson_data.encroached_bdry_edges.begin()) );
    return;
  }

  //Else, insert the point in m_mesh.
  Vert* new_vert =   m_mesh->createVert(insert_location.x(),
					insert_location.y());
  new_vert->vSetType(Vert::eInterior);
  new_vert->set_parent_entity(static_cast<GeometryEntity*>(NULL));

  vector<Cell*> new_cells;

  m_mesh->insert_watson_interior(new_vert, watson_data, &new_cells);
  
  if(m_sizing_field)
    m_sizing_field->set_length_scale(new_vert);

  //Update the priority queue.
  std::for_each( new_cells.begin(), new_cells.end(),
		 std::bind1st( std::mem_fun(&TriMeshRefiner::add_to_priority_queue), this ) );

}

bool TriMeshRefiner::
split_bdry_edge(BdryEdgeBase* const bedge_to_split,
		std::pair<BdryEdgeBase*, BdryEdgeBase*>* new_bedges) {

  assert(bedge_to_split);
  assert(!bedge_to_split->qDeleted());

  vector<Cell*> new_cells;
  m_mesh->delete_verts_in_edge_ball(bedge_to_split, &new_cells);  

  //Find the split location and the corresponding parameter.
  CubitVector split_location;
  bool concentric_shell_split;
  double split_param = bedge_to_split->get_split_data(BdryEdgeBase::MID_TVT, 
						      split_location, concentric_shell_split);
  
  Vert* new_vert = m_mesh->createVert(split_location.x(),
				      split_location.y());
  new_vert->vSetType(Vert::eBdryCurve);
  new_vert->set_parent_entity(bedge_to_split->get_curve());
  if(concentric_shell_split) new_vert->set_shell_vert(true);

  //Compute Watson hull.
  Mesh2D::WatsonData watson_data;
  m_mesh->compute_watson_data(new_vert, bedge_to_split, watson_data, true, false);

  { //Because of curve boundaries, we might try to insert on the wrong side of a constraining edge.
    //Try to avoid that by re-ordering edge splits.

    Vert mid_vert;
    double mid_coords[] = { 0.5 * (bedge_to_split->pVVert(0)->dX() + bedge_to_split->pVVert(1)->dX()),
			    0.5 * (bedge_to_split->pVVert(0)->dY() + bedge_to_split->pVVert(1)->dY()) };
    mid_vert.vSetCoords(2, mid_coords);
    
    BdryEdgeBase* enc_bedge;
    std::set<BdryEdgeBase*>::const_iterator 
      itbe     = watson_data.encroached_bdry_edges.begin(),
      itbe_end = watson_data.encroached_bdry_edges.end();
    
    for( ; itbe != itbe_end; ++itbe) {
      enc_bedge = *itbe;
      assert(iOrient2D(enc_bedge->pVVert(0), enc_bedge->pVVert(1), &mid_vert) != 0);
      if( iOrient2D(enc_bedge->pVVert(0), enc_bedge->pVVert(1), &mid_vert) !=
	  iOrient2D(enc_bedge->pVVert(0), enc_bedge->pVVert(1), new_vert) ) {
	m_edge_split_queue.push_front(enc_bedge);
	if(new_bedges)
	  new_bedges->first = new_bedges->second = static_cast<BdryEdgeBase*>(NULL);
	return false;
      }
    }

  }

  //Perform the split
  Mesh2D::BEdgePair new_bdry_edges = m_mesh->insert_watson_boundary(new_vert, bedge_to_split, 
								    watson_data, split_param, &new_cells);

  //The new boundary edges are possibly encroached.
  if(new_bdry_edges.first->eIsEncroached(m_mesh->eEncroachmentType()) != eClean)
    m_edge_split_queue.push_back(new_bdry_edges.first);
  if(new_bdry_edges.second->eIsEncroached(m_mesh->eEncroachmentType()) != eClean)
    m_edge_split_queue.push_back(new_bdry_edges.second);

  //Queue boundary edges getting encroached by this insertion.
  std::copy(watson_data.encroached_bdry_edges.begin(),
	    watson_data.encroached_bdry_edges.end(),
	    std::back_inserter(m_edge_split_queue));

  if(new_bedges) { 
    new_bedges->first  = new_bdry_edges.first;
    new_bedges->second = new_bdry_edges.second; 
  }
  if(m_sizing_field)
    m_sizing_field->set_length_scale(new_vert);

  //Update the priority queue.
  std::for_each( new_cells.begin(), new_cells.end(),
		 std::bind1st( std::mem_fun(&TriMeshRefiner::add_to_priority_queue), this ) );

  return true;

}

void TriMeshRefiner::
queue_encroached_bdry_edges() {

  BdryEdgeBase* bdry_edge;

  GR_index_t i;
  for(i = 0; i < m_mesh->iNumBdryFaces(); i++) {
    if(m_mesh->pBFBFace(i)->qDeleted()) continue;
    bdry_edge = dynamic_cast<BdryEdgeBase*>(m_mesh->pBFBFace(i));
    assert(bdry_edge);      
    if( bdry_edge->eIsEncroached(m_mesh->eEncroachmentType()) != eClean )
      m_edge_split_queue.push_back(bdry_edge);
  }

  for(i = 0; i < m_mesh->iNumIntBdryFaces(); i++) {
    if(m_mesh->pIBEIntBdryEdge(i)->qDeleted()) continue;
    bdry_edge = dynamic_cast<BdryEdgeBase*>(m_mesh->pIBEIntBdryEdge(i));
    assert(bdry_edge);      
    if( bdry_edge->eIsEncroached(m_mesh->eEncroachmentType()) != eClean )
      m_edge_split_queue.push_back(bdry_edge);
  }

}

void TriMeshRefiner::
add_to_priority_queue(Cell* const cell) {

  if(!m_IQ) return;
  if(cell->qDeleted()) return;
  assert(dynamic_cast<TriCell*>(cell)); 
  
  m_IQ->qAddEntry(cell); 
  
}

void TriMeshRefiner::
output_triangulation_to_file(const char* const filename) const {

  FILE* out_file = fopen(filename, "w");
  if(!out_file) vFatalError("Cannot open output file for writing", 
			    "TriMeshBuilder::output_verts_to_file"); 

  fprintf(out_file, "MeshVersionFormatted 1\n");
  fprintf(out_file, "Dimension 2\n");
  
  vector<Vert*> all_verts;
  
  for(GR_index_t i = 0; i < m_mesh->iNumVerts(); i++) 
    if(!m_mesh->pVVert(i)->qDeleted()) 
      all_verts.push_back(m_mesh->pVVert(i));

  vector<Vert*>::iterator itv,
                          itv_beg = all_verts.begin(),
                          itv_end = all_verts.end();

  fprintf(out_file, "Vertices\n");
  fprintf(out_file, "%d\n", static_cast<int>(itv_end - itv_beg) );
  
  for(itv = itv_beg; itv != itv_end; ++itv) {
    
    Vert* vertex = *itv;
    assert(!vertex->qDeleted());
    
    fprintf(out_file, "%lf %lf 1\n", 
	    vertex->dX(), vertex->dY());
  
  }

  vector<Face*> all_faces;
  int num_faces = m_mesh->iNumFaces();

  for(int i = 0; i < num_faces; ++i) {

    Face* face = m_mesh->pFFace(i);

    if( !face->qDeleted() )   
      all_faces.push_back(m_mesh->pFFace(i));

  }

  vector<Face*>::iterator itf,
                          itf_beg = all_faces.begin(),
                          itf_end = all_faces.end();
  
  fprintf(out_file, "Edges\n");
  fprintf(out_file, "%d\n", static_cast<int>(itf_end - itf_beg) );

  for(itf = itf_beg; itf != itf_end; ++itf) {
    
    Face* face = *itf;
    assert(!face->qDeleted());
    assert(face->iNumVerts() == 2);

    int index1 = std::find(itv_beg, itv_end, face->pVVert(0)) - itv_beg;
    int index2 = std::find(itv_beg, itv_end, face->pVVert(1)) - itv_beg;
    
    fprintf(out_file, "%d %d %d\n", 
	    index1 + 1, index2 + 1, face->iFaceLoc());
  
  }

  fprintf(out_file, "End\n");

  fclose(out_file);

}
