#include "GR_FaceSwapInfo.h"
#include "GR_Geometry.h"
#include "GR_SwapManager.h"
#include "GR_SwapDecider.h"
#include "GR_Mesh2D.h"

#ifdef SIM_ANNEAL_TEST
extern double simAnnealTemp;
#endif

namespace GRUMMP {
  void FaceSwapInfo2D::calculateFaceInfo(Face* const pF)
  {
    m_nonSwappable = false;
    if (!pF->qSwapAllowed() || pF->qLocked()) {
      m_nonSwappable = true;
      return;
    }

    //@@ Case: one or both cells is not a tri, including boundaries
    Cell *pCLeft = pF->pCCellLeft ();
    Cell *pCRight = pF->pCCellRight ();
    if (!pCLeft->qValid () || !pCRight->qValid () ||
	pCLeft->eType () != Cell::eTriCell ||
	pCRight->eType () != Cell::eTriCell) {
      m_nonSwappable = true;
      return;
    }
    
    m_pTris[0] = dynamic_cast<TriCell*>(pCLeft);
    m_pTris[1] = dynamic_cast<TriCell*>(pCRight);
    // Already checked that these are tri's, so the dynamic casts should
    // always work unless the database is corrupt somehow.
    assert(m_pTris[0] != NULL);
    assert(m_pTris[1] != NULL);
    
    m_pVerts[0] = pF->pVVert(0);
    m_pVerts[1] = pF->pVVert(1);
    m_pVerts[2] = m_pTris[0]->pVVertOpposite (pF);
    m_pVerts[3] = m_pTris[1]->pVVertOpposite (pF);

    int iOrientA = iOrient2D (m_pVerts[0], m_pVerts[3], m_pVerts[2]);
    int iOrientB = iOrient2D (m_pVerts[1], m_pVerts[2], m_pVerts[3]);
    m_orientOK = (iOrientA == 1 && iOrientB == 1);
  }

  SwapManager2D::~SwapManager2D()
  {
    m_pM2D->removeObserver(this);
    vMessage(2, "SwapManager exiting.\n");
    vMessage(2, "  Used a %s SwapDecider.\n", m_pSD->getName().c_str());
    vMessage(2, "  Face swapping stats: \n");
    vMessage(2, "    %6d swaps out of %6d attempts\n",
	     m_successes, m_attempts);
  }

  int SwapManager2D::swapFace(FaceSwapInfo2D& FSI2D)
  {
    m_attempts++;
    if (m_pSD->doFaceSwap(FSI2D)) {
      reconfigure(FSI2D);
      m_successes++;
      return 1;
    }
    else
      return (0);
  }

  int SwapManager2D::swapAllFaces()
  {
    // Initialize the queue with all the faces in the mesh.
    EntContainer<EdgeFace>::iterator ECiter = m_pM2D->edgeFace_begin(),
      ECiterEnd = m_pM2D->edgeFace_end();
    for ( ; ECiter != ECiterEnd; ++ECiter) {
      Face *pF = &(*ECiter);
      faceQueue.insert(pF);
    }

    int numSwaps = 0, swapsThisPass = 0, passes = 0;
    do {
      int attempts = faceQueue.size();
      swapsThisPass = swapAllQueuedFaces();
      numSwaps += swapsThisPass;
      passes++;

      vMessage(2, "Pass %d, %d swaps out of %d attempts\n",
	       passes, swapsThisPass, attempts);
      m_pM2D->sendEvents();
      vMessage(2, "  Master swap queue now has %zu faces.\n",
	       faceQueue.size());
#ifdef SIM_ANNEAL_TEST
      vMessage(2, "  Sim anneal temp is %f\n", simAnnealTemp);
      simAnnealTemp /= 1.1;
    } while (swapsThisPass != 0 && simAnnealTemp > 1.e-6);
#else
    } while (swapsThisPass != 0);
#endif
    return numSwaps;
  }

  int SwapManager2D::swapAllQueuedFaces()
  {
    std::set<Face*> liveFaceQueue;

    // Initialize the queue with all the faces in the queue.
    swap(faceQueue, liveFaceQueue);

    std::set<Face*>::iterator iter = liveFaceQueue.begin(),
      iterEnd = liveFaceQueue.end();
    int numSwaps = 0;
    FaceSwapInfo2D FSI2D;
    for ( ; iter != iterEnd; iter++) {
      Face *pF = *iter;
      FSI2D.calculateFaceInfo(pF);
      numSwaps += swapFace(FSI2D);
    } // for
    
    return numSwaps;
  }

  bool SwapManager2D::reconfigure(FaceSwapInfo2D& FSI2D) const
  {
    Cell* pTri[2];
    FSI2D.getTris(pTri);
    int iReg = pTri[0]->iRegion();
    m_pM2D->deleteCell(pTri[0]);
    m_pM2D->deleteCell(pTri[1]);

    Cell *pC0 = m_pM2D->createTriCell(FSI2D.getVertD(), FSI2D.getVertC(),
				 FSI2D.getVertA(), iReg);
    Cell *pC1 = m_pM2D->createTriCell(FSI2D.getVertC(), FSI2D.getVertD(),
				 FSI2D.getVertB(), iReg);
    
    assert(pC0->iFullCheck());
    assert(pC1->iFullCheck());

    return true;
  }

 void SwapManager2D::receiveDeletedFaces(std::vector<Face*>& deletedFaces)
  {
    vMessage(4, "SwapManager2D received word about %zu deleted faces.\n",
	     deletedFaces.size());
    std::vector<Face*>::iterator iter = deletedFaces.begin(),
      iterEnd = deletedFaces.end();
    for ( ; iter != iterEnd; ++iter ) {
      Face *pF = *iter;
      faceQueue.erase(pF);
    }
  }

  void SwapManager2D::receiveCreatedCells(std::vector<Cell*>& createdCells)
  {
    vMessage(4, "SwapManager2D received word about %zu new cells.\n",
	     createdCells.size());
    std::vector<Cell*>::iterator iter = createdCells.begin(),
      iterEnd = createdCells.end();
    for ( ; iter != iterEnd; ++iter) {
      Cell *pC = *iter;
      if (pC->eType() != CellSkel::eTriCell) continue;
      for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
	Face *pF = pC->pFFace(i);
	faceQueue.insert(pF);
      }
    }
  }

  void SwapManager2D::receiveMovedVerts(std::vector<Vert*>& movedVerts)
  {
    vMessage(4, "SwapManager2D received word about %zu moved verts.\n",
	     movedVerts.size());
    std::vector<Vert*>::iterator iter = movedVerts.begin(),
      iterEnd = movedVerts.end();
    for ( ; iter != iterEnd; ++iter) {
      Vert *pV = *iter;
      // Need to be sure to get not just incident faces but also
      // opposite faces. 
      for (int i = pV->iNumFaces() - 1; i >= 0; i--) {
        Face *pF = pV->pFFace(i);
	Cell *pC = pF->pCCellLeft();
	for (int ii = pC->iNumFaces() - 1; ii >= 0; ii--) {
	  faceQueue.insert(pC->pFFace(ii));
	}

	pC = pF->pCCellRight();
	for (int ii = pC->iNumFaces() - 1; ii >= 0; ii--) {
	  faceQueue.insert(pC->pFFace(ii));
	}
      }
    }
  }

  void FaceSwapInfo2D::getTris(Cell* pTris[2]) const
  {
    pTris[0] = m_pTris[0];
    pTris[1] = m_pTris[1];
  }


} // namespace GRUMMP
