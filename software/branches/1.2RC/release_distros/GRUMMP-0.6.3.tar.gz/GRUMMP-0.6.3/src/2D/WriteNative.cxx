#include <stdio.h>
#include "GR_misc.h"
#include "GR_events.h"
#include "GR_Face.h"
#include "GR_Cell.h"
#include "GR_BFace.h"
#include "GR_Vertex.h"
#include "GR_Mesh2D.h"
void writeNative(Mesh2D& OutMesh,
		 const char strBaseFileName[],
		 const bool qHighOrder,
		 const char strExtraFileSuffix[])
{
  SUMAA_LOG_EVENT_BEGIN(OUTPUT);
  //  assert(OutMesh.qSimplicial());
  FILE *pFOutFile = fopen("/dev/zero", "r");
  char strFileName[1024];
  OutMesh.vPurge();
  sprintf(strFileName, "%s%s.mesh", strBaseFileName, strExtraFileSuffix);

  /*newfile mesh*/
  printf("Opening output file %s\n", strFileName);
  if (pFOutFile) fclose(pFOutFile);
  pFOutFile = fopen(strFileName, "w");
  if (NULL == pFOutFile)
    vFatalError("Couldn't open output file for writing",
                "2d mesh output");

  /*ncells nfaces nbfaces nverts*/
  fprintf(pFOutFile, "%u %u %u %u\n", OutMesh.iNumCells(),
	  OutMesh.iNumFaces(), OutMesh.iNumBdryFaces(), OutMesh.iNumVerts());

  for (GR_index_t iV = 0; iV < OutMesh.iNumVerts(); iV++) 
    /*verts: coords*/
    fprintf(pFOutFile, "%.16g %.16g\n",
	    OutMesh.pVVert(iV)->dX(), OutMesh.pVVert(iV)->dY());


  for (GR_index_t iF = 0; iF < OutMesh.iNumFaces(); iF++) {
    Face* pF = OutMesh.pFFace(iF);
    GR_sindex_t iCA, iCB;
    Cell *pC = pF->pCCellLeft();
    switch (pC->eType()) {
    case Cell::eBdryEdge:
    case Cell::eTriBFace:
    case Cell::eQuadBFace:
    case Cell::eIntBdryEdge:
    case Cell::eIntTriBFace:
    case Cell::eIntQuadBFace:
      iCA = - (dynamic_cast<BFace*>(pC))->iBdryCond();
      break;
//    case Cell::eIntBdryEdge:
//    case Cell::eIntTriBFace:
//    case Cell::eIntQuadBFace:
//      {
//        Face *pFOther = pC->pFFace(0);
//        if (pF == pFOther) pFOther = pC->pFFace(1);
//        Cell *pCOther = pFOther->pCCellOpposite(pC);
//        iCA = OutMesh.iCellIndex(pCOther);
//      }
//      break;
    default:
      iCA = OutMesh.iCellIndex(pC);
      break;
    }

    pC = pF->pCCellRight();
    switch (pC->eType()) {
    case Cell::eBdryEdge:
    case Cell::eTriBFace:
    case Cell::eQuadBFace:
    case Cell::eIntBdryEdge:
    case Cell::eIntTriBFace:
    case Cell::eIntQuadBFace:
      iCB = - (dynamic_cast<BFace*>(pC))->iBdryCond();
      break;
//    case Cell::eIntBdryEdge:
//    case Cell::eIntTriBFace:
//    case Cell::eIntQuadBFace:
//      {
//        Face *pFOther = pC->pFFace(0);
//        if (pF == pFOther) pFOther = pC->pFFace(1);
//        Cell *pCOther = pFOther->pCCellOpposite(pC);
//        iCB = OutMesh.iCellIndex(pCOther);
//      }
//      break;
    default:
      iCB = OutMesh.iCellIndex(pC);
      break;
    }
    /*faces: cells verts*/
    fprintf(pFOutFile, "%d %d %u %u\n", iCA, iCB,
	    OutMesh.iVertIndex(pF->pVVert(0)),
	    OutMesh.iVertIndex(pF->pVVert(1)));
  }


  for (GR_index_t iBF = 0; iBF < OutMesh.iNumBdryFaces(); iBF++) {
    BFace* pBF = OutMesh.pBFBFace(iBF);
    /*bdryfaces: face bc verts*/
    fprintf(pFOutFile, "%u %d %u %u\n",
	    OutMesh.iFaceIndex(pBF->pFFace(0)), pBF->iBdryCond(),
	    OutMesh.iVertIndex(pBF->pVVert(0)),
	    OutMesh.iVertIndex(pBF->pVVert(1)));
  }


  for (GR_index_t iC = 0; iC < OutMesh.iNumCells(); iC++) {
    Cell* pC = OutMesh.pCCell(iC);
    /*cells: region*/
    fprintf(pFOutFile, "%d\n", pC->iRegion());
  }

  fclose(pFOutFile);

  if (qHighOrder) {
    OutMesh.vWriteBdryPatchFile(strBaseFileName, strExtraFileSuffix);
  }

  SUMAA_LOG_EVENT_END(OUTPUT);
}
