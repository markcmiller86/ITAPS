#include <math.h>
#include "GR_misc.h"
#include "GR_Geometry.h"
#include "GR_Vertex.h"
#include "GR_Face.h"
#include "GR_Cell.h"
#include "GR_AdaptPred.h"
#include "GR_Vec.h"

//@ Compute the vector normal for a set of three verts
void
vNormal2D (const double adA[2], const double adB[2],
	   const double adC[2], double *const pdRes)
{
  double adTempB[] =
  {adB[0] - adA[0],
   adB[1] - adA[1]};
  double adTempC[] =
  {adC[0] - adA[0],
   adC[1] - adA[1]};
  *pdRes = adTempB[0] * adTempC[1] - adTempB[1] * adTempC[0];
}

//@ Compute the vector normal for a set of two verts
// This is always rotated 90 degrees counterclockwise from the vector
// running from vertex A to vertex B.
void
vNormal (const double adA[2], const double adB[2], double adRes[2])
{
  adRes[0] = adA[1] - adB[1];
  adRes[1] = adB[0] - adA[0];
}

//@ Determine whether a vertex lies inside, on or outside a triangle
int
iIsInTri (const Vert * const pV, const Vert * const pVertA,
	  const Vert * const pVertB, const Vert * const pVertC)
  // For pV to be inside the tri formed by pVertA-C, the orientation
  // has to be right wrt every face.  The return value is -1 if the
  // vert lies outside the tri, 0 if it's colinear with all three
  // faces (impossible for valid tris), 1 if it coincides with a vert
  // in the tri, 2 if it lies on an edge, and 3 if it lies strictly
  // inside. 
{
  assert (pV->qValid () && pV->iSpaceDimen () == 2);
  assert (pVertA->qValid () && pVertA->iSpaceDimen () == 2);
  assert (pVertB->qValid () && pVertB->iSpaceDimen () == 2);
  assert (pVertC->qValid () && pVertC->iSpaceDimen () == 2);
  int iRetVal = 0;
  int iCheck = iOrient2D (pVertA, pVertB, pV);
  if (iCheck == -1)
    return -1;
  iRetVal += iCheck;

  iCheck = iOrient2D (pVertB, pVertC, pV);
  if (iCheck == -1)
    return -1;
  iRetVal += iCheck;

  iCheck = iOrient2D (pVertC, pVertA, pV);
  if (iCheck == -1)
    return -1;
  iRetVal += iCheck;

  return (iRetVal);
}


//@ 2D orientation test
int
iOrient2D (const Vert * const pVertA, const Vert * const pVertB,
	   const Vert * const pVertC)
  // Computes the orientation of three verts in 2D
{
  assert (pVertA->qValid ());
  assert (pVertB->qValid ());
  assert (pVertC->qValid ());
  assert (pVertA->iSpaceDimen () == 2);
  assert (pVertB->iSpaceDimen () == 2);
  assert (pVertC->iSpaceDimen () == 2);
  return iOrient2D (pVertA->adCoords (), pVertB->adCoords (),
		    pVertC->adCoords ());
}

int
iOrient2D (const double adA[2], const double adB[2],
	   const double adC[2])
{
  if (qAdaptPred) {
    double dResult = orient2d_shew (adA, adB, adC);
    if (dResult > 0)
      return 1;
    else if (dResult < 0)
      return -1;
    else
      return 0;
  }
  else {
    double xa = adA[0];
    double ya = adA[1];

    double xb = adB[0];
    double yb = adB[1];

    double xc = adC[0];
    double yc = adC[1];

    // Currently no exact arithmetic
    double dDet = ((xb - xa) * (yc - ya) - (xc - xa) * (yb - ya));
    // Scale the determinant by the mean of the magnitudes of vectors:
    double dScale = (dDIST2D (adA, adB) + dDIST2D (adB, adC)
		     + dDIST2D (adC, adA)) / 3;
    dDet /= (dScale * dScale);
    if (dDet > 1.e-10)
      return 1;
    else if (dDet < -1.e-10)
      return -1;
    else
      return 0;
  }
}

//@ Incircle test
int
iIncircle (const Vert * const pVertA, const Vert * const pVertB,
	   const Vert * const pVertC, const Vert * const pVertD)
  // Determines whether pVertD is inside or outside the circumcircle
  // of the tri formed by pVertA-C, using as nearly exact arithmetic
  // as required.  Returns 1 if pVertD is inside the
  // circumcircle of the tri, -1 if outside, 0 if on. 
{
  assert (pVertA->qValid ());
  assert (pVertB->qValid ());
  assert (pVertC->qValid ());
  assert (pVertD->qValid ());
  return iIncircle(pVertA->adCoords(), pVertB->adCoords(),
		   pVertC->adCoords(), pVertD->adCoords());
}

int
iIncircle (const double adA[2], const double adB[2],
	   const double adC[2], const double adD[2])
  // Determines whether pVertD is inside or outside the circumcircle
  // of the tri formed by pVertA-C, using as nearly exact arithmetic
  // as required.  Returns 1 if pVertD is inside the
  // circumcircle of the tri, -1 if outside, 0 if on. 
{
  if (qAdaptPred) {
    double dResult = incircle_shew (adA, adB, adC, adD);
    if (dResult > 0)
      return 1;
    else if (dResult < 0)
      return -1;
    else
      return 0;
  }
  else {
    double xa = adA[0];
    double ya = adA[1];
    double wa2 = xa * xa + ya * ya;

    double xb = adB[0];
    double yb = adB[1];
    double wb2 = xb * xb + yb * yb;

    double xc = adC[0];
    double yc = adC[1];
    double wc2 = xc * xc + yc * yc;

    double xd = adD[0];
    double yd = adD[1];
    double wd2 = xd * xd + yd * yd;

    // Currently no exact arithmetic
    double dDet1 = ((xb - xa) * ((yc - ya) * (wd2 - wa2) - (yd - ya) * (wc2 - wa2))
		    + (xc - xa) * ((yd - ya) * (wb2 - wa2) - (yb - ya) * (wd2 - wa2))
		    + (xd - xa) * ((yb - ya) * (wc2 - wa2) - (yc - ya) * (wb2 - wa2))
		    );
    int iOrient = iOrient2D(adA, adB, adC);
    double dProd = dDet1 * iOrient;
    // Scale by the mean of the magnitudes of vectors:
    double dScale = (dDIST2D (adB, adA) +
		     dDIST2D (adC, adA) +
		     dDIST2D (adB, adC)) / 3;
    // Unclear exactly how to scale this...
    dProd /= (dScale * dScale * dScale * dScale);
    if (dProd > 1.e-10)
      return -1;
    else if (dProd < -1.e-10)
      return 1;
    else
      return 0;
  }
}

bool LineLineIntersection(const Vert* const pVA, const Vert* const pVB,
			  const Vert* const pVC, const Vert* const pVD,
			  double intersection[2]) {

  assert(pVA->qValid() && pVB->qValid() &&
	 pVC->qValid() && pVD->qValid());
  assert(pVA->iSpaceDimen() == 2 && pVB->iSpaceDimen() == 2 &&
	 pVC->iSpaceDimen() == 2 && pVD->iSpaceDimen() == 2);

  double det_x, det_y, det_denom, det1, det2;
  double x1 = pVA->dX(), x2 = pVB->dX(), x3 = pVC->dX(), x4 = pVD->dX();
  double y1 = pVA->dY(), y2 = pVB->dY(), y3 = pVC->dY(), y4 = pVD->dY();

  det1  = x1 * y2 - x2 * y1;
  det2  = x3 * y4 - x4 * y3;
  det_x = det1 * (x3 - x4) - det2 * (x1 - x2);
  det_y = det1 * (y3 - y4) - det2 * (y1 - y2);
  det_denom = (x1 - x2) * (y3 - y4) - (x3 - x4) * (y1 - y2);
    
  if(iFuzzyComp(det_denom, 0.) == 0) return false; //parallel
  else {
    intersection[0] = det_x / det_denom;
    intersection[1] = det_y / det_denom;
    return true;
  }

}

int iRayIntersect(const Vert* const pVA, const Vert* pVB,
		  const Vert* const pVC, const Vert* pVD,
		  double* intersection) {

  double inter[2];
  if( !LineLineIntersection(pVA, pVB, pVC, pVD, inter) ) return -1;

  double x = inter[0], y = inter[1];

  if(intersection != NULL) 
    { intersection[0] = x; intersection[1] = y; }
  
  double x1 = pVC->dX(), x2 = pVD->dX();
  double y1 = pVC->dY(), y2 = pVD->dY();

//   printf("intersection: %lf %lf\n", x, y);
//   printf("x1 = %lf, y1 = %lf\n", x1, y1);
//   printf("x2 = %lf, y2 = %lf\n", x2, y2);

  double vec_vAvB[]    = { pVB->dX() - pVA->dX(), pVB->dY() - pVA->dY() };
  double vec_vAinter[] = { inter[0]  - pVA->dX(), inter[1]  - pVA->dY() };
  if( iFuzzyComp(dDOT2D(vec_vAvB, vec_vAinter), 0.) <= 0) return -1;

  if( iFuzzyComp(std::min(x1, x2), x) <= 0 && 
      iFuzzyComp(std::max(x1, x2), x) >= 0 &&
      iFuzzyComp(std::min(y1, y2), y) <= 0 && 
      iFuzzyComp(std::max(y1, y2), y) >= 0 ) return 1;

//   if( iFuzzyComp(std::min(x1, x2), x) == 0 && 
//       iFuzzyComp(std::max(x1, x2), x) == 0 &&
//       iFuzzyComp(std::min(y1, y2), y) == 0 && 
//       iFuzzyComp(std::max(y1, y2), y) == 0 ) return 0;
  
  return -1;

}

int iSegmentIntersect(const Vert* const pVA, const Vert* pVB,
		      const Vert* const pVC, const Vert* pVD) {

  //The ends of both lines are included in intersection search.

  double inter[2];
  if( !LineLineIntersection(pVA, pVB, pVC, pVD, inter) ) return -1;
  
  double x  = inter[0],  y = inter[1];
  double x1 = pVA->dX(), x2 = pVB->dX(), x3 = pVC->dX(), x4 = pVD->dX();
  double y1 = pVA->dY(), y2 = pVB->dY(), y3 = pVC->dY(), y4 = pVD->dY();

  if( iFuzzyComp(std::min(x1, x2), x) <= 0 && 
      iFuzzyComp(std::max(x1, x2), x) >= 0 &&
      iFuzzyComp(std::min(y1, y2), y) <= 0 && 
      iFuzzyComp(std::max(y1, y2), y) >= 0 &&
      iFuzzyComp(std::min(x3, x4), x) <= 0 &&
      iFuzzyComp(std::max(x3, x4), x) >= 0 &&
      iFuzzyComp(std::min(y3, y4), y) <= 0 &&
      iFuzzyComp(std::max(y3, y4), y) >= 0 ) return 1;
 
  return -1;
 
}

//@ End of file
//@ End of file
