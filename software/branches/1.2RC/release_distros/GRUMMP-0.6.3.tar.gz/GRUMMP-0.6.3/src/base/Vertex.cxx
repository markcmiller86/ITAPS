#include <math.h>
#include <stdlib.h>
#include "GR_Vertex.h"
#include "GR_BFace.h"
#include "GR_Mesh.h"
#include "GR_Bdry3D.h"

#include "CubitBox.hpp"
#include "CubitVector.hpp"

#if (defined(SOLARIS2) && !defined(NDEBUG))
// Solaris puts the definition of finite() in an odd place.  Need this
// only in some assertions, so don't include the file when assertions
// are null.
#include <ieeefp.h>
#endif

Face* Vert::pFHintFace() const
{
  assert(!qDeleted());
  if (pFHint->qValid() && pFHint->qHasVert(this)) {
    return pFHint;
  }
  else {
#ifdef USE_VECTOR
    if (vecpFInc.size() > 0) {
      pFHint = vecpFInc[0];
#else
    if (pFL->size() > 0) {
      pFHint = pFL->pFGetFace(0);
#endif
      assert(pFHint->qValid() && pFHint->qHasVert(this));
      return pFHint;
    }
    else {
      return pFInvalidFace;
    }
  }
}

void Vert::vSetHintFace(Face *const pF)
{
  assert(qValid() && !qDeleted());
  assert(pF->qValid() && !pF->qDeleted());
#ifndef NDEBUG
  bool qOK = false;
  for (int ii = 0; ii < pF->iNumVerts(); ii++) {
    if (pF->pVVert(ii) == this) qOK = true;
  }
  assert(qOK);
#endif
  pFHint = pF;
}

Face* Vert::pFSetHintFace(const Mesh* const pM)
{
  assert(qValid() && !qDeleted());

  if (pFHint->qValid() && !pFHint->qDeleted() && pFHint->qHasVert(this))
    return pFHint;
  
  int i;
  // Check first among boundary faces.
  for (i = pM->iNumBdryFaces() - 1; i >= 0; i--) {
    BFace *pBF = pM->pBFBFace(i);
    if (pBF->qValid() && !pBF->qDeleted() && pBF->qHasVert(this)) {
      pFHint = pBF->pFFace(0);
      return pFHint;
    }
  }
  // Failing that, try all the faces until you get a hit.
  for (i = pM->iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pM->pFFace(i);
    if (pF->qValid() && !pF->qDeleted() && pF->qHasVert(this)) {
      pFHint = pF;
      return pFHint;
    }
  }
  return pFInvalidFace;
}

void Vert::vUpdateHintFace()
{
  assert(qValid() && !qDeleted());

  Face *pF;
  if (pFL->size() == 0) {
    pF = pFInvalidFace;
  }
  else {
    pF = pFL->pFGetFace(0);
    assert(pF->qValid() && !pF->qDeleted() && pF->qHasVert(this));
    if (pF == pFHint) {
      // This is bad, because the hint face is presumably about to be
      // deleted, or we wouldn't be here.
      pF = pFL->pFGetFace(1);
      assert(pF->qValid() && !pF->qDeleted() && pF->qHasVert(this));
    }
  }
  pFHint = pF;
}

Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
		     bool qCanBeConnectedBothSides)
{
#ifdef USE_VECTOR
  std::vector<Face *>::const_iterator iter0 = pV0->vecpFInc.begin(),
    iter0_end = pV0->vecpFInc.end(),
    iter1, iter1_end = pV1->vecpFInc.end();

  for (; iter0 != iter0_end; iter0++) {
    for (iter1 = pV1->vecpFInc.begin(); iter1 != iter1_end; iter1++) {
      if (*iter0 == *iter1) return (*iter0);
    }
  }
  return pFInvalidFace;
#else
  int iMax0 = pV0->pFL->size();

  Face *result = pFInvalidFace;
  Face *possible = pFInvalidFace;
  for (int i0 = 0; i0 < iMax0; i0++) {
    Face *pFCand = pV0->pFL->pFGetFace(i0);
    assert(pFCand->qValid());
    assert(!pFCand->qDeleted());
    if (pFCand->qHasVert(pV1)) {
      if (!pFCand->pCCellLeft()->qValid() ||
	  !pFCand->pCCellRight()->qValid() ||
	  pFCand->eType() == Face::eMultiEdge) {
	result = pFCand;
      }
      else {
	possible = pFCand;
      }
    }
  }
  assert(result || !possible || qCanBeConnectedBothSides);
  if (!result && qCanBeConnectedBothSides) result = possible;
  return result;
#endif
}

Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
		     const Vert * const pV2, const Vert * const pV3,
		     bool qCanBeConnectedBothSides)
{
  assert(pV0->qValid());
  assert(pV1->qValid());
  assert(pV2->qValid());
#ifdef USE_VECTOR
  std::vector<Face *>::const_iterator iterA = pV0->vecpFInc.begin(),
    iterA_end = pV0->vecpFInc.end(),
    iterB, iterB_end = pV1->vecpFInc.end();
  Face *apFCom01[pV0->vecpFInc.size()];
  int iComCount = 0;

  Face *result = pFInvalidFace;
  
  for (; iterA != iterA_end; iterA++) {
    assert(*iterA != pFInvalidFace);
    if((*iterA)->qDeleted()) continue;
    for (iterB = pV1->vecpFInc.begin(); iterB != iterB_end; iterB++) {
      assert(*iterB != pFInvalidFace);
      if((*iterB)->qDeleted()) continue;
      if (*iterA == *iterB) {
	apFCom01[iComCount++] = *iterA;
      }
    }
  }

  // Now check which of those faces are also common to pV2.
  Face **iterCom_end = apFCom01 + iComCount;
  iterB_end = pV2->vecpFInc.end();
  for (Face **iterCom = apFCom01;
       iterCom != iterCom_end && !result;
       iterCom++) {
    assert(*iterCom != pFInvalidFace);
    if((*iterCom)->qDeleted()) continue;
    for (iterB = pV2->vecpFInc.begin();
	 iterB != iterB_end && !result;
	 iterB++) {
      if (*iterCom == *iterB) {
	result = (*iterCom);
      }
    }
  }
#else
  int iMax0 = pV0->pFL->size();
  int iMax1 = pV1->pFL->size();
  int iMax2 = pV2->pFL->size();
  
  Face *result = pFInvalidFace;
  Face *possible = pFInvalidFace;

  if (iMax0 < iMax1 && iMax0 < iMax2) {
    for (int i0 = 0; i0 < iMax0; i0++) {
      Face *pFCand = pV0->pFL->pFGetFace(i0);
      assert(pFCand != pFInvalidFace);
      if (!pFCand->qDeleted() &&
	  pFCand->qHasVert(pV1) &&
	  pFCand->qHasVert(pV2)) {
	if (pFCand->pCCellLeft()->qValid() &&
	    pFCand->pCCellRight()->qValid()) {
	  possible = pFCand;
	}
	else {
	  result = pFCand;
	}
      }
    }
  }
  else if (iMax1 < iMax2) {
    for (int i1 = 0; i1 < iMax1; i1++) {
      Face *pFCand = pV1->pFL->pFGetFace(i1);
      assert(pFCand != pFInvalidFace);
      if (!pFCand->qDeleted() &&
	  pFCand->qHasVert(pV0) &&
	  pFCand->qHasVert(pV2)) {
	if (pFCand->pCCellLeft()->qValid() &&
	    pFCand->pCCellRight()->qValid()) {
	  possible = pFCand;
	}
	else {
	  result = pFCand;
	}
      }
    }
  }
  else {
    // Vert 2 has the fewest neighbors.
    for (int i2 = 0; i2 < iMax2; i2++) {
      Face *pFCand = pV2->pFL->pFGetFace(i2);
      assert(pFCand != pFInvalidFace);
      if (!pFCand->qDeleted() &&
	  pFCand->qHasVert(pV1) &&
	  pFCand->qHasVert(pV0)) {
	if (pFCand->pCCellLeft()->qValid() &&
	    pFCand->pCCellRight()->qValid()) {
	  possible = pFCand;
	}
	else {
	  result = pFCand;
	}
      }
    }
  }
  
  // Prefer a result that has only one cell attached to it.
  assert(result || !possible || qCanBeConnectedBothSides);
  if (!result && qCanBeConnectedBothSides) result = possible;
#endif

  assert(!result->qValid() ||
	 (result->qHasVert(pV0) && result->qHasVert(pV1) &&
	  result->qHasVert(pV2)));
  if (pV3->qValid() && result->qValid()) {
    bool qOK = result->qHasVert(pV3);
    if (!qOK) {
      // Trying to create a quad, but hit a snag...
      switch (result->eType()) {
      case Face::eTriFace:
	vFatalError("Tried to identify a quad, but three verts form a tri.",
		    "findCommonFace");
	break;
      case Face::eQuadFace:
	vWarning("Tried to identify a quad, but another exists with three of these verts.");
	break;
      case Face::eEdgeFace:
      case Face::eMultiEdge:
	assert(0);
	// Should never be able to ID an edge w/ three verts in common.
	break;
      }
    }
  } // Done confirming face identity
  return result;
}

void Vert::vSetDefaultFlags()
{
  uiDim = 0;
  uiType = eInterior;
  qDel = qDelReq = qAct = qSurfStruct = qStruct = qShapeOK =
    qSmall = qShell = false;
  dLengthScale = LARGE_DBL;
}

void Vert::vResetAllData()
{
  vSetDefaultFlags();
  pFHint = pFInvalidFace;
#ifdef USE_VECTOR
  vecpFInc.clear();
#else
  if (pFL) delete pFL;
  pFL = new FaceList();
#endif
  vClearLS();
  adLoc[0] = adLoc[1] = adLoc[2] = 0;
}  

void Vert::vCopyAllFlags(const Vert &V)
{
  uiDim = V.uiDim;
  uiType = V.uiType;
  qDel = V.qDel;
  qDelReq = V.qDelReq;
  qAct = V.qAct;
  qSurfStruct = V.qSurfStruct;
  qStruct = V.qStruct;
  qShapeOK = V.qShapeOK;
  qSmall = V.qSmall;
  qShell = V.qShell;
}

bool Vert::qIsBdryVert() const
{
  bool qRetVal = false;
  qRetVal = ((uiType == eBdryApex) ||
	     (uiType == eBdryCurve) ||
	     (uiType == eBdryTwoSide) ||
	     (uiType == eBdry) ||
	     (uiType == ePseudoSurface));
  return qRetVal;
}

bool Vert::qSmoothable() const
{
  return (!qIsStructured() &&
	  !qDeletionRequested() &&
	  !qDeleted() &&
	  !(iVertType() == eBdryApex) &&
	  !(iVertType() == eBdryCurve) &&
	  !(iVertType() == eBdryTwoSide));
  // Technically, bdry curve points -are- smoothable, but that isn't
  // implemented yet.  
}

void Vert::vSetCoords(const int iNumDim, const double adNewLoc[])
{
  assert(iNumDim == 2 || iNumDim == 3);
  if (iSpaceDimen() == 0) vSetDimen(iNumDim);
  // The following assertion is false for ITAPS setting 2D coords...
#ifndef ITAPS
  assert(iNumDim == iSpaceDimen());
#endif
  switch(iNumDim) {
  case 3:
    assert(finite(adNewLoc[2]));
    adLoc[2] = adNewLoc[2];
    // Deliberate fallthrough
  case 2:
    assert(finite(adNewLoc[1]));
    assert(finite(adNewLoc[0]));
    adLoc[1] = adNewLoc[1];
    adLoc[0] = adNewLoc[0];
    break;
  default:
    assert(0);
  }
  vMarkIllShaped();
}

void Vert::vSetCoords(const char * const pcBuffer)
{
  switch (iSpaceDimen()) {
  case 2:
    sscanf(pcBuffer, "%lf %lf", &(adLoc[0]), &(adLoc[1]));
    assert(finite(adLoc[0]));
    assert(finite(adLoc[1]));
    break;
  case 3:
    sscanf(pcBuffer, "%lf %lf %lf", &(adLoc[0]), &(adLoc[1]), &(adLoc[2]));
    assert(finite(adLoc[0]));
    assert(finite(adLoc[1]));
    assert(finite(adLoc[2]));
    break;
  default:
    assert(0);
  }
  vMarkIllShaped();
}

void Vert::vSetCoords(const int iNumDim, const CubitVector& coord) {
  assert(iNumDim == 2 || iNumDim == 3);
  if (iSpaceDimen() == 0) vSetDimen(iNumDim);
  assert(iNumDim == iSpaceDimen());
  switch(iNumDim) {
  case 3:
    assert(finite(coord.z()));
    adLoc[2] = coord.z();
    // Deliberate fallthrough
  case 2:
    assert(finite(coord.y()));
    assert(finite(coord.x()));
    adLoc[1] = coord.y();
    adLoc[0] = coord.x();
    break;
  default:
    assert(0);
  }
  vMarkIllShaped();
}

CubitBox Vert::
bounding_box() const {
 
  CubitVector coord1;
  CubitVector coord2;
    
  if(iSpaceDimen() == 2) {
    coord1.set(dX(), dY(), 0.);
    coord2.set(dX(), dY(), 0.);
  }
  else {
    coord1.set(dX(), dY(), dZ());
    coord2.set(dX(), dY(), dZ());
  }

  return CubitBox(coord1, coord2); 

}

double dDistanceBetween(const Vert * const pV0, const Vert * const pV1)
{
  assert(pV0->iSpaceDimen() == pV1->iSpaceDimen());
  if (pV0->iSpaceDimen() == 2) 
    return dDIST2D(pV0->adCoords(), pV1->adCoords());
  else {
    assert(pV0->iSpaceDimen() == 3);
    return dDIST3D(pV0->adCoords(), pV1->adCoords());
  }
}

Face* findCommonFace(const Vert * const pV0, const Vert * const pV1)
{
  // At this point, can't do much better than finding and comparing
  // neighborhoods.
  std::set<Face*> spF0, spF1;
  {
    std::set<Cell*> spCTmp0, spCTmp1;
    std::set<Vert*> spVTmp0, spVTmp1;
    vNeighborhood(pV0, spCTmp0, spVTmp0, NULL, NULL, &spF0);
    vNeighborhood(pV1, spCTmp1, spVTmp1, NULL, NULL, &spF1);
  }
  Face **apF = new Face*[spF0.size()]; // Can't be any more than this.
  Face **ppFEnd = std::set_intersection(spF0.begin(), spF0.end(),
					spF1.begin(), spF1.end(), apF);
  int iCount = ppFEnd - apF;
  for (int ii = 0; ii < iCount; ii++) {
    Face *pF = apF[ii];
    if (pF->qHasVert(pV0) && pF->qHasVert(pV1))
      return pF;
  }
  return NULL;
}

// Stuff required for new-style length scale calculation

void Vert::vSetClosest(Vert * const pVIn) {
  assert(pVIn->qValid());
  pV1 = pVIn;
  qIsClosestVert = true;
}

void Vert::vSetClosest(BdryPatch * const pBPIn) {
  assert(pBPIn->qValid());
  pBP1 = pBPIn;
  qIsClosestVert = false;
}

void Vert::vSetClosest(Vert * const pVIn, BdryPatch * const pBPIn) {
  if (pVIn->qValid()) {
    assert(!pBPIn->qValid());
    vSetClosest(pVIn);
  }
  else {
    assert(pBPIn->qValid());
    vSetClosest(pBPIn);
  }
}

void Vert::vSetSecond(Vert * const pVIn) {
  assert(pVIn->qValid());
  pV2 = pVIn;
  qIsSecondVert = true;
}

void Vert::vSetSecond(BdryPatch * const pBPIn) {
  assert(pBPIn->qValid());
  pBP2 = pBPIn;
  qIsSecondVert = false;
}

void Vert::vSetSecond(Vert * const pVIn, BdryPatch * const pBPIn) {
  if (pVIn->qValid()) {
    assert(!pBPIn->qValid());
    vSetSecond(pVIn);
  }
  else {
    assert(pBPIn->qValid());
    vSetSecond(pBPIn);
  }
}

void Vert::vGetClosest(Vert **ppVOut, BdryPatch **ppBPOut) {
  if (qIsClosestVert) {
    (*ppVOut) = pV1;
    (*ppBPOut) = static_cast<BdryPatch*>(NULL);
  }
  else {
    (*ppVOut) = pVInvalidVert;
    (*ppBPOut) = pBP1;
  }
}

void Vert::vGetSecond(Vert **ppVOut, BdryPatch **ppBPOut) {
  if (qIsSecondVert) {
    (*ppVOut) = pV2;
    (*ppBPOut) = static_cast<BdryPatch*>(NULL);
  }
  else {
    (*ppVOut) = pVInvalidVert;
    (*ppBPOut) = pBP2;
  }
}
 
Vert& Vert::operator=(const Vert& V) {
  if (this != &V) {
    adLoc[0] = V.adLoc[0];
    adLoc[1] = V.adLoc[1];
    adLoc[2] = V.adLoc[2];
    pFHint = V.pFHint; // This hint will not be valid unless the face
    // is updated, too.
    (*pFL) = *(V.pFL);

    for (int i = iNumFaces() - 1; i >=0; i--) {
      Face *pF = pFFace(i);
      pF->vReplaceVert(&V, this);
    }

    vCopyAllFlags(V);
    vCopyInfluence(&V);
    dLengthScale = V.dLengthScale;
    parent_entity = V.parent_entity;
    parent_topology = V.parent_topology;
  }
  return (*this);
}
