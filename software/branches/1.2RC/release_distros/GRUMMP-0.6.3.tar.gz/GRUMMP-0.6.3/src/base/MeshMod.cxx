#include "GR_Mesh.h"

// Generally speaking, the functions in this file are generic topology
// change functions that are members of Face, Cell, etc.  These
// functions are intended only to be called by Mesh member functions
// that are changing topology in ways that only valid entities can ever
// exist (although topology may be incomplete at times).

void Face::vAssign(Cell* const pCA, Cell* const pCB,
		   Vert* const pV0, Vert* const pV1,
		   Vert* const pV2, Vert* const pV3)
{
  assert(qValid());
  pCL = pCA;
  pCR = pCB;
  vSetFaceLoc();
  vSetVerts(pV0, pV1, pV2, pV3);
}

/// This topology change function is only used in createFace (both in 2D
/// and 3D) and in vAssign.
void Face::vSetVerts(Vert* const pV0, Vert* const pV1,
		     Vert* const pV2, Vert* const pV3)
{
  assert(qValid());
  // Fallthrough is deliberate
  switch (iNumVerts()) {
  case 4:
    assert(pV3->qValid());
    apVVerts[3] = pV3;
    pV3->vAddFace(this);
#ifndef OMIT_VERTEX_HINTS
    if (!pV3->pFHintFace()->qValid()) pV3->vSetHintFace(this);
#endif
  case 3:
    assert(pV2->qValid());
    apVVerts[2] = pV2;
    pV2->vAddFace(this);
#ifndef OMIT_VERTEX_HINTS
    if (!pV2->pFHintFace()->qValid()) pV2->vSetHintFace(this);
#endif
  case 2:
    assert(pV1->qValid());
    apVVerts[1] = pV1;
    pV1->vAddFace(this);
#ifndef OMIT_VERTEX_HINTS
    if (!pV1->pFHintFace()->qValid()) pV1->vSetHintFace(this);
#endif
  case 1:
    assert(pV0->qValid());
    apVVerts[0] = pV0;
    pV0->vAddFace(this);
#ifndef OMIT_VERTEX_HINTS
    if (!pV0->pFHintFace()->qValid()) pV0->vSetHintFace(this);
#endif
    break;
  default:
    assert2(0, "Bad number of verts");
  }
  vMarkForSwap();
  vMarkIllSized();
}

