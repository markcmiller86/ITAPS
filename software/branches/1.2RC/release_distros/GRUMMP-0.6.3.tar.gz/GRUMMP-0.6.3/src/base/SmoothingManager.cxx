#include "GR_Cell.h"
#include "GR_SmoothingManager.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

namespace GRUMMP {
  SmoothingManager::~SmoothingManager()
  {
    m_pVM->removeObserver(this);
    // Smoothing stats will eventually be reported here.
  }

  void SmoothingManager::receiveCreatedCells(std::vector<Cell*>& createdCells)
  {
    vMessage(4, "SmoothingManager received word about %zu new cells.\n",
	     createdCells.size());
    std::vector<Cell*>::iterator iter = createdCells.begin(),
      iterEnd = createdCells.end();
    for ( ; iter != iterEnd; ++iter) {
      Cell *pC = *iter;
      if (pC->eType() != CellSkel::eTet) continue;
      for (int i = pC->iNumVerts() - 1; i >= 0; i--) {
	Vert *pV = pC->pVVert(i);
       	vertQueue.insert(pV);
      }
    }
  }

  void SmoothingManager::receiveDeletedVerts(std::vector<Vert*>& deletedVerts)
  {
    vMessage(4, "SmoothingManager received word about %zu deleted verts.\n",
	     deletedVerts.size());
    std::vector<Vert*>::iterator iter = deletedVerts.begin(),
      iterEnd = deletedVerts.end();
    for ( ; iter != iterEnd; ++iter) {
      Vert *pV = *iter;
      vertQueue.erase(pV);
    }
  }

  void SmoothingManager::receiveMovedVerts(std::vector<Vert*>& movedVerts)
  {
    vMessage(4, "SmoothingManager received word about %zu moved verts.\n",
	     movedVerts.size());
    std::vector<Vert*>::iterator iter = movedVerts.begin(),
      iterEnd = movedVerts.end();
    for ( ; iter != iterEnd; ++iter) {
      Vert *pV = *iter;
      for (int i = pV->iNumFaces() - 1; i >= 0; i--) {
        Face *pF = pV->pFFace(i);
	for (int ii = pF->iNumVerts() - 1; ii >= 0; ii--) {
	  vertQueue.insert(pF->pVVert(ii));
	}
      }
    }
  }

  int SmoothingManager::smoothVert(Vert* vert)
  {
    return m_pVM->iSmoothVertex(vert);
  }

  int SmoothingManager::smoothAllQueuedVerts()
  {
    // Initialize the active queue with all the verts in the master queue.
    std::set<Vert*> liveVertQueue;
    swap(vertQueue, liveVertQueue);
    vMessage(4, "Live vert queue contains %zu entries.\n",
	     liveVertQueue.size());

    std::set<Vert*>::iterator iter = liveVertQueue.begin(),
      iterEnd = liveVertQueue.end();
    int numSmoothed = 0;
    for ( ; iter != iterEnd; iter++) {
      Vert *pV = *iter;
      numSmoothed += smoothVert(pV);
    }    
    return numSmoothed;
  }

  int SmoothingManager::smoothAllVerts()
  {
    // Initialize the active queue with all the verts in the mesh.
    EntContainer<Vert>::iterator ECiter = m_pVM->vert_begin(),
      ECiterEnd = m_pVM->vert_end();
    for ( ; ECiter != ECiterEnd; ++ECiter) {
      Vert *pV = &(*ECiter);
      vertQueue.insert(pV);
    }

    int numSmoothed = 0, smoothedThisPass = 0, passes = 0;
    do {
      int attempts = vertQueue.size();
      smoothedThisPass = smoothAllQueuedVerts();
      numSmoothed += smoothedThisPass;
      passes++;

      vMessage(2, "Pass %d, %d smoothed out of %d attempts\n",
	       passes, smoothedThisPass, attempts);
      m_pVM->sendEvents();
      vMessage(2, "  Master smoothing queue now has %zu verts.\n",
	       vertQueue.size());
    } while (smoothedThisPass != 0 && passes < 20);
    return numSmoothed;
  }
}
