#include "GR_assert.h"
#include "GR_CellSkel.h"
#include "GR_Vec.h"
#include "GR_Vertex.h"

int CellSkel::iFullCheck() const
{
  if (!qValid() || qDeleted()) {
    return 0;
  }
  bool qOkay = true;
  for (int i = 0; i < iNumVerts() && qOkay; i++) {
    qOkay = pVVert(i)->qValid();
  }
  return (qOkay);
}

double CellSkel::dMaxDihed() const
{
  assert(qValid());
  int iNDihed;
  double adDihed[12];
  vAllDihed(adDihed, &iNDihed);
  double dRetVal = 0;
  for (int i = 0; i < iNDihed; i++)
    dRetVal = (dRetVal > adDihed[i]) ? dRetVal : adDihed[i];
  return dRetVal;
}

double CellSkel::dMinDihed() const
{
  assert(qValid());
  int iNDihed;
  double adDihed[12];
  vAllDihed(adDihed, &iNDihed);
  double dRetVal = 180;
  for (int i = 0; i < iNDihed; i++)
    dRetVal = (dRetVal < adDihed[i]) ? dRetVal : adDihed[i];
  return dRetVal;
}

double CellSkel::dMaxSolid() const
{
  assert(qValid());
  int iNSolid;
  double adSolid[12];
  vAllSolid(adSolid, &iNSolid);
  double dRetVal = 0;
  for (int i = 0; i < iNSolid; i++)
    dRetVal = (dRetVal > adSolid[i]) ? dRetVal : adSolid[i];
  return dRetVal;
}

double CellSkel::dMinSolid() const
{
  assert(qValid());
  int iNSolid;
  double adSolid[12];
  vAllSolid(adSolid, &iNSolid);
  double dRetVal = 360;
  for (int i = 0; i < iNSolid; i++)
    dRetVal = (dRetVal < adSolid[i]) ? dRetVal : adSolid[i];
  return dRetVal;
}

bool CellSkel::qHasVert(const Vert* pV) const
{
  assert(qValid());
  for (int i = 0; i < iNumVerts(); i++)
    if (pVVert(i) == pV) return true;
  return false;
}

