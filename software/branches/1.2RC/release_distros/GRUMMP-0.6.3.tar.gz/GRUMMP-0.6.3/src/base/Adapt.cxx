#include "GR_InsertionQueue.h"
#include "GR_Mesh.h"

void Mesh::vAdaptToLengthScale(const eEncroachType eET)
{
  vMessage(1, "Making mesh Delaunay\n");
  bool qResult = qDelaunayize();
  if (!qResult) {
    vWarning("Couldn't make mesh fully Delaunay before coarsening!\n");
    vWarning("This MIGHT still turn out okay...\n");
  }
  
  vMessage(1, "Coarsening\n");
  vCoarsenToLengthScale();

  vMessage(1, "Ensuring that mesh is Delaunay\n");
  qResult = qDelaunayize();
  if (!qResult) {
    vFatalError("Couldn't make mesh Delaunay!  Insertion will fail; bailing out!\n",
		"Mesh::vAdaptToLengthScale");
  }
  
  vMessage(1, "Refining\n");
  // Set up insertion queue and insert.
  vSetEncroachmentType(eET);
  InsertionQueue IQ(this);
  IQ.vQualityRefine();
  vPurge();
  
  iSmooth(2);
  assert(qValid());
}
