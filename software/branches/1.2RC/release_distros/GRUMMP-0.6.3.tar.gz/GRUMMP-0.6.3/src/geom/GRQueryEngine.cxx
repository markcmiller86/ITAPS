#include "GR_misc.h"
#include "GR_GRQueryEngine.h"

#include "CubitString.hpp"
#include "CubitVector.hpp"
#include "DLIList.hpp"
#include "Body.hpp"
#include "GMem.hpp"
#include "TopologyBridge.hpp"
#include "GeometryEntity.hpp"
#include "BodySM.hpp"
#include "Surface.hpp"
#include "Curve.hpp"
#include "Point.hpp"
#include "GeometryQueryTool.hpp"

#include <stdio.h>
#include <string.h>

GRQueryEngine* GRQueryEngine::instance_ = NULL;

//================================================================================
// Description: Returns the instance of GRQueryEngine object
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
GRQueryEngine* GRQueryEngine::
instance() {

  if(instance_ == NULL) { instance_ = new GRQueryEngine; }
  return instance_;

}

//================================================================================
// Description: Default constructor
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
GRQueryEngine::
GRQueryEngine() {

  GeometryQueryTool::instance()->add_gqe(this);

}

//================================================================================
// Description: Destructor
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
GRQueryEngine::
~GRQueryEngine() {

  instance_ = NULL;

}

//================================================================================
// Description: Returns GRUMMP version
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
int GRQueryEngine::
get_major_version() {

  int iVersion;
  char c[] = GRUMMP_VERSION;
  char* c1 = strtok(c, ".");
  sscanf(c1, "%d" , &iVersion);
  return iVersion;

}

int GRQueryEngine::
get_minor_version() {

  int iMinorVersion;
  char c[] = GRUMMP_VERSION;
  char* c1 = strtok(c, ".");
  c1 = strtok(NULL, ".");
  sscanf(c1, "%d", &iMinorVersion);
  return iMinorVersion;

}

int GRQueryEngine::
get_subminor_version() {

  int iSubminorVersion;
  char c[] = GRUMMP_VERSION;
  char* c1 = strtok(c, ".");
  c1 = strtok(NULL, ".");
  c1 = strtok(NULL, " ");
  sscanf(c1, "%d", &iSubminorVersion);
  return iSubminorVersion;

}

//================================================================================
// Description: Returns a string containing GRUMMP's version
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitString GRQueryEngine::
get_engine_version_string() {

  CubitString VersionString = "GRUMMP Geometry Engine version ";
  VersionString += CubitString(get_major_version());
  VersionString += CubitString(".");
  VersionString += CubitString(get_minor_version());
  VersionString += CubitString(".");
  VersionString += CubitString(get_subminor_version());
  
  return VersionString;

}

//================================================================================
// Description: Gets the curves underlying a curve (for cubic parametric curves)
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
get_underlying_curves(Curve* pCurve,
		      DLIList<TopologyBridge*>& CurveList) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::get_underlying_curves()");  

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Intersections between a curve and a line formed by two points.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
get_intersections(Curve* pCurve1, 
		  CubitVector& Point1,
		  CubitVector& Point2,
		  DLIList<CubitVector*>& IntersectionList,
		  bool qBounded,
		  bool qClosest) {

  IntersectionList.clean_out();

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::get_intersections()");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Intersections between two curves (see comments in GeometryQueryEngine)
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
get_intersections(Curve* pCurve1, 
		  Curve* pCurve2,
		  DLIList<CubitVector*>& IntersectionList,
		  bool qBounded,
		  bool qClosest) {

  IntersectionList.clean_out();

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::get_intersections()");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Intersection between a curve and a surface. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine::
get_intersections(Curve* pCurve, 
		  Surface* pSurface,
		  DLIList<CubitVector*>& IntersectionList,
		  bool qBounded) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_intersections()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Extremum locations in a given direction. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine::
entity_extrema(DLIList<GeometryEntity*>& RefEntityList, 
	       const CubitVector* pDir1, 
	       const CubitVector* pDir2,
	       const CubitVector* pDir3, 
	       CubitVector& Extrema,
	       GeometryEntity *&ExtremaEntityPtr) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::entity_extrema()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Minimum distance between two entities
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
entity_entity_distance(GeometryEntity* pEntity1,
		       GeometryEntity* pEntity2,
		       CubitVector& Loc1, 
		       CubitVector& Loc2,
		       double& dDistance) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::entity_entity_distance()");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Geometric operations. Will be implemented on an as needed basis.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
translate(BodySM* pBody,
	  const CubitVector& offset) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::translate()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
rotate(BodySM* pBody, 
       const CubitVector& axis,
       double dAngle) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::rotate()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
scale(BodySM* pBody,
      double dScaleFactor) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::scale()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
scale(BodySM* pBody, 
      const CubitVector& factors) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::scale()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
reflect (BodySM* pBody,
	 const CubitVector& axis) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::reflect()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
restore_transform(BodySM* pBody) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::restore_transform()");

  return CUBIT_SUCCESS;
  assert(0);

}


CubitStatus GRQueryEngine::
translate(GeometryEntity* pEnt,
	  const CubitVector& offset) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::translate()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
rotate(GeometryEntity* pEnt,
       const CubitVector& axis,
       double dAngle) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::rotate()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
scale(GeometryEntity* pEnt, 
      double dFactor) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::scale()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
scale(GeometryEntity* pEnt,
      const CubitVector& factors) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::scale()");

  return CUBIT_SUCCESS;
  assert(0);

}

CubitStatus GRQueryEngine::
reflect(GeometryEntity* pEnt,
	const CubitVector& axis) {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::reflect()");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Determines whether two bodies are overlapping
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================

CubitBoolean GRQueryEngine::
bodies_overlap(BodySM* pBody1,
	       BodySM* pBody2) const {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::reflect()");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Deletes a GRBody and all child entities. Not Defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
delete_solid_model_entities(BodySM* pBody) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::delete_solid_model_entities(BodySM*)");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Deletes a GRSurface and all its child entities
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
delete_solid_model_entities(Surface* pSurf) const {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::delete_solid_model_entities(Surface*)");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Deletes a GRCurve and all its child entities
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
delete_solid_model_entities(Curve* pCurve) const {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::delete_solid_model_entities(Curve*)");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Deletes a GRPoint and all its child entities
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
CubitStatus GRQueryEngine::
delete_solid_model_entities(Point* pPoint) const {

  vFatalError("This function is not yet implemented in GRQueryEngine",
	      "GRQueryEngine::delete_solid_model_entities(Point*)");

  return CUBIT_SUCCESS;
  assert(0);

}

//================================================================================
// Description: Fires ray at body and returns intersected entities. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine
::fire_ray(BodySM* pBody,
	   const CubitVector& RayStart,
	   const CubitVector& RayDirection,
	   DLIList<double>& dRayParams,
	   DLIList<GeometryEntity*>* pEntityList) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::fire_ray()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Gets isoparametric points for a surface. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine::
get_isoparametric_points(Surface* pSurf,
			 int& iNU,
			 int& iNV,
			 GMem *&gMem) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_isoparametric_points()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Gets U isoparametric points for a surface. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine::
get_u_isoparametric_points(Surface* pSurf,
			   double dV, 
			   int& iN,
			   GMem *&gMem) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_u_isoparametric_points()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Gets V isoparametric points for a surface. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================
inline CubitStatus GRQueryEngine::
get_v_isoparametric_points(Surface* pSurf,
			   double dU, 
			   int& iN,
			   GMem *&gMem) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_v_isoparametric_points()");
  return CUBIT_FAILURE;
  assert(0);

}

//================================================================================
// Description: Computes a vectorial transformation on a body. Not defined.
// Author     : Serge Gosselin
// Date       : 2006 / 02 / 01
//================================================================================

inline CubitStatus GRQueryEngine::
transform_vec_position(CubitVector const& PositionVector,
		       BodySM *OSME_ptr,
		       CubitVector& TransformVector) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::transform_vec_position()");
  return CUBIT_FAILURE;
  assert(0);

}



//The rest of functions should not be used any time soon in GRUMMP.

inline double GRQueryEngine::
get_sme_resabs_tolerance() const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_sme_resabs_tolerance()");
  return 0.;
  assert(0);

}

inline double GRQueryEngine::
set_sme_resabs_tolerance(double new_resabs) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::set_sme_resabs_tolerance()");
  return 0.;
  assert(0);

}

inline CubitStatus GRQueryEngine::
set_int_option(const char* opt_name,
	       int val) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::set_int_option()");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
set_dbl_option(const char* opt_name, 
	       double val) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::set_dbl_option()");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
set_str_option(const char* opt_name, 
	       const char* val) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::set_str_option()");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
get_graphics(Surface* surface_ptr,
	     int& number_of_triangles,
	     int& number_of_points,
	     int& number_of_facets,
	     GMem* gMem,
	     unsigned short normal_tolerance,
	     double distance_tolerance) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_graphics()");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
get_graphics(Curve* curve_ptr,
	     int& num_points,
	     GMem* gMem,
	     double tolerance) const {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::get_graphics()");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
export_solid_model(DLIList<TopologyBridge*>& bridge_list,
		   const char* file_name,
		   const char* file_type,
		   const CubitString &cubit_version,
		   const char* logfile_name) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::export_solid_model");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
save_temp_geom_file(DLIList<TopologyBridge*> &ref_entity_list,
		    const char *filename,
		    const CubitString &cubit_version,
		    CubitString &created_file,
		    CubitString &created_file_type) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::save_temp_geom_file");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
import_temp_geom_file(FILE* file_ptr, 
		      const char* file_name,
		      const char* file_type,
		      DLIList<TopologyBridge*> &bridge_list) {

  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::import_temp_geom_file");
  return CUBIT_FAILURE;
  assert(0);

}

inline CubitStatus GRQueryEngine::
import_solid_model(FILE* file_ptr, 
		   const char* file_name,
		   const char* file_type,
		   DLIList<TopologyBridge*>& imported_entities,
		   bool print_results,
		   const char* logfile_name,
		   bool heal_step,
		   bool import_bodies,
		   bool import_surfaces,
		   bool import_curves,
		   bool import_vertices,
		   bool free_surfaces) {
  
  vFatalError("This function is not defined in GRQueryEngine",
	      "GRQueryEngine::import_solid_model");
  return CUBIT_FAILURE;
  assert(0);

}
