#include "GR_GRCurveGeom.h"

GRInterp::
GRInterp() : GRSpline() {

  num_cubics = 0;
  cubics = NULL;
  closed = false;
  
}

GRInterp::
GRInterp(const CubitVector input_pts[],
	 const int num_pts,
	 const bool is_closed) : GRSpline() {

  if(num_pts < 3) 
    vFatalError("At least three points are needed to build an interpolated spline.",
		"GRInterp::GRInterp(const CubitVector, const int, const bool)");

  n_pts = num_pts;
  points = new CubitVector[n_pts];
  n_dim = 2;

  num_cubics = n_pts - 1;
  closed = is_closed;

  int i;
  for(i = 0; i < n_pts; i++)
    points[i] = input_pts[i];

  double (*x_coeff)[4] = new double[num_cubics][4];
  double (*y_coeff)[4] = new double[num_cubics][4];
  
  if(!closed) compute_coeffs_natural(x_coeff, y_coeff);
  else        compute_coeffs_closed (x_coeff, y_coeff);

  cubics = new GRCubic*[num_cubics];
  for(i = 0; i < num_cubics; i++)
    cubics[i] = new GRCubic(x_coeff[i], y_coeff[i]);   
  
  delete [] x_coeff;
  delete [] y_coeff;

//   printf("\n\n");
//   for(i = 0; i < num_cubics; i++) {
//     for(int j = 0; j < 20; j++) {
//       double param = static_cast<double>(j) / 20.;
//       CubitVector coord;
//       cubics[i]->coord_at_param(param, coord);
//       printf("%.9lf %.9lf\n", coord.x(), coord.y());
//     }
//   }
//   printf("\n\n");

}

GRInterp::
GRInterp(const GRInterp& interp) : GRSpline() {

  assert(interp.qValid());
  
  n_pts = interp.n_pts;
  n_dim = 2;
  num_cubics = interp.num_cubics;
     
  points = new CubitVector[n_pts];
  int i;
  for(i = 0; i < n_pts; i++)
    points[i] = interp.points[i];  

  cubics = new GRCubic*[num_cubics];
  for(i = 0; i < n_pts - 1; i++)
    cubics[i] = new GRCubic(*(interp.cubics[i]));
  
  closed = interp.closed;

  assert(qValid());

}

GRInterp& GRInterp::
operator=(const GRInterp& interp) {

  assert(interp.qValid());
  
  n_pts = interp.n_pts;
  n_dim = 2;
  num_cubics = interp.num_cubics;
     
  points = new CubitVector[n_pts];
  int i;
  for(i = 0; i < n_pts; i++)
    points[i] = interp.points[i];  

  cubics = new GRCubic*[num_cubics];
  for(i = 0; i < n_pts - 1; i++)
    cubics[i] = new GRCubic(*(interp.cubics[i]));
  
  closed = interp.closed;

  assert(qValid());
  
  return *this;

}

GRInterp::
~GRInterp() {}

double GRInterp::
X(const int pt) const {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  return points[pt].x();

}
 
double GRInterp::
Y(const int pt) const {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  return points[pt].y();

}
 
double GRInterp::
Z(const int pt) const {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  return points[pt].z();

}

void GRInterp::
get_coord(const int pt, 
	  CubitVector& coord) const {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  coord = points[pt];

}

const CubitVector& GRInterp::
get_coord(const int pt) const {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  return points[pt];

}
  
void GRInterp::
set_X(const int pt, 
      const double X_in) {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  if( pt == 0 || pt == n_pts - 1 ) {
    if( iFuzzyComp(points[0].x(), points[n_pts-1].x()) == 0 && 
	iFuzzyComp(points[0].y(), points[n_pts-1].y()) == 0 &&
	iFuzzyComp(points[0].z(), points[n_pts-1].z()) == 0 ) {
    points[0].x(X_in);
    points[n_pts - 1].x(X_in);
  }
  else 
    points[pt].x(X_in);
  }

  double (*x_coeff)[4] = new double[num_cubics][4];
  double (*y_coeff)[4] = new double[num_cubics][4];
  
  if(!closed) compute_coeffs_natural(x_coeff, y_coeff); 
  else        compute_coeffs_closed(x_coeff, y_coeff);

  int i;
  for(i = 0; i < num_cubics; i++) 
    cubics[i]->set_coeffs(x_coeff[i], y_coeff[i]);

  delete [] x_coeff;
  delete [] y_coeff;

}
 
void GRInterp::
set_Y(const int pt, 
      const double Y_in) {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);

  if( pt == 0 || pt == n_pts - 1 ) {
    if( iFuzzyComp(points[0].x(), points[n_pts-1].x()) == 0 && 
	iFuzzyComp(points[0].y(), points[n_pts-1].y()) == 0 &&
	iFuzzyComp(points[0].z(), points[n_pts-1].z()) == 0 ) {
    points[0].y(Y_in);
    points[n_pts - 1].y(Y_in);
  }
  else 
    points[pt].y(Y_in);
  }
  
  double (*x_coeff)[4] = new double[num_cubics][4];
  double (*y_coeff)[4] = new double[num_cubics][4];
  
  if(!closed) compute_coeffs_natural(x_coeff, y_coeff); 
  else        compute_coeffs_closed(x_coeff, y_coeff);

  int i;
  for(i = 0; i < num_cubics; i++) 
    cubics[i]->set_coeffs(x_coeff[i], y_coeff[i]);

  delete [] x_coeff;
  delete [] y_coeff;
}

void GRInterp::
set_Z(const int, const double) {
  vFatalError("Cannot modify z-coord for a 2D curve.",
	      "GRInterp::set_Z(const int, const double)");
}

void GRInterp::
set_coord(const int pt, 
	  const CubitVector& new_coord) {

  assert(qValid());
  assert(pt >= 0 && pt < n_pts);
  assert(iFuzzyComp(new_coord.z(), 0.) == 0);
  
  if( pt == 0 || pt == n_pts - 1 ) {
    if( iFuzzyComp(points[0].x(), points[n_pts-1].x()) == 0 && 
	iFuzzyComp(points[0].y(), points[n_pts-1].y()) == 0 &&
	iFuzzyComp(points[0].z(), points[n_pts-1].z()) == 0 ) 
      points[0] = points[n_pts - 1] = new_coord;
    else 
      points[pt] = new_coord;
  }

  double (*x_coeff)[4] = new double[num_cubics][4];
  double (*y_coeff)[4] = new double[num_cubics][4];
  
  if(!closed) compute_coeffs_natural(x_coeff, y_coeff); 
  else        compute_coeffs_closed(x_coeff, y_coeff);

  int i;
  for(i = 0; i < num_cubics; i++) 
    cubics[i]->set_coeffs(x_coeff[i], y_coeff[i]);
 
  delete [] x_coeff;
  delete [] y_coeff;

}

bool GRInterp::
qValid() const {

  if(n_pts < 3) { return false; }
  if(points == NULL) { return false; }
  if(cubics == NULL) { return false; }

  return true;

}

void GRInterp::
compute_coeffs_natural(double (*x_coeff)[4], 
		       double (*y_coeff)[4]) {

  //Computes the coefficients of the natural spline.
  //That is the spline with zero second derivative at both ends.

  double** LHS;
  double* RHS = new double[n_pts];
  
  LHS = new double* [n_pts];

  int i;
  for(i = 0; i < n_pts; i++) 
    LHS[i] = new double[3];    
    
  //Computing x coefficients
  LHS[0][0] = LHS[n_pts - 1][2] = 0.;
  LHS[0][1] = LHS[n_pts - 1][1] = 2.;
  LHS[0][2] = LHS[n_pts - 1][0] = 1.;
  RHS[0] = 3. * (points[1].x() - points[0].x());
  RHS[n_pts - 1] = 3. * (points[n_pts - 1].x() - points[n_pts - 2].x());

  for(i = 1; i < n_pts - 1; i++) {
    LHS[i][0] = 1.;
    LHS[i][1] = 4.;
    LHS[i][2] = 1.;
    RHS[i] = 3. * (points[i+1].x() - points[i-1].x());
  }
  
  vSolveTriDiag(LHS, RHS, n_pts - 2);

  for(i = 0; i < n_pts - 1; i++) {
    x_coeff[i][0] = points[i].x();
    x_coeff[i][1] = RHS[i];
    x_coeff[i][2] = 3. * (points[i+1].x() - points[i].x()) - 2. * RHS[i] - RHS[i+1];
    x_coeff[i][3] = 2. * (points[i].x() - points[i+1].x()) + RHS[i] + RHS[i+1];
  }

  //Getting y coefficients  
  LHS[0][0] = LHS[n_pts - 1][2] = 0.;
  LHS[0][1] = LHS[n_pts - 1][1] = 2.;
  LHS[0][2] = LHS[n_pts - 1][0] = 1.;
  RHS[0] = 3. * (points[1].y() - points[0].y());
  RHS[n_pts - 1] = 3. * (points[n_pts - 1].y() - points[n_pts - 2].y());

  for(i = 1; i < n_pts - 1; i++) {
    LHS[i][0] = 1.;
    LHS[i][1] = 4.;
    LHS[i][2] = 1.;
    RHS[i] = 3. * (points[i+1].y() - points[i-1].y());
  }

  vSolveTriDiag(LHS, RHS, n_pts - 2);

  for(i = 0; i < n_pts - 1; i++) {
    y_coeff[i][0] = points[i].y();
    y_coeff[i][1] = RHS[i];
    y_coeff[i][2] = 3. * (points[i+1].y() - points[i].y()) - 2. * RHS[i] - RHS[i+1];
    y_coeff[i][3] = 2. * (points[i].y() - points[i+1].y()) + RHS[i] + RHS[i+1];
  }

  for(i = 0; i < n_pts; i++) delete [] LHS[i];
  delete [] LHS;
  delete [] RHS;

}

void GRInterp::
compute_coeffs_closed(double (*x_coeff)[4], 
		      double (*y_coeff)[4]) {

  if(x_coeff && y_coeff) {}
  assert(0);

  //Not supported yet, but have to write a solver for
  //a matrix of the form
  //[4 1  ...   1]
  //[1 4 1       ]
  //[0 1 4 1     ] 
  //[     ...    ]
  //[1    ... 1 4]
  //The RHS is also slightly different

}
