/* geom/parallel/CGMmpi_config.h.  Generated from CGMmpi_config.h.in by configure.  */
/* MPICH_IGNORE_CXX_SEEK is not sufficient to avoid conflicts */
/* #undef CGM_MPI_CXX_CONFLICT */

/* "Value of C SEEK_CUR" */
/* #undef CGM_SEEK_CUR */

/* "Value of C SEEK_END" */
/* #undef CGM_SEEK_END */

/* "Value of C SEEK_SET" */
/* #undef CGM_SEEK_SET */
