//- Class:       FacetEntity
//- Description: FacetEntity class - the base class in the Facet Entity Tree.
//- Owner:       Steve Owen
//- Checked by:
//- Version: $Id: 

#include "FacetEntity.hpp"

FacetEntity::FacetEntity()
{

}

FacetEntity::~FacetEntity()
{
}

