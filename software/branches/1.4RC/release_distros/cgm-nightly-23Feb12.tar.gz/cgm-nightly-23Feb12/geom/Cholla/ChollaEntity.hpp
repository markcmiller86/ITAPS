//- Class:       ChollaEntity
//- Description: ChollaEntity class - the base class in the Cholla Geometry Entities.
//- Owner:       Steve Owen
//- Checked by:
//- Version: $Id:  

#ifndef CHOLLAENTITY_HPP
#define CHOLLAENTITY_HPP
 


class ChollaEntity
{   
private:
   
public:

  ChollaEntity();
  virtual ~ChollaEntity();
};

   

#endif // CHOLLAENTITY_HPP


