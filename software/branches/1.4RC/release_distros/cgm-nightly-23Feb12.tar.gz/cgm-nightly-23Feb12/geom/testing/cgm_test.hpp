

#ifndef CGM_TEST_H
#define CGM_TEST_H

// function to initialize cgm
void start_cgm(int argc, char** argv);
// function to shutdown cgm
void end_cgm(int argc, char** argv);


#endif // CGM_TEST_H

