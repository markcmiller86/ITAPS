
#ifndef TEST_CONFIG_HPP
#define TEST_CONFIG_HPP

static const char* DataDir = "@DATA_DIR@";

#endif

