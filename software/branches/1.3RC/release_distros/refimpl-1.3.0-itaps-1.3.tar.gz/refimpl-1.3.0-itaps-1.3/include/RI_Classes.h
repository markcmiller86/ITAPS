// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

/** This file contains forward declarations of all the classes in
 *  RefImpl.  This turns out to be a useful thing to have, so that another
 *  header file can use this one to provide enough info to have a
 *  pointer argument without having to include (possibly circularly) the
 *  full header file for that class.
 */

#ifndef RI_Classes
#define RI_Classes 1

/* Base class for all entities */
class Entity;

/* Cell classes */
class Cell;
#define pCInvalidCell (static_cast<Cell*>(NULL))

class TriCell;
class QuadCell;

class TetCell;
class PyrCell;
class PrismCell;
class HexCell;

/* Face classes */
class Face;
#define pFInvalidFace (static_cast<Face*>(NULL))

class EdgeFace;
class TriFace;
class QuadFace;

/* Mesh classes */
class Mesh;
class Mesh2D;
class VolMesh;

/* Vertices */
class Vert;
#define pVInvalidVert (static_cast<Vert*>(NULL))
class VertConnect;

#endif
