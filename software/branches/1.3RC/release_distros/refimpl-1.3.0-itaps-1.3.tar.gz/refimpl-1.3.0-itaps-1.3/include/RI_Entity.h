// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Entity_h
#define RI_Entity_h

// The following class is defined primarily so that ITAPS entities will
// work smoothly.  In particular, with a base Entity class that all
// RefImpl mesh pieces derive from, in the ITAPS interface (a) many entity
// queries can be handled trivially by polymorphism (perhaps easier than
// in a class that has internal state, interestingly) and (b) more
// importantly, when a function requires the return of a collection of
// entity handles, I can return pointers to RefImpl objects, and
// never have to address management of memory for newly-minted entities.

#include "RI_Classes.h"
#include "RI_iMesh_Classes.h"

// This typedef gives a more compact way to refer to entity handles in
// function signatures.
typedef iBase_EntityHandle_Private RefImpl_Entity;

/**\brief Base class for all entities in the mesh database.
 *
 * All mesh entities --- vertices, faces, cells --- in the mesh database
 * derive from this class, which in turn is derived from the trivial
 * iBase_EntityHandle_Private struct, because iMesh.h defines
 * iBase_EntityHandle as iBase_EntityHandle_Private*.
 *
 * This function has mostly pure virtual functions.
 */
class Entity : public iBase_EntityHandle_Private {
public:
  /// Default constructor, which does nothing, since there's no state data.
  Entity() {}

  /// Virtual destructor, as required; does nothing.
  virtual ~Entity() {}

  /// Ensure a sane initial state for entity data
  /** Each subclass defines a function that resets its internal state to
   * some reasonable values.
   */
  virtual void vResetAllData() = 0;

  /// Check whether this object contains valid data.
  /** RefImpl uses NULL pointers to indicate invalid/missing data. */
  bool qValid() const {return(this != NULL);}

  /// Retrieve the iV-th vertex (first) adjacent to the entity.
  virtual const Vert *pVVert(const int iV) const = 0;

  /// Retrieve the iF-th face (first) adjacent to the entity.
  /** Note that in this context, "face" == "d-1 dimensional entity,
   * which is different than the ITAPS definition.
   */
  virtual const Face *pFFace(const int iF) const = 0;

  /// Retrieve the iC-th face (first) adjacent to the entity.
  virtual const Cell *pCCell(const int iC) const = 0;

  /// Retrieve the iV-th vertex (first) adjacent to the entity.
  Vert *pVVert(const int iV)
    {return const_cast<Vert*>(static_cast<const Entity*>(this)->pVVert(iV));}

  /// Retrieve the iF-th face (first) adjacent to the entity .
  /** Note that in this context, "face" == "d-1 dimensional entity,
   * which is different than the ITAPS definition.
   */
  Face *pFFace(const int iF)
    {return const_cast<Face*>(static_cast<const Entity*>(this)->pFFace(iF));}

  /// Retrieve the iC-th face (first) adjacent to the entity.
  Cell *pCCell(const int iC)
    {return const_cast<Cell*>(static_cast<const Entity*>(this)->pCCell(iC));}

  /// Retrieves handles of all verts adjacent to entity, in canonical order.
  virtual void vAllVertHandles(RefImpl_Entity* aHandle[]) const = 0;

  /// Retrieves handles of all faces adjacent to entity.
  /** Note that in this context, "face" == "d-1 dimensional entity,
   * which is different than the ITAPS definition.
   *
   * If the entity is a cell, the faces are in canonical order.  If the
   * entity is a vertex or edge, there is no canonical order, and the
   * order of the result, while deterministic, may change between
   * releases. 
   */
  virtual void vAllFaceHandles(RefImpl_Entity* aHandle[]) const = 0;

  /// Retrieves handles of all cells adjacent to entity.
  /** No canonical order is defined, so the order is what it is. */
  virtual void vAllCellHandles(RefImpl_Entity* aHandle[]) const = 0;

  /// Returns number of verts (first) adjacent to the entity.
  virtual int iNumVerts() const = 0;

  /// Returns number of faces (first) adjacent to the entity.
  virtual int iNumFaces() const = 0;

  /// Returns number of cells (first) adjacent to the entity.
  virtual int iNumCells() const = 0;

  /// Tag an entity as deleted from the mesh.
  /** In practice, actual deletion in the sense of memory clean up is
   * done as a batch process at a later time.  Nevertheless, after this
   * call, the entity can no longer relied on to have relevant data. */
  virtual void vMarkDeleted() = 0;

  /// Return the iMesh type of the entity.
  virtual int eEntType() const = 0;

  /// Return the iMesh topology of the entity.
  virtual int eEntTopology() const = 0;
};

#endif // RI_Entity_h
