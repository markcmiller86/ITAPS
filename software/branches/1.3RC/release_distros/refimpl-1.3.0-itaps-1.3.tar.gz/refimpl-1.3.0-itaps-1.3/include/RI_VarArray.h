// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include "RI_config.h"

/**\brief A variable-sized array data class.
 *
 * In functionality, but not in interface, this class is similar to the
 * std::vector, except that data isn't copied from one place to another
 * when the size is increased.  This is because doing so would break all
 * the pointers used to store connectivity data.  Not all std::vector
 * functionality is duplicated (no push, for instance), and names are
 * different, for historical reasons.
 *
 * This class is a faux-template.  That is, the preprocessor templatizes
 * it through proper definitions of Type and VAType.  It's an ugly hack,
 * but this particular hack pre-dates reliable template implementations
 * in compilers.
 */
class VAType {
  /// The maximum number of sections to the overall data pool.
  enum {iMaxLists = 25};
  /// The data pool itself: an array of pointers to allocated data.
  Type* apTData[iMaxLists];

  /// Number of entries in use (some may be awaiting garbage collection).
  int iN;

  /// The number of entries currently allocated.
  int iMax;

  /// The number of entries allocated in each of the arrays.
  int aiMax[iMaxLists];

  /// The number of arrays in use.
  int iNLists;

  /// Basically a synonym for iMax.
  int iTotalSize;

  /// Disallow operator=
  VAType& operator=(const VAType& VA);

public:
  /// Destructor
  ~VAType();

  /// Default constructor
  VAType(const int iSizeInUse = 0);

  /// Copy constructor
  VAType(const VAType& VA);

  /// Resets to zero data accessible, though nothing is de-allocated.
  void vClear() {iN = 0;}

  /// Returns the number of entries in use.
  int iSize() const {return iN;}

  /// Returns the number of entries currently allocated.
  int iMaxSize() const {return iMax;}

  /// Allocates/de-allocates so that iNS < max size < 2*iNS.
  void vResize(const int iNS);
public:
  /// Resizes data, and sets amount of data in use to match requested size.
  void vSetup(const int iNewSize);

  /// Return an unused entry from the pool
  Type* pTNewEntry();

  /// Return an entry by index
  Type* pTEntry(const int i) const;

  /// Return the first entry 
  Type* pTFirst() const;

  /// Return the last entry
  Type* pTLast() const;

  /// Return the entry after this one
  Type* pTNext(Type* const pTCurr) const;

  /// Return the entry before this one
  Type* pTPrev(Type* const pTCurr) const;

  /// Checks whether the argument points to an entry in the container
  bool qValid(const Type* const pT) const;

private:
  /// Checks whether the argument is a valid entry index
  bool qValid(const int i) const;
};

// Implementation is a bit of a hack; might be better to have them all
// inlined. 
#if defined(VAImplementation)
VAType::~VAType()
{
  for (int i = 0; i < iNLists; i ++) {
    assert(apTData[i] != NULL);
    delete [] apTData[i];
  }
  iNLists = 0;
}

VAType::VAType(const int iSizeInUse) :
  iN(iSizeInUse), iMax(max(2048, iSizeInUse)), iNLists(1)
{
  assert(iSizeInUse >= 0);
  for (int ii = 0; ii < iMaxLists; ii++) {
    aiMax[ii] = 0;
    apTData[ii] = NULL;
  }
  aiMax[0] = iMax;
  iNLists = 1;
  apTData[0] = new Type[iMax];
  iTotalSize = iMax;
}

VAType::VAType(const VAType& VA) :
  iN(VA.iN), iMax(VA.iMax), iNLists(VA.iNLists)
{
  assert(VA.iN >= 0);
  assert(VA.iMax > 0);
  for (int ii = 0; ii < iMaxLists; ii++) {
    aiMax[ii] = 0;
    apTData[ii] = NULL;
  }
  int iSum = 0;
  for (int ii = 0; ii < iNLists; ii++) {
    assert(VA.aiMax[ii] >= 0);
    assert(VA.apTData[ii] != NULL);
    aiMax[ii] = VA.aiMax[ii];
    apTData[ii] = new Type[aiMax[ii]];
    for (int i = 0; (i < aiMax[ii]) && (iSum+i < iN); i++)
      apTData[ii][i] = VA.apTData[ii][i];
    iSum += aiMax[ii];
  }
  iTotalSize = iSum;
  //  assert(iSum == iMax);
}

void VAType::vResize(const int iNewSize) {
  if (iNewSize == iTotalSize) return;
  else if (iNewSize > iTotalSize) {
    while (iNewSize > 2 * iMax && iNLists < iMaxLists) {
      apTData[iNLists] = new Type[iMax];
      aiMax[iNLists] = iMax;
      iTotalSize += iMax;
      iMax *= 2;
      iNLists ++;
    }
    assert(iMax*2 >= iNewSize && iMax < iNewSize);
    // Create one last list
    int iLastSize = iMax;
    apTData[iNLists] = new Type[iLastSize];
    aiMax[iNLists] = iLastSize;
    iTotalSize += iLastSize;
    iMax *= 2; // This way, in case you ever need to go on, the next
	       // block will still be bigger.
    iNLists++;
    assert(iMax >= iNewSize);
  }
  else {
    assert(iNewSize <= iTotalSize);
    while (iTotalSize - aiMax[iNLists - 1] >= iNewSize && iNLists > 1) {
      iNLists --;
      delete [] apTData[iNLists];
      iMax -= aiMax[iNLists];
      iTotalSize -= aiMax[iNLists];
      aiMax[iNLists] = 0;
      apTData[iNLists] = NULL;
    }
  }
}

void VAType::vSetup(const int iNewSize)
{
  vResize(iNewSize);
  // This line got commented out somewhere along the line in the branch,
  // but not in the trunk.  It seems to be necessary for purge to work
  // properly; we'll see what problems it might cause...
  iN = iNewSize;
}

Type* VAType::pTNewEntry()
{
  if (iN == iTotalSize) vResize(iTotalSize+1);
  iN++;
  return (pTEntry(iN-1));
}

Type* VAType::pTEntry(const int i) const
{
  assert(qValid(i));
  int iList = 0, iSum = 0;
  while (i >= (iSum += aiMax[iList]) && iList < iNLists) iList++;
  assert(iList < iNLists);
  iSum -= aiMax[iList];
  assert(iSum <= i && iSum + aiMax[iList] > i);
  return(apTData[iList] + (i - iSum));
}

Type* VAType::pTFirst() const
{
  assert(iN >= 0);
  if (iN == 0) return (0);
  else         return(&(apTData[0][0]));
}

Type* VAType::pTLast() const
{
  assert(iN >= 0);
  if (iN == 0) return (0);
  else         return(pTEntry(iN-1));
}

Type* VAType::pTNext(Type* const pTCurr) const
{
  assert(qValid(const_cast<const Type*>(pTCurr)));
  int iList = 0, iSum = 0;
  while (! ((pTCurr >= apTData[iList]) &&
	    (pTCurr <  apTData[iList] + aiMax[iList])) &&
	 iList < iNLists) iSum += aiMax[iList++];
  assert(iList < iNLists);
  assert(pTCurr >= apTData[iList]);
  assert(pTCurr <  apTData[iList] + aiMax[iList]);
  assert((reinterpret_cast<unsigned long>(pTCurr) 
	  - reinterpret_cast<unsigned long>(apTData[iList]))
	 % sizeof(Type) == 0);
  // This seems to be wrong.  iSum -= aiMax[iList];
  if (pTCurr == pTLast()
      ||
      (pTCurr - apTData[iList] == aiMax[iList] - 1
       && iList == iNLists - 1) )
    return 0;
  else if (pTCurr - apTData[iList] == aiMax[iList] - 1)
    return apTData[iList+1];
  else
    return pTCurr+1;
}

Type* VAType::pTPrev(Type* const pTCurr) const
{
  assert(qValid(const_cast<const Type*>(pTCurr)));
  int iList = 0, iSum = 0;
  while (! ((pTCurr >= apTData[iList]) &&
	    (pTCurr <  apTData[iList] + aiMax[iList])) &&
	 iList < iNLists) iSum += aiMax[iList++];
  assert(iList < iNLists);
  assert(pTCurr >= apTData[iList]);
  assert(pTCurr <  apTData[iList] + aiMax[iList]);
  assert((reinterpret_cast<unsigned long>(pTCurr)
	  - reinterpret_cast<unsigned long>(apTData[iList]))
	 % sizeof(Type) == 0);
  // This seems to be wrong.  iSum -= aiMax[iList];
  if (iList == 0 && pTCurr - apTData[iList] == 0)
    return 0;
  else if (pTCurr - apTData[iList] == 0)
    return apTData[iList-1] + aiMax[iList-1] - 1;
  else
    return pTCurr-1;
}

bool VAType::qValid(const int i) const
{
  return ((i >= 0) && (i < iN));
}

bool VAType::qValid(const Type* const pT) const
{
  int iList = 0, iSum = 0;
  while (! ((pT >= apTData[iList]) &&
	    (pT <  apTData[iList] + aiMax[iList])) &&
	 iList < iNLists) {
    iSum += aiMax[iList];
    iList++;
  }
  if (iList == iNLists) return false;
  else {
    assert(iList < iNLists);
    assert(pT >= apTData[iList]);
    assert(pT <  apTData[iList] + aiMax[iList]);
    // This next one must always be true, provided that pT is really a
    // pointer to Type.
    assert((reinterpret_cast<unsigned long>(pT) 
	    - reinterpret_cast<unsigned long>(apTData[iList]))
	   % sizeof(Type) == 0);
    return true;
  }
}
#endif 

#undef Type
#undef VAType
