// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Cell
#define RI_Cell 1

#include "RI_config.h"
#include "RI_Entity.h"
#include "RI_Classes.h"

/**\brief class for all highest-dimensional entities in the mesh.
 *
 * The reference implementation has finite-volume roots, so it is
 * organized so that highest-dimensional entities are called
 * cells. These correspond to iMesh regions for 3D meshes and iMesh
 * faces for 2D meshes.
 *
 * Functions inherited from the Entity base class are not documented
 * again in Cell or its derivatives.
 */
class Cell : public Entity {
public:
  /// An enumeration of all possible cell types in RefImpl.
  enum eCellType {eTriCell = 0, eQuadCell, eTet, ePyr, ePrism, eHex};

protected:
  /// Storage for the cell type
  unsigned int uiType:3;

  /// A flag to indicate whether a cell has been deleted from the mesh.
  /** This flag is required because RefImpl defers garbage collection,
   *  so an entity can be deleted but still exist in the database.
   */
  bool qDel:1;

protected:
  /// Copy construction disallowed.
  Cell(const Cell&) : Entity(), ppFFaces(NULL) {
    assert(0);
  }

  /// Storage for cell-to-face connectivity data.
  /** Note that cell-to-vert connectivity data is computed as needed. */
  Face** ppFFaces;

protected:
  /// The constructor used by all derived cell types.
  Cell(const int iNFaces, const int iNVerts, Face** const ppFIn,
       const eCellType eTypeIn);

public:
  /// Destructor
  virtual ~Cell();

  /// Copies cell data from one Cell object to another.
  Cell& operator=(const Cell& C);

  /// Ensure a sane initial state for face data
  void vResetAllData();

  /// A complete validity check, including adjacency data.
  virtual int iFullCheck() const;

  /// Set a default state for internal flags.
  void vSetDefaultFlags() {
    // Type is not reset; this is set once and for all by the
    // derived-class constructor.
    qDel = false;
  }

  /// Copy all internal flags from one cell to another.
  void vCopyAllFlags(const Cell &C) {
    uiType = C.uiType;
    qDel = C.qDel;
  }

  /// Return the type of the cell object.
  int eType() const {assert(qValid()); return uiType;}

  /// True iff this cell has been marked as deleted.
  bool qDeleted() const {assert(qValid()); return qDel;}

  // The following are inherited from Entity.
  void vMarkDeleted() {qDel = true;}
  virtual int iNumFaces() const = 0;
  virtual int iNumVerts() const = 0;
  int iNumCells() const {return 0;}
  virtual const Vert* pVVert(const int i) const = 0;
  Vert* pVVert(const int i) {return Entity::pVVert(i);}
  const Face* pFFace(const int i) const;
  Face* pFFace(const int i);
  void vAllFaceHandles(RefImpl_Entity* aHandles[]) const;

  const Cell* pCCell(const int i) const {
    assert(i == 0);
    return NULL;
  }

  void vAllCellHandles(RefImpl_Entity* []) const {/* Do nothing */}

  /// True iff this cell has the given face as part of its closure.
  bool qHasFace(const Face* pF) const;

  /// True iff this cell has the given vert as part of its closure.
  bool qHasVert(const Vert* pV) const;

  /// True iff the cell has a proper closure.
  virtual bool qIsClosed() const = 0;

  /// Replaces one face for another in the cell's connectivity info.
  /** Used only in updating the connectivity of adjacent cells when
   *  copying face data (op=).
   */      
  void vReplaceFace(const Face* const pFOld, Face* const pFNew);

  /// Remove the given face from a cell's connectivity info.
  /** Used only in updating the connectivity of adjacent cells when
   *  copying face data (op=).
   */      
  void vRemoveFace(const Face* const pFOld);

  /// Set faces from the array of data; number of faces is known internally.
  void vAssign(Face* const apF[]);

  /// Set faces from a list of face arguments.
  /** Must allow as few as three valid faces. It is an error to provide the
   *  wrong number of faces as arguments. */
  void vAssign(Face* const pF0,
	       Face* const pF1,
	       Face* const pF2,
	       Face* const pF3 = pFInvalidFace,
	       Face* const pF4 = pFInvalidFace,
	       Face* const pF5 = pFInvalidFace);

  /// Reorder faces if necessary to get them in canonical order.
  virtual void vCanonicalizeFaceOrder() {}
};

/// A class for tetrahedral cells
class TetCell : public Cell {
  /// Copy construction disallowed.
  TetCell(const TetCell& TC) : Cell(TC) {assert(0);}
public:
  /// Constructor
  TetCell(Face** const ppFIn = 0) : Cell(4, 4, ppFIn, eTet) {}

  // From Entity
  int iNumFaces() const {return 4;}
  int iNumVerts() const {return 4;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  int eEntType() const {return iBase_REGION;}
  int eEntTopology() const {return iMesh_TETRAHEDRON;}
  virtual const Vert* pVVert(const int i) const;

  // The non-const version of vertex retrieval.
  Vert* pVVert(const int i) {return Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;

  /// Return the (unique) vertex opposite a given face.
  Vert* pVVertOpposite(const Face* const pFFace) const;
};

/// A class for triangular cells
class TriCell : public Cell {
  /// Copy construction disallowed.
  TriCell(const TriCell& TC) : Cell(TC) {assert(0);}
public:
  ///
  TriCell(Face** const ppFIn = 0) : Cell(3, 3, ppFIn, eTriCell) {}

  // Inherited from Entity.
  int iNumFaces() const {return 3;}
  int iNumVerts() const {return 3;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  int eEntType() const {return iBase_FACE;}
  int eEntTopology() const {return iMesh_TRIANGLE;}
  virtual const Vert* pVVert(const int i) const;

  /// The non-const version of vertex retrieval.
  Vert* pVVert(const int i) {return this->Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;

};

/// A class for quadrilateral cells
class QuadCell : public Cell {
  /// Copy construction disallowed.
  QuadCell(const QuadCell& QC) : Cell(QC) {assert(0);}
public:
  /// Constructor
  QuadCell(Face** const ppFIn = 0) : Cell(4, 4, ppFIn, eQuadCell) {}

  // From Entity
  int iNumFaces() const {return 4;}
  int iNumVerts() const {return 4;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  int eEntType() const {return iBase_FACE;}
  int eEntTopology() const {return iMesh_QUADRILATERAL;}
  virtual const Vert* pVVert(const int i) const;

  /// The non-const version of vertex retrieval.
  Vert* pVVert(const int i) {return this->Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;

  // Get the faces into cyclic order.
  /** This is actually the only cell type that requires anything to be done. */
  virtual void vCanonicalizeFaceOrder();
};

/// A class for pyramid cells.
class PyrCell : public Cell {
  /// Copy construction disallowed.
  PyrCell(const PyrCell& PCIn) : Cell(PCIn) {assert(0);}
public:
  /// Constructor
  PyrCell(Face** const ppFIn = 0) : Cell(5, 5, ppFIn, ePyr) {}
  
  // From Entity
  int iNumFaces() const {return 5;}
  int iNumVerts() const {return 5;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  int eEntType() const {return iBase_REGION;}
  int eEntTopology() const {return iMesh_PYRAMID;}
  virtual const Vert* pVVert(const int i) const;
  virtual Vert* pVVert(const int i) {return this->Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;
};

/// A class for prismatic cells
class PrismCell : public Cell {
  /// Copy construction disallowed.
  PrismCell(const PrismCell& PCIn) : Cell(PCIn) {assert(0);}
public:
  /// Constructor
  PrismCell(Face** const ppFIn = 0) : Cell(5, 6, ppFIn, ePrism) {}

  // From Entity
  int iNumFaces() const {return 5;}
  int iNumVerts() const {return 6;}
  int eEntType() const {return iBase_REGION;}
  int eEntTopology() const {return iMesh_PRISM;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  virtual const Vert* pVVert(const int i) const;
  virtual Vert* pVVert(const int i) {return this->Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;
};

/// A class for hexahedral cells
class HexCell : public Cell {
  /// Copy construction disallowed.
  HexCell(const HexCell& HC) : Cell(HC) {assert(0);}
public:
  /// Constructor
  HexCell(Face** const ppFIn = 0) : Cell(6, 8, ppFIn, eHex) {}

  // From Entity
  int iNumFaces() const {return 6;}
  int iNumVerts() const {return 8;}
  int eEntType() const {return iBase_REGION;}
  int eEntTopology() const {return iMesh_HEXAHEDRON;}
  void vAllVertHandles(RefImpl_Entity* aHandles[]) const;
  virtual const Vert* pVVert(const int i) const;
  virtual Vert* pVVert(const int i) {return this->Entity::pVVert(i);}

  // From Cell
  bool qIsClosed() const;
};

/// Find the face in common to two cells; return NULL is there is none.
Face* pFCommonFace(Cell* const pC0, Cell* const pC1);

#endif
