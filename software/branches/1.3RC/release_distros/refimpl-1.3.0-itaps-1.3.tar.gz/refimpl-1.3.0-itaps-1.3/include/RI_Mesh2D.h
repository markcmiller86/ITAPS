// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Mesh2D
#define RI_Mesh2D 1

#include "RI_config.h"
#include "RI_Mesh.h" 
#include "RI_VarArray2D.h"
#include <map>

/**\brief The 2D specialization of the Mesh base class.
 *
 * Functions inherited from Mesh will not be documented again here.
 */
class Mesh2D : public Mesh {
private:
  /// Variable size array containing faces in the 2D mesh
  VAEdgeFace      VAEdgeF;      

  /// Variable sized array containing triangular cells in the 2D mesh
  VATriCell       VATri; 

  /// Variable sized array containing quadrilateral cells in the 2D mesh
  VAQuadCell      VAQuad;
  
  /// The copy constructor is disallowed
  Mesh2D(const Mesh2D& ) : Mesh() {assert(0);}
  
  /// operator= is also disallowed
  Mesh2D& operator=(const Mesh2D&) {assert(0); return *this;}

public:
  /// Default constructor.
  Mesh2D();

  /// Destructor.
  ~Mesh2D() { }

  /// Read 2D mesh data from a file.
  void readMeshFile(const char strFileName[]);

  //////////////////////////////////////////////////////////////////////
  /// Functions that directly manipulate or query the mesh database. ///
  //////////////////////////////////////////////////////////////////////
  
  // Inherited from Mesh
  virtual int iNumFaces() const {return VAEdgeF.iSize();}
  virtual Face* pFFace(const int i) const;
  virtual int iNumCells() const {return iNumTriCells() + iNumQuadCells();}
  virtual Cell* pCCell(const int i) const;

  /// Return the number of triangular cells.
  int iNumTriCells() const {return VATri.iSize();}

  /// Return the number of quadrilateral cells.
  int iNumQuadCells() const {return VAQuad.iSize();}

  // Inherited from Mesh
  virtual bool qIsValidEnt(void* pvEnt) const;
  virtual eMeshType eType() const {return Mesh::eMesh2D;}

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////

  // The generic, ITAPS-style calls, inherited from Mesh
  Vert* createVert(const double dX, const double dY, const double dZ = 0);
  bool deleteVert(Vert * const pV);
  bool deleteFace(Face * const pF);
  bool deleteCell(Cell * const pC);

  /// Create an edge face from two vertices.
  Face* createFace(Vert * const pV0, Vert * const pV1);

  /// Create a tri cell from three (edge) faces.
  Cell* createTriCell(Face * const pF0, Face * const pF1, Face * const pF2);

  /// Create a quad cell from four (edge) faces.
  Cell* createQuadCell(Face * const pF0, Face * const pF1, Face * const pF2,
		       Face * const pF3);

  /// Create a tri cell from three vertices.
  Cell* createTriCell(Vert * const pV0, Vert * const pV1, Vert * const pV2);

  /// Create a quad cell from four vertices.
  Cell* createQuadCell(Vert * const pV0, Vert * const pV1, Vert * const pV2,
		       Vert * const pV3);
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  
  // Inherited from Mesh
  virtual void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL);
  virtual void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  virtual void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  virtual void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL);

  /// Return an available, unused face from the data pool.
  Face*    pFNewFace(const int iNV = 2);

  /**\brief Return an available, unused cell from the data pool.
   *
   * If the requested number of faces is 3, it's a triangle.  If 4, it's
   * a quad.  Any other value is an error.
   */
  Cell*    pCNewCell(const int iNF = 3);
};

#endif
