// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <queue>

#include "RI_config.h"
#include "RI_Mesh.h"
#include "RI_Vertex.h"
#include "RI_Face.h"

void Mesh::vSetVertFaceNeighbors()
{
  vMessage(2, "Setting all vert-face connectivity...");
  vClearVertFaceNeighbors();
  // Have to clear vertex hints -before- checking validity, else bad
  // hints will cause an irrelevant assertion.
  //  assert(qValid());

  int i;
  for (i = 0; i < iNumFaces(); i++) {
    Face* pF = pFFace(i);
    if (pF->qDeleted()) continue;
    printf("%3d %p\n", i, pF);
    for (int ii = pF->iNumVerts() - 1; ii >= 0; ii --) {
      Vert* pV = pF->pVVert(ii);
      if (pV != pVInvalidVert) {
	pV->vAddFace(pF);
      }
    }
  }
  vMessage(2, "done\n");
}

void Mesh::vClearVertFaceNeighbors()
{
  int i;
  for (i = 0; i < iNumVerts(); i++)
    pVVert(i)->vClearFaceConnectivity();
}

void vNeighborhood(const Vert* const pVert, std::set<Cell*>& spCInc,
		   std::set<Vert*>& spVNeigh, std::set<Face*>* pspFNearby)
{
#ifdef OLD_NEIGHBORHOOD
  Face *pF = pVert->pFHintFace();
  assert(pF->qValid() && pF->qHasVert(pVert));

  spCInc.clear();
  spVNeigh.clear();
  if (pspFNearby) pspFNearby->clear();

  Cell *pC = pF->pCCellLeft();
  if (pC == pCInvalidCell) {
    pC = pF->pCCellOpposite(pC);
  }
  spCInc.insert(pC);
  std::queue<Cell*> qpC;
  qpC.push(pC);

  // Keep adding cells incident on pVert until they're all there.
  // spCInc.iLength() increases as cells are added, but the process
  // is guaranteed to exit.  In the process, create a list of pointers
  // to all the neighboring verts of pVert and all the faces incident on
  // pVert. The latter list will have to be trimmed later by removing faces
  // opposite to pVert.
  while (!qpC.empty()) {
    pC = qpC.front();
    qpC.pop();
    // Add the parts of this cell to the appropriate lists.
    for (int iV = pC->iNumVerts() - 1; iV >= 0; iV--) {
      Vert *pVAdd = pC->pVVert(iV);
      if (!pVAdd->qDeleted())
	spVNeigh.insert(pVAdd);
    }

    for (int iF = pC->iNumFaces() - 1; iF >= 0; iF--) {
      pF = pC->pFFace(iF);
      if (pspFNearby) {
	pspFNearby->insert(pF);
      }
      if (pF->qHasVert(pVert)) {
	// This Face has the right vertex, so the cell behind it does, too.
	Cell *pCCand = pF->pCCellOpposite(pC);
	if (pCCand->qValid() && spCInc.count(pCCand) == 0) {
	  assert(pCCand->qHasVert(pVert));
	  // The insertion is safe anyway, but the queue push is not!
	  spCInc.insert(pCCand);
	  qpC.push(pCCand);
	}
      }
    } // Done checking all faces for this cell
  } // Done checking all cells

  // Clean up vertex list
  spVNeigh.erase(const_cast<Vert*>(pVert));

#else
  // New neighborhood calc, enabled by storing pointers for all the
  // faces for each vertex.

  spCInc.clear();
  spVNeigh.clear();
  if (pspFNearby) pspFNearby->clear();

  int iNFaces = pVert->iNumFaces();

  for (int i = 0; i < iNFaces; i++) {
    Face *pF = const_cast<Vert*>(pVert)->pFFace(i);

    spCInc.insert(pF->pCCell(0));
    if (pF->iNumCells() == 2) {
      spCInc.insert(pF->pCCell(1));
    }
  }

  std::set<Cell*>::iterator iter = spCInc.begin(), iterEnd = spCInc.end();
  for ( ; iter != iterEnd ; iter++) {
    Cell* pC = *iter;
    if (pspFNearby) {
      for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
	Face *pF = pC->pFFace(i);
	pspFNearby->insert(pF);
      }
    }
    for (int i = pC->iNumVerts() - 1; i >= 0; i--) {
      Vert *pV = pC->pVVert(i);
      spVNeigh.insert(pV);
    }
  }

  // Clean up vertex list
  spVNeigh.erase(const_cast<Vert*>(pVert));
#endif
}

