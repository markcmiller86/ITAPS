// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include "RI_misc.h"
#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Vertex.h"

const Vert *TriCell::
pVVert (const int i)
  const {
  assert (iFullCheck ());
  assert (i >= 0 && i <= 2); // Vertex index out of range
  // New implementation aimed at speeding up this routine, since it was a
  // surprisingly large fraction of CPU time for ITAPS-based swapping in 2D,
  // like around 10% of the total before the switch, shockingly.
  if (i == 2) {
    Vert *pV0 = ppFFaces[0]->pVVert(0);
    Vert *pV1 = ppFFaces[0]->pVVert(1);
    Vert *pV2 = ppFFaces[1]->pVVert(0);
    if (pV2 == pV0 || pV2 == pV1)
      return ppFFaces[1]->pVVert(1);
    else
      return pV2;
  }
  else {
    return ((ppFFaces[0]->pCCellLeft() == static_cast<const Cell*>(this)) ?
	    ppFFaces[0]->pVVert(i) : ppFFaces[0]->pVVert(1-i));
  }
  // The following is the original code, retained because it's much
  // clearer in intent than the modified version.
//   const Face *const pFBase = ppFFaces[0];
//   assert (pFBase != NULL);
//   const Vert *pVRetVal;
//   switch (i)
//     {
//     case 0:
//       if (pFBase->pCCellLeft () == this)
// 	pVRetVal = (pFBase->pVVert (0));
//       else
// 	pVRetVal = (pFBase->pVVert (1));
//       break;
//     case 1:
//       if (pFBase->pCCellLeft () == this)
// 	pVRetVal = (pFBase->pVVert (1));
//       else
// 	pVRetVal = (pFBase->pVVert (0));
//       break;
//     case 2:
//       pVRetVal = (pVVertOpposite (pFBase));
//       break;
//     default:
//       assert2 (0, "Invalid vertex index");
//       pVRetVal = (pVInvalidVert);
//       break;
//     }
//   return (pVRetVal);
}

void TriCell::vAllVertHandles(RefImpl_Entity* aHandles[]) const
{
  assert (iFullCheck ());
  Vert *pV0 = ppFFaces[0]->pVVert(0);
  Vert *pV1 = ppFFaces[0]->pVVert(1);
  Vert *pV2 = ppFFaces[1]->pVVert(0);
  if (ppFFaces[0]->pCCellLeft() == static_cast<const Cell*>(this)) {
    aHandles[0] = pV0;
    aHandles[1] = pV1;
  }
  else {
    aHandles[0] = pV1;
    aHandles[1] = pV0;
  }
  if (pV2 == pV0 || pV2 == pV1)
    aHandles[2] = ppFFaces[1]->pVVert(1);
  else
    aHandles[2] = pV2;
}


bool TriCell::
qIsClosed ()
  const {
  // Check to be sure that the tet has only four vertices and that each
  // appears in exactly three faces.
  const Vert *apV[] =
  {pVInvalidVert, pVInvalidVert, pVInvalidVert};
  // If the cell is deleted, it doesn't matter whether it's closed or
  // not. 
  if (qDeleted ())
    return true;
  int iFaceCount[3];
  for (int iF = 0; iF < 3; iF++)
    {
      const Face *pF = pFFace (iF);
      assert (pF->qValid () && !pF->qDeleted ());
      for (int iV = 0; iV < 2; iV++) {
	const Vert *pV = pF->pVVert (iV);
	assert (pV->qValid () && !pV->qDeleted ());
	int ii;
	for (ii = 0; ii < 3; ii++) {
	  if (apV[ii] == pVInvalidVert) {
	    apV[ii] = pV;
	    iFaceCount[ii] = 1;
	    break;
	  }
	  else if (apV[ii] == pV) {
	    iFaceCount[ii]++;
	    break;
	  }
	}
	if (ii == 3)
	  return (false);
      }				// Done with this vertex
      
    }				// Done with this face
  
  if (iFaceCount[0] != 2 || iFaceCount[1] != 2 ||
      iFaceCount[2] != 2)
    return (false);
  return (true);
}


