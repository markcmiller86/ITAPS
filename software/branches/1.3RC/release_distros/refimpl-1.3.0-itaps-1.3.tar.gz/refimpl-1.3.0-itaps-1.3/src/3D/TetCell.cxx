// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include <stdlib.h>

#include "RI_Cell.h"
#include "RI_misc.h"
#include "RI_Face.h"
#include "RI_Vertex.h"

const Vert* TetCell::pVVert(const int i) const
{
  assert(iFullCheck());
  assert(i >= 0 && i <= 3); // Vertex index out of range
  const Face* const pFBase = ppFFaces[0];
  if (i == 0) return (pFBase->pVVert(0));
  if (i == 3) return (pVVertOpposite(pFBase));
  // For verts 1 and 2, return value depends on face orientation.
  if (pFBase->pCCellRight() == static_cast<const Cell*>(this))
    return pFBase->pVVert(i);
  else
    return pFBase->pVVert(3-i);
}

void TetCell::vAllVertHandles(RefImpl_Entity* aHandles[]) const
{
  assert(iFullCheck());
  const Face* const pFBase = ppFFaces[0];
  pFBase->vAllVertHandles(aHandles);
  // For verts 1 and 2, return value depends on face orientation, so
  // switch if needed.
  if (pFBase->pCCellRight() != static_cast<const Cell*>(this)) {
    RefImpl_Entity* pvTmp = aHandles[1];
    aHandles[1] = aHandles[2];
    aHandles[2] = pvTmp;
  }
  aHandles[3] = pVVertOpposite(pFBase);
}

bool TetCell::qIsClosed() const
{
  // Check to be sure that the tet has only four vertices and that each
  // appears in exactly three faces.
  const Vert *apV[] = {pVInvalidVert, pVInvalidVert,
		       pVInvalidVert, pVInvalidVert};
  // If the cell is deleted, it doesn't matter whether it's closed or
  // not. 
  if (qDeleted()) return true;
  int iFaceCount[4];
  for (int iF = 0; iF < 4; iF++) {
    const Face *pF = pFFace(iF);
    assert(pF->qValid() && !pF->qDeleted());
    for (int iV = 0; iV < 3; iV++) {
      const Vert *pV = pF->pVVert(iV);
      assert(pV->qValid() && !pV->qDeleted());
      int ii;
      for (ii = 0; ii < 4; ii++) {
	if (apV[ii] == pVInvalidVert) {
	  apV[ii] = pV;
	  iFaceCount[ii] = 1;
	  break;
	}
	else if (apV[ii] == pV) {
	  iFaceCount[ii]++;
	  break;
	}
      }
      if (ii == 4)
	return (false);
    } // Done with this vertex
  } // Done with this face
  if (iFaceCount[0] != 3 || iFaceCount[1] != 3 ||
      iFaceCount[2] != 3 || iFaceCount[3] != 3)
    return (false);
  return (true);
}

Vert* TetCell::pVVertOpposite(const Face* const pFFaceIn) const
{
  assert(iFullCheck());
  assert(pFFaceIn->qValid());

  int iNVerts = iNumVerts();
  Face* pF = (ppFFaces[0] == pFFaceIn) ? ppFFaces[1] : ppFFaces[0];
  RefImpl_Entity* apV[3];
  pFFaceIn->vAllVertHandles(apV);
  for (int i = 0; i < iNVerts - 1; i++) {
    Vert *pVCand = pF->pVVert(i);
    bool qFoundMatch = false;
    for (int j = 0; j < iNVerts - 1 && !qFoundMatch; j++) {
      qFoundMatch = (apV[j] == pVCand);
    }
    if (!qFoundMatch) return pVCand;
  }
  assert(0); // Strange. All faces of a simplex are incident on a single vert
  return(pVInvalidVert);
}


