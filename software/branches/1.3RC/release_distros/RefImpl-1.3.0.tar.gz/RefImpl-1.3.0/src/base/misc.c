// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>

#ifdef IRIX6
#include <values.h>
#endif

#define misc_implementation
#include "RI_misc.h"
#undef misc_implementation

/* These levels are #define'd in config.h */
int iMessageStdoutLevel = MESSAGE_LEVEL_STDOUT;

void vMessage(const int i, const char *acFormat, ...)
{
  va_list VArgList1;
  va_start(VArgList1, acFormat);

  if (i <= iMessageStdoutLevel) {
    vprintf(acFormat, VArgList1);
    fflush(stdout);
  }
  va_end(VArgList1);
}

