// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include "RI_misc.h"
#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Vertex.h"

const Vert* HexCell::pVVert(const int i) const
{
  assert(iFullCheck());
  assert(i >= 0 && i <= 7);
  switch (i) {
  case 0:
    return pVCommonVert(ppFFaces[0], ppFFaces[1], ppFFaces[4]);
  case 1:
    return pVCommonVert(ppFFaces[0], ppFFaces[2], ppFFaces[1]);
  case 2:
    return pVCommonVert(ppFFaces[0], ppFFaces[3], ppFFaces[2]);
  case 3:
    return pVCommonVert(ppFFaces[0], ppFFaces[4], ppFFaces[3]);
  case 4:
    return pVCommonVert(ppFFaces[5], ppFFaces[1], ppFFaces[4]);
  case 5:
    return pVCommonVert(ppFFaces[5], ppFFaces[2], ppFFaces[1]);
  case 6:
    return pVCommonVert(ppFFaces[5], ppFFaces[3], ppFFaces[2]);
  case 7:
    return pVCommonVert(ppFFaces[5], ppFFaces[4], ppFFaces[3]);
  default:
    // Should never get here in debug mode.
    assert(0);
    return pVInvalidVert;
  }
}

void HexCell::vAllVertHandles(RefImpl_Entity* aHandles[]) const
{
  assert(iFullCheck());
  for (int i = 0; i < 8; i++) {
    aHandles[i] = const_cast<Vert*>(pVVert(i));
  }
}

bool HexCell::qIsClosed() const
{
  assert(0); // No closure check for hexes
  return false;
}
