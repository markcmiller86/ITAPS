// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

//#include <math.h>
#include <stdlib.h>
#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Vertex.h"
#include "RI_VolMesh.h"

//#include <algorithm>
#include <map>

using std::map;

// This is here so that configure can find the library.
extern "C"
{
  void vRefImpl_3D_Lib (void) {}
}

VolMesh::VolMesh()
  : Mesh (), VATriF(), VAQuadF(),
     VATet(), VAPyr(), VAPrism(), VAHex()
    {}

VolMesh::~VolMesh()
{
  VATriF.~VATriFace();
  VAQuadF.~VAQuadFace();
  VATet.~VATetCell();
  VAPyr.~VAPyrCell();
  VAPrism.~VAPrismCell();
  VAHex.~VAHexCell();
}

//@ Retrieval of entities by index
Face*  VolMesh::pFFace(const int i) const
{
  assert(i >= 0 && i < iNumFaces());
  if (i < iNumTriFaces())
    return VATriF.pTEntry(i);
  else
    return VAQuadF.pTEntry(i - iNumTriFaces());
}


Cell*  VolMesh::pCCell(const int i) const
{
  assert(i >= 0 && i < iNumCells());
  int iNTet = iNumTetCells();

  if (i < iNTet)
    return VATet.pTEntry(i);

  int iNTPyr = iNTet + iNumPyrCells();
  if (i < iNTPyr)
    return VAPyr.pTEntry(i - iNTet);

  int iNTPPrism = iNTPyr + iNumPrismCells();
  if (i < iNTPPrism)
    return VAPrism.pTEntry(i - iNTPyr);

  else
    return VAHex.pTEntry(i - iNTPPrism);
}

bool VolMesh::
qIsValidEnt (void* pvEnt) const
  // Determines if the memory location pointed to by the pointer
  // given is valid (within the range) for any of the entity types
  // for this mesh
{
  return (VAVerts.qValid( static_cast<Vert*>(pvEnt) )      ||
	  VATriF.qValid( static_cast<TriFace*>(pvEnt) )    ||
	  VATet.qValid( static_cast<TetCell*>(pvEnt) )     ||
	  VAQuadF.qValid( static_cast<QuadFace*>(pvEnt) )  ||
	  VAPyr.qValid( static_cast<PyrCell*>(pvEnt) )     ||
	  VAPrism.qValid( static_cast<PrismCell*>(pvEnt) ) ||
	  VAHex.qValid( static_cast<HexCell*>(pvEnt) )     );
}

//@ Create new entities
Face* VolMesh::pFNewFace(const int iNV)
{
  assert(iNV == 3 || iNV == 4);
  switch (iNV) {
  case 3:
    {
      TriFace *pTF = VATriF.pTNewEntry();
      pTF->vSetDefaultFlags();
      return pTF;
    }
  case 4:
    {
      QuadFace *pQF = VAQuadF.pTNewEntry();
      pQF->vSetDefaultFlags();
      return pQF;
    }
  default:
    assert(0);
    return (pFInvalidFace);
  }
}

Cell* VolMesh::pCNewCell(const int iNF, const int iNV)
{
  assert((iNF == 4 && iNV == 4) || // Tetrahedron
	 (iNF == 5 && (iNV == 5 || iNV== 6)) || // Pyramid and prism
	 (iNF == 6 && iNV == 8)); // Hexahedron
  switch (iNV) {
  case 4:
    {
      TetCell *pTet = VATet.pTNewEntry();
      pTet->vSetDefaultFlags();
      assert(pTet->eType() == Cell::eTet);
      return pTet;
    }
  case 5:
    {
      PyrCell *pPyr = VAPyr.pTNewEntry();
      pPyr->vSetDefaultFlags();
      assert(pPyr->eType() == Cell::ePyr);
      return pPyr;
    }
  case 6:
    {
      PrismCell *pPrism = VAPrism.pTNewEntry();
      pPrism->vSetDefaultFlags();
      assert(pPrism->eType() == Cell::ePrism);
      return pPrism;
    }
  case 8:
    {
      HexCell *pHex = VAHex.pTNewEntry();
      pHex->vSetDefaultFlags();
      assert(pHex->eType() == Cell::eHex);
      return pHex;
    }
  default:
    assert(0);
    return (pCInvalidCell);
  }
}

//@ Weed out empty entries in the connectivity tables
void VolMesh::vPurgeFaces(map<Face*, Face*>* /*face_map*/)
  // Get rid of all unused faces in the connectivity table.
{
  if (iNumTriFaces() > 0) {
    TriFace *pTFFor  = VATriF.pTFirst();
    TriFace *pTFBack = VATriF.pTLast();
    
    int iNewSize = 0;
    assert(pTFFor != pTFBack);
    
    while (pTFFor != pTFBack) {
      while (pTFFor != pTFBack && !pTFFor->qDeleted()) {
	pTFFor = VATriF.pTNext(pTFFor);
	iNewSize++;
      }
      
      while (pTFBack != pTFFor && pTFBack->qDeleted())
	pTFBack = VATriF.pTPrev(pTFBack);
      
      if (pTFFor != pTFBack) {
	assert(pTFFor->qDeleted());
	iNewSize++;
	(*pTFFor) = (*pTFBack);
	pTFBack->vMarkDeleted();
	pTFFor = VATriF.pTNext(pTFFor);
      }
      else if (!pTFFor->qDeleted()) {
	// This case only arises if there are no deleted faces to be purged.
	iNewSize++;
      }
    } // Loop over all faces
    // This resets the number of entries in use to iNewSize.
    VATriF.vSetup(iNewSize);
  } // Done with tris
  
  if (iNumQuadFaces() > 0) {
    QuadFace *pQFFor  = VAQuadF.pTFirst();
    QuadFace *pQFBack = VAQuadF.pTLast();
    
    int iNewSize = 0;
    assert(pQFFor != pQFBack);
    
    while (pQFFor != pQFBack) {
      while (pQFFor != pQFBack && !pQFFor->qDeleted()) {
	pQFFor = VAQuadF.pTNext(pQFFor);
	iNewSize++;
      }
      
      while (pQFBack != pQFFor && pQFBack->qDeleted())
	pQFBack = VAQuadF.pTPrev(pQFBack);
      
      if (pQFFor != pQFBack) {
	assert(pQFFor->qDeleted());
	iNewSize++;
	(*pQFFor) = (*pQFBack);
	pQFBack->vMarkDeleted();
	pQFFor = VAQuadF.pTNext(pQFFor);
      }
      else if (!pQFFor->qDeleted()) {
	// This case only arises if there are no deleted faces to be purged.
	iNewSize++;
      }
    } // Loop over all faces
    // This resets the number of entries in use to iNewSize.
    VAQuadF.vSetup(iNewSize);
  } // Done with quads
    
}

void VolMesh::vPurgeCells(map<Cell*, Cell*>* cell_map)
  // Get rid of all unused cells in the connectivity table.
{
  // Purge tetrahedra
  {
    int iFor = 0, iBack = iNumTetCells() - 1;

    int iNewSize = 0;
    // The case of exactly one valid cell
    if ( (iFor == iBack) &&
	 pCCell(iFor)->qValid() && !pCCell(iFor)->qDeleted() ) {
      if(cell_map) cell_map->insert( std::make_pair(pCCell(iFor), pCCell(iFor)) );
      iNewSize = 1;
      iFor = 1; // Necessary because of an assertion later.      
    }

    while (iFor < iBack) {

      while (!pCCell(iFor)->qDeleted() && iFor < iBack) {
	if(cell_map) cell_map->insert( std::make_pair(pCCell(iFor), pCCell(iFor)) );
	iFor++;
	iNewSize++;
      }

      while (pCCell(iBack)->qDeleted() && iFor < iBack)
	iBack--;

      if (iFor != iBack) {
	Cell *pCFor = pCCell(iFor);
	Cell *pCBack = pCCell(iBack);

	assert(pCFor->qDeleted());
	assert(!pCBack->qDeleted());
	if(cell_map) cell_map->insert( std::make_pair(pCBack, pCFor) );
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted();
// #ifndef NDEBUG
//	for (int i = 0; i < pCFor->iNumFaces(); i++)
//	  assert(pCFor->pFFace(i)->iFullCheck());
// #endif
	iNewSize++;
	iFor++;
      }
      else if (!pCCell(iFor)->qDeleted()) {
	if(cell_map) cell_map->insert( std::make_pair(pCCell(iFor), pCCell(iFor)) );
	iNewSize++;
	iFor++;
      }

    }

    assert(iFor == iNewSize);
    // Reset the number of tet cells in use
    VATet.vSetup(iNewSize);
  } // Tetrahedron iteration

  // Purge pyramids
  {
    int iFor = iNumTetCells(), iBack = iFor + iNumPyrCells() - 1;

    int iNewSize = 0;
    // The case of exactly one valid cell
    if ((iFor == iBack) &&
	pCCell(iFor)->qValid() &&
	!pCCell(iFor)->qDeleted()) {
      iNewSize = 1;
      iFor = 1; // Necessary because of an assertion later.
    }

    while (iFor < iBack) {
      while (!pCCell(iFor)->qDeleted() && iFor < iBack){
	iFor++;
	iNewSize++;
      }

      while (pCCell(iBack)->qDeleted() && iFor < iBack)
	iBack--;

      if (iFor != iBack) {
	Cell *pCFor = pCCell(iFor);
	Cell *pCBack = pCCell(iBack);

	assert(pCFor->qDeleted());
	assert(!pCBack->qDeleted());
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted();
// #ifndef NDEBUG
//	for (int i = 0; i < pCFor->iNumFaces(); i++)
//	  assert(pCFor->pFFace(i)->iFullCheck());
// #endif
	iNewSize++;
	iFor++;
      }
      else if (!pCCell(iFor)->qDeleted()) {
	iNewSize++;
	iFor++;
      }
    }
    assert(iFor == iNewSize + iNumTetCells());
    // Reset the number of tet cells in use
    VAPyr.vSetup(iNewSize);
  } // Pyramid iteration

  // Purge prisms
  {
    int iFor = iNumTetCells() + iNumPyrCells(),
      iBack = iFor + iNumPrismCells() - 1;

    int iNewSize = 0;
    // The case of exactly one valid cell
    if ((iFor == iBack) &&
	pCCell(iFor)->qValid() &&
	!pCCell(iFor)->qDeleted()) {
      iNewSize = 1;
      iFor = 1; // Necessary because of an assertion later.
    }

    while (iFor < iBack) {
      while (!pCCell(iFor)->qDeleted() && iFor < iBack){
	iFor++;
	iNewSize++;
      }

      while (pCCell(iBack)->qDeleted() && iFor < iBack)
	iBack--;

      if (iFor != iBack) {
	Cell *pCFor = pCCell(iFor);
	Cell *pCBack = pCCell(iBack);

	assert(pCFor->qDeleted());
	assert(!pCBack->qDeleted());
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted();
// #ifndef NDEBUG
//	for (int i = 0; i < pCFor->iNumFaces(); i++)
//	  assert(pCFor->pFFace(i)->iFullCheck());
// #endif
	iNewSize++;
	iFor++;
      }
      else if (!pCCell(iFor)->qDeleted()) {
	iNewSize++;
	iFor++;
      }
    }
    assert(iFor == iNewSize + iNumTetCells() + iNumPyrCells());
    // Reset the number of prism cells in use
    VAPrism.vSetup(iNewSize);
  } // Prism iteration

  // Purge hexahedra
  {
    int iFor = iNumTetCells() + iNumPyrCells() + iNumPrismCells(),
      iBack = iFor + iNumHexCells() - 1;

    int iNewSize = 0;
    // The case of exactly one valid cell
    if ((iFor == iBack) &&
	pCCell(iFor)->qValid() &&
	!pCCell(iFor)->qDeleted()) {
      iNewSize = 1;
      iFor = 1; // Necessary because of an assertion later.
    }

    while (iFor < iBack) {
      while (!pCCell(iFor)->qDeleted() && iFor < iBack){
	iFor++;
	iNewSize++;
      }

      while (pCCell(iBack)->qDeleted() && iFor < iBack)
	iBack--;

      if (iFor != iBack) {
	Cell *pCFor = pCCell(iFor);
	Cell *pCBack = pCCell(iBack);

	assert(pCFor->qDeleted());
	assert(!pCBack->qDeleted());
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted();
// #ifndef NDEBUG
//	for (int i = 0; i < pCFor->iNumFaces(); i++)
//	  assert(pCFor->pFFace(i)->iFullCheck());
// #endif
	iNewSize++;
	iFor++;
      }
      else if (!pCCell(iFor)->qDeleted()) {
	iNewSize++;
	iFor++;
      }
    }
    assert(iFor ==
	   iNewSize + iNumTetCells() + iNumPyrCells() + iNumPrismCells());
    // Reset the number of hex cells in use
    VAHex.vSetup(iNewSize);
  } // Hexahedron iteration

}

void VolMesh::vPurgeVerts(map<Vert*, Vert*>* vert_map)
  // Renumber vertices, removing those that have been marked as deleted
{
  int iV, iVActive;
  bool qAnyChanges = false;

  int iDelCount = 0;
  for (iV = iNumVerts() - 1; iV >= 0; iV--) {
    Vert *pV = pVVert(iV);
    if (pV->qDeleted()) iDelCount++;
  }
  if (iDelCount != 0) {
    vSetVertFaceNeighbors();
    iVActive = 0;
    // Copy the vertex data down within the list and establish a lookup so
    // that the faces can figure out where their verts are now stored.
    for (iV = 0; iV < iNumVerts(); iV++) {
      Vert *pV = pVVert(iV);
      if (pV->iNumFaces() == 0) {
	pV->vMarkDeleted();
      }
      if (pV->qDeleted()) {// If vert is deleted, copy over it.
	qAnyChanges = true;
      }
      else {
	Vert *pVA = pVVert(iVActive);
	// Copy the data from its old to its new location
	(*pVA) = (*pV);
	iVActive++;
      }
    }
    
    // If there are no verts deleted, then skip all the hard work.
    Vert *pV = pVVert(iV);
    Vert *pVA = pVVert(iVActive);
    if(vert_map) vert_map->insert( std::make_pair(pV, pVA) );
    // Copy the data from its old to its new location
    (*pVA) = (*pV);
    iVActive++;
  }

  for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
    Face *pF = pFFace(iF);
    if (pF->qDeleted()) continue;
    Vert *apVNew[] = {NULL, NULL, NULL, NULL};
    for (int ii = pF->iNumVerts() - 1; ii >= 0; ii--) {
      std::map<Vert*, Vert*>::iterator iter =
	vert_map->find(pF->pVVert(ii));
      apVNew[ii] = iter->second;
    }
    // Passing the extra arguments does no harm, as they are ignored.
    pF->vSetVerts(apVNew[0], apVNew[1], apVNew[2], apVNew[3]);
  }
  vSetVertFaceNeighbors();
  return;
}

void VolMesh::vPurge(map<Vert*, Vert*>*   vert_map,
		     map<Face*, Face*>*   face_map,
		     map<Cell*, Cell*>*   cell_map) 
{
  vPurgeCells(cell_map);
  vPurgeFaces(face_map);
  vPurgeVerts(vert_map);
}

