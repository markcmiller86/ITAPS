// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <math.h>
#include "RI_misc.h"
#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Vertex.h"

const Vert* PyrCell::pVVert(const int i) const
{
  assert(iFullCheck());
  assert(i >= 0 && i <= 4); // Vertex index out of range
  const Face* const pFBase = ppFFaces[4];
  switch (i) {
  case 0:
  case 2:
    return pFBase->pVVert(i);
  case 1:
  case 3:
    if (pFBase->pCCellRight() == static_cast<const Cell*>(this))
      return pFBase->pVVert(i);
    else
      return pFBase->pVVert(4-i);
  case 4:
    {
      const Face *pF0 = pFFace(0);
      for (int ii = 0; ii < 3; ii++) {
	const Vert *pV = pF0->pVVert(ii);
	if (!pFBase->qHasVert(pV))
	  return pV;
      }
    }
    assert(0); // Should never get here.
    break;
  }
  return pVInvalidVert;
}

void PyrCell::vAllVertHandles(RefImpl_Entity* aHandles[]) const
{
  assert(iFullCheck());
  const Face* const pFBase = ppFFaces[4];
  aHandles[0] = const_cast<Vert*>(pFBase->pVVert(0));
  aHandles[2] = const_cast<Vert*>(pFBase->pVVert(2));
  if (pFBase->pCCellRight() == static_cast<const Cell*>(this)) {
    aHandles[1] = const_cast<Vert*>(pFBase->pVVert(1));
    aHandles[3] = const_cast<Vert*>(pFBase->pVVert(3));
  }
  else {
    aHandles[1] = const_cast<Vert*>(pFBase->pVVert(3));
    aHandles[3] = const_cast<Vert*>(pFBase->pVVert(1));
  }
  // Now for the last one...
  {
    const Face *pF0 = pFFace(0);
    for (int ii = 0; ii < 3; ii++) {
      const Vert *pV = pF0->pVVert(ii);
      if (!pFBase->qHasVert(pV)) {
	aHandles[4] = const_cast<Vert*>(pV);
      }
    }
  }
  assert(aHandles[4] != NULL); 
}

bool PyrCell::qIsClosed() const
{
  for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
    const Face *pF = pFFace(iF);
    for (int iV = pF->iNumVerts() - 1; iV >= 0; iV--) {
      if (!qHasVert(pF->pVVert(iV)))
	return false;
    }
  }
  return true;
}
  
