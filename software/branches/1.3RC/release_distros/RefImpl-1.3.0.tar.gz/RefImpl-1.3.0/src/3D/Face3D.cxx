// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <stdlib.h>

#include "RI_config.h"
#include "RI_misc.h"
#include "RI_Vertex.h"
#include "RI_Face.h"
#include "RI_VolMesh.h"

int QuadFace::iFullCheck() const
{
  if (!Face::iFullCheck()) return 0;
  // Check whether face location is correct.
  assert(pCR->qValid() && pCL->qValid());
  if ( (pCR->eType() != Cell::eHex &&
	pCR->eType() != Cell::ePyr &&
	pCR->eType() != Cell::ePrism)
       ||
       (pCL->eType() != Cell::eHex &&
	pCL->eType() != Cell::ePyr &&
	pCL->eType() != Cell::ePrism)
       ) {
    return 0;
  }
  return 1;
}

int TriFace::iFullCheck() const
{
  if (!Face::iFullCheck()) return 0;

  // Check whether face location is correct.
  assert(pCR->qValid() && pCL->qValid());
  if ( (pCR->eType() != Cell::eTet &&
	pCR->eType() != Cell::ePyr &&
	pCR->eType() != Cell::ePrism)
       ||
       (pCL->eType() != Cell::eTet &&
	pCL->eType() != Cell::ePyr &&
	pCL->eType() != Cell::ePrism)
       ) {
    return 0;
  }
  return 1;
}

Vert *pVCommonVert(const Face* const pF0, const Face* const pF1,
		   const Face* const pF2)
{
  Vert *apVCand0[4];
  pF0->vAllVertHandles(reinterpret_cast<RefImpl_Entity**>(apVCand0));

  int iNCands = pF0->iNumVerts();
  for (int j = iNCands - 1; j >= 0; j--) {
    Vert *pVCand = apVCand0[j];
    if (pF1->qHasVert(pVCand) &&
	pF2->qHasVert(pVCand)) {
      return pVCand;
    }
  }
  return pVInvalidVert;
}
