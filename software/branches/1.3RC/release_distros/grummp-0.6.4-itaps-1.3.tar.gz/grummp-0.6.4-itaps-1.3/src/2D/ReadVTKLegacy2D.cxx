#include <cstdio>

#include "GR_events.h"
#include "GR_Mesh2D.h"

#define DISCARD_LINE do {			\
    lineNum++;					\
    int _res_ = fscanf(pFInFile, "%*[^\n]\n");	\
    _res_++;					\
  } while(0)

#define CHECK_READ(b, a) do {						\
    int _res_ = (a);							\
    lineNum++;								\
    if (_res_ != b) {							\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("File format error", __func__);			\
    }									\
  } while(0)

#define CHECK_RANGE(val_, min_, max_) do {				\
    if (val_ < min_ || val_ > sGR_index_t(max_)) {				\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("Index range error", __func__);			\
    }									\
  } while(0)

#define CHECK_POS_RANGE(val_, max_) do {					\
    if (val_ > max_) {							\
      vMessage(0, "File %s, line %d: \n", strFileName, lineNum);	\
      vFatalError("Index range error", __func__);			\
    }									\
  } while(0)

#define CHECK_VERTEX_RANGE(val_) CHECK_POS_RANGE(val_, nVerts)

void readVTKLegacy(Mesh2D& M2D,
		     const char strFileName[])
{
  FILE *pFInFile = fopen(strFileName, "r");
  if (NULL == pFInFile) {
    vFatalError("Couldn't open input file for reading",
		"__func__");
  }
  vMessage(1, "Reading VTK legacy input (triangles only)\n");

  // Discard the four line header
  GR_index_t lineNum = 1;
  DISCARD_LINE;
  DISCARD_LINE;
  DISCARD_LINE;
  DISCARD_LINE;
  GR_index_t nVerts, nCells;
  CHECK_READ(1, (fscanf(pFInFile, "POINTS %u float\n", &nVerts)));
  if (nVerts == 0)
    vFatalError("Number of vertices is specified to be 0!",
		__func__);

  for (GR_index_t i = 0; i < nVerts; i++) {
    double x, y;
    CHECK_READ(2, (fscanf(pFInFile, "%lf%lf%*f\n", &x, &y)));
    (void) M2D.createVert(x, y);
  }

  CHECK_READ(1, (fscanf(pFInFile, "CELLS %u %*d\n", &nCells)));
  if (nCells == 0)
    vFatalError("Number of cells is specified to be 0!",
		__func__);

  GR_index_t maxVert = 0;
  for (GR_index_t c = 0; c < nCells; c++) {
    GR_index_t vertA, vertB, vertC;
    CHECK_READ(3, (fscanf(pFInFile, "3%u%u%u\n", &vertA, &vertB, &vertC)));
    CHECK_VERTEX_RANGE(vertA);
    CHECK_VERTEX_RANGE(vertB);
    CHECK_VERTEX_RANGE(vertC);
    maxVert = std::max(std::max(maxVert, vertA), std::max(vertB, vertC));
    (void) M2D.createTriCell(M2D.pVVert(vertA), M2D.pVVert(vertB),
			     M2D.pVVert(vertC), iDefaultRegion);
  }

  // Don't bother reading the cell type data

  if (nVerts != maxVert + 1) 
    vFatalError("Vertex numbering in mesh doesn't match number of verts given.",
		__func__);

  // Now create some bdry faces, since VTK doesn't provide them.

  for (GR_index_t f = 0; f < M2D.iNumFaces(); f++) {
    Face *pF = M2D.pFFace(f);
    if (pF->pCCellLeft() == pCInvalidCell ||
	pF->pCCellRight() == pCInvalidCell) {
      (void) M2D.createBFace(pF, iDefaultBC);
    }
  }
}
