#include <cmath>

#include "GR_FaceSwapInfo.h"
#include "GR_Geometry.h"
#include "GR_SwapDecider.h"
#include "GR_Util.h"

using std::min;

using namespace GRUMMP;

#ifdef SIM_ANNEAL_TEST
extern double simAnnealTemp;
static bool simAnnealComp(const double a, const double b)
{
  assert(0 <= a && a <= 1);
  assert(0 <= b && b <= 1);
  double diff = 1/b - 1/a + 1.e-10;
  diff /= (simAnnealTemp);
  diff = (diff + 1) / 2;
  double rand = drand48();
  return (rand < diff);
}
#endif

/// Unless overridden in a derived class, this function decides whether
/// the current configuration is preferable to the alternate
/// configuration by seeking to maximize the minimum value of the
/// quality function for the current or speculative tets.
bool SwapDecider2D::doFaceSwap(const FaceSwapInfo2D& FC) const
{
  if (!m_pQM) {
    // How could we have gotten here?  The subclasses that don't set a
    // specific shape quality measure are supposed to override this
    // function.  This is definitely a library bug, if it occurs.
    assert(0);
    return false;
  }
  // If we've gotten this far, we know for sure that it's topologically
  // valid to do the reconfiguration.  But is it advisable in terms of
  // mesh quality?

  // First, make sure that the verts that are definitely supposed to be
  // here actually are.  
  Vert *pVA = FC.getVertA();
  Vert *pVB = FC.getVertB();
  Vert *pVC = FC.getVertC();
  Vert *pVD = FC.getVertD();
  VALIDATE_INPUT(pVA->qValid() && pVB->qValid() &&
		 pVC->qValid() && pVD->qValid());

  // Verts are ordered like this: A and B are the ends of the existing
  // face; C and D are the opposite verts in the two tris incident on
  // the face. 

  // If these values never get changed, there'll never be any face swaps.
  double qualBefore = 1, qualAfter = 0; 

  // Old configuration
  double qualADB = m_pQM->eval(pVA, pVD, pVB);
  double qualABC = m_pQM->eval(pVA, pVB, pVC);
  qualBefore = min(qualADB, qualABC);

  // New configuration
  double qualADC = m_pQM->eval(pVA, pVD, pVC);
  double qualCDB = m_pQM->eval(pVC, pVD, pVB);
  qualAfter = min(qualADC, qualCDB);

  // In cases of (near) tie, don't do anything; this will help termination. 
#ifdef SIM_ANNEAL_TEST
  return simAnnealComp(qualAfter, qualBefore);
#else
  return (fuzzyGreater(qualAfter, qualBefore));
#endif
}

bool DelaunaySwapDecider2D::doFaceSwap(const FaceSwapInfo2D& FC) const
{
  if (!FC.isSwappable()) return false;
  int iIncircleRes = iIncircle(FC.getVertA(), FC.getVertB(), FC.getVertC(),
			       FC.getVertD());

  return (iIncircleRes == 1);
}

bool UniformDegreeSwapDecider2D::doFaceSwap(const FaceSwapInfo2D& FC) const
{
  if (!FC.isSwappable()) return false;
  Vert *verts[4];
  verts[0] = FC.getVertA();
  verts[1] = FC.getVertB();
  verts[2] = FC.getVertC();
  verts[3] = FC.getVertD();

//   if (pVA->qIsBdryVert() || pVB->qIsBdryVert() ||
//       pVC->qIsBdryVert() || pVD->qIsBdryVert()) {
//     return false;
//   }

  int degDiff[4];
  for (int ii = 0; ii < 4; ii++) {
    if (verts[ii]->iVertType() == Vert::eBdryApex) return false;
    int deg = verts[ii]->iNumFaces();
    bool qBdry = verts[ii]->qIsBdryVert();
    if (qBdry) {
      degDiff[ii] = 2*(deg-1) - 6;
    }
    else {
      degDiff[ii] = deg - 6;
    }
  }

  int before = (degDiff[0]*degDiff[0] + degDiff[1]*degDiff[1] +
		degDiff[2]*degDiff[2] + degDiff[3]*degDiff[3]);

  degDiff[0] -= (verts[0]->qIsBdryVert() ? 2 : 1);
  degDiff[1] -= (verts[1]->qIsBdryVert() ? 2 : 1);
  degDiff[2] += (verts[2]->qIsBdryVert() ? 2 : 1);
  degDiff[3] += (verts[3]->qIsBdryVert() ? 2 : 1);

  int after = (degDiff[0]*degDiff[0] + degDiff[1]*degDiff[1] +
	       degDiff[2]*degDiff[2] + degDiff[3]*degDiff[3]);

  return (after < before);
}

// This tie breaker is used only to pick a unique configuration in the
// event that a tie occurs trying to decide  how to swap.  The only
// thing which this choice of tiebreaker has to recommend it is that it
// gives a unique answer for any two pairs of verts (AB and CD).
static bool
qTieBreak (const Vert * pVVertA, const Vert * pVVertB,
	   const Vert * pVVertC, const Vert * pVVertD)
{
  unsigned long ulA = reinterpret_cast<unsigned long> (pVVertA);
  unsigned long ulB = reinterpret_cast<unsigned long> (pVVertB);
  unsigned long ulC = reinterpret_cast<unsigned long> (pVVertC);
  unsigned long ulD = reinterpret_cast<unsigned long> (pVVertD);
  if (min (ulA, ulB) > min (ulC, ulD))
    return true;
  else
    return false;
}

//@@ Determines whether swapping will improve the maximum face angle.
// Returns true to swap, false to remain the same.
bool MinMaxAngleSwapDecider2D::doFaceSwap(const FaceSwapInfo2D& FSI2D) const
{
  if (!FSI2D.isSwappable()) return false;
  // This algorithm finds face angles between adjacent faces by dotting
  // their unit normals.  The largest magnitude loses.
  //
  // To prevent pairs from flopping back and forth, the tie-breaker is
  // invoked if the inequality is small.

  Vert *pVVertA = FSI2D.getVertA();
  Vert *pVVertB = FSI2D.getVertB();
  Vert *pVVertC = FSI2D.getVertC();
  Vert *pVVertD = FSI2D.getVertD();
  
  double dEps = 1.e-12;
  // All of these normals are intended to point inwards.
  double adNormDA[2], adNormBD[2], adNormCB[2], adNormAC[2];
  vNormal (pVVertA->adCoords (), pVVertD->adCoords (), adNormDA);
  vNormal (pVVertD->adCoords (), pVVertB->adCoords (), adNormBD);
  vNormal (pVVertB->adCoords (), pVVertC->adCoords (), adNormCB);
  vNormal (pVVertC->adCoords (), pVVertA->adCoords (), adNormAC);

  vNORMALIZE2D (adNormDA);
  vNORMALIZE2D (adNormBD);
  vNORMALIZE2D (adNormCB);
  vNORMALIZE2D (adNormAC);

  double dDotBDA = dDOT2D (adNormBD, adNormDA);
  double dDotACB = dDOT2D (adNormAC, adNormCB);
  double dDotDAC = dDOT2D (adNormDA, adNormAC);
  double dDotCBD = dDOT2D (adNormCB, adNormBD);

  double dMaxThis = max (dDotBDA, dDotACB);
  double dMaxOther = max (dDotDAC, dDotCBD);

  if (dMaxThis > dMaxOther + dEps)
    return true;
  else if (dMaxThis + dEps < dMaxOther)
    return false;
  else
    return qTieBreak (pVVertA, pVVertB, pVVertC, pVVertD);
}
