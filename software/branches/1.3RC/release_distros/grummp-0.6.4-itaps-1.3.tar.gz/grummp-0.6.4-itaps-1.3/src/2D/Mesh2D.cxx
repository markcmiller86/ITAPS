#include <cmath>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <deque>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <iterator>
#include <utility>
using std::deque;
using std::list;

using std::map;
using std::multimap;
using std::pair;
using std::set;

#include "GR_GRGeom2D.h"
#include "GR_GRCoEdge.h"
#include "GR_GRCurve.h"
#include "GR_GRPoint.h"

#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "DLIList.hpp"

#include "GR_VertTree.h"
#include "GR_Mesh2D.h"
#include "GR_CellCV.h"
#include "GR_Geometry.h"
#include "GR_InsertionQueue.h"
#include "GR_Vec.h"
#include "GR_misc.h"
#include "GR_events.h"
#include "GR_BFace.h"
#include "GR_BFace2D.h"
#include "GR_BFaceCV.h"
#include "GR_Sort.h"

#include "OptMS.h"
#include "SMsmooth.h"

#ifndef WIN_VC32
#include <unistd.h>
#else
#pragma warning(disable:4786) // DEBUG symbol > 255 chars
#endif

// This is here so that configure can find the library.
extern "C"
{
  void vGRUMMP_2D_Lib (void) {}
}



//@ Default constructor
Mesh2D::Mesh2D(const int iQualMeas)
  : Mesh (), ECEdgeF(), ECEdgeBF(), ECTri(), ECQuad(),
    iOnEdge(0), iOnBdryEdge(0), iOnBdryEdge2(0),
    iInterior(0), iInternalBdry(0), iInternalBdry2(0)
{
  pQ = new Quality(this, iQualMeas);
  SMinitSmoothing(2, 'f', OPTMS_DEFAULT, OPTMS_DEFAULT, &pvSmoothData);
}



void
Mesh2D::vMarkCleanNeighbors (Cell * pC)
{
  int iReg = pC->iRegion ();
  assert (iReg != iInvalidRegion);
  // Cells in the exterior do not get marked with a region.  Instead,
  // they retain their invalid region tag and no traversal is done.
  for (int iF = 0; iF < pC->iNumFaces (); iF++) {
    Face *pF = pC->pFFace (iF);
    if (pF->qValid ()) {
      Cell *pCCand = pF->pCCellOpposite (pC);
      assert (pCCand->qValid ());
      if (pCCand->eType () == Cell::eBdryEdge)
	continue;
      if (pCCand->iRegion () == iInvalidRegion) {
	// If the opposite cell hasn't been marked, mark it the same as
	// this one.
	pCCand->vSetRegion (iReg);
	vMarkCleanNeighbors (pCCand);
      }				// Done tagging candidate cell
    }				// Face is OK
  }				// Loop over faces
}

Face *
Mesh2D::pFFaceBetween (Vert * const pV0, Vert * const pV1)
{
  int nFaces = pV0->iNumFaces();

  for (int i = 0; i < nFaces; i++) {
    Face *pFCand = pV0->pFFace(i);
    assert(pFCand->qHasVert(pV0));
    if (pFCand->qHasVert (pV1))
      return pFCand;
  }
  // If we got to here, then the two verts are not in fact adjacent in
  // the mesh.
  return pFInvalidFace;
}


//@ Retrieval by index
Face* Mesh2D::
pFFace (const GR_index_t i) const
{
  assert (i < iNumFaces ());
  return ECEdgeF.getEntry (i);
}

BFace* Mesh2D::
pBFBFace (const GR_index_t i) const
{
  assert (i < iNumTotalBdryFaces ());
  if (i < iNumBdryFaces())
    return ECEdgeBF.getEntry(i);
  else
    return ECIntEdgeBF.getEntry(i - iNumBdryFaces());
}

IntBdryEdge* Mesh2D::
pIBEIntBdryEdge (const GR_index_t i) const
{
  assert (i < iNumIntBdryFaces ());
  return ECIntEdgeBF.getEntry (i);
}

Cell* Mesh2D::
pCCell (const GR_index_t i) const
{
  assert (i < iNumCells ());
  if (i < ECTri.lastEntry ())
    return ECTri.getEntry (i);
  else
    return ECQuad.getEntry (i - ECTri.lastEntry ());
}

/// If the face pointer is -not- a valid pointer to a face in this mesh,
/// then the function returns -1.
/// @param pF A pointer to a face
/// @seealso iBFaceIndex
/// @seealso iCellIndex
/// @seealso iVertIndex
/// @return Integer index of the face
GR_index_t Mesh2D::
iFaceIndex (const Face * const pF) const
{
  assert (pF->eType () == Face::eEdgeFace);
  return (ECEdgeF.getIndex (dynamic_cast<const EdgeFace *>(pF)));
}

GR_index_t Mesh2D::
iBFaceIndex (const BFace * const pBF) const
{
  switch (pBF->eType()) {
  case Cell::eBdryEdge:
    return ECEdgeBF.getIndex(dynamic_cast<const BdryEdge*>(pBF));
  case Cell::eIntBdryEdge:
    return iNumBdryFaces() + ECIntEdgeBF.getIndex(dynamic_cast<const IntBdryEdge*>(pBF));
  default:
    assert(0);
    return -1;
  }
}

GR_index_t Mesh2D::
iCellIndex (const Cell * const pC) const
{
  assert ((pC->eType () == Cell::eQuadCell && !qSimplex) ||
	  pC->eType () == Cell::eTriCell);
  if (pC->eType () == Cell::eTriCell)
    return ECTri.getIndex (dynamic_cast<const TriCell *>(pC));
  else
    {
      return ECQuad.getIndex (dynamic_cast<const QuadCell *>(pC)) + ECTri.lastEntry ();
    }
}				//@ Creation of new entities

bool Mesh2D::
qIsValidEnt (void* pvEnt) const
  // Determines if the memory location pointed to by the pointer
  // given is valid (within the range) for any of the entity types
  // for this mesh
{
  return ( ECEdgeF.qValid( static_cast<EdgeFace*>(pvEnt) ) ||
	   ECTri.qValid( static_cast<TriCell*>(pvEnt) )    ||
	   ECQuad.qValid( static_cast<QuadCell*>(pvEnt) )  ||
	   ECVerts.qValid( static_cast<Vert*>(pvEnt) )     );
}

Face* Mesh2D::
pFNewFace (const int iNV)
{
  assert (iNV == 2);
  Face *pF = ECEdgeF.getNewEntry ();
  pF->vResetAllData ();
  return pF;
}

BFace* Mesh2D::
pBFNewBFace (const int iNBV)
{
  assert (iNBV == 2);
  BFace *pBF = ECEdgeBF.getNewEntry ();
  pBF->vResetAllData();
  return pBF;
}

IntBdryEdge* Mesh2D::
pIBENewIntBdryEdge (const int iNBV)
{
  assert (iNBV == 2);
  IntBdryEdge *pIBE = ECIntEdgeBF.getNewEntry ();
  pIBE->vResetAllData();
  return pIBE;
}

Cell* Mesh2D::
pCNewCell (const int iNF)
{
  assert (iNF == 3 || (iNF == 4 && !qSimplex));
  if (iNF == 3) {
    TriCell *pTriC = ECTri.getNewEntry ();
    pTriC->vResetAllData();
    pTriC->vSetType (Cell::eTriCell);
    return pTriC;
  }
  else {
    QuadCell *pQuadC = ECQuad.getNewEntry ();
    pQuadC->vResetAllData();
    pQuadC->vSetType (Cell::eQuadCell);
    return pQuadC;
  }
}

//@ Purge unused entries
void Mesh2D::
vPurge (map<Vert*, Vert*>*   vert_map,
	map<Face*, Face*>*   face_map,
	map<Cell*, Cell*>*   cell_map,
	map<BFace*, BFace*>* bface_map)
{
  SUMAA_LOG_EVENT_BEGIN(PURGE);
#ifdef ITAPS
  vCheckForITAPSBdryErrors();
#endif
  vPurgeCells (cell_map);
  vPurgeBdryFaces (bface_map);
  vPurgeFaces (face_map);
  vPurgeVerts (vert_map);
  SUMAA_LOG_EVENT_END(PURGE);
}

void Mesh2D::
vPurgeVerts (map<Vert*, Vert*>* vert_map)
// Renumber vertices, removing those that have been marked as deleted
{
  bool qLocalLog = false;
#ifdef SUMAA_LOG
  if (SUMAA_LOG_current != PURGE) {
    qLocalLog = true;
    SUMAA_LOG_EVENT_BEGIN(PURGE);
  }
#endif
  GR_index_t *aiVertInd = new GR_index_t[iNumVerts()];
  GR_index_t iV, iVActive;
  
  vSetAllHintFaces();
  iVActive = 0;
  // Copy the vertex data down within the list and establish a lookup so
  // that the faces can figure out where their verts are now stored.
  for (iV = 0; iV < iNumVerts(); iV++) {
    Vert *pV = pVVert(iV);
    if (pV->qDeleted()) {// If vert is deleted, copy over it.
      aiVertInd[iV] = GR_index_t(INT_MAX)*2;
    }
    else {
      aiVertInd[iV] = iVActive;
      Vert *pVA = pVVert(iVActive);
      if(vert_map) vert_map->insert( std::make_pair(pV, pVA) );
      // Copy the data from its old to its new location
      if (pVA != pV) {
	(*pVA) = (*pV);
	pV->vMarkDeleted();
      }
      iVActive++;
    }
  }

  // This should happen automatically now.
//   // Change the vertices for all the faces.
//   vClearVertFaceNeighbors();
//   vClearAllHintFaces();
//   for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
//     Face *pF = pFFace(iF);
//     if (pF->qDeleted()) continue;
//     Vert *apVNew[4];
//     for (int ii = pF->iNumVerts() - 1; ii >= 0; ii--) {
//       GR_index_t tmp = aiVertInd[iVertIndex(pF->pVVert(ii))];
    
//       apVNew[ii] = pVVert(
//     // Passing the extra arguments does no harm, as they are ignored.
//     pF->vSetVerts(apVNew[0], apVNew[1], apVNew[2], apVNew[3]);
//   }
  vSetAllHintFaces();
  assert(qValid());
  
  // Now change the influencing verts, where they occur, to match the
  // new vertex numbering.
  
  for (iV = 0; iV < iVActive; iV++) {
    Vert *pV = pVVert(iV);
    assert(pV->qValid() && !pV->qDeleted());
    if (pV->dLS() < 0) {
      // Don't bother copying data if no length scale exists yet.
      pV->vClearLS();
      continue;
    }
    
    
    //     vFatalError("See code - The following should be replaced", 
    // 		"Mesh2D::vPurgeVerts()");
    Vert *pVInf;
    BdryPatch *pBPJunk;
    pV->vGetClosest(&pVInf, &pBPJunk);
    if (pVInf->qValid()) {
      pVInf = pVVert(aiVertInd[iVertIndex(pVInf)]);
      pV->vSetClosest(pVInf);
    }
    
    // Not commented in trunk rev 599
    //     pV->vGetSecond(&pVInf, &pBPJunk);
    //     if (pVInf->qValid()) {
    //       pVInf = pVVert(aiVertInd[iVertIndex(pVInf)]);
    //       pV->vSetSecond(pVInf);
    //     }
  }
  delete [] aiVertInd;
  
  vSetupVerts(iVActive);
  //   vUpdateInfluence();
  if (qLocalLog) {
    SUMAA_LOG_EVENT_END(PURGE);
  }
}

void Mesh2D::
vPurgeFaces (map<Face*, Face*>* face_map)
  // Get rid of all unused faces in the connectivity table.
{
  bool qLocalLog = false;
#ifdef SUMAA_LOG
  if (SUMAA_LOG_current != PURGE) {
    qLocalLog = true;
    SUMAA_LOG_EVENT_BEGIN(PURGE);
  }
#endif
  EdgeFace *pFFor = ECEdgeF.pTFirst ();
  EdgeFace *pFBack = ECEdgeF.pTLast ();

  int iNewSize = 0;
  // The case of exactly one valid face
  if (pFFor == pFBack && pFFor != pFInvalidFace && 
      !pFFor->qDeleted ()) { 
    if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
    iNewSize++;
  }

  while (pFFor != pFBack) {
    while (!pFFor->qDeleted () && pFFor != pFBack) {
      if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
      pFFor = ECEdgeF.pTNext (pFFor);
      iNewSize++;
    }

    while (pFBack->qDeleted () && pFFor != pFBack)
      pFBack = ECEdgeF.pTPrev (pFBack);

    if (pFFor != pFBack) {
      assert (pFFor->qDeleted ());
      if(face_map) face_map->insert( std::make_pair(pFBack, pFFor) );
      iNewSize++;
      (*pFFor) = (*pFBack);
      assert (!pFFor->qDeleted ());
      pFBack->vMarkDeleted ();
      pFFor = ECEdgeF.pTNext (pFFor);
    }
    // Allow for the case where nothing has been deleted
    else if (!pFFor->qDeleted ()) {
      if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
      iNewSize++;
    }
  }				// Loop over all faces

  // This resets the number of entries in use to iNewSize.
  ECEdgeF.vSetup (iNewSize);
  vResetPeriodicData();
  vResetVertexConnectivity();
  if (qLocalLog) {
    SUMAA_LOG_EVENT_END(PURGE);
  }
}

void Mesh2D::
vPurgeCells (map<Cell*, Cell*>* cell_map)
  // Get rid of all unused cells in the connectivity table.
{
  bool qLocalLog = false;
#ifdef SUMAA_LOG
  if (SUMAA_LOG_current != PURGE) {
    qLocalLog = true;
    SUMAA_LOG_EVENT_BEGIN(PURGE);
  }
#endif
  {
    TriCell *pCFor = ECTri.pTFirst ();
    TriCell *pCBack = ECTri.pTLast ();
    int iNewSize = 0;
    // The case of exactly one valid cell
    if (pCFor == pCBack &&
	pCFor != pCInvalidCell &&
	!pCFor->qDeleted ()) {
      iNewSize = 1;
      if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
    }

    while (pCFor != pCBack) {
      while (!pCFor->qDeleted () && pCFor != pCBack) {
	if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
	pCFor = ECTri.pTNext (pCFor);
	iNewSize++;
      }

      while (pCBack->qDeleted () && pCFor != pCBack)
	pCBack = ECTri.pTPrev (pCBack);

      if (pCFor != pCBack) {
	assert (pCFor->qDeleted ());
	if(cell_map) cell_map->insert( std::make_pair(pCBack, pCFor) );
	iNewSize++;
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pCFor->iNumFaces (); i++) {
	  assert (pCFor->pFFace (i)->iFullCheck ());
	}
#endif
	pCFor = ECTri.pTNext (pCFor);
      }
      // Allow for the case where nothing has been deleted
      else if (!pCFor->qDeleted ()) {
	if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
	iNewSize++;
      }
    }				// Loop over triangles
    // Reset the number of tri cells in use

    ECTri.vSetup (iNewSize);
  }				// Contex for loop over triangles

  {
    QuadCell *pCFor = ECQuad.pTFirst ();
    QuadCell *pCBack = ECQuad.pTLast ();
    int iNewSize = 0;
    // The case of exactly one valid cell
    if (pCFor == pCBack &&
	pCFor != pCInvalidCell &&
	!pCFor->qDeleted ())
      iNewSize++;
    while (pCFor != pCBack) {
      while (!pCFor->qDeleted () && pCFor != pCBack) {
	pCFor = ECQuad.pTNext (pCFor);
	iNewSize++;
      }

      while (pCBack->qDeleted () && pCFor != pCBack)
	pCBack = ECQuad.pTPrev (pCBack);

      if (pCFor != pCBack) {
	assert (pCFor->qDeleted ());
	iNewSize++;

	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pCFor->iNumFaces (); i++)
	  assert (pCFor->pFFace (i)->iFullCheck ());
#endif
	pCFor = ECQuad.pTNext (pCFor);
      }
      // Allow for the case where nothing has been deleted
      else if (!pCFor->qDeleted ())
	iNewSize++;
    }				// Loop over quads
    // Reset the number of quad cells in use

    ECQuad.vSetup (iNewSize);
  }				// Context for loop over quads
  if (qLocalLog) {
    SUMAA_LOG_EVENT_END(PURGE);
  }
  
}

void Mesh2D::
vPurgeBdryFaces (map<BFace*, BFace*>* bface_map) {

  // Get rid of all unused bdry faces in the connectivity table.

  bool qLocalLog = false;

#ifdef SUMAA_LOG
  if (SUMAA_LOG_current != PURGE) {
    qLocalLog = true;
    SUMAA_LOG_EVENT_BEGIN(PURGE);
  }
#endif

  // First the "real" bdry edges
  {
    BdryEdge *pEBFFor  = ECEdgeBF.pTFirst();
    BdryEdge *pEBFBack = ECEdgeBF.pTLast ();

    int iNewSize = 0;

    while (pEBFFor != pEBFBack) {

      while (!pEBFFor->qDeleted() && pEBFFor != pEBFBack) {
	if(bface_map) bface_map->insert( std::make_pair(pEBFFor, pEBFFor) );
	pEBFFor = ECEdgeBF.pTNext(pEBFFor);
	iNewSize++;
      }

      while (pEBFBack->qDeleted() && pEBFFor != pEBFBack)
	pEBFBack = ECEdgeBF.pTPrev(pEBFBack);

      if (pEBFFor != pEBFBack) {
	assert (pEBFFor->qDeleted ());
	if(bface_map) bface_map->insert( std::make_pair(pEBFBack, pEBFFor) );
	iNewSize++;
	(*pEBFFor) = (*pEBFBack);
	pEBFBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pEBFFor->iNumFaces(); i++) {
	  assert (pEBFFor->pFFace(i)->iFullCheck());
	}	
#endif
	pEBFFor = ECEdgeBF.pTNext (pEBFFor);
      }
      else if (!pEBFFor->qDeleted ()) {
	if(bface_map) bface_map->insert( std::make_pair(pEBFFor, pEBFFor) );
	iNewSize++;
      }
    }

    //Set the number of bdry faces in use
    ECEdgeBF.vSetup(iNewSize);
  }

  // Now the internal bdry faces
  {
    int iNewSize = 0;
    IntBdryEdge *pIEBFFor = ECIntEdgeBF.pTFirst ();
    IntBdryEdge *pIEBFBack = ECIntEdgeBF.pTLast ();
    // The case of exactly one valid internal bdry edge
    if (pIEBFFor == pIEBFBack &&
	pIEBFFor != pBFInvalidBFace &&
	!pIEBFFor->qDeleted ()) {
      if(bface_map) bface_map->insert( std::make_pair(pIEBFFor, pIEBFFor) );
      iNewSize = 1;
    }

    while (pIEBFFor != pIEBFBack) {
      while (!pIEBFFor->qDeleted () && pIEBFFor != pIEBFBack) {
	if(bface_map) bface_map->insert( std::make_pair(pIEBFFor, pIEBFFor) );
	pIEBFFor = ECIntEdgeBF.pTNext (pIEBFFor);
	iNewSize++;
      }

      while (pIEBFBack->qDeleted () && pIEBFFor != pIEBFBack)
	pIEBFBack = ECIntEdgeBF.pTPrev (pIEBFBack);

      if (pIEBFFor != pIEBFBack) {
	assert (pIEBFFor->qDeleted ());
	if(bface_map) bface_map->insert( std::make_pair(pIEBFBack, pIEBFFor) );
	iNewSize++;
	(*pIEBFFor) = (*pIEBFBack);
	pIEBFBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pIEBFFor->iNumFaces (); i++)
	  assert (pIEBFFor->pFFace (i)->iFullCheck ());
#endif
	pIEBFFor = ECIntEdgeBF.pTNext (pIEBFFor);
      }
      else if (!pIEBFFor->qDeleted ()) {
	if(bface_map) bface_map->insert( std::make_pair(pIEBFFor, pIEBFFor) );
	iNewSize++;
      }
    }
    // Reset the number of bdry faces in use
    ECIntEdgeBF.vSetup (iNewSize);
  }

  if (qLocalLog) {
    SUMAA_LOG_EVENT_END(PURGE);
  }
}

//@ Validity checking of entire mesh
bool Mesh2D::
qValid () const
{
  
  bool qRetVal = true;
  int i;

  for (i = iNumVerts () - 1; i >= 0 && qRetVal; i--) {
    Vert *pV = pVVert (i);
    qRetVal = qRetVal && pV->qValid ();
    // If the vertex still belongs to the mesh...
    if (!pV->qDeleted ()) {	
      // and the vertex has a hint face defined...
      Face *pF = pV->pFHintFace ();
      if (pF->qValid ())	
	// that hint has to be correct.
	qRetVal = qRetVal && pF->qHasVert (pV); 
    }
  }
  
  for (i = iNumFaces () - 1; i >= 0 && qRetVal; i--) {
    Face *pF = pFFace (i);
    if (!(pF->qValid ())) {
      qRetVal = false;
      break;
    }
    if (pF->qDeleted()) continue;
    if (!pF->pCCellLeft ()->qValid () ||
	!pF->pCCellRight ()->qValid ()) {
      if (pF->iFaceLoc() == Face::eInterior) {
	qRetVal = false;
	break;
      }
      else {
	continue;
      }
    }
    int iLoc = pF->iFaceLoc ();
    switch (iLoc) {
    case (Face:: eInterior):
      if (pF->pCCellLeft ()->iRegion () !=
	  pF->pCCellRight ()->iRegion ())
	qRetVal = false;
      break;
    case (Face:: eBdryTwoSide):
      //if (pF->pCCellLeft()->iRegion() == pF->pCCellRight()->iRegion())
      //	qRetVal = false;
      // Must make sure that at least one side is an IntBdryEdge...
//       if ((pF->pCCellLeft ()->eType () != Cell::eIntBdryEdge) &&
// 	  (pF->pCCellRight ()->eType () != Cell::eIntBdryEdge)) {
// 	qRetVal = false;
      //   }

      break;
    default:
      break;
    }
    if (pF->iFullCheck() == 0) qRetVal = false;

  }

  for (i = iNumBdryFaces () - 1; i >= 0 && qRetVal; i--)
    qRetVal = qRetVal && pBFBFace (i)->qValid ();

  for (i = iNumCells () - 1; i >= 0 && qRetVal; i--) {
    Cell *pC = pCCell (i);
    qRetVal = qRetVal && pC->qValid ();
    
    if (pC->qDeleted ())
      continue;
    bool qRegOK = (pC->iRegion () != iInvalidRegion);
    qRetVal = qRetVal && qRegOK;
    
    // Check that the cell is actually closed
    qRetVal = qRetVal && pC->qIsClosed ();    
  }

  //   qRetVal = qRetVal && qWatertight();
  return qRetVal;
}

//@ Computation of perimeter, total surface area, and watertightness of surface
double Mesh2D::
dBoundarySize () const
{
  double dRetVal = 0;
  for (int i = iNumBdryFaces () - 1; i >= 0; i--)
    dRetVal += pBFBFace (i)->dSize ();
  return dRetVal;
}

double Mesh2D::
dInteriorSize () const
{
  double dRetVal = 0;
  for (int i = iNumCells () - 1; i >= 0; i--)
    dRetVal += pCCell (i)->dSize ();
  return dRetVal;
}

bool Mesh2D::
qWatertight () const
{
  double adSum[] =
  {0., 0., 0.};
  double dArea = 0;
  bool qAnyCells = false;
  for (int i = iNumCells () - 1; i >= 0; i--)
    {
      Cell *pC = pCCell (i);
      // Only compute the directed surface area for cells which have valid
      // connectivity.  This way, surface meshes with deleted cells (ie,
      // no valid faces) can be checked for watertightness.
      if (pC->iFullCheck () == 1) {
	qAnyCells = true;
	double adTemp[3];
	pC->vVecSize (adTemp);
	adSum[0] += adTemp[0];
	adSum[1] += adTemp[1];
	adSum[2] += adTemp[2];
	dArea += pC->dSize ();
      }
    } if (!qAnyCells)
      return true;
  double dInvArea = 1. / dArea;
  vSCALE3D (adSum, dInvArea);
  if (iFuzzyComp (adSum[0], 0) == 0 &&
      iFuzzyComp (adSum[1], 0) == 0 &&
      iFuzzyComp (adSum[2], 0) == 0)
    return (true);
  else {
    vMessage (2, "Directed surface areas are non-zero:");
    vMessage (2, "  x: %12.5g\n  y: %12.5g\n  z: %12.5g\n", adSum[0],
	      adSum[1], adSum[2]);
    return (false);
  }
}

typedef struct _vert_vert_ {
  int iV0, iV1;
  _vert_vert_ (const int i0 = -1, const int i1 = -1) :
    iV0(i0), iV1(i1) {}
}
VertVert;

extern "C"
{
  static int qVVComp (const void *pv0, const void *pv1) {
    const VertVert *const pVV0 = (const VertVert *) pv0;
    const VertVert *const pVV1 = (const VertVert *) pv1;
    return (pVV0->iV0 < pVV1->iV0 ||
	    (pVV0->iV0 == pVV1->iV0 && pVV0->iV1 < pVV1->iV1)) ? -1 : 1;
  }
}

typedef struct _renum_ {
  int iV, iDeg;
  _renum_ (const int iVIn = -1, const int iDegIn = 0) :
    iV(iVIn), iDeg(iDegIn) {}
} Renum;

extern "C"
{
  static int qRenumComp2D (const void *pv0, const void *pv1) {
    const Renum *const pR0 = (const Renum *) pv0;
    const Renum *const pR1 = (const Renum *) pv1;
    return ((pR0->iDeg < pR1->iDeg) ? -1 :
	    ((pR0->iDeg == pR1->iDeg) ? 0 : 1));
  }
}

//@ Reorder vertices in a 2D mesh using the reverse Cuthill-McKee algorithm
void Mesh2D::
vReorderVerts_RCM (void)
{
#warning Reordering in 2D is buggy.
  vMessage(2, "Renumbering vertices...");
  int iVert, iFace, iNVerts = iNumVerts (), iNFaces = iNumFaces ();
  //@@ Construct the vert-vert connectivity
  // Make a list containing each edge (once in each direction) and sort
  VertVert *aVV = new VertVert[2 * iNFaces];
  for (iFace = iNFaces - 1; iFace >= 0; iFace--) {
    Face *pF = pFFace (iFace);
    int iV0 = iVertIndex (pF->pVVert (0));
    int iV1 = iVertIndex (pF->pVVert (1));
    aVV[2 * iFace + 1] = VertVert (iV0, iV1);
    aVV[2 * iFace] = VertVert (iV1, iV0);
  }
  qsort (aVV, 2 * iNFaces, sizeof (VertVert), qVVComp);
  // Tabulate starting locations and degree for each vertex.
  int *aiStart = new int[iNVerts + 1];
  int *aiDegree = new int[iNVerts];
  bool *aqUsed = new bool[iNVerts];
  int iStart = 0, iNAttachedVerts = 0;
  for (iVert = 0; iVert < iNVerts; iVert++) {
    aiStart[iVert] = iStart;
    for (; (iStart < 2*iNFaces) && (aVV[iStart].iV0 == iVert); iStart++) {}
    if (iStart != aiStart[iVert])
      iNAttachedVerts++;
    aiDegree[iVert] = iStart - aiStart[iVert];
    aqUsed[iVert] = false;
  }
  aiStart[iNVerts] = 2 * iNFaces;

  // Set up space to compute re-ordering
  Renum *aRReorder = new Renum[iNVerts];

  int iNumRenumbered = 0;
  while (iNumRenumbered < iNAttachedVerts) {
    //@@ Initialize the front to be a single unrenumbered vertex with lowest degree
    // Find lowest degree vertex
    int iMinDeg = 100, iMinVert = -1;
    for (iVert = 0; iVert < iNAttachedVerts; iVert++) {
      int iDeg = aiStart[iVert + 1] - aiStart[iVert];
      if (iDeg < iMinDeg && iDeg > 0 && !aqUsed[iVert]) {
	iMinDeg = iDeg;
	iMinVert = iVert;
	if (iMinDeg == 2)
	  break;	// Can never be lower than this, so why go on?
      }
    }
    assert (iMinVert != -1);

    // Initialize
    aqUsed[iMinVert] = true;
    aRReorder[iNumRenumbered] = Renum (iMinVert, iMinDeg);
    iNumRenumbered++;
    int iEnd = iNumRenumbered, iBegin = iNumRenumbered-1;

    //@@ Propagate across the mesh
    do {
      //@@@ Add all the next layer of vertices
      int iEnt;
      for (iEnt = iBegin; iEnt < iEnd; iEnt++) {
	int iV = aRReorder[iEnt].iV;
	for (int iNeigh = aiStart[iV]; iNeigh < aiStart[iV + 1]; iNeigh++) {
	  // Grab a candidate
	  assert (aVV[iNeigh].iV0 == iV);
	  int iCand = aVV[iNeigh].iV1;
	  if (!aqUsed[iCand]) {
	    // Add it if it isn't already in the list
	    aRReorder[iNumRenumbered].iV = iCand;
	    aRReorder[iNumRenumbered].iDeg = aiDegree[iCand];
	    aqUsed[iCand] = true;
	    iNumRenumbered++;
	  }
	}			// Loop over neighbors of a given vertex
      }				// Loop over all verts in the most recent layer

      //@@@ Sort the new layer in order of increasing degree
      iBegin = iEnd;
      iEnd = iNumRenumbered;
      qsort (&(aRReorder[iBegin]), static_cast<GR_index_t>(iEnd - iBegin),
	     sizeof (Renum), qRenumComp2D);
    } while (iEnd != iBegin);
  }
  delete [] aVV;
  delete [] aiStart;
  delete [] aiDegree;
  delete [] aqUsed;

  for (iVert = 0; iNumRenumbered != iNVerts; iVert++) {
    if (!aqUsed[iVert]) {
      aRReorder[iNumRenumbered].iV = iVert;
      aqUsed[iVert] = true;
      iNumRenumbered++;
    }
  }

  //@@ Reverse the ordering
  for (iVert = 0; iVert < iNVerts / 2; iVert++) {
    int iTemp = aRReorder[iVert].iV;
    aRReorder[iVert].iV = aRReorder[iNVerts - iVert - 1].iV;
    aRReorder[iNVerts - iVert - 1].iV = iTemp;
  }

  //@@ Move vertex data
  // Create a new copy
  EntContainer<Vert> ECTemp;
  ECTemp.vSetup (iNVerts);
  for (iVert = 0; iVert < iNVerts; iVert++) {
    // Copy both coordinates and vertex tags
    ECTemp[iVert] = (*pVVert(iVert));
//     Vert *pVTmp = pVVert (iVert);
//     ECTemp[iVert].vSetCoords (pVTmp->iSpaceDimen (), pVTmp->adCoords ());
//     ECTemp[iVert].vCopyAllFlags (pVTmp);
//     ECTemp[iVert].vCopyInfluence(pVTmp);
//     ECTemp[iVert].vSetLS(pVTmp->dLS());
  }
  for (iVert = 0; iVert < iNVerts; iVert++) {
    // Copy back into re-ordered locations
    Vert *pVSource = &(ECTemp[aRReorder[iVert].iV]);
    Vert *pVTarget = pVVert(iVert);
    (*pVTarget) = (*pVSource);
//     pVVert (iVert)->vSetCoords (pVSource->iSpaceDimen (), pVSource->adCoords ());
//     pVVert (iVert)->vCopyAllFlags (pVSource);
//     pVVert (iVert)->vCopyInfluence(pVSource);
//     pVVert (iVert)->vSetLS(pVSource->dLS());
  }

  //@@ Re-label all the face data
  int *aiOld2New = new int[iNVerts];
  for (iVert = 0; iVert < iNVerts; iVert++)
    aiOld2New[aRReorder[iVert].iV] = iVert;
  delete[]aRReorder;

  vClearAllHintFaces();
  vClearVertFaceNeighbors();

  for (iFace = 0; iFace < iNFaces; iFace++) {
    Face *pF = pFFace (iFace);
    Vert *apVNew[2];		// Only two verts to an edge

    apVNew[0] = pVVert (aiOld2New[iVertIndex (pF->pVVert (0))]);
    apVNew[1] = pVVert (aiOld2New[iVertIndex (pF->pVVert (1))]);
    pF->vSetVerts(apVNew[0], apVNew[1]);
  }
  delete[]aiOld2New;

  //@@ Reset vertex hints
  vSetAllHintFaces ();
  if (!(qValid ())) {
    vMessage(2, "aborted!\n");
    vFoundBug ("Vertex re-ordering for 2D meshes");
  }
  vMessage(2, "done.\n");
}

void Mesh2D::vReorderCells()
  // Reorder cells according to vertex indices, so that cells with the
  // lowest sum of vertex indices are first in order.  The hardest part
  // is actually to get the faces and cells reconnected afterwards.
{
  vMessage(2, "Renumbering cells...");
  assert(qSimplicial());
  multimap<GR_index_t, GR_index_t> mOrderedCells;
  GR_index_t iC;
  for (iC = 0; iC < iNumCells(); iC++) {
    Cell *pC = pCCell(iC);
    GR_index_t iSum = 0;
    GR_index_t iNV = pC->iNumVerts();
    for (GR_index_t iV = 0; iV < iNV; iV++) {
      iSum += iVertIndex(pC->pVVert(iV));
    }
    GR_index_t iMean = iSum / iNV;
    mOrderedCells.insert(pair<GR_index_t, GR_index_t>(iMean, iC));
  }
  // Now we have a list of all the cells, sorted in order by smallest
  // average of vertex indices!  Use this to create a map that tells
  // which old cell goes into which slot in the new numbering.
  GR_index_t *aiCellMapping = new GR_index_t[iNumCells()];
  multimap<GR_index_t, GR_index_t>::iterator iter;
  iC = 0;
  for (iter = mOrderedCells.begin(); iter != mOrderedCells.end(); iter++) {
    vMessage(4, "Old cell: %u  New cell: %u  Sum: %u\n",
	     iter->second, iC, iter->first);
    aiCellMapping[iC] = iter->second;
    iC++;
  }
  assert(iC == iNumCells());

  // Finally, update the cell information.  Fundamentally, re-ordering
  // the cells results in one or more circular permutations of cells
  // (A->B->Q->L->A, etc).  So follow each of these.
  bool *aqUpdated = new bool[iNumCells()];
  for (iC = 0; iC < iNumCells(); iC++) {
    aqUpdated[iC] = false;
  }

  GR_index_t iNumUpdated = 0;
  GR_index_t iFirst = 0;
  while (iNumUpdated != iNumCells()) {
    while (aqUpdated[iFirst]) iFirst++;
    assert(iFirst < iNumCells());
    if (aiCellMapping[iFirst] == iFirst) {
      aqUpdated[iFirst] = true;
      iNumUpdated++;
    }
    else {
      assert(pCCell(iFirst)->eType() == Cell::eTriCell);
      TriCell TC;
      TC = *(dynamic_cast<TriCell*>(pCCell(iFirst)));
      GR_index_t iNext = iFirst;
      while (aiCellMapping[iNext] != iFirst) {
	(*pCCell(iNext)) = (*pCCell(aiCellMapping[iNext]));
	aqUpdated[iNext] = true;
	iNumUpdated++;
	iNext = aiCellMapping[iNext];
      }
      (*pCCell(iNext)) = TC;
      aqUpdated[iNext] = true;
      iNumUpdated++;
    }
  }
  if (!(qValid ())) {
    vMessage(2, "aborted!\n");
    vFoundBug ("Cell re-ordering for 2D meshes");
  }
  vMessage(2, "done.\n");
  delete [] aiCellMapping;
  delete [] aqUpdated;
}

void Mesh2D::vReorderFaces()
  // Reorder faces according to vertex indices, so that faces with the
  // lowest sum of vertex indices are first in order.  The hardest part
  // is actually to get the faces and cells reconnected afterwards.
{
  vMessage(2, "Renumbering faces...");
  assert(qSimplicial());
  multimap<GR_index_t, GR_index_t> mOrderedFaces;
  GR_index_t iF, iNF = iNumFaces();
  for (iF = 0; iF < iNF; iF++) {
    Face *pF = pFFace(iF);

    GR_index_t iSum = iVertIndex(pF->pVVert(0)) + iVertIndex(pF->pVVert(1));
    mOrderedFaces.insert(pair<GR_index_t, GR_index_t>(iSum, iF));
  }
  // Now we have a list of all the faces, sorted in order by smallest
  // average of vertex indices!  Use this to create a map of which -old-
  // face becomes which -new- face.
  GR_index_t *aiFaceMapping = new GR_index_t[iNF];
  multimap<GR_index_t, GR_index_t>::iterator iter;
  iF = 0;
  for (iter = mOrderedFaces.begin(); iter != mOrderedFaces.end(); iter++) {
    vMessage(4, "Old face: %u  New face: %u  Sum: %u\n",
	     iter->second, iF, iter->first);
    aiFaceMapping[iF] = iter->second;
    iF++;
  }
  assert(iF == iNF);

  // Finally, update the cell information.  Fundamentally, re-ordering
  // the cells results in one or more circular permutations of cells
  // (A->B->Q->L->A, etc).  So follow each of these.
  bool *aqUpdated = new bool[iNF];
  for (iF = 0; iF < iNF; iF++) {
    aqUpdated[iF] = false;
  }

  GR_index_t iNumUpdated = 0;
  GR_index_t iFirst = 0;
  while (iNumUpdated != iNF) {
    while (aqUpdated[iFirst]) iFirst++;
    assert(iFirst < iNF);
    if (aiFaceMapping[iFirst] == iFirst) {
      aqUpdated[iFirst] = true;
      iNumUpdated++;
    }
    else {
      assert(pFFace(iFirst)->eType() == Face::eEdgeFace);
      EdgeFace EF;
      EF = *(dynamic_cast<EdgeFace*>(pFFace(iFirst)));
      GR_index_t iNext = iFirst;
      while (aiFaceMapping[iNext] != iFirst) {
	(*pFFace(iNext)) = (*pFFace(aiFaceMapping[iNext]));
	aqUpdated[iNext] = true;
	iNumUpdated++;
	iNext = aiFaceMapping[iNext];
      }
      (*pFFace(iNext)) = EF;
      aqUpdated[iNext] = true;
      iNumUpdated++;
    }
  }

  vResetVertexConnectivity();

  if (!(qValid ())) {
    vMessage(2, "aborted!\n");
    vFoundBug ("Face re-ordering for 2D meshes");
  }
  vMessage(2, "done.\n");
  delete [] aqUpdated;
  delete [] aiFaceMapping;
}


void Mesh2D::vIdentifyVertexTypesGeometrically() const
  // In addition to some topological deductions, this routine also
  // detects verts at which the boundary has a sharp corner.  This is
  // critical for keeping boundaries from degenerating with repeated
  // coarsening.
  //
  // Note that no effort at all is made to define an apex as a point
  // where two patches meet, because a mesh input from file will have
  // one patch per bdry edge.  This would make every bdry vert a
  // eBdryApex, and that's no good.  However, boundary condition changes
  // are detected, and verts where the BC changes are tagged as
  // eBdryApex.
{
  // Tentatively set the type of every vertex to eInterior.  Then modify
  // that to accomodate boundary verts (both internal and regular).
  for (GR_index_t iV = 0; iV < iNumVerts(); iV++) {
    Vert *pV = pVVert(iV);
    if (pV->iVertType() != Vert::eBdryApex) 
      pV->vSetType(Vert::eInterior);
  }

  // Mark internal boundaries
  GR_index_t iBF;
  for (iBF = 0; iBF < iNumBdryFaces(); iBF++) {
    BFace *pBF = pBFBFace(iBF);
    if (pBF->eType() == Cell::eIntBdryEdge) {
      Face *pF = pBF->pFFace();
      if (pF->pVVert(0)->iVertType() != Vert::eBdryApex) 
	pF->pVVert(0)->vSetType(Vert::eBdryTwoSide);
      if (pF->pVVert(1)->iVertType() != Vert::eBdryApex) 
	pF->pVVert(1)->vSetType(Vert::eBdryTwoSide);
    }
  }

  // Now mark regular boundaries.  In the process, tag intersections of
  // regular and internal boundaries as type eBdryApex.  Finally, make a
  // sorted list of bdry normals (sorted by vertex) for both regular and
  // internal boundaries.
  std::multiset<BdryNorm> msBN;
  for (iBF = 0; iBF < iNumBdryFaces(); iBF++) {
    BFace *pBF = pBFBFace(iBF);
    Face *pF = pBF->pFFace();
    Cell *pCL = pF->pCCellLeft();
    Cell *pCR = pF->pCCellRight();

    Vert *pV0 = pF->pVVert(0);
    Vert *pV1 = pF->pVVert(1);

    if (pCL->eType() == Cell::eBdryEdge ||
	pCR->eType() == Cell::eBdryEdge) {
      switch (pV0->iVertType()) {
      case Vert::eBdryApex:
	break;
      case Vert::eBdryTwoSide:
	pV0->vSetType(Vert::eBdryApex);
	break;
      default:
	pV0->vSetType(Vert::eBdry);
	break;
      }

      switch (pV1->iVertType()) {
      case Vert::eBdryApex:
	break;
      case Vert::eBdryTwoSide:
	pV1->vSetType(Vert::eBdryApex);
	break;
      default:
	pV1->vSetType(Vert::eBdry);
	break;
      }
    }

    double adNorm[3];
    pBF->vUnitNormal(adNorm);
    msBN.insert(BdryNorm(pV0, adNorm));
    msBN.insert(BdryNorm(pV1, adNorm));
  }
  assert(msBN.size() == iNumBdryFaces() * 2);

  // At this point, msBN is a sorted set of BdryNorm's, with multiple
  // entries having the same vertex.
  GR_index_t iRecordsChecked = 0;
  std::multiset<BdryNorm>::iterator itFirst, itLast;
  itFirst = itLast = msBN.begin();
  do {
    Vert *pV = itFirst->pVVert();
    // Should already be tagged as a bdry vert.
    assert(pV->iVertType() != Vert::eInterior);
    do {
      itLast++;
    } while (itLast != msBN.end() && itLast->pVVert() == pV);
    itLast --;
    assert(itLast->pVVert() == pV);

    // If there are three or more distinct BFaces incident on a vertex,
    // it's definitely a eBdryApex, and should already be tagged as
    // such.
    assert(itFirst != itLast);
    int iDist = 1;
    {
      std::multiset<BdryNorm>::iterator itTemp = itFirst;
      itTemp++;
      while (itTemp != itLast) {
	itTemp++; iDist++;
      }
    }

    if (iDist >= 2) {
      assert(pV->iVertType() == Vert::eBdryApex);
      pV->vSetType(Vert::eBdryApex);
    }
    else {
      // There'd better be precisely two bdry edges:
      assert(iDist == 1);

      // Now check how close their normals are to being parallel.
      // Deviations of as much as 20 degrees are permitted.
      double dDot = dDOT2D(itFirst->adNormal(), itLast->adNormal());
      if (dDot < 0.94) {
	// This one is now an apex!
	pV->vSetType(Vert::eBdryApex);
      }
    }
    iRecordsChecked += iDist + 1;
    itFirst = ++itLast;
  } while (iRecordsChecked < 2*iNumBdryFaces());
}


// int Mesh2D::iQueueEncroachedBdryEntities(InsertionQueue& IQ,
// 					 const std::set<BFace*>& spBF) const
// {

//   // Now queue up all encroached bdry entities
//   // Can be used both to add all initially encroached BFaces and
//   // subsegments to the insertion queue and to subsequently add
//   // newly-created entities that are still encroached.

//   // If the list is empty, then we're in the interior and there's
//   // nothing to do.
//   if (spBF.empty()) return 0;

//   // If bdry's can't be changed, there's no point in queueing bdry
//   // entities.
//   if (!qBdryChangesAllowed()) return 0;

//   // First, check all the bdry faces...
//   int iAdded = 0;
//   vMessage(4, "%d bfaces, %d patches, %d periodic patches\n",
// 	   iNumBdryFaces(), B2DInfo.iNumPatches(), B2DInfo.iNumPeriodic());
//   std::set<BFace*>::iterator iterBF;
//   for (iterBF = spBF.begin(); iterBF != spBF.end(); iterBF++) {
//     BdryEdgeBase* pBE = (dynamic_cast<BdryEdgeBase*>(*iterBF));
//     if (pBE->eIsEncroached(eEncroachmentType()) != eClean) {
//       if (IQ.qAddEntry(InsertionQueueEntry(pBE))) {
// 	iAdded ++;
//       }
//       vMessage(4, "Queueing bdry edge (%10.6f, %10.6f) (%10.6f, %10.6f)\n",
// 	       pBE->pVVert(0)->dX(), pBE->pVVert(0)->dY(),
// 	       pBE->pVVert(1)->dX(), pBE->pVVert(1)->dY()); 
//       // Now add the periodic face if one exists.
//       BdryPatch* pBP = pBE->pPatchPointer();
//       if (pBP->qIsPeriodic()) {
// 	vMessage(4, "Is periodic!\n");
// 	Periodic *pP = pBP->pPGetPeriodicData();
// 	Face *pFOpp = const_cast<Face*>(pP->pFFaceOpposite(pBP, pBE->pFFace()));
// 	if (!pFOpp->qValid()) {
// 	  // There isn't a periodic face for this one yet; it'll be
// 	  // added in a subsequent insertion.
// 	  continue;
// 	}
// 	BdryEdgeBase* pBEOpp =
// 	  dynamic_cast<BdryEdgeBase*>(pFOpp->pCCellLeft());
// 	if (pBEOpp == NULL) {
// 	  pBEOpp = dynamic_cast<BdryEdgeBase*>(pFOpp->pCCellRight());
// 	}
// 	vMessage(4, "Queueing periodic pair (%10.6f, %10.6f) (%10.6f, %10.6f)\n",
// 		 pFOpp->pVVert(0)->dX(), pFOpp->pVVert(0)->dY(),
// 		 pFOpp->pVVert(1)->dX(), pFOpp->pVVert(1)->dY()); 
// 	assert(pBEOpp != NULL);
// 	assert(dynamic_cast<const BdryEdge*>(pBEOpp) != NULL);
// 	if (IQ.qAddEntry(InsertionQueueEntry(pBEOpp))) {
// 	  iAdded ++;
// 	}
//       } // Done with the periodic case.
//     } // Done with queueing an encroached BFace
//   } // Done with loop over all candidate BFace's
//   vMessage(3, "Added a total of %d encroached bdry edges to the queue.\n",
// 	   iAdded);
//   return iAdded;
// }

// int Mesh2D::iQueueEncroachedBdryEntities(InsertionQueue& IQ,
// 					 const std::set<BFace*>& spBF,
// 					 const double adLoc[],
// 					 const double dOffset) const
// {

//   // Now queue up all encroached bdry entities
//   // Can be used both to add all initially encroached BFaces and
//   // subsegments to the insertion queue and to subsequently add
//   // newly-created entities that are still encroached.

//   // If the list is empty, then we're in the interior and there's
//   // nothing to do.
//   if (spBF.empty()) return 0;

//   // If bdry's can't be changed, there's no point in queueing bdry
//   // entities.
//   if (!qBdryChangesAllowed()) return 0;

//   // First, check all the bdry faces...
//   int iAdded = 0;
//   vMessage(4, "%d bfaces, %d patches, %d periodic patches\n",
// 	   iNumBdryFaces(), B2DInfo.iNumPatches(), B2DInfo.iNumPeriodic());
//   std::set<BFace*>::iterator iterBF;
//   for (iterBF = spBF.begin(); iterBF != spBF.end(); iterBF++) {
//     BdryEdgeBase* pBE = (dynamic_cast<BdryEdgeBase*>(*iterBF));
//     if (pBE->eIsPointEncroaching(adLoc, eEncType, true) != eClean) {
//       if (IQ.qAddEntry(InsertionQueueEntry(pBE), dOffset)) {
// 	iAdded ++;
//       }
//       vMessage(4, "Queueing bdry edge (%10.6f, %10.6f) (%10.6f, %10.6f)\n",
// 	       pBE->pVVert(0)->dX(), pBE->pVVert(0)->dY(),
// 	       pBE->pVVert(1)->dX(), pBE->pVVert(1)->dY()); 
//       // Now add the periodic face if one exists.
//       BdryPatch* pBP = pBE->pPatchPointer();
//       if (pBP->qIsPeriodic()) {
// 	vMessage(4, "Is periodic\n");
// 	Periodic *pP = pBP->pPGetPeriodicData();
// 	Face *pFOpp = const_cast<Face*>(pP->pFFaceOpposite(pBP, pBE->pFFace()));
// 	if (!pFOpp->qValid()) {
// 	  // There isn't a periodic face for this one yet; it'll be
// 	  // added in a subsequent insertion.
// 	  continue;
// 	}
// 	BdryEdgeBase* pBEOpp =
// 	  dynamic_cast<BdryEdgeBase*>(pFOpp->pCCellLeft());
// 	if (pBEOpp == NULL) {
// 	  pBEOpp = dynamic_cast<BdryEdgeBase*>(pFOpp->pCCellRight());
// 	}
// 	vMessage(4, "Queueing periodic pair (%10.6f, %10.6f) (%10.6f, %10.6f)\n",
// 		 pFOpp->pVVert(0)->dX(), pFOpp->pVVert(0)->dY(),
// 		 pFOpp->pVVert(1)->dX(), pFOpp->pVVert(1)->dY()); 
// 	assert(pBEOpp != NULL);
// 	assert(dynamic_cast<const BdryEdge*>(pBEOpp) != NULL);
// 	if (IQ.qAddEntry(InsertionQueueEntry(pBEOpp))) {
// 	  iAdded ++;
// 	}
//       } // Done with the periodic case.
//     }
//   }
//   vMessage(3, "Added a total of %d encroached bdry edges to the queue.\n",
// 	   iAdded);
//   return iAdded;
// }

void Mesh2D::vBuildBdryPatches()
  // Given a Mesh2D (but no knowledge of the underlying geometry), make
  // a new set of patches, one per bdry face.  This is used, in
  // particular, to re-create bdry patch info after mesh coarsening.
{

  vFatalError("The function is no longer defined",
	      "Mesh2D::vBuildBdryPatches()");

//   int iBF;
//   int iNBFaces = iNumTotalBdryFaces();
//   int iNVerts = iNumVerts();

//   // Record the boundary condition and region info.
//   int *aiRightReg = new int[iNBFaces];
//   int *aiLeftReg  = new int[iNBFaces];
//   int *aiRightBC  = new int[iNBFaces];
//   int *aiLeftBC   = new int[iNBFaces];

//   for (iBF = 0; iBF < iNBFaces; iBF++) {
//     BFace *pBF = pBFBFace(iBF);
//     Face *pF = pBF->pFFace(0);
//     Cell *pC = pF->pCCellOpposite(pBF);
//     assert(pC->eType() == Cell::eTriCell);

//     Vert *pV0 = pBF->pVVert(0);
//     Vert *pV1 = pBF->pVVert(1);
//     Vert *pVOpp = dynamic_cast<TriCell*>(pC)->pVVertOpposite(pF);

//     int iOrient = iOrient2D(pV0, pV1, pVOpp);
//     bool qIntBFace = (pBF->iNumFaces() == 2);

//     if (qIntBFace) {
//       // Internal bdry face!

//       // FIX ME!  Untested code, because coarsening with internal bdrys
//       // hasn't been written yet.

//       assert(pBF->eType() == Cell::eIntBdryEdge);
//       // Identify the other cell
//       Face *pFAlt = pBF->pFFace(1);
//       Cell *pCAlt = pFAlt->pCCellOpposite(pBF);

//       // Get regions on both sides.
//       switch (iOrient) {
//       case 1:
// 	aiLeftReg[iBF]  = pC   ->iRegion();
// 	aiRightReg[iBF] = pCAlt->iRegion();
// 	break;
//       case -1:
// 	aiLeftReg[iBF]  = pCAlt->iRegion();
// 	aiRightReg[iBF] = pC   ->iRegion();
// 	break;
//       default:
// 	// Unreachable for valid meshes
// 	assert(0);
// 	break;
//       }
//       aiRightBC[iBF] = aiLeftBC[iBF] = iInvalidBC;
//     }
//     else { // Regular bdry face
//       aiRightReg[iBF] = aiLeftReg[iBF] = iInvalidRegion;
//       aiRightBC[iBF]  = aiLeftBC[iBF]  = iInvalidBC;

//       // Get regions on both sides.
//       switch (iOrient) {
//       case 1:
// 	aiLeftReg[iBF]  = pC ->iRegion();
// 	aiRightBC[iBF]  = pBF->iBdryCond();
// 	break;
//       case -1:
// 	aiRightReg[iBF] = pC ->iRegion();
// 	aiLeftBC[iBF]   = pBF->iBdryCond();
// 	break;
//       default:
// 	// Unreachable for valid meshes
// 	assert(0);
// 	break;
//       }
//     } // Done with real bdry faces
//     // Do some post-checking to be sure this matches qualitatively with
//     // the data for the patch.
// #ifndef NDEBUG
//     BdryPatch *pBP = pBF->pPatchPointer();
//     assert( ( aiRightReg[iBF] == pBP->iRightRegion() ||
// 	      aiRightReg[iBF] == pBP->iLeftRegion() )
// 	    &&
// 	    ( aiLeftReg[iBF]  == pBP->iRightRegion() ||
// 	      aiLeftReg[iBF]  == pBP->iLeftRegion() ) );
//     assert( ( aiRightBC[iBF] == pBP->iBdryCond() ||
// 	      aiRightBC[iBF] == iInvalidBC )
// 	    &&
// 	    ( aiLeftBC[iBF]  == pBP->iBdryCond() ||
// 	      aiLeftBC[iBF]  == iInvalidBC ) );
// #endif
//   } // End of loop over BFaces


//   // Throw away all the existing bdry patch info.
//   B2DInfo.vSetSize(iNBFaces, iNVerts);
//   B2DInfo.vClearPoints();

//   // Now begin again, creating a new bdry patch for every BdryEdge.

//   // Need to map vertex indices to point indices in the Bdry2D
//   // struct, since Bdry2D no longer uses vertices directly.  This
//   // mapping is stored in the following array.
//   int *aiVertMap = new int[iNVerts];
//   int iV;
//   for (iV = 0; iV < iNVerts; aiVertMap[iV++] = -1);

//   int iBPt = 0;
//   for (iBF = 0; iBF < iNBFaces; iBF++) {
//     BFace *pBF = pBFBFace(iBF);
//     int iV0 = iVertIndex(pBF->pVVert(0));
//     int iV1 = iVertIndex(pBF->pVVert(1));

//     if (aiVertMap[iV0] == -1) {
//       aiVertMap[iV0] = iBPt;
//       B2DInfo.vAddPoint(pVVert(iV0)->adCoords());
//       B2DInfo.vSetBdryPoint(iBPt, false);
//       iBPt++;
//     }

//     if (aiVertMap[iV1] == -1) {
//       aiVertMap[iV1] = iBPt;
//       B2DInfo.vAddPoint(pVVert(iV1)->adCoords());
//       B2DInfo.vSetBdryPoint(iBPt, false);
//       iBPt++;
//     }

//     int iBP0 = aiVertMap[iV0];
//     int iBP1 = aiVertMap[iV1];
//     assert(iBP0 >= 0 && iBP1 >= 0);

//     BdryPatch2D *pBP =
//       new BdrySeg(&B2DInfo, aiLeftBC[iBF], aiRightBC[iBF], aiLeftReg[iBF],
// 		  aiRightReg[iBF], iBP0, iBP1);
//     B2DInfo.vAddPatchToList(pBP);
//     // vSetPatch can handle getting the patch for an internal bdry
//     // fixed up, too.
//     (dynamic_cast<BdryEdgeBase*>(pBF))->vSetPatch(iBF, &B2DInfo);
//   } // Done with boundary cases
//   delete [] aiVertMap;

//   if (!(qValid ()))
//     vFoundBug ("building 2D boundary data from mesh");
}

// Find the cell incident on pV0 that lies astride the direction to pV1.
Cell* Mesh2D::pCBeginPipe(const Vert* const pV0, const Vert* const pV1) const
{
  std::set<Cell*> spCInc;
  std::set<Vert*> spVTmp;
  vNeighborhood(pV0, spCInc, spVTmp);

  // Now check out each cell.
  std::set<Cell*>::iterator iterC;
  for (iterC = spCInc.begin(); iterC != spCInc.end(); iterC++) {
    assert((*iterC)->eType() == Cell::eTriCell);
    TriCell *pTCCand = dynamic_cast<TriCell*>(*iterC);
    assert(pTCCand->qHasVert(pV0));

    Face *pFOpp = pTCCand->pFFaceOpposite(pV0);
    Vert *pVA = pFOpp->pVVert(0);
    Vert *pVB = pFOpp->pVVert(1);

    int iOrientA = iOrient2D(pVA, pV0, pV1);
    int iOrientB = iOrient2D(pVB, pV0, pV1);

    if (iOrientA != iOrientB) {
      // pV1 falls between the lines determined by (pVA, pV0) and (pVB,
      // pV0), or on one of them.  Now, to eliminate a cell that happens
      // to point away from pV1, look at barycentrics.
      double adBary[3];
      pTCCand->vBarycentrics(pV1->adCoords(), adBary);
      int iNegBary = ((adBary[0] < -1.e-10 ? 1 : 0) +
		      (adBary[1] < -1.e-10 ? 1 : 0) +
		      (adBary[2] < -1.e-10 ? 1 : 0));
      int iZeroBary = ((fabs(adBary[0]) < 1.e-10 ? 1 : 0) +
		       (fabs(adBary[1]) < 1.e-10 ? 1 : 0) +
		       (fabs(adBary[2]) < 1.e-10 ? 1 : 0));
      // Combinations of result values:
      // iNeg iZero Case
      //   0    0   pV1 inside pTCCand (Hit!)
      //   0    1   pV1 on pTCCand (Hit!)
      //   0    2   pV1 is a vertex of pTCCand (Hit!)
      //   1    0   pV1 is in the "wedge" of pTCCand but beyond its face
      //              opposite pV0 (Hit! You sunk my battleship!)
      //   1    1   Can't tell yet whether pV1 is on the "proper" side
      //            of pV0 for pTCCand to be the right choice or not. (?)
      //   2    0   pV1 is in the "reverse wedge" of pTCCand (i.e., the
      //            ray from pV0 to pV1 is headed in the opposite
      //            direction to pTCCand) (Miss!)
      if (iNegBary == 0 || (iNegBary == 1 && iZeroBary == 0)) {
	return pTCCand;
      }
      else if (iNegBary == 1 && iZeroBary == 1) {
	// Need to find out whether the edge of pTCCand that is
	// collinear with pV1 is pointing in the same or the opposite
	// direction as pV1.
	assert(iOrientA == 0 || iOrientB == 0);
	Vert *pVTest = (iOrientA == 0) ? pVA : pVB;
	double adVecTest[] = adDIFF2D(pVTest->adCoords(),
				      pV0->adCoords());
	double adVec1[]    = adDIFF2D(pV1->adCoords(),
				      pV0->adCoords());
	double dDot = dDOT2D(adVecTest, adVec1);
	if (dDot > 0)
	  return pTCCand;
	else {
	  // Wrong choice; keep checking
	}
      }
      else {
	// Do nothing; this cell isn't the right one, so keep checking.
      }
    }
  }
  assert(0);
  return pCInvalidCell;
}

void Mesh2D::
vWriteBdryPatchFile(const char strBaseFileName[],
		    const char strExtraFileSuffix[]) const {

  SUMAA_LOG_EVENT_BEGIN(OUTPUT);

  // I can't imagine why this assertion is needed.
  //  assert(qSimplicial());

  FILE *output_file = NULL;
  char filename[1024];
  sprintf(filename, "%s.bpatch%s", strBaseFileName, strExtraFileSuffix);

  /*newfile mesh*/
  vMessage(0, "Opening boundary patch output file %s\n", filename);
  
  if(output_file) fclose(output_file);
  
  output_file = fopen(filename, "w");
  if (NULL == output_file)
    vFatalError("Could not open boundary patch output file for writing",
                "Mesh2D::vWriteBdryPatchFile()");

  int num_gauss_points = 18;
  double beg_ratio[num_gauss_points],
         mid_ratio[num_gauss_points],
         end_ratio[num_gauss_points];
  
  // useful constant.
  double S = 0.5 * (1. + sqrt(1./3.));

  // one gauss point
  beg_ratio[0] = 0.;
  mid_ratio[0] = 0.5;
  end_ratio[0] = 1.;

  // two gauss points
  beg_ratio[1] = beg_ratio[0];
  mid_ratio[1] = 1. - S;
  end_ratio[1] = 0.5;
  
  beg_ratio[2] = end_ratio[1];
  mid_ratio[2] = S;
  end_ratio[2] = end_ratio[0];

  // three gauss points
  beg_ratio[3] = beg_ratio[0];
  mid_ratio[3] = 0.5 - sqrt(0.15);
  end_ratio[3] = 5. / 18.;

  beg_ratio[4] = end_ratio[3];
  mid_ratio[4] = 0.5;
  end_ratio[4] = 13. / 18.;

  beg_ratio[5] = end_ratio[4];
  mid_ratio[5] = 0.5 + sqrt(0.15);
  end_ratio[5] = end_ratio[0];

  // two times one gauss points
  beg_ratio[6] = beg_ratio[0];
  mid_ratio[6] = 0.25;
  end_ratio[6] = 0.5;

  beg_ratio[7] = end_ratio[6];
  mid_ratio[7] = 0.75;
  end_ratio[7] = end_ratio[0];

  // two times two gauss points
  beg_ratio[8] = beg_ratio[0];
  mid_ratio[8] = 0.5 * (1. - S);
  end_ratio[8] = 0.25;

  beg_ratio[9] = end_ratio[8];
  mid_ratio[9] = 0.5 * S;
  end_ratio[9] = 0.5;

  beg_ratio[10] = end_ratio[9];
  mid_ratio[10] = 1. - mid_ratio[9];
  end_ratio[10] = 0.75;

  beg_ratio[11] = end_ratio[10];
  mid_ratio[11] = 0.5 * (1. + S);
  end_ratio[11] = end_ratio[0];

  // two times three gauss points
  beg_ratio[12] = beg_ratio[0];
  mid_ratio[12] = 0.5 * (0.5 - sqrt(0.15));
  end_ratio[12] = 5. / 36.;

  beg_ratio[13] = end_ratio[12];
  mid_ratio[13] = 0.25;
  end_ratio[13] = 13. / 36.;

  beg_ratio[14] = end_ratio[13];
  mid_ratio[14] = 0.5 * (0.5 + sqrt(0.15));
  end_ratio[14] = 0.5;

  beg_ratio[15] = end_ratio[14];
  mid_ratio[15] = 0.5 * (1.5 - sqrt(0.15));
  end_ratio[15] = 0.5 + 5. / 36.;

  beg_ratio[16] = end_ratio[15];
  mid_ratio[16] = 0.75;
  end_ratio[16] = 0.5 + 13. / 36.;

  beg_ratio[17] = end_ratio[16];
  mid_ratio[17] = 0.5 * (1.5 + sqrt(0.15));
  end_ratio[17] = end_ratio[0];

//   for(int i = 0; i < 18; i++) {
//     printf("i = %d, beg = %e, mid = %e, end = %e\n", 
// 	   i, beg_ratio[i], mid_ratio[i], end_ratio[i]);
//   }

  ///

  int num_faces = iNumFaces();
  double beg_param, end_param, gauss_param, face_length;
  
  GRCurve* curve = NULL;
  Face* face = NULL;
  BdryEdgeBase* bdry_edge = NULL;

  CubitVector gauss_coord, normal;
  bool reverse_normal;

  for(int i = 0; i < num_faces; i++) {

    face = pFFace(i);    
    if(face->qDeleted()) continue;

    reverse_normal = false;

    if(face->qIsBdryFace()) {

      bdry_edge = dynamic_cast<BdryEdgeBase*>(face->pCCellLeft());
      if(!bdry_edge) {
	bdry_edge = dynamic_cast<BdryEdgeBase*>(face->pCCellRight());
	assert(bdry_edge);
	if(!bdry_edge->is_forward()) reverse_normal = true;
      }
      else {
	if(!bdry_edge->is_forward()) reverse_normal = true;
      }

      curve = bdry_edge->get_curve();

      if (bdry_edge->is_forward()) {
        beg_param = bdry_edge->vert0_param();
        end_param = bdry_edge->vert1_param();
      }
      else { 
        beg_param = bdry_edge->vert1_param();
        end_param = bdry_edge->vert0_param();
      }
      assert(iFuzzyComp(beg_param, end_param) == -1);

      face_length = curve->geom_ptr()->arc_length(beg_param, end_param);

    }
    
    else 
      continue;

    fprintf(output_file, "%d\n", i);

    for(int j = 0; j < num_gauss_points; j++) {
      
      gauss_param = curve->geom_ptr()->param_at_arc_length( beg_param , mid_ratio[j] * face_length );
      
      curve->geom_ptr()->coord_at_param( gauss_param, gauss_coord );
      curve->geom_ptr()->unit_normal( gauss_param, normal );
      if(reverse_normal) normal *= -1.;
      
      fprintf(output_file, "%.16g %.16g %.16g %.16g %.16g\n", 
	      gauss_coord.x(), gauss_coord.y(), 
	      normal.x(), normal.y(), 
	      (end_ratio[j] - beg_ratio[j]) * face_length );

    }

    fprintf(output_file, "\n");

  }

  fclose(output_file);

  SUMAA_LOG_EVENT_END(OUTPUT);

}

bool Mesh2D::qCreateQuadFromTris(Cell* const pCA,
				 Cell* const pCB)
{
  assert(pCA->iNumVerts() == 3);
  assert(pCB->iNumVerts() == 3);
  assert(dynamic_cast<const TriCell*>(pCA) != NULL);
  assert(dynamic_cast<const TriCell*>(pCB) != NULL);

  Face *pFCommon = pFCommonFace(pCA, pCB);
  if (!pFCommon->qValid()) return false;

  int iReg = pCA->iRegion();
  if (pCB->iRegion() != iReg) return false;

  Face *apFOuter[4];
  int iF, iFOuter = 0;
  for (iF = 0; iF < 3; iF++) {
    Face *pF = pCA->pFFace(iF);
    if (pF != pFCommon) {
      apFOuter[iFOuter++] = pF;
    }

    pF = pCB->pFFace(iF);
    if (pF != pFCommon) {
      apFOuter[iFOuter++] = pF;
    }
  }
  
  deleteCell(pCA);
  deleteCell(pCB);

  Cell *pCQuad = createQuadCell(apFOuter[0], apFOuter[1],
				apFOuter[2], apFOuter[3], iReg); 

  assert(pCQuad->qValid());
  assert(apFOuter[0]->qValid());
  assert(apFOuter[1]->qValid());
  assert(apFOuter[2]->qValid());
  assert(apFOuter[3]->qValid());

  return true;
}


bool Mesh2D::qCreateQuadFromVerts(Vert* const pVA, Vert* const pVB,
				  Vert* const pVC, Vert* const pVD)
{
  // Vertices must be specified in cyclic order.  These checks verify that.
  assert(iOrient2D(pVA, pVB, pVC) == 1);
  assert(iOrient2D(pVB, pVC, pVD) == 1);
  assert(iOrient2D(pVC, pVD, pVA) == 1);
  assert(iOrient2D(pVD, pVA, pVB) == 1);

  // Step one: ensure that all the perimeter edges exist, or swap for them.
  // Because the edges are known to be non-intersecting (based on the
  // previous assertions), then recovering all four of them should be
  // trivial.  Collect face ID's as you go.
  Face *pFAB, *pFBC, *pFCD, *pFDA;
  bool qRes = qRecoverEdge(pVA, pVB, pFAB) &&
    qRecoverEdge(pVB, pVC, pFBC) &&
    qRecoverEdge(pVC, pVD, pFCD) &&
    qRecoverEdge(pVD, pVA, pFDA);
  if (!(qRes && pFAB->qValid() && pFBC->qValid() &&
	pFCD->qValid() && pFDA->qValid() &&
	!pFAB->qDeleted() && !pFBC->qDeleted() &&
	!pFCD->qDeleted() && !pFDA->qDeleted() && 
	pFAB->qHasVert(pVA) && pFAB->qHasVert(pVB) &&
	pFBC->qHasVert(pVB) && pFBC->qHasVert(pVC) &&
	pFCD->qHasVert(pVC) && pFCD->qHasVert(pVD) &&
	pFDA->qHasVert(pVD) && pFDA->qHasVert(pVA))) {
    // Something bad, and unexpected, just happened!
    return false;
  }  

  // Step two: identify triangles and interior edge for quad creation.
  // Each edge must share a triangle with one of the adjacent edges; we
  // just need to find out which is which.
  Cell* pCQuad;

  Cell *pC1, *pC2;
  pC1 = pCCommonCell(pFAB, pFBC);
  Face *pFCommon = pFInvalidFace;
  if (pC1 == pCInvalidCell) {
    // So pFAB and pFDA have a common tri, as do pFBC and pFCD
    pC1 = pCCommonCell(pFAB, pFDA);
    pC2 = pCCommonCell(pFBC, pFCD);
  }
  else {
    // The other tri is shared by pFCD and pFDA
    pC2 = pCCommonCell(pFCD, pFDA);
  }
  if ((pC1 == pCInvalidCell) || (pC2 == pCInvalidCell)) {
    // In this case, there's some vert inside the alleged quad; bail!
    return false;
  }
  pFCommon = pFCommonFace(pC1, pC2);
  assert(pFCommon != pFInvalidFace);

  int iReg = pC1->iRegion();
  if (pC2->iRegion() != iReg) return false;

  deleteCell(pC1);
  deleteCell(pC2);

  pCQuad = createQuadCell(pFAB, pFBC, pFCD, pFDA, iReg);

  assert(pCQuad->qValid());
  assert(pFAB->qValid());
  assert(pFBC->qValid());
  assert(pFCD->qValid());
  assert(pFDA->qValid());

#ifndef NDEBUG
  Vert *pV0 = pFCommon->pVVert(0);
  Vert *pV1 = pFCommon->pVVert(1);

  assert(pV0->pFHintFace() != pFCommon && pV0->pFHintFace()->qHasVert(pV0));
  assert(pV1->pFHintFace() != pFCommon && pV1->pFHintFace()->qHasVert(pV1));
#endif
  return true;
}
