#include "GR_Mesh2D.h"
#include "GR_AdaptPred.h"

#include "GR_InsertionQueue.h"
#include "GR_InsertionQueueEntry.h"
#include "GR_Geometry.h"
#include "CubitVector.hpp"

#include "GR_GRCurve.h"

#include <set>
#include <map>
#include <vector>
#include <deque>
#include <queue>
#include <algorithm>
#include <functional>
#include <iterator>
#include <utility>

using std::map;
using std::set;
using std::queue;
using std::vector;
using std::deque;
using std::pair;
using std::multimap;

#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Vertex.h"

struct RemoveVertFromMesh {

  Mesh* m_mesh;
  std::vector<Cell*>* m_new_cells;
  
  RemoveVertFromMesh(Mesh2D* const mesh,
		     std::vector<Cell*>* new_cells = NULL) 
    : m_mesh(mesh), m_new_cells(new_cells)  
  { assert(m_mesh->qSimplicial()); }
  
  void operator()(Vert* const vertex) {
    
    assert(!vertex->qDeleted());
    assert(vertex->iVertType() == Vert::eInterior);

    Face* face = vertex->pFHintFace();

    assert(face->iFaceLoc() == Face::eInterior);
    assert(face->pCCellLeft()->eType() == Cell::eTriCell);

    int region = face->pCCellLeft()->iRegion();
    int num_cells_before = m_mesh->iNumCells();
    int num_swaps;
  
#ifndef NDEBUG
    bool success = m_mesh->qRemoveVert(vertex, num_swaps);
    assert(success);
#else
    m_mesh->qRemoveVert(vertex, num_swaps);
#endif  

    int num_cells_after = m_mesh->iNumCells();

    for(int i = num_cells_before; i < num_cells_after; i++) {
      
      Cell* cell = m_mesh->pCCell(i);
      assert(!cell->qDeleted());
      assert(cell->eType() == Cell::eTriCell);
      
      cell->vSetRegion(region);
      assert(cell->iRegion() > 0);

      if(m_new_cells) m_new_cells->push_back(cell);

    }

  }

};

int Mesh2D::
iInsertPointWatson(WatsonInfo&) {

  vFatalError("This refinement interface is no longer working in 2D.",
	      "Mesh2D::iInsertPointWatson(WatsonInfo&)");

}

void Mesh2D::
insert_watson(const CubitVector& insert_location,
	      Cell* seed_cell,
	      const std::set<Cell*>* seed_guesses,
	      std::vector<Cell*>* new_cells,
	      std::vector<Face*>* new_faces) {

  assert(0); //not tested

  WatsonData watson_data;

  Vert* new_vert = createVert(insert_location.x(),
			      insert_location.y());

  if(!seed_cell && seed_guesses) {
  
    if(!seed_guesses->empty())
      seed_cell = find_seed_guesses(new_vert, seed_guesses);
    else
      seed_cell = find_seed_naively(new_vert);
  
  }

  else if(!seed_cell && !seed_guesses)
    seed_cell = find_seed_naively(new_vert);

  assert(seed_cell);
  assert(seed_cell->qValid());

  compute_watson_data(new_vert, seed_cell, watson_data);

  //No encroached edge was found. Insert in the interior

  if(watson_data.encroached_bdry_edges.empty()) {
    insert_watson_interior(new_vert, watson_data, new_cells, new_faces);
    return;
  }  

  //At least one edge is encroached by the proposed insertion location.
  //We need to split edges until none are encroached.

  deleteVert(new_vert);

  std::deque<BdryEdgeBase*> encroached_queue;
  encroached_queue.push_back( *(watson_data.encroached_bdry_edges.begin()) );

  BdryEdgeBase* bdry_edge = NULL;
    
  while(!encroached_queue.empty()) {

    bdry_edge = encroached_queue.front();
    encroached_queue.pop_front();
    
    CubitVector split_location;
    bool concentric_shell_split;
    double split_param = bdry_edge->get_split_data(BdryEdgeBase::MID_TVT, 
						   split_location, 
						   concentric_shell_split);
  
    new_vert = createVert(split_location.x(),
			  split_location.y());
    new_vert->vSetType(Vert::eBdryCurve);
    new_vert->set_parent_entity(bdry_edge->get_curve());
    if(concentric_shell_split) new_vert->set_shell_vert(true);

    //Compute Watson hull.
    compute_watson_data(new_vert, bdry_edge, watson_data, true, false);

    //Queue boundary edges getting encroached by this insertion.
    std::copy(watson_data.encroached_bdry_edges.begin(),
	      watson_data.encroached_bdry_edges.end(),
	      std::back_inserter(encroached_queue));

    //Split the boundary
    insert_watson_boundary(new_vert, bdry_edge, 
			   watson_data, split_param, 
			   new_cells, new_faces);

  }

}

void Mesh2D::
insert_watson_interior(Vert* const new_vert,
		       WatsonData& watson_data,
		       vector<Cell*>* new_cells,
		       vector<Face*>* new_faces) {

#ifndef NDEBUG

  assert(watson_data.encroached_bdry_edges.empty());
  assert(!watson_data.cells_to_remove.empty());
  assert(!watson_data.hull_faces.empty());

  if(watson_data.cells_to_remove.size() == 1)
    assert(watson_data.faces_to_remove.empty());
  else
    assert(!watson_data.faces_to_remove.empty());

#endif

  SUMAA_LOG_EVENT_BEGIN(WATSON_INSERT);

  delete_watson_hull( watson_data.cells_to_remove, 
		      watson_data.faces_to_remove );
  
  //Reconnect hull. Their will be one new cell per hull face.

  reconnect_watson_hull(new_vert, watson_data.hull_faces,
			new_cells, new_faces);

  SUMAA_LOG_EVENT_END(WATSON_INSERT);

}

Mesh2D::BEdgePair Mesh2D::
insert_watson_boundary(Vert* const new_vert,
		       BdryEdgeBase* const edge_to_split,
		       WatsonData& watson_data,
		       double new_param,
		       vector<Cell*>* new_cells,
		       vector<Face*>* new_faces) {

#ifndef NDEBUG

  if(watson_data.cells_to_remove.empty()) {
    assert(watson_data.faces_to_remove.empty());
    //Pretty sure this can only happen for exterior boundaries.
    assert(edge_to_split->iNumFaces() == 1);
//     if(edge_to_split->iNumFaces() == 1)
//       assert(watson_data.hull_faces.size() == 1);
//     else if(edge_to_split->iNumFaces() == 2)
//       assert(watson_data.hull_faces.size() == 2);
//     else assert(0);
  }
  else {
    assert(!watson_data.faces_to_remove.empty());
    assert(!watson_data.hull_faces.empty());
  }

#endif

  SUMAA_LOG_EVENT_BEGIN(WATSON_INSERT);

  GRCurve* curve = edge_to_split->get_curve();
  bool forward   = edge_to_split->is_forward();

  Vert* beg_vert = forward ? edge_to_split->pVVert(0) : edge_to_split->pVVert(1);
  Vert* end_vert = forward ? edge_to_split->pVVert(1) : edge_to_split->pVVert(0);

  double beg_param = forward ? 
    edge_to_split->vert0_param() : edge_to_split->vert1_param();
  double end_param = forward ? 
    edge_to_split->vert1_param() : edge_to_split->vert0_param();

  assert( iFuzzyComp(beg_param, end_param) == -1 );
  assert( iFuzzyComp(beg_param, new_param) == -1 );
  assert( iFuzzyComp(new_param, end_param) == -1 );

  //Delete the Watson hull: Complications for curved boundaries.
  //Indeed, it is possible, when a vertex is inserted on a curve, 
  //that the first triangle neighborhing the boundary edge getting
  //split does not contain the new vertex in its circumcircle.
  //Therefore, it does not get removed from the mesh.
  
  //If and when this situation happens, the face sharing the boundary
  //edge becomes an interior face, part of the Watson hull. This is taken
  //care in the following switch, both for interior and exterior boundaries.
  
  //If the first neighboring cell is not included, then we proceed as usual.

  switch(edge_to_split->iNumFaces()) {

  case 1: {
    //Regular boundary face. If the first cell by the face is not
    //in cells_to_remove, then cells_to_remove must be empty. 
    assert(edge_to_split->eType() == Cell::eBdryEdge);
    assert(edge_to_split->iNumFaces() == 1);
    Cell* cell0 = edge_to_split->pFFace(0)->pCCellOpposite(edge_to_split);
    assert(cell0->eType() == Cell::eTriCell);
    if(watson_data.cells_to_remove.count(cell0) == 0) {
      assert(watson_data.cells_to_remove.empty());
      assert(watson_data.faces_to_remove.empty());
      assert(watson_data.hull_faces.size() == 1);
      assert(watson_data.hull_faces.begin()->first == edge_to_split->pFFace(0));
      edge_to_split->pFFace(0)->vSetFaceLoc(Face::eInterior);
    }
    break;
  }

  case 2: {
    //Internal boundary face. One of the two neighboring cells
    //might not be in the cells_to_remove, but definitely not both.
    assert(edge_to_split->eType() == Cell::eIntBdryEdge);
    assert(edge_to_split->iNumFaces() == 2);
    Cell* cell0 = edge_to_split->pFFace(0)->pCCellOpposite(edge_to_split);
    Cell* cell1 = edge_to_split->pFFace(1)->pCCellOpposite(edge_to_split);
    assert(cell0->eType() == Cell::eTriCell);
    assert(cell1->eType() == Cell::eTriCell);
    if(watson_data.cells_to_remove.count(cell0) == 0) {
      assert(watson_data.hull_faces.count(edge_to_split->pFFace(0)) == 1);
      assert(watson_data.faces_to_remove.count(edge_to_split->pFFace(0)) == 0);
      edge_to_split->pFFace(0)->vSetFaceLoc(Face::eInterior);
    }
    if(watson_data.cells_to_remove.count(cell1) == 0) {
      assert(watson_data.hull_faces.count(edge_to_split->pFFace(1)) == 1);
      assert(watson_data.faces_to_remove.count(edge_to_split->pFFace(1)) == 0);
      edge_to_split->pFFace(1)->vSetFaceLoc(Face::eInterior);
    }
    assert(watson_data.cells_to_remove.count(cell0) == 1 ||
	   watson_data.cells_to_remove.count(cell1) == 1);
    break;
  }
  }

  delete_watson_hull( watson_data.cells_to_remove,
		      watson_data.faces_to_remove, edge_to_split );

  //Reconnect the emptied Watson hull:
  vector<Face*> new_faces_local;
  reconnect_watson_hull(new_vert, watson_data.hull_faces,
			new_cells, &new_faces_local);

  if(new_faces) *new_faces = new_faces_local;

  Face *face1 = static_cast<Face*>(NULL), 
       *face2 = static_cast<Face*>(NULL);

  vector<Face*>::iterator it     = new_faces_local.begin(),
                          it_end = new_faces_local.end();

  do {

    Face* face = *it;

    if(!face1 && face->qHasVert(beg_vert))      face1 = face;
    else if(!face2 && face->qHasVert(end_vert)) face2 = face;

  } while( ++it != it_end || (!face1 || !face2) );

  assert(face1 && face2);

  BdryEdgeBase *new_bedge1, *new_bedge2;
  if (curve->region_left() != 0 && curve->region_right() != 0) {
    new_bedge1 = createIntBdryEdge(beg_vert, new_vert, curve,
				   beg_param, new_param);
    new_bedge2 = createIntBdryEdge(new_vert, end_vert, curve,
				   new_param, end_param);
  }
  else {
    new_bedge1 = createBdryEdge(beg_vert, new_vert, curve,
				beg_param, new_param);
    new_bedge2 = createBdryEdge(new_vert, end_vert, curve,
				new_param, end_param);
  }
  assert(new_bedge1 && new_bedge2);

  SUMAA_LOG_EVENT_END(WATSON_INSERT);

  return std::make_pair(new_bedge1, new_bedge2);

}

void Mesh2D::
delete_verts_in_edge_ball(BdryEdgeBase* const edge_to_split,
			  vector<Cell*>* new_cells) {
  
  double radius = 0.5 * edge_to_split->length();
  CubitVector midpoint = edge_to_split->mid_point(); 
  CubitVector vert_coord(0., 0., 0.);

  queue<Cell*> cells_to_test;
  set<Cell*> cells_tested;
  set<Vert*> verts_tested;
  set<Vert*> verts_to_delete;

  int i, j;

  for(i = 0; i < edge_to_split->iNumFaces(); i++) 
    cells_to_test.push( edge_to_split->pFFace(i)->pCCellOpposite(edge_to_split) );

  while( !cells_to_test.empty() ) {
    Cell* cell = cells_to_test.front();
    cells_to_test.pop();

    assert(!cell->qDeleted());
    if( cell->eType() != Cell::eTriCell ) continue;
    if( !cells_tested.insert(cell).second ) continue;

    for(i = 0; i < 3; i++) {
      
      Vert* vertex = cell->pVVert(i);
      
      if(vertex->iVertType() != Vert::eInterior) continue;

      if( verts_tested.insert(vertex).second ) {
	
	vert_coord.set(vertex->dX(), vertex->dY(), 0.);

	if( iFuzzyComp((midpoint - vert_coord).length(), radius) != 1 ) {

	  verts_to_delete.insert(vertex);
	    
	  for(j = 0; j < 3; j++) 
	    cells_to_test.push(cell->pFFace(j)->pCCellOpposite(cell));
	    
	}

      }

    }

  }

  //No point in continuing if there is no vert to delete.
  if(verts_to_delete.empty()) return;

  std::for_each( verts_to_delete.begin(),
		 verts_to_delete.end(),
		 RemoveVertFromMesh(this, new_cells) );

}

/// This function removes all cells and faces in the Watson hull.
/// Probably pretty easy to make generic for 2D/surface/3D.  Also, at
/// present at least, the set<Face*>& argument is not used.
/// @param cells_to_remove A std::set<Cell*> whose members should be
/// removed from the mesh.
/// @param faces_to_remove A std::set<Face*> whose members should be
/// removed from the mesh.
/// @param edge_to_split A BdryEdgeBase*, which if non-NULL points to a
/// bdry edge that is being split during this Watson insertion.
void Mesh2D::
delete_watson_hull(set<Cell*>& cells_to_remove,
		   set<Face*>& /*faces_to_remove*/,
		   BdryEdgeBase* const edge_to_split) { 

  //Mark boundary edge as deleted (if not NULL)
  if(edge_to_split) deleteBFace(edge_to_split);

  //Mark cells as deleted; their common faces are also deleted once
  //they're no longer in use.
  set<Cell*>::iterator iter = cells_to_remove.begin();
  set<Cell*>::iterator iterEnd = cells_to_remove.end();
  for ( ; iter != iterEnd; iter++) {
    Cell *pC = *iter;
    deleteCell(pC);
  }
}

void Mesh2D::
reconnect_watson_hull(Vert* const new_vertex,
		      const map<Face*, int>& hull_faces,
		      vector<Cell*>* new_cells,
		      vector<Face*>* new_faces) {

  typedef map<Vert*, Face*> VertFaceMap;
  typedef VertFaceMap::iterator ItVertFace;
  typedef pair<ItVertFace, bool> VertFaceInsert;

  VertFaceMap vert_face_map;

  GR_index_t local_new_cells_start = 0;
  if (new_cells) local_new_cells_start = new_cells->size();
  
  map<Face*, int>::const_iterator itf     = hull_faces.begin();
  map<Face*, int>::const_iterator itf_end = hull_faces.end();  

  for( ; itf != itf_end; ++itf) {
    // Create all the new cells the easy way
    Face* hull_face = itf->first;
    int   region    = itf->second;

    Cell *pCNew = createTriCell(hull_face->pVVert(0), hull_face->pVVert(1),
				new_vertex, region);
    if (new_cells) new_cells->push_back(pCNew);

#ifndef NDEBUG

    SUMAA_LOG_EVENT_BEGIN(WATSON_CHECK);
 
    assert(hull_face->iFullCheck() == 1);
    assert(pCNew->iFullCheck() == 1);
    assert(iOrient2D(pCNew->pVVert(0), 
		     pCNew->pVVert(1), 
		     pCNew->pVVert(2)) == 1);
    
    SUMAA_LOG_EVENT_END(WATSON_CHECK);
  
#endif

  }

  if (new_faces) {
    assert(new_cells);
    for (GR_index_t i = local_new_cells_start; i < new_cells->size(); i++) {
      Cell* pC = (*new_cells)[i];
      for (int ii = 0; ii < 3; ii++) {
	Face *pF = pC->pFFace(ii);
	if (hull_faces.find(pF) == hull_faces.end()) {
	  new_faces->push_back(pF);
	}
      }
    }
  }
    

}

void Mesh2D::
vGetWatsonData(const double adPoint[3],
	       Cell* const pCSeed,
	       std::set<Cell*>& spCSearch,
	       std::set<Face*>& spFHull,
	       std::set<Face*>& spFToRemove,
	       std::set<BFace*>& spBFEncroached) const {

  WatsonData watson_data;
  CubitVector point(adPoint[0], adPoint[1], adPoint[2]);
 
  compute_watson_data(point, pCSeed, watson_data);

  spCSearch      = watson_data.cells_to_remove;
  spFToRemove    = watson_data.faces_to_remove;
  
  std::copy(watson_data.encroached_bdry_edges.begin(),
	    watson_data.encroached_bdry_edges.end(),
	    std::inserter(spBFEncroached, spBFEncroached.end()));

//   std::copy( watson_data.hull_faces.begin(), watson_data.hull_faces.end(),
// 	     std::compose1 ( std::inserter(spFHull, spFHull.end()),
// 			     std::select1st< map<Face*, int>::value_type > );

  map<Face*, int>::iterator it     = watson_data.hull_faces.begin(),
                            it_end = watson_data.hull_faces.end();

  for( ; it != it_end; ++it) 
    spFHull.insert(it->first);
  

}

void Mesh2D::
compute_watson_data(const CubitVector& point,
		    const Cell* const seed_cell,
		    WatsonData& watson_data,
		    const bool test_bdry_for_encroachment,
		    const bool exit_on_encroached_bdry) const {

  Vert vertex;
  vertex.vSetCoords(2, point);

  compute_watson_data(&vertex, seed_cell, watson_data, 
		      test_bdry_for_encroachment, exit_on_encroached_bdry);

}

void Mesh2D::
compute_watson_data(const Vert* const vertex,
		    const Cell* const seed_cell,
		    WatsonData& watson_data,
		    const bool test_bdry_for_encroachment,
		    const bool exit_on_encroached_bdry) const {

  SUMAA_LOG_EVENT_BEGIN(WATSON_INFO);

#ifndef NDEBUG
 
  if(exit_on_encroached_bdry) {
    assert(test_bdry_for_encroachment);
    assert(seed_cell->eType() == Cell::eTriCell);
  }

  if(seed_cell->eType() == Cell::eTriCell) 
    assert( incircle_shew(seed_cell->pVVert(0)->adCoords(),
			  seed_cell->pVVert(1)->adCoords(), 
			  seed_cell->pVVert(2)->adCoords(), 
			  vertex->adCoords()) > 0. );

  else {

    //For curved boundaries, a boundary edge split point might 
    //actually lie outside the neighbor cell. It is therefore possible
    //to obtain an empty hull. Because of that, not much we can demand
    //in this check.

    assert( seed_cell->eType() == Cell::eBdryEdge ||
	    seed_cell->eType() == Cell::eIntBdryEdge );

  }

#endif

  watson_data.hull_faces.clear();
  watson_data.faces_to_remove.clear();
  watson_data.cells_to_remove.clear();
  watson_data.encroached_bdry_edges.clear();

  //Declaring some of the variables
  const Cell *cell;
  const Face *face, *next_face;

  int i = 0;

  set<const Cell*> cells_tested;
  multimap<const Face*, int> all_faces;
  queue<const Cell*> cells_to_test;
  
  //For a boundary edge, we must be extra cautious. The presence of
  //curves can cause the new vertex not to be included in the circumcenter
  //of the cell bounded by the boundary edge. This is due to the fact that
  //we are actually redefining the convex hull of the set of points making
  //our triangulation. If this case happens, we obtain an empty hull 

  if(seed_cell->eType() == Cell::eTriCell)
    cells_to_test.push(seed_cell);
 
  else {

    assert(seed_cell->eType() == Cell::eBdryEdge ||
	   seed_cell->eType() == Cell::eIntBdryEdge);

#ifndef NDEBUG
    assert(cells_tested.insert(seed_cell).second);
#else
    cells_tested.insert(seed_cell);
#endif

    for(i = 0; i < seed_cell->iNumFaces(); i++) {
      
      face = seed_cell->pFFace(i);
      cell = face->pCCellOpposite(seed_cell);
      assert(cell->eType() == Cell::eTriCell);

      if( incircle_shew(cell->pVVert(0)->adCoords(),
			cell->pVVert(1)->adCoords(),
			cell->pVVert(2)->adCoords(),
			vertex->adCoords()) < 0. ) {
	//The cell immediately by the boundary face does not have
	//the new point inside its circumcircle. Therefore, it must
	//not be removed from the mesh (only happens with curved boundaries).
	all_faces.insert( std::make_pair(face, cell->iRegion()) );
      }
      else {
	//Otherwise, mark the cell to start the walk.
	all_faces.insert( std::make_pair(face, -1) );      
	cells_to_test.push(cell);
      }
   
    }

  }

  //The method performs a march from the top entry in the queue.
  //Marching out from seed_cell, it finds all the cells
  //having vertex's in its circumcenter and boundary
  //edges encroached by vertex.

  while(!cells_to_test.empty()) {
 
    cell = cells_to_test.front();
    cells_to_test.pop();

    if( !cells_tested.insert(cell).second ) continue;

    if( cell->eType() != Cell::eTriCell ) {
      
      if(test_bdry_for_encroachment) {

	BdryEdgeBase* bdry_edge 
	  = dynamic_cast<BdryEdgeBase*>( const_cast<Cell*>(cell) );
	assert(bdry_edge);

	if( bdry_edge->eIsPointEncroaching(vertex->adCoords(), 
					   eEncroachmentType(), 
					   true) ) {
	  watson_data.encroached_bdry_edges.insert(bdry_edge);	  
	  if(exit_on_encroached_bdry) return;
	}

      }

      continue;

    }

    assert(cell->eType() == Cell::eTriCell);
    assert(cell->iNumVerts() == 3);
  
    if( incircle_shew(cell->pVVert(0)->adCoords(),
		      cell->pVVert(1)->adCoords(),
		      cell->pVVert(2)->adCoords(),
		      vertex->adCoords()) >= 0. ) {

      watson_data.cells_to_remove.insert( const_cast<Cell*>(cell) );

      for(i = 0; i < 3; i++) {
	face = cell->pFFace(i);
	all_faces.insert( std::make_pair(face, cell->iRegion()) );
	cells_to_test.push(face->pCCellOpposite(cell));
      }

    }
    
  }
  
  assert(!all_faces.empty());

  //The following looks awful, but does a simple job.
  //It iterates through all_faces. Split the set into 
  //two sets: faces_of_hull, faces_to_delete based on 
  //the following rule:

  //- The entries of faces_of_hull   have one entry   in all_faces.
  //- The entries of faces_to_delete have two entries in all_faces. 

  //Tried implementing using algorithms but could not find a way to
  //match the performance of the following code.

  int region = -1;

  std::multimap<const Face*, int>::iterator 
    it     = all_faces.begin(), 
    it_end = all_faces.end();

  next_face = it->first;
  
  do {
        
    face = next_face;
    region = it->second;

    if(++it == it_end) { 
      assert(region != -1);
      watson_data.hull_faces.insert( watson_data.hull_faces.end(), 
				     std::make_pair( const_cast<Face*>(face), region ) );
      break;
    }
    else { 
      next_face = it->first;
    }

    if( face == next_face ) {
      watson_data.faces_to_remove.insert( watson_data.faces_to_remove.end(), 
					  const_cast<Face*>(face) );
      next_face = (++it)->first;
    }
    else {
      assert(region != -1);
      watson_data.hull_faces.insert( watson_data.hull_faces.end(), 
				     std::make_pair( const_cast<Face*>(face), region ) );
      continue;
    }    

  } while(it != it_end);

//   printf("cells to remove size = %d\n", watson_data.cells_to_remove.size());
//   printf("faces to remove size = %d\n", watson_data.faces_to_remove.size());
//   printf("faces of hull size   = %d\n\n", watson_data.hull_faces.size());

  SUMAA_LOG_EVENT_END(WATSON_INFO);

}

Cell* Mesh2D::
find_seed_naively(const Vert* const vertex) const {

  Cell* cell = NULL;

  for(GR_index_t i = 0; i < iNumCells(); i++) {

    cell = pCCell(i);
    assert(dynamic_cast<TriCell*>(cell));

    if(cell->qDeleted()) continue;
 
    if( incircle_shew(cell->pVVert(0)->adCoords(),
		      cell->pVVert(1)->adCoords(),
		      cell->pVVert(2)->adCoords(),
		      vertex->adCoords()) > 0 ) return cell;

  }

  vFatalError("Unable to find a seed cell naively",
	      "Mesh2D::find_seed_naively");

}

Cell* Mesh2D::
find_seed_guesses(const Vert* const vertex,
		  const set<Cell*>* const guesses) const {

  if(guesses == NULL)
    return find_seed_naively(vertex);

  if(guesses->empty())
    return find_seed_naively(vertex);

  set<Cell*>::iterator it     = guesses->begin(),
                       it_end = guesses->end();

  Cell* cell = NULL;

  for( ; it != it_end; ++it) {

    cell = *it;
    assert(cell->eType() == Cell::eTriCell);

    if( incircle_shew(cell->pVVert(0)->adCoords(),
		      cell->pVVert(1)->adCoords(),
		      cell->pVVert(2)->adCoords(),
		      vertex->adCoords()) > 0 ) return cell;

  }

  return find_seed_naively(vertex);

}
