#include "GR_Face.h"

void MultiEdge::vAssign(Vert* const pV0, Vert* const pV1, Cell **apCExtraIn,
			int iNCellsIn)
{
  apVVerts[0] = pV0;
  apVVerts[1] = pV1;
  pCL = apCExtraIn[0];
  pCR = apCExtraIn[1];
  iNCells = iNCellsIn;
  assert(iNCells > 2);
  for (int i = 2; i < iNCellsIn; i++)
    apCExtra[i-2] = apCExtraIn[i];
}

bool MultiEdge::qHasCell(const Cell* const pC) const
{
  bool qRetVal = (pC == pCL || pC == pCR);
  for (int i = 2; i < iNCells && !qRetVal; i++)
    qRetVal = qRetVal || (apCExtra[i-2] == pC);
  return qRetVal;
}

Cell* MultiEdge::pCCellOpposite(const Cell* const pC) const
  // This operator traverses all the cells incident on the face if
  // called often enough.
{
  if (pC == pCL) return pCR;
  if (pC == pCR) return apCExtra[0];
  for (int i = 2; i < iNCells-1; i++)
    if (pC == apCExtra[i-2])
      return apCExtra[i-1];
  assert(pC == apCExtra[iNCells-3]);
  return pCL;
}

void MultiEdge::vRemoveCell(const Cell* const pCOld)
{
  // The assumption here is that a cell will eventually replace this
  // one.  That is, this call assumes that the actual non-manifold mesh
  // topology isn't being changed, just the identities of triangles on
  // the surface.
  assert(iNCells > 2 || apCExtra[0] == pCInvalidCell);
  if (pCOld == pCL) pCL = apCExtra[iNCells-3];
  else if (pCOld == pCR) pCR = apCExtra[iNCells-3];
  else {
    int i;
    for (i = 2; i < iNCells; i++) {
      if (pCOld == apCExtra[i-2]) {
        apCExtra[i-2] = apCExtra[iNCells-3];
	break;
      }
    }
    assert(i < iNCells);
  }
  apCExtra[iNCells-3] = pCInvalidCell;
  iNCells --;
}

void MultiEdge::vReplaceCell(const Cell* const pCOld, Cell* const pCNew)
{
  assert(pCNew->qValid());
  if (pCOld == pCL) pCL = pCNew;
  else if (pCOld == pCR) pCR = pCNew;
  else {
    int i;
    for (i = 2; i < iNCells; i++) {
      if (pCOld == apCExtra[i-2]) {
        apCExtra[i-2] = pCNew;
	break;
      }
    }
    assert(i < iNCells);
  }
}
    
void MultiEdge::vAddCell(Cell* const pCNew)
{
  assert(pCNew != NULL);
  switch (iNCells) {
  case 0:
    pCL = pCNew;
    break;
  case 1:
    pCR = pCNew;
    break;
  default:
    {
      int ii; 
      for (ii = 2; ii < iNCells; ii++) {
	if (apCExtra[ii - 2] == NULL) continue;
      }
      apCExtra[ii-2] = pCNew;
    }
    break;
  }
  iNCells++;
  assert(iNCells < 10);
}
  
