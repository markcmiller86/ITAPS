#include "GR_SurfMesh.h"

Vert* SurfMesh::createVert(const double dx, const double dy,
			   const double dz)
{
  double adData[] = {dx, dy, dz};
  return createVert(adData);
}

Vert* SurfMesh::createVert(const double adCoords[])
{
  Vert *pV = pVNewVert();
  pV->vResetAllData();
  pV->vSetCoords(3, adCoords);
  return pV;
}

MultiEdge* SurfMesh::createMultiEdge(Vert* const pV0, Vert* const pV1)
{
  assert(pV0->qValid());
  assert(pV1->qValid());
  // This thing had better not have existed before.
  assert(!findCommonFace(pV0, pV1)->qValid());
  MultiEdge *pME = pMENewMultiEdge();
  pME->vSetVerts(pV0, pV1);
  pME->vSetLeftCell(NULL);
  pME->vSetRightCell(NULL);

#ifndef OMIT_VERTEX_HINTS
  // Make sure verts always have a valid hint face...
  if (!pV0->pFHintFace()->qValid())
    pV0->vSetHintFace(pME);
  if (!pV1->pFHintFace()->qValid())
    pV1->vSetHintFace(pME);
#endif

  assert(pME->iFullCheck());

  return pME;
}

MultiEdge* SurfMesh::createMultiEdge(Face* const pF)
{
  assert(pF->qValid());
  assert(pF->pCCellLeft()->qValid());
  assert(pF->pCCellRight()->qValid());
  // This thing had better not have existed before.
  MultiEdge *pME = pMENewMultiEdge();
  
  Vert *pV0 = pF->pVVert(0);
  Vert *pV1 = pF->pVVert(1);

  Cell *pCR = pF->pCCellRight();
  Cell *pCL = pF->pCCellLeft();

  pME->vSetVerts(pV0, pV1);
  pME->vAddCell(pCL);
  pME->vAddCell(pCR);

  pCL->vReplaceFace(pF, pME);
  pCR->vReplaceFace(pF, pME);

  pF->vRemoveCell(pCL);
  pF->vRemoveCell(pCR);
  deleteFace(pF);

#ifndef OMIT_VERTEX_HINTS
  // Make sure verts always have a valid hint face...
  if (!pV0->pFHintFace()->qValid())
    pV0->vSetHintFace(pME);
  if (!pV1->pFHintFace()->qValid())
    pV1->vSetHintFace(pME);
#endif

  assert(pME->iFullCheck());

  return pME;
}

TriCell* SurfMesh::createTriCell(Vert * const pV0, Vert * const pV1,
				 Vert * const pV2, const int iReg)
{
  bool qExist;
  Face *pF01 = createFace(qExist, pV0, pV1);
  Face *pF12 = createFace(qExist, pV1, pV2);
  Face *pF20 = createFace(qExist, pV2, pV0);
  // These faces may or may not already exist.

  TriCell *pC = createTriCell(pF01, pF12, pF20, iReg);
  assert(pC->qHasVert(pV0));
  assert(pC->qHasVert(pV1));
  assert(pC->qHasVert(pV2));
  return (pC);
}

static void fixUpFaceCell(Face *& pF, Cell *pC, Vert *pV,
			  SurfMesh* pSM)
{
  if (pF->pCCellRight()->qValid() && pF->pCCellLeft()->qValid()) {
    if (pF->eType() != Face::eMultiEdge) {
      // Need to create a multi-edge.
      assert(pF->pCCellRight() != pC && pF->pCCellLeft() != pC);
      Face *pFOld = pF;
      pF = pSM->createMultiEdge(pF);
      pC->vReplaceFace(pFOld, pF);
    }
    pF->vAddCell(pC);
  }
  else if (pF->pCCellRight()->qValid()) {
    assert(!pF->pCCellLeft()->qValid());
    pF->vSetLeftCell(pC);
  }
  else if (pF->pCCellLeft()->qValid()) {
    pF->vSetRightCell(pC);
  }
  else {
    if (pF->pVVert(1) == pV) 
      pF->vSetRightCell(pC);
    else
      pF->vSetLeftCell(pC);
  }
}

TriCell* SurfMesh::createTriCell(Face *& pF0, Face *& pF1,
				 Face *& pF2, const int iReg)
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());

  // Set up the face->cell connectivity properly.  The canonical tri
  // looks like this:
  //
  //                2
  //               / \         .
  //              /   \        .
  //             2     1       .
  //            /       \      .
  //           0 - -0- - 1


  // Each pair of faces  must have a common vert.
  Vert *apV[3];
  apV[0] = pVCommonVert(pF0, pF2);
  apV[1] = pVCommonVert(pF0, pF1);
  apV[2] = pVCommonVert(pF1, pF2);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());

  TriCell *pC = dynamic_cast<TriCell*>(pCNewCell(3));
  pC->vResetAllData();
  pC->vAssign(pF0, pF1, pF2);
  pC->vSetRegion(iReg);

  fixUpFaceCell(pF0, pC, apV[0], this);
  fixUpFaceCell(pF1, pC, apV[1], this);
  fixUpFaceCell(pF2, pC, apV[2], this);

  assert(pC->iFullCheck());
  assert(pC->qHasFace(pF0));
  assert(pC->qHasFace(pF1));
  assert(pC->qHasFace(pF2));
  assert(pF0->iFullCheck());
  assert(pF1->iFullCheck());
  assert(pF2->iFullCheck());

  return pC;
}
