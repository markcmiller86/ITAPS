#include "GR_TetMeshInitializer.h"
#include "GR_TetMeshRefiner.h"
#include "GR_AdaptPred.h"
#include "GR_Geometry.h"
#include "GR_Cell.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"
#include "CubitBox.hpp"
#include "CubitVector.hpp"
#include "DLIList.hpp"
#include "KDDTree.hpp"

#include <algorithm>
#include <functional>
#include <set>
#include <vector>

using std::set;
using std::vector;

TetMeshInitializer::
TetMeshInitializer()
  : m_mesh(NULL), m_using_tree(false), m_cell_tree(NULL) { assert(0); }

TetMeshInitializer::
TetMeshInitializer(const TetMeshInitializer&) 
  : m_mesh(NULL), m_using_tree(false), m_cell_tree(NULL) { assert(0); }

TetMeshInitializer& TetMeshInitializer::
operator=(const TetMeshInitializer&) { assert(0); return *this; }

TetMeshInitializer::
TetMeshInitializer(const CubitBox& box,
		   const bool using_tree) 
  : m_mesh(new VolMesh(box)), m_using_tree(using_tree),
    m_cell_tree(m_using_tree ? new KDDTree<TetCell*>() : NULL) {

  for(GR_index_t i = 0; m_using_tree && i < m_mesh->iNumCells(); i++) {
    TetCell* tet_cell = dynamic_cast<TetCell*>(m_mesh->pCCell(i));
    if(tet_cell && !tet_cell->qDeleted()) m_cell_tree->add(tet_cell);
  }

}

TetMeshInitializer::
~TetMeshInitializer() {

  if(m_cell_tree) delete m_cell_tree;
  if(m_mesh)      delete m_mesh;

}

Vert* TetMeshInitializer::
insert_vert_in_mesh(const Vert* const vertex,
		    std::vector<Cell*>* new_cells) {

  assert(vertex->iSpaceDimen() == 3);

  Cell* seed_cell = NULL;

  if(m_using_tree) {
    assert(m_cell_tree);
    seed_cell = find_seed_cell_tree(vertex);
  }
  else {
    seed_cell = find_seed_cell_naively(vertex);
  }

  assert(seed_cell);

  return insert_vert_in_mesh(vertex, seed_cell, new_cells);

}

Vert* TetMeshInitializer::
insert_vert_in_mesh(const Vert* const vertex,
		    const Vert* const vert_guess1,
		    const Vert* const vert_guess2,
		    const Vert* const vert_guess3,
		    vector<Cell*>* new_cells)
{

  assert(vertex->qValid());

  set<const Cell*> guesses; set<Cell*>tmp_cells; set<Vert*> tmp_verts;

  if(vert_guess1) {
    vNeighborhood(vert_guess1, tmp_cells, tmp_verts);
    std::copy(tmp_cells.begin(), tmp_cells.end(), 
	      std::inserter(guesses, guesses.begin()));
  }
  if(vert_guess2) {
    vNeighborhood(vert_guess2, tmp_cells, tmp_verts);
    std::copy(tmp_cells.begin(), tmp_cells.end(), 
	      std::inserter(guesses, guesses.begin()));
  }
  if(vert_guess3) {
    vNeighborhood(vert_guess3, tmp_cells, tmp_verts);
    std::copy(tmp_cells.begin(), tmp_cells.end(), 
	      std::inserter(guesses, guesses.begin()));
  }

  return insert_vert_in_mesh(vertex, guesses, new_cells);

}

Vert* TetMeshInitializer::
insert_vert_in_mesh(const Vert* const vertex,
		    const set<const Cell*>& seed_guesses,
		    vector<Cell*>* new_cells)
{

  assert(vertex->iSpaceDimen() == 3);

  set<const Cell*>::iterator it     = seed_guesses.begin(),
                             it_end = seed_guesses.end();

  Cell* seed = NULL;

  for( ; it != it_end; ++it) {

    //Not too elegant I admit:
    Cell* cell = const_cast<Cell*>(*it);
    assert(cell && !cell->qDeleted());

    if(cell_is_seed(vertex, cell)) {
      seed = cell;
      break;
    }

  }

  if(!seed) 
    seed = find_seed_cell_naively(vertex);
  
  assert(seed);

  return insert_vert_in_mesh(vertex, seed, new_cells);

}
  
Vert* TetMeshInitializer::
insert_vert_in_mesh(const Vert* const vertex,
		    const Cell* known_seed,
		    vector<Cell*>* new_cells)
{

  assert(cell_is_seed(vertex, known_seed));

  Vert* new_vertex = m_mesh->createVert(vertex);

  //Compute Watson Data.
  VolMesh::WatsonData watson_data;
  m_mesh->compute_watson_data(new_vertex, known_seed, 
			      watson_data, false, false);

#ifndef NDEBUG
  
  assert(!watson_data.cells_to_remove.empty());
  assert(watson_data.encroached_bfaces.empty());

  if(watson_data.cells_to_remove.size() == 1)
    assert(watson_data.faces_to_remove.empty());
  else
    assert(!watson_data.faces_to_remove.empty());

#endif

  if(m_using_tree) {
    
    assert(m_cell_tree);
    //Remove cells to delete from m_cell_tree.
    std::for_each( watson_data.cells_to_remove.begin(), watson_data.cells_to_remove.end(),
		   std::bind1st(std::mem_fun(&TetMeshInitializer::remove_from_cell_tree), this) );
    //Proceed with insertion.
  
    vector<Cell*> local_new_cells;
    qAdaptPred = true;
    m_mesh->vInsertWatsonInterior(new_vertex,
				  watson_data.cells_to_remove,
				  watson_data.faces_to_remove,
				  watson_data.hull_faces,
				  &local_new_cells);
    qAdaptPred = false;
    
    //Add newly created cells to m_cell_tree.
    std::for_each( local_new_cells.begin(), local_new_cells.end(),
		   std::bind1st(std::mem_fun(&TetMeshInitializer::add_to_cell_tree), this) );
    if(new_cells) new_cells->swap(local_new_cells);
  
  }

  else {

    qAdaptPred = true;
    m_mesh->vInsertWatsonInterior(new_vertex,
				  watson_data.cells_to_remove,
				  watson_data.faces_to_remove,
				  watson_data.hull_faces,
				  new_cells);
    qAdaptPred = false;
  
  }

  return new_vertex;

}

bool TetMeshInitializer::
cell_is_seed(const Vert* const vertex,
	     const Cell* const cell) {

  assert(cell->eType() == Cell::eTet);

  return ( iInsphere(cell->pVVert(0)->adCoords(), 
		     cell->pVVert(1)->adCoords(), 
		     cell->pVVert(2)->adCoords(), 
		     cell->pVVert(3)->adCoords(),
		     vertex->adCoords()) == 1 ); 

}

void TetMeshInitializer::
purge_mesh() {

  assert(m_mesh);
  assert(m_cell_tree);

  m_mesh->vPurge();

  //After purging the mesh, we need to rebuild the search tree entirely.

  if(m_using_tree) {

    assert(m_cell_tree);
    delete m_cell_tree;
    
    m_cell_tree = new KDDTree<TetCell*>();

    for(GR_index_t i = 0; i < m_mesh->iNumCells(); i++) {
      TetCell* tet_cell = dynamic_cast<TetCell*>(m_mesh->pCCell(i));
      if(tet_cell && !tet_cell->qDeleted()) m_cell_tree->add(tet_cell);
    }

  }

}

void TetMeshInitializer::
add_to_cell_tree(Cell* const cell) {

  TetCell* tet_cell = dynamic_cast<TetCell*>(cell);
  assert(tet_cell && !tet_cell->qDeleted());
 
  m_cell_tree->add(tet_cell); 

}

void TetMeshInitializer::
remove_from_cell_tree(Cell* const cell) {
  
  TetCell* tet_cell = dynamic_cast<TetCell*>(cell);
  assert(tet_cell);
  
  m_cell_tree->remove(tet_cell); 
  
}

Cell* TetMeshInitializer::
find_seed_cell_tree(const Vert* const vertex) const {
  
  //printf("finding seed with tree\n");

  assert(m_using_tree && m_cell_tree);

  DLIList<TetCell*> seed_candidates; 
  CubitVector point_loc(vertex->dX(), vertex->dY(), vertex->dZ());
 
  m_cell_tree->find(CubitBox(point_loc, point_loc), seed_candidates);

  int size = seed_candidates.size();

  for(int i = 0; i < size; i++) {

    TetCell* cell = seed_candidates.next(i);
    if(cell->qDeleted()) continue;

    if(cell_is_seed(vertex, cell)) return cell;

  }
  
  return find_seed_cell_naively(vertex);

}

Cell* TetMeshInitializer::
find_seed_cell_naively(const Vert* const vertex) const {

  //printf("finding seed naively\n");

  int num_cells = m_mesh->iNumCells();

  for(int i = 0; i < num_cells; i++) {

    Cell* cell = m_mesh->pCCell(i);
    if(!cell || cell->qDeleted()) continue;
    
    if(cell_is_seed(vertex, cell)) return cell;

  }

#ifndef NDEBUG

  printf("Tried to insert a vertex at: %lf %lf %lf\n", 
	 vertex->dX(), vertex->dY(), vertex->dZ());
  
  assert(m_mesh->qValid());

  for(int i = 0; i < num_cells; i++) {

    Cell* cell = m_mesh->pCCell(i);
    if(!cell || cell->qDeleted()) continue;
  
    int in_tet = iIsInTet(vertex,
			  cell->pVVert(0),
			  cell->pVVert(1),
			  cell->pVVert(2),
			  cell->pVVert(3));
  
    if(in_tet == -1) continue;

    printf("cell = %p: ", cell);
    if(in_tet == 0) printf("INVALID TET\n");
    if(in_tet == 1) printf("COINCIDES WITH VERT\n");
    if(in_tet == 2 || in_tet == 3) printf("COINCIDES WITH FACE\n");
    if(in_tet == 4) printf("IN TET\n");

  }

#endif

  vFatalError("The point you are trying to insert is outside the meshed domain.",
	      "TetMeshInitializer::find_seed_cell()");
}

void TetMeshInitializer::
find_cells_in_box(const CubitBox& box,
		  std::vector<TetCell*>& cells_in_box) const {

  DLIList<TetCell*> query_return;
  m_cell_tree->find(box, query_return);

  int size = query_return.size();

  for(int i = 0; i < size; i++) 
    cells_in_box.push_back(query_return.next(i));

}
