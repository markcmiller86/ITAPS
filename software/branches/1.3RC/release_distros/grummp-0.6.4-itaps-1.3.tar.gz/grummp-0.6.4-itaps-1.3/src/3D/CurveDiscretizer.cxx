#include "GR_CurveDiscretizer.h"
#include "GR_misc.h"

#include "CubitVector.hpp"  
#include "RefEdge.hpp"

#include <list>
#include <set>

using std::list;

void CurveSample::init_sample(unsigned int num_points, bool compute_tangent) {

  clear_sample();
  assert(m_curve_sample.empty());

  if(num_points < 3) num_points = 3;
  unsigned int num_sample = num_points - 2; //num_points - number of end points
    
  double min_param, max_param, param_diff, fraction;
  m_curve->get_param_range(min_param, max_param);
  param_diff = max_param - min_param;
  assert(param_diff > 0.);

  CurveSampleData csd_beg, csd_end;
  CubitVector coord, tangent;
  csd_beg.set_param(min_param);
  csd_end.set_param(max_param);
  csd_beg.set_coord(m_curve->start_coordinates());
  csd_end.set_coord(m_curve->end_coordinates());
  
  if(compute_tangent) {

    m_curve->position_from_u(min_param + 0.0001, coord);
    m_curve->tangent(coord, tangent);
    csd_beg.set_tangent(tangent);

    m_curve->position_from_u(max_param - 0.0001, coord);
    m_curve->tangent(coord, tangent);
    csd_end.set_tangent(tangent);

  }
  
  m_curve_sample.push_back(csd_beg);

  for(unsigned int i = 0; i < num_sample; i++) {

    fraction = static_cast<double>(i+1) / static_cast<double>(num_sample+1);
       
    csd_beg.set_param( min_param + (param_diff * fraction) );
    m_curve->position_from_u( csd_beg.get_param(), coord );
    csd_beg.set_coord( coord );

    if(compute_tangent) { 
      m_curve->tangent( *csd_beg.get_coord(), tangent );     
      csd_beg.set_tangent( tangent );
    }     

    m_curve_sample.push_back(csd_beg);
    
  }
  
  m_curve_sample.push_back(csd_end);
  
  assert(m_curve_sample.size() >= 3);
  assert(m_curve_sample.size() == num_points);

}

void CurveSample::sample_tvt(double threshold) {

  assert( m_curve );
  assert( iFuzzyComp(threshold, 0.)  == 1  );
  assert( iFuzzyComp(threshold, 0.1) == -1 );

  init_sample(10, true);

  double mid_param, tvt1, tvt2, tvt_diff;
  CubitVector mid_coord, mid_tangent;
  CurveSampleData sample_data;

  list<CurveSampleData>::iterator it_prev, it;
  it_prev = it = m_curve_sample.begin();

  while(++it != m_curve_sample.end()) {
    
    assert(it != it_prev);
    assert(it_prev->get_tangent() && it->get_tangent());
    assert(it_prev->get_param() < it->get_param());

    mid_param = 0.5 * ( it_prev->get_param() + it->get_param() );
    m_curve->position_from_u(mid_param, mid_coord);
    m_curve->tangent(mid_coord, mid_tangent);

    tvt1 = GR_acos( *it_prev->get_tangent() % *it->get_tangent() );
    tvt2 = GR_acos( *it_prev->get_tangent() % mid_tangent ) + 
           GR_acos( *it     ->get_tangent() % mid_tangent );

    tvt_diff = fabs(tvt2 - tvt1);

    if(tvt_diff < threshold) { it_prev = it; } 
    else {      
      sample_data.set_param(mid_param);
      sample_data.set_coord(mid_coord);
      sample_data.set_tangent(mid_tangent);
      m_curve_sample.insert(it, sample_data);
      it = it_prev;
    }
    
  }

}

  
double CurveSample::compute_tvt(double beg_param, double end_param) {

  assert( !m_curve_sample.empty() );
  
  double min_param, max_param;
  m_curve->get_param_range(min_param, max_param);
  
  double u1, u2;
  if(beg_param < min_param) u1 = min_param;
  else                      u1 = beg_param;
  if(end_param > max_param) u2 = max_param;
  else                      u2 = end_param;

  assert(iFuzzyComp(u1, u2) == -1);
  assert(iFuzzyComp(u1, min_param) >= 0 &&
	 iFuzzyComp(u1, max_param) <= 0);
  assert(iFuzzyComp(u2, min_param) >= 0 &&
	 iFuzzyComp(u2, max_param) <= 0);

  CubitVector beg_tangent, end_tangent, beg_coord, end_coord;
  m_curve->position_from_u(u1, beg_coord);
  m_curve->position_from_u(u2, end_coord);
  m_curve->tangent(beg_coord, beg_tangent);
  m_curve->tangent(end_coord, end_tangent);
  
  list<CurveSampleData>::iterator it, 
    it_beg =   std::find_if( m_curve_sample.begin(), m_curve_sample.end(), ParamGreaterThan(u1) ), 
    it_end = --std::find_if( it_beg, m_curve_sample.end(), ParamGreaterThan(u2) );

  assert(iFuzzyComp(u1, it_beg->get_param()) !=  1);
  assert(iFuzzyComp(u2, it_end->get_param()) != -1);
  assert(it_beg->get_tangent());
  assert(it_end->get_tangent());    

  //This will happen if u1 and u2 are in the same sample interval.
  if( it_beg->get_param() > it_end->get_param() )
    return GR_acos( beg_tangent % end_tangent ); 

  double tvt = 0.;
  CubitVector *tangent1 = it_beg->get_tangent(), *tangent2;

  tvt += GR_acos( beg_tangent % *tangent1 );

  for(it = it_beg; it != it_end; ) {
    tangent2 = (++it)->get_tangent();
    assert( tangent1 && tangent2 );
    tvt += GR_acos( *tangent1 % *tangent2 );
    tangent1 = tangent2;
  }
  
  tangent2 = it_end->get_tangent();
  tvt += GR_acos( *tangent2 % end_tangent );

  return tvt;

}

void TangentDiscretizer::discretize(DiscreteCurve& discrete_curve) {

  discrete_curve.clear();
  
  RefEdge* curve = m_sample.get_curve();
  double lo_param, hi_param, mid_param, tvt;
  CubitVector coord;
  
  curve->get_param_range(lo_param, hi_param);
  curve->position_from_u(lo_param, coord);
  discrete_curve.insert( CurvePoint(lo_param, coord) );
  curve->position_from_u(hi_param, coord);
  discrete_curve.insert( CurvePoint(hi_param, coord) ); 

  DiscreteCurve::iterator it_prev, it;
  it_prev = it = discrete_curve.begin();

  while(++it != discrete_curve.end()) {
    
    lo_param = it_prev->get_param();
    hi_param = it->get_param();	
    assert(hi_param > lo_param);

    tvt = m_sample.compute_tvt(lo_param, hi_param);

    if(tvt > m_tvt_bound) {
      mid_param = 0.5 * (lo_param + hi_param);
      curve->position_from_u( mid_param, coord );
      it = discrete_curve.insert( CurvePoint(mid_param, coord) ).first;
      it_prev = --it;
    }
    else {
      it_prev = it;
    }

  }

}

void UniformDiscretizer::discretize(DiscreteCurve& discrete_curve) {

  discrete_curve.clear();
  assert(0);

}

void CurvatureDiscretizer::discretize(DiscreteCurve& discrete_curve) {

  discrete_curve.clear();
  assert(0);

}
