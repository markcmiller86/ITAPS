#include <stdlib.h>
#include <stdio.h>

#include "GR_misc.h"
#include "GR_VolMesh.h"

void vReadVMesh(const char * const fileName
    // Now read all of the mesh data from file
    GR_index_t iNVerts, iNFaces, iNCells, iNBFaces, iNIntBFaces;
    bool qFaceVert, qCellVert, qFaceCell, qCellFace, qCellRegion;
    bool qBFaceFace, qBFaceVert, qBFaceBC;
    bool qIntBFaceFace, qIntBFaceVert, qIntBFaceBC;
    GR_index_t (*a2iFaceVert)[3];
    GR_sindex_t (*a2iFaceCell)[2];
    GR_index_t (*a2iCellVert)[4], (*a2iCellFace)[4];
    int *aiCellRegion;
    GR_index_t *aiBFaceFace, (*a2iBFaceVert)[3];
    GR_index_t (*a2iIntBFaceFace)[2], (*a2iIntBFaceVert)[3];
    int *aiBFaceBC, *aiIntBFaceBC;
    
    vReadFile_VolMesh(strBaseFileName, iNVerts, iNFaces, iNCells,
		      iNBFaces, iNIntBFaces, qFaceVert, qCellVert,
		      qFaceCell, qCellFace, qCellRegion, qBFaceFace,
		      qBFaceVert, qBFaceBC, qIntBFaceFace,
		      qIntBFaceVert, qIntBFaceBC, ECVerts,
		      a2iFaceVert, a2iFaceCell, a2iCellVert,
		      a2iCellFace, aiCellRegion, aiBFaceFace,
		      aiBFaceBC, a2iBFaceVert, a2iIntBFaceFace,
		      aiIntBFaceBC, a2iIntBFaceVert);
    
    if (ECVerts.lastEntry() == 0)
      vFatalError("No vertex coordinate data read", "volume mesh input");
    
    bool qConnectOK = false;
    if (qFaceVert && qFaceCell)
      qConnectOK = true; // face-based structure
    else if (qCellVert)
      qConnectOK = true; // FE structure
    
    if (!qConnectOK)
      vFatalError("Inadequate connectivity data read; consult user's manual.",
		  "volume mesh input");
    
    int *aiBCList;
    
    //@@@ Convert face-based data to VolMesh
    // This is the easiest conversion case
    
    if (qFaceVert && qFaceCell) {
      // If the number of cells, faces, and boundary faces have been
      // provided, we can check for mesh validity.
      if (iNFaces == 0)
	vFatalError("Mesh size unknown.", "volume mesh input");
      //@@@@ Verify mesh size
      {
	GR_sindex_t iTmpNCells = 0;
	GR_index_t iTmpNBFaces = 0, iTmpNVerts = 0;
	for (GR_index_t iF = 0; iF < iNFaces; iF++) {
	  GR_sindex_t iC0 = a2iFaceCell[iF][0];
	  GR_sindex_t iC1 = a2iFaceCell[iF][1];
	  iTmpNCells = MAX3(iTmpNCells, iC0, iC1);
	  if (iC0 < 0 || iC1 < 0)
	    iTmpNBFaces ++;
	  GR_index_t iV0 = a2iFaceVert[iF][0];
	  GR_index_t iV1 = a2iFaceVert[iF][1];
	  GR_index_t iV2 = a2iFaceVert[iF][2];
	  iTmpNVerts = max(max(iTmpNVerts, iV0), max(iV1, iV2));
	}
	if (iNCells == 0)
	  iNCells = iTmpNCells+1;
	else if (iNCells != GR_index_t(iTmpNCells+1))
	  vFatalError("Number of cells in mesh doesn't match number given.",
		      "volume mesh input");
	
	if (iNBFaces == 0)
	  iNBFaces = iTmpNBFaces;
	else if (iNBFaces != iTmpNBFaces)
	  vFatalError("Number of bdry faces in mesh doesn't match number given.",
		      "volume mesh input");
	
	if (iNVerts == 0)
	  iNVerts = iTmpNVerts+1;
	else if (iNVerts != iTmpNVerts+1)
	  vFatalError("Number of verts in mesh doesn't match number given.",
		      "volume mesh input");
      }
      
      // FIX ME
      // To do Euler's formula, we would need to identify all the edges,
      // which isn't worth doing yet.
      
      ECTriF.vSetup(iNFaces);       // Ensure the existence of enough
      ECTet.vSetup(iNCells);       // blank faces, bdry faces, and cells.
      ECTriBF.vSetup(iNBFaces);
      
      aiBCList = new int[iNBFaces];
      
      
      GR_index_t iBFace = 0;
      for (GR_index_t i = 0; i < iNFaces; i ++) {
	// Add entry to cell-face table or bdry face list on the fly
	GR_sindex_t iC0 = a2iFaceCell[i][0];
	GR_sindex_t iC1 = a2iFaceCell[i][1];
	Cell *pC0, *pC1;
	Face *pF = pFFace(i);
	if (iC0 < 0) {
	  BFace* pBF = pBFBFace(iBFace);
	  pBF->vAssign(pF);
	  pF->vSetFaceLoc(Face::eBdryFace);
	  aiBCList[iBFace] = abs(iC0);
	  pC0 = pBF;
	  iBFace ++;
	}
	else {
	  pC0 = pCCell(iC0);
	  pC0->vAddFace(pF);
	}
	
	if (iC1 < 0) {
	  BFace *pBF = pBFBFace(iBFace);
	  pBF->vAssign(pF);
	  pF->vSetFaceLoc(Face::eBdryFace);
	  aiBCList[iBFace] = abs(iC1);
	  pC1 = pBF;
	  iBFace ++;
	}
	else {
	  pC1 = pCCell(iC1);
	  pC1->vAddFace(pF);
	}
	
	// Tell the face everything it needs to know.
	GR_index_t iV0 = a2iFaceVert[i][0];
	GR_index_t iV1 = a2iFaceVert[i][1];
	GR_index_t iV2 = a2iFaceVert[i][2];
	pFFace(i)->vAssign(pC0, pC1, pVVert(iV0), pVVert(iV1), pVVert(iV2));
      }
      assert(iBFace == iNBFaces);
      
      //@@@ Assign BC's and check boundary consistency
      // If the BC's were read on a boundary-face by boundary-face
      // basis, then these BC's silently override anything read
      // elsewhere. Also, verify that the boundary face and its
      // corresponding face have the same vertices, if data exists to do
      // this check.
      
      //@@@@ The easy case:  real face ID read
      if (qBFaceFace && (qBFaceBC || qBFaceVert)) {
	for (GR_index_t iBF = 0; iBF < iNBFaces; iBF++) {
	  GR_index_t iFace = aiBFaceFace[iBF];
	  Face *pF = pFFace(iFace);
	  //@@@@@ Assign BC
	  if (qBFaceBC) {
	    int iBC = aiBFaceBC[iBF];
	    Cell *pC = pF->pCCellLeft();
	    if (pC->eType() == Cell::eTet) {
	      pC = pF->pCCellRight();
	    }
	    assert(pC->eType() == Cell::eTriBFace);
	    aiBCList[iBF] = abs(iBC);
	  } // Done assigning BC
	  //@@@@@ Verify vertex consistency
	  if (qBFaceVert) {
	    GR_index_t iV0 = iVertIndex(pF->pVVert(0));
	    GR_index_t iV1 = iVertIndex(pF->pVVert(1));
	    GR_index_t iV2 = iVertIndex(pF->pVVert(2));
	    if ( (iV0 != a2iBFaceVert[iBF][0] &&
		  iV0 != a2iBFaceVert[iBF][1] &&
		  iV0 != a2iBFaceVert[iBF][2])
		 ||
		 (iV1 != a2iBFaceVert[iBF][0] &&
		  iV1 != a2iBFaceVert[iBF][1] &&
		  iV1 != a2iBFaceVert[iBF][2])
		 ||
		 (iV2 != a2iBFaceVert[iBF][0] &&
		  iV2 != a2iBFaceVert[iBF][1] &&
		  iV2 != a2iBFaceVert[iBF][2]) ) {
	      vFatalError("Verts of bdry face don't match verts of actual face",
			  "volume mesh input");
	    }
	  } // Done consistency checking for vertices on boundary
	} // Done looping over all bdry faces
      } // Done with cases where face ID was read for each bdry face
      
      //@@@@ Assign BC's if bface-vert and bdry cond data have been read
      else if (qBFaceVert && qBFaceBC) {
	for (GR_index_t iBF = 0; iBF < iNBFaces; iBF++) {
	  GR_index_t iV0 = a2iBFaceVert[iBF][0];
	  GR_index_t iV1 = a2iBFaceVert[iBF][1];
	  GR_index_t iV2 = a2iBFaceVert[iBF][2];
	  Vert *pV0 = pVVert(iV0);
	  Vert *pV1 = pVVert(iV1);
	  Vert *pV2 = pVVert(iV2);
	  // The bface must already exist, but which one is it?
	  // Find all incident faces for pV0.
	  std::set<Cell*> spCIncident;
	  std::set<Vert*> spVNeigh;
	  std::set<BFace*> spBFIncident;
	  BFace *pBF = pBFInvalidBFace; /* Init for picky compilers. */
	  vNeighborhood(pV0, spCIncident, spVNeigh, &spBFIncident);
	  assert(spVNeigh.count(pV1) == 1);
	  assert(spVNeigh.count(pV2) == 1);
	  assert(spBFIncident.size() > 0);
	  for (std::set<BFace*>::iterator iter = spBFIncident.begin();
	       iter != spBFIncident.end(); iter++) {
	    pBF = *iter;
	    assert(pBF->qHasVert(pV0));
	    if (pBF->qHasVert(pV1) && pBF->qHasVert(pV2)) break;
	  }
	  assert(pBF->qHasVert(pV1) && pBF->qHasVert(pV2));
	  aiBCList[iBF] = abs(aiBFaceBC[iBF]);
	} // Done looping over all bdry faces to assign BC's
      } // Done assigning BC's based on bdry verts alone
      else if (qBFaceFace || qBFaceVert || qBFaceBC) {
	vWarning("Insufficient boundary data read to be useful; ignoring.");
      }
      
      //@@@ Further consistency checking
      if (qCellFace) {
	vMessage(3, "Checking consistency of cell-face and face-cell data...");
	for (GR_index_t iC = 0; iC < iNCells; iC++) {
	  Cell *pC = pCCell(iC);
	  for (int ii = 0; ii < pC->iNumFaces(); ii++) {
	    GR_index_t iF = a2iCellFace[iC][ii];
	    Face *pF = pFFace(iF);
	    if (!(pC->qHasFace(pF)))
	      vFatalError("Cell-face data inconsistent with face-cell data",
			  "volume mesh input");
	  }
	}
	vMessage(3, "OK\n");
      }
      if (qCellVert) {
	vMessage(3, "Checking consistency of cell-vert and face-vert data...");
	for (GR_index_t iC = 0; iC < iNCells; iC++) {
	  Cell *pC = pCCell(iC);
	  for (int ii = 0; ii < pC->iNumVerts(); ii++) {
	    GR_index_t iV = a2iCellVert[iC][ii];
	    Vert *pV = pVVert(iV);
	    if (!(pC->qHasVert(pV)))
	      vFatalError("Cell-vert data inconsistent with face-vert data",
			  "volume mesh input");
	  }
	}
	vMessage(3, "OK\n");
      }
      
    } // Done converting face-based data
    else if (qCellVert) {
      // This is the cell-vert conversion case.
      if (iNCells == 0)
	vFatalError("Mesh size unknown.", "volume mesh input");
      //@@@@ Verify that number of verts is correct
      {
	GR_index_t iTmpNVerts = 0;
	for (GR_index_t iC = 0; iC < iNCells; iC++) {
	  GR_index_t iV0 = a2iCellVert[iC][0];
	  GR_index_t iV1 = a2iCellVert[iC][1];
	  GR_index_t iV2 = a2iCellVert[iC][2];
	  GR_index_t iV3 = a2iCellVert[iC][3];
	  iTmpNVerts = max(iTmpNVerts, max(max(iV0, iV1), max(iV2, iV3)));
	}
	if (iNVerts != 0 && iNVerts != iTmpNVerts+1)
	  vFatalError("Number of verts in mesh doesn't match number given.",
		      "volume mesh input");
      }
      
      aiBCList = new int[iNBFaces];
      
      // FIX ME 0.2.3
      // All format translation needs to be modularized and pulled out for
      // easy access when converting from and to user meshes for
      // refinement.
      vConvertFromCellVert(iNCells, iNBFaces, a2iCellVert,
			   a2iBFaceVert, aiBFaceBC, aiBCList);
      
      if (!(qValid()))
	vFoundBug("volume mesh input from user-format FE-style file");
      // FIX ME 0.2.3:
      // Consistency checking is much harder for data that centers
      // around cell-vertex connectivity.  For example, the only
      // meaningful information that can be gleaned from cell-face or
      // face-cell data is that the reciprocity relationships are the
      // same for the data file and the mesh.  This is a lot of work for
      // very little gain, so I'm skipping it for now.
    } // Done translating cell-vert/bface-vert/bface-BC data
    
    // FIX ME: Add code to set up bdry data after 3D mesh input conversion.
    
    //@@@ Assign cells to regions
    // The default region, set when the cell was created, is 1.
    if (qCellRegion) {
      for (GR_index_t iCell = 0; iCell < iNumCells(); iCell++)
	pCCell(iCell)->vSetRegion(aiCellRegion[iCell]);
      // Done with aiCellRegion, so get rid of it.
      delete [] aiCellRegion;
    }
    
    //@@@ Tag faces and verts
    for (GR_index_t iVert = 0; iVert < iNumVerts(); iVert++)
      pVVert(iVert)->vSetType(Vert::eInterior);
    for (GR_index_t iFace = 0; iFace < iNumFaces(); iFace++) {
      Face *pF = pFFace(iFace);
      Cell *pCL = pF->pCCellLeft();
      Cell *pCR = pF->pCCellRight();
      if (pF->qIsBdryFace())
	continue; // Do boundaries separately.
      // Mark internal boundaries
      if (pCL->iRegion() != pCR->iRegion()) {
	pF->vSetFaceLoc(Face::eBdryTwoSide);
	pF->pVVert(0)->vSetType(Vert::eBdryTwoSide);
	pF->pVVert(1)->vSetType(Vert::eBdryTwoSide);
	pF->pVVert(2)->vSetType(Vert::eBdryTwoSide);
      }
      else // Not an internal boundary
	pF->vSetFaceLoc(Face::eInterior);
    }
    
    // Tag ordinary boundary verts, and tag verts that lie at the
    // intersection of internal and regular boundary faces as boundary
    // apexes, so that they can never be smoothed or removed.
    // At this point, geometric tagging of BdryApex and BdryCurve
    // vertices isn't done.
    for (GR_index_t iBFace = 0; iBFace < iNumBdryFaces(); iBFace++) {
      BFace *pBF = pBFBFace(iBFace);
      for (int iV = 0; iV < pBF->iNumVerts(); iV++) {
	Vert *pV = pBF->pVVert(iV);
	switch (pV->iVertType()) {
	case Vert::eBdryTwoSide:
	  pV->vSetType(Vert::eBdryApex);
	  break;
	case Vert::eInterior:
	  pV->vSetType(Vert::eBdry);
	  break;
	default:
	  // Nothing needs to be done
	  break;
	}
      }

    }

    if (pB3DIn) {
      // Now infer which bdry faces are on which patches.  Start by
      // identifying all bdry verts, and finding which patches, if any,
      // they fall on.  While it's not very efficient to do this by
      // checking all bdry verts against all patches, this approach has
      // the virtue of working, and for meshes that aren't absolutely
      // huge, it should be no problem from the runtime point of view.
      multimap<Vert*, BdryPatch3D*> mmVertPatch;
      for (int iV = iNumVerts() - 1; iV >= 0; iV--) {
	Vert *pV = pVVert(iV);
	for (int iP = pB3D->iNumPatches() - 1; iP >= 0; iP--) {
	  BdryPatch3D *pBP3D = (*pB3D)[iP];
	  if (!pBP3D->qDisjointFrom(pV)) {
	    vMessage(4, "Vert at (%10.6f, %10.6f, %10.6f) lies on patch %10p\n",
		     pV->dX(), pV->dY(), pV->dZ(), pBP3D);
	    mmVertPatch.insert(pair<Vert*, BdryPatch3D*>(pV, pBP3D));
	  }
	}
      }
      
      // Now for every bdry face, identify a patch common to its verts.
      for (int iBF = iNumBdryFaces() - 1; iBF >= 0; iBF--) {
	BFace *pBF = pBFBFace(iBF);
	Vert *pV0 = pBF->pVVert(0);
	Vert *pV1 = pBF->pVVert(1);
	Vert *pV2 = pBF->pVVert(2);
	pV0->vSetType(Vert::eBdry);
	pV1->vSetType(Vert::eBdry);
	pV2->vSetType(Vert::eBdry);
	
	// How many patches for each one?
	pair<multimap<Vert*, BdryPatch3D*>::iterator,
	  multimap<Vert*, BdryPatch3D*>::iterator> pRange0, pRange1, pRange2;
	pRange0 = mmVertPatch.equal_range(pV0);
	pRange1 = mmVertPatch.equal_range(pV1);
	pRange2 = mmVertPatch.equal_range(pV2);
	multimap<Vert*, BdryPatch3D*>::iterator iter0, iter1, iter2;
	BdryPatch3D* pBP3D = NULL;
	for (iter0 = pRange0.first;
	     pBP3D == NULL && iter0 != pRange0.second;
	     iter0++) {
	  for (iter1 = pRange1.first;
	       pBP3D == NULL && iter1 != pRange1.second;
	       iter1++) {
	    if (iter0->second == iter1->second) {
	      for (iter2 = pRange2.first;
		   pBP3D == NULL && iter2 != pRange2.second;
		   iter2++) {
		if (iter0->second == iter2->second) {
		  pBP3D = iter0->second;
		} // Inner if
	      } // Loop for vert 3
	    } // 1 and 2 have a face in common
	  } // Loop for vert 2
	} // Loop for vert 1
	assert(pBP3D != NULL);
	vMessage(4, "BFace %3d lies on patch %10p\n", iBF, pBP3D);
	vMessage(4, "  coords: (%10.6f, %10.6f, %10.6f),\n",
		 pV0->dX(), pV0->dY(), pV0->dZ());
	vMessage(4, "  coords: (%10.6f, %10.6f, %10.6f),\n",
		 pV1->dX(), pV1->dY(), pV1->dZ());
	vMessage(4, "  coords: (%10.6f, %10.6f, %10.6f),\n",
		 pV2->dX(), pV2->dY(), pV2->dZ());
	pBF->vSetPatch(pBP3D);
    }
    delete [] aiBCList;

      // Definitively identify bdry apexes and bdry curve pts: any vert
      // with faceson
      // more than two patches is an apex; those on exactly two are bdry
      // curve pts.  This assumes specifically that there aren't any
      // internal bdrys.
      for (int iV = iNumVerts() - 1; iV >= 0; iV--) {
	Vert *pV = pVVert(iV);
	if (pV->iVertType() == Vert::eBdry) {
	  int iCount = mmVertPatch.count(pV);
	  if (iCount == 2) {
	    // FIX ME:
	    // Could also be a bizarre apex, where the curve separating
	    // two patches has a kink in it.
	    pV->vSetType(Vert::eBdryCurve);
	  }
	  else if (iCount > 2) {
	    // FIX ME:
	    // Could be a curve with one or more internal faces.
	    pV->vSetType(Vert::eBdryApex);
	  }
	  vMessage(4, "Patch count: %d.  Vert type: %d.\n",
		   iCount, pV->iVertType());
	}
      }
    }
    else {
      vMessage(3, "Creating bdry patches directly from mesh data.\n");
      vMessage(3, "You should specify a bdry file if you have one available.\n");
      vCreatePatchesFromBdryFaces(aiBCList);
    }
    delete [] aiBCList;

    if (qFaceVert) delete [] a2iFaceVert;
    if (qCellVert) delete [] a2iCellVert;
    if (qFaceCell) delete [] a2iFaceCell;
    if (qCellFace) delete [] a2iCellFace;
    if (qBFaceFace) delete [] aiBFaceFace;
    if (qBFaceVert) delete [] a2iBFaceVert;
    if (qBFaceBC) delete [] aiBFaceBC;

