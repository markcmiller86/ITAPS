#include "GR_QualMeasure.h"

using namespace GRUMMP;

void SineDihedralAngles::evalAll
(int& nValues, double* values, const Cell* cell) const
{
  switch (cell->eType()) {
  case CellSkel::eTet:
    evalAll(nValues, values, cell->pVVert(0), cell->pVVert(1),
	    cell->pVVert(2), cell->pVVert(3));
    break;
  default:
    nValues = 0;
    break;
  }
}

void SineDihedralAngles::evalAll
(int& nValues, double* values,
 const Vert* vert0, const Vert* vert1, const Vert* vert2, const Vert* vert3,
 const Vert* vert4, const Vert* vert5, const Vert* vert6, const Vert* vert7)
  const
{
  // For now, only tets.
  assert(vert3);
  assert(!vert4 && !vert5 && !vert6 && !vert7);
  nValues = 6;

  const double * const adA = vert0->adCoords();
  const double * const adB = vert1->adCoords();
  const double * const adC = vert2->adCoords();
  const double * const adD = vert3->adCoords();

  double adNorm0[3], adNorm1[3], adNorm2[3], adNorm3[3];
  vUnitNormal(adC, adB, adD, adNorm0);
  vUnitNormal(adA, adC, adD, adNorm1);
  vUnitNormal(adB, adA, adD, adNorm2);
  vUnitNormal(adA, adB, adC, adNorm3);

  // The order in which the dihedrals are assigned matters for
  // computation of solid angles.  The way they're currently set up,
  // combining them as (0,1,2), (0,3,4), (1,3,5), (2,4,5) gives (in
  // order) solid angles at vertices A, B, C, D
  
  double cross[3];
   // Always positive, even if the sine is negative, so no good for untangling.
  vCROSS3D(adNorm0, adNorm1, cross);
  values[5] = dMAG3D(cross); // Edge CD

  vCROSS3D(adNorm0, adNorm2, cross);
  values[4] = dMAG3D(cross); // Edge BD

  vCROSS3D(adNorm0, adNorm3, cross);
  values[3] = dMAG3D(cross); // Edge BC

  vCROSS3D(adNorm1, adNorm2, cross);
  values[2] = dMAG3D(cross); // Edge AD

  vCROSS3D(adNorm1, adNorm3, cross);
  values[1] = dMAG3D(cross); // Edge AC

  vCROSS3D(adNorm2, adNorm3, cross);
  values[0] = dMAG3D(cross); // Edge AB
}

void DihedralAngles::evalAll
(int& nValues, double* values, const Cell* cell) const
{
  switch (cell->eType()) {
  case CellSkel::eTet:
    evalAll(nValues, values, cell->pVVert(0), cell->pVVert(1),
	    cell->pVVert(2), cell->pVVert(3));
    break;
  default:
    nValues = 0;
    break;
  }
}

void DihedralAngles::evalAll
(int& nValues, double* values,
 const Vert* vert0, const Vert* vert1, const Vert* vert2, const Vert* vert3,
 const Vert* vert4, const Vert* vert5, const Vert* vert6, const Vert* vert7)
  const
{
  // For now, only tets.
  assert(vert3);
  assert(!vert4 && !vert5 && !vert6 && !vert7);
  nValues = 6;

  const double * const adA = vert0->adCoords();
  const double * const adB = vert1->adCoords();
  const double * const adC = vert2->adCoords();
  const double * const adD = vert3->adCoords();

  double adNorm0[3], adNorm1[3], adNorm2[3], adNorm3[3];
  vUnitNormal(adC, adB, adD, adNorm0);
  vUnitNormal(adA, adC, adD, adNorm1);
  vUnitNormal(adB, adA, adD, adNorm2);
  vUnitNormal(adA, adB, adC, adNorm3);

  // The order in which the dihedrals are assigned matters for
  // computation of solid angles.  The way they're currently set up,
  // combining them as (0,1,2), (0,3,4), (1,3,5), (2,4,5) gives (in
  // order) solid angles at vertices A, B, C, D
  
  double dot = -dDOT3D(adNorm0, adNorm1);
  values[5] = GR_acos(dot); // Edge CD

  dot = -dDOT3D(adNorm0, adNorm2);
  values[4] = GR_acos(dot); // Edge BD

  dot = -dDOT3D(adNorm0, adNorm3);
  values[3] = GR_acos(dot); // Edge BC

  dot = -dDOT3D(adNorm1, adNorm2);
  values[2] = GR_acos(dot); // Edge AD

  dot = -dDOT3D(adNorm1, adNorm3);
  values[1] = GR_acos(dot); // Edge AC

  dot = -dDOT3D(adNorm2, adNorm3);
  values[0] = GR_acos(dot); // Edge AB
}
