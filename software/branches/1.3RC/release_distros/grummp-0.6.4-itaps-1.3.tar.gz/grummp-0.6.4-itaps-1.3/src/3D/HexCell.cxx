#include <math.h>
#include "GR_misc.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_Vertex.h"
#include "GR_Vec.h"

const Vert* HexCell::pVVert(const int i) const
{
  assert(iFullCheck());
  assert(i >= 0 && i <= 7);
  switch (i) {
  case 0:
    return pVCommonVert(ppFFaces[0], ppFFaces[1], ppFFaces[4]);
  case 1:
    return pVCommonVert(ppFFaces[0], ppFFaces[2], ppFFaces[1]);
  case 2:
    return pVCommonVert(ppFFaces[0], ppFFaces[3], ppFFaces[2]);
  case 3:
    return pVCommonVert(ppFFaces[0], ppFFaces[4], ppFFaces[3]);
  case 4:
    return pVCommonVert(ppFFaces[5], ppFFaces[1], ppFFaces[4]);
  case 5:
    return pVCommonVert(ppFFaces[5], ppFFaces[2], ppFFaces[1]);
  case 6:
    return pVCommonVert(ppFFaces[5], ppFFaces[3], ppFFaces[2]);
  case 7:
    return pVCommonVert(ppFFaces[5], ppFFaces[4], ppFFaces[3]);
  default:
    // Should never get here in debug mode.
    assert(0);
    return pVInvalidVert;
  }
}

void HexCell::vAllVertHandles(GRUMMP_Entity* aHandles[]) const
{
  assert(iFullCheck());
  for (int i = 0; i < 8; i++) {
    aHandles[i] = const_cast<Vert*>(pVVert(i));
  }
}

double HexCell::dSize() const
{
  assert2(0, "Volume calculation not supported for hexes");
  assert(iFullCheck());
//   const Vert *pV0, *pV1, *pV2;
//   const Face* const pFBase = ppFFaces[0];
//   pV0 = pFBase->pVVert(0);
//   if (pFBase->pCCellRight() == (const Cell*)this) {
//     pV1 = pFBase->pVVert(1);
//     pV2 = pFBase->pVVert(2);
//   }
//   else {
//     pV1 = pFBase->pVVert(2);
//     pV2 = pFBase->pVVert(1);
//   }

  return (0);
}

bool HexCell::qIsClosed() const
{
#ifndef NDEBUG
  #warning Hex closure check is weak!
#endif
  for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
    const Face *pF = pFFace(iF);
    for (int iV = pF->iNumVerts() - 1; iV >= 0; iV--) {
      if (!qHasVert(pF->pVVert(iV)))
	return false;
    }
  }
  return true;
}
