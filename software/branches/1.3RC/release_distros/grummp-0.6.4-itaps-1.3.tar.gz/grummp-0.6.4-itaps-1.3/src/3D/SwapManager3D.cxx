#include "GR_EdgeCanon.h"
#include "GR_EdgeSwapInfo.h"
#include "GR_FaceSwapInfo.h"
#include "GR_Geometry.h"
#include "GR_SwapManager.h"
#include "GR_SwapDecider.h"
#include "GR_VolMesh.h"

#ifdef SIM_ANNEAL_TEST
extern double simAnnealTemp;
#endif

namespace GRUMMP {
  
  SwapManager3D::~SwapManager3D()
  {
    m_pVM->removeObserver(this);
    vMessage(2, "SwapManager exiting.\n");
    vMessage(2, "  Used a %s SwapDecider.\n", m_pSD->getName().c_str());
    vMessage(2, "  Face swapping stats: \n");
    vMessage(2, "    T22: %6d swaps out of %6d attempts\n",
	     m_faceSuccesses[FaceSwapInfo3D::eT22],
	     m_faceAttempts[FaceSwapInfo3D::eT22]);
    vMessage(2, "    T23: %6d swaps out of %6d attempts\n",
	     m_faceSuccesses[FaceSwapInfo3D::eT23],
	     m_faceAttempts[FaceSwapInfo3D::eT23]);
    vMessage(2, "    T32: %6d swaps out of %6d attempts\n",
	     m_faceSuccesses[FaceSwapInfo3D::eT32],
	     m_faceAttempts[FaceSwapInfo3D::eT32]);
    vMessage(2, "    T44: %6d swaps out of %6d attempts\n",
	     m_faceSuccesses[FaceSwapInfo3D::eT44],
	     m_faceAttempts[FaceSwapInfo3D::eT44]);
    vMessage(2, "  Edge swapping stats: \n");
    for (int i = 3; i < 11; i++) {
      vMessage(2, "    %2d tets for %2d:  %6d out of %6d attempts\n",
	       i, 2*i-4, m_edgeSuccesses[i], m_edgeAttempts[i]);
    }		 
  }

  int SwapManager3D::swapFace(Face* pF)
  {
    VALIDATE_INPUT(pF->qValid());
    if (pF->qDeleted()) return 0;
    FaceSwapInfo3D FC;
    FC.categorizeFace(pF);
    return swapFace(FC);
  }

  int SwapManager3D::swapFace(const FaceSwapInfo3D& FC)
  {
    FaceSwapInfo3D::faceCat fc = FC.getFaceCat();
    switch (fc) {
    case eT22:
    case eT23:
    case eT32:
    case eT44:
      m_faceAttempts[fc]++;
      if (m_pSD->doFaceSwap(FC) && reconfigure(FC)) {
	m_faceSuccesses[fc]++;
	return 1;
      }
      else
	return 0;
      break;
    case eN32:
    case eN44:
      {
	EdgeSwapInfo ES(FC);
	m_edgeAttempts[ES.getNumOrigCells()]++;
	if (m_pSD->doEdgeSwap(ES)) {
	  reconfigureEdge(ES);
	  m_edgeSuccesses[ES.getNumOrigCells()]++;
	  return (ES.getNumOrigVerts() - 2);
	}
	else return 0;
      }
      break;
    default:
      return 0;
      break;
    }
  }

  int SwapManager3D::swapAllFaces()
  {
    // Initialize the queue with all the faces in the mesh.
    EntContainer<TriFace>::iterator ECiter = m_pVM->triFace_begin(),
      ECiterEnd = m_pVM->triFace_end();
    for ( ; ECiter != ECiterEnd; ++ECiter) {
      Face *pF = &(*ECiter);
      faceQueue.insert(pF);
    }

    int numSwaps = 0, swapsThisPass = 0, passes = 0;
    do {
      int attempts = faceQueue.size();
      swapsThisPass = swapAllQueuedFaces();
      numSwaps += swapsThisPass;
      passes++;

      vMessage(2, "Pass %d, %d swaps out of %d attempts\n",
	       passes, swapsThisPass, attempts);
      m_pVM->sendEvents();
      vMessage(2, "  Master swap queue now has %zu faces.\n",
	       faceQueue.size());
#ifdef SIM_ANNEAL_TEST
      vMessage(2, "  Sim anneal temp is %f\n", simAnnealTemp);
      simAnnealTemp /= 1.1;
    } while (swapsThisPass != 0 && simAnnealTemp > 1.e-6);
#else
    } while (swapsThisPass != 0 && passes < 20);
#endif
    return numSwaps;
  }

  int SwapManager3D::swapAllQueuedFaces()
  {
    std::set<Face*> liveFaceQueue;

    // Initialize the queue with all the faces in the queue.
    swap(faceQueue, liveFaceQueue);

    std::set<Face*>::iterator iter = liveFaceQueue.begin(),
      iterEnd = liveFaceQueue.end();
    int numSwaps = 0;
    for ( ; iter != iterEnd; iter++) {
      Face *pF = *iter;
      numSwaps += swapFace(pF);
    } // for
    
    return numSwaps;
  }

  bool SwapManager3D::reconfigure(const FaceSwapInfo3D& FC) 
  {
    assert(!FC.getFace()->qLocked());

    Cell* pTets[4];
    int nTets;
    FC.getTets(nTets, pTets);

    Vert *pVA = FC.getVertA();
    Vert *pVB = FC.getVertB();
    Vert *pVC = FC.getVertC();
    Vert *pVD = FC.getVertD();
    Vert *pVE = FC.getVertE();
    Vert *pVF = FC.getVertF();

    switch (FC.getFaceCat()) {
    case eT22:
      return (reconfTet22(pTets, pVA, pVB, pVC, pVD, pVE, pVF,
			  FC.getBFaceA(), FC.getBFaceB()));
    case eT23:
      return (reconfTet23(pTets, pVA, pVB, pVC, pVD, pVE, pVF));
    case eT32:
      return (reconfTet32(pTets, pVA, pVB, pVC, pVD, pVE, pVF));
    case eT44:
      return (reconfTet44(pTets, pVA, pVB, pVC, pVD, pVE, pVF));
    default:
      assert2(0, "Bad face type in reconfigure");
      return false;
    }
  }

  //@@ Swap two tets for three.
  bool SwapManager3D::reconfTet23(Cell* pTets[4],
				  Vert *const pVVertA, Vert* const pVVertB,
				  Vert *const pVVertC, Vert *const pVVertD,
				  Vert *const pVVertE, Vert *const pVVertF)
  {
    assert(pTets[0] != NULL && pTets[1] != NULL && 
	   pVVertA != NULL && pVVertB != NULL && pVVertC != NULL &&
	   pVVertD != NULL && pVVertE != NULL);
    assert(pTets[2] == NULL && pTets[3] == NULL && pVVertF == NULL);
    // Identify both cells and all seven faces in the two-tet config.
    Cell* pTetD = pTets[0];
    Cell* pTetE = pTets[1];
    int iRegion = pTetD->iRegion();

    // Delete old tets
    m_pVM->deleteCell(pTetD);
    m_pVM->deleteCell(pTetE);

    // Create three new tets
    bool qExist;

    TetCell *pTCTetA = m_pVM->createTetCell(qExist, pVVertB, pVVertC,
					    pVVertD, pVVertE, iRegion);
    assert(!qExist);

    TetCell *pTCTetB = m_pVM->createTetCell(qExist, pVVertC, pVVertA,
					    pVVertD, pVVertE, iRegion);
    assert(!qExist);

    TetCell *pTCTetC = m_pVM->createTetCell(qExist, pVVertA, pVVertB,
					    pVVertD, pVVertE, iRegion);
    assert(!qExist);

    assert(!pTCTetA->qHasVert(pVVertA));
    assert(!pTCTetB->qHasVert(pVVertB));
    assert(!pTCTetC->qHasVert(pVVertC));
    // Orientation and correctness tests for the tets are done at
    // creation time; it's a waste of time to repeat the assertions.

    return true;
  }

  //@@ Swap three tets for two.
  bool SwapManager3D::reconfTet32(Cell* pTets[4],
				  Vert *const pVVertA, Vert* const pVVertB,
				  Vert *const pVVertC, Vert *const pVVertD,
				  Vert *const pVVertE, Vert *const pVVertF)
  {
    assert(pTets[0] != NULL && pTets[1] != NULL && pTets[2] != NULL &&
	   pVVertA != NULL && pVVertB != NULL && pVVertC != NULL &&
	   pVVertD != NULL && pVVertE != NULL);
    assert(pTets[3] == NULL && pVVertF == NULL);
    Cell* pTetA = pTets[0];
    Cell* pTetB = pTets[1];
    Cell* pTetC = pTets[2];
    int iRegion = pTetA->iRegion();
    if ( (iRegion != pTetB->iRegion()) ||
	 (iRegion != pTetC->iRegion()) ) return false;

    // Delete tets
    m_pVM->deleteCell(pTetA);
    m_pVM->deleteCell(pTetB);
    m_pVM->deleteCell(pTetC);

    // Create new tets
    bool qExist;
    TetCell *pTetD = m_pVM->createTetCell(qExist, pVVertA, pVVertC,
					  pVVertB, pVVertD, iRegion);
    assert(!qExist);

    TetCell *pTetE = m_pVM->createTetCell(qExist, pVVertA, pVVertB,
					  pVVertC, pVVertE, iRegion);
    assert(!qExist);

    assert(pTetD->qHasVert(pVVertD));
    assert(pTetE->qHasVert(pVVertE));

    return true;
  }

//@@ Swap two tets for two, in the case where two faces are coplanar.
  bool SwapManager3D::reconfTet22(Cell* pTets[4],
				  Vert *const pVVertA, Vert* const pVVertB,
				  Vert *const pVVertC, Vert *const pVVertD,
				  Vert *const pVVertE, Vert *const pVVertF,
				  TriBFace *const pTBFA,
				  TriBFace *const pTBFB)
  {
    // This routine does only the 2-to-2 case.  4-to-4 is done elsewhere.
    // The cells and verts are assumed to have been set up properly already.

    /*      	        C
        	       /\
        	      /||\
        	     / |  \                 A,D are on the base;
       	       	    /  | | \                B,E are front, C,F are back.
  		   /   |    \               Cell A is on the left, B on
        	  /    |  |  \	            the right.
        	 /     |      \
  		/      |   |   \
  	       /     C |     F  \
  	      /	       |  E |    \
  	     /   B     | _ - B    \
  	    /  _ _ - - |    /  - _ \
  	   D -         |           -E
  	    -__	    A  |  /  D  __--
  	       -__     |     __-
  	     	  -___ |/__--
  	     	      -A-

    */
    assert(pTets[0] != NULL && pTets[1] != NULL &&
	   pVVertA != NULL && pVVertB != NULL && pVVertC != NULL &&
	   pVVertD != NULL && pVVertE != NULL);
    assert(pTets[2] == NULL && pTets[3] == NULL && pVVertF == NULL);
    Cell* pTCTetA = pTets[0];
    Cell* pTCTetB = pTets[1];

    // Do the actual two-for-two swap here.  The faces all stay in the
    // same places except for pFFace, the dividing face, which gets turned.
    // Cell A ends up in front, cell B in back.  The only vert hints
    // affected are for verts 1 and 2, which can be set explicitly.
    
    int iRegion = pTCTetA->iRegion();
    assert(iRegion == pTCTetB->iRegion());
    
    // Delete old cells
    m_pVM->deleteCell(pTCTetA);
    m_pVM->deleteCell(pTCTetB);
    
    bool qExist;
    pTCTetA = m_pVM->createTetCell(qExist, pVVertD, pVVertA,
				   pVVertE, pVVertC, iRegion);
    assert(!qExist);

    pTCTetB = m_pVM->createTetCell(qExist, pVVertE, pVVertB,
				   pVVertD, pVVertC, iRegion);
    assert(!qExist);

    Face *pFBdryA = pTCTetA->pFFaceOpposite(pVVertC);
    Face *pFBdryB = pTCTetB->pFFaceOpposite(pVVertC);
    m_pVM->createBFace(pFBdryA, pTBFA);
    m_pVM->createBFace(pFBdryB, pTBFA);

    // Delete bdry faces now
    m_pVM->deleteBFace(pTBFA);
    m_pVM->deleteBFace(pTBFB);

    return true;
  }

  //@@ Swap four tets for four, in the case where two faces are coplanar.
  bool SwapManager3D::reconfTet44(Cell* pTets[4],
				  Vert *const pVVertA, Vert* const pVVertB,
				  Vert *const pVVertC, Vert *const pVVertD,
				  Vert *const pVVertE, Vert *const pVVertF)
  {
    // The cells and verts are assumed to have been set up properly already.
    
    // Here's the before picture:
    /*      	        C
        	       /\
        	      /||\
        	     / |  \                 A,D are on the base;
       	       	    /  | | \                B,E are front, C,F are back.
  		   /   |    \               Cell A is on the left, B on
        	  /    |  |  \	            the right.
        	 /     |      \
  		/      |   |   \
  	       /     C |     F  \
  	      /	       |  E |    \
  	     /   B     | _ - B    \
  	    /  _ _ - - |    /  - _ \
  	   D -         |           -E
  	    -__	    A  |  /  D  __--
  	       -__     |     __-
  	     	  -___ |/__--
  	     	      -A-

  	               ___---B_
  	       ____----	    /  --__
  	   D---            /       -E
  	    - _	    A     / |D  _ -
  	    \  - _       /   _ -   /
             \     -_   / _-      /
  	      \       -A-  |     /
  	       \     C1|     F1 /
  		\      |  |    /
        	 \ B1  |  E1  /
        	  \    |     /	            A,D are on the base;
  		   \   | |  /               B1,E1 are front, C1,F1 are back.
       	       	    \  |   /                Cell A1 is on the left, B1 on
        	     \ || /                 the right.
        	      \| /                  Face G divides these two cells.
        	       \/
                       C1

    */
    assert(pTets[0] != NULL && pTets[1] != NULL &&
	   pTets[2] != NULL && pTets[3] != NULL &&
	   pVVertA != NULL && pVVertB != NULL && pVVertC != NULL &&
	   pVVertD != NULL && pVVertE != NULL);
    Cell* pTCTetA = pTets[0];
    Cell* pTCTetB = pTets[1];
    Cell* pTCTetC = pTets[2];
    Cell* pTCTetD = pTets[3];
    
    int iReg = pTCTetA->iRegion();
    int iReg1 = pTCTetC->iRegion();
    // Delete all four tets
    m_pVM->deleteCell(pTCTetA);
    m_pVM->deleteCell(pTCTetB);
    m_pVM->deleteCell(pTCTetC);
    m_pVM->deleteCell(pTCTetD);
    
    // Now create four new tets directly from verts.
    bool qExist;
    pTCTetA = m_pVM->createTetCell(qExist, pVVertD, pVVertA,
				   pVVertE, pVVertC, iReg);
    assert(!qExist);
    pTCTetB = m_pVM->createTetCell(qExist, pVVertE, pVVertB,
				   pVVertD, pVVertC, iReg);
    assert(!qExist);
    
    pTCTetC = m_pVM->createTetCell(qExist, pVVertE, pVVertA,
				   pVVertD, pVVertF, iReg1);
    assert(!qExist);
    pTCTetD = m_pVM->createTetCell(qExist, pVVertD, pVVertB,
				   pVVertE, pVVertF, iReg1);
    assert(!qExist);
    return true;
  }

 void SwapManager3D::receiveDeletedFaces(std::vector<Face*>& deletedFaces)
  {
    vMessage(4, "SwapManager3D received word about %zu deleted faces.\n",
	     deletedFaces.size());
    std::vector<Face*>::iterator iter = deletedFaces.begin(),
      iterEnd = deletedFaces.end();
    for ( ; iter != iterEnd; ++iter ) {
      Face *pF = *iter;
      faceQueue.erase(pF);
    }
  }

  void SwapManager3D::receiveCreatedCells(std::vector<Cell*>& createdCells)
  {
    vMessage(4, "SwapManager3D received word about %zu new cells.\n",
	     createdCells.size());
    std::vector<Cell*>::iterator iter = createdCells.begin(),
      iterEnd = createdCells.end();
    for ( ; iter != iterEnd; ++iter) {
      Cell *pC = *iter;
      if (pC->eType() != CellSkel::eTet) continue;
      for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
	Face *pF = pC->pFFace(i);
	faceQueue.insert(pF);
      }
    }
  }

  void SwapManager3D::receiveMovedVerts(std::vector<Vert*>& movedVerts)
  {
    vMessage(4, "SwapManager3D received word about %zu moved verts.\n",
	     movedVerts.size());
    std::vector<Vert*>::iterator iter = movedVerts.begin(),
      iterEnd = movedVerts.end();
    for ( ; iter != iterEnd; ++iter) {
      Vert *pV = *iter;
      // Need to be sure to get not just incident faces but also
      // opposite faces. 
      for (int i = pV->iNumFaces() - 1; i >= 0; i--) {
        Face *pF = pV->pFFace(i);
	Cell *pC = pF->pCCellLeft();
	for (int ii = pC->iNumFaces() - 1; ii >= 0; ii--) {
	  faceQueue.insert(pC->pFFace(ii));
	}

	pC = pF->pCCellRight();
	for (int ii = pC->iNumFaces() - 1; ii >= 0; ii--) {
	  faceQueue.insert(pC->pFFace(ii));
	}
      }
    }
  }

  void SwapManager3D::reconfigureEdge(const EdgeSwapInfo& ES)
  {
    // The interior version; the bdry version calls this, then does a
    // little post-processing to get bfaces set up properly.

    // If the highest-quality alternative is better than the current
    // configuration:
    unsigned numOrigCells = ES.getNumOrigCells();
    unsigned numOrigVerts = ES.getNumOrigVerts();

    // Get the region identifier for this collection of tets.
    int iReg = ES.getOrigCell(0)->iRegion();

    // Delete all of the interior tets and faces.  These must be
    // separate loops, or forced.
    for (unsigned i = 0; i < numOrigCells; i++) {
      m_pVM->deleteCell(ES.getOrigCell(i));
      assert(iReg == ES.getOrigCell(i)->iRegion());
    }

    // The old version stored all the newly-created cells for two
    // reasons:
    //   1. So that their faces could be swapped recursively.  With
    //      Observer, that's now handled, including automatically
    //      handling cases where recursion isn't desired.
    //   2. To post-check cells for correctness.  This is done in the
    //      tet cell creation code, so it doesn't need to be done again.

    // Also, old face data isn't needed anymore (it was only used for
    // post-validation, which is handled internal to the new creation
    // calls.

    // Get the new configuration data.
    unsigned bestCanon, bestPerm;
    ES.getNewConfig(bestCanon, bestPerm);
    EdgeConfig& Conf = EdgeConfigs::getInstance().getConfSet(numOrigVerts).
      getConfig(bestCanon);

    int iOrient = 0;

    // There are numOrigVerts - 2 triangles on the equator, two tets apiece,
    // four verts per tet.
    Vert *northVert = ES.getNorthVert();
    Vert *southVert = ES.getSouthVert();

    for (unsigned i = 0; i < numOrigVerts -2; i++) {
      // These are the equatorial tris, so all these indices should be
      // positive. 
      assert(Conf.getFaceVert(i, 0) >= 0);
      assert(Conf.getFaceVert(i, 1) >= 0);
      assert(Conf.getFaceVert(i, 2) >= 0);
      Vert* pVert0 = ES.getVert((Conf.getFaceVert(i, 0)+bestPerm)%numOrigVerts);
      Vert* pVert1 = ES.getVert((Conf.getFaceVert(i, 1)+bestPerm)%numOrigVerts);
      Vert* pVert2 = ES.getVert((Conf.getFaceVert(i, 2)+bestPerm)%numOrigVerts);

      // Calculate the orientation exactly once.
      if (iOrient == 0)
	iOrient = iOrient3D(pVert0, pVert1, pVert2, northVert);
      
      if (iOrient == 1) {
	assert(iOrient3D(pVert0, pVert1, pVert2, northVert) == 1);
	assert(iOrient3D(pVert0, pVert2, pVert1, southVert) == 1);
	bool qExist;
	Cell *pC;
	pC = m_pVM->createTetCell(qExist, pVert0, pVert1, pVert2, northVert,
				  iReg);
	assert(pC->qValid() && !qExist);
	pC = m_pVM->createTetCell(qExist, pVert0, pVert2, pVert1, southVert,
				  iReg);
	assert(pC->qValid() && !qExist);
      }
      else {
	assert(iOrient3D(pVert0, pVert2, pVert1, northVert) == 1);
	assert(iOrient3D(pVert0, pVert1, pVert2, southVert) == 1);
	bool qExist;
	Cell *pC;
	pC = m_pVM->createTetCell(qExist, pVert0, pVert2, pVert1, northVert,
				  iReg);
	assert(pC->qValid() && !qExist);
	pC = m_pVM->createTetCell(qExist, pVert0, pVert1, pVert2, southVert,
				  iReg);
	assert(pC->qValid() && !qExist);
      }
    }

    // Old code marked vertices for smoothing; Observer makes this
    // unneccessary.

    // Tet and face validation is done when they're created.

    // Swap recursion has been replaced by batch queueing of faces that
    // would otherwise be swapped.

    if (ES.isBdryEdge()) {
      // Replace the two bdry faces.
      BFace* oldBFace0 = ES.getBFace(0);
      BFace* oldBFace1 = ES.getBFace(1);
      
      // Retrieve the faces that were just created on the boundary.
      Face *faceOnBdry0, *faceOnBdry1;
      {
	Vert *pV0 = ES.getVert(0);
	Vert *pV1 = ES.getVert(numOrigVerts - 1);
	
	faceOnBdry0 = findCommonFace(pV0, pV1, northVert);
	assert(faceOnBdry0->qValid()); // Just created them; they'd -better- exist!
	// Exactly one cell should exist
	assert(faceOnBdry0->pCCellLeft()->qValid() ^ faceOnBdry0->pCCellRight()->qValid());
	
	faceOnBdry1 = findCommonFace(pV1, pV0, southVert);
	assert(faceOnBdry1->qValid()); // Just created them; they'd -better- exist!
	// Exactly one cell should exist
	assert(faceOnBdry1->pCCellLeft()->qValid() ^ faceOnBdry1->pCCellRight()->qValid());
      }
      
      // Attach the new faces to the bdry faces.
      BFace* newBFace0 = m_pVM->createBFace(faceOnBdry0, oldBFace0);
      BFace* newBFace1 = m_pVM->createBFace(faceOnBdry1, oldBFace1);
      assert(newBFace0->qValid());
      assert(newBFace1->qValid());
      
      // Delete the old faces on the boundary.
      m_pVM->deleteBFace(oldBFace0);
      m_pVM->deleteBFace(oldBFace1);
    }
  }
} // namespace GRUMMP
