#include <algorithm>

#include "GR_Observable.h"
#include "GR_Observer.h"
#include "GR_misc.h"

namespace GRUMMP {
  
  Observable::Observable() :
    m_allObservedEvents(0), m_eventCount(0), m_eventThreshold(1000), m_OKToSend(true)
  {}
  
  size_t Observable::addObserver(Observer* obs, const unsigned events)
  {
    // An Observer have more than one entry in the map.
    m_observers.insert(ObsPair(obs, events));
    m_allObservedEvents |= events;
    vMessage(2, "Added observer of events %u; all observed events: %u\n",
	     events, m_allObservedEvents);
    return m_allObservedEvents;
  }

  size_t Observable::removeObserver(Observer* obs)
  {
    m_observers.erase(obs);
    m_allObservedEvents = 0;
    ObsContIter iter = m_observers.begin(), iterEnd = m_observers.end();
    for ( ; iter != iterEnd ; ++iter) {
      unsigned int oe = iter->second;
      m_allObservedEvents |= oe;
    }
    return m_allObservedEvents;
  }

  template<class T>
  void Observable::deleteEvent(T* t, std::vector<T*>& deletedEnts,
			       std::vector<T*>& createdEnts)
  {
    typename std::vector<T*>::iterator iter =
      std::find(createdEnts.begin(), createdEnts.end(), t);

    if (iter != createdEnts.end()) {
      createdEnts.erase(iter);
      m_eventCount--;
    }
    else {
      deletedEnts.push_back(t);
      m_eventCount++;
    }
    if (m_eventCount >= m_eventThreshold) sendEvents();
  }

  void Observable::deleteVertEvent(Vert* v)
  {
    if (m_allObservedEvents & (vertDeleted | vertCreated | vertMoved)) {
      deleteEvent(v, m_deletedVerts, m_createdVerts);
      if (m_allObservedEvents & vertMoved) {
	std::vector<Vert*>::iterator iter =
	  std::find(m_movedVerts.begin(), m_movedVerts.end(), v);

	if (iter != m_movedVerts.end()) {
	  m_movedVerts.erase(iter);
	  m_eventCount--;
	}
      }      
    }
  }

  void Observable::deleteFaceEvent(Face* f)
  {
    if (m_allObservedEvents & (faceDeleted | faceCreated))
      deleteEvent(f, m_deletedFaces, m_createdFaces);
  }

  void Observable::deleteBFaceEvent(BFace* bf)
  {
    if (m_allObservedEvents & (bfaceDeleted | bfaceCreated))
      deleteEvent(bf, m_deletedBFaces, m_createdBFaces);
  }

  void Observable::deleteCellEvent(Cell* c)
  {
    if (m_allObservedEvents & (cellDeleted | cellCreated))
      deleteEvent(c, m_deletedCells, m_createdCells);
  }

  template<class T>
  void Observable::createEvent(T* t, std::vector<T*>& createdEnts)
  {
    createdEnts.push_back(t);
    m_eventCount++;

    if (m_eventCount >= m_eventThreshold) sendEvents();
  }

  void Observable::createVertEvent(Vert* v)
  {
    if (m_allObservedEvents & (vertCreated | vertDeleted))
      createEvent(v, m_createdVerts);
  }

  void Observable::createFaceEvent(Face* f)
  {
    if (m_allObservedEvents & (faceCreated | faceDeleted))
      createEvent(f, m_createdFaces);
  }

  void Observable::createBFaceEvent(BFace* bf)
  {
    if (m_allObservedEvents & (bfaceCreated | bfaceDeleted))
      createEvent(bf, m_createdBFaces);
  }

  void Observable::createCellEvent(Cell* c)
  {
    if (m_allObservedEvents & (cellCreated | cellDeleted))
      createEvent(c, m_createdCells);
  }

  void Observable::moveVertEvent(Vert* v)
  {
    if (m_allObservedEvents & vertMoved) {
      m_movedVerts.push_back(v);
      m_eventCount++;
      
      if (m_eventCount >= m_eventThreshold) sendEvents();
    }
  }

  void Observable::sendEvents()
  {
    if (!m_OKToSend) return;
    ObsContIter iter = m_observers.begin(), iterEnd = m_observers.end();
    for ( ; iter != iterEnd ; ++iter) {
      Observer* obs = iter->first;
      unsigned int oe = iter->second;

      vMessage(4, "Sending info about mesh changes.  Recorded the following:\n");
      vMessage(4, "  Verts: %8zu deleted, %8zu created, %8zu moved.\n",
	       m_deletedVerts.size(), m_createdVerts.size(),
	       m_movedVerts.size());
      vMessage(4, "  Faces: %8zu deleted, %8zu created.\n",
	       m_deletedFaces.size(), m_createdFaces.size());
      vMessage(4, "  Cells: %8zu deleted, %8zu created.\n",
	       m_deletedCells.size(), m_createdCells.size());
      vMessage(4, "  BFaces: %8zu deleted, %8zu created.\n",
	       m_deletedBFaces.size(), m_createdBFaces.size());
      vMessage(4, "  Observer asking for %u\n", oe);

      // Send deleted stuff first.
      if (oe & vertDeleted) obs->receiveDeletedVerts(m_deletedVerts);
      if (oe & faceDeleted) obs->receiveDeletedFaces(m_deletedFaces);
      if (oe & cellDeleted) obs->receiveDeletedCells(m_deletedCells);
      if (oe & bfaceDeleted) obs->receiveDeletedBFaces(m_deletedBFaces);

      if (oe & vertCreated) obs->receiveCreatedVerts(m_createdVerts);
      if (oe & faceCreated) obs->receiveCreatedFaces(m_createdFaces);
      if (oe & cellCreated) obs->receiveCreatedCells(m_createdCells);
      if (oe & bfaceCreated) obs->receiveCreatedBFaces(m_createdBFaces);

      if (oe & vertMoved) obs->receiveMovedVerts(m_movedVerts);

    } // Loop over observers
    m_deletedVerts.clear();
    m_deletedFaces.clear();
    m_deletedCells.clear();
    m_deletedBFaces.clear();
    m_createdVerts.clear();
    m_createdFaces.clear();
    m_createdCells.clear();
    m_createdBFaces.clear();
    m_movedVerts.clear();
    
    m_eventCount = 0;
  } // sendEvents
} // namespace GRUMMP
