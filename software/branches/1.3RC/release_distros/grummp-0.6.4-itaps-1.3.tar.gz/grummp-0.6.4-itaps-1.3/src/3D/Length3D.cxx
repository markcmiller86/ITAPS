#include "GR_Length3D.h"
#include "GR_BFace.h"
#include "GR_Cell.h"
#include "GR_events.h"
#include "GR_Mesh.h"
#include "GR_misc.h"
#include "GR_Subseg.h"
#include "GR_TetMeshRefiner.h"
#include "GR_Vec.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

#include <queue>
#include <vector>
#include <set>

using std::set;
using std::vector;

double Length3D::sq_distance_to_subseg(const Vert* const vert0,
				       const Subseg* const subseg) {

  assert(vert0 && vert0->qValid() && !vert0->qDeleted());
  assert(subseg && subseg->is_not_deleted());

  double close[3];
  subseg->closest_on_subseg(vert0->adCoords(), close);
  return dDIST_SQ_3D(vert0->adCoords(), close);

}

double Length3D::sq_distance_to_bface(const Vert* const vert0,
				      const BFace* const bface) {

  assert(vert0 && vert0->qValid() && !vert0->qDeleted());
  assert(bface && bface->qValid() && !bface->qDeleted());
  assert(bface->eType() == Cell::eTriBFace ||
	 bface->eType() == Cell::eIntTriBFace);
  assert(bface->iNumFaces() == 1 || bface->iNumFaces() == 2);
  assert(!bface->qHasVert(vert0));

  double close[3];
  bface->closest_on_bface(vert0->adCoords(), close);
  return dDIST_SQ_3D(vert0->adCoords(), close);

}

void Length3D::init_length(const VolMesh* const mesh) {

  SUMAA_LOG_EVENT_BEGIN(INIT_LENGTH);

  int ii, num_verts = mesh->iNumVerts();
  Vert *vert0;
  
  for(ii = 0; ii < num_verts; ++ii) {

    vert0 = mesh->pVVert(ii);
    if( vert0->qDeleted() ) continue;

    assert(vert0->qValid());

    //Set a very large length scale to start 
    //and then initialize length.
    vert0->vSetLS(LARGE_DBL);  
    init_vert_length(vert0);

  }

#ifndef NDEBUG
  m_length_initialized = true;
#endif

  //Once all length scales are initialized, 
  //set the graded length.
  set_graded_length();

  SUMAA_LOG_EVENT_END(INIT_LENGTH);

}

void Length3D::init_vert_length(Vert* const vert0) {

#ifndef NDEBUG
  
  assert(m_subseg_map);
  assert(vert0 && vert0->qValid() && !vert0->qDeleted());
  assert(m_min_length > 0.);

  //Initialization must be performed before any 
  //interior vertices get inserted.
  int vert_type = vert0->iVertType();
  assert( vert_type == Vert::eBdryApex || vert_type == Vert::eBdryCurve ||
	  vert_type == Vert::eBdry || vert_type == Vert::eBdryTwoSide );

#endif

  double min_dist = LARGE_DBL;

  get_neighborhood(vert0);
  assert( !m_neigh.verts.empty() && !m_neigh.cells.empty() &&
	  !m_neigh.bfaces.empty() );

  //Go through the three phases to initialize the vert's length scale.
  //(see each functions for more comments).
  comp_length_phase1(vert0, min_dist);
  comp_length_phase2(vert0, min_dist);
  comp_length_phase3(vert0, min_dist);

  //We found the local feature size of vert0, assign it a length_scale. 
  vert0->vSetLS( std::min( (sqrt(min_dist) / m_refine), m_min_length ) );

  //Queue the vert to set the graded length.
  m_length_check_queue.push(vert0);

}

void Length3D::comp_length_phase1(Vert* const vert0, double& min_dist) {

  assert(m_subseg_map);

  //Phase 1 only applies to apex and curve vertices ONLY during 
  //length initialization. Sets a ceiling local feature size
  //based on the distance to the vertex closest to vert0 connected
  //by a subsegment (strongly depends on the scheme used to discretize
  //curves initially and on the number of vertices inserted during
  //boundary recovery). 

  if( vert0->iVertType() == Vert::eBdryApex || 
      vert0->iVertType() == Vert::eBdryCurve ) {

    Vert* vert1;
    vector<Vert*> subseg_neigh;
    m_subseg_map->get_connected_verts(vert0, subseg_neigh);
    vector<Vert*>::iterator 
      itv = subseg_neigh.begin(), itv_end = subseg_neigh.end();

    for( ; itv != itv_end; ++itv) {
      vert1 = *itv;
      assert(vert1->iVertType() == Vert::eBdryApex ||
	     vert1->iVertType() == Vert::eBdryCurve);
      min_dist = std::min( min_dist, dDIST_SQ_3D(vert0->adCoords(), vert1->adCoords()) );
    }
  
  }

  //Obviously, nothing to do for other vertex types.

}

void Length3D::comp_length_phase2(Vert* const vert0, double& min_dist,
				  Vert* const sub_vert1, Vert* const sub_vert2) {

#ifndef NDEBUG
  assert(m_subseg_map);
  if(sub_vert1 || sub_vert2) {
    assert(vert0->iVertType() == Vert::eBdryCurve);
    assert(sub_vert1 && sub_vert2);
    assert(m_subseg_map->verts_are_connected(vert0, sub_vert1));
    assert(m_subseg_map->verts_are_connected(vert0, sub_vert2));
  }
#endif

  //Phase 2 looks at the boundary faces attached to vert0 (boundary 1-star
  //of vert0). Find the minimum distance to boundary entities of this 1-star
  //(either distance to a subsegment or to a vertex). 
 
  vector<VertexPair> ring_edges;
  get_ring_edges(vert0, ring_edges);

  Vert* vert1, *vert2;
  Subseg* subseg;
  vector<VertexPair>::iterator 
    it = ring_edges.begin(), it_end = ring_edges.end();

  for( ; it != it_end; ++it) {
    vert1 = it->first;
    vert2 = it->second;
    //Find if the edge vert1 - vert2 on the periphery of the star is 
    //a subsegment. If so, then find the distance to the curve discretized
    //by this subsegment.
    subseg = m_subseg_map->verts_are_connected(vert1, vert2);
    if(subseg) {
      assert(!subseg->has_vert(vert0));
      if(subseg->has_vert(sub_vert1) || subseg->has_vert(sub_vert2)) { } //adjacent, skip it!
      else min_dist = std::min(min_dist, sq_distance_to_subseg(vert0, subseg));
    }
    //If the peripheral edge is not a subsegment, but vert0 is 
    //a surface vertex, we must still set a ceiling length scale based on
    //the closest vertex on the periphery of the star of bdry faces.
    //Strongly dependent on the surface discretization scheme.
    else if( vert0->iVertType() == Vert::eBdry || 
	     vert0->iVertType() == Vert::eBdryTwoSide ) {
      min_dist = MIN3(min_dist, 
		      2. * dDIST_SQ_3D(vert0->adCoords(), vert1->adCoords()), 
		      2. * dDIST_SQ_3D(vert0->adCoords(), vert2->adCoords()));
    }
  }

}

void Length3D::comp_length_phase3(Vert* const vert0, double& min_dist) {

  //The third and final phase finds all the cells attached to vert0.
  //Among these cells, it looks for boundary faces opposing vert0 
  //(on the periphery of the adjacent cells). Local feature size is
  //the closest distance to these boundary faces.

  if(m_neigh.my_vert != vert0) get_neighborhood(vert0);
  assert(!m_neigh.bfaces.empty());

  Cell* cell;
  Face* face;
  BFace* bface;
  set<TetRefinerEdge> edges;

  set<BFace*>::iterator
    itbf = m_neigh.bfaces.begin(), itbf_end = m_neigh.bfaces.end();

  for( ; itbf != itbf_end; ++itbf) {
    bface = *itbf;
    assert(bface->qHasVert(vert0));
    assert(bface->iNumVerts() == 3);
    switch(bface->pVVert(0) == vert0 ? 1 : 
	   bface->pVVert(1) == vert0 ? 2 : 3) {
    case 1: edges.insert( TetRefinerEdge(bface->pVVert(1), bface->pVVert(2)) ); break;
    case 2: edges.insert( TetRefinerEdge(bface->pVVert(0), bface->pVVert(2)) ); break;
    case 3: edges.insert( TetRefinerEdge(bface->pVVert(0), bface->pVVert(1)) ); break;
    }
  }

  set<Cell*>::iterator
    itc = m_neigh.cells.begin(), itc_end = m_neigh.cells.end();
  
  for( ; itc != itc_end; ++itc) {

    cell = *itc;
    face = cell->pFFaceOpposite(vert0);
    assert( !face->qHasVert(vert0) );
    assert( face->qHasCell(cell) );

    if( face->pCCellLeft()->eType()  == Cell::eTet &&
 	face->pCCellRight()->eType() == Cell::eTet ) continue;
    assert( face->pCCellLeft()->eType()  == Cell::eTet ||
 	    face->pCCellRight()->eType() == Cell::eTet ); 

    cell = cell == face->pCCellLeft() ? face->pCCellRight() : face->pCCellLeft();
    assert( cell->eType() == Cell::eTriBFace || cell->eType() == Cell::eIntTriBFace ); 

    bface = dynamic_cast<BFace*>(cell); assert(bface);
    assert(!bface->qHasVert(vert0));
    if( edges.count(TetRefinerEdge(bface->pVVert(0), bface->pVVert(1))) == 1 || 
	edges.count(TetRefinerEdge(bface->pVVert(0), bface->pVVert(2))) == 1 ||
	edges.count(TetRefinerEdge(bface->pVVert(1), bface->pVVert(2))) == 1 ) continue;

    min_dist = std::min(min_dist, sq_distance_to_bface(vert0, bface));

  }

}

void Length3D::set_given_length_scale(Vert* const vert0, double length) {

  vert0->vSetLS( std::min(length, m_min_length) );
  m_length_check_queue.push(vert0);
  set_graded_length();

}

void Length3D::set_curv_vert_length(Vert* const vert0,
				    const Subseg* const subseg0, const Subseg* const subseg1) {

  //The function sets the length scale for a curve vertex during refinement.

  //It first sets a ceiling on the length scale by linearly interpolating
  //between the two vertices connected to vert0 by a subsegment. 

  SUMAA_LOG_EVENT_BEGIN(LENGTH_SCALE);

  assert(m_length_initialized);
  assert(vert0 && vert0->qValid() && !vert0->qDeleted());
  assert(vert0->iVertType() == Vert::eBdryCurve);

  assert(subseg0 && subseg1);
  assert(subseg0->is_not_deleted());
  assert(subseg0->has_vert(vert0));
  assert(subseg1->is_not_deleted());
  assert(subseg1->has_vert(vert0));

  double length;
  m_neigh.my_vert = NULL;

  {

    Vert *vert1, *vert2;

    //This is the case where there is a curve attached to subseg0.
    if( subseg0->get_ref_edge() ) {
      assert( subseg0->get_ref_edge() == subseg1->get_ref_edge() );
      assert( iFuzzyComp(subseg0->get_vert_param(vert0), subseg1->get_vert_param(vert0)) == 0 );
      double param0 = subseg0->get_vert_param(vert0), param1, param2;
      subseg0->get_other_vert_data(vert0, vert1, param1);
      subseg1->get_other_vert_data(vert0, vert2, param2);
#ifndef NDEBUG
      if(param2 > param1) assert(param2 > param0 && param1 < param0);
      else                assert(param1 > param0 && param2 < param0);
#endif
      double slope = (vert2->dLS() - vert1->dLS()) / (param2 - param1);
      length = ( (param2 - param0) * slope + vert1->dLS() );
    }

    //No curve attached, take the average length scale.
    else { 
      subseg0->get_other_vert(vert0, vert1);
      subseg1->get_other_vert(vert0, vert2);
      length = 0.5 * (vert1->dLS() + vert2->dLS());
    }

    //If we interpolate the length scale from two apex vertices, 
    //there is the possibility of ending up with over-refinement in 
    //the middle of the curve (imagine if vert1 and vert2 have small 
    //length scale, while the first split point have a large length scale).
    //This is somewhat of a hack to dodge this. Only do it with the first
    //split point inserted on a curve, otherwise, experiment showed that 
    //we run the risk of ending up with decreasing length scales after each
    //insertion, which is bad (ugly point clusters along the curve).

    if(vert1->iVertType() == Vert::eBdryApex &&
       vert2->iVertType() == Vert::eBdryApex) {
      double min_dist = std::min( dDIST_SQ_3D(vert0->adCoords(), vert1->adCoords()),
				  dDIST_SQ_3D(vert0->adCoords(), vert2->adCoords()) );
      comp_length_phase2(vert0, min_dist, vert1, vert2);
      comp_length_phase3(vert0, min_dist);
      length = std::max(length, sqrt(min_dist) / m_refine);
    }

  }

  vert0->vSetLS( std::min(m_min_length, length) );

  m_length_check_queue.push(vert0);
  set_graded_length();

  SUMAA_LOG_EVENT_END(LENGTH_SCALE);

}

void Length3D::set_surf_vert_length(Vert* const vert0) {

  //The function sets the length scale for a surface vertex during refinement.

  SUMAA_LOG_EVENT_BEGIN(LENGTH_SCALE);

  assert(m_length_initialized);
  assert(vert0->iVertType() == Vert::eBdry ||
	 vert0->iVertType() == Vert::eBdryTwoSide);

  //Use a weighted average based on the ring of boundary faces 
  //are vert0 to compute its length scale.

  get_neighborhood(vert0);
  assert( !m_neigh.bfaces.empty() );

  Vert* vert;
  set<Vert*> verts_involved;
  set<Vert*>::iterator itv, itv_end;

  BFace* bface;
  set<BFace*>::iterator itb = m_neigh.bfaces.begin(), itb_end = m_neigh.bfaces.end();

  int i;
  double weight, sum_lengths = 0., sum_weights = 0., length;

  for( ; itb != itb_end; ++itb) {
    bface = *itb;
    assert(bface->iNumVerts() == 3);
    assert(bface->qHasVert(vert0));
    for(i = 0; i < 3; ++i) verts_involved.insert(bface->pVVert(i));
  }

  verts_involved.erase(vert0);
  itv     = verts_involved.begin();
  itv_end = verts_involved.end();

  for( ; itv != itv_end; ++itv) {
    vert = *itv;
    assert(vert != vert0);
    weight = 1. / dDIST3D(vert->adCoords(), vert0->adCoords());
    sum_lengths += weight * vert->dLS();
    sum_weights += weight;
  }

  length = sum_lengths / sum_weights;

  vert0->vSetLS( std::min(m_min_length, length) );
  m_length_check_queue.push(vert0);
  set_graded_length();
  
  SUMAA_LOG_EVENT_END(LENGTH_SCALE);

}

void Length3D::set_volu_vert_length(Vert* const vert0) {

  //Once the boundary have been refined to desired length,
  //the interior length scale is set depending solely on the grading factor.
  //This is simple enough...

  SUMAA_LOG_EVENT_BEGIN(LENGTH_SCALE);

  assert(m_length_initialized);
  assert( vert0->iVertType() == Vert::eInterior );

  vert0->vSetLS( std::min(m_min_length, LARGE_DBL) );
  m_length_check_queue.push(vert0);
  set_graded_length();

  SUMAA_LOG_EVENT_END(LENGTH_SCALE);

}

void Length3D::set_graded_length() {

  Vert *vert, *neigh_vert;
  double length_scale, lip_length, neigh_ls, neigh_dist;

  while(!m_length_check_queue.empty()) {

    vert = m_length_check_queue.front();
    m_length_check_queue.pop();

    lip_length = LARGE_DBL;
    length_scale = vert->dLS();
    get_neighborhood(vert);
    
    set<Vert*>::iterator it = m_neigh.verts.begin(), it_end = m_neigh.verts.end();
    
    for(; it != it_end; ++it) {

      neigh_vert = *it;
      neigh_ls   = neigh_vert->dLS();
      neigh_dist = dDistanceBetween(vert, neigh_vert);
     
      assert(iFuzzyComp(neigh_ls,   0.) == 1);
      assert(iFuzzyComp(neigh_dist, 0.) == 1);
    
      lip_length = std::min(lip_length, neigh_ls + (neigh_dist / m_grade) );

    }

    assert(iFuzzyComp(m_min_length, 0.) == 1);
    assert(iFuzzyComp(lip_length, 0.) == 1);

    length_scale = MIN3(m_min_length, lip_length, length_scale);
    vert->vSetLS(length_scale);  
    
  }
  
}

void Length3D::get_neighborhood(Vert* const vertex) {

  m_neigh.my_vert = vertex;

  if( vertex->iVertType() == Vert::eBdryApex ||
      vertex->iVertType() == Vert::eBdryCurve ||
      vertex->iVertType() == Vert::eBdry ||
      vertex->iVertType() == Vert::eBdryTwoSide ) {
    
    bool bdry_vert = true;
    vNeighborhood(vertex, m_neigh.cells, m_neigh.verts, 
		  &m_neigh.bfaces, &bdry_vert);

  }

  else 
    vNeighborhood(vertex, m_neigh.cells, m_neigh.verts);

}

void Length3D::get_ring_edges(Vert* const vert0, vector<VertexPair>& edges) {

  //If the stored neighborhood is not that of the vertex we want, then recompute it.
  if(m_neigh.my_vert != vert0) get_neighborhood(vert0);

  Vert* vert1, *vert2;
  BFace* bface;
  
  std::set<BFace*>::iterator 
    itbf = m_neigh.bfaces.begin(), itbf_end = m_neigh.bfaces.end();

  for( ; itbf != itbf_end; ++itbf) {

    bface = *itbf;
    assert(bface->iNumVerts() == 3);
    assert(bface->eType() == Cell::eTriBFace ||
	   bface->eType() == Cell::eIntTriBFace);
    
    switch( vert0 == bface->pVVert(0) ? 0 : 
	    vert0 == bface->pVVert(1) ? 1 : 2 ) {
    case 0: vert1 = bface->pVVert(1); vert2 = bface->pVVert(2); break;
    case 1: vert1 = bface->pVVert(0); vert2 = bface->pVVert(2); break;
    case 2: vert1 = bface->pVVert(0); vert2 = bface->pVVert(1); break;
    }

    assert(bface->qHasVert(vert0) && bface->qHasVert(vert1) && bface->qHasVert(vert2));
    assert(vert1 != vert2);
    assert(vert1 != vert0 && vert2 != vert0);

    edges.push_back(std::make_pair(vert1, vert2));

  }

}
