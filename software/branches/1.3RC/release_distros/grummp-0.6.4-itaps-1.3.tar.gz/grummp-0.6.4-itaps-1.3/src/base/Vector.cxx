#include "GR_Vector.h"
#include "GR_misc.h"

#include <cmath>

double GRUMMP::Vector::interior_angle( const GRUMMP::Vector& other_vec ) const {
  
  double arg, mag1 = this->length_squared(), mag2 = other_vec.length_squared();

  if( mag1 > 0. && mag2 > 0. ) 
    arg = (*this % other_vec) / sqrt(mag1 * mag2);
  else
    vFatalError("A vector has zero magnitude, impossible to compute angle",
		"GRUMMP::Vector::interior_angle");

  return ( (GR_acos(arg) * 180.) / M_PI );

}

bool GRUMMP::Vector::about_equal( const GRUMMP::Vector& other_vec, 
				  double rel_tolerance, double abs_tolerance ) const {

  assert( rel_tolerance >= 0. && abs_tolerance >= 0. );

  if( abs_tolerance > 0. ) {

    double diff_mag  = ( *this - other_vec ).length_squared();
    double a_tol_mag =  abs_tolerance * abs_tolerance;
    if( diff_mag <= a_tol_mag ) return true;

    if( rel_tolerance > 0. ) {

      double sum_mag   = ( *this + other_vec ).length_squared();
      double r_tol_mag = rel_tolerance * rel_tolerance;
      if( 4. * diff_mag <= sum_mag * r_tol_mag ) return true;

    }

  }

  else { //this is not really safe, but you asked for it...

    if( (m_x < other_vec.x() || m_x > other_vec.x()) ||
	(m_y < other_vec.y() || m_y > other_vec.y()) ||
	(m_z < other_vec.z() || m_z > other_vec.z()) ) return false;
    
    return true;

  }

  return false;

}

