#include <assert.h>
#include "GR_events.h"
#include "OptMS.h"


#ifdef SUMAA_LOG
static char GR_event_names[][32] = {
  "Total Time", "GUI being idle", "Read Bdry 2D", "Optimize Bdry2D",
  "Read Bdry 3D", "Read 2D Mesh", "Read Surf Mesh", "Read 3D Mesh",
  "Ruppert", "Init Ruppert", "InitRupp Large", "InitRupp Small",
  "Ruppert Loop", "Ruppert Bad Cell",
  "LFS Setup", "LFS Checking",
  "Shewchuk Driver", "Shewchuk Hull Manip", "Shewchuk Subsegs",
  "Shewchuk Subfacets",
  "Watson", " Watson Neighbors", " Watson Order",
  " Watson Insert", " Watson Check",
  "BdryWatson", " BdryWat Neighbors", " BdryWat Order",
  " BdryWat Insert", " BdryWat Check", " BdryWat Unknown",
  "Insertion queue", " Build IQ", " Refine using IQ",
  " Manip IQ", " Build IQ entry", " Query IQ entry", "Watson info",
  "Init Tri", "Init Surface Tri", "Init Tetra",
  "Length Scale", " Init Length Scale", " Update Length Scale",
  "Steiner",  " Steiner Cell Quality", 
  "Smoothing Passes", "Smooth + O/H", "Swapping Passes", "All Swapping",
  "Insert Vertex", "Delete Vertex", "Purge", "Classify Tets", "Quality Assess",
  "Fix Bad Tets", "Fix Bad Bdry Tets", "Mesh Output",
  "Curve discretization", "Surface sampling", "Boundary recovery",
  "CDT Construction", "Curve Sampling", "Small Angle Init", "Boundary C.D.",
  "Quality refinement", " Init Subseg Encroach", " Init Subface Encroach",
  "Test Probe 1", "Test Probe 2", "Test Probe 3",
  "Test Probe 4", "Test Probe 5"};
#endif

void vGRUMMPInitLogging(void)
{ 
#ifdef SUMAA_LOG
  int i_macro; 
  SMinitLogging(0, NULL); 
  for (i_macro = TOTAL_TIME; i_macro < FINAL; i_macro++) { 
    SUMAA_LOG_EVENT_REGISTER(i_macro, GR_event_names[i_macro-TOTAL_TIME]); 
  } 
#endif
}

void vGRUMMPFinishLogging(void)
{
#ifdef SUMAA_LOG
  /* This assertion fails for error exits. */
  /* assert(SUMAA_LOG_current == TOTAL_TIME); */
  SUMAA_LOG_EVENT_END(TOTAL_TIME);
  SUMAA_LOG_GLOBAL_TIME(TOTAL_TIME);
  SUMAA_LOG_PRINT;
  SUMAA_LOG_FREE;
#endif
}


