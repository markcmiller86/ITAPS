#include "GR_config.h"
#ifdef BROKEN_INLINE
#include "GR_assert.h"
#include "GR_BFace.h"

BFaceCV::BFaceCV(const int iNV, Vert** const ppVIn, const
                             int iBCIn)
{
  assert(iNV >= 1 && iNV <= 4);
  iN = iNV;
  iBC = iBCIn;
  ppV = new Vert*[iNV];
  if (ppVIn) {
    for (int i = 0; i < iNV; i++) {
      if (ppVIn[i] == pVInvalidVert)
        vFatalError("Invalid vertex assigned to boundary face",
                    "BFaceCV constructor");
      ppV[i] = ppVIn[i];
    }
  }
  else {
    for (int i = 0; i < iNV; i++)
      ppV[i] = pVInvalidVert;
  }
}

#endif


