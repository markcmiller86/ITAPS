#include "GR_GeomComp.h"
#include "GR_misc.h"
#include "GR_Vec.h"

void normal_to_plane( const double pt0[3], const double pt1[3], const double pt2[3],
		      double norm[3], const bool unit ) {

  double u[] = adDIFF3D(pt1, pt0);
  double v[] = adDIFF3D(pt2, pt0);
  vCROSS3D(u, v, norm);

  if(unit) vNORMALIZE3D(norm);

}

void project_point_to_plane( const double pt[3], 
			     const double pt0[3], const double pt1[3], const double pt2[3],
			     double proj[3] ) {

  double a, b, c, d;
  compute_plane(pt0, pt1, pt2, a, b, c, d);

  double num = - (a*pt[0] + b*pt[1] + c*pt[2] + d);
  double den = a*a + b*b + c*c;
  double param = num/den;

  proj[0] = pt[0] + a * param;
  proj[1] = pt[1] + b * param;
  proj[2] = pt[2] + c * param;

  //assert( iFuzzyComp(a*proj[0] + b*proj[1] + c*proj[2] + d, 0.) == 0 );

}

void closest_on_triangle(const double pt[3], 
			 const double t0[3], const double t1[3], const double t2[3], 
			 double close[3]) {

  double u[] = adDIFF3D(t1, t0),
         v[] = adDIFF3D(t2, t0),
         w[] = adDIFF3D(t0, pt),

         a = dDOT3D(u, u),
         b = dDOT3D(u, v),
         c = dDOT3D(v, v),
         d = dDOT3D(u, w),
         e = dDOT3D(v, w),

         det = fabs(a*c - b*b), 
         s = b*e - c*d, 
         t = b*d - a*e;

  int zone;

  if(s+t <= det) {
    if(s < 0.) {
      if(t < 0.)    zone = 4;
      else          zone = 3;
    }
    else if(t < 0.) zone = 5;
    else            zone = 0;
  }
  else {
    if(s < 0.)      zone = 2;
    else if(t < 0.) zone = 6;
    else            zone = 1;
  }

  switch( zone ) {

  case 0: { //closest point inside the triangle.
    double inv_det = 1./det;
    s *= inv_det;
    t *= inv_det;
    break;
  }

  case 1: { //closest point along s + t = 1;
    //min dist at (c + e - b - d) / (a - 2b + c)
    double num = c + e - b - d;
    if(num <= 0.) s = 0;
    else {
      double den = a - 2.*b + c; //always positive.
      s = num >= den ? 1. : num / den;
    }
    t = 1. - s;
    break;
  }

  case 2: { //closest point either along s + t = 1 or s = 0.
    double C0 = b + d, C1 = c + e;
    if(C1 > C0) { //closest point alogn s + t = 1. (like case 1).
      double num = C1 - C0;
      double den = a - 2.*b + c;  //always positive.
      s = num >= den ? 1. : num / den;
      t = 1. - s;
    }
    else { //closest point along s = 0. (like case 3)
      s = 0.;
      t = e >= 0. ? 0. : -e >= c ? 1. : -e / c;      
    }
    break;
  }

  case 3: { //closest point along s = 0. c must be positive (=v*v)
    //min dist at t' such that ct' + e = 0
    s = 0.;
    t = e >= 0. ? 0. : -e >= c ? 1. : -e / c;
    break;
  }

  case 4: { //closest point along s = 0 or t = 0
    if(d < 0.) { //closest point along t = 0.
      s = -d >= a ? 1. : -d / a;
      t = 0.;
    }
    else {
      s = 0.;
      t = e >= 0. ? 0. : -e >= c ? 1. : -e / c;
    }
    break;
  }    

  case 5: { //closest point along t = 0.
    s = d >= 0. ? 0. : -d >= a ? 1. : -d / a;
    t = 0.;
    break;
  }

  case 6: { //closest point along s + t = 1 or along t = 0.
    double C0 = a + d;
    double C1 = b + e;
    if(C1 < C0) { //closest point along s + t = 1
      double num = C0 - C1;
      double den = a - 2.*b + c;
      t = num >= den ? 1. : num / den;
      s = 1. - t;
    }
    else { //closest point along t = 0.
      s = d >= 0. ? 0. : -d >= a ? 1. : -d / a;
      t = 0.;
    }
    break;
  }

  default:
    assert(0);
    break;

  }

  close[0] = t0[0] + s * u[0] + t * v[0];
  close[1] = t0[1] + s * u[1] + t * v[1];
  close[2] = t0[2] + s * u[2] + t * v[2];

}

//Given three points in space, computes the plane equation 
//coefficients, a, b, c and d, such that a*x + b*y + c*z + d = 0.
void compute_plane(const double pt0[3], const double pt1[3], const double pt2[3],
		   double& a, double& b, double& c, double& d) {

  //The equation of a plane with normal n and going through point x0 is
  //n dot (x-x0) = 0;

  double norm[3];
  normal_to_plane(pt0, pt1, pt2, norm, false);

  a = norm[0];
  b = norm[1];
  c = norm[2];
  d = - a * pt0[0] - b * pt0[1] - c * pt0[2];

  //assert( iFuzzyComp(a*pt0[0] + b*pt0[1] + c*pt0[2] + d, 0.) == 0 );
  //assert( iFuzzyComp(a*pt1[0] + b*pt1[1] + c*pt1[2] + d, 0.) == 0 );
  //assert( iFuzzyComp(a*pt2[0] + b*pt2[1] + c*pt2[2] + d, 0.) == 0 );
  
}
