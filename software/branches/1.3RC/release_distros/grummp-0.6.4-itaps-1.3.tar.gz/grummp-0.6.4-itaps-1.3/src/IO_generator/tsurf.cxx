#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "GR_SurfMesh.h"
#include "GR_misc.h"
#include "GR_events.h"

#ifdef IRIX6
#include <getopt.h>
#endif

static void vUsage()
{
  vMessage(0, "Usage:  tsurf -i basefilename \n");
  exit(1);
}

int main(int iNArg, char *apcArgs[]) {
  extern char *optarg;
  char strBaseFileName[FILE_NAME_LEN];

  vGRUMMPInit("tsurf");

  bool qFile = false;
  int iPChar;
  while ((iPChar = getopt(iNArg, apcArgs, "i:")) != EOF) {
    switch (iPChar) {
    case 'i':
      (void) strncpy(strBaseFileName, optarg, FILE_NAME_LEN-1);
      {
	int iDum;
	for (iDum = 0; iDum < FILE_NAME_LEN && strBaseFileName[iDum];
	     iDum++);
	if (iDum == FILE_NAME_LEN) // No null; file name too long
	  vFatalError("File name too long", "command line");
      }
      qFile = true;
      break;
    default:
      vUsage();
    }
  }
  if (! qFile) vUsage();

  // Read and validate surface mesh
  SurfMesh CSMesh(strBaseFileName);

  vWriteFile_Surface(CSMesh, strBaseFileName, ".out");

  return (0);
}

