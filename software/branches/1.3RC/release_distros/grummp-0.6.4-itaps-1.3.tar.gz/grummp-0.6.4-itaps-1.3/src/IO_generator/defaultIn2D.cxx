#include "GR_config.h"
#include <stdio.h>
#include <stdlib.h>
#include "GR_misc.h"
#include "GR_VarArrayBase.h"
#define TOPO_DIM 2
#define SPACE_DIM 2
#include "GR_Mesh2D.h"
void vReadFile_Mesh2D(
                       const char * const strBaseFileName,
                       int& iNumVerts,
                       int& iNumFaces,
                       int& iNumCells,
                       int& iNumBdryFaces,
                       int& iNumIntBdryFaces,
                       bool& qFaceVert,
                       bool& qCellVert,
                       bool& qFaceCell,
                       bool& qCellFace,
                       bool& qCellRegion,
                       bool& qBFaceFace,
                       bool& qBFaceVert,
                       bool& qBFaceBC,
                       bool& qIntBFaceFace,
                       bool& qIntBFaceVert,
                       bool& qIntBFaceBC,
                       ECVertex& ECVerts,
                       int (*&a2iFaceVert)[TOPO_DIM],
                       int (*&a2iFaceCell)[2],
                       int (*&a2iCellVert)[TOPO_DIM+1],
                       int (*&a2iCellFace)[TOPO_DIM+1],
                       int *&aiCellRegion,
                       int *&aiBFaceFace,
                       int *&aiBFaceBC,
                       int (*&a2iBFaceVert)[TOPO_DIM],
                       int (*&a2iIntBFaceFace)[2],
                       int *&aiIntBFaceBC,
                       int (*&a2iIntBFaceVert)[TOPO_DIM]
                       )
{
  iNumVerts = 0;
  iNumFaces = 0;
  iNumCells = 0;
  iNumIntBdryFaces = 0;
  iNumBdryFaces = 0;
  qFaceVert = false;
  qCellVert = false;
  qFaceCell = false;
  qCellFace = false;
  qCellRegion = false;
  a2iFaceCell = reinterpret_cast<int(*)[2]> (NULL);
  a2iFaceVert = reinterpret_cast<int(*)[TOPO_DIM]> (NULL);
  a2iCellVert = reinterpret_cast<int(*)[TOPO_DIM+1]> (NULL);
  a2iCellFace = reinterpret_cast<int(*)[TOPO_DIM+1]> (NULL);
  aiCellRegion = reinterpret_cast<int *> (NULL);
  qBFaceVert = false;
  qBFaceFace = false;
  qBFaceBC = false;
  aiBFaceFace = reinterpret_cast<int *> (NULL);
  aiBFaceBC   = reinterpret_cast<int *> (NULL);
  a2iBFaceVert= reinterpret_cast<int(*)[TOPO_DIM]> (NULL);
  qIntBFaceFace = false;
  qIntBFaceVert = false;
  qIntBFaceBC   = false;
  a2iIntBFaceFace = reinterpret_cast<int(*)[2]> (NULL);
  aiIntBFaceBC    = reinterpret_cast<int *> (NULL);
  a2iIntBFaceVert = reinterpret_cast<int(*)[TOPO_DIM]> (NULL);
 
  int iVertOffset = 0, iFaceOffset = 0;
  int iCellOffset = 0, iBFaceOffset = 1;
  FILE *pFInFile = fopen("/dev/zero", "r");
  char strFileName[1024];
  sprintf(strFileName, "%s.mesh", strBaseFileName);

  /*newfile mesh*/
  printf("Opening input file %s\n", strFileName);
  if (pFInFile) fclose(pFInFile);
  pFInFile = fopen(strFileName, "r");
  if (NULL == pFInFile)
    vFatalError("Couldn't open input file for reading",
                "2d mesh input");

  /*ncells nfaces nbfaces nverts*/
  fscanf(pFInFile, "%d %d %d %d\n", &iNumCells, &iNumFaces, &iNumBdryFaces, &iNumVerts);

  if (iNumVerts == 0)
    vFatalError("Tried to read vertex data without specifying number of vertices",
                "2d mesh input");
  ECVerts.vSetup(iNumVerts);
  for (int iV = 0; iV < iNumVerts; iV++) {
    int iRealVert = iV;
    double dXX, dYY;
    /*verts: coords*/
    fscanf(pFInFile, "%lf%lf\n", &dXX, &dYY);
    {
      double adCoord[] = {dXX, dYY};
      (ECVerts.getEntry(iRealVert))->vSetCoords(SPACE_DIM, adCoord);
    }
  }


  if (iNumFaces == 0)
    vFatalError("Tried to read face data without specifying number of faces",
                "2d mesh input");
  /* Allocate both the face-vert and face-cell arrays if they haven't been.
     One or both may have to be deleted later. */
  if (! a2iFaceVert)
    a2iFaceVert = new int[iNumFaces][TOPO_DIM];
  if (! a2iFaceCell)
    a2iFaceCell = new int[iNumFaces][2];
  if (iNumVerts == 0)
    vWarning("Number of verts unknown while reading faces; sanity checking may be crippled.");
  if (iNumCells == 0)
    vWarning("Number of cells unknown while reading faces; sanity checking may be crippled.");
  for (int iF = 0; iF < iNumFaces; iF++) {
    int iRealFace = iF;
    int iCellA = iNumCells, iCellB = iNumCells;
    int iVertA = -1, iVertB = -1;
    /*faces: cells verts*/
    fscanf(pFInFile, "%d%d %d%d\n", &iCellA, &iCellB, &iVertA, &iVertB);
    /* Remove an offset from the vertex indices if needed. */
    iVertA -= iVertOffset;
    iVertB -= iVertOffset;
    if ( iVertA < 0 || iVertB < 0 ||
         ((iNumVerts > 0) && 
          (iVertA >= iNumVerts || 
           iVertB >= iNumVerts) ) ) 
      vFatalError("Vertex index out of range",
                "2d mesh input");
    (a2iFaceVert)[iRealFace][0] = iVertA;
    (a2iFaceVert)[iRealFace][1] = iVertB;

    /* Remove an offset from the vertex indices if needed. */
    if (iCellA >= 0) iCellA -= iCellOffset;
    if (iCellB >= 0) iCellB -= iCellOffset;
    /* Can not check cell index for out-of-range low, */
    /* because BC's have a negative index. */
    if ( iNumCells > 0 && 
         (iCellA >= iNumCells || 
          iCellB >= iNumCells) ) 
      vFatalError("Cell index out of range",
                "2d mesh input");
    (a2iFaceCell)[iRealFace][0] = iCellA;
    (a2iFaceCell)[iRealFace][1] = iCellB;
  }

  qFaceVert = true;
  qFaceCell = true;

  if (iNumBdryFaces == 0)
    vFatalError("Tried to read bdry face data without specifying number of bdry faces",
                "2d mesh input");
  /* Allocate the bface-face, bface-vert, and bface-BC arrays. */
  /* One or more may have to be deleted later. */
  if (! aiBFaceFace) 
    aiBFaceFace = new int[iNumBdryFaces];
  if (! aiBFaceBC) 
    aiBFaceBC   = new int[iNumBdryFaces];
  if (! a2iBFaceVert) 
    a2iBFaceVert= new int[iNumBdryFaces][TOPO_DIM];
  if (iNumVerts == 0)
    vWarning("# of verts unknown while reading bdry faces; sanity checking may be crippled.");
  if (iNumFaces == 0)
    vWarning("# of faces unknown while reading bdry faces; sanity checking may be crippled.");
  for (int iBF = 0; iBF < iNumBdryFaces; iBF++) {
    int iRealBFace = iBF;
    int iFace = iNumFaces, iBC = -100;
    int iVertA = -1, iVertB = -1;
    /*bdryfaces: face bc verts*/
    fscanf(pFInFile, "%d %d %d%d\n", &iFace, &iBC, &iVertA, &iVertB);
    /* Remove offset from the vertex indices */
    iVertA -= iVertOffset;
    iVertB -= iVertOffset;
    if ( iVertA < 0 || iVertB < 0 ||
         ((iNumVerts > 0) && 
          (iVertA >= iNumVerts || 
           iVertB >= iNumVerts) ) ) 
      vFatalError("Vertex index out of range",
                "2d mesh input");
    (a2iBFaceVert)[iRealBFace][0] = iVertA;
    (a2iBFaceVert)[iRealBFace][1] = iVertB;

    /* Remove offset from face index */ 
    iFace -= iFaceOffset;
    if ( iFace < 0 ||
         ((iNumFaces > 0) && 
          (iFace >= iNumFaces) ) ) 
      vFatalError("Face index out of range",
                "2d mesh input");
    (aiBFaceFace)[iRealBFace] = iFace;
    if ( iBC <= 0 )
      vFatalError("Boundary condition out of range",
                "2d mesh input");
    (aiBFaceBC)[iRealBFace] = iBC;
  }

  qBFaceVert = true;
  qBFaceFace = true;
  if (iNumCells == 0)
    vFatalError("Tried to read cell data without specifying number of cells",
                "2d mesh input");
  /* Allocate both the cell-vert and cell-face arrays if they haven't been.
     One or both may have to be deleted later. */
  if (! a2iCellVert) 
    a2iCellVert = new int[iNumCells][TOPO_DIM+1];
  if (! a2iCellFace) 
    a2iCellFace = new int[iNumCells][TOPO_DIM+1];
  if (! aiCellRegion) 
    aiCellRegion = new int[iNumCells];
  if (iNumVerts == 0)
    vWarning("Number of verts unknown while reading cells; sanity checking may be crippled.");
  if (iNumFaces == 0)
    vWarning("Number of faces unknown while reading cells; sanity checking may be crippled.");
  for (int iC = 0; iC < iNumCells; iC++) {
    int iRealCell = iC;
    int iFaceA = iNumFaces, iFaceB = iNumFaces;
    int iFaceC = iNumFaces;
    int iVertA = -1, iVertB = -1, iVertC = -1;
    int iReg = 0;
    /*cells: region*/
    fscanf(pFInFile, "%d\n", &iReg);
    /* Store the region that the cell belongs to. */
    if (iReg <= 0 || iReg >= 32)
      vFatalError("Cell tagged with invalid region.",
                "2d mesh input");
    (aiCellRegion)[iRealCell] = iReg;
    /* The following (possibly) extra work happens to get rid */
    /* of compiler complaints about unused variables. */
    /* Remove offset from the vertex indices */
    iVertA -= iVertOffset;
    iVertB -= iVertOffset;
    iVertC -= iVertOffset;
    /* The following (possibly) extra work happens to get rid */
    /* of compiler complaints about unused variables. */
    /* Remove offset from the face indices */
    iFaceA -= iFaceOffset;
    iFaceB -= iFaceOffset;
    iFaceC -= iFaceOffset;
  }

  qCellRegion = true;
  /* Get rid of the face-vert array if it isn't used. */
  if (!(qFaceVert) && a2iFaceVert) {
    delete [] a2iFaceVert;
    a2iFaceVert = reinterpret_cast<int(*)[TOPO_DIM]> (NULL);
  }

  /* Get rid of the face-cell array if it isn't used. */
  if (!(qFaceCell) && (a2iFaceCell)){
    delete [] a2iFaceCell;
    a2iFaceCell = reinterpret_cast<int(*)[2]> (NULL);
  }

  /* Get rid of the cell-vert array if it isn't used. */
  if (!(qCellVert) && (a2iCellVert)) {
    delete [] a2iCellVert;
    a2iCellVert = reinterpret_cast<int(*)[TOPO_DIM+1]> (NULL);
  }

  /* Get rid of the cell-face array if it isn't used. */
  if (!(qCellFace) && (a2iCellFace)) {
    delete [] a2iCellFace;
    a2iCellFace = reinterpret_cast<int(*)[TOPO_DIM+1]> (NULL);
  }

  /* Get rid of the cell-region array if it isn't used. */
  if (!(qCellRegion) && (aiCellRegion)) {
    delete [] aiCellRegion;
    aiCellRegion = reinterpret_cast<int *> (NULL);
  }

  /* Get rid of the bface-face array if it isn't used. */
  if (!(qBFaceFace) && (aiBFaceFace)){
    delete [] aiBFaceFace;
    aiBFaceFace = reinterpret_cast<int *> (NULL);
  }

  /* Get rid of the bface-BC array if it isn't used. */
  if (!(qBFaceBC) && (aiBFaceBC)){
    delete [] aiBFaceBC;
    aiBFaceBC = reinterpret_cast<int *> (NULL);
  }

  /* Get rid of the bface-vert array if it isn't used. */
  if (!(qBFaceVert) && (a2iBFaceVert)) {
    delete [] a2iBFaceVert;
    a2iBFaceVert = reinterpret_cast<int(*)[TOPO_DIM]> (NULL);
  }

  /* The following lines prevent compiler complaints. */
  iBFaceOffset++;
  iFaceOffset++;
  iCellOffset++;
  iVertOffset++;
  fclose(pFInFile);
}
