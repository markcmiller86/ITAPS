#ifndef GR_SmoothingManager_h
#define GR_SmoothingManager_h

#include <set>

#include "GR_Cell.h"
#include "GR_Observer.h"
#include "GR_Vertex.h"
#include "GR_VolMesh.h"

namespace GRUMMP {
  class SmoothingManager : public Observer {
    VolMesh* m_pVM;
    /// Default construction is a really, really bad idea.
    SmoothingManager();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SmoothingManager(SmoothingManager&);
    // Need to have a queue and ways to access it, but that can wait for
    // specializations --- OpenMP, MPI, etc --- and/or Observer giving
    // feedback about faces that should be looked at.
    //
    // The following set is the simple serial version.  For parallel
    // (either version) it isn't going to be adequate.
    std::set<Vert*> vertQueue;
  public:
    /// Set the swap criterion and mesh at construction time.
    SmoothingManager(VolMesh* pMeshToSmooth) :
      m_pVM(pMeshToSmooth)
      {
	m_pVM->addObserver(this,
			   Observable::cellCreated | Observable::vertDeleted |
			   Observable::vertMoved);
      }
    ~SmoothingManager();

    // Observer function overrides
    void receiveDeletedVerts(std::vector<Vert*>& deletedVerts);
    void receiveMovedVerts(std::vector<Vert*>& movedVerts);
    void receiveCreatedCells(std::vector<Cell*>& createdCells);

    int smoothAllVerts();
    int smoothAllQueuedVerts();
    int smoothVert(Vert* vert);
  };
};

#endif
