#ifndef GR_LENGTH2D_H
#define GR_LENGTH2D_H

#include "GR_config.h"
#include <utility>
#include <queue>
#include <set>
#include "CubitBox.hpp"
#include "CubitVector.hpp"

class BFace;
class Entity;
class Vert;
class GeometryEntity;
template <class X> class RTree;

class Length2D {
  
 public:

  enum LengthType { NONE, SPECIFIED, AUTOMATIC, TREE };

 private:

  //Cleans up queries to Mesh::vNeighborhood.
  struct Neighborhood {
    std::set<Vert*>  verts;
    std::set<Cell*>  cells;
    std::set<BFace*> bfaces;
  };

  //Couples a length to its boundary entity. 
  typedef std::pair<double,  Entity*> DistanceToEntity;
  
  //Entries in the length tree.
  class LengthTreeEntry {
  
    double m_x_loc, m_y_loc, m_length;
    
    LengthTreeEntry() : 
      m_x_loc(-LARGE_DBL), m_y_loc(-LARGE_DBL), m_length(-LARGE_DBL) 
      { assert(0); }
    LengthTreeEntry(const LengthTreeEntry&) : 
      m_x_loc(-LARGE_DBL), m_y_loc(-LARGE_DBL), m_length(-LARGE_DBL)  
      { assert(0); }
    LengthTreeEntry& operator=(const LengthTreeEntry&) 
      { assert(0); return (*this); }
    
   public:

    LengthTreeEntry(double x_loc, double y_loc, double length) 
      : m_x_loc(x_loc), m_y_loc(y_loc), m_length(length) {}
      
    double get_length() const { return m_length; }

    CubitBox bounding_box() const {

      CubitVector mini(m_x_loc - m_length, m_y_loc - m_length, 0.);
      CubitVector maxi(m_x_loc + m_length, m_y_loc + m_length, 0.);
      return CubitBox(mini, maxi);
      
    }

  };
  
  //What type of length scale are we using?
  LengthType m_length_type;

  //Refinement and grading constants.
  double m_refine, m_grade, m_min_length;
  
  //The tree to set length scales
  RTree<LengthTreeEntry*>* m_length_tree;

  //We also need a vector to contain the tree entries because
  //once in the tree, they are no longer accessible for deletion.
  std::vector<LengthTreeEntry*> m_tree_entries;

  //To queue vertices requiring a grading check.
  std::queue<Vert*> m_length_check_queue;
  
  //A neighborhood object declared here to save time on initilization.
  Neighborhood m_neigh;

  Length2D() :
    m_length_type(NONE), m_refine(-1.), m_grade(-1.), 
    m_length_tree(NULL), m_tree_entries(), m_length_check_queue() 
    { assert(0); }
  
  Length2D(const Length2D&) :
    m_length_type(NONE), m_refine(-1.), m_grade(-1.), 
    m_length_tree(NULL), m_tree_entries(), m_length_check_queue() 
    { assert(0); }

  Length2D& operator=(const Length2D&) 
    { assert(0); return *this; }				     
  
  void init_length_automatic(Vert* const vertex);

  void init_length_tree(Vert* const vertex);
  
  void set_length_scale_automatic(Vert* const vertex);
  
  void set_length_scale_tree(Vert* const vertex);
  
  void set_graded_length();

  void get_neighborhood(Vert* const vertex);

  double evaluate_length_from_tree(Vert* const vertex) const;

  double evaluate_length_from_neighbors(Vert* const vertex,
					const std::set<Vert*>& neigh_verts) const;

 public:

  //Public constructor.
  //length_type: the type of length scale used: SPECIFIED, AUTOMATIC, TREE. 
  //refine: the refinement constant,
  //grade: the grading constant
  Length2D(const LengthType& length_type, 
	   double refine, double grading, 
	   double min_length = -LARGE_DBL);

  //Destructor
  ~Length2D();
 
  //Initializes the length scale of vertices in mesh.
  //CAUTION: AUTOMATIC type can only have boundary verts in the mesh.
  void init_length(const Mesh2D* const mesh);

  //Computes the length scale for a given vertex 
  //(neighbor vertices' length scale must be properly initialized).
  void set_length_scale(Vert* const vertex);

  //Assigns a given length scale to a vertex.
  void set_length_scale(Vert* const vertex, 
			double length_scale);
  
  //Adds an entry to the length tree.
  void add_to_length_tree(double x_loc, double y_loc, double length);

};

#endif
