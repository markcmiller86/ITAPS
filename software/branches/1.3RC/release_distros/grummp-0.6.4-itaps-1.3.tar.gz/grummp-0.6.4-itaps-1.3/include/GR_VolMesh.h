#ifndef GR_VolMesh
#define GR_VolMesh 1

#include "GR_config.h"
#include "GR_BFace3D.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_List.h"
#include "GR_Mesh.h"
#include "GR_EntContainer.h"

class CubitBox;
class TetRefinerEdge;

///
class VolMesh : public Mesh {
private:
  ///
  bool qOKToChangeSurfaceEdges:1, qDoEdgeSwapping:1,
    qStrictPatchChecking:1; 
  ///
  // This angle is used to determine when swapping of surface edges is
  // allowed, and also to decide when a surface edge is actually on a
  // bdry curve or not (in the absence of other info and of surface
  // patch recovery code)
  double dMaxAngleForSurfSwap; // In degrees
  /// Three-dimensional topology
  EntContainer<TriFace>       ECTriF;      /// Faces  
  EntContainer<QuadFace>      ECQuadF;     /// Faces
  EntContainer<TriBFace>      ECTriBF;     /// BFaces
  EntContainer<QuadBFace>     ECQuadBF;    /// BFaces 
  EntContainer<TetCell>       ECTet;       /// Cells  
  EntContainer<PyrCell>       ECPyr;       /// Cells
  EntContainer<PrismCell>     ECPrism;     /// Cells
  EntContainer<HexCell>       ECHex;       /// Cells
  EntContainer<IntTriBFace>   ECIntTriBF;  /// Internal bdry faces
  EntContainer<IntQuadBFace>  ECIntQuadBF; /// Internal bdry faces
  Bdry3D          *pB3D;       /// Bdry info
  bool            qBdryFromMesh; 
private:
  /// Operator= is disabled, because I can't see a use case for it.
  VolMesh& operator=(const VolMesh&) {assert(0); return *this;}
public:
  /// 
  VolMesh(const VolMesh&);
  ///
  VolMesh(const char strBaseFileName[], const int iQualMeas = 2,
	  const double dMaxAngle = 0, Bdry3D * const pB3DIn = NULL);
  ///Added March 2007 by SG.
  VolMesh(const CubitBox& box, const int iQualMeas = 2,
	  const double dMaxAngle = 0);
  ///Modified March 2007 by SG.
  VolMesh(const EntContainer<Vert>& EC, const int iQualMeas = 2,
	  const double dMaxAngle = 0, const CubitBox* const = NULL);
  ///
  VolMesh(SurfMesh &SM, const int iQualMeas = 2,
	  const double dRes = 1, const double dGrade = 1,
	  const double dMaxAngle = 0);
  ///
  VolMesh(const int iQualMeas = 2);
  ///
  virtual ~VolMesh();
  ///
  void vReadFromFile(const char strBaseFileName[]);
 public:
  void vCreatePatchesFromBdryFaces(const int aiBCList[]);
public:
  void vMeshInBrick(const double dXMin, const double dXMax,
		    const double dYMin, const double dYMax,
		    const double dZMin, const double dZMax);
  ///
  void vConvertFromCellVert(const GR_index_t iNCells, const GR_index_t iNBdryFaces,
			    const GR_index_t a2iCellVert[][4],
			    const GR_index_t a2iBFaceVert[][3],
			    const int aiBFaceBC[], int*& aiBCList);
  ///
  void vConvertFromCellVert(const GR_index_t nTet, const GR_index_t nPyr,
			    const GR_index_t nPrism, const GR_index_t nHex,
			    const GR_index_t nBdryTri, const GR_index_t nBdryQuad,
			    const GR_index_t tetToVert[][4],
			    const GR_index_t pyrToVert[][5],
			    const GR_index_t prismToVert[][6],
			    const GR_index_t hexToVert[][8],
			    const GR_index_t bdryTriToVert[][3],
			    const GR_index_t bdryQuadToVert[][4]);
  ///
  eMeshType eType() const {return eVolMesh;}
  ///
  GR_index_t iNumFaces() const {return ECTriF.lastEntry() + ECQuadF.lastEntry();}
  
  GR_index_t iNumEdgesInUse() const {return 0;}
  ///
  GR_index_t iNumTriFaces() const {return ECTriF.lastEntry();}
  GR_index_t iNumTrisInUse() const {return ECTriF.size();}
  ///
  GR_index_t iNumQuadFaces() const {return ECQuadF.lastEntry();}
  GR_index_t iNumQuadsInUse() const {return ECQuadF.size();}
  ///
  GR_index_t iNumBdryFaces() const {return ECTriBF.lastEntry() + ECQuadBF.lastEntry();}
  ///
  GR_index_t iNumTriBdryFaces() const {return ECTriBF.lastEntry();}
  ///
  GR_index_t iNumQuadBdryFaces() const {return ECQuadBF.lastEntry();}
  ///
  GR_index_t iNumIntBdryFaces() const
    {return ECIntTriBF.lastEntry() + ECIntQuadBF.lastEntry();}
  ///
  GR_index_t iNumIntTriBdryFaces() const {return ECIntTriBF.lastEntry();}
  ///
  GR_index_t iNumIntQuadBdryFaces() const {return ECIntQuadBF.lastEntry();}
  ///
  GR_index_t iNumCells() const {return ECTet.lastEntry() + ECPyr.lastEntry() +
			   ECPrism.lastEntry() + ECHex.lastEntry();}
  ///
  GR_index_t iNumTetCells() const {return ECTet.lastEntry();}
  GR_index_t iNumTetsInUse() const {return ECTet.size();}
  ///
  GR_index_t iNumPyrCells() const {return ECPyr.lastEntry();}
  GR_index_t iNumPyrsInUse() const {return ECPyr.size();}
  ///
  GR_index_t iNumPrismCells() const {return ECPrism.lastEntry();}
  GR_index_t iNumPrismsInUse() const {return ECPrism.size();}
  ///
  GR_index_t iNumHexCells() const {return ECHex.lastEntry();}
  GR_index_t iNumHexesInUse() const {return ECHex.size();}
  ///
  Face*    pFFace(const GR_index_t i) const;
  ///
  BFace* pBFBFace(const GR_index_t i) const;
  ///
  BFace* pBFIntBFace(const GR_index_t i) const;
  ///
  Cell*    pCCell(const GR_index_t i) const;
  /// Index retrieval
  virtual GR_index_t iFaceIndex(const Face* const pF) const;
  ///
  virtual GR_index_t iBFaceIndex(const BFace* const pBF) const;
  ///
  virtual GR_index_t iCellIndex(const Cell* const pC) const;
  ///
  virtual bool qIsValidEnt(void* pvEnt) const;
  /// Add entries to connectivity tables
  Face*    pFNewFace(const int iNV = 3);
  ///
  BFace* pBFNewBFace(const int iNBV = 3, const bool qIsInternal = false);
  ///
  Cell*    pCNewCell(const int iNF = 4, const int iNV = 4);
  ///
  Cell*    pCNewCell(const Cell* const pC); // Returned cell has
						  // same type and
						  // data as old one. 
  /// New topology modifiers, a la ITAPS
  virtual Face* createFace(Vert * const /*apV*/[], const int /*iNVerts*/)
  {return pFInvalidFace;}
  virtual BFace* createBFace(Face * const pF,
			     BFace * const pBF = pBFInvalidBFace);
/*   virtual Cell* createCell(Face * const /\* apF *\/[], const int /\* iNFaces *\/, */
/* 			   const int /\* iReg = iDefaultRegion *\/) */
/*   {return pCInvalidCell;} */
/*   virtual Cell* createCell(Vert * const /\* apV *\/[], const int /\* iNVerts *\/, */
/* 			   const int /\* iReg = iDefaultRegion *\/) */
/*   {return pCInvalidCell;} */

  Vert* createVert(const double dX, const double dY, const double dZ);
  Vert* createVert(const double adCoords[]);
  Vert* createVert(const Vert* pVIn);
  Face* createFace(bool &qExistedAlready, Vert * const pVA, Vert * const pVB,
		   Vert * const pVC, Vert * const pVD = pVInvalidVert,
		   bool qForceDuplicate = false);
  TetCell* createTetCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 const int iRegion = iDefaultRegion);
  /// The following version should only be used if the correct vertex
  /// ordering isn't known in advance.
  TetCell* createTetCell(bool &qExistedAlready,
			 Vert * const pV, Face * const pF,
			 const int iRegion = iDefaultRegion);
  TetCell* createTetCell(bool &qExistedAlready,
			 Face * const pFA, Face * const pFB,
			 Face * const pFC, Face * const pFD,
			 const int iRegion = iDefaultRegion);

  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom.
  PyrCell* createPyrCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE,
			 const int iRegion = iDefaultRegion);
  // Faces are: tris in cyclic order, then quad.  Verts, if given, are
  // the verts in the same order as above.  See implementation for a
  // sketch.
  PyrCell* createPyrCell(bool &qExistedAlready,
			 Face* const pF014, Face* const pF124,
			 Face* const pF234, Face* const pF304,
			 Face* const pF0123,
			 const int iRegion = iDefaultRegion,
			 Vert * pVA = pVInvalidVert, 
			 Vert * pVB = pVInvalidVert,
			 Vert * pVC = pVInvalidVert, 
			 Vert * pVD = pVInvalidVert,
			 Vert * pVE = pVInvalidVert);
  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom, out for top.
  PrismCell* createPrismCell(bool &qExistedAlready,
			     Vert * const pVA, Vert * const pVB,
			     Vert * const pVC, Vert * const pVD,
			     Vert * const pVE, Vert * const pVF,
			     const int iRegion = iDefaultRegion);
  // Faces are: quads in cyclic order, bottom tri, top tri. Verts, if
  // given, are the verts in the same order as above. 
  PrismCell* createPrismCell(bool &qExistedAlready,
			     Face * const pFA, Face * const pFB,
			     Face * const pFC, Face * const pFD,
			     Face * const pFE,
			     const int iRegion = iDefaultRegion,
			     Vert * pVA = pVInvalidVert, 
			     Vert * pVB = pVInvalidVert,
			     Vert * pVC = pVInvalidVert, 
			     Vert * pVD = pVInvalidVert,
			     Vert * pVE = pVInvalidVert, 
			     Vert * pVF = pVInvalidVert);
  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom, out for top.
  HexCell* createHexCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE, Vert * const pVF,
			 Vert * const pVG, Vert * const pVH,
			 const int iRegion = iDefaultRegion);
  // Faces are: sides in cyclic order, bottom, top. Verts, if
  // given, are the verts in the same order as above. 
  HexCell* createHexCell(bool &qExistedAlready,
			 Face* const pFA, Face* const pFB, 
			 Face* const pFC, Face* const pFD, 
			 Face* const pFE, Face* const pFF, 
			 const int iRegion = iDefaultRegion,
			 Vert * pVA = pVInvalidVert, 
			 Vert * pVB = pVInvalidVert,
			 Vert * pVC = pVInvalidVert, 
			 Vert * pVD = pVInvalidVert,
			 Vert * pVE = pVInvalidVert, 
			 Vert * pVF = pVInvalidVert,
			 Vert * pVG = pVInvalidVert, 
			 Vert * pVH = pVInvalidVert);

/*   Cell* createCell(bool &qExistedAlready, */
/* 		   Face * const pFA, Face * const pFB, Face * const pFC, */
/* 		   Face * const pFD, Face * const pFE, */
/* 		   const int iRegion = iDefaultRegion); */
  
  bool deleteVert(Vert * const pV);
  bool deleteFace(Face * const pF);
  bool deleteBFace(BFace * const pBF);
  bool deleteCell(Cell * const pC);

  /// Clean up connectivity tables
  void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  ///
  void vPurgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL);
  ///
  void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL);
  ///
  void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  ///
  void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
	      std::map<Face*, Face*>*   face_map  = NULL,
	      std::map<Cell*, Cell*>*   cell_map  = NULL,
	      std::map<BFace*, BFace*>* bface_map = NULL);

/*   /// Ensure that the correct number of verts exist */
/*   void vSetupVerts(const int i, */
/* 		   const bool qExact = false) {ECVerts.vSetup(i, qExact);} */
  ///
  void vAssignInitialLengthScales(double dRes, double dAlpha);
protected:
  virtual void vReorderVerts_RCM(void);
  virtual void vReorderCells(void);
  virtual void vReorderFaces(void);
public:
  /// perimeter area:
  double dBoundarySize() const;
  /// interior volume:
  double dInteriorSize() const;
  ///
  bool qWatertight() const;
  ///
  bool qMeshOrientationOK(const bool qFix = true);
/// Conversion to/from simplicial form
  ///
  void vMakeSimplicial() {
    assert(iNumCells() == iNumTetCells());
    qSimplex = true;
  }

 public:

  /// Validity checking
  bool qValid() const;

  /// Insert points into the mesh
  int iInsertOnEdge(Vert* const pVNew, Vert* const pV0,
			    Vert* const pV1, Face* const pF,
			    const int qSwap);
  ///
  int iInsertOnBdryEdge(Vert* const pVNew, Vert* const pV0,
			Vert* const pV1, Face* const pF,
			const int qSwap);
  ///
  int iInsertOnFace(Vert* const pVNew, Face* const pF,
		    Cell* const pC, const int qSwap);
  ///
  int iInsertInInterior(Vert* const pVNew, Cell* const pC,
			const int qSwap);

  //Added by SG 2007/06/28. A substitute to WatsonInfo class.
  struct WatsonData {

    std::set<Cell*> cells_to_remove;
    std::set<Face*> faces_to_remove;
    std::set<Face*> hull_faces;
    std::set<BFace*> encroached_bfaces;
  
    WatsonData() 
      : cells_to_remove(), faces_to_remove(), 
	hull_faces(), encroached_bfaces() {}

    void clear_containers() {

      cells_to_remove.clear();
      faces_to_remove.clear();
      hull_faces.clear();
      encroached_bfaces.clear();

    }

  };

  //Computes Watson insertion data using adaptive predicates.
  void compute_watson_data(const Vert* const vertex,
			   const Cell* const seed_cell,
			   WatsonData& watson_data,
			   const bool test_bdry_for_encroachment = true,
			   const bool exit_on_encroached_bdry    = true) const;
  ///Addendum end.

  void vInsertWatsonInterior(Vert* const pVNew,
			     const std::set<Cell*>& spCToRemove,
			     const std::set<Face*>& spFToRemove,
			     const std::set<Face*>& spFHull,
			     std::vector<Cell*>* const new_cells = NULL);

  void vInsertWatsonBoundary(Vert* const pVNew,
			     std::set<Cell*>& spCToRemove,
			     std::set<Face*>& spFToRemove,
			     std::set<Face*>& spFHull,
			     const std::set<BFace*>& spBFEncroached,
			     std::vector<Cell*>* const new_cells = NULL,
			     std::vector<BFace*>* const new_bfaces = NULL);

  ///// *** The following calls were added by SG 08/2008. *** ///// 
  
  //The two public methods are designed to be called for the TetMeshRefiner
  //class. The functions accomplish a task similar to the previously existing
  //Watson insertion calls (and are somewhat their genetically modified clones).
  //They require more info as input, but this allows them to deal a wider range of 
  //domain's topology; dangling curves and surfaces are now supported for instance.
  //They also use Shewchuk's adaptive precision predicates.
 
 private:
 
  void strip_cavity( const std::set<Cell*>& cells_to_remove,
		     const std::set<Face*>& faces_to_remove,
		     const std::set<BFace*>* bfaces_to_remove = NULL );

  void reconnect_cavity( Vert* const new_vert,
			 const std::map<Face*, int>& faces_of_hull,
			 std::vector<Cell*>*  new_cells,
			 std::vector<BFace*>* new_bfaces,
			 std::set<TetRefinerEdge>* edges_with_bface = NULL,
			 bool insert_on_subsegment = false );

  void post_check_cavity( const std::vector<Cell*>& new_cells );

 public:

  void insert_watson_interior( Vert* const new_vert,
			       const std::set<Cell*>& cells_to_remove,
			       const std::set<Face*>& faces_to_remove,
			       const std::map<Face*, int>& faces_of_hull,
			       std::vector<Cell*>* const new_cells = NULL );


  void insert_watson_boundary( Vert* const new_vert,
			       std::set<Cell*>&  cells_to_remove,
			       std::set<Face*>&  faces_to_remove,
			       std::set<BFace*>& bfaces_to_remove,
			       std::map<Face*, int>& faces_of_hull,
			       std::set<TetRefinerEdge>& edges_with_bface,
			       bool insert_on_subsegment,
			       std::vector<Cell*>*  const new_cells  = NULL,
			       std::vector<BFace*>* const new_bfaces = NULL);

  ///// *** Addendum by SG 08/2008 stops here *** /////

  // Bdry encroachment check.
  virtual int iQueueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF) const;
  virtual int iQueueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF,
					   const double adLoc[],
					   const double dOffset = 0) const;
public:
  ///
  bool qInsertPoint(const double adPoint[], Cell* const pCGuess,
		    int *const piSwaps, const bool qSwap = true,
		    const bool qForce = false,
		    Vert* pVNew = pVInvalidVert);
  int iInsertPointWatson(WatsonInfo& WI);
  void vCleanupWatson(WatsonInfo& WI);
  // The worst shape quality measure allowed.
  virtual double dWorstAllowedCellShape() const
    {
      switch (eEncType) {
      case eBall:
	return sqrt(0.09375); // sqrt(3) sqrt(2) / 8
      case eLens:
	return sqrt(0.1875);  // sqrt(3) / 4
      case eNewLens:
	return sqrt(0.375);   // sqrt(3) sqrt(2) / 4
	// The mythical best-case scenario would be to use sqrt(3) / 2,
	// because then slivers would be impossible.
      default:
	assert(0);
	return 1;
      }
    }
  bool qInsertPointWatson(const double adPoint[], Cell* const pCSeed);
  bool qInsertPointWatson(Vert* const pVNew, Cell* const pCSeed);
  virtual bool qDeleteInteriorPointsInBall(const Cell *pCSeed,
					   const double adLoc[],
					   const double dRadius,
					   int& iNDeleted);
  virtual void vGetWatsonData(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const;
// Mesh optimization routines
/// Sliver fix
public:
  int iRepairBadCells(bool qAllowInsertion = false);
  ///
  int iBreakBadBdryCells(bool qAllowInsertion = false);
  ///
  int iSplitLargeAngle(Cell *pC,
                       const double dSplitAngle,
		       const double * const adDihed = 0,
		       const bool qOnlyInterior = false);
// // Mesh coarsening routines
/// // Mesh smoothing routines  
public:
  void vProtectSmallAngles();
  ///
  virtual bool qDoSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE) const;
  ///
  virtual int iSwap(const int iMaxPasses = 2,
		    const bool qAlreadyMarked = false);
  ///
  int iFaceSwap(Face*& pF);
  ///
  bool qSurfaceEdgeChangesAllowed() const {return qOKToChangeSurfaceEdges;}
  ///
  void vAllowSurfaceEdgeChanges(const double dMaxAngle = 0)
    {
      assert(dMaxAngle >= 0 && dMaxAngle < 180.);
      qOKToChangeSurfaceEdges = true;
      dMaxAngleForSurfSwap = dMaxAngle;
    }
  ///
  double dMaxAngleForSurfaceEdgeChanges() const {return dMaxAngleForSurfSwap;}
  ///
  void vDisallowSurfaceEdgeChanges() {qOKToChangeSurfaceEdges = false;}
  ///
  bool qStrictPatchCheckingUsed() const {return qStrictPatchChecking;}
  ///
  void vSetStrictPatchChecking() {qStrictPatchChecking = true;}
  ///
  void vSetLenientPatchChecking() {qStrictPatchChecking = false;}
  virtual GR_index_t iNumBdryPatches() {return pB3D->iNumPatches();}
  ///
  bool qBdryFacesOKToSwap(const TriBFaceBase * const pBF0,
			  const TriBFaceBase * const pBF1) const;
  ///
  bool qEdgeSwappingAllowed() const {return qDoEdgeSwapping;}
  ///
  void vAllowEdgeSwapping() {qDoEdgeSwapping = true;}
  ///
  void vDisallowEdgeSwapping() {qDoEdgeSwapping = false;}

  ///
  void vRefineToLengthScale(const bool qSameSize,
			    const int iMaxPasses = 40);
  ///
  virtual bool qRemoveVert(Vert * const pV, int& iNewSwaps)
  { return qRemoveVertByContraction(pV, iNewSwaps); }
  virtual bool qRemoveVertByContraction(Vert * const pV, int& iNewSwaps,
			   Vert * apVPreferred[] = NULL,
			   const int iNPref = 0);
  /// The following routine was an 1100 line monstrosity that was never
  //  used.  
  //  virtual bool qRemoveVertByRemeshing(Vert * const pV, int& iNewSwaps);
  ///
  virtual void vIdentifyVertexTypesGeometrically() const;
  virtual double dCoarsenConstant() const {return 0.36;}
  ///
  int iSmooth(const int iMaxPasses = 10);
  void vSetSmoothingGoal(const int iGoal)
    {
      SMsetSmoothFunction(pvSmoothData, iGoal+20);
    }
  ///
  int iSmoothVertex(Vert * const pV);
  ///
  bool qDelaunayize();
  ///
  int iReconfigure(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int iReconfTet23(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int iReconfTet32(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int iReconfTet22(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int iReconfTet44(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int iEdgeSwap3D(Face* const pF, Vert* pVNorth,
		  Vert* pVSouth, Vert* const pVOther,
		  const bool qAllowAnyValid = false,
		  const Vert* const pVWant0 = pVInvalidVert,
		  const Vert* const pVWant1 = pVInvalidVert);
  ///
  int iBdryEdgeSwap3D(Face* const pF, Vert* pVNorth,
                      Vert* pVSouth, Vert* const pVOther);
private:
  double dQualFunc(Vert* const pV0, Vert* const pV1, 
		   Vert* const pV2, Vert* const pV3) const;
 public:
  // Boundary recovery routines
  void vRecoverConstrainedSurface(SurfMesh& SM, const int iNumOrigVerts,
				  const int iNumBBoxVerts = 8);
  void vMarkCleanNeighbors(Cell* pC);
  int iRecoverFace(const int iVerts[3],
		   int * const piPointsInserted = NULL,
		   const bool qAllowEdgeSwap = true,
		   const int iRecurDepth = 0);
  int iRecoverEdge(const Vert* const pV0,
		   const Vert* const pV1,
		   const bool qInsertionOK = false);
  int iRecoverEdge(const Vert* const pV0,
		   const Vert* const pV1,
		   SurfMesh& SM,
		   const bool qInsertionOK = false);
  void vSplitEdge(const Vert* const pV0,
		  const Vert* const pV1,
		  SurfMesh& SM);
  // Find the cell incident on pV0 that covers the ray towards pV1 (may be
  // a multiple choice question if pV0 and pV1 are adjacent, or if there
  // is a face containing one but not the other and coplanar with both. 
  Cell* pCBeginPipe(const Vert* const pV0, const Vert* const pV1) const;
  int iReamPipe(const Vert* const pVInit,
		const Vert* const pVEnd,
		bool& qHitEdge, Face* apFSkipped[], int& iNSkip);
  void vDeleteExternal(const SurfMesh* pSM, const int iNumOrigVerts,
		       const int iNumBBoxVerts = 8);
  void vIdentifyBadEdgesAndFaces(const Vert* const pV0,
				 const Vert* const pV1,
				 const Vert* const pV2,
				 std::set<BadEdge>& sBEBadEdges,
				 std::set<Face*>& spFBadFaces);
public:
  /// Mesh quality assessment
  void vClassifyTets() const;
  ///
  friend class VolQual;

public:
  /// Iterator functions
  EntContainer<TriFace>::iterator triFace_begin() const
  { return ECTriF.begin(); }
  EntContainer<TriFace>::iterator triFace_end() const
  { return ECTriF.end(); }

  EntContainer<Vert>::iterator vert_begin() const
  { return ECVerts.begin(); }
  EntContainer<Vert>::iterator vert_end() const
  { return ECVerts.end(); }

};

// Check to see whether a VolMesh correctly conforms to a surface mesh.
bool qIsBdryConstrained(VolMesh* pVM, SurfMesh* pSM, 
			std::set<ConstrainEdge>& sCESubSegs,
			std::set<ConstrainEdge>& sCEInFacets,
			std::set<ConstrainFace>& sCFSubFacets);


void vReadUGridBinary(const char * const fileName, VolMesh * const pVM);
void vReadVGridBinary(const char * const fileName, VolMesh * const pVM);
void vReadVTK_ASCII(const char * const fileName, VolMesh * const pVM);

void vWriteVTK_ASCII(VolMesh& OutMesh,
		     const char strBaseFileName[]);

/** Unlikely ever to be called by user code. */
void vWriteFile_VolMesh(VolMesh & Mesh,
		        const char strBaseFileName[],
		        const char strExtraFileSuffix[] = "");

void vWriteFile_PWM(VolMesh & Mesh,
		    const char strBaseFileName[],
		    const char strExtraFileSuffix[] = "");

///
void vReadFile_VolMesh(const char * const strBaseFileName,
		       GR_index_t& iNumVerts,
		       GR_index_t& iNumFaces,
		       GR_index_t& iNumCells,
		       GR_index_t& iNumBdryFaces,
                       GR_index_t& iNumIntBdryFaces,
		       bool& qFaceVert,
		       bool& qCellVert,
		       bool& qFaceCell,
		       bool& qCellFace,
		       bool& qCellRegion,
		       bool& qBFaceFace,
		       bool& qBFaceVert,
		       bool& qBFaceBC,
		       bool& qIntBFaceFace,
		       bool& qIntBFaceVert,
                       bool& qIntBFaceBC,
		       EntContainer<Vert>& EC,
		       GR_index_t (*&a2iFaceVert)[3],
		       GR_sindex_t (*&a2iFaceCell)[2],
		       GR_index_t (*&a2iCellVert)[4],
		       GR_index_t (*&a2iCellFace)[4],
		       int *&aiCellRegion,
		       GR_index_t *&aiBFaceFace,
		       int *&aiBFaceBC,
		       GR_index_t (*&a2iBFaceVert)[3],
                       GR_index_t (*&a2iIntBFaceFace)[2],
                       int *&aiIntBFaceBC,
                       GR_index_t (*&a2iIntBFaceVert)[3]);

void repairBadCells(VolMesh* pVM);
void vNewSurfaceRecovery(VolMesh* const pVM, SurfMesh* const pSM);
#endif
