#ifndef GR_EntContainer
#define GR_EntContainer

#include "GR_assert.h"
#include "GR_misc.h"
#include <algorithm>
#include <iostream>
#include <vector>

///
template<typename T>
class EntContainer {
  ///
  enum {m_maxLists = 20, m_firstListSize = 2048};
  /// An array of allocatable arrays of objects of type T.
  T *m_data[m_maxLists];

  /// The allocated size of each list.
  GR_index_t m_listSize[m_maxLists];

  /// The cumulative size of all lists so far, including the current one.
  GR_index_t m_cumSize[m_maxLists];

  /// The number of lists actually in use.
  GR_index_t m_nLists;

  /// The number of entries in use.  This should always be m_lastEntry -
  /// the size of m_empties.
  GR_index_t m_liveEntries;

  /// The index of the last entry in use.
  GR_index_t m_lastEntry;

  /// The overall number of T's allocated; identical to m_cumSize[m_nLists].
  GR_index_t m_totalSize;

  /// A collection of empty spots in the database that are available for reuse.
  std::vector<T*> m_empties;

  // Private member functions

  /// Copy constructor is -really- dubious, because of pointers to data
  /// that's being copied.
  EntContainer(const EntContainer& EC) {assert(0);}
public:
  //////////////////////////////////////////////////////////////////////
  // Iterator functionality
  //////////////////////////////////////////////////////////////////////

  class iterator {
  private:
    const EntContainer<T>* m_pEC;
    GR_index_t m_whichList;
    T *m_data, *m_listEnd, *m_listBegin;
  public:
    iterator(const EntContainer<T>& EC, const bool begin = true) :
      m_pEC(&EC), m_whichList(0), m_data(NULL), m_listEnd(NULL)
    {
      GR_index_t index;
      if (begin) {
	m_whichList = 0;
	index = 0;
      }
      else {
	// Initializing at the end.
	m_whichList = m_pEC->m_nLists - 1;
	index = m_pEC->m_lastEntry
	  - (m_whichList == 0 ? 0 : m_pEC->m_cumSize[m_whichList - 1]);
      }
      m_data = m_pEC->m_data[m_whichList] + index;
      m_listBegin = m_pEC->m_data[m_whichList];
      
      if (m_data->qDeleted() && begin) {
	increment();
      }

      GR_index_t lastIndex = m_pEC->m_listSize[m_whichList];
      if (m_whichList == m_pEC->m_nLists - 1) {
	// This can happen at the beginning, too.
	lastIndex = m_pEC->m_lastEntry
	  - (m_whichList == 0 ? 0 : m_pEC->m_cumSize[m_whichList - 1]);
      }
      
      m_listEnd = m_pEC->m_data[m_whichList] + lastIndex;
    }
    ~iterator() {}
    // The compiler-default operator= and copy constructor are fine.
    T& operator*() const {return (*m_data);}
    T* operator->() const {return m_data;}
    iterator operator++(int) {
      // Post-increment
      // Return the value that hasn't yet been incremented
      iterator __tmp = *this;
      increment();
      return __tmp;
    }
    iterator& operator++() {
      // Pre-increment
      // Increment, then return.
      increment();
      return *this;
    }
    bool operator==(const iterator& iter) const {return m_data == iter.m_data;}
    bool operator!=(const iterator& iter) const {return m_data != iter.m_data;}
    friend std::ostream&
    operator<<(std::ostream& os, const iterator& iter) {
      os << "EntContainer: " << iter.m_pEC << " Data: " << iter.m_data;
      return (os);
    }
  private:
    void increment() {
      // Warning!  This function cheerfully increments past the end, so
      // you'd better be careful to check the end condition every time...
      // Carefully, so that wraparound will work properly...
//       if (pEC->size() == 0) return;
      do {
	m_data++;
	if (m_data == m_listEnd) {
	  if (m_whichList == m_pEC->m_nLists - 1) {
	    return;
	  }
	  else {
	    // Switch over to the next list
	    m_whichList++;
	    m_listBegin = m_data = m_pEC->m_data[m_whichList];
	    GR_index_t lastIndex = m_pEC->m_listSize[m_whichList];
	    if (m_whichList == m_pEC->m_nLists - 1) {
	      // This can happen at the beginning, too.
	      lastIndex = m_pEC->m_lastEntry
		- (m_whichList == 0 ? 0 : m_pEC->m_cumSize[m_whichList - 1]);
	    }
	    
	    m_listEnd = m_pEC->m_data[m_whichList] + lastIndex;
	  }
	}
      } while (m_data->qDeleted());
    }
  };

  //////////////////////////////////////////////////////////////////////
  // Done with iterator stuff.
  //////////////////////////////////////////////////////////////////////

  ///
  ~EntContainer()
  {
    for (GR_index_t i = 0; i < m_nLists; i ++) {
      assert(m_data[i] != NULL);
      delete [] m_data[i];
    }
    m_nLists = 0;
  }
  
  ///
  EntContainer() :
    m_nLists(1), m_liveEntries(0), m_lastEntry(0), m_totalSize(m_firstListSize)
  {
    for (GR_index_t ii = 0; ii < m_maxLists; ii++) {
      m_listSize[ii] = 0;
      m_cumSize[ii] = 0;
      m_data[ii] = NULL;
    }
    m_listSize[0] = m_totalSize;
    m_cumSize[0] = m_totalSize;
    m_data[0] = new T[m_totalSize];
    m_empties.clear();
  }

  ///
  iterator begin() const
  {
    return iterator(*this, true);
  }
  iterator end() const
  {
    return iterator(*this, false);
  }

  ///
  void clear()
  {
    // Free up all data, then set up an empty container with
    // m_firstListSize entries allocated. 
    m_liveEntries = 0;
    m_lastEntry = 0;
    m_nLists = 1;
    m_totalSize = m_firstListSize;
    for (GR_index_t ii = 0; ii < m_maxLists; ii++) {
      m_listSize[ii] = 0;
      m_cumSize[ii] = 0;
      if (m_data[ii]) delete [] m_data[ii];
      m_data[ii] = NULL;
    }
    m_listSize[0] = m_totalSize;
    m_cumSize[0] = m_totalSize;
    m_data[0] = new T[m_totalSize];
    m_empties.clear();
  }
  /// \brief The number of entries actually in use.
  ///
  /// Note that there may be holes in the data structure, so the last
  /// entry in use may be at a higher index than this.  So use the
  /// iterators to loop over containers.
  GR_index_t size() const {return m_liveEntries;}

  /// \brief The index of the last entry ever used.
  ///
  /// This is a backward compatibility function so that it's possible to
  /// write the old-style integer loops over entities.  This function
  /// will go away, so its use in new code is a very bad idea.
  GR_index_t lastEntry() const {return m_lastEntry;}

  /// \brief The number of entries currently allocated.
  GR_index_t capacity() const {return m_cumSize[m_nLists-1];}

  /// \brief The most entities one could store in the data structures as
  /// currently compiled.
  ///
  /// Note that actually using all of this hypothetical total is likely
  /// to blow the virtual memory on your machine.  Caveat programmer.
  GR_index_t max_size() const {return GR_index_t(m_firstListSize) << (m_maxLists);}

  /// This function is deprecated; new code shouldn't use it.
  void vSetup(GR_index_t newSize)
  {
    resize(newSize);
    m_lastEntry = newSize;
    m_empties.clear();
    m_liveEntries = 0;
    for (GR_index_t i = 0; i < newSize; i++) {
      T* pT = getEntry(i);
      if (pT->qDeleted()) m_empties.push_back(pT);
      else m_liveEntries++;
    }
    assert(m_liveEntries <= capacity());
    assert(m_liveEntries + m_empties.size() == m_lastEntry);
  }
  /// \brief Force a change in size for the container.
  ///
  /// Unlike the std::vector reserve function, this one also reduces
  /// size when appropriate.
  void resize(GR_index_t newSize)
  {
    // FIX ME This assertion should be re-enabled once full use of the
    // empties list is up and going. CFOG Nov 2010.
/*     assert(newSize >= m_lastEntry); // Shouldn't try to nuke data that's */
/*                                     // in use! */
    if (newSize == m_totalSize) return;
    else if (newSize > m_totalSize) {
      GR_index_t iMax = m_cumSize[m_nLists-1];
      while (newSize > m_cumSize[m_nLists-1] && m_nLists < m_maxLists) {
	m_data[m_nLists] = new T[iMax];
	m_listSize[m_nLists] = iMax;
	iMax = m_totalSize = m_cumSize[m_nLists] = 2*iMax;
	m_nLists ++;
      }
      assert(iMax >= newSize && iMax < 2*newSize);
//       // Create one last list
//       GR_index_t iLastSize = (qExact ? newSize - iMax : iMax);
//       m_data[m_nLists] = new T[iLastSize];
//       m_listSize[m_nLists] = iLastSize;
//       m_totalSize += iLastSize;
//       iMax *= 2; // This way, in case you ever need to go on, the next
//       // block will still be bigger.
//       m_nLists++;
      if (iMax < newSize) vFatalError("Out of space",
				       "resizing variable-sized array");
    }
    else {
      assert(newSize <= m_totalSize);
      while (m_totalSize - m_listSize[m_nLists - 1] >= newSize
	     && m_nLists > 1) {
	// m_nLists >= 2 or we wouldn't be here.
	assert(m_totalSize - m_listSize[m_nLists - 1] ==
		m_cumSize[m_nLists - 2]);
	m_nLists --;
	delete [] m_data[m_nLists];
	m_totalSize -= m_listSize[m_nLists];
	m_listSize[m_nLists] = m_cumSize[m_nLists] = 0;
	m_data[m_nLists] = NULL;
      }
    }
  }

  void purge()
  {
    if (m_lastEntry > 0) {
      T* pTFor = pTFirst();
      T* pTBack = pTLast();

      GR_index_t newSize = 0;
      while (pTFor != pTBack) {
	while (pTFor != pTBack && !pTFor->qDeleted()) {
	  pTFor = pTNext(pTFor);
	  newSize++;
	}

	while (pTBack != pTFor && pTBack->qDeleted()) {
	  pTBack = pTPrev(pTBack);
	}

	if (pTFor != pTBack) {
	  assert(pTFor->qDeleted());
	  newSize++;
	  (*pTFor) = (*pTBack);
	  pTBack->vMarkDeleted();
	  pTFor = pTNext(pTFor);
	}
	else if (!pTFor->qDeleted()) {
	  newSize++;
	}
      }
      resize(newSize);
      m_liveEntries = m_lastEntry = newSize;
      m_empties.clear();
      assert(m_liveEntries < capacity());
    }
  }

  /// \brief Returns a pointer to an unused entity in the container.
  ///
  /// This entity may be at the end, or we may be re-using one that's
  /// been deleted.
  T* getNewEntry()
  {
    if (m_empties.empty()) {
      if (m_lastEntry == m_totalSize) resize(m_totalSize+1);
      m_lastEntry++;
      m_liveEntries++;
      return (getEntry(m_lastEntry-1));
    }
    else {
      T* retVal = m_empties.back();
      m_empties.pop_back();
      m_liveEntries++;
      assert(m_empties.size() + m_liveEntries == m_lastEntry);
      return retVal;
    }
  }

  void deleteEntry(T* dead)
  {
    assert(qValid(dead) && dead->qDeleted());
    m_empties.push_back(dead);
    m_liveEntries--;
    assert(m_empties.size() + m_liveEntries == m_lastEntry);
  }

  /// \brief Finds the pointer for a particular index
  T* getEntry(const GR_index_t i) const
  {
    assert(qValid(i));
    GR_index_t iList = 0, iSum = 0;
    while (i >= (iSum += m_listSize[iList]) && iList < m_nLists) iList++;
    assert(iList < m_nLists);
    iSum -= m_listSize[iList];
    assert(iSum <= i && iSum + m_listSize[iList] > i);
    return(m_data[iList] + (i - iSum));
  }

  /// \brief Finds the entity for a particular index
  T& operator[](const GR_index_t i) const
  {
    return (*getEntry(i));
  }

  /// \brief Turn a pointer in the container into an index.
  ///
  /// Really useful in two places:  output and debugging.
  GR_index_t getIndex(const T* const pT) const
  {
    // This function's runtime depends on the number of lists, so it's
    // technically log(n), with a very small constant.
    GR_index_t iList;
    for (iList = 0;
	 (! ((const_cast<T*>(pT) >= m_data[iList]) &&
	     (const_cast<T*>(pT) < m_data[iList] + m_listSize[iList])) &&
	  iList < m_nLists) ;
	 iList++)
      {}
    if (iList == m_nLists) return (~0); // Not a valid pointer.
    assert(iList < m_nLists);
    assert(const_cast<T*>(pT) >= m_data[iList]);
    assert(const_cast<T*>(pT) < m_data[iList] + m_listSize[iList]);
    GR_index_t prevSize = (iList == 0) ? 0 : m_cumSize[iList-1];
    assert((reinterpret_cast<size_t>(pT) 
	    - reinterpret_cast<size_t>(m_data[iList])) % sizeof(T) == 0);
    return prevSize + (const_cast<T*>(pT) - m_data[iList]);
  }
  
  /// \brief op= is not safe for containers of mesh entities because of
  /// the pointer interconnections between entities.
 private:
  EntContainer& operator=(const EntContainer& EC)
  {
    assert(EC.m_liveEntries >= 0);
    assert(EC.m_totalSize > 0);
    // Do nothing if the source says EC=EC.
    if (this != &EC) {
      // Clean up the existing data.
      int i;
      for (i = 0; i < m_nLists; i++)
	delete [] m_data[i];
    
      m_liveEntries = EC.m_liveEntries;
      m_lastEntry = EC.m_lastEntry;
      m_nLists = EC.m_nLists;
      m_totalSize = EC.m_totalSize;
      int iSum = 0;
      for (int ii = 0; ii < m_nLists; ii++) {
	assert(EC.m_listSize[ii] >= 0);
	assert(EC.m_data[ii] != NULL);
	m_listSize[ii] = EC.m_listSize[ii];
	m_cumSize[ii] = EC.m_cumSize[ii];
	m_data[ii] = new T[m_listSize[ii]];
	iSum += m_listSize[ii];
	for (i = 0; i < m_listSize[ii]; i++)
	  m_data[ii][i] = EC.m_data[ii][i];
      }
      //    assert(iSum == iMax);
    }
    return (*this);
  }
 public:
  ///
  T* pTFirst() const
  {
    if (m_liveEntries == 0) return (0);
    else         return(&(m_data[0][0]));
  }
  ///
  T* pTLast() const
  {
    if (m_lastEntry == 0) return (0);
    else                  return(getEntry(m_lastEntry-1));
  }
  ///
  T* pTNext(T* const pTCurr) const
  {
    assert(qValid(const_cast<const T*>(pTCurr)));
    GR_index_t iList = 0, iSum = 0;
    while (! ((pTCurr >= m_data[iList]) &&
	      (pTCurr <  m_data[iList] + m_listSize[iList])) &&
	   iList < m_nLists) iSum += m_listSize[iList++];
    assert(iList < m_nLists);
    assert(pTCurr >= m_data[iList]);
    assert(pTCurr <  m_data[iList] + m_listSize[iList]);
    assert((reinterpret_cast<unsigned long>(pTCurr) 
	    - reinterpret_cast<unsigned long>(m_data[iList]))
	   % sizeof(T) == 0);
    // This seems to be wrong.  iSum -= m_listSize[iList];
    if (pTCurr == pTLast()
	||
	(pTCurr - m_data[iList] == ptrdiff_t(m_listSize[iList] - 1)
	 && iList == m_nLists - 1) )
      return 0;
    else if (pTCurr - m_data[iList] == ptrdiff_t(m_listSize[iList] - 1))
      return m_data[iList+1];
    else
      return pTCurr+1;
  }

  ///
  T* pTPrev(T* const pTCurr) const
  {
    assert(qValid(const_cast<const T*>(pTCurr)));
    GR_index_t iList = 0, iSum = 0;
    while (! ((pTCurr >= m_data[iList]) &&
	      (pTCurr <  m_data[iList] + m_listSize[iList])) &&
	   iList < m_nLists) iSum += m_listSize[iList++];
    assert(iList < m_nLists);
    assert(pTCurr >= m_data[iList]);
    assert(pTCurr <  m_data[iList] + m_listSize[iList]);
    assert((reinterpret_cast<unsigned long>(pTCurr)
	    - reinterpret_cast<unsigned long>(m_data[iList]))
	   % sizeof(T) == 0);
    // This seems to be wrong.  iSum -= m_listSize[iList];
    if (iList == 0 && pTCurr - m_data[iList] == 0)
      return 0;
    else if (pTCurr - m_data[iList] == 0)
      return m_data[iList-1] + m_listSize[iList-1] - 1;
    else
      return pTCurr-1;
  }
  ///
  bool qValid(const T* const pT) const
  {
    GR_index_t ind = getIndex(pT);
    return qValid(ind);
  }
private:
  ///
  bool qValid(const GR_index_t i) const
  {
    return (i < m_lastEntry);
  }
};


#endif
