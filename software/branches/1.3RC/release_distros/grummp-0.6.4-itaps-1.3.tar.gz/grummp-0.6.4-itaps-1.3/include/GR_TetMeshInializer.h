#ifndef GR_TETMESHINITIALIZER_H
#define GR_TETMESHINITIALIZER_H 1

#include "GR_config.h"

class CubitBox;
class CubitVector;
class TetCell;
class VolMesh;
template <class X> class KDDTree;

//This class is used to initialize and insert vertices into 
//a tetrahedral mesh instantiated somewhere else. 

class TetMeshInitializer {

  //A pointer to the volume mesh we wish to initialize.
  VolMesh* m_mesh;

  //A spatial indexing tree to accelerate seed cell computation.
  KDDTree<TetCell*>* m_cell_tree;

 public:

  TetMeshInitializer(const CubitBox& box);

  ~TetMeshInitializer();

  //Inserts a vertex in m_mesh at coord.
  void insert_in_mesh(const CubitVector& coord);

  //Returns the pointer to the volume mesh.
  VolMesh* get_mesh() const { return m_mesh; }

  //Purges deleted entities from the mesh and rebuilds the tree.
  void purge_mesh();

 private:

  //These are made private.
  TetMeshInitializer();
  TetMeshInitializer(const TetMeshInitializer&);
  TetMeshInitializer& operator=(const TetMeshInitializer&);

  //Adds a cell to the cell tree.
  void add_cell_to_tree(TetCell* const tet_cell);

  //Removes a cell from the cell tree.
  void remove_cell_from_tree(TetCell* const tet_cell);

  //Find a TetCell having the point coord in its interior.
  TetCell* find_seed_cell(const CubitVector& coord) const;
  TetCell* find_seed_cell(const Vertex* const vertex) const;

};

#endif
