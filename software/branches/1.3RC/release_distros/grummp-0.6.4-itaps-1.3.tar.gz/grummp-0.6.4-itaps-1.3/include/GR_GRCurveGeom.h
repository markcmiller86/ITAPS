#ifndef GR_GRCURVEGEOM_H
#define GR_GRCURVEGEOM_H 1

#include "GR_config.h"
#include "GR_misc.h"
#include "CubitDefines.h"
#include "CubitVector.hpp"
#include "DLIList.hpp"
#include <set>
#include <algorithm>
#include <iterator>
#include <functional>

class CubitBox;

class GRCurveGeom {

 public:

  enum curve_type { UNKNOWN, LINE, ARC, CUBIC, BEZIER, INTERP };

 protected:

  int n_pts;           //Number of points defining the curve
  CubitVector* points; //Points locations
  int n_dim;           //Curve geometric dimension

  //Functor used to compare parameters on a curve. Two params
  //that are almost equal (to a small tolerance) are considered equal.
  struct param_compare {
    bool operator()(const double& d1, const double& d2) const {
      if(iFuzzyComp(d1, d2) == -1) { return true; }
      else { return false; }      
    }
  };
   
 private:

  //Disabling copy construction and operator=.
  GRCurveGeom(const GRCurveGeom&) 
    { assert(0); n_pts = 0; points = NULL; }  
  GRCurveGeom& operator=(const GRCurveGeom&) 
    { assert(0); n_pts = 0; points = NULL; return *this; }
 
 public:
  
  GRCurveGeom() : n_pts(0), points(NULL), n_dim(0) {}
  virtual ~GRCurveGeom() { if(points) delete [] points; }

  //Returns the curve number of topological dimensions.
  int topo_dim() const { return 1; }

  //Returns the curve number of geometric dimensions.
  virtual int geom_dim() const { return n_dim; }

  //Returns the type of geometric entity.
  virtual curve_type get_curve_type() const = 0;

  //Returns the min and max param for this curve;
  virtual double min_param() const = 0;
  virtual double max_param() const = 0;

  //Calculates the bounding box for this curve.
  virtual CubitBox bounding_box() const = 0;

  //Returns parameter at a given coordinate.
  virtual double param_at_coord(const CubitVector& coord) const = 0;

  //Gets the parameter located arc length "length" from "param_start" 
  virtual double param_at_arc_length(const double param_start, const double length) const = 0;

  //Returns coordinate at a given parameter.
  virtual void coord_at_param(const double param, CubitVector& coord) const = 0;

  //Computes coordinate at a given Euclidean distance from start or end
  //Returns corresponding parameter.
  virtual double coord_at_dist(const double dist, const bool start, 
			       CubitVector& coord) const = 0;

  //Computes the coordinate at middle Euclidean distance from two coords or params on the curve. 
  //Returns corresponding parameter.
  virtual double coord_at_mid_dist(const double param1, const double param2, 
				   CubitVector& middle) const = 0;
  virtual double coord_at_mid_dist(const CubitVector& coord1, const CubitVector& coord2,
				   CubitVector& middle) const = 0;  

  //Given a coordinate near the curve, computes neareast coord on the curve.
  //Optionally, can specify a param range between which to restrict the search.
  virtual void closest_coord_on_curve(const CubitVector& coord,
				      CubitVector& closest,
				      const double param1 = -1.,
				      const double param2 = -1.) const = 0;

  //Given a coordinate near the curve, computes neareast parameter on the curve.
  //Optionally, can specify a param range between which to restrict the search.
  virtual double closest_param_on_curve(const CubitVector& coord,
					const double param1 = -1.,
					const double param2 = -1.) const = 0;

  //Returns true if coord is directly on the curve.
  virtual bool coord_on_curve(const CubitVector& coord,
			      double* const param_X = NULL,
			      double* const param_Y = NULL,
			      double* const param_Z = NULL) const = 0; 

  //Returns the first and second derivative with respect to the parameter
  virtual void first_deriv(const double param, CubitVector& FD) const = 0;
  virtual void first_deriv(const CubitVector& coord, CubitVector& FD) const = 0;

  virtual void second_deriv(const double param, CubitVector& SD) const = 0;
  virtual void second_deriv(const CubitVector& coord, CubitVector& SD) const = 0;

  //Curvature at param and at coord (located on the curve).
  virtual double curvature(const double param) const = 0;
  virtual double curvature(const CubitVector& coord) const = 0;

  //Curvature vector
  virtual void curvature(const double param, CubitVector& curvature) const = 0;
  virtual void curvature(const CubitVector& coord, CubitVector& curvature) const = 0;

  //Unit normal points to the left side of the curve.
  //ONLY WORKS IN 2D!!!
  virtual void unit_normal(const double param, CubitVector& normal) const = 0;
  virtual void unit_normal(const CubitVector& coord, CubitVector& normal) const = 0;
  
  //Tangent vector has the same "sense" as the curve.
  virtual void unit_tangent(const double param, CubitVector& tangent) const = 0;
  virtual void unit_tangent(const CubitVector& coord, CubitVector& tangent) const = 0;

  //Total length, length between dParam1 and dParam2, between adCoord1 and adCoord2.
  virtual double arc_length() const = 0;
  virtual double arc_length(const double param1, const double param2) const = 0;
  virtual double arc_length(const CubitVector& coord1, const CubitVector& coord2) const = 0;

  //Rerturns the center point based on arc length. Either based on total
  //arc length or between params or points.
  virtual void center_point(CubitVector& mid_point) const = 0;
  virtual void center_point(const double param1, const double param2,
			    CubitVector& mid_point) const = 0;
  virtual void center_point(const CubitVector& coord1, const CubitVector& coord2,
			    CubitVector& mid_point) const = 0;

  //Rerturns the point located in the middle of the parameterization range.
  void mid_point(CubitVector& mp) const;
  void mid_point(const double param1, const double param2,
		 CubitVector& mp) const;
  void mid_point(const CubitVector& coord1, const CubitVector& coord2,
		 CubitVector& mp) const;

  //Total variation of the tangent angle
  virtual double TVT() const = 0;
  virtual double TVT(const double param1, const double param2) const = 0;  
  virtual double TVT(const CubitVector& coord1, const CubitVector& coord2) const = 0;

  //Finds the param at which the TVT is half of what it is between param1 and param2.
  virtual double mid_TVT(const double param1, const double param2) const = 0;
  virtual double mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const = 0;

  //Returns the local interior extrema for the curve.
  virtual void interior_extrema(DLIList<CubitVector*>& point_list, 
				CubitSense return_sense = CUBIT_FORWARD) const = 0;

  //Gets points[pt] in some form or another.
  virtual double X(const int pt) const = 0;
  virtual double Y(const int pt) const = 0;
  virtual double Z(const int pt) const = 0;
  virtual void get_coord(const int pt, CubitVector& coord) const = 0;
  virtual const CubitVector& get_coord(const int pt) const = 0;

  //Sets Points[iPt] to new location
  virtual void set_X(const int pt, const double X) = 0;
  virtual void set_Y(const int pt, const double Y) = 0;
  virtual void set_Z(const int pt, const double Z) = 0;
  virtual void set_coord(const int pt, const CubitVector& new_coord) = 0; 

  virtual bool qValid() const = 0;  
  virtual bool closed_param() { return false; }

};

class GRLine : public GRCurveGeom {
 
 public:

  GRLine();
  GRLine(const CubitVector& coord_start, const CubitVector& coord_end);
  GRLine(const GRLine& L);
  GRLine& operator=(const GRLine& L);
  virtual ~GRLine();

  GRCurveGeom::curve_type get_curve_type() const { return GRCurveGeom::LINE; }

  double min_param() const { return 0.; }
  double max_param() const { return 1.; }
 
  CubitBox bounding_box() const;
  
  double param_at_coord(const CubitVector& coord) const;
  
  double param_at_arc_length(const double param_start, const double length) const;

  void coord_at_param(const double param, CubitVector& coord) const;
   
  double coord_at_dist(const double dist, const bool start, 
		       CubitVector& coord) const;

  double coord_at_mid_dist(const double param1, const double param2, 
			   CubitVector& middle) const;
  double coord_at_mid_dist(const CubitVector& coord1, const CubitVector& coord2,
			   CubitVector& middle) const;  

  void closest_coord_on_curve(const CubitVector& coord,
			      CubitVector& closest,
			      const double param1 = -1., 
			      const double param2 = -1.) const;
  
  double closest_param_on_curve(const CubitVector& coord,
				const double param1 = -1.,
				const double param2 = -1.) const;

  bool coord_on_curve(const CubitVector& coord,
		      double* const param_X = NULL,
		      double* const param_Y = NULL,
		      double* const param_Z = NULL) const; 
  
  void first_deriv(const double param, CubitVector& FD) const;
  void first_deriv(const CubitVector& coord, CubitVector& FD) const;

  void second_deriv(const double param, CubitVector& SD) const;
  void second_deriv(const CubitVector& coord, CubitVector& SD) const;

  double curvature(const double param) const;
  double curvature(const CubitVector& coord) const;
  void curvature(const double param, CubitVector& curvature) const;
  void curvature(const CubitVector& coord, CubitVector& curvature) const;
  
  void unit_normal(const double param, CubitVector& normal) const;
  void unit_normal(const CubitVector& coord, CubitVector& normal) const;
    
  void unit_tangent(const double param, CubitVector& tangent) const;
  void unit_tangent(const CubitVector& coord, CubitVector& tangent) const;
  
  double arc_length() const;
  double arc_length(const double param1, const double param2) const;
  double arc_length(const CubitVector& coord1, const CubitVector& coord2) const;

  void center_point(CubitVector& mid_point) const;
  void center_point(const double param1, const double param2,
		    CubitVector& mid_point) const;
  void center_point(const CubitVector& coord1, const CubitVector& coord2,
		    CubitVector& mid_point) const;
  
  double TVT() const;
  double TVT(const double param1, const double param2) const;  
  double TVT(const CubitVector& coord1, const CubitVector& coord2) const;

  double mid_TVT(const double param1, const double param2) const;
  double mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const;
  
  void interior_extrema(DLIList<CubitVector*>& point_list, 
			CubitSense return_sense = CUBIT_FORWARD) const;
  
  double X(const int pt) const;
  double Y(const int pt) const;
  double Z(const int pt) const;
  void get_coord(const int pt, CubitVector& coord) const;
  const CubitVector& get_coord(const int pt) const;

  //Sets Points[iPt] to new location
  void set_X(const int pt, const double X);
  void set_Y(const int pt, const double Y);
  void set_Z(const int pt, const double Z);
  void set_coord(const int pt, const CubitVector& new_coord); 

  bool qValid() const;  

};

class GRArc : public GRCurveGeom {
  
  double radius;
  double angle_beg;
  double angle_span;

 public:

  GRArc();
  GRArc(const CubitVector& center,
	const CubitVector& beg_pt,
	const CubitVector& end_pt);
  GRArc(const CubitVector& beg_pt,
	const CubitVector& end_pt,
	const double rad,
	const bool short_arc = true);
  GRArc(const GRArc& arc);
  GRArc& operator=(const GRArc& arc);
  ~GRArc();
  
  int topo_dim() const { return 1; } 
  int geom_dim() const { return n_dim; }
    
  GRCurveGeom::curve_type get_curve_type() const { return GRCurveGeom::ARC; }

  //Returns the min and max param for this curve 
  double min_param() const { return 0.; } 
  double max_param() const { return 1.; }

  CubitBox bounding_box() const;

  double param_at_coord(const CubitVector& coord) const;
  double param_at_arc_length(const double param_start, const double length) const;
  void coord_at_param(const double param, CubitVector& coord) const;

  double coord_at_dist(const double dist, const bool start, 
		       CubitVector& coord) const;

  double coord_at_mid_dist(const double param1, const double param2, 
			   CubitVector& middle) const;
  double coord_at_mid_dist(const CubitVector& coord1, const CubitVector& coord2,
			   CubitVector& middle) const;
  
  void closest_coord_on_curve(const CubitVector& coord,
			      CubitVector& closest,
			      const double param1 = -1., 
			      const double param2 = -1.) const;
  double closest_param_on_curve(const CubitVector& coord,
				const double param1 = -1., 
				const double param2 = -1.) const;
  
  bool coord_on_curve(const CubitVector& coord, 
		      double* const param_X = NULL,
		      double* const param_Y = NULL,
		      double* const param_Z = NULL) const; 
  
  void first_deriv(const double param, CubitVector& FD) const;
  void first_deriv(const CubitVector& coord, CubitVector& FD) const;
  
  void second_deriv(const double param, CubitVector& SD) const;
  void second_deriv(const CubitVector& coord, CubitVector& SD) const;
  
  double curvature(const double param) const;
  double curvature(const CubitVector& coord) const;
  
  void curvature(const double, CubitVector&) const 
  { assert(0); }
  void curvature(const CubitVector&, CubitVector&) const 
  { assert(0); }
  
  void unit_normal(const double param, CubitVector& normal) const;
  void unit_normal(const CubitVector& coord, CubitVector& normal) const;
  
  void unit_tangent(const double param, CubitVector& tangent) const;
  void unit_tangent(const CubitVector& coord, CubitVector& tangent) const;
  
  double arc_length() const;
  double arc_length(const double param1, const double param2) const;
  double arc_length(const CubitVector& coord1, const CubitVector& coord2) const;
  
  void center_point(CubitVector& mid_point) const;
  void center_point(const double param1, const double param2, 
		    CubitVector& mid_point) const;
  void center_point(const CubitVector& coord1, const CubitVector& coord2, 
		    CubitVector& mid_point) const;
  
  double TVT() const;
  double TVT(const double param1, const double param2) const;
  double TVT(const CubitVector& coord1, const CubitVector& coord2) const;
  
  double mid_TVT(const double param1, const double param2) const;
  double mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const;

  void interior_extrema(DLIList<CubitVector*>& point_list,  
			CubitSense return_sense = CUBIT_FORWARD) const;
  
  double X(const int pt) const;
  double Y(const int pt) const;
  double Z(const int pt) const;
  void get_coord(const int pt, CubitVector& coord) const;
  const CubitVector& get_coord(const int pt) const;
  
  void set_X(const int pt, const double X);
  void set_Y(const int pt, const double Y);
  void set_Z(const int pt, const double Z);
  void set_coord(const int pt, const CubitVector& new_coord);
  
  void get_center(CubitVector& center) { center = points[0]; }
  double get_radius() { return radius; }
  
  bool qValid() const;
  
};

class GRCubic : public GRCurveGeom {

  //Class for cubic parametric curves. The curves are defined as:
  //x(t) = x_coeff[0] + t * x_coeff[1] + t^2 * x_coeff[2] + t^3 * x_coeff[3]
  //Likewise for y(t).
  //This class only works for 2D.

  double* x_coeff;
  double* y_coeff;

  std::set<double, param_compare> crit_pts;
  
 public:

  GRCubic();
  GRCubic(const double x_coefficient[4],
	  const double y_coefficient[4]);
  GRCubic(const GRCubic& cubic);
  GRCubic& operator=(const GRCubic& cubic);
  ~GRCubic();

  void set_coeffs(const double xcoeff[4], const double ycoeff[4]);
  void set_xcoeffs(const double xcoeff[4]);
  void set_ycoeffs(const double ycoeff[4]);

  int topo_dim() const { return 1; }
  int geom_dim() const { return n_dim; }
    
  GRCurveGeom::curve_type get_curve_type() const { return GRCurveGeom::CUBIC; }

  //Returns the min and max param for this curve
  double min_param() const { return 0.; }
  double max_param() const { return 1.; }

  CubitBox bounding_box() const;

  double param_at_coord(const CubitVector& coord) const;
  double param_at_arc_length(const double param_start, const double length) const;

  void coord_at_param(const double param, CubitVector& coord) const;

  double coord_at_dist(const double dist, const bool start,
		       CubitVector& coord) const;

  double coord_at_mid_dist(const double param1, const double param2,
			   CubitVector& middle) const;
  double coord_at_mid_dist(const CubitVector& coord1, const CubitVector& coord2,
			   CubitVector& middle) const;
  
  void closest_coord_on_curve(const CubitVector& coord,
			      CubitVector& closest,
			      const double param1 = -1.,
			      const double param2 = -1.) const;
  double closest_param_on_curve(const CubitVector& coord,
				const double param1 = -1.,
				const double param2 = -1.) const;
  
  bool coord_on_curve(const CubitVector& coord,
		      double* const param_X = NULL,
		      double* const param_Y = NULL,
		      double* const param_Z = NULL) const;
  
  void first_deriv(const double param, CubitVector& FD) const;
  void first_deriv(const CubitVector& coord, CubitVector& FD) const;
  
  void second_deriv(const double param, CubitVector& SD) const;
  void second_deriv(const CubitVector& coord, CubitVector& SD) const;
  
  double curvature(const double param) const;
  double curvature(const CubitVector& coord) const;
  
  void curvature(const double, CubitVector&) const
  { assert(0); }
  void curvature(const CubitVector&, CubitVector&) const
  { assert(0); }
  
  void unit_normal(const double param, CubitVector& normal) const;
  void unit_normal(const CubitVector& coord, CubitVector& normal) const;
  
  void unit_tangent(const double param, CubitVector& tangent) const;
  void unit_tangent(const CubitVector& coord, CubitVector& tangent) const;
  
  double arc_length() const;
  double arc_length(const double param1, const double param2) const;
  double arc_length(const CubitVector& coord1, const CubitVector& coord2) const;
  
  void center_point(CubitVector& mid_point) const;
  void center_point(const double param1, const double param2,
		    CubitVector& mid_point) const;
  void center_point(const CubitVector& coord1, const CubitVector& coord2,
		    CubitVector& mid_point) const;
  
  double TVT() const;
  double TVT(const double param1, const double param2) const;
  double TVT(const CubitVector& coord1, const CubitVector& coord2) const;
  
  double mid_TVT(const double param1, const double param2) const;
  double mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const;

  void interior_extrema(DLIList<CubitVector*>& point_list,
			CubitSense return_sense = CUBIT_FORWARD) const;
  
  double X(const int pt) const;
  double Y(const int pt) const;
  double Z(const int pt) const;
  void get_coord(const int pt, CubitVector& coord) const;
  const CubitVector& get_coord(const int pt) const;
  
  void set_X(const int pt, const double X);
  void set_Y(const int pt, const double Y);
  void set_Z(const int pt, const double Z);
  void set_coord(const int pt, const CubitVector& new_coord);
  
  void get_center(CubitVector& center) {
    center.set(LARGE_DBL, LARGE_DBL, LARGE_DBL);
    vFatalError("This function is only defined for arcs.",
		"GRCubic::get_center(CubitVector&)\n");
  }
  double get_radius() {
    vFatalError("This function is only defined for arcs.",
		"GRCubic::get_radius()\n");
  }

  void get_crit_pts(std::set<double>& critical_points,
		    const double add_param = 0.) const {

    std::transform(crit_pts.begin(), crit_pts.end(), 
		   std::inserter(critical_points, critical_points.begin()),
		   std::bind2nd(std::plus<double>(), add_param));

  }
  
  const double* get_x_coeff() const { return x_coeff; }
  const double* get_y_coeff() const { return y_coeff; }

  bool qValid() const;

 private:

  void compute_crit_pts();
  void insert_crit_pts(const int num_roots, const double root1, const double root2);

  bool newton(const CubitVector& coord, const double lower_param,
	      const double upper_param, double& return_param, double tolerance = 1.e-12) const;
  bool bisection(const CubitVector& coord, const double lower_param,
		 const double upper_param, double& return_param, double tolerance = 1.e-12) const;

};

class GRSpline : public GRCurveGeom {

  //This is the base class for all flavors of cubic parametric spline

 public:

  GRSpline();
  virtual ~GRSpline();

 protected:

  int num_cubics;
  GRCubic** cubics;
  bool closed;

  GRSpline(const GRSpline&) : GRCurveGeom() 
    { assert(0); }
  GRSpline& operator=(const GRSpline&)
    { assert(0); return *this; }
 
 public:
  
  int topo_dim() const { return 1; }
  int geom_dim() const { return n_dim; }
    
  virtual GRCurveGeom::curve_type get_curve_type() const = 0;

  //Returns the min and max param for this curve
  virtual double min_param() const = 0;
  virtual double max_param() const = 0;

  CubitBox bounding_box() const;

  double param_at_coord(const CubitVector& coord) const;
  double param_at_arc_length(const double param_start, const double length) const;

  void coord_at_param(const double param, CubitVector& coord) const;

  double coord_at_dist(const double dist, const bool start,
		       CubitVector& coord) const;

  double coord_at_mid_dist(const double param1, const double param2,
			   CubitVector& middle) const;
  double coord_at_mid_dist(const CubitVector& coord1, const CubitVector& coord2,
			   CubitVector& middle) const;
  
  void closest_coord_on_curve(const CubitVector& coord,
			      CubitVector& closest,
			      const double param1 = -1.,
			      const double param2 = -1.) const;
  double closest_param_on_curve(const CubitVector& coord,
				const double param1 = -1.,
				const double param2 = -1.) const;
  
  bool coord_on_curve(const CubitVector& coord,
		      double* const param_X = NULL,
		      double* const param_Y = NULL,
		      double* const param_Z = NULL) const;
  
  void first_deriv(const double param, CubitVector& FD) const;
  void first_deriv(const CubitVector& coord, CubitVector& FD) const;
  
  void second_deriv(const double param, CubitVector& SD) const;
  void second_deriv(const CubitVector& coord, CubitVector& SD) const;
  
  double curvature(const double param) const;
  double curvature(const CubitVector& coord) const;
  
  void curvature(const double, CubitVector&) const
  { assert(0); }
  void curvature(const CubitVector&, CubitVector&) const
  { assert(0); }
  
  void unit_normal(const double param, CubitVector& normal) const;
  void unit_normal(const CubitVector& coord, CubitVector& normal) const;
  
  void unit_tangent(const double param, CubitVector& tangent) const;
  void unit_tangent(const CubitVector& coord, CubitVector& tangent) const;
  
  double arc_length() const;
  double arc_length(const double param1, const double param2) const;
  double arc_length(const CubitVector& coord1, const CubitVector& coord2) const;
  
  void center_point(CubitVector& mid_point) const;
  void center_point(const double param1, const double param2,
		    CubitVector& mid_point) const;
  void center_point(const CubitVector& coord1, const CubitVector& coord2,
		    CubitVector& mid_point) const;
  
  double TVT() const;
  double TVT(const double param1, const double param2) const;
  double TVT(const CubitVector& coord1, const CubitVector& coord2) const;
  
  double mid_TVT(const double param1, const double param2) const;
  double mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const;

  void interior_extrema(DLIList<CubitVector*>& point_list,
			CubitSense return_sense = CUBIT_FORWARD) const;
  
  virtual double X(const int pt) const = 0;
  virtual double Y(const int pt) const = 0;
  virtual double Z(const int pt) const = 0;
  virtual void get_coord(const int pt, CubitVector& coord) const = 0;
  virtual const CubitVector& get_coord(const int pt) const = 0;
  
  virtual void set_X(const int pt, const double X) = 0;
  virtual void set_Y(const int pt, const double Y) = 0;
  virtual void set_Z(const int pt, const double Z) = 0;
  virtual void set_coord(const int pt, const CubitVector& new_coord) = 0;
  
  void get_center(CubitVector& center) {
    center.set(LARGE_DBL, LARGE_DBL, LARGE_DBL);
    vFatalError("This function is only defined for arcs.",
		"GRSpline::get_center(CubitVector&)\n");
  }
  double get_radius() {
    vFatalError("This function is only defined for arcs.",
		"GRSpline::get_radius()\n");
  }
  
  virtual bool qValid() const = 0;

  virtual bool closed_param() {
    return ( iFuzzyComp(points[0].x(), points[n_pts-1].x()) == 0 &&
	     iFuzzyComp(points[0].y(), points[n_pts-1].y()) == 0 );
  }

};

class GRBezier : public GRSpline {

 public:

  GRBezier();
  GRBezier(const CubitVector input_points[4]);
  GRBezier(const GRBezier& B);
  GRBezier& operator=(const GRBezier& B);
  ~GRBezier();

  GRCurveGeom::curve_type get_curve_type() const { return GRCurveGeom::BEZIER; }
  double min_param() const { return 0.; }
  double max_param() const { return 1.; }

  double X(const int pt) const;
  double Y(const int pt) const;
  double Z(const int pt) const;
  void get_coord(const int pt, CubitVector& coord) const;
  const CubitVector& get_coord(const int pt) const;
  
  void set_X(const int pt, const double X);
  void set_Y(const int pt, const double Y);
  void set_Z(const int pt, const double Z);
  void set_coord(const int pt, const CubitVector& new_coord);

  bool qValid() const;
  
 private:
  
  void compute_coeffs(double x_coeff[4], double y_coeff[4]);
  void set_coeffs();

};

class GRInterp : public GRSpline {

 public:

  GRInterp();
  GRInterp(const CubitVector input_pts[],
	   const int num_pts,
	   const bool is_closed = false);
  GRInterp(const GRInterp& interp);
  GRInterp& operator=(const GRInterp& interp);
  ~GRInterp();

  GRCurveGeom::curve_type get_curve_type() const { return GRCurveGeom::INTERP; }
  double min_param() const { return 0.; }
  double max_param() const { return static_cast<int>(num_cubics); }

  double X(const int pt) const;
  double Y(const int pt) const;
  double Z(const int pt) const;
  void get_coord(const int pt, CubitVector& coord) const;
  const CubitVector& get_coord(const int pt) const;
  
  void set_X(const int pt, const double X);
  void set_Y(const int pt, const double Y);
  void set_Z(const int pt, const double Z);
  void set_coord(const int pt, const CubitVector& new_coord);

  bool qValid() const;
  
 private:

  void compute_coeffs_natural(double (*x_coeff)[4],
			      double (*y_coeff)[4]);
  void compute_coeffs_closed (double (*x_coeff)[4],
			      double (*y_coeff)[4]);

};


///INLINE DEFINITIONS FOR BASE CLASS///

inline void GRCurveGeom::mid_point(CubitVector& mp) const {
  assert(qValid()); coord_at_param(0.5 * (max_param() + min_param()), mp);
}

inline void GRCurveGeom::mid_point(const double param1, 
				   const double param2, 
				   CubitVector& mp) const {
  assert(qValid());
  assert(iFuzzyComp(param1, min_param()) >= 0 &&
	 iFuzzyComp(param1, max_param()) <= 0);
  assert(iFuzzyComp(param2, min_param()) >= 0 &&
	 iFuzzyComp(param2, max_param()) <= 0);
  coord_at_param(0.5 * (param1 + param2), mp);
}

inline void GRCurveGeom::mid_point(const CubitVector& coord1, 
				   const CubitVector& coord2, 
				   CubitVector& mp) const {
  assert(qValid());
  assert(coord_on_curve(coord1));
  assert(coord_on_curve(coord2));
  coord_at_param(0.5 * (param_at_coord(coord1) + param_at_coord(coord2)), mp);
}

///INLINE DEFINITIONS FOR GRLine CLASS///

inline void GRLine::second_deriv(const double,
				 CubitVector& SD) const 
{ SD.set(0., 0., 0.); }
inline void GRLine::second_deriv(const CubitVector&,
				 CubitVector& SD) const 
{ SD.set(0., 0., 0.); }

inline double GRLine::curvature(const double) const { return 0.; }
inline double GRLine::curvature(const CubitVector&) const { return 0.; }

inline void GRLine::curvature(const double,
			       CubitVector& curv_vector) const 
{ curv_vector.set(0., 0., 0.); }

inline void GRLine::curvature(const CubitVector&,
			       CubitVector& curv_vector) const 
{ curv_vector.set(0., 0., 0.); }

inline double GRLine::TVT() const { return 0.; }
inline double GRLine::TVT(const double param1,
			  const double param2) const { 
  assert(qValid());
  assert(iFuzzyComp(param1, min_param()) >= 0 &&
	 iFuzzyComp(param1, max_param()) <= 0);
  assert(iFuzzyComp(param2, min_param()) >= 0 &&
	 iFuzzyComp(param2, max_param()) <= 0);
  return 0.; 
}
inline double GRLine::TVT(const CubitVector& coord1,
			  const CubitVector& coord2) const { 
  assert(qValid());
  assert(coord_on_curve(coord1));
  assert(coord_on_curve(coord2));
  return 0.; 
}

inline double GRLine::mid_TVT(const double param1, const double param2) const {
  assert(qValid());
  assert(iFuzzyComp(param1, min_param()) >= 0 &&
	 iFuzzyComp(param1, max_param()) <= 0);
  assert(iFuzzyComp(param2, min_param()) >= 0 &&
	 iFuzzyComp(param2, max_param()) <= 0);
  return (0.5 * (param1 + param2));
}

inline double GRLine::mid_TVT(const CubitVector& coord1, const CubitVector& coord2) const {
  return ( 0.5 * ( param_at_coord(coord1) + param_at_coord(coord2) ) );
}

//No interior extremum for a line.
inline void GRLine::interior_extrema(DLIList<CubitVector*>& point_list, 
				     CubitSense return_sense) const 
{ return_sense = CUBIT_UNKNOWN; point_list.clean_out(); }

inline double GRLine::X(const int pt) const { 
  assert(pt >= 0 && pt < n_pts);
  return points[pt].x();
}
inline double GRLine::Y(const int pt) const {
  assert(pt >= 0 && pt < n_pts);
  return points[pt].y();
}
inline double GRLine::Z(const int pt) const {
  assert(pt >= 0 && pt < n_pts);
  return points[pt].z();
}
inline void GRLine::get_coord(const int pt,
			      CubitVector& coord) const {
  assert(pt >= 0 && pt < n_pts);
  coord.set(points[pt].x(), points[pt].y(), points[pt].z());  
}
inline const CubitVector& GRLine::get_coord(const int pt) const {
  assert(pt >= 0 && pt < n_pts);
  return points[pt];
}

inline void GRLine::set_X(const int pt,
			  const double new_x) {
  assert(n_pts == 2);
  assert(points != NULL);
  assert(pt >= 0 && pt < n_pts);
  
  points[pt].x(new_x);

  if(iFuzzyComp(points[0].x(), points[1].x()) == 0 && 
     iFuzzyComp(points[0].y(), points[1].y()) == 0 &&
     iFuzzyComp(points[0].z(), points[1].z()) == 0) {
    vFatalError("Both points of a line are at the same coordinate.",
		"GRLine::set_x(const int, const double)");    
  }
}
inline void GRLine::set_Y(const int pt,
			  const double new_y) {
  assert(n_pts == 2);
  assert(points != NULL);
  assert(pt >= 0 && pt < n_pts);
  
  points[pt].y(new_y);

  if(iFuzzyComp(points[0].x(), points[1].x()) == 0 && 
     iFuzzyComp(points[0].y(), points[1].y()) == 0 &&
     iFuzzyComp(points[0].z(), points[1].z()) == 0) {
    vFatalError("Both points of a line are at the same coordinate.",
		"GRLine::set_y(const int, const double)");    
  }
}
inline void GRLine::set_Z(const int pt,
			  const double new_z) {
  assert(n_pts == 2);
  assert(points != NULL);
  assert(pt >= 0 && pt < n_pts);

  if(n_dim == 2) { assert(0); }
  points[pt].z(new_z);

  if(iFuzzyComp(points[0].x(), points[1].x()) == 0 && 
     iFuzzyComp(points[0].y(), points[1].y()) == 0 &&
     iFuzzyComp(points[0].z(), points[1].z()) == 0) {
    vFatalError("Both points of a line are at the same coordinate.",
		"GRLine::vSetY(const int, const double)");    
  }
}
inline void GRLine::set_coord(const int pt,
			      const CubitVector& new_coord) {
  assert(n_pts == 2);
  assert(points != NULL);
  assert(pt >= 0 && pt < n_pts);
  if(n_dim == 2) { assert(iFuzzyComp(new_coord.z(), 0.) == 0); }

  points[pt].set(new_coord.x(), new_coord.y(), new_coord.z());

  if(iFuzzyComp(points[0].x(), points[1].x()) == 0 && 
     iFuzzyComp(points[0].y(), points[1].y()) == 0 &&
     iFuzzyComp(points[0].z(), points[1].z()) == 0) {
    vFatalError("Both points of a line are at the same coordinate.",
		"GRLine::set_coord(const int, const CubitVector&).");    
  }
}



#endif 
