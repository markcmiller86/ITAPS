#include "GR_config.h"
#include <sys/types.h>
#include <sys/time.h>

#if defined(SUNOS4) && !defined(__cplusplus)
    extern int gettimeofday(struct timeval *, struct timezone *);
#endif

#if (defined(solaris) || defined(SUNOS4)) && defined(__cplusplus)
    extern "C" {extern int gettimeofday(struct timeval *, struct timezone *);}
#endif

#if defined(rs6000)
#if defined(__cplusplus)
        extern "C" { extern UTP_readTime(struct timestruc_t *); }
#else
        extern UTP_readTime(struct timestruc_t *);
#endif

#define SUMAA_LOG_time_func(v) {static struct  timestruc_t _tp; \
                               UTP_readTime(&_tp); \
                               (v)=((double)_tp.tv_sec)+(1.0e-9)*(_tp.tv_nsec);}

#else

#define SUMAA_LOG_time_func(v) {static struct timeval _tp; \
                               gettimeofday(&_tp,(struct timezone *)0);\
                               (v)=((double)_tp.tv_sec)+(1.0e-6)*(_tp.tv_usec);}
#endif
