#ifndef GR_Vertex
#define GR_Vertex 1

#include <vector>

#include "GR_config.h"
#include "GR_Classes.h"
#include "GR_Entity.h"
#include "GR_Vec.h"

class BasicTopologyEntity;
class GeometryEntity;
class CubitVector;
class CubitBox;

class FaceList {
  static const int block_size = 10;
  int iNUsed;
  Face *apF[block_size];
  FaceList *pFL;
 FaceList(FaceList&) : iNUsed(0), pFL(NULL) {assert(0);}
 public:
  FaceList() : iNUsed(0), pFL(NULL) {}
  ~FaceList() {
    if (pFL) {
      delete pFL;
      pFL = NULL;
    }
  }
/*   friend class FaceListIter; */
    
  void vAddFace(Face * const pF) {
    assert(iNUsed <= block_size);
#ifndef NDEBUG
    for (int ii = 0; ii < iNUsed; ii++) 
      assert(apF[ii] != pF);
#endif
    if (iNUsed == block_size) {
      if (!pFL) {
	pFL = new FaceList();
      }
      pFL->vAddFace(pF);
    }
    else {
      apF[iNUsed++] = pF;
    }
  }
  void vRemoveFace(Face const * const pF) {
    int i;
    FaceList *pFLCand = this;
    FaceList *pFLLast = this;
    FaceList *pFLPrev = NULL;
    assert(iNUsed > 0);
    do {
      for (i = 0; i < iNUsed; i++) {
	if (pFLCand->apF[i] == pF) {
	  // Get the last face...
	  while (pFLLast->pFL) {
	    pFLPrev = pFLLast;
	    pFLLast = pFLLast->pFL;
	  }
	  assert(pFLLast);
	  // Put it here instead
	  pFLCand->apF[i] = pFLLast->apF[pFLLast->iNUsed - 1];
	  // And drop the last one
	  pFLLast->iNUsed --;
	  assert(pFLLast->iNUsed >= 0);
	  if (pFLLast->iNUsed == 0 && !(pFLLast == this)) {
	    assert(pFLPrev);
	    delete pFLLast;
	    pFLPrev->pFL = NULL;
	  }
	  return;
	}
      }
      // If you got here, this block doesn't have it.
      pFLPrev = pFLCand;
      pFLCand = pFLCand->pFL;
    } while (pFLCand);
    assert(0);
  }	  
  Face* pFGetFace(const int i) const {
    if (i >= block_size)
      return pFL->pFGetFace(i - block_size);
    else {
      if (i >= iNUsed) return pFInvalidFace;
      else             return apF[i];
    }
  }
  bool qHasFace(const Face* const pF) const {
    int i;
    for (i = 0; i < iNUsed; i++) {
      if (apF[i] == pF) {
	return true;
      }
    }
    // If you got here, this block doesn't have it.
    if (pFL) return pFL->qHasFace(pF);
    else return false;
  }
  void clear() {
    if (pFL) delete pFL;
    pFL = NULL;
    iNUsed = 0;
  }
  int size() {
    if (pFL) {
      assert(iNUsed == block_size);
      return block_size + pFL->size();
    }
    else return iNUsed;
  } 
 public:
  FaceList& operator=(const FaceList& FL) {
    if (this != &FL) {
      iNUsed = FL.iNUsed;
      for (int ii = 0; ii < block_size; ii++) {
	apF[ii] = FL.apF[ii];
      }
      if (pFL != NULL) {
	delete pFL;
	pFL = NULL;
      }
      if (FL.pFL != NULL) {
	pFL = new FaceList;
	(*pFL) = *(FL.pFL);
      }
    }
    return *this;
  }
};

class Vert : public Entity {
  
  ///
  double adLoc[3];
  ///
#ifndef OMIT_VERTEX_HINTS
  mutable Face *pFHint;
#endif
  FaceList *pFL;
  enum {eDefaultVecSize = 8};
  ///PUT THE FOLLOWING TWO IN AN UNION.
  GeometryEntity* parent_entity;        //Parent geometric entity (2D)
  BasicTopologyEntity* parent_topology; //Parent topological entity (3D)
  ///
  
  // This is a packed bitfield containing a set of flags, including 10
  // bits for user data. The mechanics of the packing are handled
  // automatically by the compiler.
  unsigned int uiDim:2, uiType:4;
  bool qDel:1, qDelReq:1, qAct:1, qSurfStruct:1, qStruct:1,
    qShapeOK:1, qSmall:1, qShell:1;
  
  ////////////////////////////////////////////////////////////
  //////Part of the old interface that might get deleted//////
  ////////////////////////////////////////////////////////////
  // Flags to tell you what data you've got.
  bool qIsClosestVert:1, qIsSecondVert:1;
  // Pointer to length-scale influencing vert (old style)
  // or to the nearest vert / patch (new style)
  union {
    Vert* pV1;
    BdryPatch* pBP1;
  };
  // Pointer to the second-nearest vert / patch (new style)
  union {
    Vert* pV2;
    BdryPatch* pBP2;
  };
  ////////////////////////////////////////////////////////////
  ////////////////////////////////////////////////////////////
  
private:
  ///Length-scale for this vertex
  double dLengthScale;
  
 Vert(const Vert&) : Entity(), pFHint(NULL), pFL(NULL), parent_entity(),
    parent_topology(), uiDim(), uiType(), qDel(false), qDelReq(false),
    qAct(false), qSurfStruct(false), qStruct(false), qShapeOK(false),
    qSmall(false), qShell(false), qIsClosestVert(false),
    qIsSecondVert(false), pV1(NULL), pV2(NULL), dLengthScale(0) 
    { assert(0); }
  
public:
  Face *pFFace(const int i) {
    return(pFL->pFGetFace(i));
  }
private:
  Cell *pCCell(const int) {assert(0); return pCInvalidCell;}
  const Face *pFFace(const int) const {assert(0); return pFInvalidFace;}
  const Cell *pCCell(const int) const {assert(0); return pCInvalidCell;}
public:
  ///
  enum VertType {eUnknown = 0, eBdryApex, eBdryCurve, eBdryTwoSide,
      eBdry, ePseudoSurface, eInterior, eInteriorFixed, eBBox, eInvalid};
  ///
  Vert(const VertType VT = eInterior) : Entity(), 
    pFHint(pFInvalidFace), pFL(NULL), parent_entity(), parent_topology(),
    uiDim(), uiType((VT & 0xF)), qDel(false), qDelReq(false),
    qAct(false), qSurfStruct(false), qStruct(false), qShapeOK(false),
    qSmall(false), qShell(false), qIsClosestVert(false),
    qIsSecondVert(false), pV1(NULL), pV2(NULL), dLengthScale(0) 
    // Others set by SetDefaultFlags
  {
    // By default, a vertex has eInterior type, 0 space dimensions, and
    // is smoothable.  All other flags are cleared.
    pFL = new FaceList();
    vSetDefaultFlags();
    adLoc[0] = adLoc[1] = adLoc[2] = 0.;
    vClearLS();
  }
  ///
  ~Vert() {if (pFL) delete pFL;}
  ///
  Vert& operator=(const Vert& V);
  /// Ensure a sane initial state for face data
  void vResetAllData();
public:
  /* ITAPS Begin ITAPS Begin ITAPS Begin ITAPS Begin ITAPS Begin ITAPS Begin */
  // The following functions are very useful for GRUMMP support of ITAPS.
  const Vert *pVVert(const int /*iV*/) const {
    return this;
  }
  Vert *pVVert(const int /*iV*/) {
    return this;
  }
  void vAllVertHandles(GRUMMP_Entity* []) const {assert(0);}
  void vAllCellHandles(GRUMMP_Entity* []) const {assert(0);}
  void vAllFaceHandles(GRUMMP_Entity* []) const {assert(0);}

  int iNumVerts() const {return 0;}
  int iNumFaces() const {
    return pFL->size();
  }
  int iNumCells() const {assert(0); return(0);}
#ifdef ITAPS
  int eEntType() const {return iBase_VERTEX;}
  int eEntTopology() const {return iMesh_POINT;}
#endif
  /* ITAPS End ITAPS End ITAPS End ITAPS End ITAPS End ITAPS End ITAPS End */

  ///
  Face *pFHintFace() const;
  ///
  void vSetHintFace(Face *const pF);
  ///
  Face *pFSetHintFace(const Mesh* const pM);
  ///
  void vClearHintFace() {pFHint = pFInvalidFace;}
  void vUpdateHintFace();
  ///
  void set_parent_topology(BasicTopologyEntity* const parent) { parent_topology = parent; }

  void vAddFace(Face * const pF) {
    pFL->vAddFace(pF);
  }
  ///
  void vRemoveFace(Face const * const pF)
  {
    pFL->vRemoveFace(pF);
  }
  void vClearFaceConnectivity() {
    pFL->clear();
  }
  bool qHasFace(const Face * const pF) const
  {
    return pFL->qHasFace(pF);
  }
  ///
  BasicTopologyEntity* get_parent_topology() const { return parent_topology; }
  ///
  void vSetDefaultFlags();
  ///
  void vCopyAllFlags(const Vert &V);
  ///
  void vCopyAllFlags(const Vert * const pV) {vCopyAllFlags(*pV);}
  ///
  void vSetType(const VertType VT) {uiType = (VT & 0xF);}
  ///
  void vSetType(const unsigned int uiTypeIn) {
    assert(uiTypeIn <= eInvalid);
    uiType = (uiTypeIn & 0xF);
  }
  ///
  int iVertType() const {return (uiType);}
  ///
  bool qIsBdryVert() const;
  ///
  int iSpaceDimen() const {return (uiDim);}
  ///
  void vSetDimen(const unsigned iSD) {
    assert(uiDim == 0);
    assert(iSD == 2 || iSD == 3);
    uiDim = (iSD & 0x3);
  }
  ///
  void vMarkDeleted() { qDel = true; }
  ///
  bool qDeleted() const { return (qDel); }
  ///
  void vMarkActive() { qAct = true; }
  ///
  void vMarkInactive() { qAct = false; }
  ///
  bool qActive() const { return (qAct); }
  ///
  void vMarkToDelete() { qDelReq = true; }
  ///
  void vMarkToKeep() { qDelReq = false; }
  ///
  bool qDeletionRequested() const { return (qDelReq); }
  ///
  void vMarkStructured() {
    if( qIsBdryVert() ) qSurfStruct = true;
    else                qStruct = true;
  }
  ///
  void vClearStructured() {qSurfStruct = qStruct = false;}
  ///
  bool qIsStructured() const {
    if( qIsBdryVert() ) return qSurfStruct;
    else                return qStruct;
  }
  ///
  bool qSmoothable() const;
  ///
  bool qWellShaped() const { return (qShapeOK); }
  ///
  void vMarkWellShaped() { qShapeOK = true; }
  ///
  void vMarkIllShaped()  { qShapeOK = false; }
  ///
  double dX() const { return adLoc[0]; }
  ///
  double dY() const { return adLoc[1]; }
  ///
  double dZ() const { return (iSpaceDimen() == 3) ? adLoc[2] : 0; }
  ///
  void vCopyCoords(const Vert * const pV) {
    assert(pV->qValid());
    vSetCoords(pV->iSpaceDimen(), pV->adCoords());
  }
  ///
  void vSetCoords(const int iNumDim, const double adNewLoc[]);
  ///
  void vSetCoords(const char * const pcBuffer);
  ///
  void vSetCoords(const int iNumDim, const CubitVector& coord);
  ///
  
  //Added by SG.
  void set_parent_entity(GeometryEntity* const parent) { parent_entity = parent; }
  ///
  GeometryEntity* get_parent_entity() { return parent_entity; }
  
  //The following four added on Sept. 11 2006 SG.//
  bool small_angle_vert() const { return qSmall; }
  bool shell_vert() const       { return qShell; }
  void set_small_angle_vert(const bool small) { qSmall = small; }
  void set_shell_vert      (const bool shell) { qShell = shell; }

  //The following added on Jan 24th 2007 SG //
  CubitBox bounding_box() const;
  const double* adCoords() const { assert(qValid()); return adLoc; }

  bool qValid() const { return (this != pVInvalidVert); } ;

  ///////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////
  bool qIsSmallAngleCorner() const { 
    if(iSpaceDimen() == 2) assert(0);
    return qSmall;
  }
  void vSetSmallAngleCorner(bool qSmallAngle) {
    if(iSpaceDimen() == 2) assert(0);
    qSmall = qSmallAngle;
  }
  ///////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////

  //The following code has to do with length scale calculation.
  //Potential rewrite (Doug?) in a near future (Sept. 11 2006)

  double dLS() const { return dLengthScale; }

  void vSetLS(double dLength) {
    assert( dLength > 0 );
    dLengthScale = dLength;
  }

  void vClearLS() {
    dLengthScale = LARGE_DBL;
    qIsClosestVert = qIsSecondVert = false;
    pV1 = pV2 = pVInvalidVert;
  }

  // Stuff required for new-style length scale calculation
  void vSetClosest(Vert * const pVIn);
  void vSetClosest(BdryPatch * const pBPIn);
  void vSetClosest(Vert * const pVIn, BdryPatch * const pBPIn);

  void vSetSecond(Vert * const pVIn);
  void vSetSecond(BdryPatch * const pBPIn);
  void vSetSecond(Vert * const pVIn, BdryPatch * const pBPIn);

  void vGetClosest(Vert **ppVOut, BdryPatch **ppBPOut);
  void vGetSecond(Vert **ppVOut, BdryPatch **ppBPOut);

  void vCopyInfluence(const Vert * const pVIn) {
    qIsClosestVert = pVIn->qIsClosestVert;
    qIsSecondVert = pVIn->qIsSecondVert;
    // Might not be a vertex pointer, but the operation still works...
    pV1 = pVIn->pV1;
    pV2 = pVIn->pV2;
  }

  ///
  friend Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
			      bool qCanBeConnectedBothSides = false);

  friend Face* findCommonFace(const Vert * const pV0, const Vert * const pV1,
			      const Vert * const pV2,
			      const Vert * const pV3 = pVInvalidVert,
			      bool qCanBeConnectedBothSides = false);
};

double dDistanceBetween(const Vert * const pV1, const Vert * const pV2);

#endif
