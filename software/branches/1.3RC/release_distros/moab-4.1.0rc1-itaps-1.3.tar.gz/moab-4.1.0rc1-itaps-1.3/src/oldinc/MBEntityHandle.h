#ifndef MBEntityHandle_HEADER
#define MBEntityHandle_HEADER
#include "moab/EntityHandle.hpp"
typedef moab::EntityHandle MBEntityHandle;
#endif
