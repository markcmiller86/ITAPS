#ifndef MBVersion_HEADER
#define MBVersion_HEADER
#include "moab/Version.h"
#endif
