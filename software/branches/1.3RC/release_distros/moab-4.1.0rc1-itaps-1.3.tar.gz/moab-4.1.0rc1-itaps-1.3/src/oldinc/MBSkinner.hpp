#ifndef MBSkinner_HEADER
#define MBSkinner_HEADER

#include "MBForward.hpp"

#include "moab/Skinner.hpp"
typedef moab::Skinner MBSkinner;

#endif
