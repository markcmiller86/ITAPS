#ifndef MBWriteUtilIface_HEADER
#define MBWriteUtilIface_HEADER

#include "MBRange.hpp"

#include "moab/WriteUtilIface.hpp"
typedef moab::WriteUtilIface MBWriteUtilIface;

#endif
