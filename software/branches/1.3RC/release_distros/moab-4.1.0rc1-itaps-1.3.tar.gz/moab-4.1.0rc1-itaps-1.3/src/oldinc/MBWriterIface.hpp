#ifndef MBWriterIface_HEADER
#define MBWriterIface_HEADER

#include "MBTypes.h"

#include "moab/WriterIface.hpp"
typedef moab::WriterIface MBWriterIface;

#endif
