#ifndef MBAdaptiveKDTree_HEADER
#define MBAdaptiveKDTree_HEADER

#include "MBTypes.h"

#include "moab/AdaptiveKDTree.hpp"
typedef moab::AdaptiveKDTree MBAdaptiveKDTree;
typedef moab::AdaptiveKDTreeIter MBAdaptiveKDTreeIter;

#endif
