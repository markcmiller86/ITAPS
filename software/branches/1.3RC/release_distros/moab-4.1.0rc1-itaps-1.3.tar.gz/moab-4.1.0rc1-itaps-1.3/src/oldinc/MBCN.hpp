#ifndef MBCN_HEADER
#define MBCN_HEADER

#include "MBEntityType.h"

#include "moab/CN.hpp"
typedef moab::CN MBCN;
using moab::DimensionPair;
#define MB_MAX_SUB_ENTITIES  moab::MAX_SUB_ENTITIES;
#define MB_MAX_SUB_ENTITY_VERTICES moab::MAX_SUB_ENTITY_VERTICES;

#endif
