#ifndef MBInterface_HEADER
#define MBInterface_HEADER

#include "MBForward.hpp"

#include "moab/Interface.hpp"
typedef moab::Interface MBInterface;

#endif
