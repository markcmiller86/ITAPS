#ifndef MBGeomUtil_HEADER
#define MBGeomUtil_HEADER

#include "MBCartVect.hpp"

#include "moab/GeomUtil.hpp"
namespace MBGeomUtil = moab::GeomUtil;

#endif
