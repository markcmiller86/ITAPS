#ifndef IGEOM_F_H
#define IGEOM_F_H

#define iGeom_Instance integer
#define iGeom_EntityIterator integer
#define iGeom_EntityArrIterator integer

#endif 

#include "iBase_f.h"

