//- Class:       ChollaEntity
//- Description: ChollaEntity class - the base class in the Cholla Geometry Entities.
//- Owner:       Steve Owen
//- Checked by:
//- Version: $Id: 

#include "ChollaEntity.hpp"

ChollaEntity::ChollaEntity()
{

}

ChollaEntity::~ChollaEntity()
{
}

