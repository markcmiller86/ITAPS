#ifndef SDL_MREFEDGELENGTH_LIST_HPP
#define SDL_MREFEDGELENGTH_LIST_HPP

#include "SDLList.hpp"
#include "MRefEdge.hpp"

SDLListdeclare(SDLMRefEdgeLengthList, MRefEdge*, get_arc_length, double)

#endif 

