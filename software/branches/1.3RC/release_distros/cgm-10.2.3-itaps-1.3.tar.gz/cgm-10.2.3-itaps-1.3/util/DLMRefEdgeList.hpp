#ifndef DLMREFEDGELIST_HPP
#define DLMREFEDGELIST_HPP

#include "DLList.hpp"

class MRefEdge;

DLListdeclare(DLMRefEdgeList,MRefEdge*)

#endif 

