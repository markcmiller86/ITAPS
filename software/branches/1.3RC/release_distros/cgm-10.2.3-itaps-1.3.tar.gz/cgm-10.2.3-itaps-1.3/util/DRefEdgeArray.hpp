#ifndef DREFEDGEARRAY_HPP
#define DREFEDGEARRAY_HPP
 
#include "DynamicArray.hpp"
 
class RefEdge;
 
DynamicArrayDeclare(DRefEdgeArray,RefEdge*)
 
#endif

