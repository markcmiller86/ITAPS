/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "mMigrateUtil.h"
#include "pmModelUtil.h"


#include "FMDB_OwnerManager.h"
#include "FMDB_LoadBalancer.h"
#include "mAttachableDataContainer.h"
#include "mPart.h"
#include "mEntity.h"
#include "mException.h"
#include "mEdge.h"
#include "mVertex.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#ifdef FMDB_PARALLEL
#include "mExchangeData.h"
#endif
#include "mFMDB.h"
#include <list>

using std::list;
using std::pair;
using std::vector;

//this one give the pid that is poor
int getPid_withBalance(mPart* mesh, mEntity* ent, vector<int>& poor_to_rich_pids)
{
#ifdef FMDB_PARALLEL
  FMDB_OwnerManager* o = mesh->theOwnerManager;
  FMDB_OwnerManager::iter it = o->begin(ent);
  FMDB_OwnerManager::iter itend = o->end(ent);
  
  int owner=ParUtil::Instance()->rank();
  vector<int> allPids;
  vector<int>::iterator pidIter=poor_to_rich_pids.begin();
  
  allPids.push_back(ParUtil::Instance()->rank());

  for (;it != itend;++it) {
    allPids.push_back((*it).second.pid());
  }
  
  for (;pidIter!=poor_to_rich_pids.end();++pidIter)
  {
    if (std::find(allPids.begin(),allPids.end(),*pidIter)!=allPids.end())
    {  
      owner=*pidIter;
      break;
    }
  }
//  cout<<"\t* ("<<M_Pid()<<") pid_withBalance of "<<ent->getUid()<<" : "<<owner<<endl;
  return (owner);
#else
  return 0;
#endif
}


#ifdef FMDB_PARALLEL
// ***********************************************************
void setEntitiesToMoveFromVertices_withBalance(mPart* mesh, 
                   list<mEntity*>& entities)
// ***********************************************************
{
  // get the entities to move and their owner processor
  unsigned int tagMark=FMDB_Util::Instance()->lookupMeshDataId("_pid");
  int dim=M_globalMaxDim(mesh);
  mEntity* ent;
  mEntity* vt;
  int owner;
  vector<int> poor_to_rich_pids;
  
  getSortedPids_poor_to_rich(mesh,poor_to_rich_pids);
  
  list<mEntity*>::iterator vit=entities.begin();
  for (; vit!=entities.end();++vit)
  {
    mEntity* v = *vit;
    mAdjacencyContainer upward;
    v->getHigherOrderUpward (dim,upward);
    int owner = getPid_withBalance(mesh, v, poor_to_rich_pids);

//     assert(owner == v->getCommonBdry()->getOwner());    // This getCommonBdry() does not exist in mEntity anymore. 
    for (int i=0; i<upward.size();++i)
    {
      mRegion* r = (mRegion*) upward[i];
      if (r->getData(tagMark))
      {  
        if (r->getAttachedInt(tagMark)>owner)
        {
          r->deleteData(tagMark);
          r->attachInt(tagMark,owner);
        }
      }
      else
      {
        r->attachInt(tagMark,owner);
      }
    } //upward
  } // vit
}
#endif
