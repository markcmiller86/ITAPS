/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <list>
#include <set>
#include <map>
#include <vector>
#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mEntity.h"
#include "mFMDB.h"
#include "oldFMDB.h"
#include "ParUtil.h"
#include "FMDB_cint.h"
#include "FMDB_Internals.h"

using std::cout;
using std::endl;
using std::list;
using std::pair;
using std::vector;
using std::map;
using std::set;

void set_subtract(set<int> A, set<int> B, set<int>& C)
{
  set<int>::iterator aiter, biter;
  for (aiter=A.begin(); aiter!=A.end();++aiter)
  {
    biter = B.find(*aiter);
    if (biter==B.end()) C.insert(*aiter);
  }
} 


void printFamily(mEntity* ent)
{
  int mypid=ParUtil::Instance()->rank();
  list<mEntity*> family;
  list<mEntity*>::iterator it;
  getFamily(ent, family);
  cout<<"("<<mypid<<") family of "<<ent->getUid()<<": ";
  for (it=family.begin();it!=family.end();++it)
    cout<<(*it)->getUid()<<",";
  cout<<endl;
}  

// *****************************************
void getFamily(mEntity* ent, list<mEntity*>& family)
// *****************************************
{
  int n = ent->getLevel();
  mEntity* fc;
  mEntity* eg;
  switch (n)
  {
    case 3:
           for (int i=0; i<ent->size(2);++i)
           { 
             fc = ent->get(2,i);
             family.push_back(fc);
             for (int j=0; j<fc->size(1);++j)
             {
               eg = fc->get(1,j);
               family.push_back(eg);
               family.push_front(eg->get(0,0));
               family.push_front(eg->get(0,1));
             }  
           }
           break;
    case 2:// edges
          for (int j=0; j<ent->size(1);++j)
          {
            eg = ent->get(1,j);
            family.push_back(eg);
            family.push_front(eg->get(0,0));
            family.push_front(eg->get(0,1));
	  }  
	  break;
    case 1:  
          family.push_front(eg->get(0,0));
          family.push_front(eg->get(0,1));
           break;
    default: break;
  }
  family.push_back(ent);
  return;
}

void getEntitiesToHandle(std::map<mEntity*,int>& entitiesToMove,
                         std::set<mEntity*>* entitiesToHandle)
{
    map<mEntity*,int*> POtoMove; 
    map<mEntity*,int>::iterator iter; 
    int* pids; 
    for(iter=entitiesToMove.begin(); iter!=entitiesToMove.end(); iter++) {
      pids = new int[3]; 
      pids[0]=0; 
      pids[1]=iter->second; 
      pids[2]=iter->second;

      POtoMove[iter->first]=pids; 
    }

    map<mEntity*,int> entities[4]; 
    getEntitiesToHandle(POtoMove, entities);

    mEntity* ent; 
    map<mEntity*,int>::iterator mapit; 
    for(int dim=0; dim<4; dim++)
      for(mapit=entities[dim].begin(); mapit!=entities[dim].end(); mapit++) {
	 ent = mapit->first; 
	 (entitiesToHandle[ent->getLevel()]).insert(ent); 
      }
}


// *****************************************
void getEntitiesToHandle(map<mEntity*,int*>& POToMove,         // int[3]:lid, tgt_pid, tgt_proc
             map<mEntity*,int>* entitiesToHandle)              // int: local pid (lid)
// *****************************************
{
  int mypid=ParUtil::Instance()->rank();
  int rank;

  int tgtNumPart = ParUtil::Instance()->getTgtNumParts(); 
  int numPart = ParUtil::Instance()->getCurNumParts(); 
 
  map<mEntity*, int*>::iterator mapit; 
  mEntity* ent;

  IPComMan *CM = ParUtil::Instance()->ComMan();

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(int_mEnt_struct));
  int_mEnt_struct* msg_send = (int_mEnt_struct*)CM->alloc_msg(sizeof(int_mEnt_struct));

  int num_sent = 0, num_recvd = 0;

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    // make sure POToMove does not include PO whose target part equals the local part 
    int poLid = (mapit->second)[0];                    // local pid 
    if (mypid==(mapit->second)[2] && mypid*tgtNumPart+poLid==(mapit->second)[1])      
    { // stay in the current part 
      POToMove.erase(mapit->first);
      continue;
    }
    list<mEntity*> family;
    list<mEntity*>::const_iterator lit;
    getFamily(mapit->first, family);
    for (lit=family.begin();lit!=family.end();++lit)
    {
      ent = *lit;
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
      (entitiesToHandle[ent->getLevel()])[ent]=poLid; 
      if (ent->getNumRemoteCopies()==0)
        continue;
      for(mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      {
          int pid = (rciter->first)/numPart;
          msg_send->entity = rciter->second;
	  msg_send->i=(rciter->first)%numPart;             // local pid of receiver
          CM->send(pid, (void*)msg_send);
          num_sent++;
      } // for rciter
    } // for family
  } // for POtoMove

  CM->finalize_send();
  CM->free_msg(msg_send);


  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    int_mEnt_struct* castbuf = (int_mEnt_struct*) msg_recv; 
    ent = castbuf->entity;
   
    if(entitiesToHandle[ent->getLevel()].count(ent)==0) {
        ent->clearBPs();
        ent->setPClassification((pmEntity*)0);
        (entitiesToHandle[ent->getLevel()])[ent]=castbuf->i;
    }
 
    CM->free_msg(msg_recv);
  }
}


// *****************************************
void setBPs(int meshDim, map<mEntity*,int*>& POtoMove,       // int*: int[3]
           map<mEntity*,int>* entitiesToHandle)              // int: lid
// *****************************************
{
  map<mEntity*, int*>::const_iterator mapit; 
  mEntity* ent;
  int mypid=ParUtil::Instance()->rank();

  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();

  //  int poLid; 
  for (mapit=POtoMove.begin();mapit!=POtoMove.end();++mapit)
  {
    mapit->first->clearBPs(); 
    mapit->first->addBPs((mapit->second)[1]);         // target_global_pid 
  }
    
  for (mapit=POtoMove.begin();mapit!=POtoMove.end();++mapit)
  {
    int lid = (mapit->second)[0]; 
    int pid = (mapit->second)[1]; 
    list<mEntity*> family;
    list<mEntity*>::const_iterator lit;
    getFamily(mapit->first, family);
 
    for (lit=family.begin();lit!=family.end();++lit)
    {
      if ((*lit)->getLevel()==meshDim) // exit if self 
        continue;
 
      ent = *lit;
      ent->addBPs(pid);
  
      mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
          ent->addBPs(mypid*tgtNumPart+lid); // stay in the current part 
          break;  // exit for loop
        }
      }
    }
  }
  
  for (int dim=0;dim<meshDim;++dim)
  {
 
    map<mEntity*, int>::iterator eit = entitiesToHandle[dim].begin(); 
    for (;eit!=entitiesToHandle[dim].end();++eit)
    {
      int lid = eit->second; 
      ent = eit->first; 
      mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
	  ent->addBPs(mypid*tgtNumPart+lid); // stay in the current part 
          break;  // exit for loop
        }
      } // upward
    } // for entitiesToHandle
  }  // for dim
}


// *****************************************
void exchangeBPs(set<mEntity*>* entitiesToHandle)
// *****************************************
{
   map<mEntity*,int> entities_map[4]; 
   set<mEntity*>::iterator iter; 
   for(int dim=0; dim<4; dim++)
      for(iter=entitiesToHandle[dim].begin(); iter!=entitiesToHandle[dim].end(); iter++) {
	  (entities_map[dim])[*iter]=0; 
      }

   exchangeBPs(entities_map);
}

// *****************************************
void exchangeBPs(map<mEntity*,int>* entitiesToHandle)
// *****************************************
{    
 
  map<mEntity*, int>::iterator eit;  
  mEntity* ent;
  int numPart = ParUtil::Instance()->getCurNumParts();
  
  int pid, buf_size, numBP;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  int num_sent = 0, num_recvd = 0;

  void *msg_send;
  mEntity** castbuf;

  for (int dim=0; dim<=3;++dim)
  {
    for (eit=entitiesToHandle[dim].begin();eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first; 
      numBP = ent->getNumBPs();
      if (ent->getNumRemoteCopies()==0)
        continue;
      for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
      {
	pid = (rciter->first)/numPart;
        buf_size=sizeof(mEntity*) + numBP*sizeof(int);
        msg_send = CM->alloc_msg(buf_size);
        castbuf = (mEntity**)msg_send;
        *castbuf = rciter->second;
        int *BPs = (int*)((char*)msg_send + sizeof(mEntity*));
        int i = 0;
        for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
        {
          BPs[i]=*bpiter;
          i++;
        }
        CM->send(pid, (void*)msg_send, buf_size);
        num_sent++;
        CM->free_msg(msg_send);
      }  
    }
  }
  CM->finalize_send();

  // receive phase begins
  void *msg_recv;
  int pid_from;
  int* BPs;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    BPs = (int*)((char*)msg_recv + sizeof(mEntity*));
    numBP = (rc - sizeof(mEntity*)) / INT_SIZE;
    for (int i = 0; i < numBP; i++)
    {
      ent->addBPs(BPs[i]);
    }
    CM->free_msg(msg_recv);
  }
}

// ***********************************************************
void updatePC_and_collectEntitiesToRemove(
			map<mEntity*,int>* entitiesToHandle, 
			map<mEntity*,int>* entitiesToRemove)
// ***********************************************************
{
  mEntity* ent;
  map<mEntity*, int>::const_iterator eit; 

  int mypid = ParUtil::Instance()->rank();
  int numPart = ParUtil::Instance()->getTgtNumParts();
  
  for (int dim=0; dim<=3; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();
      eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first; 
      int lid = eit->second; 
      if (lid >= numPart)                                        // the whole part will be removed 
	 (entitiesToRemove[dim])[ent]=lid; 
      else if (!ent->findPidInBPs(mypid*numPart+lid))               // stay in the current part 
	(entitiesToRemove[dim])[ent]=lid; 
      else //if (!ent->getPClassification()) 
        ent->setPClassificationWithBPs();
    }    
  }
}


// ***********************************************************
void removeUnusedEntities(mPart* mesh, pmMigrationCallbacks &cb,int dim,
                         set<mEntity*>* entitiesToRemove)
// ***********************************************************
{
   vector<mPart*> meshes; 
   meshes.push_back(mesh);

   map<mEntity*,int> entities_map[4]; 
   set<mEntity*>::iterator setit; 
   for(int i=0; i<=dim; i++)
      for(setit=entitiesToRemove[i].begin(); setit!=entitiesToRemove[i].end(); setit++) 
	 (entities_map[i])[*setit]=0; 

   removeUnusedEntities(meshes, cb, dim, entities_map);
}


// ***********************************************************
void removeUnusedEntities(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb,int dim, 
			 map<mEntity*,int>* entitiesToRemove)
// ***********************************************************
{

  map<mEntity*, int>::iterator eiter;
  map<mEntity*, int> entitiesOnCB; 
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  mEntity* ent; 
  int mypid = ParUtil::Instance()->rank(); 

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::All_Reduce);
  CM->set_tag(0);
  int msg_size = sizeof(mEntity*)+sizeof(int);
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;
  mEntity** s_ent; 
  int* s_id; 

  for (int i=dim; i>=0; --i)  // region to vertex
    for (eiter=entitiesToRemove[i].begin(); eiter!=entitiesToRemove[i].end();++eiter) 
    {
      ent = eiter->first; 
      cb.deleteEntityData(ent);
      if (ent->getNumRemoteCopies())
      {
        for (mEntity::RCIter rcIter=ent->rcBegin(); rcIter!=ent->rcEnd();++rcIter)
        {
	  s_ent = (mEntity**)msg_send; 
	  *s_ent = rcIter->second;
	  s_id = (int*)((char*)msg_send+sizeof(mEntity*)); 
	  *s_id = mypid*numPart + eiter->second;                        // ent's global pid
          CM->send((rcIter->first)/numPart, (void*)msg_send);
	  num_sent++; 
        }
      }
    }
  
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    s_ent = (mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv+sizeof(mEntity*)); 
    (*s_ent)->deleteRemoteCopy(*s_id);
    CM->free_msg(msg_recv);
  }

   unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag"); 
   void* tmp; 

#ifdef MATCHING
    CM->set_tag(0);
    msg_size = 2*sizeof(mEntity*)+ sizeof(int);
    CM->set_fixed_msg_size(msg_size);
    void* msg_send2 = CM->alloc_msg(msg_size);
    num_sent = 0; num_recvd = 0;

    for (int i=dim-1; i>=0; --i)  // region to vertex
      for (eiter=entitiesToRemove[i].begin(); eiter!=entitiesToRemove[i].end();++eiter)
      {
        ent = eiter->first;
        if( !ent->hasMatchEnt() )
	  continue; 
        for (mEntity::MEIter meIter=ent->meBegin(); meIter!=ent->meEnd();++meIter)
        {
          if((meIter->first)/numPart==mypid) {
	    (meIter->second)->deleteMatchEnt(mypid*numPart + eiter->second, ent);
	    continue; 
	  }  
	
          s_ent = (mEntity**)msg_send2;
          s_ent[0] = meIter->second;
          s_ent[1] = ent;
          s_id = (int*)((char*)msg_send2 + 2*sizeof(mEntity*));
          *s_id = mypid*numPart + eiter->second;                        // ent's global pid
          CM->send((meIter->first)/numPart, (void*)msg_send2);
          num_sent++;
       }
     }
    CM->finalize_send();
    CM->free_msg(msg_send2);

  // receive phase begins
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;
      s_ent = (mEntity**)msg_recv;
      s_id = (int*)((char*)msg_recv+ 2*sizeof(mEntity*));
      (s_ent[0])->deleteMatchEnt(*s_id, s_ent[1]);
      CM->free_msg(msg_recv);
    }
#endif

  if (dim==3)
    for (eiter=entitiesToRemove[3].begin(); eiter!=entitiesToRemove[3].end();++eiter){
      if(EN_getDataPtr(eiter->first, egTag, &tmp)) {
	 (eiter->first)->deleteData(egTag);
      }
      M_removeRegion(meshes[eiter->second], eiter->first);
    }
      
  for (eiter=entitiesToRemove[2].begin(); eiter!=entitiesToRemove[2].end();++eiter) {
      if(dim==2 && EN_getDataPtr(eiter->first, egTag, &tmp)) {
	  (eiter->first)->deleteData(egTag); 
       }
      M_removeFace(meshes[eiter->second], eiter->first );
  }

  for (eiter=entitiesToRemove[1].begin(); eiter!=entitiesToRemove[1].end();++eiter)
       M_removeEdge(meshes[eiter->second], eiter->first );
  
  for (eiter=entitiesToRemove[0].begin(); eiter!=entitiesToRemove[0].end();++eiter)
       M_removeVertex(meshes[eiter->second], eiter->first );

}

// *****************************************
void getEntitiesToHandle_and_setBPs(int meshDim, map<mEntity*,int*>& POToMove,
             map<mEntity*,int>* entitiesToHandle)
// *****************************************
{
  int mypid=ParUtil::Instance()->rank();
  int pid;
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();
  int numPart = ParUtil::Instance()->getCurNumParts();

  IPComMan *CM = ParUtil::Instance()->ComMan();
   CM->set_comm_validation(IPComMan::All_Reduce);

  map<mEntity*, int*>::iterator mapit;
  mEntity* ent, *r;

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    mapit->first->clearBPs();
    mapit->first->setPClassification((pmEntity*)0);
    mapit->first->addBPs((mapit->second)[1]);
    (entitiesToHandle[mapit->first->getLevel()])[mapit->first]=(mapit->second)[0];   
  }

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    pid = (mapit->second)[1];               // dest global pid
    r = mapit->first;
    list<mEntity*> family;
    list<mEntity*>::iterator lit;
    getFamily(r, family);
    for (lit=family.begin();lit!=family.end();++lit)
    {
      ent = *lit;

      if (ent->getLevel() == meshDim)
        continue;

      int entCount = entitiesToHandle[ent->getLevel()].count(ent);
      if (!entCount)
      {
        ent->clearBPs();
        ent->setPClassification((pmEntity*)0);
        entitiesToHandle[ent->getLevel()][ent]=(mapit->second)[0];        // src local pid

        mAdjacencyContainer upward;
        ent->getHigherOrderUpward(meshDim,upward);
        for (int i=0; i<upward.size();++i)
        {
          if (upward[i]->getNumBPs()==0)
          {
            ent->addBPs(mypid*tgtNumPart+(mapit->second)[0]); 
            break;  // exit for loop
          }
        }
      }
      ent->addBPs(pid);
    } // for family
  } // for POtoMove

  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  int num_sent = 0, num_recvd = 0;
  void *msg_send;
  mEntity** s_ent;
  int* s_id; 

  map<mEntity*, int>::iterator eit;
  int msg_size, numBP;
  for (int dim = 0; dim <= meshDim; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first;
      if (ent->getNumRemoteCopies()==0)
        continue;

      numBP = ent->getNumBPs();
      for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
      {
        pid = (rciter->first)/numPart;
        msg_size=sizeof(mEntity*) +sizeof(int) + numBP*sizeof(int);
        msg_send = CM->alloc_msg(msg_size);
        
        s_ent = (mEntity**)msg_send; 
        s_id = (int*)((char*)msg_send+sizeof(mEntity*));
	
        *s_ent = rciter->second; 
        *s_id = rciter->first; 

        int *BPs = (int*)((char*)msg_send + sizeof(mEntity*) + sizeof(int));
        int i = 0;
        for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
        {
          BPs[i]=*bpiter;
          i++;
        }
        CM->send(pid, (void*)msg_send, msg_size);
        num_sent++;
        CM->free_msg(msg_send);
      }
    }
  }
  CM->finalize_send();

  map<mEntity*,int> restToMove;
  map<mEntity*,int>::iterator rest_iter;

  // recieve phase
  void *msg_recv;
  int pid_from;
  int* BPs;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *((mEntity**)msg_recv); 
    int* src_pid = (int*)((char*)msg_recv+sizeof(mEntity*)); 
    BPs = (int*)((char*)msg_recv+sizeof(mEntity*)+sizeof(int)); 
    numBP = (rc-sizeof(mEntity*)-sizeof(int)) / INT_SIZE;

    if (!entitiesToHandle[ent->getLevel()].count(ent))
    {
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
      mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
          ent->addBPs(mypid*tgtNumPart+(*src_pid) % numPart); ///send to rem copies info about mypid
          if (ent->getNumRemoteCopies())
            restToMove[ent] = mypid*tgtNumPart + (*src_pid) % numPart ;
          break;  // exit for loop
        }
      } // upward
      entitiesToHandle[ent->getLevel()][ent] = (*src_pid) % numPart;
    }

    for (int i = 0; i < numBP; i++)
    {
      ent->addBPs(BPs[i]);
    }
    CM->free_msg(msg_recv);
  }

  msg_size = sizeof(mEntity*) + sizeof(int);
  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  msg_send = CM->alloc_msg(msg_size);
  num_sent = 0; num_recvd = 0;

  for (rest_iter = restToMove.begin(); rest_iter != restToMove.end(); rest_iter++)
  {
    ent = rest_iter->first;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      pid = (rciter->first)/numPart;
      s_ent = (mEntity**)msg_send;
      *s_ent = rciter->second;
      s_id = (int*)((char*)msg_send + sizeof(mEntity*));
      *s_id = rest_iter->second;
      CM->send(pid, (void*)msg_send);
      num_sent++;
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
    ent->addBPs(*s_id);
    CM->free_msg(msg_recv);
  }  
}


// the following one does not work for multiple parts per process 

// *****************************************
void getEntsToHandle_setBPs_nbrs(int meshDim, map<mEntity*,int*>& POToMove, map<mEntity*, int>* entitiesToHandle)
// *****************************************
{
  int mypid=ParUtil::Instance()->rank();
  int pid;
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();
  int numPart = ParUtil::Instance()->getCurNumParts();
  int numPtn = ParUtil::Instance()->size();

  IPComMan *CM = ParUtil::Instance()->ComMan();

  map<mEntity*, int*>::iterator mapit;
  mEntity* ent, *r;

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    mapit->first->clearBPs();
    mapit->first->addBPs((mapit->second)[1]);
    (entitiesToHandle[mapit->first->getLevel()])[mapit->first]=(mapit->second)[0];
  }

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    pid = (mapit->second)[1];
    r = mapit->first;
    list<mEntity*> family;
    list<mEntity*>::iterator lit;
    getFamily(r, family);

    int po_move_flag = 1;
    lit = family.begin();
    int i = 0;
    pmEntity *pme, *pme_comp;
    for (; i < 4; i++, lit++)
    {
      ent = *lit;
      pme = ent->getPClassification();
      if (pme)
      {
        break;
      }
    }
    i++;
    lit++;
    for (; i < 4; i++, lit++)
    {
      ent = *lit;
      pme_comp = ent->getPClassification();
      if (pme_comp && (pme != pme_comp))
      {
        po_move_flag = 0;
        break;
      }
    }

    if (po_move_flag)
    {

    for (lit=family.begin();lit!=family.end();++lit)
    {
      ent = *lit;

      if (ent->getLevel() == meshDim)
        continue;

      int entCount = entitiesToHandle[ent->getLevel()].count(ent);

      if (!entCount)
      {
        ent->clearBPs();
        entitiesToHandle[ent->getLevel()][ent]=(mapit->second)[0];

        mAdjacencyContainer upward;
        ent->getHigherOrderUpward(meshDim,upward);
        for (int i=0; i<upward.size();++i)
        {
          if (upward[i]->getNumBPs()==0)
          {
            ent->addBPs(mypid*tgtNumPart+(mapit->second)[0]);
            break;  // exit for loop
          }
        }
      }
      ent->addBPs(pid);
    } // for family

    }
    else
    {
      for (lit=family.begin();lit!=family.end();++lit)
      {
        ent = *lit;
        if (ent->getLevel() == meshDim)
          continue;

        int entCount = entitiesToHandle[ent->getLevel()].count(ent);
        if (entCount)
        {
          ent->addBPs(mypid*tgtNumPart+(mapit->second)[0]);
        }
      }
      r->clearBPs();
      entitiesToHandle[r->getLevel()].erase(r);
    }
  } // for POtoMove

  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  int num_sent = 0, num_recvd = 0;
  void *msg_send;
  mEntity** s_ent;
  int* s_id;

  map<mEntity*, int>::iterator eit;
  int msg_size, numBP;
  for (int dim = 0; dim <= meshDim; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first;
      ent->setPClassification((pmEntity*)0);
      if (ent->getNumRemoteCopies()==0)
        continue;

      numBP = ent->getNumBPs();
      for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
      {
        pid = (rciter->first)/numPart;
        msg_size = sizeof(mEntity*) + sizeof(int) + numBP*sizeof(int);
        msg_send = CM->alloc_msg(msg_size);

        s_ent = (mEntity**)msg_send;
        s_id = (int*)((char*)msg_send+sizeof(mEntity*));

        *s_ent = rciter->second;
        *s_id = rciter->first;

        int *BPs = (int*)((char*)msg_send + sizeof(mEntity*) + sizeof(int));
        int i = 0;
        for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
        {
          BPs[i]=*bpiter;
          i++;
        }
        CM->send(pid, (void*)msg_send, msg_size);
        num_sent++;
        CM->free_msg(msg_send);
      }
    }
  }
  CM->finalize_send();

  map<mEntity*, int> restToMove;
  map<mEntity*, int>::iterator rest_iter;

  // recieve phase
  void *msg_recv;
  int pid_from;
  int* BPs;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *((mEntity**)msg_recv);
    int* src_pid = (int*)((char*)msg_recv+sizeof(mEntity*));
    BPs = (int*)((char*)msg_recv+sizeof(mEntity*)+sizeof(int));
    numBP = (rc-sizeof(mEntity*)-sizeof(int)) / INT_SIZE;

    if (!entitiesToHandle[ent->getLevel()].count(ent))
    {
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
      mAdjacencyContainer upward;
      ent->getHigherOrderUpward(meshDim,upward);
      for (int i=0; i<upward.size();++i)
      {
        if (upward[i]->getNumBPs()==0)
        {
          ent->addBPs(mypid*tgtNumPart+(*src_pid) % numPart); //send to rem copies info about mypid
          if (ent->getNumRemoteCopies())
            restToMove[ent] = mypid*tgtNumPart + (*src_pid) % numPart ;
          break;  // exit for loop
        }
      } // upward
      entitiesToHandle[ent->getLevel()][ent] = (*src_pid) % numPart;
    }

    for (int i = 0; i < numBP; i++)
    {
      ent->addBPs(BPs[i]);
    }
    CM->free_msg(msg_recv);
  }

  msg_size = sizeof(mEntity*) + sizeof(int);
  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  msg_send = CM->alloc_msg(msg_size);
  num_sent = 0; num_recvd = 0;

  for (rest_iter = restToMove.begin(); rest_iter != restToMove.end(); rest_iter++)
  {
    ent = rest_iter->first;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      pid = (rciter->first)/numPart;
      s_ent = (mEntity**)msg_send;
      *s_ent = rciter->second;
      s_id = (int*)((char*)msg_send + sizeof(mEntity*));
      *s_id = rest_iter->second;
      CM->send(pid, (void*)msg_send);
      num_sent++;
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
    ent->addBPs(*s_id);
    CM->free_msg(msg_recv);
  }

}

void getEntityGroupsToHandle(std::map<mEntity*,int*>& entitiesToMove,
                             std::map<mEntityGroup*, int*>& egsToHandle)
{
  map<mEntity*,int*>::iterator mapit;
  unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");

  for(mapit=entitiesToMove.begin(); mapit!=entitiesToMove.end(); mapit++) {
    mEntity* ent = mapit->first;
    int* pid= mapit->second; 

    void* tmp;
    if (EN_getDataPtr(ent, egTag, &tmp))
       egsToHandle[(mEntityGroup*)tmp]=pid;
  }

  map<mEntityGroup*,int*>::iterator egit;
  for(egit = egsToHandle.begin(); egit!=egsToHandle.end(); egit++) {
     mEntityGroup* eg = egit->first;
     for(mEntityGroup::entIter entit=eg->begin(); entit!=eg->end(); entit++) {
       mEntity* ent = *entit;
       entitiesToMove[ent]=egit->second;
     }
  }
}
#endif /* FMDB_PARALLEL */
