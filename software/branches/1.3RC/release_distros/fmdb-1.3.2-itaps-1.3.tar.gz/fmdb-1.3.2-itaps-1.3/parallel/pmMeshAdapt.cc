/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <list>
#include <set>
#include "pmMeshAdapt.h"
#include "pmModel.h"
#include "pmUtility.h"
#include "ParUtil.h"
#include "FMDB_cint.h"

using std::vector;
using std::list;
using std::cout;
using std::endl;
using std::set;

int deleteDimReduction(mPart* mesh, pmMigrationCallbacks &cb, vector<mEntity*>* rmE)
{
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return 0;
  int mypid = ParUtil::Instance()->rank();

  int meshDim = ParUtil::Instance()->get_maxMeshDim(); 
  if (meshDim<3)  return 0;

// STEP I: collect faces to delete
  set<mEntity*> entToDelete[3];
  mEntity* ent;
  for (mPart::iterall it=mesh->beginall(2); it!=mesh->endall(2);++it)
  {
    ent = *it;
    if (F_numRegions(ent)==0)
    {
      entToDelete[2].insert(ent);
      for (int i=0; i<ent->size(1);++i) // for all adj edge
      {
        mEntity* eg = ent->get(1,i);
	bool toDelete=true;
        for (int j=0; j<eg->size(2);++j) // all adj faces
        {
          if (F_numRegions(eg->get(2,j))>0)
  	  {
	    toDelete=false; // if any adj face has region
	    break;
	  }
        }
        if (toDelete) 
	  entToDelete[1].insert(eg);
      }  // adj edge
    }  // fc to delete
  }
  
  for (set<mEntity*>::iterator eit=entToDelete[1].begin();
        eit!=entToDelete[1].end();++eit)
  { 
    ent = *eit;
    for (int i=0; i<2;++i)
    {
      mEntity* vt = ent->get(0,i);
      bool toDelete=true;
      for (int j=0; j<vt->size(1);++j) // all adj edges
      {
        mEntity* eg=vt->get(1,j);
	for (int k=0; k<eg->size(2);++k)
	{
	  if (F_numRegions(eg->get(2,k))>0)
  	  {  
	    toDelete=false;
	    break;
	  }
	}
      }
      if (toDelete) 
        entToDelete[0].insert(vt);
    }
  }
  
  if (P_getMaxInt(entToDelete[2].size())==0) // no face to delete
    return 0;
 
// STEP II: prepare for communication
  
  mEntity::RCIter rciter;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;
  
  for (int i=2; i>=0;--i)
  {
    for (set<mEntity*>::iterator eit=entToDelete[i].begin();
          eit!=entToDelete[i].end();++eit)
    {
      ent=*eit;
      // STEP III: send message to delete the copy of face to delete
      for (rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      {
        *msg_send = rciter->second;
        CM->send(rciter->first, (void*)msg_send);
        num_sent++;
      } // for RCIter
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    // delete remote copy
    int numRC = ent->getNumRemoteCopies();
    ent->deleteRemoteCopy(pid_from);
    assert(numRC==ent->getNumRemoteCopies()+1);
    // update PClassification
    set<int> bps;
    ent->getPidsExist(bps);
    pmEntity* pe = pmModel::Instance()->getPartitionEntity(bps);
    if (pe)
      assert(ent->getNumRemoteCopies()==pe->getNumBPs()-1);
    ent->setPClassification(pe);
    CM->free_msg(msg_recv);
  }

  // STEP IIV: delete face, edges, vertices
  for (int i=2;i>=0;--i)
  {
    for (set<mEntity*>::iterator eit=entToDelete[i].begin();
        eit!=entToDelete[i].end();++eit)
    {
      rmE[i].push_back(*eit);
      cb.deleteEntityData(*eit);
      switch(i) {
      case 2 :
        M_removeFace(mesh,(*eit)); 
	break;
      case 1 :
        M_removeEdge(mesh,(*eit));
	break;
      case 0 :
        M_removeVertex(mesh,(*eit)); 
        break;
      }
    }
  }

  int numDeleted=P_getSumInt(entToDelete[2].size());
  if (P_pid()==0)
     cout<<"      # faces deleted = "<<numDeleted<<endl;
  return numDeleted;
}

//*************************************************************
void unifyTaggedEntities(unsigned int attachTag, std::list<mEntity*> *LIST)
//*************************************************************
{
  // send phase begins
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;
  
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;

  list<mEntity*>::iterator lit=LIST->begin();
  mEntity* ent;
  for(; lit!=LIST->end();++lit)
  {
    ent=*lit;
    if (!ent->getPClassification())
      continue;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      *msg_send = rciter->second;
      CM->send(rciter->first, (void*)msg_send);
      num_sent++;
    } // for RCItet
  }  // for LIST
  CM->finalize_send();
  CM->free_msg(msg_send);  

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    if(!ent->getAttachedInt(attachTag))
    {
      ent->attachInt(attachTag,1);
      LIST->push_back(ent);
    }
    CM->free_msg(msg_recv);
  }
}


//*************************************************************
void unifyTaggedEntitiesWithValues(unsigned int attachTag, std::list<mEntity*> *LIST)
//*************************************************************
{
  // send phase begins
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  int msg_size = sizeof(mEntity*) + sizeof(int);
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);

  int num_sent = 0, num_recvd = 0;
  mEntity** s_ent;
  int *s_tag;

  list<mEntity*>::iterator lit=LIST->begin();
  mEntity* ent;
  int tag;
  for(; lit!=LIST->end();++lit)
  {
    ent=*lit;
    if (!ent->getPClassification())
      continue;
    if(!EN_getDataInt(ent,attachTag,&tag))
      continue;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      s_ent = (mEntity**)msg_send;
      *s_ent = rciter->second;
      s_tag = (int*)((char*)msg_send + sizeof(mEntity*));
      *s_tag = tag;
      CM->send(rciter->first, (void*)msg_send);
      num_sent++;
    } // for RCItet
  }  // for LIST
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    tag = *(int*)((char*)msg_recv + sizeof(mEntity*));
    if(!ent->getAttachedInt(attachTag))
    {
      ent->attachInt(attachTag, tag);
      LIST->push_back(ent);
    }
    CM->free_msg(msg_recv);
  }
}


//*************************************************************
void unifyTaggedEntitiesWithValuesDbl(unsigned int attachTag, std::list<mEntity*> *LIST)
//*************************************************************
{
  // send phase begins
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  int msg_size = sizeof(mEntity*) + sizeof(double);
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);

  int num_sent = 0, num_recvd = 0;
  mEntity** s_ent;
  double *s_tag;

  list<mEntity*>::iterator lit=LIST->begin();
  mEntity* ent;
  double tag;
  for(; lit!=LIST->end();++lit)
  {
    ent=*lit;
    if (!ent->getPClassification())
      continue;
    if(!EN_getDataDbl(ent,attachTag,&tag))
      continue;
    for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
    {
      s_ent = (mEntity**)msg_send;
      *s_ent = rciter->second;
      s_tag = (double*)((char*)msg_send + sizeof(mEntity*));
      *s_tag = tag;
      CM->send(rciter->first, (void*)msg_send);
      num_sent++;
    } // for RCItet
  }  // for LIST
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    tag = *(double*)((char*)msg_recv + sizeof(mEntity*));
    if(!ent->getAttachedDouble(attachTag))
    {
      ent->attachDouble(attachTag, tag);
      LIST->push_back(ent);
    }
    CM->free_msg(msg_recv);
  }
}


// every program should call this function before creating vertices 
// on CB and use getAttachedDataInt(FMDBtag) as an vertex id on CB 
//*************************************************************
void attachUniqueId(mPart* mesh, unsigned int FMDBtag)
//*************************************************************
{ 
  int numPtn = ParUtil::Instance()->size();
  if (numPtn==1) return;
  
  int mypid = ParUtil::Instance()->rank();
  
  int localMaxId, globalMaxId;
  int localMinId, globalMinId;

  localMinId =mesh->getIdGenerator().getMaxValue();
  globalMinId = localMinId;
  MPI_Allreduce(&localMinId,&globalMinId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMinId-numPtn+mypid+1);

  int msg_size = sizeof(mEntity*) + sizeof(int);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  void *msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;

  mEntity** s_ent;
  int *s_id;

  // count how many of mesh edges on VEC are owned by the actual processor
  mEntity* ent;
  mPart::iterall eit=mesh->beginall(1);
  for (;eit!=mesh->endall(1);++eit)
  {
    ent = *eit;
    if (ent->getPClassification() && 
        ent->getOwner()==ParUtil::Instance()->rank())
    {
      int id=mesh->getNewVertexId();
      ent->attachInt(FMDBtag, id);
      // iterate over remote copies
      for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
      { 
        // send phase begins to find the entity in the counterpart
	// and assign the same id		
        s_ent = (mEntity**)msg_send;
        *s_ent = rciter->second;
        s_id = (int*)((char*)msg_send + sizeof(mEntity*));
        *s_id = id;
        CM->send(rciter->first, (void*)msg_send);
        num_sent++;
      } // for RCIter
    } // if (Owner)
  }  // for eiter
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    s_ent = (mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
    (*s_ent)->attachInt(FMDBtag, *s_id);
    CM->free_msg(msg_recv);
  }

  // update maximumValue of mIdGenerator
  localMaxId =mesh->getIdGenerator().getMaxValue();
  globalMaxId = localMaxId;
  MPI_Allreduce(&localMaxId,&globalMaxId,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  mesh->pmSetNewVertexId(globalMaxId-numPtn+mypid+1);
} // end of computeVtIDonPB(..)

class idExchanger_replace : public pmDataExchanger
{
  pMeshDataId id;
  int m_size;

public :
  idExchanger_replace(pMeshDataId i): id(i), m_size(0) {}
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, int, int, mEntity *remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);
};

int idExchanger_replace::msg_size ()
{
  return m_size;
}

void idExchanger_replace::fill_buffer (mEntity *e, int src, int dest, mEntity *remoteEnt, void *&msg_send)
{
  pPList ents;
  void* tmp_ptr;
  if (!EN_getDataPtr(e, id, &tmp_ptr))
    throw 1;
  ents = (pPList) tmp_ptr;

  int enities_size = PList_size(ents);
  m_size = sizeof(pEntity) * (enities_size + 1);

  msg_send = ParUtil::Instance()->ComMan()->alloc_msg(m_size); 

  pEntity* entities = (pEntity*)msg_send;
  int icount = 0;
  entities[icount++] = remoteEnt;
  for(int i = 0; i < enities_size; i++) {
    entities[icount++] = (pEntity)PList_item(ents, i);
  }
}

void idExchanger_replace::receiveData (void *msg_recv, int pid_from)
{  
  pEntity* entities = (pEntity*)msg_recv;
  pEntity ent;

  int icount = 0;
  pEntity e = entities[icount++];
  pPList ents;
  void* tmp_ptr;
  if (!EN_getDataPtr(e, id, &tmp_ptr))
     throw 1;
  ents = (pPList) tmp_ptr;

  int enities_size = PList_size(ents);
  for(int i = 0; i < enities_size; i++)
  {
    ent = (pEntity)PList_item(ents, i);
    ent->addRemoteCopy(pid_from, entities[icount++]);
    ent->setPClassification(e->getPClassification());
  }
}

void update_CB_Links(list<pEntity> &ents_to_updt, pMeshDataId id)
{
  idExchanger_replace cb(id);
  genericDataExchanger(ents_to_updt.begin(), ents_to_updt.end(), cb);
}
#endif
