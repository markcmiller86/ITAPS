/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <string>
#include <map>

#include "pmModel.h"
#include "pmModelUtil.h"
#include "pmMigrateUtil.h"
#include "FMDB_cint.h"
#include "FMDB_OwnerManager.h"
#include "pmUtility.h"
#include "ParUtil.h"

using std::list;
using std::pair;
using std::vector;
using std::cout;
using std::string;
using std::endl;
using std::multimap; 

// ***********************************************************
void getSortedPids_poor_to_rich(mPart* mesh,vector<int>& poor_to_rich_pids)
// ***********************************************************
{
  int dim = ParUtil::Instance()->get_maxMeshDim();
  int numPE = ParUtil::Instance()->size();
  // one round communication to get #regions for all processors
  vector<pair<int,int> > numRg_pid;
  vector<pair<int,int> >::iterator vecIt;
  int* senddata = new int;
  int* recvdata = new int[numPE];

  *senddata = mesh->size(dim);
  MPI_Allgather(senddata, 1, MPI_INT, recvdata, 1, MPI_INT, ParUtil::Instance()->getComm());
  for (int i = 0; i < numPE; i++)
  {
    numRg_pid.push_back(pair<int,int> (recvdata[i], i));
  }  

  delete [] senddata;
  delete [] recvdata;

  std::sort(numRg_pid.begin(), numRg_pid.end());
  
  for (vecIt=numRg_pid.begin();vecIt!=numRg_pid.end();++vecIt)
  {
    poor_to_rich_pids.push_back((*vecIt).second);
  }
}


// ***********************************************************
void getSortedPids_poor_to_rich_comm(mPart* mesh, vector<int>& poor_to_rich_pids)
// ***********************************************************
{
  int dim = ParUtil::Instance()->get_maxMeshDim();
  int numPE = ParUtil::Instance()->size();
  // one round communication to get #regions for the neighboring parts
  vector<pair<int,int> > numRg_pid;
  vector<pair<int,int> >::iterator vecIt;

  numRg_pid.push_back(pair<int,int>(mesh->size(dim), ParUtil::Instance()->rank()));

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(int));
  int* msg_send = (int*)CM->alloc_msg(sizeof(int));

  int num_sent = 0, num_recvd = 0;

  *msg_send = mesh->size(dim);

  num_sent = CM->send_to_nbrs((void*)msg_send);

  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    numRg_pid.push_back(pair<int,int> (*(int*)msg_recv,pid_from));
    CM->free_msg(msg_recv);
  }

  std::sort(numRg_pid.begin(), numRg_pid.end());

  for (vecIt=numRg_pid.begin();vecIt!=numRg_pid.end();++vecIt)
  {
    poor_to_rich_pids.push_back((*vecIt).second);
  }
}


// ***********************************************************
void getSortedPids_poor_to_rich(vector<mPart*> meshes, list<int>& poor_to_rich_pids)
// ***********************************************************
{
  int dim = ParUtil::Instance()->get_maxMeshDim();
  int numPE = ParUtil::Instance()->size();
 
  int mypid = ParUtil::Instance()->rank(); 
	
  // one round communication to get #regions for all processors

  multimap<int, int> numRg_pid;                          // num of regions, global pids 
  multimap<int, int>::iterator mapIt; 
  pair<multimap<int, int>::iterator,multimap<int, int>::iterator> range; 

  // assume equal number of parts per process 
  int numpart = ParUtil::Instance()->getTgtNumParts(); 

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  CM->set_fixed_msg_size(0);

  int msg_size = meshes.size()*2*sizeof(int);
  int* msg_send = (int*)CM->alloc_msg(msg_size); 

  mPart* mesh;
  for(int ipart=0; ipart<(int)meshes.size(); ipart++) {
    mesh = meshes[ipart];
    msg_send[2*ipart]=mesh->size(dim);
    if((ParUtil::Instance()->localPids).size()==0)
    {
      numRg_pid.insert(pair<int,int>(mesh->size(dim), mypid*numpart+ipart));
      msg_send[2*ipart+1] = ipart;
    }
    else
    {
      numRg_pid.insert(pair<int,int>(mesh->size(dim), mypid*numpart+(ParUtil::Instance()->localPids)[ipart] ) );
      msg_send[2*ipart+1] = (ParUtil::Instance()->localPids)[ipart];
    }
  }

  int num_sent = CM->send_to_nbrs((void*)msg_send, msg_size);

  // receive phase begins
  CM->finalize_send();
  CM->free_msg(msg_send);

  void* msg_recv;
  int pid_from; 
  int num_recv=0; 
  int gid; 

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recv ++;
    int recvd_num_parts = rc / (2*(sizeof(int)));
    for (int ipart = 0; ipart < recvd_num_parts; ipart++)
    {
      gid = pid_from*numpart+((int*)msg_recv)[2*ipart+1]; 

      // sort the equal-key value in the multimap 
      range = numRg_pid.equal_range(((int*)msg_recv)[2*ipart]);
      for(mapIt=range.first; mapIt!=range.second; mapIt++)
       if( (*mapIt).second>=gid ) 
         break; 
      
       if(range.first==mapIt)
           numRg_pid.insert(mapIt, std::make_pair(((int*)msg_recv)[2*ipart], gid));
       else
           numRg_pid.insert(mapIt--, std::make_pair(((int*)msg_recv)[2*ipart], gid));
    }
     
      CM->free_msg(msg_recv);

   }  // if(rc)

  for (mapIt=numRg_pid.begin();mapIt!=numRg_pid.end();++mapIt)
  {
    poor_to_rich_pids.push_back((*mapIt).second);
  }
}


// it compares two patition ids based on the mesh size and returns 
//   1 if A > B
//   0 if A = B
//  -1 if A < B
int comparePid(mPart* mesh, int A, int B)
{
  vector<int> sortedPids;
  getSortedPids_poor_to_rich_comm(mesh,sortedPids);
  int indexA=0, indexB=0;
  
/// Find an index with stl routines: int index = (int)std::distance(sortedPids.begin(), iIt); where iIt is the iterator
  for (int i=0; i<sortedPids.size();++i)
  {
    if (sortedPids[i]==A) indexA=i;
    if (sortedPids[i]==B) indexB=i;
  }
  if (indexA>indexB) return 1;
  else if (indexA==indexB) return 0;
  else return -1;
}
#endif
