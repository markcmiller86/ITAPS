/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "ParUtil.h"
#ifdef FMDB_PARALLEL
#else
#ifndef MSC
#include <sys/time.h>
#endif
#endif

ParUtil* ParUtil::Instance()
{
  if(!instance.get())
    {
      instance.reset(new ParUtil);
      instance->setVertbosityLevel(0);
    }
  return instance.get();
}

ParUtil::~ParUtil() 
{}

ParUtil::ParUtil() 
{
#ifdef FMDB_PARALLEL
  initialized = 0;
  finalized = 0; 
#endif
}

void ParUtil::init(MPI_Comm communicator) 
{
#ifdef FMDB_PARALLEL
  if(initialized) 
    return;

  int init_flag=0;
  MPI_Initialized(&init_flag);
  if(!init_flag)
    MPI_Init(0,0);

  local_comm = communicator;
  MPI_Comm_rank(communicator, &myrank);
  MPI_Comm_size(communicator, &mysize);

  MPI_Comm_dup(communicator, &local_comm);
  MPI_Errhandler_set(communicator,MPI_ERRORS_RETURN);
  CM = new IPComMan(communicator, 0, 10240, IPComMan::Neighbors);
  vl = 1;
  resetBarrierSensor();
  initialized = 1;    
  
  curNumParts = 1;           // current_local_num_parts_per_process
  tgtNumParts = 1;           // target_local_num_parts_per_process
  usrNumParts = 1; 
#endif
}

double ParUtil::wTime() const
{

#ifdef FMDB_PARALLEL
  return MPI_Wtime(); 
#else
  struct timeval tp;
  struct timezone tzp;
  double timeval;
  
  gettimeofday(&tp,&tzp);
  
  timeval = (double) tp.tv_sec;
  timeval = timeval + (double) ((double) .000001 * (double) tp.tv_usec);
  
  return(timeval);
#endif
}

std::string ParUtil::processorName() const
{
#ifdef FMDB_PARALLEL
  return procName;
#else
  return std::string("localhost");
#endif
}

void ParUtil::Msg(ParUtil::MessageLevel level, char *fmt, ...)
{ 
  char buff[1024];
  va_list  args;
  va_start (args, fmt);
  vsprintf(buff, fmt, args);
  va_end (args);

  switch(level)
  {
    case INFO:
      if(vl >= 0 && master())
	  fprintf(stdout,"%s",buff);
      break;
    case WARNING:
      fprintf(stdout,"Proc %d FMDB WARNING : %s",rank(),buff);
      fflush(stdout);
      break;
    case ERROR:
      fprintf(stdout,"FMDB FATAL ERROR : %s",buff);
      fflush(stdout);
      break;
    default: break;
  }
}

void ParUtil::Barrier(int line, const char *fn)
{
#ifdef FMDB_PARALLEL
    double t1 = wTime();
    MPI_Barrier(MPI_COMM_WORLD);
    timeSpentOnBarriers += (wTime()-t1);
#endif
}

void ParUtil::Finalize(bool do_mpi_finalize)
{
#ifdef FMDB_PARALLEL
   if(initialized && !finalized) 
   {
     delete CM;
     if (do_mpi_finalize)
       MPI_Finalize();
     finalized = 1;
   }
#endif
}

std::auto_ptr<ParUtil> ParUtil::instance;
int ParUtil::buffer_size = 1024;


