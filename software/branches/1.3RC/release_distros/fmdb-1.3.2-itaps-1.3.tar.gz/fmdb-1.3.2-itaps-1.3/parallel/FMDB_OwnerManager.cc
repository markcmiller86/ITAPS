/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <map>
#include "FMDB_OwnerManager.h"
#include "mMigrateUtil.h"
#include "ParUtil.h"
#include "mEntity.h"
#include "mPart.h"
#include "pmModelUtil.h"

using std::vector;
using std::multimap;
using std::cout;
using std::endl;

FMDB_OwnerManager::FMDB_OwnerManager()
{
  allSharedInfos = new std::multimap <mEntity*,FMDB_SharedInfo>;
  theTopology = new std::multimap <int,int>;
}

FMDB_OwnerManager::~FMDB_OwnerManager()
{
  delete allSharedInfos;
  delete theTopology;
}

void FMDB_OwnerManager::clearRemoteCopies()
{
  allSharedInfos->clear();
}

void FMDB_OwnerManager::addRemoteCopy(mEntity* here, int from, 
                                      mEntity *there , bool per)
{
  allSharedInfos->insert(std::pair<mEntity* const,FMDB_SharedInfo>
                        (here,FMDB_SharedInfo(from,there,per)));
}

void FMDB_OwnerManager::deleteRemoteCopy(mEntity* ent)
{
  iter oit, oitend;
  oit=begin(ent);
  oitend=end(ent);
  allSharedInfos->erase(ent);
}

void FMDB_OwnerManager::addNeighbor(int here, int otherside)
{
  theTopology->insert(std::pair<int const,int>(here,otherside));
}

int FMDB_OwnerManager::count(mEntity*e)   
{
  return allSharedInfos->count(e);
}

int FMDB_OwnerManager::count(int i)   
{
  return theTopology->count(i);
}

FMDB_OwnerManager::iter FMDB_OwnerManager:: begin() 
{
  return allSharedInfos->begin();
}

FMDB_OwnerManager::iter FMDB_OwnerManager:: end() 
{
  return allSharedInfos->end();
}

FMDB_OwnerManager::iter_top FMDB_OwnerManager:: begin_top() 
{
  return theTopology->begin();
}

FMDB_OwnerManager::iter_top FMDB_OwnerManager:: end_top() 
{
  return theTopology->end();
}

FMDB_OwnerManager::iter FMDB_OwnerManager:: begin(mEntity*e) 
{
  return allSharedInfos->lower_bound(e);
}

FMDB_OwnerManager::iter FMDB_OwnerManager:: end(mEntity*e) 
{
  return allSharedInfos->upper_bound(e);
}

FMDB_OwnerManager::iter_top FMDB_OwnerManager:: begin_top(int thisside) 
{
  return theTopology->lower_bound(thisside);
}

FMDB_OwnerManager::iter_top FMDB_OwnerManager:: end_top(int thisside) 
{
  return theTopology->upper_bound(thisside);
}

bool FMDB_OwnerManager :: isPeriodic(mEntity *e)
{
  for(iter it = begin(e);it != end(e); ++it)
    if((*it).second.isPeriodic())return true;
  return false;
}

void FMDB_OwnerManager::print()
{
  std::vector<int> ids;
  getPartitionIds (ids);
 
  for(int i=0;i<ids.size();++i)
    {
      printf("Processor %d boundary %d comm (",ParUtil::Instance()->rank(),ids[i]);
      for(iter_top itx = begin_top(ids[i]); itx != end_top(ids[i]); ++itx)
	{	      
	  int to = (*itx).second;
	  printf("%d ",to);
	}
      printf(")\n");
    }
//  return;
  for(iter it = begin() ; it != end() ; ++it)
    {
      FMDB_SharedInfo si = (*it).second;
      printf("connect with P%d",si.pid()); 
      mEntity *e = (*it).first;
      e->print();
    }

}


void FMDB_OwnerManager::getPartitionIds ( std::vector<int> &ids )
{
  int id_old = 0;
  for(iter_top itx = begin_top(); itx != end_top(); ++itx)
    {	      
      int id = (*itx).first;
      if(id != id_old)ids.push_back(id);
      id_old = id;
    }
}

int FMDB_OwnerManager::find (int nbProcs , int *procs)
{

  std::vector<int> ids;
  std::sort(procs,procs+nbProcs);
  getPartitionIds(ids);
	
  // MUST ADD THIS PROCESSOR TO THE LIST

  for(int i=0;i<ids.size();++i)
    {
      if(nbProcs == count(ids[i])) // if size corresponds 
	{
	  bool found = true;
	  for(iter_top itx = begin_top(ids[i]); itx != end_top(ids[i]); ++itx)
	    {	      
	      int to = (*itx).second;
	      if(!std::binary_search(procs,procs+nbProcs,to))found = false;	      
	    }
	  if(found) return ids[i];
	}
    }
  return 0;
}

int FMDB_OwnerManager::create (int nbProcs , int *procs)
{
  int maxid = 0;
  for(iter_top itx = begin_top(); itx != end_top(); ++itx)
    {	      
      int id = (*itx).first;
      if(id > maxid)maxid = id;
    }
  for(int i=0;i<nbProcs;i++)
    {
      addNeighbor(maxid+1,procs[i]);
    }
  return maxid+1;
}


void FMDB_OwnerManager::setPoorPid_asOwner(mPart* mesh)
{
#ifdef FMDB_PARALLEL
  std::vector<int> ids;
  getPartitionIds (ids);
  
  mPart::cbiter cbIter= mesh->cbbegin();
  //mPart::cbiter cbIterend = mesh->cbend();
  mCommonBdry* cb;
  int cbId, owner;
  vector<int> allSortedPids;
  vector<int>::iterator pidIter;

  getSortedPids_poor_to_rich(mesh,allSortedPids);
  pidIter=allSortedPids.begin();

  if (ParUtil::Instance()->master())
  {  cout<<"POOR TO RICH PIDS: ";
    for (int counter=0; pidIter!=allSortedPids.end();++pidIter)
       cout<<"P"<<*pidIter<<" -> ";
    cout<<"\n";
  }
  
   
  for(int i=0;i<ids.size();++i)
  {
    vector<int> cbPids;
    cbPids.push_back(ParUtil::Instance()->rank());
    cb = *cbIter;
    cbId = ids[i];
    assert(cb->getId()==cbId);
    //mCommonBdry* cb = *cbIter;
//    cout<<"("<<ParUtil::Instance()->rank()<<") boundary "<<cbId<<" comm (";
    	
    for(iter_top itx = begin_top(ids[i]); itx != end_top(ids[i]); ++itx)
    {
  //    int to = (*itx).second;
      cbPids.push_back((*itx).second);
  //    printf("%d ",to);
    }
  //  cout<<")   ";
    pidIter = allSortedPids.begin();
    owner=-1;
    for (;pidIter!=allSortedPids.end();++pidIter)
    {
      if (std::find(cbPids.begin(),cbPids.end(),*pidIter)!=cbPids.end())
      {  
        owner=*pidIter;
        break;
      }
    }
//    cout<<"owner = "<<owner<<endl;
    assert(owner>=0 && owner <ParUtil::Instance()->size());
    cb->setOwner(owner);
    cbIter++;
  }
#endif
}
  
bool FMDB_OwnerManager::amITheOwnerOf (mEntity * e )
{
  if (e->getOwner()==ParUtil::Instance()->rank())
    return true;
  else
    return false;
}

