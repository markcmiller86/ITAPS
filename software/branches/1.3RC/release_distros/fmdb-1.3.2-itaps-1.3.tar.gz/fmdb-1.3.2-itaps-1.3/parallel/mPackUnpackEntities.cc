/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "mMigrateUtil.h"

#include "FMDB_OwnerManager.h"
#include "FMDB_LoadBalancer.h"
#include "mAttachableDataContainer.h"
#include "mPart.h"
#include "mEntity.h"
#include "mException.h"
#include "mEdge.h"
#include "mVertex.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "FMDB_Internals.h"
#include "FMDBInternals.h"
#include "oldFMDB.h"

#ifdef FMDB_PARALLEL
#include "mExchangeData.h"
#endif
#include "pmGraphs.h"
#include "mFMDB.h"

#ifndef SIM
#include "modeler.h"
#else
#include "SimModel.h"
#endif

#include <list>

using std::list;

#if 0
#ifdef FMDB_PARALLEL
/*
struct packedVertex
{
  int id;
  int clas;
  int clasdim;
  double pos[3];
};
*/
/*
  Here is, at last, a general strategy for
  recalssifying mesh entities on the mesh
  before load balancing. This will require one 
  round of communications.
  
  The idea is to attach a vector to all mesh entities
  that are on interprocessor boundaries. This vector
  will contain all partitions where the entity is 
  present.

  Then, we reclassify entities with respect to the 
  vector of integers. theOwnerManager::find is able
  to map this vector of integers to the connecting 
  entity.
*/


void * mPart::packMeshEntity (mEntity *e, int iproc, FMDB_LoadBalancerCallbacks &cb)
{
  char *buf;
  char *buf_user;
  int user_size;
  int entity_size;

  // User may have some data to send to the other process. These data are of size user_size
  buf_user = (char*)cb.getUserData(e, iproc,user_size);
  if(!buf_user)user_size = 0;

  if(e->getLevel() == 0)
    {            
      mVertex *v = (mVertex*)e;

      int nbDests = getNbDests(v);

      entity_size = sizeof(packedVertex) + (nbDests + 1) * sizeof(int);

      // TEST TEST TEST 
      buf=(char*)AP_alloc(iproc, TAGVERTEX,
			  entity_size + user_size);
      
      //      packedVertex *castbuf= ( packedVertex*)buf;
      packedVertex castbuf; 
      castbuf.id = v->getId();
      //      if(castbuf.id == 45) ParUtil::Instance()->Msg(ParUtil::WARNING,"vertex %d send\n",castbuf.id );
      castbuf.clas = GEN_tag(v->getClassification());
      castbuf.clasdim = GEN_type(v->getClassification());
      SCOREC::Util::mPoint p (v->point());
      for(int i=0;i<3;i++)castbuf.pos[i] = p(i);
      memcpy(buf,&castbuf,sizeof(packedVertex));
      /// put then destinations ...
      int *dests = (int*)malloc((nbDests + 1) * sizeof(int));
      dests[0] = nbDests;
      for(int i=0;i<dests[0];i++)
	{
	  dests[i+1] = getDest(v,i);
	}
      memcpy(&buf[sizeof(packedVertex)],dests,(nbDests + 1) * sizeof(int));
      free (dests);
    }
  else
    {
      /*
	we pack a mesh entity like that
	-) the type (quad,tri,hex,...)
	-) the classification id
	-) the classification dimension
	-) the refinement level
	-) vertices of the entity
	-) vertices of the parent
	-) vertices of the parent of the parent
	-) ...
	-) if classification id < 0, numbre of processors
	-) procs
      */
      int d = getRefinementLevel(e);      
      
      //      int d = 0;
      
      // hypothesis !!! all parents have same number of vertices
      // k is the number of integers needed for packing the entity
      int k  = 1 + 1 + 1 + 1 + (d+1)*e->size(0);
      int k2 =getNbDests(e)+1;      
      entity_size = (k+k2)*sizeof(int);
      int *castbuf = (int*)malloc(entity_size);
      buf=(char*) AP_alloc(iproc, TAGNONVERTEX, entity_size + user_size);
      
      castbuf[0] = e->getType();
      castbuf[1] = GEN_tag(e->getClassification());
      castbuf[2] = GEN_type(e->getClassification());
      castbuf[3] = d+1;

      int j = 0;
      packVertices (e, &castbuf[4], j);
      castbuf[k] = getNbDests(e);
      for(int i=0;i<k2-1;i++)
	{
	  castbuf[k+i+1] = getDest(e,i);
	}
      
      memcpy(buf,castbuf,entity_size);
      free(castbuf);
    }

  if(user_size)
    {
      memcpy (&buf[entity_size],buf_user,user_size);
      cb.deleteUserData(buf_user);
    }
  
  return buf;
  
}

void mPart::unpackMeshEntity (void *vbuf, int iproc, int itag, FMDB_LoadBalancerCallbacks &cb)
{
  char *buf = (char*)vbuf;
  int entity_size;
  mEntity *theLeaf;

  if(itag == TAGVERTEX)
    {
      packedVertex castbuf;
      entity_size = sizeof(packedVertex); 
      memcpy(&castbuf,buf,entity_size);
      mEntity *ver = getVertex(castbuf.id);
      if(!ver)
	{	  	  
	  theLeaf = createVertex_noUpdateId(castbuf.id,castbuf.pos[0],castbuf.pos[1],castbuf.pos[2],
		       getGEntity(castbuf.clas,castbuf.clasdim));		       
	}      
      else theLeaf = ver;
      int *procs = (int*) &buf[sizeof(packedVertex)];
      mCommonBdry *g = getInterprocessorCommonBdry(procs[0],&procs[1],0);
      theLeaf->setCommonBdry(g);
      entity_size += (procs[0] + 1) * sizeof(int);
    }
  else if(itag == TAGNONVERTEX)
    {
      int *castbuf= (int*)buf;
      mEntity *theMeshEntity, *child = 0;
      pGEntity g = 0;
      mCommonBdry *pg = 0;
      int nbv;
      switch(castbuf[0])
	{
	case mEntity::EDGE : nbv = 2; break;
	case mEntity::TRI : nbv = 3; break;
	case mEntity::QUAD : nbv = 4; break;
	case mEntity::TET : nbv = 4; break;
	case mEntity::HEX : nbv = 8; break;
	default :
	  throw new mException(__LINE__,__FILE__,
			       "unpacking not done for this type of mesh entity"); 
	  break;	      
	}
      
      g = getGEntity(castbuf[1],castbuf[2]);
      int *procs = &castbuf[4 + nbv * castbuf[3]];	
      entity_size = (4 + nbv * castbuf[3] + procs[0] + 1)*sizeof(int);
  
      for(int i=0;i<castbuf[3];i++)
	{
	  switch(castbuf[0])
	    {
	    case mEntity::EDGE :
	      {
		mVertex *v1 = getVertex(castbuf[4+2*i]);
		mVertex *v2 = getVertex(castbuf[5+2*i]);
		theMeshEntity = (mEntity*)getEdge(v1,v2);
		if(!theMeshEntity)
		  theMeshEntity = (mEntity*)createEdge(v1,v2,g);
		  mEntity* e = theMeshEntity;
	      }
	    break;		
	    case mEntity::TRI :
	      {
		mVertex *v1 = getVertex(castbuf[4+3*i]);
		mVertex *v2 = getVertex(castbuf[5+3*i]);
		mVertex *v3 = getVertex(castbuf[6+3*i]);
		theMeshEntity = (mEntity*)getTri(v1,v2,v3);
		if(!theMeshEntity)		
		  theMeshEntity = (mEntity*)createFaceWithVertices(v1,v2,v3,g);
	      }
	    break;
	    case mEntity::QUAD :
	      {
		/*
		  printf("proc %d (%d) recieving form %d (%d %d %d %d)\n",
		  ParUtil::Instance()->rank(),i,iproc,castbuf[4+4*i],castbuf[5+4*i],
		  castbuf[6+2*i],castbuf[7+4*i]);		*/
		mVertex *v1 = getVertex(castbuf[4+4*i]);
		mVertex *v2 = getVertex(castbuf[5+4*i]);
		mVertex *v3 = getVertex(castbuf[6+4*i]);
		mVertex *v4 = getVertex(castbuf[7+4*i]);
		theMeshEntity = (mEntity*)getQuad(v1,v2,v3,v4);
		if(!theMeshEntity)		
		  theMeshEntity =  (mEntity*)createFaceWithVertices(v1,v2,v3,v4,g);
	      }
	    break;
	    case mEntity::TET :
	      {
		mVertex *v1 = getVertex(castbuf[4+4*i]);
		mVertex *v2 = getVertex(castbuf[5+4*i]);
		mVertex *v3 = getVertex(castbuf[6+4*i]);
		mVertex *v4 = getVertex(castbuf[7+4*i]);
		theMeshEntity = (mEntity*)getTet(v1,v2,v3,v4);
		if(!theMeshEntity)		
		  theMeshEntity = (mEntity*)createTetWithVertices(
								  castbuf[4+4*i],
								  castbuf[5+4*i],
								  castbuf[6+4*i],
								  castbuf[7+4*i],g);
	      }
	    break;
	    case mEntity::HEX :
	      {
		mVertex *v1 = getVertex(castbuf[4+8*i]);
		mVertex *v2 = getVertex(castbuf[5+8*i]);
		mVertex *v3 = getVertex(castbuf[6+8*i]);
		mVertex *v4 = getVertex(castbuf[7+8*i]);
		mVertex *v5 = getVertex(castbuf[8+8*i]);
		mVertex *v6 = getVertex(castbuf[9+8*i]);
		mVertex *v7 = getVertex(castbuf[10+8*i]);
		mVertex *v8 = getVertex(castbuf[11+8*i]);
		theMeshEntity = (mEntity*)getHex(v1,v2,v3,v4,v5,v6,v7,v8);
		if(!theMeshEntity)		
		  theMeshEntity = (mEntity*)createHexWithVertices(
								  castbuf[4+8*i],
								  castbuf[5+8*i],
								  castbuf[6+8*i],
								  castbuf[7+8*i],
								  castbuf[8+8*i],
								  castbuf[9+8*i],
								  castbuf[10+8*i],
								  castbuf[11+8*i],g);
	      }
	    break;
	    default :
	      throw new mException(__LINE__,__FILE__,
				   "unpacking not done for this type of mesh entity"); 
	      break;
	    }
	  
	  pg = getInterprocessorCommonBdry(procs[0],&procs[1],theMeshEntity->getLevel());      
	  theMeshEntity->setCommonBdry(pg);
	  
	  // this is the leaf, datas can only be attached to leaves
	  if(i == 0)
	    {
	      theLeaf = theMeshEntity;
	    }
	  
	  if(child)
	    {
	      if(!theMeshEntity->find(child))
		theMeshEntity->add(child);
	      child->setParent(theMeshEntity);
	    }
	  child = theMeshEntity;
	}
    }
  cb.recieveUserData(theLeaf,iproc,itag,&buf[entity_size]);    
  // now that entities are created, we can send user data
}


void mPart::unpackMeshEntity_oneLevel(void *vbuf, int iproc, int itag,
                       FMDB_LoadBalancerCallbacks &cb,
                       int dim, std::vector<mEntity*> &newE)
{
  char *buf = (char*)vbuf;
  int entity_size;
  mEntity *theLeaf;
 
  if(itag == TAGVERTEX)
    {
      packedVertex castbuf;
      entity_size = sizeof(packedVertex);
      memcpy(&castbuf,buf,entity_size);
      mEntity *ver = getVertex(castbuf.id);
      if(!ver)
        {
          theLeaf = createVertex_noUpdateId(castbuf.id,castbuf.pos[0],castbuf.pos[1],castbuf.pos[2],
                         getGEntity(castbuf.clas,castbuf.clasdim));
          // theLeaf = create(this, castbuf.pos[0], castbuf.pos[1], castbuf.pos[2], 0,
	//	   castbuf.id, getGEntity(castbuf.clas,castbuf.clasdim));
          if (dim==0)
           newE.push_back(theLeaf);
        }
      else theLeaf = ver;
      int *procs = (int*) &buf[sizeof(packedVertex)];
      mCommonBdry *g = getInterprocessorCommonBdry(procs[0],&procs[1],0);
      theLeaf->setCommonBdry(g);
      entity_size += (procs[0] + 1) * sizeof(int);
    }
  else if(itag == TAGNONVERTEX)
    {
      int *castbuf= (int*)buf;
      mEntity *theMeshEntity, *child = 0;
      pGEntity g = 0;
      mCommonBdry *pg = 0;
      int nbv;
      switch(castbuf[0])
        {
        case mEntity::EDGE : nbv = 2; break;
        case mEntity::TRI : nbv = 3; break;
        case mEntity::TET : nbv = 4; break;
        default :
          throw new mException(__LINE__,__FILE__,
                               "unpacking not done for this type of mesh entity");
          break;
        }
      g = getGEntity(castbuf[1],castbuf[2]);
      int *procs = &castbuf[4 + nbv * castbuf[3]];
      entity_size = (4 + nbv * castbuf[3] + procs[0] + 1)*sizeof(int);
 
      for(int i=0;i<castbuf[3];i++)
        {
          switch(castbuf[0])
            {
            case mEntity::EDGE :
              {
                mVertex *v1 = getVertex(castbuf[4+2*i]);
                mVertex *v2 = getVertex(castbuf[5+2*i]);
                //assert(v1&&v2);
                //theMeshEntity = (mEntity*)getEdge(v1,v2);
                theMeshEntity = (mEntity*)E_exist(v1,v2);
                
                if(!theMeshEntity)
                {
                  //theMeshEntity = (mEntity*)createEdge_oneLevel(v1,v2,g);
		  theMeshEntity = M_createE(this, v1, v2, g);
                  if (dim==1)
                     newE.push_back(theMeshEntity);
                }
              }
            break;
            case mEntity::TRI :
              {
                mVertex *v1 = getVertex(castbuf[4+3*i]); // edge 1
                mVertex *v2 = getVertex(castbuf[5+3*i]);
                mVertex *v3 = getVertex(castbuf[6+3*i]); // edge 2
                
                //assert(v1&&v2&&v3);
               // theMeshEntity = (mEntity*)getTri(v1,v2,v3);
                  theMeshEntity = (mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,(mEntity*)0);

                if(!theMeshEntity)
                {
                  mEntity* edges[3];
        //          cout<<"("<<M_Pid()<<") call E_exist\n";
		  edges[0]=(mEntity*)E_exist(v1,v2);
          //        cout<<"\t("<<M_Pid()<<") edges[0]="<<edges[0]->getUid()<<endl;
                  edges[1]=(mEntity*)E_exist(v2,v3);
            //      cout<<"\t("<<M_Pid()<<") edges[1]="<<edges[1]->getUid()<<endl; 
                  edges[2]=(mEntity*)E_exist(v1,v3);
              //    cout<<"\t("<<M_Pid()<<") edges[2]="<<edges[2]->getUid()<<endl;
	//	  assert(edges[0]&&edges[1]&&edges[2]);
                  theMeshEntity = M_createF(this, 3, edges, 0, g);
             //     cout<<"("<<M_Pid()<<") CREATE"<<theMeshEntity->getUid()<<endl;
		  if (dim==2)
                    newE.push_back(theMeshEntity);
                }
              }
            break;
            case mEntity::QUAD :
              {
                  throw new mException(__LINE__,__FILE__,
                                   "unpacking_oneLevel not done for this type of mesh entity");
              }
            break;
            case mEntity::TET :
              {
               mVertex* v1=getVertex(castbuf[4+4*i]);
               mVertex* v2=getVertex(castbuf[5+4*i]);
               mVertex* v3=getVertex(castbuf[6+4*i]);
               mVertex* v4=getVertex(castbuf[7+4*i]);
               //theMeshEntity=(mEntity*)getTet(v1,v2,v3,v4);
               //if (!theMeshEntity)
               {
		 mEntity* faces[4];
		 faces[0]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v3,(mEntity*)0);
                // cout<<"\t("<<M_Pid()<<") faces[0]="<<faces[0]->getUid()<<endl;
                 faces[1]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v2,(mEntity*)v4,(mEntity*)0);
                // cout<<"\t("<<M_Pid()<<") faces[1]="<<faces[1]->getUid()<<endl;
                 faces[2]=(mEntity*)F_exist(0,(mEntity*)v2,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
                // cout<<"\t("<<M_Pid()<<") faces[2]="<<faces[2]->getUid()<<endl;
                 faces[3]=(mEntity*)F_exist(0,(mEntity*)v1,(mEntity*)v3,(mEntity*)v4,(mEntity*)0);
                // cout<<"\t("<<M_Pid()<<") faces[3]="<<faces[3]->getUid()<<endl;
		 
                 theMeshEntity=(mEntity*)M_createR(this, 4, faces, 0, g);
                //                  cout<<"("<<M_Pid()<<") CREATE"<<theMeshEntity->getUid()<<endl;
               }
              }
            break;
            default :
              throw new mException(__LINE__,__FILE__,
                                   "unpacking_oneLevel not done for this type of mesh entity");
              break;
            }
 
          pg = getInterprocessorCommonBdry(procs[0],&procs[1],theMeshEntity->getLevel());
          theMeshEntity->setCommonBdry(pg);
 
          // this is the leaf, datas can only be attached to leaves
          if(i == 0)
            {
              theLeaf = theMeshEntity;
            }
 
          if(child)
            {
              if(!theMeshEntity->find(child))
                theMeshEntity->add(child);
              child->setParent(theMeshEntity);
            }
          child = theMeshEntity;
        }
    }
  cb.recieveUserData(theLeaf,iproc,itag,&buf[entity_size]);
  // now that entities are created, we can send user data
}
#endif
#endif

