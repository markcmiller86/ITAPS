/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifdef FMDB_PARALLEL
#include <iostream>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include "pmZoltanCallbacks.h"
#include "mEntity.h"

#include "mAttachableDataContainer.h"
#include "pmDataExchanger.h"   
#include "mFMDB.h"
#include "pmUtility.h" 
#include <list>
#include <assert.h>
#include <map>
#include <set>
#include "FMDB_cint.h"   
#include "FMDB_Internals.h"

using std::vector;
using std::find;
using std::cout; 
using std::endl; 
using std::list; 

#define MAX_NUM_PARTS_PER_PROCESS 1000 

pmZoltanCallbacks::pmZoltanCallbacks(Algorithm algo)
  : theAlgorithm(algo),
    parAlgorithm(pmZoltanCallbacks::PartKway)
{
  localNumParts=1; 
}

void pmZoltanCallbacks::setAlgorithm(const Algorithm &algo)
{
  theAlgorithm = algo;
}

void pmZoltanCallbacks::setParAlgorithm (const ParAlgorithm &algo)
{
  parAlgorithm = algo;  
}

#ifdef _HAVE_ZOLTAN_
#include "ParUtil.h"
#include "zoltan.h"

// return TRUE if the attached user data to entity should be removed 
// on this processor after migration, otherwise, return FALSE
bool deleteUserData(mEntity* ent,int pid)
{
  mEntity::BPIter bpiter=ent->bpBegin();
  bool startFlag=false;
  for (;bpiter!=ent->bpEnd();++bpiter)
  {
    if (*bpiter==pid)
    {
      startFlag=true;
      continue;
    }
    if (startFlag)
    {
      vector<int> pidsExist;
      ent->getPidsExist(pidsExist);
      if (find(pidsExist.begin(), pidsExist.end(), *bpiter)==pidsExist.end()) // find another pid to send this entity
        return false;
    }
  }
  if (!ent->findPidInBPs(ParUtil::Instance()->rank()))
    return true;
  return false;
}


class idExchanger2 : public pmDataExchanger
{
  int dim; 
  
public :
  idExchanger2(int d): dim(d) {}
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, int, int, mEntity* remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);  
};

  int idExchanger2::msg_size()
  {
    return 2*sizeof(void*);
  }
  
  void idExchanger2:: fill_buffer (mEntity *e, int src, int dest, mEntity* remoteEnt, void *&msg_send)
  {
    if(!e->isAdjacencyCreated(dim))
      {
	ParUtil::Instance()->Msg(ParUtil::WARNING,"   KATASTROFF \n");
	throw;
      }
    
    void** s_ent = (void**)msg_send;  
    mEntity* ent = e->get(dim, 0);    // assume one part boundary entity is adjacent to only one partition object     

    unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");
    void* tmp; 
    if(EN_getDataPtr(ent, egTag, &tmp))
      s_ent[0] = tmp;            // entity group  
    else
      s_ent[0] = (void*)ent;     // entity 
    s_ent[1] = (void*)remoteEnt; 
  }
  
  void idExchanger2::receiveData (void *msg_recv, int pid_from)
  {
    void** s_ent = (void**)msg_recv;
    int_mEnt_struct* attbuf= new int_mEnt_struct; 
    attbuf->i=pid_from;                       // process rank 
    attbuf->entity = (mEntity*)(s_ent[0]);       // partition object
    
    mEntity* ent = (mEntity*)s_ent[1]; 
    // attach a pointer to the entity 
    unsigned int tagId= MD_lookupMeshDataId("SetEntOnCB"); 
    EN_attachDataPtr(ent, tagId, (void*)attbuf); 
  }
#ifdef MATCHING
   void exchangeMatchEnts(map<mEntity*, int> entMatch, int dim) 
   {   	 
      unsigned int matchId = MD_lookupMeshDataId("MatchEntity"); 
      int mypid = ParUtil::Instance()->rank();       
      int numParts = ParUtil::Instance()->getCurNumParts();

      IPComMan *CM = ParUtil::Instance()->ComMan();
      CM->set_comm_validation(IPComMan::All_Reduce);
      
      int msg_size = 2*sizeof(mEntity*);
      CM->set_tag(0);
      CM->set_fixed_msg_size(msg_size);
      mEntity** msg_send = (mEntity**)CM->alloc_msg(msg_size);
      int num_sent = 0, num_recvd = 0;	      

      multimap<int, mEntity*>* reg_map; 
      map<mEntity*,int>::iterator mapit; 
      mEntity* ent; 
      for(mapit=entMatch.begin(); mapit!=entMatch.end(); mapit++) {
	 ent = mapit->first; 
	 reg_map = new multimap<int, mEntity*>; 
	 EN_attachDataPtr(ent, matchId, reg_map);
	 mEntity* adj = ent->get(dim, 0);                    // adjacent po 

	 for(mEntity::MEIter miter = ent->meBegin(); miter!=ent->meEnd(); miter++) 
	    if ((miter->first)/numParts == mypid ) {              // on-part matched entity
	       mEntity* ment = miter->second;  
	       mEntity* madj = ment->get(dim, 0);
	       (*reg_map).insert(pair<int, mEntity*>(mypid, madj) );                        // adjacent po         
	    }
	    else{						  // off-part matched entity
	       msg_send[0] = adj; 
	       msg_send[1] = miter->second; 
	       CM->send((miter->first)/numParts, (void*)msg_send);
	       num_sent ++; 
	    }
      }      
      CM->finalize_send();
      CM->free_msg(msg_send);
      
      // receive phase begins
      void *msg_recv;
      int pid_from;
      while(int rc = CM->receive(msg_recv, &pid_from))
      {
	 num_recvd++;
	 mEntity** s_ent = (mEntity**)msg_recv;

	 void* tmp; 
	 if(!EN_getDataPtr(s_ent[1], matchId, &tmp)){
	     ParUtil::Instance()->Msg(ParUtil::WARNING,"   SEND MSG TO NON_MATCH ENTITY. \n");
	     throw;
	 }
	 
	 // make sure the uniqueness in the multimap 
	 int flag=0; 
	 reg_map = (multimap<int, mEntity*>* )tmp; 
	 multimap<int,mEntity*>::iterator mapiter = reg_map->find(pid_from);
	 if(mapiter!=reg_map->end()) 
	    for(unsigned int j=0; j<reg_map->count(pid_from); j++)
	       if(mapiter->second==s_ent[0]) {
		  flag = 1; 
		  break; 
	       }
	    if(flag==0)
	       (*reg_map).insert(pair<int, mEntity*>(pid_from, s_ent[0]) );
		 
	 CM->free_msg(msg_recv);
      }
					    
   }
#endif
  
// attach adjacent partition objects to part boundary entities
  void setEntOnCB(std::vector<mPart*>& meshes, int dim)        
  {
    map<mEntity*,int> entOnCB;           // entptr+local_pid
    
    // create a new tag 
    unsigned int tagId= MD_lookupMeshDataId("SetEntOnCB"); 
    int numParts = ParUtil::Instance()->getCurNumParts(); 

#ifdef MATCHING
    map<mEntity*, int> entMatch; 
#endif
    
    mPart* mesh; 
    for(int iPart=0; iPart<(int)meshes.size(); iPart++) {
      mesh = meshes[iPart]; 
      for (mPart::iterall it=mesh->beginall(dim-1); it!=mesh->endall(dim-1);++it) {
	if ((*it)->getPClassification())
	  if((ParUtil::Instance()->localPids).size()>0)
	    entOnCB[*it]=(ParUtil::Instance()->localPids)[iPart]; 
	  else
	     entOnCB[*it]=iPart;

#ifdef MATCHING
       if((*it)->hasMatchEnt()) {
	  if((ParUtil::Instance()->localPids).size()>0)
            entMatch[*it]=(ParUtil::Instance()->localPids)[iPart];
          else
            entMatch[*it]=iPart;     
	  }
#endif        
      }
    }
      
    idExchanger2 myCallback(dim);
    myCallback.numPart = numParts; 
    genericDataExchanger2(entOnCB.begin(), entOnCB.end(), myCallback); 

#ifdef MATCHING
    exchangeMatchEnts(entMatch, dim); 
#endif

  }

  
  void deleteEntOnCB(std::vector<mPart*>& meshes,int dim)
  {
    unsigned int tagId= MD_lookupMeshDataId("SetEntOnCB");

    mEntity* ent; 
    mPart* mesh; 

    for(int i=0; i< (int)meshes.size(); i++) {
      mesh = meshes[i]; 
      for (mPart::iterall it=mesh->beginall(dim-1); it!=mesh->endall(dim-1);++it)
	if ((*it)->getPClassification()){
	
	ent = *it; 
	void* tmp_ptr;
	if (!EN_getDataPtr(ent, tagId, &tmp_ptr))
	  throw 1;
	
	// delete the attached pointer
	EN_deleteData(ent, tagId);
	
	// delete the pointer
        delete (int_mEnt_struct*)tmp_ptr;
	}
    }

    // delete the tag 
    MD_deleteMeshDataId(tagId);

#ifdef MATCHING
   unsigned int matchId = MD_lookupMeshDataId("MatchEntity"); 
   MD_deleteMeshDataId(matchId);
#endif
  }
  


  typedef struct POofMeshes{            // data structure passed to Zoltan 

    vector<mPart*>* meshes;            
    int dim;                // mesh dimension
    int ptrsize;            // pointer size

  } POofMeshes;  
  
/*
    Get the number of the part objects (assume entities of highest order) on the process.
*/
  int get_num_POs(void *data, int *ierr) { 
  
    *ierr = ZOLTAN_OK; /* set error code */ 

    /* Take data structure given by Zoltan, use to access the mesh */
    if (data == NULL) {
      *ierr = ZOLTAN_FATAL;
      return 0;
    }

    POofMeshes* poMesh = (POofMeshes*)data;  
    std::vector<mPart*>* meshes = poMesh->meshes; 
    int dim = poMesh->dim; 
    int numPo=0;
 
    int size = (int) (*meshes).size();

    for(int i=0; i<size; i++) 
      numPo += ((*meshes)[i])->numEntGrp(); 

    if(numPo==0) {

      if(dim == 2) {
	 for(int i=0; i<size; i++) {
	    int num = M_numFaces( (*meshes)[i] );
	    numPo += num;
	 }
      } 
      else {
	 for(int i=0; i<size; i++) {
	    int num = M_numRegions( (*meshes)[i] );
	    numPo += num;
	 }
      }
      
    }
    else {
    
       pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag");
       pEntity ent;  
       for(int i=0; i<size; i++) {
         mPart* mesh = (*meshes)[i]; 
         for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) { 
            ent=*it; 
	    void* tmp;  
	    if(!EN_getDataPtr(ent, egTag, &tmp))   
	          numPo++; 
	 }
       }
    }

    return numPo;
  }
  
/*
    Get a list of local_ids and global_ids for each of the part objects.
*/
  void get_PO_list(void *data, int num_gid_entries, int num_lid_entries,
		   ZOLTAN_ID_PTR global_ids, ZOLTAN_ID_PTR local_ids,
		   int wgt_dim, float *obj_wgts, int *ierr) {


    /* Take data structure given by Zoltan, use to access the mesh */
    if (data == NULL) {
      *ierr = ZOLTAN_FATAL;
    }
    *ierr = ZOLTAN_OK; 

    POofMeshes* poMesh = (POofMeshes*)data; 
    std::vector<mPart*>* meshes = poMesh->meshes; 
    int dim = poMesh->dim; 
    int ptrsize = poMesh->ptrsize; 
    
    int count=0; 
    double poWeight; 
    wgt_dim=1; 
    mEntity* ent; 
    mPart* mesh;
    int size = (int) (*meshes).size();

    int numEntGrp = 0; 
    for(int ipart=0; ipart<size; ipart++)
      numEntGrp += ((*meshes)[ipart])->numEntGrp(); 

   if(numEntGrp==0) {

    for(int iPart=0; iPart<size; iPart++) {

      mesh = (*meshes)[iPart];

      for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {

        ent = *it;
        memcpy(&global_ids[count*num_gid_entries],&ent, ptrsize);

        if(ptrsize==4){  // 32bit code
          global_ids[count*num_gid_entries+1]= ParUtil::Instance()->rank();
        }
        else {                // 64bit code
          global_ids[count*num_gid_entries+2]= ParUtil::Instance()->rank();
        }

       int tmpLid=iPart; 
       if((ParUtil::Instance()->localPids).size()>0)
	 tmpLid = (ParUtil::Instance()->localPids)[iPart];
        memcpy(&local_ids[count*num_lid_entries], &tmpLid, sizeof(int));

        if(EN_getWeight((ent), &poWeight))
          obj_wgts[count*wgt_dim]=poWeight;
        else
          obj_wgts[count*wgt_dim]=1;

        count++;

      }
    }
    return;  

  } 

  count=0;  
  pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag"); 

  for(int iPart=0; iPart<size; iPart++) {

    mesh = (*meshes)[iPart];
    mEntityGroup* entGrp;

    for(mPart::iterEntGrp it=mesh->beginEntGrp(); it!=mesh->endEntGrp(); ++it) {
      entGrp = *it;

      // global part id of partition object equals entity pointer plus process rank
      memcpy(&global_ids[count*num_gid_entries],&entGrp, ptrsize);

      if(ptrsize==4)  // 32bit code
        global_ids[count*num_gid_entries+1]= ParUtil::Instance()->rank();
      else {                // 64bit code
        global_ids[count*num_gid_entries+2]= ParUtil::Instance()->rank();
      }

     int tmpLid=iPart;
     if((ParUtil::Instance()->localPids).size()>0)
       tmpLid = (ParUtil::Instance()->localPids)[iPart];
     memcpy(&local_ids[count*num_lid_entries], &tmpLid, sizeof(int));				 

     obj_wgts[count*wgt_dim]= entGrp->numEntity();

     count++;
   }


   for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {

      ent = *it;
      
      void* tmp; 
      if(!EN_getDataPtr(ent, egTag, &tmp)) {
         memcpy(&global_ids[count*num_gid_entries],&ent, ptrsize);

         if(ptrsize==4){  // 32bit code
	   global_ids[count*num_gid_entries+1]= ParUtil::Instance()->rank();
	 }	 
	 else {                // 64bit code
	   global_ids[count*num_gid_entries+2]= ParUtil::Instance()->rank();
	 }

	 int tmpLid=iPart;
	 if((ParUtil::Instance()->localPids).size()>0)
	    tmpLid = (ParUtil::Instance()->localPids)[iPart];
	    
	 memcpy(&local_ids[count*num_lid_entries], &tmpLid, sizeof(int));

	 if(EN_getWeight((ent), &poWeight))
	    obj_wgts[count*wgt_dim]=poWeight;
	 else
	    obj_wgts[count*wgt_dim]=1;
 	 count++;
     }
    }
  }
    
   *ierr = ZOLTAN_OK;
 }
  

/*
  Get a list of global part ids for each part object. 
*/

void  get_part_multi (  void *data,
			int num_gid_entries,
			int num_lid_entries,
			int num_obj,
			ZOLTAN_ID_PTR global_id,
			ZOLTAN_ID_PTR local_id,
			int *parts,
			int *ierr )
{
  
  if (data == NULL) {
    *ierr = ZOLTAN_FATAL;
  }
  *ierr = ZOLTAN_OK; 

  POofMeshes* poMesh = (POofMeshes*)data; 
  std::vector<mPart*>* meshes = poMesh->meshes; 
  int dim = poMesh->dim; 
  //  int ptrsize = poMesh->ptrsize; 
  
  int mypid = ParUtil::Instance()->rank(); 
  int numParts = ParUtil::Instance()->getCurNumParts();
 
  int count=0; 
  mPart* mesh;
  int size = (int) (*meshes).size();

  pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag"); 

  for(int iPart=0; iPart<size; iPart++) {
    
    mesh = (*meshes)[iPart];
    int tmpLid=iPart; 
    if((ParUtil::Instance()->localPids).size()>0)
       tmpLid = (ParUtil::Instance()->localPids)[iPart];

    for(mPart::iterEntGrp it=mesh->beginEntGrp(); it!=mesh->endEntGrp(); ++it) { 
      parts[count]=mypid*numParts+tmpLid;
      count++;
    }

    for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {
      mEntity* ent=*it; 

      void* tmp; 
      if(!EN_getDataPtr(ent, egTag, &tmp)) {
	 parts[count]=mypid*numParts+tmpLid;                       // global part id 
	 count++;
      }
    }
  }

  *ierr = ZOLTAN_OK;
  
}

/*
  Get a list of number of edges connected to each part object. 
*/
  void get_num_edges_multi(void* data, int num_gid_entries,           
			   int num_lid_entries,int num_obj, ZOLTAN_ID_PTR global_ids, 
			   ZOLTAN_ID_PTR local_ids, int* num_edges, int* ierr)
  {
    
    if(data == NULL)
      {
	*ierr = ZOLTAN_FATAL; 
      }

    POofMeshes* poMesh = (POofMeshes*)data; 
    vector<mPart*>* meshes = poMesh->meshes; 
    int dim = poMesh->dim;  

    unsigned int tagId= MD_lookupMeshDataId("SetEntOnCB");  
#ifdef MATCHING
    unsigned int matchId = MD_lookupMeshDataId("MatchEntity");
#endif
    
    int k=0;
    
    int size = (*meshes).size(); 
    mPart* mesh; 
    int numEntGrp=0; 
    
    for(int iPart=0; iPart<size; iPart++) {
      mesh = (*meshes)[iPart]; 
      numEntGrp += mesh->numEntGrp(); 
    }

  if(numEntGrp==0) {                                 // no entity group 

    for(int iPart=0; iPart<size; iPart++) {
       mesh=(*meshes)[iPart];	
       for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {

	 mEntity *ent = *it;      
	 int counter=0; 

	 for(int i=0; i<ent->size(dim-1); i++){
	
	// get the downward adjacency
	   mEntity* down = ent->get(dim-1, i);
	
	// get the upward adjacency 
	 for(int j=0; j<down->size(dim); j++) {
	   mEntity* adj = down->get(dim, j); 
	   if(adj!=ent)
	    counter++; 
	 }

#ifdef MATCHING
        // check if it is matched entity
	void* tmp; 
	if (EN_getDataPtr(down, matchId, &tmp)){
	  multimap<int, mEntity*>* reg_map = (multimap<int, mEntity*>*)tmp; 
	  counter += reg_map->size(); 
	}
#endif 

	// check if down entity is adjacent to other po on other parts 
	 if(down->getData(tagId))
	   counter++; 
	
       }  
       num_edges[k++]=counter;                  //adjPOs.size();
     }
   }
   *ierr = ZOLTAN_OK;  
 
    return;
  }

   unsigned int egTag= MD_lookupMeshDataId("EntityGroupTag");

    mEntityGroup* eg;
    k=0;
    list<void*>::iterator listIt;
    map<int, set<void*> > adjPOs;
    map<int, set<void*> >::iterator mapIt;

   for(int iPart=0; iPart<size; iPart++) {
    mesh = (*meshes)[iPart];
    for(mPart::iterEntGrp it=mesh->beginEntGrp(); it!=mesh->endEntGrp(); ++it) {
      eg = *it;
      eg->getBdryEntities();

      adjPOs.clear();
      for(listIt=(eg->bdryEnts)->begin(); listIt!=(eg->bdryEnts)->end(); listIt++) {
         mEntity* down = (mEntity*)(*listIt);

         for(int j=0; j<down->size(dim); j++) {
            mEntity* adj = down->get(dim, j);

            void* tmp;
            if(!EN_getDataPtr(adj, egTag, &tmp))        // not in any entity-group
               adjPOs[ParUtil::Instance()->rank()].insert(adj);
            else
              if(tmp!=eg)                               // in a different entity-group
                adjPOs[ParUtil::Instance()->rank()].insert(tmp);
         }

         void* tmp;
         if(down->getPClassification() && EN_getDataPtr(down, tagId, &tmp)) {   // part boundary entity
            int_mEnt_struct* buf = (int_mEnt_struct*) tmp;
            adjPOs[buf->i].insert((void*)buf->entity);
         }
      }

      int counter=0;
      for(mapIt=adjPOs.begin(); mapIt!=adjPOs.end(); mapIt++) {
         counter += (mapIt->second).size();
      }

      num_edges[k++]= counter;
    }
   
   for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {

      mEntity *ent = *it;
      int counter=0;

      void* tmp;
      if(!EN_getDataPtr(ent, egTag, &tmp)) {          // not in any entity-group

        map<int, set<void*> > adjs;

        for(int i=0; i<ent->size(dim-1); i++){

          // get the downward adjacency
          mEntity* down = ent->get(dim-1, i);

          // get the upward adjacency
          for(int j=0; j<down->size(dim); j++) {
            mEntity* adj = down->get(dim, j);
            if(adj!=ent) {
               void* tmpEg;
               if(!EN_getDataPtr(adj, egTag, &tmpEg))   // not in any entity-group
                  adjs[ParUtil::Instance()->rank()].insert(adj);
               else                                      // in another entity-group
                  adjs[ParUtil::Instance()->rank()].insert(tmpEg);
            }
          }

          // check if down entity is adjacent to other po on other parts
          void* tmp;
          if(EN_getDataPtr(down, tagId, &tmp)) {

             int_mEnt_struct* buf = (int_mEnt_struct*) tmp;
             adjs[buf->i].insert((void*)buf->entity);
          }
        }

        map<int, set<void*> >::iterator mapIt;

        for(mapIt=adjs.begin(); mapIt!=adjs.end(); mapIt++)
           counter += mapIt->second.size();

        num_edges[k++]=counter;                  //adjPOs.size();
      }
    }  
  }
   *ierr = ZOLTAN_OK; 
  }
  
/*
    Get a list of neighboring partition objects connected to each partition object. 
*/
 void get_edge_list_multi(void* data, int num_gid_entries,
		     int num_lid_entries, int num_obj, ZOLTAN_ID_PTR global_ids,
		     ZOLTAN_ID_PTR local_ids, int* num_edges, 
		     ZOLTAN_ID_PTR nbor_global_id, int *nbr_procs,
		     int wgt_dim, float *ewgts, int *ierr)
  {
    
    if(data == NULL)
    {
       *ierr = ZOLTAN_FATAL;
    }

    POofMeshes*  poMesh = (POofMeshes*)data;
    vector<mPart*>* meshes = poMesh->meshes; 
    int dim = poMesh->dim;  
    int ptrsize = poMesh->ptrsize; 
    
    // get the tag 
    unsigned int tagId= MD_lookupMeshDataId("SetEntOnCB");
#ifdef MATCHING
    unsigned int matchId = MD_lookupMeshDataId("MatchEntity"); 
#endif
   
    int k=0;     
    int sum=0;   
   
    mPart* mesh; 
    int numpart = (*meshes).size(); 
    int numEntGrp=0; 

    for(int iPart=0; iPart<numpart; iPart++) {
      mesh = (*meshes)[iPart];
      numEntGrp += mesh->numEntGrp(); 
    }

   if(numEntGrp==0) {

    for(int iPart=0; iPart<numpart; iPart++) {
      mesh = (*meshes)[iPart];
      for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {
      
        mEntity *ent = *it;
        int count=0; 
    
        for(int i=0; i<ent->size(dim-1); i++){

	// get the downward adjacency 
	  mEntity* down = ent->get(dim-1, i); 
	
	// get the upward adjacency for down 
	  for(int j=0; j<down->size(dim); j++) {
	    mEntity* adj = down->get(dim, j); 

	    if (adj!=ent){
	      memcpy(&nbor_global_id[(sum+count)*num_gid_entries], &adj, sizeof(adj));     // entity pointer

	      if(ptrsize==4) {  // 32bit  
	       nbor_global_id[(sum+count)*num_gid_entries+1]=ParUtil::Instance()->rank();  // proc rank
	      }
	      else {           // 64bit
	       nbor_global_id[(sum+count)*num_gid_entries+2]=ParUtil::Instance()->rank();  // proc rank
	      }
	    
	      nbr_procs[sum+count]=ParUtil::Instance()->rank();
	 
	    // set the edge weight 
	      ewgts[sum+count]=1.0;               // inter-process edge
	      count++; 
	    }
	  }
	  
#ifdef MATCHING
        // check if it is matched entity
	 void* tmp;
	 if (EN_getDataPtr(down, matchId, &tmp)){
	    multimap<int, mEntity*>* reg_map = (multimap<int, mEntity*>*)tmp;
	    
	    multimap<int, mEntity*>::iterator mapit; 
	    for(mapit=reg_map->begin(); mapit!=reg_map->end(); mapit++) {
	       
	       memcpy(&nbor_global_id[(sum+count)*num_gid_entries], &(mapit->second), ptrsize);   // entity pointer

	       if(ptrsize==4) { // 32bit
		  nbor_global_id[(sum+count)*num_gid_entries+1]= mapit->first;   // proc rank
	       }
	       else {          // 64bit
		  nbor_global_id[(sum+count)*num_gid_entries+2]= mapit->first;   // proc rank
	       }
	    
	    nbr_procs[sum+count]= mapit->first;

	    ewgts[sum+count]=1.0; 
	    count++; 
	    }

	    delete reg_map;                        // deallocate the multimap
	    EN_deleteData(down, matchId);
	 }
#endif
						    

	// check if down entity is adjacent to other po on other part 
	  void* tmp_ptr;
	  if ( EN_getDataPtr(down, tagId, &tmp_ptr) ) { 
	  
	   int_mEnt_struct* buf = (int_mEnt_struct*) tmp_ptr; 
	  
	   memcpy(&nbor_global_id[(sum+count)*num_gid_entries], &(buf->entity), ptrsize); // po pointer

           if(ptrsize==4) { // 32bit 
	    nbor_global_id[(sum+count)*num_gid_entries+1]= buf->i;   // proc rank
           }
	   else {          // 64bit
	    nbor_global_id[(sum+count)*num_gid_entries+2]= buf->i;   // proc rank
           }

	   nbr_procs[sum+count]= buf->i; 
	  
	  // set the edge weight
	  if(buf->i==ParUtil::Instance()->rank())
       	    ewgts[sum+count]=1.0;                    // inter-process edge
	  else
	    ewgts[sum+count]=1.0;                    // intra-process edge
	   count++;  
	  }
        }
	
       sum += count;
       assert(count==num_edges[k++]);
    } 
  }
  
   *ierr = ZOLTAN_OK;
  
 return; 
 }

  unsigned int egTag= MD_lookupMeshDataId("EntityGroupTag");

   mEntityGroup* eg;
   list<void*>::iterator listIt;
   map<int, set<void*> > adjPOs;
   map<int, set<void*> >::iterator mapIt;

  for(int iPart=0; iPart<numpart; iPart++) {
    mesh = (*meshes)[iPart];
    for(mPart::iterEntGrp it=mesh->beginEntGrp(); it!=mesh->endEntGrp(); ++it) {
      eg = *it;
      eg->getBdryEntities();

      adjPOs.clear();
      for(listIt=(eg->bdryEnts)->begin(); listIt!=(eg->bdryEnts)->end(); listIt++) {
         mEntity* down = (mEntity*)(*listIt);

         for(int j=0; j<down->size(dim); j++) {
            mEntity* adj = down->get(dim, j);

            void* tmp;
            if(!EN_getDataPtr(adj, egTag, &tmp))
               adjPOs[ParUtil::Instance()->rank()].insert(adj);
            else
              if(tmp!=eg)
                adjPOs[ParUtil::Instance()->rank()].insert(tmp);
         }

         void* tmp;
         if(down->getPClassification() && EN_getDataPtr(down, tagId, &tmp)) {   // part boundary entity
            int_mEnt_struct* buf = (int_mEnt_struct*) tmp;
            adjPOs[buf->i].insert((void*)buf->entity);
         }
      }

      int count=0;
      for(mapIt=adjPOs.begin(); mapIt!=adjPOs.end(); mapIt++) {

        for(set<void*>::iterator setIt = mapIt->second.begin(); setIt!=mapIt->second.end(); setIt++) {

          memcpy(&nbor_global_id[(sum+count)*num_gid_entries], &(*setIt), ptrsize);

          if(ptrsize==4)  // 32bit
            nbor_global_id[(sum+count)*num_gid_entries+1]= mapIt->first;  // proc rank
          else           // 64bit
            nbor_global_id[(sum+count)*num_gid_entries+2]= mapIt->first;
  
          nbr_procs[sum+count]= mapIt->first; 
	  
          ewgts[sum+count]=1.0;
          count++;
        }
      }

      assert(count==num_edges[k++]);
      eg->removeBdryEntities();

      sum += count;
    }

    for(mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim); ++it) {

      mEntity *ent = *it;

      void* tmp;
      if(!EN_getDataPtr(ent, egTag, &tmp)) {          // not in any entity-group

        map<int, set<void*> > adjs;

        for(int i=0; i<ent->size(dim-1); i++){

          // get the downward adjacency
          mEntity* down = ent->get(dim-1, i);

          // get the upward adjacency
          for(int j=0; j<down->size(dim); j++) {
            mEntity* adj = down->get(dim, j);
            if(adj!=ent) {
               void* tmpEg;
               if(!EN_getDataPtr(adj, egTag, &tmpEg))
                  adjs[ParUtil::Instance()->rank()].insert(adj);
               else
                 adjs[ParUtil::Instance()->rank()].insert(tmpEg);
            }
          }

          // check if down entity is adjacent to other po on other parts
          void* tmp;
          if(EN_getDataPtr(down, tagId, &tmp)) {

             int_mEnt_struct* buf = (int_mEnt_struct*) tmp;
             adjs[buf->i].insert((void*)buf->entity);
          }
        }

        map<int, set<void*> >::iterator mapIt;

        int count=0;
        for(mapIt=adjs.begin(); mapIt!=adjs.end(); mapIt++) {

          for(set<void*>::iterator setIt = mapIt->second.begin(); setIt!=mapIt->second.end(); setIt++) {

            memcpy(&nbor_global_id[(sum+count)*num_gid_entries], &(*setIt), ptrsize);

            if(ptrsize==4)  // 32bit
              nbor_global_id[(sum+count)*num_gid_entries+1]= mapIt->first;  // proc rank
            else           // 64bit
              nbor_global_id[(sum+count)*num_gid_entries+2]= mapIt->first;

            nbr_procs[sum+count]= mapIt->first;
	    
            ewgts[sum+count]=1.0;
            count++;
          }
        }

        assert(count==num_edges[k++]);
        sum += count;
      }
    }
  }

  *ierr = ZOLTAN_OK;
}

void pmZoltanCallbacks::partition(std::vector<mPart*>& meshes, map<mEntity*, int*>& POtoMove)
{
   map<mEntityGroup*, int*> EntGrpToMove; 
   partition(meshes, POtoMove, EntGrpToMove);
}

void pmZoltanCallbacks::partition(std::vector<mPart*>& meshes, map<mEntity*, int*>& POtoMove, map<mEntityGroup*, int*>& EntGrpToMove)
{
    int changes; 
    ZOLTAN_ID_PTR import_gids = NULL; /* Global ids of nodes imported */
    ZOLTAN_ID_PTR import_lids = NULL; /* Pointers to nodes imported */
    int *import_procs = NULL;     /* Proc IDs of procs owning nodes to be
                                     imported.*/
    ZOLTAN_ID_PTR export_gids = NULL; /* Global ids of nodes exported */
    ZOLTAN_ID_PTR export_lids = NULL; /* Pointers to nodes exported */
    int *export_procs = NULL;     /* Proc IDs of destination procs for nodes
                                     to be exported.*/
    int num_imported;             /* Number of nodes to be imported. */
    int num_exported;             /* Number of nodes to be exported. */
    int num_gid_entries;          /* Number of array entries in global ID  */
    int num_lid_entries;          /* Number of array entries in local ID   */
    int *import_to_part = NULL; 
    int *export_to_part = NULL; 
    
    int rc; 
    float ver; 
    rc = Zoltan_Initialize(0, 0, &ver);
    if(rc != ZOLTAN_OK) {
      printf("sorry...\n");
      exit(0);
    }
    
//  construct the data structure 
    POofMeshes*  poMesh = new POofMeshes;
    poMesh->meshes = &meshes; 
    poMesh->dim = M_globalMaxDim(meshes[0]);
    poMesh->ptrsize = sizeof(void*); 
    
//  exchange the adjacent partition object info for part bdry entity 
    setEntOnCB(meshes, poMesh->dim);
    
    int mypid = ParUtil::Instance()->rank(); 

    struct Zoltan_Struct *zz;
    zz = Zoltan_Create(MPI_COMM_WORLD);
    
// define the pointer size based on machine bit
    if(sizeof(void*)==4) {
      num_gid_entries=2;                 // global ID: ent + proc rank. 32 bit
      num_lid_entries=1;                 // local ID: local pid 
    }
    else{
      num_gid_entries=3;                 // global ID: ent + proc rank., 64 bit
      num_lid_entries=1;                 // local ID: local pid
    }

    char tempstr[50]; 
    sprintf(tempstr, "%d", num_gid_entries);
    Zoltan_Set_Param(zz, "num_gid_entries", tempstr);  
    
    sprintf(tempstr, "%d", num_lid_entries);
    Zoltan_Set_Param(zz, "num_lid_entries", tempstr);
    
    Zoltan_Set_Param(zz, "obj_weight_dim", "1");    
    Zoltan_Set_Param(zz, "edge_weight_dim", "1"); 
    Zoltan_Set_Param(zz, "debug_level", "0");    
    
    Zoltan_Set_Param(zz, "imbalance_tol", "1.03"); 
    
    switch(theAlgorithm) {
    case GRAPH:
      sprintf(tempstr, "%s", "GRAPH");
      break;
    case HYPERGRAPH:
      sprintf(tempstr, "%s", "HYPERGRAPH");
      break;
    default: 
      sprintf(tempstr, "%s", "PARMETIS");
    }
    Zoltan_Set_Param(zz, "LB_METHOD", tempstr);       // graph-based partition 
    
    switch(parAlgorithm) {                         // set the parmetis submethod. 
    case PartKway:
      sprintf(tempstr, "%s","PartKway"); 
      break; 
    case PartGeom:
      sprintf(tempstr, "%s","PartGeom"); 
      break;
    case PartGeomKway:
      sprintf(tempstr, "%s","PartGeomKway"); 
      break;
    case AdaptiveRepart:
      sprintf(tempstr, "%s","AdaptiveRepart"); 
      break;
    case RepartLDiffusion:
      sprintf(tempstr, "%s","RepartLDiffusion"); 
      break; 
    case RepartGDiffusion:
      sprintf(tempstr, "%s","RepartGDiffusion"); 
      break;
    case RepartRemap:
      sprintf(tempstr, "%s","RepartRemap"); 
      break; 
    case RepartMLRemap:
      sprintf(tempstr, "%s","RepartMLRemap"); 
      break; 
    default:
      sprintf(tempstr, "%s","RefineKway"); 
    }
    Zoltan_Set_Param(zz, "PARMETIS_METHOD", tempstr);  

    if(localNumParts<0)
      localNumParts=0;                       // fix the user error, and set the upbound for localNumParts 
    if(localNumParts>MAX_NUM_PARTS_PER_PROCESS)
      localNumParts=MAX_NUM_PARTS_PER_PROCESS;   
    sprintf(tempstr, "%d", localNumParts);
    Zoltan_Set_Param(zz, "NUM_LOCAL_PARTITIONS", tempstr);
    	 
    Zoltan_Set_Param(zz, "CHECK_GRAPH", "0");    // SET IT TO PURSUE HIGH PERFORMANCE 

    Zoltan_Set_Fn (zz, ZOLTAN_NUM_OBJ_FN_TYPE, (void (*)())get_num_POs, (void*)(poMesh));
    Zoltan_Set_Fn (zz, ZOLTAN_OBJ_LIST_FN_TYPE, (void (*)())get_PO_list, (void *)(poMesh));
    Zoltan_Set_Fn (zz, ZOLTAN_NUM_EDGES_MULTI_FN_TYPE, (void (*)())get_num_edges_multi, (void*)(poMesh));
    Zoltan_Set_Fn (zz, ZOLTAN_EDGE_LIST_MULTI_FN_TYPE, (void (*)())get_edge_list_multi, (void*)(poMesh)); 
    Zoltan_Set_Fn (zz, ZOLTAN_PARTITION_MULTI_FN_TYPE, (void (*)())get_part_multi, (void*)(poMesh));  

#ifdef DEBUG_ 
    Zoltan_Generate_Files(zz, "kdd", 1, 0, 1, 0);              // to create kdd debugging files. 
#endif 

    rc = Zoltan_LB_Partition(zz, &changes,
			     &num_gid_entries, &num_lid_entries,
			     &num_imported, &import_gids,
			     &import_lids, &import_procs,&import_to_part,  
			     &num_exported,&export_gids,
			     &export_lids, &export_procs,&export_to_part);
    
    
    deleteEntOnCB(meshes, poMesh->dim);
    delete poMesh; 

// get the local number of parts from each process 
    int size = ParUtil::Instance()->size(); 
    int* glbNumParts = new int[size];
    for(int i=0; i<size; i++)
      glbNumParts[i] =0 ; 
    MPI_Allgather(&localNumParts, 1, MPI_INT, glbNumParts, 1, MPI_INT, MPI_COMM_WORLD);
 
// set max local number of parts   
    int maxNumParts=glbNumParts[0];                             // should be improved through stl algorithm
    for(int i=1; i<size; i++) {
      if(glbNumParts[i]>maxNumParts)
	maxNumParts=glbNumParts[i]; 
      glbNumParts[i] += glbNumParts[i-1]; 
    }
     
    int tgtMax=ParUtil::Instance()->getTgtNumParts(); 
    if(maxNumParts>tgtMax)
      maxNumParts=MAX_NUM_PARTS_PER_PROCESS; 
    else
      maxNumParts=tgtMax; 
    
    ParUtil::Instance()->setTgtNumParts(maxNumParts);            // set max_target_local_num_part
    ParUtil::Instance()->setUsrNumParts(localNumParts);
    
// construct POtoMove from Zoltan output 
  
    mEntity* ent; 
    mAttachableDataContainer* con;
    mEntityGroup* entGrp; 

    for(int icount=0; icount<num_exported; icount++)   { 
      memcpy(&con, &export_gids[icount*num_gid_entries], sizeof(void*));
      int* pid = new int[3]; 
      pid[0]=export_lids[icount*num_lid_entries];                           // current_local_pid 
      pid[2]=export_procs[icount];                                          // target_proc_rank
      if(pid[2]>0)
         pid[1]=pid[2]*maxNumParts+(export_to_part[icount]-glbNumParts[pid[2]-1]);     // target_part_id 
      else
	 pid[1]=pid[2]*maxNumParts+export_to_part[icount]; 

      if( (mypid==pid[2] && (pid[1]==mypid*maxNumParts+pid[0])) ) {      // stay in the current part, assume globally unique continuous part id from Zoltan
        delete[] pid; 
	continue; 
      }

      if(con->getContainerType()==mAttachableDataContainer::ENTITY) {
        memcpy(&ent, &export_gids[icount*num_gid_entries], sizeof(void*));
	POtoMove[ent]=pid; 
      }
      else {
	 memcpy(&entGrp, &export_gids[icount*num_gid_entries], sizeof(void*)); 
	 EntGrpToMove[entGrp]=pid;

         for(mEntityGroup::entIter entIt=entGrp->begin(); entIt!=entGrp->end(); entIt++) {
           ent = *entIt;
           POtoMove[ent]=pid;
         }						     
      }
      
    }
    delete[] glbNumParts; 
    
    Zoltan_LB_Free_Part( &import_gids, &import_lids, &import_procs, &import_to_part);
    Zoltan_LB_Free_Part( &export_gids, &export_lids, &export_procs, &export_to_part);
    Zoltan_Destroy(&zz); 
  }

void pmZoltanCallbacks::partition(mPart* mesh, map<mEntity*, int>& POtoMove)
{
   vector<mPart*> meshes;
   meshes.push_back(mesh);

   /**< STEP 1: call real partition function */
   map<mEntity*, int*> tmpPOtoMove; 
   map<mEntityGroup*, int*> EntGrpToMove;  
   partition(meshes, tmpPOtoMove, EntGrpToMove);

   /**< STEP 2: convert POtoMove */
   map<mEntity*, int*>::iterator iter; 
   for(iter=tmpPOtoMove.begin(); iter!=tmpPOtoMove.end(); iter++) { 
     POtoMove[(mEntity*)(iter->first)]=(iter->second)[2];               // target_proc_rank 
   }
   
   /**< STEP 3: delete POtoMove and empty meshes */
  for(iter = tmpPOtoMove.begin(); iter!= tmpPOtoMove.end(); iter++) {
    int* pid = (*iter).second;
    delete[] pid; 
  }

} 
#endif
#endif
