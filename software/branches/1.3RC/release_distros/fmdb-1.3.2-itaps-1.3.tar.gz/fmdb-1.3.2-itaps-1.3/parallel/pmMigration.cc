/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <vector>
#include <set>
#include <list>
#include <map>
#include <iterator>

#include "pmModel.h"
#include "pmMigrateUtil.h"
#include "pmModelUtil.h"
#include "pmMigrationCallbacks.h"
#include "mPart.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "pmGraphs.h"
#include "mFMDB.h"
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "mFlexDB.h"
#include "mException.h"
#include "FMDB_EntGrp.h"

using std::vector;
using std::set;
using std::cout;
using std::pair;
using std::list;
using std::endl;
using std::map;

  extern "C" void trace_start(void);
  extern "C" void trace_stop(void);
  extern "C" void summary_start(void);
  extern "C" void summary_stop(void);
	       
#ifdef BLOCK_MIGRATE
#define MAX_POTOMOVE_AT_A_TIME  0
#endif 

void  printPOtoMove(map<mEntity*, int*>& POtoMove)       
{
  map<mEntity*, int*>::const_iterator mapit;  
  int mypid=ParUtil::Instance()->rank();
  for (mapit=POtoMove.begin(); mapit!=POtoMove.end();++mapit)
    cout<<"("<<mypid<<") move "<<mapit->first->getUid()<<" to Part"<<(mapit->second)[1]<<" of P"<<(mapit->second)[2]<<endl;
}

void pmLoadBalance(mPart* mesh, pmMigrationCallbacks &cb)
{
   vector<mPart*> meshes; 
   meshes.push_back(mesh);
   pmLoadBalance(meshes, cb);
}


// *****************************************
void pmLoadBalance(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb)
// *****************************************
{
  mPart* mesh = meshes[0]; 
  // assume all part meshes have the same dimension
  int from = M_globalMaxDim(mesh); 
  int to = from-1;
  ParUtil::Instance()->set_maxMeshDim(from);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

/**< STEP 1: get partition objects from Zoltan */
  map<mEntity*,int*> POtoMove;       // POtoMove: entity_pointer, local_pid + tgt_glb_pid + tgt_proc_rank
  map<mEntityGroup*, int*> EntGrpToMove; 
  cb.partition(meshes, POtoMove, EntGrpToMove);  

#ifdef DEBUG_
  printPOtoMove(POtoMove);
#endif

/**< STEP 2: migrate entities */ 
  CM->set_comm_validation(IPComMan::All_Reduce);

  int numPart = (int)meshes.size(); 
  int usrNumPart = ParUtil::Instance()->getUsrNumParts();    // usr_local_num_parts is set during partition

  // when local_num_part is increased 
  pGModel model = mesh->getSolidModel();
  if(numPart<usrNumPart)  {
    for(int i= numPart ; i<usrNumPart; ++i) {

      mPart* tmpMesh = MS_newMesh(model);
      meshes.push_back(tmpMesh);
    }
  }
	      
  std::list<mEntity*> rmE[4], newE[4];
  std::vector<mEntityGroup*> rmEG; 
  std::vector<mEntityGroup*> newEG; 
  migrateMeshEntities(meshes, POtoMove, EntGrpToMove, cb, rmE, newE, rmEG, newEG);      // current num_part is reset as target_num_part 
}

// *****************************************
int pmMerge(mPart* mesh, pmMigrationCallbacks &cb)
// *****************************************
{
  if (ParUtil::Instance()->size()==1)  return 0;

  int mDim = M_globalMaxDim(mesh); 
#ifdef _DEBUG
  double t1, t2;
#endif  
// STEP 1: get partition objects to move
  map<mEntity*,int> POtoMove;
#ifdef _DEBUG
  t1=ParUtil::Instance()->wTime();
#endif

// determine the processor to merge
  int numPE = ParUtil::Instance()->size();
  int myPid = ParUtil::Instance()->rank();
  int* numR = new int[numPE];
  
  // send phase begins
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::All_Reduce);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  int* msg_send = (int*)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;
 
  for (int pid=0; pid<numPE;++pid)
  {
    if (pid==P_pid()) continue;
    *msg_send = mesh->size(mDim);
    CM->send(pid, (void*)msg_send);
    num_sent++;
  }
  CM->finalize_send();
  CM->free_msg(msg_send);  

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    numR[pid_from] = *(int*)msg_recv;
    CM->free_msg(msg_recv);
  }

  numR[myPid] = mesh->size(mDim);
  int pidToMerge = myPid;
  int numRMax = mesh->size(mDim);
  
  for (int k=0; k<numPE; ++k)
    if (numR[k] > numRMax)
    {
      numRMax = numR[k];
      pidToMerge = k;
    }
    
  delete [] numR;

  pidToMerge = P_getMinInt(pidToMerge);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\tPID TO MERGE = %d\n",pidToMerge);

  if (ParUtil::Instance()->rank() != pidToMerge)
    for (mPart::iterall it=mesh->beginall(mDim); it!=mesh->endall(mDim); ++it)
      POtoMove.insert(entityPidMap::value_type(*it,pidToMerge)); 

#ifdef _DEBUG  
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) get entities to move\n",t2-t1);
#endif
// STEP 2: migrate entities

  /// Restore neighbors
  set<int> nbrs;
  pmModel::Instance()->getNbrPTs(nbrs);
  CM->set_Nbrs(nbrs);
  CM->set_comm_validation(IPComMan::Neighbors);

  list<mEntity*> rmE[4];
  list<mEntity*> newE[4];
  std::vector<mEntityGroup*> rmEG;
  std::vector<mEntityGroup*> newEG; 
  migrateMeshEntities(mesh, POtoMove, cb, rmE, newE, rmEG, newEG);

  return pidToMerge; 
}

int pmPartMigration(std::vector<mPart*>& meshes, 
		    int source_pid, 
		    int target_rank, 
		    pmMigrationCallbacks &cb)
{ 
  int numPart, sender, mypid, source_lid; 
  mPart* mesh; 
  int dim; 

// ********************************************
// STEP 1: initialize localPids if necessary 
// ********************************************
  int size = (ParUtil::Instance()->localPids).size(); 
  if(size==0) 
    for(int ivec=0; ivec<(int)meshes.size(); ivec++)
      (ParUtil::Instance()->localPids).push_back(ivec);  

#ifdef DEBUG
  size = (ParUtil::Instance()->localPids).size(); 
  assert(size==meshes.size()); 
#endif

// ********************************************
// STEP 2: get source part mesh and 
//         send request to target process
// ********************************************
  numPart = ParUtil::Instance()->getCurNumParts();    // max local num parts per process 
  sender = source_pid / numPart;
  mypid = ParUtil::Instance()->rank(); 
  source_lid = source_pid % numPart;   
 
  IPComMan *CM = ParUtil::Instance()->ComMan();
  set<int> nbrs; 
  if(mypid==sender)
    nbrs.insert(target_rank);
  if(mypid==target_rank)
    nbrs.insert(sender); 
  CM->set_Nbrs(nbrs);
  
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0); 
  int msg_size=sizeof(int);
  int num_sent=0, num_recvd=0; 
 
  if(mypid==sender) {
    mesh=NULL; 
    for(int ivec=0; ivec<(int)meshes.size(); ivec++)
      if((ParUtil::Instance()->localPids)[ivec]==source_lid) {
	mesh = meshes[ivec];
	break; 
      }
    if(mesh==NULL)                       // should throw an exception 
      throw new mException(__LINE__,__FILE__,"Invalid argument of source_global_part_id in part migration."); 
      
    dim=M_dimension(mesh);
    int* msg_send = (int*)CM->alloc_msg(msg_size);
    *msg_send = dim; 
    CM->send(target_rank, (void*)msg_send, msg_size);
    num_sent++; 
    CM->free_msg(msg_send);
  }

  CM->finalize_send(); 
  
// ********************************************  
// STEP 3: create new global pid on target process  
// ********************************************   
   void* msg_recv;
   int pid_from=-1;

   // recieve phase
   int count=0; 
   while(int rc = CM->receive(msg_recv, &pid_from))
   {
      num_recvd++;
      int* dim = (int *)msg_recv; 		  
   
    // make sure the request is valid, size will not exceed numPart 
    if((ParUtil::Instance()->localPids).size()>0)
      count = (ParUtil::Instance()->localPids).back()+1; 
    if (count>=numPart) 
      throw new mException(__LINE__,__FILE__,"Invalid argument of target_process in part migration.");
    
    // create a new part 
    mesh=meshes[0];                                    
    pGModel model = mesh->getSolidModel();
    mPart* tmpMesh = MS_newMesh(model);
    meshes.push_back(tmpMesh);
    
    // create a new global pid for the new part 
    (ParUtil::Instance()->localPids).push_back(count); 
    int usrNumPart = ParUtil::Instance()->getUsrNumParts(); 
    ParUtil::Instance()->setUsrNumParts(usrNumPart+1); 
  }
  
   CM->set_tag(0);
   num_sent=0; 
   num_recvd=0; 
 
  if (pid_from !=-1) {
   int* msg_send = (int*)CM->alloc_msg(msg_size);
   *msg_send = count; 
   CM->send_to_nbrs((void*)msg_send, msg_size);
   CM->free_msg(msg_send);
   num_sent++; 
  }
  CM->finalize_send(); 

// ********************************************    
// STEP 4: create POtoMove 
// ********************************************  
  map<mEntity*,int*> POtoMove;   
  mEntity* ent; 
  
  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++; 
    int* count = (int*)msg_recv; 

    for (mPart::iterall it=mesh->beginall(dim); it!=mesh->endall(dim);++it){ 
      ent=*it; 
      int* pid=new int[3]; 
      pid[0]= source_lid; 
      pid[1]= target_rank*numPart+ *count;  
      pid[2]= target_rank; 
      POtoMove[ent]=pid; 
    }
   
    int usrNumPart = ParUtil::Instance()->getUsrNumParts(); 
    ParUtil::Instance()->setUsrNumParts(usrNumPart-1); 
    
    // marks the part to move  
    vector<int>::iterator vecit; 
    vecit = std::find((ParUtil::Instance()->localPids).begin(), (ParUtil::Instance()->localPids).end(), source_lid);
    int lid = *vecit; 
    *vecit = lid-(ParUtil::Instance()->localPids).size(); 

#ifdef DEBUG_
    cout<<"("<<mypid<<") LOCAL PIDS: "; 
    for(vecit=(ParUtil::Instance()->localPids).begin(); vecit!=(ParUtil::Instance()->localPids).end(); vecit++)
      cout<<*vecit<<" "; 
    cout<<endl; 
#endif
  }
  
#ifdef DEBUG_
  printPOtoMove(POtoMove);
#endif

// ********************************************  
// STEP 5: call mesh entity migration 
// ********************************************  
  migrateMeshEntities(meshes, POtoMove, cb);  
  return 1; 
}

// *****************************************
int pmPartMigration(mPart* mesh,
                    int dimToMove,list<mEntity*>& entities,
                    pmMigrationCallbacks &cb,
                    std::list<mEntity*>* rmE,
                    std::list<mEntity*>* newE,
                    std::vector<mEntityGroup*>& rmEG,
                    std::vector<mEntityGroup*>& newEG)
// *****************************************
{
  if (ParUtil::Instance()->size()==1)  return 0;

  int mmigr;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

// STEP 1: unify origin entities to move
  unifyEntitiesToMove(mesh, entities);

// STEP 2: get partition objects to move
  map<mEntity*,int> POtoMove;
  getPOsToMove(mesh, entities, dimToMove, POtoMove);

// STEP 3: migrate entities
  mmigr = migrateMeshEntities(mesh, POtoMove, cb, rmE, newE, rmEG, newEG);

  return mmigr;
}

int pmPartMigration(mPart* mesh, pmMigrationCallbacks &cb,
 		    std::list<mEntity*>& vtsOnCB, 
		    std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
                    std::list<mEntity*>* rmE,
                    std::list<mEntity*>* newE,
                    std::vector<mEntityGroup*>& rmEG,
                    std::vector<mEntityGroup*>& newEG)
{
  if (ParUtil::Instance()->size()==1)  return 0;

  int mmigr;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

// STEP 1: unify CB vertices to move
  unifyEntitiesToMove(mesh, vtsOnCB);

// STEP 2: get partition objects to move
  map<mEntity*,int> POtoMove;
  getPOsToMoveForSnap(mesh,vtsOnCB, vtfcPairs, POtoMove); 

// STEP 3: migrate entities
  mmigr = migrateMeshEntities(mesh, POtoMove, cb, rmE, newE, rmEG, newEG);

  return mmigr;
}


// *****************************************
int migrateMeshEntities(mPart* mesh,
                        map<mEntity*,int>& POtoMove,
                        pmMigrationCallbacks& cb)
// *****************************************
{
  std::list<mEntity*> rmE[4]; 
  std::list<mEntity*> newE[4]; 
  std::vector<mEntityGroup*> rmEG;
  std::vector<mEntityGroup*> newEG; 
  return migrateMeshEntities(mesh, POtoMove, cb, rmE, newE, rmEG, newEG);
}


// *****************************************
int migrateMeshEntities(mPart* mesh,
                        map<mEntity*,int>& POtoMove,
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE,
                        std::list<mEntity*>* newE,
                        std::vector<mEntityGroup*>& rmEG,
                        std::vector<mEntityGroup*>& newEG)				  
// *****************************************
{
   vector<mPart*> meshes;
   meshes.push_back(mesh);

   // construct new POtoMove structure 
   map<mEntity*, int*> pos;
   map<mEntity*, int>::iterator iter;
   for(iter=POtoMove.begin(); iter!=POtoMove.end(); iter++) {
      int* pids=new int[3];
      pids[0]=0;
      pids[1]=iter->second;
      pids[2]=iter->second;
      pos[iter->first]=pids;
   }
   int err = migrateMeshEntities(meshes, pos, cb, rmE, newE, rmEG, newEG);

  return err; 
}


// *****************************************
int migrateMeshEntities(std::vector<mPart*>& meshes, 
                        map<mEntity*,int*>& POtoMove,
		        pmMigrationCallbacks& cb)
// *****************************************			
{
  list<mEntity*> rmE[4];
  list<mEntity*> newE[4];
  std::vector<mEntityGroup*> rmEG; 
  std::vector<mEntityGroup*> newEG; 
  return migrateMeshEntities(meshes, POtoMove, cb,rmE,newE, rmEG, newEG);
}

int migrateMeshEntities(std::vector<mPart*>& meshes,
                        std::map<mEntity*,int*>& POtoMove,
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE,
                        std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG,
                        std::vector<mEntityGroup*>& newEG)
{
   map<mEntityGroup*,int*> EntGrpToMove; 
   getEntityGroupsToHandle(POtoMove, EntGrpToMove);
   migrateMeshEntities(meshes, POtoMove, EntGrpToMove, cb, rmE, newE, rmEG, newEG);
}

// *****************************************
int migrateMeshEntities(vector<mPart*>& meshes,
                        map<mEntity*,int*>& POtoMove,
			map<mEntityGroup*,int*>& EntGrpToMove, 
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE,
                        std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG,
			std::vector<mEntityGroup*>& newEG)
// *****************************************
{
  int lMove = 0;
  int gMove = 0;
  int localMove=POtoMove.size();
  int totalMove;
  MPI_Allreduce(&localMove,&totalMove,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  if (totalMove==0)
  {
#ifdef _DEBUG
    ParUtil::Instance()->Msg(ParUtil::INFO,"\n* NO entity migration needed\n");
#endif
    return 0;
  }

#ifdef DEBUG
   lMove += localMove;
   gMove += totalMove;
#endif 

  int mypid = ParUtil::Instance()->rank();

  set<int> nbrs;
  pmModel::Instance()->getNbrPids(nbrs);
  ParUtil::Instance()->ComMan()->set_Nbrs(nbrs);

  int dim = M_globalMaxDim(meshes[0]); 

#ifdef _DEBUG
  double t1, t2;
#endif
  map<mEntity*,int> entitiesToRemove[4];
  map<mEntity*,int> entitiesToHandle[4];
 
// ********************************************
// STEP 1: reset BPs
// ********************************************
  // unify entitiesToHandle and clear their BPs and PCs
#ifdef _DEBUG
  t1 = ParUtil::Instance()->wTime();
#endif
#ifdef DEBUG  
  double ts = ParUtil::Instance()->wTime();
#endif

  getEntitiesToHandle_and_setBPs(dim, POtoMove, entitiesToHandle);

#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set bounding partition ids \n",t2-t1);

// ********************************************
// STEP 2: update PClassification and collect entities to remove
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif
  updatePC_and_collectEntitiesToRemove(entitiesToHandle, entitiesToRemove);

#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update PClassification\n",t2-t1);

// ********************************************
// STEP 3: update RC when maxNumParts is changed (costly) 
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  int curNumPart = ParUtil::Instance()->getCurNumParts();    // current_local_num_parts
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();    // target_local_num_parts 
  mEntity* ent; 
  mPart* mesh; 
  if(curNumPart!=tgtNumPart) {

    for(int ipart=0; ipart<(int)meshes.size(); ipart++) {
      mesh = meshes[ipart];
      for(int idim=0; idim<dim; idim++)
	for (mPart::iterall it=mesh->beginall(idim); it!=mesh->endall(idim);++it){ 

	  // update remote copy
     	  ent=*it; 
	  if(ent->getNumRemoteCopies()) {       
	    map<int, mEntity*> tmpRemoteCopies;
	    ent->getRemoteCopies(tmpRemoteCopies);
	    ent->clearRemoteCopies();
	    
	    for(mEntity::RCIter rcIter=tmpRemoteCopies.begin(); rcIter!=tmpRemoteCopies.end(); ++rcIter) {
	      int pid=(*rcIter).first; 	 
	      int newPid = (pid/curNumPart)*tgtNumPart + pid%curNumPart;          // target global pid 
	      ent->addRemoteCopy(newPid, (*rcIter).second);          
	    }

	    // update partition classification
	    if(entitiesToHandle[idim].find(ent)==entitiesToHandle[idim].end() ) { 
	      set<int> BPset; 
	      ent->getPidsExist(BPset);
	      BPset.insert(mypid*tgtNumPart+ipart);
	      pmEntity* pe = pmModel::Instance()->getPartitionEntity(BPset);
	      ent->setPClassification(pe);
	    }
	  }
#ifdef MATCHING
	  if(ent->hasMatchEnt()) {

            const multimap<int, mEntity*>* tmpMatchEnts;
	    multimap<int, mEntity*> tmpMatchEnts2; 
            tmpMatchEnts = ent->getMatchEnts();

	    int pid, newPid; 
            for(multimap<int, mEntity*>::const_iterator meIter=tmpMatchEnts->begin(); meIter!=tmpMatchEnts->end(); ++meIter) 
	    {
              pid=(*meIter).first;
              newPid = (pid/curNumPart)*tgtNumPart + pid%curNumPart;          // target global pid
	      tmpMatchEnts2.insert(mEntity::matchEntMap::value_type(newPid, meIter->second));
            } 
	    
	    ent->clearMatchEnts(); 
	    for(multimap<int, mEntity*>::iterator meIter=tmpMatchEnts2.begin(); meIter!=tmpMatchEnts2.end(); ++meIter)
	       ent->addMatchEnt(meIter->first, meIter->second);
	       
	  }
#endif
	}
    }
  }

#ifdef _DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update remote copies when numParts is changed.\n",t2-t1);
// ********************************************
// STEP 4: Migrate entities
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  for (int i=0; i<=dim;++i)
    exchangeEntities(meshes, dim, cb, i, entitiesToHandle[i], newE, newEG);

#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) exchange entities\n",t2-t1);

// ********************************************
// STEP 5: collect entities removed to return
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  map<mEntity*,int>::iterator mapit; 
  for (int i=0; i<=dim;++i)
    for(mapit=entitiesToRemove[i].begin(); mapit!=entitiesToRemove[i].end(); mapit++)
      rmE[i].push_back(mapit->first); 

#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) gather removed entities to return to the user\n", t2-t1);

// ********************************************
// STEP 6: delete unused entities
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  ParUtil::Instance()->setCurNumParts(tgtNumPart);
  removeUnusedEntities(meshes, cb, dim, entitiesToRemove); 

// ********************************************
// STEP : delete unused entity groups 
// ********************************************
    map<mEntityGroup*, int*>::iterator egIter;
    mEntityGroup::entIter eiter; 
    int pid;
    mEntityGroup* eg; 
    for(egIter=EntGrpToMove.begin(); egIter!=EntGrpToMove.end(); ++egIter) {
      eg=egIter->first;
      pid = (egIter->second)[0];        // local part id
      for(eiter=eg->begin(); eiter!=eg->end(); ++eiter) {
        POtoMove.erase(*eiter);
      }
      
      meshes[pid]->deleteEntGrp(eg, 0);
      rmEG.push_back(eg);  // collect removed entity group
      delete[] (egIter->second); 
    }

   map<mEntity*,int*>::iterator iter;
   for(iter = POtoMove.begin(); iter!=POtoMove.end(); ++iter) {
      int* pid = (*iter).second;
       delete[] pid;
   }

#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove unused entities\n", t2-t1);

// ********************************************
// STEP 7: delete empty parts and update localPids 
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  int usrNumPart = ParUtil::Instance()->getUsrNumParts(); 
  int size = (int)meshes.size(); 
  if(usrNumPart< size)                   // local_num_parts is reduced     
    if((ParUtil::Instance()->localPids).size()==0 )              
      for(int i=usrNumPart; i< size; ++i) {
	mPart* tmpMesh = meshes[i];
	M_delete(tmpMesh);
	meshes.pop_back(); 
    }
    else{

      vector<int>::iterator vecit; 
      int ipart=0; 
      set<mPart*> meshSet; 
      set<int> pidSet; 
      for(vecit=(ParUtil::Instance()->localPids).begin(); vecit!=(ParUtil::Instance()->localPids).end(); ++vecit, ++ipart) {
	if(*vecit<0) {
	  meshSet.insert(meshes[ipart]); 
	  pidSet.insert(*vecit); 
	}
      }
      
      vector<mPart*>::iterator meshIt; 
      for(set<mPart*>::iterator setit=meshSet.begin(); setit!=meshSet.end(); ++setit) {
	meshIt = std::find(meshes.begin(), meshes.end(), *setit);
	if(meshIt!=meshes.end())
	  meshes.erase(meshIt);
      }
      
      for(set<int>::iterator setit=pidSet.begin(); setit!=pidSet.end(); ++setit){
	vecit = std::find((ParUtil::Instance()->localPids).begin(), (ParUtil::Instance()->localPids).end(), *setit); 
	if(vecit!=(ParUtil::Instance()->localPids).end())
	  (ParUtil::Instance()->localPids).erase(vecit); 
      }
    }


#ifdef _DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove empty parts and update localPids\n",t2-t1);

// ********************************************
// STEP 5: update partition model in terms of ownership
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  /// Set neighboring parts based on the new partition model information
  pmModel::Instance()->clean_up();
  pmModel::Instance()->setNbrPTs();
  nbrs.clear();
  pmModel::Instance()->getNbrPids(nbrs);  
   
  ParUtil::Instance()->ComMan()->set_Nbrs(nbrs);
  pmModel::Instance()->updateOwnership(meshes);

#ifdef DEBUG_
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update partition model\n",t2-t1);
#endif
#ifdef DEBUG_
  if (mypid==0)
    cout<<"      # Moved = " <<totalMove<<" (t = "<<ParUtil::Instance()->wTime()-ts<<" sec)\n";
#endif
  return 1;
}

#endif
