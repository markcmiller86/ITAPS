/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center,
      Rensselaer Polytechnic Institute. All rights reserved.

  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.

*******************************************************************************/
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <list>
#include <set>
#include <map>
#include <vector>
#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mEntity.h"
#include "mFMDB.h"
#include "FMDB.h"
#include "ParUtil.h"
#include "FMDB_cint.h"
#include "oldFMDB.h"
#include "pmModelUtil.h"
#include "mAttachableDataContainer.h"
#include "PList.h"

using std::cout;
using std::endl;
using std::list;
using std::pair;
using std::vector;
using std::map;
using std::set;

// ***********************************************************
void getPOsToMoveFromPartitionVector(mPart *mesh, int from,
                		int *partitionVector, int delta_id, 
				map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int pid;
  mEntity* ent;
  for(mPart::iterall it = mesh->beginall(from) ; it!= mesh->endall(from) ; ++it)
  {      
    ent = *it;
    int id = ent->getAttachedInt(FMDB_Util::Instance()->getId()) - delta_id;
    pid = partitionVector[id];
    if (ParUtil::Instance()->rank()!=pid)
      entitiesToMove.insert(entityPidMap::value_type(ent,pid));
    ent->deleteData(FMDB_Util::Instance()->getId());            // delete the attached data of ent. 
  }
    
}

// ***********************************************************
void unifyEntitiesToMove(mPart* mesh,list<mEntity*>& entities)
// ***********************************************************
{
  // unify entities container
  mEntity* ent;
  list<mEntity*>::iterator it_ent = entities.begin(); 
  IPComMan *CM = ParUtil::Instance()->ComMan();

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;

  for (; it_ent!=entities.end();++it_ent)
  {
    ent = (*it_ent);
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {  
      *msg_send = rciter->second;
      CM->send(rciter->first, (void*)msg_send);
      num_sent++;
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  bool flag;
  int counter = 0;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEnt_struct* castbuf = (mEnt_struct*) msg_recv;
    mEntity* recvEnt = *(mEntity**)msg_recv;
    flag=false;
    if ((recvEnt->getLevel()==0 &&
         recvEnt->getOwner()!=ParUtil::Instance()->rank())
         || (recvEnt->getLevel()==1))
      flag=true;
    if (flag)
    {
      entities.push_back(recvEnt);
      counter++;
    }
    CM->free_msg(msg_recv);
  }  
  entities.unique();
}

// ***********************************************************
void getPOsToMove(mPart* mesh, 
		list<mEntity*>& entities,int ent_dim,
		map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int mypid=ParUtil::Instance()->rank();
  list<mEntity*>::iterator vit;
  
  mEntity *v, *r;
  
  int dim = ParUtil::Instance()->get_maxMeshDim();
  int owner;
  bool reset;

  unsigned int tagId= MD_lookupMeshDataId("visited"); 

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;

  for (vit = entities.begin(); vit != entities.end(); vit++)
  {
    v = *vit;

    if (v->getAttachedInt(tagId))
      continue;
    v->attachInt(tagId,1);

    owner = v->getOwner();
    if (owner==mypid)
      continue;
    mAdjacencyContainer upward;
    v->getHigherOrderUpward(dim,upward);
    reset=false;
    for (int i=0; i<upward.size();++i)
    {
      r = upward[i];
      if (entitiesToMove.find(r)==entitiesToMove.end())
        entitiesToMove[r] = owner;
      else if (entitiesToMove[r]!=owner) // already processed by high priority pid
      { 
	reset=true;  
	break; 
      }
    }
      
    if(reset)
    {
      // undo setting regions to migrate
      for (int i=0; i<upward.size();++i)
      {
        r = upward[i];
        if (entitiesToMove.find(r)!=entitiesToMove.end() &&
	    entitiesToMove[r]==owner)
	  entitiesToMove.erase(entityPidMap::key_type(r));  
      }
      // send message to remote copies
      for (mEntity::RCIter rciter=v->rcBegin();rciter!=v->rcEnd();++rciter)
      {  
	if (rciter->first==owner) continue;
        *msg_send = rciter->second;
        CM->send(rciter->first, (void*)msg_send);
          num_sent++;
      }
    } // if (reset)
  } // for vertices[*piter]

  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEntity* recvEnt = *(mEntity**)msg_recv;
    owner = recvEnt->getOwner();
    mAdjacencyContainer upward;
    recvEnt->getHigherOrderUpward(dim,upward);

    for (int i=0; i<upward.size();++i)
    {
      r = upward[i];
      if (entitiesToMove.find(r)!=entitiesToMove.end() &&
              entitiesToMove[r]==owner)
          entitiesToMove.erase(entityPidMap::key_type(r));
    }
    CM->free_msg(msg_recv);
  }

  for (vit=entities.begin();vit!=entities.end();++vit)
    (*vit)->deleteData(tagId);
}


// ***********************************************************
void getPOsToMove_nbrs(mPart* mesh, list<mEntity*>& entities,int ent_dim, map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int mypid=ParUtil::Instance()->rank();

  list<mEntity*>::iterator vit;

  mEntity *v, *r;

  int dim = ParUtil::Instance()->get_maxMeshDim();
  int owner;
  bool reset;

  unsigned int tagId= MD_lookupMeshDataId("visited");

  pMeshDataId POtag = MD_lookupMeshDataId("vertex originated migration");

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;

  for (vit = entities.begin(); vit != entities.end(); vit++)
  {
    v = *vit;

    if (v->getAttachedInt(tagId))
      continue;
    v->attachInt(tagId,1);

    owner = v->getOwner();
    if (owner==mypid)
      continue;
    mAdjacencyContainer upward;
    v->getHigherOrderUpward(dim,upward);
    reset=false;
    for (int i=0; i<upward.size();++i)
    {
      r = upward[i];
      if (entitiesToMove.find(r)==entitiesToMove.end())
      {
        EN_attachDataPtr(r, POtag, (void*)v);
        entitiesToMove[r] = owner;
      }
      else if (entitiesToMove[r]!=owner) // already processed by high priority pid
      {
        reset=true;
        break;
      }
    }

    if(reset)
    {
      // undo setting regions to migrate
      for (int i=0; i<upward.size();++i)
      {
        r = upward[i];
        if (entitiesToMove.find(r)!=entitiesToMove.end() && entitiesToMove[r]==owner)
        {
          entitiesToMove.erase(r);
          EN_deleteData(r, POtag);
        }
      }
      // send message to remote copies
      for (mEntity::RCIter rciter=v->rcBegin();rciter!=v->rcEnd();++rciter)
      {
        if (rciter->first==owner) continue;
        *msg_send = rciter->second;
        CM->send(rciter->first, (void*)msg_send);
        num_sent++;
      }
    } // if (reset)
  } // for vertices[*piter]

  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEntity* recvEnt = *(mEntity**)msg_recv;
    owner = recvEnt->getOwner();
    mAdjacencyContainer upward;
    recvEnt->getHigherOrderUpward(dim,upward);

    for (int i=0; i<upward.size();++i)
    {
      r = upward[i];
      if (entitiesToMove.find(r)!=entitiesToMove.end() && entitiesToMove[r]==owner)
      {
        entitiesToMove.erase(r);
        EN_deleteData(r, POtag);
      }
    }
    CM->free_msg(msg_recv);
  }

  for (vit=entities.begin();vit!=entities.end();++vit)
    (*vit)->deleteData(tagId);
}

// ***********************************************************
void getPOsToMove_nbrs2(mPart* mesh, list<mEntity*>& entities,int ent_dim, map<mEntity*, int>& entitiesToMove)
// ***********************************************************
{
  int mypid=ParUtil::Instance()->rank();

  list<mEntity*>::iterator vit;

  mEntity *v, *r;

  int dim = ParUtil::Instance()->get_maxMeshDim();
  int owner;
  bool reset;

  unsigned int tagId= MD_lookupMeshDataId("visited");

  pMeshDataId POtag = MD_lookupMeshDataId("vertex originated migration");
  pMeshDataId v_up = MD_lookupMeshDataId("upward");

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));

  int num_sent = 0, num_recvd = 0;

  for (vit = entities.begin(); vit != entities.end(); vit++)
  {
    v = *vit;
    if (v->getAttachedInt(tagId))
      continue;
    v->attachInt(tagId,1);

    owner = v->getOwner();
    if (owner==mypid)
      continue;
    mAdjacencyContainer *upward = new mAdjacencyContainer;
    v->getHigherOrderUpward(dim, *upward);
    reset=false;
    for (int i=0; i<upward->size();++i)
    {
      r = upward->get(i);
      if (entitiesToMove.find(r)==entitiesToMove.end())
      {
        EN_attachDataPtr(r, POtag, (void*)v);
        entitiesToMove[r] = owner;
      }
      else if (entitiesToMove[r]!=owner) // already processed by high priority pid
      {
        reset=true;
        break;
      }
    }

    if(reset)
    {
      // undo setting regions to migrate
      for (int i=0; i<upward->size();++i)
      {
        r = upward->get(i);
        if (entitiesToMove.find(r)!=entitiesToMove.end() && entitiesToMove[r]==owner)
        {
          entitiesToMove.erase(r);
          EN_deleteData(r, POtag);
        }
      }
      // send message to remote copies
      for (mEntity::RCIter rciter=v->rcBegin();rciter!=v->rcEnd();++rciter)
      {
        if (rciter->first==owner) continue;
        *msg_send = rciter->second;
        CM->send(rciter->first, (void*)msg_send);
        num_sent++;
      }
    } // if (reset)
    else
    {
      EN_attachDataPtr(v, v_up, (void*)upward);
    }
  } // for vertices[*piter]

  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEntity* recvEnt = *(mEntity**)msg_recv;
    owner = recvEnt->getOwner();
    mAdjacencyContainer upward;
    recvEnt->getHigherOrderUpward(dim,upward);

    for (int i=0; i<upward.size();++i)
    {
      r = upward[i];
      if (entitiesToMove.find(r)!=entitiesToMove.end() && entitiesToMove[r]==owner)
      {
        entitiesToMove.erase(r);
        EN_deleteData(r, POtag);
      }
    }
    CM->free_msg(msg_recv);
  }

  for (vit=entities.begin();vit!=entities.end();++vit)
    (*vit)->deleteData(tagId);
}


// called by M_migrationForSnap
// ***********************************************************
void getPOsToMoveForSnap(mPart* mesh, std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove)
// ***********************************************************
{
  mEntity *vt, *orgVt, *rgn;
  int pid;
  int mypid=ParUtil::Instance()->rank();
  int numPtn=ParUtil::Instance()->size();
  int dim = ParUtil::Instance()->get_maxMeshDim();
  void* iter=0;
  assert(dim==3);
  
  // STEP 1: Collect pairs to process considering CASE 2 
  // CASE 2: If vertices/pb_face is found on vtsOnCB container, 
  //         the vtFcPair shoule be given up
  map<mEntity*, vector<mEntity*> > pairToProcess;
  for (std::list<std::pair<mEntity*,mEntity*> >::iterator pit=vtfcPairs.begin();
      pit!=vtfcPairs.end();++pit)
  { 
    switch (pit->second->getLevel())
    {
      case 2: if (find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second, 0))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second, 1))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),F_vertex((pFace)pit->second, 2))
	                !=vtsOnCB.end())
             {
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,0));
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,1));
	       pairToProcess[pit->first].push_back(F_vertex((pFace)pit->second,2));
             }
	     break; // exit switch
      case 1: if (find(vtsOnCB.begin(),vtsOnCB.end(),E_vertex((pEdge)pit->second,0))
	                !=vtsOnCB.end() &&
		 find(vtsOnCB.begin(),vtsOnCB.end(),E_vertex((pEdge)pit->second,1))
	                !=vtsOnCB.end())
	     {
	       pairToProcess[pit->first].push_back(E_vertex((pEdge)pit->second,0));
      	       pairToProcess[pit->first].push_back(E_vertex((pEdge)pit->second,1));
	     }
	     break; // exit switch
       case 0: if (find(vtsOnCB.begin(),vtsOnCB.end(),pit->second)!=vtsOnCB.end())
                 pairToProcess[pit->first].push_back(pit->second);
  	      break; // exit for switch
    } // switch
  } // for pit
#ifdef DEBUG_    
  cout<<"("<<mypid<<") done STEP 1\n";
#endif
  // STEP 2: First, process the list of vertices on CB due to priority 
  //         while considering CASE 1.
  // CASE 1: if conflicts between CB vertices ito dpids, 
  //         adjust them based on poor-to-rich rule to repect the cavity for snapping

  getPOsToMove(mesh,vtsOnCB,0,entitiesToMove);

#ifdef DEBUG_
  cout<<"("<<mypid<<") done STEP 2\n";
#endif  
  // Second, process the list of pairs 
  // it contains vertex to process and origin vertex requesting in 
  //  verticesToProcess[dpid] where dpid is the local pid of origin vertex
  vector<vector<pair<mEntity*, mEntity*> > >verticesToProcess(numPtn);
  vector<pair<mEntity*, mEntity*> > ::iterator vecpairit;
  vector<mEntity*>::iterator vecit;
  
  // STEP 3: SEND msg (vt, orgVt, localPid) to remote copies of vt
  //         and While RECIEVE, store msg into verticesToProcess[from]

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);

  CM->set_fixed_msg_size(2*sizeof(mEntity*));
  mEntity** msg_send = (mEntity**)CM->alloc_msg(2*sizeof(mEntity*));
  int num_sent = 0, num_recvd = 0;

  for (map<mEntity*, vector<mEntity*> >::iterator mapit=pairToProcess.begin();
      mapit!=pairToProcess.end();++mapit)
  {
    // iterate over vertices
    orgVt = mapit->first;
    for (vecit=mapit->second.begin(); vecit!=mapit->second.end();++vecit)
    {  
      if ((*vecit)->getPClassification()) 
      {
        // if vertex/pb_face is on CB, send message to remote copy
	// asking adj regions of remote copy to this partition
        for (mEntity::RCIter rciter=(*vecit)->rcBegin();rciter!=(*vecit)->rcEnd();++rciter)
        {
          msg_send[0] = rciter->second;
	  msg_send[1] = orgVt;
          CM->send(rciter->first, (void*)msg_send);
          num_sent++;
	}
      }
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);
#ifdef DEBUG_
  cout<<"("<<mypid<<") done SEND\n";
#endif
  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEntity** castbuf = (mEntity**)msg_recv;
    verticesToProcess[pid_from].push_back(pair<mEntity*, mEntity*>(castbuf[0], castbuf[1]));
    CM->free_msg(msg_recv);
  }  // end of while(!AP...)

#ifdef DEBUG_  
  cout<<"("<<mypid<<") done STEP 3\n";
#endif  
  // STEP 4: mark V_regions of vt in verticesToProcess[pid] where
  //         pid is processed from poor to rich partitions 
  //         if any rg is marked already by != pid, SEND msg back to (orgVt) on pid
  //         so as to while RECIEVE, cancel migration for orgVt to pid
  pMeshDataId undoMigr_tag=MD_newMeshDataId("undo migration");
  int tag_value;
  // get sorted pids from poor to rich
  vector<int> sortedPids;
  getSortedPids_poor_to_rich_comm(mesh,sortedPids);

  CM->set_fixed_msg_size(sizeof(mEntity*));
  msg_send = (mEntity**)CM->alloc_msg(sizeof(mEntity*));
  CM->set_tag(0);
  num_sent = 0;
  num_recvd = 0;

  for (vector<int>::iterator pidit=sortedPids.begin();
      pidit!=sortedPids.end();++pidit)
  {
    // wait for other processors to get started simultaneously
#ifdef DEBUG_  
    cout<<"("<<mypid<<") START to process verticesToProcess["<<*pidit<<"]\n";
#endif
    pid = *pidit;
    if (pid==mypid) continue;

      for (vecpairit=verticesToProcess[pid].begin();
          vecpairit!=verticesToProcess[pid].end();++vecpairit)
      {
        mAdjacencyContainer upward;
        (vecpairit->first)->getHigherOrderUpward(dim,upward);
        pPList vrgns=V_regions((pVertex)vecpairit->first);
        bool reset = false;
        for (int i=0; i<upward.size();++i)
        {
          rgn = upward[i];
          if (entitiesToMove.find(rgn)==entitiesToMove.end())
	    entitiesToMove.insert(entityPidMap::value_type(rgn,pid));
          else
	  {
            /// There are no priorities anymore - first come first served, so no need to check if the region
            /// was grabbed by a higher or lower priority pid.
            reset=true;
            break;
          } // else
        } // for upward	
        if (reset)
        {
          // undo setting regions to migrate
	  for (int i=0; i<upward.size();++i)
	
          {
            rgn = upward[i];
  	  if (entitiesToMove.find(rgn)!=entitiesToMove.end() &&
	        entitiesToMove[rgn]==pid)
	      entitiesToMove.erase(entityPidMap::key_type(rgn));  
          }
	  // send message to orgVt to cancel migration for that
          *msg_send = vecpairit->second;
          CM->send(pid, (void*)msg_send);
          num_sent++;
        } // if (reset)
      } // for vertices[pid]
  }

  CM->finalize_send();

  vector<mEntity*> undoEntities;
  // receive phase begins
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;    
    mEntity** castbuf = (mEntity**)msg_recv;
    // mark orgVt for undo migration;
    EN_attachDataInt(*castbuf, undoMigr_tag, pid_from);
    undoEntities.push_back(*castbuf);
    CM->free_msg(msg_recv);
  }  // end of while(!AP...)

  // reset sendcounts
  CM->set_tag(0);
  num_sent = 0;
  num_recvd = 0;

  for (vector<mEntity*>::iterator undoit = undoEntities.begin();
       undoit!=undoEntities.end(); ++undoit)
  {
    // iterate over vertices
    orgVt = *undoit;
    EN_getDataInt(orgVt, undoMigr_tag, &tag_value);
    // undo migration for this
    for (vecit=pairToProcess[orgVt].begin(); vecit!=pairToProcess[orgVt].end();++vecit)
    {  
      if ((*vecit)->getPClassification()) // send message
      {
        for (mEntity::RCIter rciter=(*vecit)->rcBegin();rciter!=(*vecit)->rcEnd();++rciter)
        {
          if (rciter->first == tag_value) continue;
          *msg_send = rciter->second;
          CM->send(rciter->first, (void*)msg_send);
          num_sent++;
        }
      }
    }
    EN_deleteData(orgVt, undoMigr_tag);
  } // for undoEntities
   
  CM->finalize_send();

  while (int rc = CM->receive(msg_recv, &pid_from)) 
  {
    num_recvd++; 
    mAdjacencyContainer upward;
    (*(mEntity**)msg_recv)->getHigherOrderUpward(dim,upward);
    for (int i=0; i<upward.size();++i)
    {
      rgn = upward[i];
      if (entitiesToMove.find(rgn)!=entitiesToMove.end() && 
        entitiesToMove[rgn] == pid_from)
        entitiesToMove.erase(entityPidMap::key_type(rgn));  
    }
    CM->free_msg(msg_recv);
  }  // end of while(!AP...)
  CM->free_msg(msg_send);

  MD_deleteMeshDataId(undoMigr_tag);
}

#endif /* FMDB_PARALLEL */
