/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <assert.h>
#include "mMigrateUtil.h"

#include "FMDB_OwnerManager.h"
#include "FMDB_LoadBalancer.h"
#include "mAttachableDataContainer.h"
#include "mPart.h"
#include "mEntity.h"
#include "mException.h"
#include "mEdge.h"
#include "mVertex.h"
#include "mRegion.h"
#include "ParUtil.h"
#include "FMDB_Internals.h"
#include "FMDBInternals.h"
#include "oldFMDB.h"
#include "FMDB_cint.h"
#ifdef FMDB_PARALLEL
#include "mExchangeData.h"
#endif
#include "pmGraphs.h"
#include "mFMDB.h"
#include <list>

using std::list;
using std::cout;
using std::endl;
using std::cerr;
using std::vector;

void mEntity::getAllEntitiesOfAllDimensions_oneLevel(std::set<mEntity*> &family)
{
  int n = getLevel();
  // insert self
  family.insert(this);
  mEntity* fc;
  mEntity* eg;
  mEntity* vt;
  if (n==3)
  {
    for (int i=0; i<size(2);++i)
    {
      fc=get(2,i);
      family.insert(fc);
      for (int j=0;j<fc->size(1);++j)
      {
        eg = fc->get(1,j);
        if (family.find(eg) == family.end())
           family.insert(eg);
        for (int k=0; k<2; ++k)
        {
          vt = eg->get(0,k);
          if (family.find(vt) == family.end())
           family.insert(vt);
        } // vt
      } // eg
    } // fc
  }
  else if (n==2) //2D mesh
  {
    for (int j=0;j<size(1);++j)
    {
      eg = get(1,j);
      family.insert(eg);
      for (int k=0; k<2; ++k)
      {
         vt = eg->get(0,k);
         if (family.find(vt) == family.end())
           family.insert(vt);
      } // vt
    } // eg
  }
}

void removeEntities(mPart* mesh, int dim,
                    std::list<mEntity*>& toRemove)
{
#ifdef FMDB_PARALLEL
  std::list<mEntity*>::iterator biter;
  if (dim>0)
    for (biter=toRemove.begin(); biter!=toRemove.end();++biter)
      mesh->DEL_oneLevel(*biter);
  else
    for (biter=toRemove.begin(); biter!=toRemove.end();++biter)
      mesh->DEL(*biter);
#endif
}

/*
#ifdef FMDB_PARALLEL
class IB_DataExchanger : public FMDB_DataExchanger
{
public :
  virtual int tag() const;
  virtual void * AP_alloc_and_fill_buffer (mEntity *e, FMDB_SharedInfo &si, int);
  virtual void receiveData (int pid, void *buf);   
};

int IB_DataExchanger :: tag () const
{
  return 11132;
}

void * IB_DataExchanger :: AP_alloc_and_fill_buffer (mEntity *e, FMDB_SharedInfo &si, int d_tag)
{
  int nbDests = getNbDests(e);

  char *buf= (char*) AP_alloc(si.pid(), d_tag,
		        (sizeof(mEntity*) + (nbDests+1) * sizeof(int)) );  
   
  mEntity *l = si.getRemotePointer();

  memcpy(buf,&l,sizeof(mEntity*));
  int *dests = (int*)malloc((nbDests+1)*sizeof(int));
  dests[0] = nbDests;
  for(int i=1;i<=nbDests;i++)dests[i] = getDest(e,i-1);
  memcpy(&buf[sizeof(mEntity*)],dests,(nbDests+1)*sizeof(int));
  
  free(dests);
  return buf;
}

void IB_DataExchanger :: receiveData (int from, void *buf)
{
  char *mybuf = (char*) buf;
  mEntity *e;
  memcpy(&e,mybuf,sizeof(mEntity*));
  int nbDests;
  memcpy(&nbDests,&mybuf[sizeof(mEntity*)],sizeof(int));
  int *dests = (int*)malloc((nbDests+1)*sizeof(int));
  memcpy(dests,&mybuf[sizeof(mEntity*)],(nbDests+1)*sizeof(int));

  for(int i=1;i<=nbDests;i++)
    {
      markAllSubs(e, true, dests[i]);
      //cout<<"("<<M_Pid()<<") IB_DataExchanger::recieveData::markAllSubs("<<e->getUid()<<","<<true<<","<<dests[i]<<endl;

    }
  free (dests);
}
#endif
*/

bool isEntityOnCurrentProcessor (mEntity *e, int currentProcessor )
{
  if (currentProcessor < 0)return true; 
  int N = getNbDests (e);
  for (int i=0;i<N;i++)
    {
      if (currentProcessor == getDest(e,i))return true;
    }
  return false;
}

void printEntity (mEntity *e)
{
  printf ("Processor %d\n",ParUtil::Instance()->rank());
  e->print();
  printf ("%d dests = ",getNbDests(e));
  for (int i=0;i<getNbDests(e);i++)
    {
      printf ("%d ", getDest(e,i));      
    }
  printf("\n");
}
/*static int getDest(mEntity *e, int i)
{
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");
  if(e->getData(tagMark))
    {
      mAttachableIntVector *avec;
      avec = (mAttachableIntVector*)e->getData(tagMark);
      return avec->v[i];
    }
  else
    {
      return -1;
    }
}

static int getNbDests(mEntity *e)
{
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");
  if(e->getData(tagMark))
    {
      mAttachableIntVector *avec;
      avec = (mAttachableIntVector*)e->getData(tagMark);
      return avec->v.size();
    }
  else
    {
      return 0;
    }
}
*/

mCommonBdry *mPart::getInterprocessorCommonBdry( int nbProcs, int *procs , int dim )
{
/*
  int gid = theOwnerManager->find(nbProcs,procs);

  if (nbProcs == 1) return 0;
  
  if(gid)
    {      
      for(cbiter it = cbbegin();it != cbend(); ++it)
	{
	  mCommonBdry *g = (*it);
	  if(g->getId() == gid)
	    {
	      return g;
	    }
	}      
    }
  else
    {
      gid = theOwnerManager->create(nbProcs,procs);
      mCommonBdry *newg = getCommonBdry(gid,dim);
      return newg;
    }
*/
  return 0;
}

void mPart::ParallelReclassifyMeshEntities (int n)
{
/*
#ifdef FMDB_PARALLEL  
  //allCommonBdries.clear();
  int parts[1024];
  for(int DIM=0; DIM<=3; DIM++)
    {
      for(iter it = begin(DIM) ; it!= end(DIM) ; ++it)
	{
	  mEntity *e = *it;
	  
	  e->setCommonBdry((mCommonBdry*)0);
	  
	  int nbDests = getNbDests(e);	  
//          cout<<"("<<M_Pid()<<") ParallelReclassify - "<<e->getUid()
//              <<" nbDests = "<<nbDests<<"\n";
	  for(int i=0;i<nbDests;i++)
	    {
	      parts[i] = getDest(e,i);
	    }	      
//          cout<<"("<<M_Pid()<<") ParallelReclassifyMeshEntities "<<e->getUid()
//              <<"(nbDests ="<<nbDests<<endl;
	  e->setCommonBdry(getInterprocessorCommonBdry(nbDests,parts, e->getLevel()));
	}
    }
#endif
  return;
*/
}

// ***********************************************************
void mPart::setCB_and_collectEntitiesToRemove(int n,
                                 list<mEntity*>& vtToRemove, 
                                 list<mEntity*>& egToRemove,
                                 list<mEntity*>& fcToRemove)
// ***********************************************************
{
/*
#ifdef FMDB_PARALLEL  
  //allCommonBdries.clear();
  int parts[1024];
  bool toRemove;
  int pid;
  int myPE = ParUtil::Instance()->rank();
  int mDim=getDim();
// partition object
// do we need this? NO
//  for(iter it = begin(mDim) ; it!= end(mDim) ; ++it)  
//  {
//    e->setCommonBdry((mCommonBdry*)0);
//  }
  
  for(int DIM=0; DIM<mDim; DIM++)
  {
    for(iterall it = beginall(DIM) ; it!= endall(DIM) ; ++it)
    {
      mEntity *e = *it;
	  
//      e->setCommonBdry((mCommonBdry*)0);
	  
      int nbDests = getNbDests(e);	  
//      for (int i=0; i<nbDests;++i)
//        if (getDest(e,i)!=ParUtil::Instance()->rank())
//          cout<<"("<<M_Pid()<<") "<<e->getUid()
//              <<" dest p="<<getDest(e,i)<<"\n";
      toRemove=true;  
      for(int i=0;i<nbDests;i++)
      {
        pid=getDest(e,i);
	parts[i] = pid;
	if (pid==myPE)
	  toRemove=false;
	
      }	      
//          cout<<"("<<M_Pid()<<") ParallelReclassifyMeshEntities "<<e->getUid()
//              <<"(nbDests ="<<nbDests<<endl;
      e->setCommonBdry(getInterprocessorCommonBdry(nbDests,parts, e->getLevel()));

      if (toRemove)
      {
	switch(e->getLevel())
        {
          case 0: vtToRemove.push_front(e); break;
          case 1: egToRemove.push_front(e); break;
          case 2: fcToRemove.push_front(e); break;
          default: break;
        }
      }
    }
  }
  vtToRemove.unique();
  egToRemove.unique();
  fcToRemove.unique();    
#endif
  return;
*/
}

void CreateMigrationVectors (mPart *theMesh,
				    int *partitionVector, 
				    int delta_id,
				    int from,
				    int levelMin,
				    list<mEntity *> &toDelete, 
				    int nbProcs,
				    int strategy)
{
/*
  int *perproc = new int[nbProcs];
  
  int part;
  int k1(0),k2(0);
 
  for(mPart::iterall it = theMesh->beginall(from) ; it!= theMesh->endall(from) ; ++it)
    {
      mEntity *e = *it;

      k1++;
      for(int i=0;i<nbProcs;i++)perproc[i] = 0;
      if(theMesh->getRefinementLevel(e) == levelMin)
	{
	  int imax = 0;
	  if(strategy == 1 && e->getData(FMDB_Util::Instance()->getId()))
	    {
	      int id = e->getAttachedInt(FMDB_Util::Instance()->getId()) - delta_id;
	      imax = partitionVector[id];
	    }
	  else
	    {
	      list<mEntity *>leaves;
	      e->getLeaves(leaves);
	      for(list<mEntity*>::const_iterator it2 = leaves.begin();it2 != leaves.end();++it2)
		{
		  mEntity *leaf = *it2;
//                  printf("\t(%d) leaf=%s\n",M_Pid(),leaf->getUid());
		  int id = leaf->getAttachedInt(FMDB_Util::Instance()->getId()) - delta_id;
		  part = partitionVector[id];
		  perproc[part]++;
//                  printf("\t(%d) leaf=%s, id=%d, part=%d\n",M_Pid(),leaf->getUid(), id, part);
		}
	      int max = perproc[0];
	      //	      printf("perproc : ");
	      for(int i=1;i<nbProcs;i++)
	      {
	  //		  printf ("%d ",perproc[i]);
	        if(perproc[i]>max)
	        {
	          max = perproc[i];
	          imax = i;
	        }
	      }	    
	      for(list<mEntity*>::const_iterator it2 = leaves.begin();it2 != leaves.end();++it2)
	      {
	        mEntity *leaf = *it2;
	        int id = leaf->getAttachedInt(FMDB_Util::Instance()->getId()) - delta_id;
	        partitionVector[id] = imax;
//                printf("\t(%d) partitionVector[%d]=%d\n", M_Pid(), id, imax);
	      }	
	    }
	  markAllSubs(e,true,imax);
//          cout<<"("<<M_Pid()<<") markAllSubs("<<e->getUid()
//              <<","<<true<<","<<imax<<endl;

	  list<mEntity *>subs;
	  e->getAllSubTree(subs);
	  //  printf("subtree is %d\n",subs.size());
	  for(list<mEntity*>::const_iterator it2 = subs.begin();it2 != subs.end();++it2)
	    {
	      k2++;
	      mEntity *sub = *it2;
	      if(ParUtil::Instance()->rank() != imax)
		toDelete.push_back(sub);
	    }
	}
    }    
    //complete information with a round of communications
  
  if(k1!=k2)
    ParUtil::Instance()->Msg(ParUtil::ERROR," in file %s line %d\n",__FILE__,__LINE__);
  //  ParUtil::Instance()->Msg(ParUtil::WARNING," exchangin starts\n");
#ifdef FMDB_PARALLEL
  IB_DataExchanger myCallback;
  theMesh->exchangeDataOnPartBdrys (myCallback);  
  //  ParUtil::Instance()->Msg(ParUtil::WARNING," exchangin ends\n");
#endif
  delete [] perproc;
*/
}

void CreateMigrationVectors_oneLevel(mPart *theMesh,
                                    int *partitionVector,
                                    int delta_id,
                                    int from,
                                    int levelMin,
                                    list<mEntity *> &toDelete,
                                    int nbProcs)
{
  int part; 
  for(mPart::iterall it = theMesh->beginall(from) ; it!= theMesh->endall(from) ; ++it)
  {      
    mEntity *e = *it;
    int id = e->getAttachedInt(FMDB_Util::Instance()->getId()) - delta_id;
    part = partitionVector[id];
    markAllSubs_oneLevel(e,true,part);
    if (ParUtil::Instance()->rank()!=part)
      toDelete.push_back(e);
  }
}

// ***********************************************************
void computePartitionVector(mPart* pm,
                           int* partitionVector)
// ***********************************************************
{
// this must be updated to use find function
// BUILD A NEW PARTITION VECTOR
  unsigned int tagMark=FMDB_Util::Instance()->lookupMeshDataId("_pid");
  
  int dim=M_globalMaxDim(pm);
  mPart::iterall it=pm->beginall(dim);
  int idx=0;
  for (; it!=pm->endall(dim);++it,++idx)
  {
    if ((*it)->getData(tagMark))
    {
      partitionVector[idx]=(*it)->getAttachedInt(tagMark);
      (*it)->deleteData(tagMark);
    }
    else
      partitionVector[idx]=ParUtil::Instance()->rank();
  }
}

// ***********************************************************
void setEntitiesToMoveFromVertices(mPart* mesh, 
                   list<mEntity*>& entities)
// ***********************************************************
{
/*
  // get the entities to move and their owner processor
  unsigned int tagMark=FMDB_Util::Instance()->lookupMeshDataId("_pid");
  int dim=M_globalMaxDim(mesh);
  mEntity* ent;
  mEntity* vt;
  int owner;
  list<mEntity*>::iterator vit=entities.begin();
  for (; vit!=entities.end();++vit)
  {
    mEntity* v = *vit;
   mAdjacencyContainer upward;
    v->getHigherOrderUpward (dim,upward);
    int owner = v->getCommonBdry()->getOwner();
    for (int i=0; i<upward.size();++i)
    {
      mRegion* r = (mRegion*) upward[i];
      if (r->getData(tagMark))
      {  
        if (r->getAttachedInt(tagMark)>owner)
        {
          r->deleteData(tagMark);
          r->attachInt(tagMark,owner);
        }
      }
      else
      {
        r->attachInt(tagMark,owner);
      }
    } //upward
  } // vit
*/
}

/*
// ***********************************************************
void setEntitiesToMoveFromEdges(mPart* mesh, 
   		list<mEntity*>& entities)
// ***********************************************************
{
  // get the entities to move and their owner processor
  unsigned int tagMark=FMDB_Util::Instance()->lookupMeshDataId("_pid");
  vector<mEntity*> tempEnt;
  vector<int> pids;

  mEntity* e;
  mEntity* entityToMove;
  int owner;
  int dim=M_globalMaxDim(mesh);

  FMDB_OwnerManager* o = mesh->theOwnerManager;
  FMDB_OwnerManager::iter oit, oitend;
  int* sendcounts = new int[ParUtil::Instance()->size()];
  for (int i=0; i<ParUtil::Instance()->size(); ++i) sendcounts[i]=0;
  
  list<mEntity*>::iterator eit=entities.begin();
  for (; eit!=entities.end();++eit)
  {
    e = *eit;
    mAdjacencyContainer upward;
    e->getHigherOrderUpward (dim,upward);
    owner = e->getCommonBdry()->getOwner();
    for (int i=0; i<upward.size();++i)
    {
      mEntity* entityToMove = upward[i];
      if (!entityToMove->getData(tagMark))
      {  
        entityToMove->attachInt(tagMark,owner);
      }
      else // entityToMove is already marked
      { // case I: already marked and the owner is greater and the edge is not on CB
        //         reset all the adj regions of the edge
        if (!e->getCommonBdry())// internal edge
        {
	  if (entityToMove->getAttachedInt(tagMark)>owner)
  	  {  
	    tempEnt.push_back(e); 
	    pids.push_back(owner); 
	  }
	  else
  	  { 
	    tempEnt.push_back(e); 
	    pids.push_back(entityToMove->getAttachedInt(tagMark));}
	  break;  // jump to the next edge      
	}
        else // if (e->getCommonBdry())
	{
          if (entityToMove->getAttachedInt(tagMark)>owner)
  	  { 
            entityToMove->deleteData(tagMark);
	    entityToMove->attachInt(tagMark,owner);
	  }

          // one round of communication to double-check counterpart
          oit=o->begin(e);
 	  oitend=o->end(e);
          while (oit!=oitend)
          { FMDB_SharedInfo si = (*oit).second;
	    //if (si.pid()>ParUtil::Instance()->rank())
	    {
	      void* buf = AP_alloc(si.pid(), 4999, sizeof(rp_int));
              rp_int* castbuf = (rp_int *)buf;
              castbuf->entity = si.getRemotePointer();
  	      castbuf->i = owner;
              AP_send(buf);
              sendcounts[si.pid()]++;
              ++oit;
	    }
          } // while oit
        } // else 
      } // else already marked
    }  // for upward
  } // for eit

  // receive phase begins
  AP_check_sends(AP_NOFLAGS);
  AP_reduce_nsends(sendcounts);
  int message=0;
  int count;
  bool flag;

  while(!AP_recv_count(&count) || message<count)
  {
    void* msg;
    int from, tag, size, rc;
    rc = AP_recv(MPI_ANY_SOURCE, 4999, AP_BLOCKING|AP_DROPOUT, &msg, &size, &from, &tag);
    if (rc)
    {
      message++;
      rp_int* castbuf = (rp_int*) msg;
      e=castbuf->entity;
      if (M_OwnerProc(mesh,e)>castbuf->i)
      {
        tempEnt.push_back(e);
	pids.push_back(castbuf->i);
      }	
      AP_free(msg);
    }  // end of if (rc)
  }  // end of while(!AP...)
 
  AP_check_sends(AP_WAITALL);
  delete[] sendcounts;	
  
  for (unsigned int i=0; i<tempEnt.size();++i)
  {
    e = tempEnt[i];
    owner=pids[i];
    mAdjacencyContainer upward;
    e->getHigherOrderUpward (dim,upward);
    for (int j=0; j<upward.size();++j)
    {
      entityToMove = upward[j];
      if (!entityToMove->getData(tagMark))
  	entityToMove->attachInt(tagMark,owner);
      else
      { 
        if (entityToMove->getAttachedInt(tagMark)>owner)
	{
	  entityToMove->deleteData(tagMark);
	  entityToMove->attachInt(tagMark, owner);
	}
      }
    }
  }
}


// ***********************************************************
void setEntitiesToMove(mPart* mesh, 
		list<mEntity*>& entities,int ent_dim)
// ***********************************************************
{
  switch (ent_dim)
  {
    case 0: //setEntitiesToMoveFromVertices_withBalance(mesh,entities);
            setEntitiesToMoveFromVertices(mesh,entities);
            break;
    case 1: setEntitiesToMoveFromEdges(mesh,entities);
           break;
    default: cerr<<"Not defined for dim "<<ent_dim<<endl;
             break;
  }
}
*/
	    
// return TRUE if the attached data to entity should be removed 
// on this processor after migration, otherwise, return FALSE
bool canDeleteAttachedData(mEntity* ent, int dest_proc)
{
  if (M_NumPE()==1)
    return false;
 
  int nbDests = getNbDests(ent);
  bool retVal = true;
  for (int i=0; i<nbDests;++i)
  {
    int dest=getDest(ent,i);
    if (dest==ParUtil::Instance()->rank() 
       || (dest==dest_proc && i<nbDests-1))
      retVal = false;
  }
  return retVal;
}


