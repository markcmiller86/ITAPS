/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "pmEntity.h"
#include "ParUtil.h"
#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <assert.h>

using std::set;
using std::cout;
using std::endl;
using std::vector;
using std::list; 

bool pmEntityLessThanKey::operator() (pmEntity* cb1, pmEntity* cb2) const
{
  if(cb1->getId() < cb2->getId())return true;
  if(cb1->getId() >= cb2->getId())return false;
  return false;
}

pmEntity::pmEntity(int id, set<int>& bps, int dim)
{
  iD = id;
  level = dim;
  owner=-1;
  numClassifiedEnts = 0;
  for (set<int>::iterator it=bps.begin(); it != bps.end(); ++it)
    BPs.insert(*it);
}

bool pmEntity::isEqual(set<int>& bpSet)
{
  if (BPs.size()!=bpSet.size())
    return false;
  set<int>::iterator it1 = BPs.begin();
  set<int>::iterator it2 = bpSet.begin();
  for (; it1!=BPs.end();++it1, ++it2)
  {
    if ((*it1) != (*it2))
      return false;
  }
  return true;
}

void pmEntity::setOwner(std::vector<int>& allSortedPids)
{
  vector<int>::iterator vit;
  set<int>::iterator where;
  for (vit=allSortedPids.begin(); vit!=allSortedPids.end();++vit)
  {
    where = BPs.find(*vit);
    if (where==BPs.end())
      continue;
    owner = *vit;
    return;
  }
  assert(false);  // if reach this line, error!
}

int pmEntity::setOwner(std::list<int>& allSortedPids)
{
  list<int>::iterator vit;
  set<int>::iterator where;
  for (vit=allSortedPids.begin(); vit!=allSortedPids.end();++vit)
  {
    where = BPs.find(*vit);
    if (where==BPs.end())
      continue;
    owner = *vit;
    return 1;
  }
   return 0; 
}

void pmEntity::print()
{
  cout<<"("<<ParUtil::Instance()->rank()<<") PE iD="<<iD<<", BPs=(";
  for (BPIter it=bpBegin(); it!=bpEnd(); ++it)
    cout<<*it<<",";
  cout<<"), dim="<<level<<", owner="<<owner<<endl;
}
  
void pmEntity::getBPs(vector<int>& bps)
{
  std::copy(bpBegin(),bpEnd(),back_inserter(bps));
}

