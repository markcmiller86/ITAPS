/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#include "pmModel.h"
#include "ParUtil.h"
#include "pmModelUtil.h"
#include "pmEntity.h"

#include <assert.h>
#include <iostream>
#include <set>
#include <vector>
#include <algorithm>
#include <iterator>
#include <list>

using std::list; 
using std::vector;
using std::set;
using std::cout;
using std::endl;

std::auto_ptr<pmModel> pmModel::instance;

pmModel::pmModel() 
{
  isUptodate=false;
  pmEntId = 0;
}
  
pmModel::~pmModel()
{ 
  PEIter peit=peBegin();
  for(; peit!=peEnd(); ++peit)
  {
    delete (*peit);
  }
  allPEntities.clear();
  for (int i=0; i<4;++i)
    allCBEntities[i].clear();
}
  
pmModel* pmModel::Instance()
{
  if(!instance.get())
    instance.reset(new pmModel);
  return instance.get();
}

pmEntity* pmModel::getPartitionEntity(set<int>& bps)
{
  if (bps.size() < 2)
     return (pmEntity*)0;
     
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
  {
    if ((*it)->isEqual(bps))
      return (*it);
  }
  pmEntId++;
  pmEntity* newPE = new pmEntity(pmEntId, bps, 0);
  allPEntities.insert(newPE);
  return newPE;
}

pmEntity* pmModel::getPartitionEntity(int id)
{
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
  {
    if ((*it)->getId()==id)
      return (*it);
  }
  return (pmEntity*)0;
}


// this function should be called whenever mesh partitioning changes
void pmModel::updateOwnership()
{
  vector<int> sortedPids;
  getSortedPids_poor_to_rich_comm(mesh, sortedPids);

  PEIter peit=peBegin();

  for(; peit!=peEnd(); ++peit)
  {
    (*peit)->setOwner(sortedPids);
  }

  isUptodate = false; 
}

void pmModel::updateOwnership(vector<mPart*> meshes)
{
  list<int> allSortedPids;
  list<int>::iterator pidIter;
  getSortedPids_poor_to_rich(meshes,allSortedPids);
  
#ifdef DEBUG_
    if (ParUtil::Instance()->master()){  
      cout<<"\t* POOR TO RICH PIDS: ";
      for (pidIter=allSortedPids.begin(); pidIter!=allSortedPids.end();++pidIter) 
        cout<<"P"<<*pidIter<<" -> ";
      cout<<"\n";
    }
#endif 

  PEIter peit=peBegin();
  for(; peit!=peEnd(); ++peit) 
     (*peit)->setOwner(allSortedPids);
  
  isUptodate = false; 
}


void pmModel::clean_up()
{
  PEIter peit = peBegin();
  PEIter petmpit;

  while(peit != peEnd())
  {
    if ((*peit)->numCE() == 0)
    {
      petmpit = peit;

      peit++;
      delPEntity(petmpit);
    }
    else
    {
      peit++;
    }
  }

  isUptodate = false;
}


void pmModel::update()
{
  if (isUptodate || ParUtil::Instance()->size()==1) return;

  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  update PARTITION MODEL ***\n");	  

// STEP 1: clear containers
  for (int d=0; d<4;++d)
    allCBEntities[d].clear();
  BPs.clear();

// STEP 2: update allCBEntities
  int numPtn = ParUtil::Instance()->size();
  bool* isBound = new bool[numPtn];
  for (int i=0; i<numPtn;++i) isBound[i]=false;
  mEntity* ent;
  
  mPart::iterall it;
  for (int d = 0; d<mesh->getDimension();++d)
  {
    for (it=mesh->beginall(d); it!=mesh->endall(d);++it)
    {
      ent = *it;
      if (ent->getPClassification())  // CB entity
      { 
        allCBEntities[d].push_back(*it);
        if (d==0) // mesh vertex
          for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter)
	    isBound[rciter->first]=true;
      }
    }
  }

// STEP 3: update BPs
  for (int i=0; i<numPtn;++i)
    if (isBound[i]) BPs.push_back(i);
    
  delete [] isBound;  

// STEP 4: set isUptodate true
  isUptodate=true;  
}


void pmModel::setNbrPTs()             // does not include global pids on current process
{
  int mypid = ParUtil::Instance()->rank();
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  
  nbrPTs.clear();
  nbrPids.clear();
  PEIter it=peBegin();
  std::set<int>::iterator pt;
  for (; it!=peEnd(); ++it)
  {
    pt = (*it)->bpBegin();
    for (; pt != (*it)->bpEnd(); ++pt)
      if ( (*pt)/numPart != mypid)
      {
        nbrPTs.insert(*pt);
        nbrPids.insert((*pt)/numPart);
      }
  }
}

void pmModel::getNbrPTs(set<int>& nbps)
{
  nbps.clear();
  NBPIter it = nbpBegin();
  for (; it != nbpEnd(); ++it)
    nbps.insert(*it);
}

void pmModel::getNbrPids(set<int>& nbpids)
{
  nbpids.clear();
  set<int>::iterator it = nbrPids.begin();
  for (; it != nbrPids.end(); ++it)
    nbpids.insert(*it);
}

void pmModel::nbrPTprint()
{
  int mypid = ParUtil::Instance()->rank();
  cout<<"("<< mypid <<"): ["<< getNumNbrPTs() <<"] PE NBPs=(";
  for (NBPIter it=nbpBegin(); it!=nbpEnd(); ++it)
    cout<<*it<<",";
  cout<<"),"<<endl;
}

void pmModel::PMEntsPrint()
{
  int mypid = ParUtil::Instance()->rank();
  PEIter it=peBegin();
  std::set<int>::iterator pt;
  cout<<"PEs of PID ("<< mypid <<"):";
  for (; it!=peEnd(); ++it)
  {
    cout << "PID "<< mypid << "'s PE has " << (*it)->getNumBPs() << " BPs with "<< (*it)->numCE() <<" clssfd ents: (";
    pt = (*it)->bpBegin();
    for (; pt != (*it)->bpEnd(); ++pt)
      cout<<*pt<<",";
    cout<<"),";      
  }
  cout << endl;
}


pmModel::BPIter pmModel::bpBegin()
{ 
  assert(isUptodate);
  return BPs.begin(); 
}

pmModel::BPIter pmModel::bpEnd()
{ 
  assert(isUptodate);
  return BPs.end(); 
}

pmModel::CBIter pmModel::cbBegin(int dim)
{  
  assert(dim>=0 && dim<=mesh->getDimension());
  assert(isUptodate);
  return allCBEntities[dim].begin();  
}

pmModel::CBIter pmModel::cbEnd(int dim)
{ 
  assert(dim>=0 && dim<=mesh->getDimension());
  assert(isUptodate);
  return allCBEntities[dim].end();  
}

void pmModel::getCBEntities(int dim, vector<mEntity*>& cbEntities)
{
  if (ParUtil::Instance()->size()==1) return;
  assert(dim>=-1 && dim<=mesh->getDimension());

  if (!isUptodate) 
  { 
    update();
  }
  if (dim==-1)
  {  
    for (int d=0; d<mesh->getDimension();++d)
      std::copy(cbBegin(d), cbEnd(d), std::back_inserter(cbEntities));
  }
  else
    std::copy(cbBegin(dim), cbEnd(dim), std::back_inserter(cbEntities));
}

void pmModel::getRPClassification(pmEntity* pe, vector<mEntity*>& entities)
{ 
  if (!isUptodate)   
    update();
  ParUtil::Instance()->Msg(ParUtil::WARNING,"Reverse PClassification is not implemented yet\n");
}

void pmModel::print()
{
  PEIter it=peBegin();
  for (; it!=peEnd(); ++it)
    (*it)->print();
}
#endif /* FMDB_PARALLEL */
