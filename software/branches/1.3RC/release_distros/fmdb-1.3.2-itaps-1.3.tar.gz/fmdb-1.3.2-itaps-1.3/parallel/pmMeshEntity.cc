/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <map>
#include <set>
#include <algorithm>
#include <assert.h>
#include <vector>

#include "mEntity.h"
#include "pmEntity.h"
#include "pmModel.h"
#include "ParUtil.h"

using std::copy;
using std::map;
using std::cout;
using std::endl;
using std::set;
using std::vector;

int mEntity::getOwner()
{
#ifdef FMDB_PARALLEL
  if (thePClassification)
    return thePClassification->getOwner();
  else 
    return ParUtil::Instance()->rank();
#else
  return 0;
#endif    
}


void mEntity::setPClassification(pmEntity* pe)
{
#ifdef FMDB_PARALLEL
  if (thePClassification == pe)
    return;
  if (pe != (pmEntity*)0)
  {
    pe->in_numCE();
  }
  if (thePClassification != (pmEntity*)0 && thePClassification != pe)
  {
    thePClassification->de_numCE();
  }
  thePClassification = pe;
#endif  
}

pmEntity* mEntity::getPClassification()
{
#ifdef FMDB_PARALLEL
  if(thePClassification!=0) 
    return thePClassification;
  else
#endif
    return (pmEntity*)0;
}


#ifdef FMDB_PARALLEL
void mEntity::printPC()
{
  cout<<"("<<ParUtil::Instance()->rank()<<") PC of "<<getUid()<<": ";
  getPClassification()->print();
}
void mEntity::printBPs()
{
    if(tempBPs==NULL) 
      return; 
  cout<<"("<<ParUtil::Instance()->rank()<<") BP of "<<getUid()<<": ";
  for (mEntity::BPIter bpiter=bpBegin(); bpiter!=bpEnd();++bpiter)
    cout<<*bpiter<<",";
  cout<<endl;  
}

void mEntity::printGPs()
{
    if(tempGPs==NULL)
      return;
  cout<<"("<<ParUtil::Instance()->rank()<<") BP of "<<getUid()<<": ";
  for (mEntity::GPIter gpiter=gpBegin(); gpiter!=gpEnd();++gpiter)
    cout<<*gpiter<<",";
  cout<<endl;
}

void mEntity::printRCs()
{
  if(theRemoteCopies==NULL)
   return; 
  cout<<"("<<ParUtil::Instance()->rank()<<") RC of "<<getUid()<<": ";
  for (mEntity::RCIter rciter=rcBegin(); rciter!=rcEnd();++rciter)
    cout<<"(P"<<rciter->first<<","<<rciter->second<<"), ";
  cout<<endl;  
}

void mEntity::printGCs()
{
  if(theGhostCopies==NULL)
   return;
  cout<<"("<<ParUtil::Instance()->rank()<<") GC of "<<getUid()<<": ";
  for (mEntity::GCIter gciter=gcBegin(); gciter!=gcEnd();++gciter)
    cout<<"(P"<<gciter->first<<","<<gciter->second<<"), ";
  cout<<endl;
}

void mEntity::setPClassificationWithBPs()
{
 if(tempBPs==NULL) {
   thePClassification = (pmEntity*)0;
   return;
 }

if (tempBPs->size() <= 1)
    thePClassification = (pmEntity*)0;
  else
  {
    pmEntity *pe = pmModel::Instance()->getPartitionEntity(*tempBPs);
    setPClassification(pe);
  }
}

void mEntity::getPidsExist(std::set<int>& pids)          // without current part id in MtoN
{
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();
  if(numPart==tgtNumPart && numPart==1)
    pids.insert(ParUtil::Instance()->rank());

   if(theRemoteCopies==NULL)
     return;

  for (mEntity::RCIter rcIter=rcBegin(); rcIter!=rcEnd();++rcIter)
    pids.insert(rcIter->first);
}

int mEntity::getMinPidExist()                            // without current part id in MtoN
{
  vector<int> pids;
  getPidsExist(pids);
  vector<int>::iterator minit=std::min_element(pids.begin(),pids.end());
  return *minit;
}

void mEntity::getPidsExist(std::vector<int>& pids)        // without current part id in MtoN
{
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();  
  if(numPart==tgtNumPart && numPart==1)
   pids.push_back(ParUtil::Instance()->rank());

   if(theRemoteCopies==NULL)
     return;

  for (mEntity::RCIter rcIter=rcBegin(); rcIter!=rcEnd();++rcIter)
   pids.push_back(rcIter->first);
}


mEntity* mEntity::getRemoteCopy(int pid)
{
  mEntity* remoteEnt = (mEntity*)0;

  if(theRemoteCopies==NULL)
   return remoteEnt;

  map<int,mEntity*>::iterator mapit = theRemoteCopies->find(pid);
  if (mapit!=theRemoteCopies->end())
    remoteEnt = mapit->second;
  return remoteEnt;
}

mEntity* mEntity::getGhostCopy(int pid)
{
  mEntity* ghostEnt = (mEntity*)0;

  if(theGhostCopies==NULL)
   return ghostEnt;

  map<int,mEntity*>::iterator mapit = theGhostCopies->find(pid);
  if (mapit!=theGhostCopies->end())
    ghostEnt = mapit->second;
  return ghostEnt;
}

void mEntity::getRemoteCopies(map<int, mEntity*>& remoteCopies)
{
  if(theRemoteCopies==NULL)
     return;
  assert(remoteCopies.empty());
  for (RCIter it=rcBegin(); it!=rcEnd(); ++it)
    remoteCopies.insert(remoteCopyMap::value_type(it->first, it->second));
}

void mEntity::getGhostCopies(map<int, mEntity*>& ghostCopies)
{
  if(theGhostCopies==NULL)
     return;
  assert(ghostCopies.empty());
  for (GCIter it=gcBegin(); it!=gcEnd(); ++it)
    ghostCopies.insert(ghostCopyMap::value_type(it->first, it->second));
}

void mEntity::addRemoteCopy(int pid, mEntity* remoteEnt)
{
  if(theRemoteCopies==NULL)
   theRemoteCopies = new remoteCopyMap;
  theRemoteCopies->insert(remoteCopyMap::value_type(pid, remoteEnt));
}

void mEntity::addGhostCopy(int pid, mEntity* ghostEnt)
{
//  int mypid=ParUtil::Instance()->rank();
//  cout<<"\t("<<mypid<<") "<<getUid()<<"->addRemoteCopy("<<pid<<")\n";

  if(theGhostCopies==NULL)
   theGhostCopies = new ghostCopyMap;

  theGhostCopies->insert(ghostCopyMap::value_type(pid, ghostEnt));
}

void mEntity::deleteRemoteCopy(int pid)
{
  if(theRemoteCopies==NULL)
     return;

  theRemoteCopies->erase(remoteCopyMap::key_type(pid));

  if(theRemoteCopies->empty())
     SAFE_DELETE(theRemoteCopies);
}

void mEntity::deleteGhostCopy(int pid)
{
//  int mypid=ParUtil::Instance()->rank();
//  cout<<"\t("<<mypid<<") "<<getUid()<<"->deleteRemoteCopy("<<pid<<")\n";

  if(theGhostCopies==NULL)
     return;

  theGhostCopies->erase(ghostCopyMap::key_type(pid));

  if(theGhostCopies->empty())
     SAFE_DELETE(theGhostCopies);
}

void mEntity::deleteRemoteCopy(mEntity::RCIter rciter)
{
  if(theRemoteCopies==NULL)
   return;

  theRemoteCopies->erase(rciter);

  if(theRemoteCopies->empty())
   SAFE_DELETE(theRemoteCopies);
}

void mEntity::deleteGhostCopy(mEntity::GCIter gciter)
{
  if(theGhostCopies==NULL)
   return;

  theGhostCopies->erase(gciter);

  if(theGhostCopies->empty())
   SAFE_DELETE(theGhostCopies);
}

void mEntity::clearRemoteCopies()
{
  if(theRemoteCopies==NULL)
    return;
  theRemoteCopies->clear();
}

void mEntity::clearGhostCopies()
{
  if(theGhostCopies==NULL)
    return;

  theGhostCopies->clear();
  assert(theGhostCopies->empty());
}


#endif /* FMDB_PARALLEL */
