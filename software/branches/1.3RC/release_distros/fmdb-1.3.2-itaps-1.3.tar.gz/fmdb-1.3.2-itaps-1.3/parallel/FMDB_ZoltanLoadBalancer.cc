/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#ifdef FMDB_PARALLEL
#include <stdio.h>
#include "FMDB_ZoltanLoadBalancer.h"

FMDB_ZoltanLoadBalancer::FMDB_ZoltanLoadBalancer(Algorithm algo)
  : theAlgorithm(algo)
{
}

void FMDB_ZoltanLoadBalancer::setAlgorithm(const Algorithm &algo)
{
  theAlgorithm = algo;
}


#ifdef _HAVE_PARMETIS_
#include "ParUtil.h"
#include "pmGraphs.h"
extern "C"
{
#include "parmetis.h"
void METIS_PartGraphRecursive(int *, idxtype *, idxtype *, idxtype *, idxtype *, int *, int *, int *, int *, int *, idxtype *); 
}


void FMDB_ZoltanLoadBalancer::partition(FMDB_distributed_graph &dg , 
				     int *partitionVector)
{
  int edgecut,options[4];
  // --- call ParMetis partioning routine ---
  int wgtflag;
  if(dg.theGraph->vwgt && dg.theGraph->adjwgt)wgtflag = 3;
  else if (dg.theGraph->vwgt)wgtflag = 2;
  else if (dg.theGraph->adjwgt)wgtflag = 1;
  else wgtflag = 0;

  int numflag    = 1;            //-> FORTRAN style numbering 
  options[0] = 0;                //-> default algorithm options 

//  if(ParUtil::Instance()->master())
//    dg.theGraph->print(std::cout);

  MPI_Comm comm = MPI_COMM_WORLD;

  printf("parmetis partitioning on P%d...\n",ParUtil::Instance()->rank());

  switch (theAlgorithm)
    {
    case Random:
      {
	for(int i=0;i<dg.theGraph->nn;i++)
	  partitionVector[i] = rand() % ParUtil::Instance()->size() + 1;
      }
      break;
    case Remap:
  //    if (ParUtil::Instance()->master())
        printf("(%d) call ParMETIS_RepartRemap\n",ParUtil::Instance()->rank());
      ParMETIS_RepartRemap(dg.vtxdist,
			   dg.theGraph->xadj,
			   dg.theGraph->adjncy,
			   dg.theGraph->vwgt,
			   dg.theGraph->adjwgt,
			   &wgtflag,
			   &numflag,
			   options,
			   &edgecut,
			   partitionVector,
			   &comm
			   );
      break;
    case MLRemap:
//      if (ParUtil::Instance()->master()) 
        printf("(%d) call ParMETIS_RepartMLRemap\n",ParUtil::Instance()->rank());
      ParMETIS_RepartMLRemap(dg.vtxdist,
			     dg.theGraph->xadj,
			     dg.theGraph->adjncy,
			     dg.theGraph->vwgt,
			     dg.theGraph->adjwgt,
			     &wgtflag,
			     &numflag,
			     options,
			     &edgecut,
			     partitionVector,
			     &comm
			     );
      break;
    case LDiffusion:
    //  if (ParUtil::Instance()->master()) 
        printf("(%d) call ParMETIS_RepartLDiffusion\n",ParUtil::Instance()->rank());
      ParMETIS_RepartLDiffusion(dg.vtxdist,
				dg.theGraph->xadj,
				dg.theGraph->adjncy,
				dg.theGraph->vwgt,
				dg.theGraph->adjwgt,
				&wgtflag,
				&numflag,
				options,
				&edgecut,
				partitionVector,
				&comm
				);
      break;
    case GDiffusion:
    //  if (ParUtil::Instance()->master()) 
        printf("(%d) call ParMETIS_RepartGDiffusion\n",ParUtil::Instance()->rank());
      ParMETIS_RepartGDiffusion(dg.vtxdist,
				dg.theGraph->xadj,
				dg.theGraph->adjncy,
				dg.theGraph->vwgt,
				dg.theGraph->adjwgt,
				&wgtflag,
				&numflag,
				options,
				&edgecut,
				partitionVector,
				&comm
				);
      break;
    case Serial:
      {
//	if (ParUtil::Instance()->master()) 
          printf("(%d) call METIS_PartGraphRecursive\n",ParUtil::Instance()->rank());
	FMDB_graph &g = *(dg.theGraph);
	int nbParts = ParUtil::Instance()->size();
	METIS_PartGraphRecursive(&g.nn,g.xadj,g.adjncy,g.vwgt,g.adjwgt,&wgtflag,
				 &numflag,&nbParts,options,&edgecut,
				 partitionVector); 
      }
      break;
    }
//  if (ParUtil::Instance()->master())
    printf("(%d) back from parmetis to c++\n", ParUtil::Instance()->rank());
  // back to C++
  for(int i=0;i<dg.theGraph->nn;i++)
    {
      partitionVector[i]--;
    }
}

#else
#include "mException.h"


void FMDB_ZoltanLoadBalancer::partition(FMDB_distributed_graph &theGraph , 
				     int *partitionVector)
{
  throw new mException(__LINE__,__FILE__,"FMDB must be linked with ParMETIS for using ParMETIS Load Balancing");
}

#endif
#endif

