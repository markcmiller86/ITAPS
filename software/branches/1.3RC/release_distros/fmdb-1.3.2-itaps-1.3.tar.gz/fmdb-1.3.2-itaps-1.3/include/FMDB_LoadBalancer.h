/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_LOADBALANCER_H_
#define _FMDB_LOADBALANCER_H_

class mEntity;
class FMDB_distributed_graph;
/**
   Load balancing callbacks for FMDB. User must
   derive a class form FMDB_LoadBalancerCallbacks
   if he wants to load balance a mesh. mPart::loadBalance
   takes this callback as parameter.
*/
class FMDB_LoadBalancerCallbacks
{
public :
  /// from a given graph, we retrieve a partitionVector
  virtual void partition(FMDB_distributed_graph &theGraph , int *partitionVector) = 0;
  /// do we use a weighted graph
  virtual bool useWeights() const = 0;
  /// node weight for a given mEntity
  virtual float getWeight (mEntity *) const = 0;
  /// user can create data's attached to a given mesh entity
  /// data's have size "size" 
  virtual void * getUserData (mEntity *, int dest_proc, int &size) = 0; 
  /// user has to provide a way to delete its own data (delete or free).
  virtual void deleteUserData (void *) = 0; 
  /// user recieves its data's. mEntity is now the mesh entity on the 
  /// remote side.
  virtual void recieveUserData (mEntity *, int pid, int tag, void *buf) = 0;
  virtual int nbProcs() const = 0;
};

#endif




