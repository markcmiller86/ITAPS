/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef MMIGRATEUTIL_H
#define MMIGRATEUTIL_H

#include "mPart.h"
#include "mEntity.h"
#include "mFMDB.h"
#include "mAttachableDataContainer.h"
#include "FMDB_LoadBalancer.h"
#include "mException.h"
#include <assert.h>
#include <vector>
#include <set>
#include <list>
#include "ParUtil.h"

bool isEntityOnCurrentProcessor (mEntity *e, int currentProcessor );
void printEntity (mEntity *e);
void CreateMigrationVectors (mPart *theMesh,
				    int *partitionVector, 
				    int delta_id,
				    int from,
				    int levelMin,
				    std::list<mEntity *> &toDelete, 
				    int nbProcs,
				    int strategy = 0);
void CreateMigrationVectors_oneLevel(mPart *theMesh,
                                    int *partitionVector,
                                    int delta_id,
                                    int from,
                                    int levelMin,
                                    std::list<mEntity *> &toDelete,
                                    int nbProcs);

void removeEntities(mPart*, int, std::list<mEntity*>&);
//void getSortedPids_poor_to_rich(mPart* mesh,std::vector<int>&);
int getPid_withBalance(mPart* mesh, mEntity* ent, std::vector<int>&);

#ifdef FMDB_PARALLEL
const int TAGVERTEX    = 222;
const int TAGNONVERTEX = 333;

void setEntitiesToMoveFromVertices_withBalance(mPart* mesh, 
                   std::list<mEntity*>& entities);
void computePartitionVector(mPart*, int* partitionVector) ;
void setEntitiesToMove(mPart* mesh, std::list<mEntity*>& entities,int dimToMove);
void setEntitiesToMoveFromEdges(mPart* mesh, std::list<mEntity*>& entities,int);
void setEntitiesToMoveFromVertices(mPart* mesh, std::list<mEntity*>& entities,int);

bool canDeleteAttachedData(mEntity* ent, int dest_proc);
#endif


static void attachIntVector (mEntity *e, bool mark, unsigned int mk,int part)
{
  if(!mark)
    {
      if(e->getData(mk))e->deleteData(mk);
    }
  else
    {
      mAttachableIntVector *avec;
      if(e->getData(mk))
	{
	  avec = (mAttachableIntVector*)e->getData(mk);
	}
      else
	{
	  avec = new mAttachableIntVector;
	  e->attachData(mk,avec);
	}
      for(int i=0;i<avec->v.size();i++)if(avec->v[i] == part)return;
      avec->v.push_back(part);
    }
}

/*
  e is going to be migrated
  markAllSubs tag entities that are going to be migrated
  e is initially an entity that is to be migrated, we look
  after all sub-entities and tag them also.
*/

static void markAllSubs(mEntity *e, bool mark, int part)

{
  int n = e->getLevel();
  
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");

  attachIntVector (e, mark, tagMark, part);

  std::set<mEntity*> theWholeFamily;
  e->getAllEntitiesOfAllDimensions(theWholeFamily);
  for(std::set<mEntity*>::iterator it2 = theWholeFamily.begin(); 
      it2 != theWholeFamily.end();++it2)
    {
      mEntity *sub = *it2;
      attachIntVector (sub, mark, tagMark, part);
    }
}

static void markAllSubs_oneLevel(mEntity *e, bool mark, int part)
{

  int n = e->getLevel();
 
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");
 
  attachIntVector (e, mark, tagMark, part);
 
  std::set<mEntity*> theWholeFamily;
    e->getAllEntitiesOfAllDimensions_oneLevel(theWholeFamily);
  for(std::set<mEntity*>::iterator it2 = theWholeFamily.begin();
      it2 != theWholeFamily.end();++it2)
    {
      mEntity *sub = *it2;
      attachIntVector (sub, mark, tagMark, part);
    }

}

static int getNbDests(mEntity *e)
{
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");
  if(e->getData(tagMark))
    {
      mAttachableIntVector *avec;
      avec = (mAttachableIntVector*)e->getData(tagMark);
      return avec->v.size();
    }
  else
    {
      return 0;
    }
}

static int getDest(mEntity *e, int i)
{
  unsigned int tagMark = FMDB_Util::Instance()->lookupMeshDataId("_dest");
  if(e->getData(tagMark))
    {
      mAttachableIntVector *avec;
      avec = (mAttachableIntVector*)e->getData(tagMark);
      return avec->v[i];
    }
  else
    {
      return -1;
    }
}

static void packVertices (mEntity *e, int *verts, int &k)
{
  for(int i=0;i<e->size(0);i++)
    verts[k++] = e->get(0,i)->getId();
}

#endif
