/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef _PM_MODEL_H_
#define _PM_MODEL_H_

#include "pmEntity.h"
#include "IPComMan.h"
#include <memory>
#include <iostream>
#include <set>
#include <vector>

#define GHOSTPARTID -111             // must be negative

class mPart;
class mEntity;

class pmModel
{
protected:
  static std::auto_ptr<pmModel> instance;
  mPart* mesh;
// isUptodate determines 3 things
//   1. CB entities pool is up-to-date, or not
//   2. bounding partition list is up-to-date, or not
//   3. Reverse PClassification is up-to-date, or not
  bool isUptodate;	

  // The counter for pmEntity ID number
  int pmEntId;

//  std::set<pmEntity*, pmEntityLessThanKey> allPEntities;	
  std::set<pmEntity*> allPEntities;
  std::vector<mEntity*> allCBEntities[4];
  // stores bounding partition ids of this mesh
  std::vector<int> BPs;  

  // stores neighboring parts
  std::set<int> nbrPTs;

  // stores neighboring pids
  std::set<int> nbrPids;
  
public:
//  typedef std::set<pmEntity*,pmEntityLessThanKey>::iterator PEIter; 
  typedef std::set<pmEntity*>::iterator PEIter;
  typedef std::vector<mEntity*>::iterator CBIter;
  typedef std::vector<int>::iterator BPIter;
  typedef std::set<int>::iterator NBPIter;

// constructor + destuctor
  pmModel();
  ~pmModel();
  static pmModel* Instance();

// set/get private data
  void setMesh(mPart* m) {  mesh=m; }
  bool is_uptodate() { return isUptodate; }

// update ownership of mesh entities
  void updateOwnership();
  void updateOwnership(std::vector<mPart*>);

// update partition model in 3 things
// 1. bounding partitions
// 2. pool of cb entities 
// 3. reverse PClassification
  void clean_up(); 
  void update();

// partition entities operators
  inline void addPEntity(pmEntity* pe) { allPEntities.insert(pe); if (pe->getId() > pmEntId) pmEntId = pe->getId(); }

  inline void delPEntity(pmEntity* pe) { allPEntities.erase(pe); }
  inline void delPEntity(PEIter peit) { allPEntities.erase(peit); }

  PEIter peBegin() const
  {  return allPEntities.begin();}
  PEIter peEnd  () const
  {  return allPEntities.end();}
  int getNumPEs() { return allPEntities.size(); }
  pmEntity* getPartitionEntity(std::set<int>& bps);
  pmEntity* getPartitionEntity(int id);

  void setNbrPTs();
  void getNbrPTs(std::set<int>& nbps);
  void getNbrPids(std::set<int>& nbpids);
  inline NBPIter nbpBegin() { return nbrPTs.begin(); }
  inline NBPIter nbpEnd() { return nbrPTs.end(); } 
  void nbrPTprint();
  inline int getNumNbrPTs() {return nbrPTs.size();}
  void PMEntsPrint();
  

// bounding partitions operators
  BPIter bpBegin();
  BPIter bpEnd();
  inline int bpSize() { return BPs.size(); }

// common boundary entities operators
  CBIter cbBegin(int dim);
  CBIter cbEnd(int dim);
  // returns CB entities of dimension dim
  // if dim=-1, it returns all CB entities
  void getCBEntities(int dim, std::vector<mEntity*>&);

// return reverse partition classification
  void getRPClassification(pmEntity* pe, std::vector<mEntity*>& entities);

// Misc.
  void print();

};
#endif
#endif /* FMDB_PARALLEL */
