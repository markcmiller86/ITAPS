/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MTET_H_
#define _MTET_H_

#include "mRegion.h"
class GEntity;
class mEdge;
class mVertex;
class mFace;
/**
  The mTet class implements specific
  templates for tets
*/
class mTet : public mRegion
{
protected:
  mEntity* down_adj[6];
  short int down_adj_dim; 

public:
// --- DIRECT TABLES ---
  static short int Tev[6][2];
  static short int Tfv[4][3];
  static short int Tfe[4][3];
  static short int Tve[4][2];
  static short int Tef[6][2];
  static short int Tvf[4][3];

  virtual ~mTet();
  mTet ();
  /// Special constructor with 4 vertices
  mTet (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4, GEntity *classification);
  /// Special constructor with 6 edges
  mTet (mEdge *e1, mEdge *e2, mEdge *e3, mEdge *e4, mEdge *e5, mEdge *e6, GEntity *classification);
  /// Special constructor with 4 faces
  mTet (mFace *f1, mFace *f2, mFace *f3, mFace *f4, GEntity *classification);
  /// Type is mEntity::TET
  inline mEntity::mType getType() const {return TET;}
  /// template members
  virtual int getNbTemplates (int what) const;
  /// template members
  virtual mEntity* getTemplate (int ith , int what , int with) const;
  /// Debug stuff
  virtual void print() const;
  /// Get the dimension of the entity through a static function
  /// Useful for template algorithms
  inline static int getDim () {return 3;}

     // adjacency related
  void add (mEntity* m) {} 
  void appendUnique (mEntity* m) {}
  void del (mEntity* m) {}
  int size (int what)const; 

  mEntity* get(int what, int ith)const;
  void deleteAdjacencies(int what) {}
  mEntity * find(mEntity* m) const;

  inline void setFace (mEntity* me,  int pos)
  {
     if(down_adj_dim==2)
        down_adj[pos]= me;
  }

};

#endif 
