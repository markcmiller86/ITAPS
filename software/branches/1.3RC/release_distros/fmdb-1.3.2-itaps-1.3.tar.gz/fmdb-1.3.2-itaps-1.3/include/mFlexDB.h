/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FLEXDB

#ifndef _H_M_FLEXDB_
#define _H_M_FLEXDB_

#include <map>
#include <vector>
#include <set>

#include "oldFMDB.h"
#ifdef FMDB_PARALLEL
#include "pmMigrationCallbacks.h"
#endif

class mMesh;

void print_MRM(mMesh* mesh);

void set_MRM_MSR(mMesh*, int);
void set_MRM_oneLevel(mMesh*, int);

void set_MRM_2D(mMesh* mesh, int MRM[4][4]);
void set_MRM_3D(mMesh* mesh, int MRM[4][4]);
void write_MRM(mMesh* mesh, int MRM[4][4]);
void get_MRM(mMesh* mesh, int MRM[4][4]);
void loadSms_MRM(mMesh *mesh,const char *fName, int MRM[4][4]);
void loadSerialSms_MRM(mMesh *, const char*,int MRM[4][4]);

#ifdef FMDB_PARALLEL
 void createIntEdge(mEntity* ent, mMesh* mesh);
 void createIntFace(mEntity* ent, mMesh* mesh);

// load balancing for flexible distributed mesh
void loadBalance_URR(mMesh* mesh, pmMigrationCallbacks &cb);

int migrateMeshEntities_URR(mMesh*mesh, 
                        std::map<mEntity*,int>& POtoMove,
                        std::set<mEntity*>& neighborPOs,
		        pmMigrationCallbacks& cb);

// mesh migration for flexible distributed mesh
int migration_URR(mMesh* mesh, 
                 std::map<mEntity*,int>& POtoMove,
	   	 pmMigrationCallbacks& cb, 
	         bool buildAdj=true);
void exchangeEntities_URR(mMesh* mesh, int meshDim, int,
                     pmMigrationCallbacks &cb,
		     int entDim, std::set<mEntity*>& entitiesToSend);
#endif

#endif
#endif // FLEXDB
