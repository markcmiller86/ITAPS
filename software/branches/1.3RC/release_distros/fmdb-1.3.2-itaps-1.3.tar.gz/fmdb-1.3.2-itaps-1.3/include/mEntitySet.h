/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _M_ENTITY_SET_H_
#define _M_ENTITY_SET_H_

#include <algorithm>
#include <list>
#include <string>
#include "oldFMDB.h"
#include "mAttachableDataContainer.h"
#include <cstdlib>

using std::list; 

void printEntityList(std::list<pEntity>& container);
int countEntity(std::list<pEntity>& container, pEntity ent);

template<typename Entity>
class EntitySet: public mAttachableDataContainer
{
  private:
    mMesh* mesh_instance;
    std::string name;
    std::list<EntitySet*> superset;
    std::list<EntitySet*> subset;
    std::list<EntitySet*> children;    
    std::list<EntitySet*> parents;   

    inline void _addSuper(EntitySet* otherset) 
    { superset.push_back(otherset);  }
    
    inline void _removeSuper(EntitySet* otherset) 
    { 
      typename std::list<EntitySet*>::iterator loc = std::find(superset.begin(), superset.end(), otherset);
      if (loc!=superset.end()) superset.erase(loc++);
    }
    
    inline void _addSub(EntitySet* otherset) 
    { 
      subset.push_back(otherset); 
    }

    inline void _removeSub(EntitySet* otherset) 
    { 
      typename std::list<EntitySet*>::iterator loc = std::find(subset.begin(), subset.end(), otherset);
      if (loc!=subset.end())
        subset.erase(loc++);
    }    
    
    inline void _addChild(EntitySet* otherset) 
    { children.push_back(otherset);  }
    
    inline void _removeChild(EntitySet* otherset) 
    { 
      typename std::list<EntitySet*>::iterator loc = std::find(children.begin(), children.end(), otherset);
      if (loc!=children.end()) children.erase(loc++);
    }
    
    inline void _addParent(EntitySet* otherset) 
    { 
      parents.push_back(otherset); 
    }

    inline void _removeParent(EntitySet* otherset) 
    { 
      typename std::list<EntitySet*>::iterator loc = std::find(parents.begin(), parents.end(), otherset);
      if (loc!=parents.end()) parents.erase(loc++);
    }    

  protected:
   bool islist; 

  public:
// **************************************************
// constructor & destructor
// **************************************************       
    EntitySet() {}
    EntitySet(mMesh* mesh , bool i, std::string name=std::string("noName")) 
	    : mesh_instance(mesh), name(name), islist(i) 
    { }
    ~EntitySet(); 
 
// **************************************************
// iterators
// **************************************************
    
    typedef typename std::list<EntitySet*>::iterator SubIter;
    typedef typename std::list<EntitySet*>::iterator SuperIter;
    typedef typename std::list<EntitySet*>::iterator ChildIter;
    typedef typename std::list<EntitySet*>::iterator ParentIter;
    
    SubIter subBegin() { return subset.begin(); }
    SubIter subEnd() { return subset.end(); }
    SuperIter superBegin() { return superset.begin(); }
    SuperIter superEnd() { return superset.end(); }
    ChildIter childBegin() { return children.begin(); }
    ChildIter childEnd() { return children.end(); }
    ParentIter parentBegin() { return parents.begin(); }
    ParentIter parentEnd() { return parents.end(); }

// **************************************************
// set info
// **************************************************
//    bool isRootSet() const {return false; }
    conType getContainerType() const  {return ENTITYSET; }
    inline bool isList() { return islist; }
    inline std::string getName() { return name; }
    inline mMesh* getMesh () { return mesh_instance; }

// **************************************************
// data manipulation
// **************************************************

    // add element to set
    virtual void addEntity(Entity* const& ent) = 0; 
    virtual bool existEntity(Entity* const& ent) = 0; 
    // remove element from the element set
    virtual void removeEntity(Entity* const& ent) = 0; 
    virtual int numEntity() = 0; 
    virtual int isEmpty() = 0; 
    void clear();  
// **************************************************
// super/subset relation
// **************************************************
    // one-level deep
    int numSubset(int h=-1);    
    void getSubset(std::list<void*>& subset, int,int visit_counter=0);
    
    // add EntitySet* into the subset
    inline bool isSubset(EntitySet* otherset)
    {
      if (std::find(subset.begin(), subset.end(),otherset)!=subset.end())
        return true;
      return false;
    }
    
    void addSubset(EntitySet* otherset);
    void removeSubset(EntitySet* otherset);   
// **************************************************
// parent/child relation
// **************************************************
    int numParents(int h=-1);
    int numChildren(int h=-1);
    void getParents(std::list<void*>&, int,int visit_counter=0);
    void getChildren(std::list<void*>&, int,int visit_counter=0);

    bool isChild(EntitySet* otherset)
    {  
      if (std::find(children.begin(), children.end(), otherset)!= children.end())
        return true;
      return false;
    }    
    
    void addChild(EntitySet* otherset);
    void removeChild(EntitySet* otherset);
// **************************************************
// set operation    
// **************************************************
    virtual void unite(EntitySet*, EntitySet*&) = 0; 
    virtual void subtract(EntitySet*, EntitySet*&) = 0; 
    virtual void intersect(EntitySet*, EntitySet*&) = 0;

// **************************************************
// Factory Method to create an entityset ordered/unordered
// **************************************************
   static EntitySet* createEntitySet(mMesh* mesh, int list);
   static EntitySet* createEntitySet(mPart* part, int list);
};


template<typename Entity>
EntitySet<Entity>::~EntitySet()
{
  /// if (mesh) mesh->removeEntSet(this);
  // remove this from superset container of subset
  for (SubIter siter = subBegin(); siter!=subEnd();++siter)
    (*siter)->_removeSuper(this);

  // remove this from subset container of superset
  for (SuperIter siter = superBegin(); siter!=superEnd();++siter)
    (*siter)->_removeSub(this);

  // remove this from parents container of children
  for (ChildIter citer = childBegin(); citer!=childEnd();++citer)
    (*citer)->_removeParent(this);
  children.clear();
  // remove this from children container of parents
  for (ParentIter piter = parentBegin(); piter!=parentEnd();++piter)
    (*piter)->_removeChild(this);

  // clear data container 
//  container.clear();
  subset.clear();
  parents.clear();
  children.clear();
}

template<typename Entity>
void EntitySet<Entity>::clear()
{

  // remove this from superset container of subset
  for (SubIter siter = subBegin(); siter!=subEnd();++siter)
    (*siter)->_removeSuper(this);
  subset.clear();    
  
  // remove this from subset container of superset
  for (SuperIter siter = superBegin(); siter!=superEnd();++siter)
    (*siter)->_removeSub(this);
  superset.clear();    

  // remove this from parents container of children
  for (ChildIter citer = childBegin(); citer!=childEnd();++citer)
    (*citer)->_removeParent(this);
  children.clear();
  // remove this from children container of parents
  for (ParentIter piter = parentBegin(); piter!=parentEnd();++piter)
    (*piter)->_removeChild(this);
  parents.clear();

  // clear data container 
  // container.clear();
}


template<typename Entity>
class EntitySetOrdered: public EntitySet<Entity>
{
protected:
   std::set<Entity*> container;

public:
   typedef typename std::set<Entity*>::iterator iter;

// **************************************************
// constructor & destructor
// **************************************************
    EntitySetOrdered(): EntitySet<Entity>() {EntitySet<Entity>::islist=0; }
    EntitySetOrdered(mMesh* mesh, std::string name=std::string("noName")): EntitySet<Entity>(mesh, 0){}
    ~EntitySetOrdered()  { container.clear();}
    
    iter  begin() { return container.begin(); }
    iter  end()   { return container.end(); }

    void clear();
   // get all entities in the set
    std::set<Entity*>& getContainer() { return container; }
    int numEntity() { return (int)container.size(); }
    int isEmpty() { return (container.empty())? 0:1; }

    // add element to set
    void addEntity(Entity* const& ent);

    inline bool existEntity(Entity* const& ent)
    {
     if(std::find(begin(), end(), ent)!=end()) return true;
      //binary_search(begin(), end(), ent); //this algorithm has bug
      return false;
    }

   // remove element from the element set
    void removeEntity(Entity* const& ent);

// **************************************************
// set operation
// **************************************************
    void unite(EntitySet<Entity>*, EntitySet<Entity>*&);
    void subtract(EntitySet<Entity>*, EntitySet<Entity>*&);
    void intersect(EntitySet<Entity>*, EntitySet<Entity>*&);
};


template<typename Entity>
class EntitySetUnordered: public EntitySet<Entity>
{
protected:
   std::list<Entity*> container;

public:
   typedef typename std::list<Entity*>::iterator iter;

// **************************************************
// constructor & destructor
// **************************************************
    EntitySetUnordered(): EntitySet<Entity>() { EntitySet<Entity>::islist=1; }
    EntitySetUnordered(mMesh* mesh, std::string name=std::string("noName")): EntitySet<Entity>(mesh, 1){}
    ~EntitySetUnordered()  { container.clear();}
    
    iter  begin() { return container.begin(); }
    iter  end()   { return container.end(); }

    void clear();
   // get all entities in the set
    std::list<Entity*>& getContainer() { return container; }
    int numEntity() { return (int)container.size(); }
    int isEmpty() { return (container.empty())? 0:1; }

    // add element to set
    void addEntity(Entity* const& ent);

    inline bool existEntity(Entity* const& ent)
    {
     if(std::find(begin(), end(), ent)!=end()) return true;
      //binary_search(begin(), end(), ent); //this algorithm has bug
      return false;
    }

   // remove element from the element set
    void removeEntity(Entity* const& ent);

   // **************************************************
   // set operation
   // **************************************************
       void unite(EntitySet<Entity>*, EntitySet<Entity>*&);
       void subtract(EntitySet<Entity>*, EntitySet<Entity>*&);
       void intersect(EntitySet<Entity>*, EntitySet<Entity>*&);
};


template<typename Entity>
EntitySet<Entity>* EntitySet<Entity>::createEntitySet(mMesh* mesh, int isList)
{
   if(isList)
      return new EntitySetUnordered<Entity>(mesh);
   else
      return new EntitySetOrdered<Entity>(mesh);
}

template<typename Entity>
EntitySet<Entity>* EntitySet<Entity>::createEntitySet(mPart* part, int isList)
{
   if(isList)
      return new EntitySetUnordered<Entity>(part);
   else
      return new EntitySetOrdered<Entity>(part);
}

template<typename Entity>
void EntitySetUnordered<Entity>::addEntity(Entity* const& ent)
{

  // put the entity into the container
  container.push_back(ent);                     // check redundancy
}


template<typename Entity>
void EntitySetOrdered<Entity>::addEntity(Entity* const& ent)
{
  // put the entity into the container
  container.insert(ent);
}


// remove element from the element set
template<typename Entity>
void EntitySetUnordered<Entity>::removeEntity(Entity* const& ent)
{
  // remove entity from the container
  iter loc = std::find(begin(),end(),ent);
  if(loc!=end())
  container.erase(loc++);
}


template<typename Entity>
// remove element from the element set
void EntitySetOrdered<Entity>::removeEntity(Entity* const& ent)
{
  // remove entity from the container
  iter loc = std::find(begin(),end(),ent);
  if(loc!=end())
  container.erase(loc++);
}


template<typename Entity>
void EntitySetOrdered<Entity>::clear()
{ 
   EntitySet<Entity>::clear();
   container.clear();
}

template<typename Entity>
void EntitySetUnordered<Entity>::clear()
{
   EntitySet<Entity>::clear();
   container.clear();
}


// **************************
//     subset related
// **************************

template<typename Entity>
void EntitySet<Entity>::getSubset(list<void*>&_list_, int num_hops, int visit_counter)
{
  if (subset.size()==0)
    return;
  for (SubIter sit = subBegin(); sit!=subEnd();++sit)
    if (find(_list_.begin(), _list_.end(), (void*)(*sit))==_list_.end())
    {
      _list_.push_back((void*)(*sit));
      if (visit_counter<num_hops || num_hops==-1)
       (*sit)->getSubset(_list_, num_hops, visit_counter+1);
    }
}

template<typename Entity>
int EntitySet<Entity>::numSubset(int num_hops)
{
  list<void*> _list_;
  getSubset(_list_, num_hops);
  return (int)_list_.size();
}

template<typename Entity>
void EntitySet<Entity>::addSubset(EntitySet<Entity>* otherset)
{
  if (std::find(subset.begin(), subset.end(), otherset)!=subset.end())
    return;
  _addSub(otherset);
  otherset->_addSuper(this);
}

template<typename Entity>
void EntitySet<Entity>::removeSubset(EntitySet<Entity>* otherset)
{
  _removeSub(otherset);
  otherset->_removeSuper(this);
}


// **************************
//     parents+children related
// **************************

template<typename Entity>
void EntitySet<Entity>::getParents(list<void*>& _list_, int num_hops, int visit_counter)
{
  for (ParentIter pit = parentBegin(); pit!=parentEnd();++pit)
    if (find(_list_.begin(), _list_.end(), (void*)(*pit))==_list_.end())
    {
      _list_.push_back((void*)(*pit));
      if (visit_counter<num_hops || num_hops==-1)
       (*pit)->getParents(_list_, num_hops, visit_counter+1);
    }
}

template<typename Entity>
void EntitySet<Entity>::getChildren(list<void*>& _list_, int num_hops, int visit_counter)
{
  for (ChildIter cit = childBegin(); cit!=childEnd();++cit)
  {
    if (find(_list_.begin(), _list_.end(), (void*)(*cit))==_list_.end())
    {
      _list_.push_back((void*)(*cit));
      if (visit_counter<num_hops || num_hops==-1)
       (*cit)->getChildren(_list_, num_hops, visit_counter+1);
    }
  }
}


template<typename Entity>
int EntitySet<Entity>::numParents(int num_hops)
{
  list<void*> _list_;
  getParents(_list_, num_hops);
  return (int)_list_.size();
}

template<typename Entity>
int EntitySet<Entity>::numChildren(int num_hops)
{
  list<void*> _list_;
  getChildren(_list_, num_hops);
  return (int)_list_.size();
}

template<typename Entity>
void EntitySet<Entity>::addChild(EntitySet<Entity>* otherset)
{
  if (std::find(children.begin(), children.end(), otherset)!=children.end())
    return;
  _addChild(otherset);
  otherset->_addParent(this);
}

template<typename Entity>
void EntitySet<Entity>::removeChild(EntitySet<Entity>* otherset)
{
  _removeChild(otherset);
  otherset->_removeParent(this);
}


// **************************
//     set operations
// **************************

template<typename Entity>
void EntitySetUnordered<Entity>::unite(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  // clean the result entset
  result->clear();
  assert(result->numSubset(-1)==0);

  if (otherset->isList()) // ordered (list) result
    assert(result->isList());
  else
    assert(!result->isList());

  // handle entities
   typename EntitySetUnordered<Entity>::iter diter;
   for (diter=begin(); diter!=end(); ++diter)
      result->addEntity(*diter);

  if( otherset->isList())
  {
   iter diter;
   for (diter=((EntitySetUnordered<Entity>*)otherset)->begin(); diter!=((EntitySetUnordered<Entity>*)otherset)->end(); ++diter)
    result->addEntity(*diter);
  }
  else
  {
   typename EntitySetOrdered<Entity>::iter diter;
   for (diter= ((EntitySetOrdered<Entity>*)otherset)->begin(); diter!=((EntitySetOrdered<Entity>*)otherset)->end(); ++diter)
    result->addEntity(*diter);
  }

  // handle subsets
  typename EntitySetUnordered<Entity>::SubIter siter; 
  for (siter=EntitySetUnordered<Entity>::subBegin(); siter!=EntitySetUnordered<Entity>::subEnd();++siter)
    result->addSubset(*siter);
  for (siter=otherset->subBegin(); siter!=otherset->subEnd();++siter)
    if (find(EntitySetUnordered<Entity>::subBegin(), EntitySetUnordered<Entity>::subEnd(), *siter)==EntitySetUnordered<Entity>::subEnd())
      result->addSubset(*siter);
  return;
}

template<typename Entity>
void EntitySetOrdered<Entity>::unite(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  // clean the result entset
  result->clear();
  assert(result->numSubset(-1)==0);

  assert(!result->isList());

  // handle entities
  typename EntitySetOrdered<Entity>::iter diter; 
  for (diter=begin(); diter!=end(); ++diter)
      result->addEntity(*diter);

  if( otherset->isList())
  {
   typename EntitySetUnordered<Entity>::iter diter;
   for (diter=((EntitySetUnordered<Entity>*)otherset)->begin(); diter!=((EntitySetUnordered<Entity>*)otherset)->end(); ++diter)
    result->addEntity(*diter);
  }
  else
  {
   typename EntitySetOrdered<Entity>::iter diter; 
   for (diter=((EntitySetOrdered<Entity>*)otherset)->begin(); diter!=((EntitySetOrdered<Entity>*)otherset)->end(); ++diter)
    result->addEntity(*diter);
  }

  // handle subsets
  typename EntitySetOrdered<Entity>::SubIter siter; 
  for (siter=EntitySetOrdered<Entity>::subBegin(); siter!=EntitySetOrdered<Entity>::subEnd();++siter)
    result->addSubset(*siter);
  for (siter=otherset->subBegin(); siter!=otherset->subEnd();++siter)
    if (find(EntitySetOrdered<Entity>::subBegin(), EntitySetOrdered<Entity>::subEnd(), *siter)==EntitySetOrdered<Entity>::subEnd())
      result->addSubset(*siter);
  return;
}


template<typename Entity>
void EntitySetUnordered<Entity>::subtract(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  typename list<Entity*>::iterator loc;

  // clean the result entset
  result->clear();
  assert(result->numSubset(-1)==0);

  // handle entities
  if (otherset->isList()) // ordered (list) result
  {
    assert(result->isList());
    list<Entity*> tmp_container;
    copy(((EntitySetUnordered*)otherset)->begin(), ((EntitySetUnordered*)otherset)->end(), back_inserter(tmp_container));
    for (typename list<Entity*>::reverse_iterator diter=container.rbegin();
           diter!=container.rend(); ++diter)
    {
      loc=find(tmp_container.begin(), tmp_container.end(), *diter);
      if (loc==tmp_container.end())
        ((EntitySetUnordered*)result)->getContainer().push_front(*diter);
      else
        tmp_container.erase(loc++);
    }
  }
  else // set
  {
    assert(!result->isList());
    typename  EntitySetUnordered<Entity>::iter diter; 
    for (diter=begin(); diter!=end(); ++diter)
      if (find(((EntitySetOrdered<Entity>*)otherset)->begin(), ((EntitySetOrdered<Entity>*)otherset)->end(), *diter)==((EntitySetOrdered<Entity>*)otherset)->end())
        result->addEntity(*diter);
  }

  // handle subsets
  typename  EntitySetUnordered<Entity>::SubIter siter; 
  for (siter=EntitySetUnordered<Entity>::subBegin(); siter!=EntitySetUnordered<Entity>::subEnd();++siter)
    if (find(otherset->subBegin(), otherset->subEnd(), *siter)==otherset->subEnd())
      result->addSubset(*siter);

  return;
}


template<typename Entity>
void EntitySetOrdered<Entity>::subtract(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  typename list<Entity*>::iterator loc;

  // clean the result entset
  result->clear();
  assert(result->numSubset(-1)==0);
  
  // handle entities
    assert(!result->isList());
    for (iter diter=begin(); diter!=end(); ++diter)
    {
     if(otherset->isList()) 
     {
      if (find(((EntitySetUnordered<Entity>*)otherset)->begin(), ((EntitySetUnordered<Entity>*)otherset)->end(), *diter)==((EntitySetUnordered<Entity>*)otherset)->end())
        result->addEntity(*diter);
     }
     else
     {
       if (find(((EntitySetOrdered<Entity>*)otherset)->begin(), ((EntitySetOrdered<Entity>*)otherset)->end(), *diter)==((EntitySetOrdered<Entity>*)otherset)->end())
        result->addEntity(*diter); 
      }
    }
    
  // handle subsets
  for (typename EntitySetOrdered<Entity>::SubIter siter=EntitySetOrdered<Entity>::subBegin(); siter!=EntitySetOrdered<Entity>::subEnd();++siter)
    if (find(otherset->subBegin(), otherset->subEnd(), *siter)==otherset->subEnd())
      result->addSubset(*siter);

  return;
}


template<typename Entity>
void EntitySetUnordered<Entity>::intersect(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  typename EntitySetUnordered<Entity>::iter loc;
  typename list<void*>::iterator sloc;

  result->clear();
  assert(result->numSubset(-1)==0);

  if (otherset->isList()) // ordered (list) result
    assert(result->isList());
  else
    assert(!result->isList());

  list<Entity*> tmp_container;
  if(otherset->isList())
     copy(((EntitySetUnordered<Entity>*)otherset)->begin(), ((EntitySetUnordered<Entity>*)otherset)->end(), back_inserter(tmp_container));
  else
    copy(((EntitySetOrdered<Entity>*)otherset)->begin(), ((EntitySetOrdered<Entity>*)otherset)->end(), back_inserter(tmp_container));

  for (typename EntitySetUnordered<Entity>::iter diter=begin(); diter!=end();++diter)
  {
    loc=find(tmp_container.begin(), tmp_container.end(), *diter);
    if (loc!=tmp_container.end())
    {
      result->addEntity(*diter);
      tmp_container.erase(loc++);
    }
  }

  for (typename EntitySetUnordered<Entity>::SubIter siter=EntitySetUnordered<Entity>::subBegin(); siter!=EntitySetUnordered<Entity>::subEnd();++siter)
    if (find(otherset->subBegin(), otherset->subEnd(), *siter)!=otherset->subEnd())
      result->addSubset(*siter);
  return;
}


template<typename Entity>
void EntitySetOrdered<Entity>::intersect(EntitySet<Entity>* otherset, EntitySet<Entity>*& result)
{
  typename list<Entity*>::iterator loc;
  typename list<void*>::iterator sloc;

  list<Entity*> tmp_container;
  if(otherset->isList())
     copy(((EntitySetUnordered<Entity>*)otherset)->begin(), ((EntitySetUnordered<Entity>*)otherset)->end(), back_inserter(tmp_container));
  else
     copy(((EntitySetOrdered<Entity>*)otherset)->begin(), ((EntitySetOrdered<Entity>*)otherset)->end(), back_inserter(tmp_container));

  result->clear();
  assert(result->numSubset(-1)==0);

    assert(!result->isList());

  for (typename EntitySetOrdered<Entity>::iter diter=begin(); diter!=end();++diter)
  {
    loc=find(tmp_container.begin(), tmp_container.end(), *diter);
    if (loc!=tmp_container.end())
    {
      result->addEntity(*diter);
      tmp_container.erase(loc++);
    }
  }
  for (typename EntitySetOrdered<Entity>::SubIter siter=EntitySetOrdered<Entity>::subBegin(); siter!=EntitySetOrdered<Entity>::subEnd();++siter)
    if (find(otherset->subBegin(), otherset->subEnd(), *siter)!=otherset->subEnd())
      result->addSubset(*siter);
  return;
}

#endif 
