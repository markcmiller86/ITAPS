/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <math.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <mException.h>  
#include <string>
#include <sstream>
#include <vector>
#include "mPart.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFMDB.h"
#include "FMDB.h"
#include "pmModel.h"
#include "pmEntity.h"
#include "FMDB_Internals.h"
#include "ParUtil.h"
#include "FMDB_cint.h"

void M_writeVTKFile (pMesh, const char*);
void M_writeVTKFile (vector<pMesh>, const char*);

/// Function for writing out a part of a mesh in vtu format
void write_3Dpart_vtu(const char* fname, vector<pRegion> &regs);
