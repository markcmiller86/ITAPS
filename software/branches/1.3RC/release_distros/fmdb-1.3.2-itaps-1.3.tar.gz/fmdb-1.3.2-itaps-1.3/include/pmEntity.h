/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _PM_ENTITY_H_
#define _PM_ENTITY_H_

#include <set>
#include <vector>
#include <list>
  
  class pmEntity;
  
  class pmEntityLessThanKey
  {
  public :
    bool operator() (pmEntity *cb1, pmEntity* cb2) const;
  };
  
  class pmEntity
  {
private:
  int iD;
  int level;	// dimension
  int owner;		// owner partition
  std::set<int> BPs;	// bounding partitions
  int numClassifiedEnts;

public:
  typedef std::set<int>::iterator BPIter; 

// constructor + destructor  
  pmEntity(int i, int l): iD(i), level(l), numClassifiedEnts(0) {}
  pmEntity(int i, std::set<int>& bps, int l);
//  ~pmEntity();

// get data members
  int getId() const {return iD;}
  int getLevel() const {return level;}
  int getOwner() { return owner; }

// set data members
  void setOwner(int o) { owner=o; }
  void setOwner(std::vector<int>&);
  int setOwner(std::list<int>&);

// equality check based on BPS
  bool isEqual(std::set<int>& bpSet);
  void getBPs(std::vector<int>&);
  void addBPs(int p) {  BPs.insert(p); }    
  int getNumBPs() { return BPs.size(); }

// BPs iterator
  
  BPIter bpBegin() { return BPs.begin();  }
  BPIter bpEnd()   { return BPs.end();  }

/// Dealing with number of classified entities on Partition Model Entity
  inline void in_numCE() { numClassifiedEnts++; }
  inline void de_numCE() { numClassifiedEnts--; }
  inline int numCE() { return numClassifiedEnts; }

// accessory
  void print();
  
  /*  protected:
    int iD;
    int level;
    int owner;
  public:
    pmEntity(int i, int l): iD(i), level(l) {}
    //~mCommonBdry();
    int getId() const {return iD;}
    int getLevel() const {return level;}
    void setOwner(int o) { owner=o; }
    int getOwner() { return owner; }
    */
  };  

#endif
