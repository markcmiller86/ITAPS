/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifndef _FMDB_CINT_H_
#define _FMDB_CINT_H_

#include <stdio.h>
#include "oldFMDB.h"
#include "FMDBInternals.h"

#include <vector>
#include <list>
#include <iostream>
#include <map>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef FLEXDB
pPList  FMDB_createAdjPList (pEntity, int);
#endif
/*************************************
  Higher-order Nodes
**************************************/
//M_createNode(pMesh, pEntity, double x, double y, double Z);
//M_deleteNode(pMesh, pEntity, SCOREC::Util::mPoint*);

/*************************************
  General Parallel operators
**************************************/
double P_getMaxDbl(double);
double P_getMinDbl(double);
double P_getSumDbl(double);
int P_getMaxInt(int num);
int P_getMinInt(int num);
int P_getSumInt(int i);
int P_size();
void P_barrier();
int P_pid();
void P_unifyMinMax(double* max, double* min); 
void P_mergeArray(std::vector<int>&); 
void P_getGlobal(int in, std::vector<int>&);
double P_wtime();
/*************************************
  Mesh operators
**************************************/
int M_getMaxVId(pMesh mesh);
int M_pid();
int M_size();

// the purpose of PM_load/write is not to visualise partitioned mesh,
// but to resume parallel simulation.
int PM_load(pMesh, const char *filename, bool fixedFName=false, int numGrp=1, int numProc=1);
int PM_load2(std::vector<pMesh> pm, const char *fName);              // multiple parts per process 
int PM_write(pMesh pm, const char *filename);
int PM_write2(std::vector<pMesh> pm, const char *fName);             // multiple parts per process
bool M_compare(pMesh, pMesh);
void M_boundingPids(std::vector<int>& bps);
void M_print(pMesh);
void M_printNumEntities(pMesh);
void M_numEntities(pMesh, int dim, std::vector<int>& );  // asked by Onkar
void M_numEntitiesOwned(pMesh, int dim, std::vector<int>& );
void M_updateOwnership(pMesh);
//void M_setEntityOwnership(pMesh);
bool M_verify(pMesh);
int PM_merge(pMesh);

/*************************************
  Entity operators
**************************************/
std::string EN_getUidStr(pEntity);
void EN_print(pEntity);
int EN_owner(pEntity);
bool EN_duplicate(pEntity);
int EN_getNumCopies(pEntity); 
pEntity EN_getCopy(pEntity, int);
void EN_getCopies(pEntity,
              std::vector<std::pair<pEntity,int> >&);
void EN_addCopy(pEntity,int,pEntity);
void EN_clearCopies(pEntity);
pmEntity* EN_getPClassification(pEntity);
void EN_setPClassification(pEntity, pmEntity*);
void R_center(pEntity, double xyz[3]);
double R_Volume(pEntity);
double R_Volume2(pEntity);
void F_center(pEntity, double xyz[3]);
void E_center(pEntity, double xyz[3]);
void EN_setWeight(pEntity, double);
int EN_getWeight(pEntity, double*);

/*************************************
  Mesh LB + migration operators
**************************************/
#ifdef FMDB_PARALLEL
bool EN_deleteUserData(pEntity ent,int);
void M_loadbalance(pMesh,pmMigrationCallbacks &);
void M_loadbalance2(std::vector<pMesh>&,pmMigrationCallbacks &);

int M_migration(pMesh, int, std::list<pEntity> &,
                pmMigrationCallbacks &,
                int dim1, std::vector<pEntity>&, std::vector<pEntity>&,
		int dim2, std::vector<pEntity>&, std::vector<pEntity>&,
		std::vector<pEntityGroup>&, std::vector<pEntityGroup>&); 

int M_partMigration(std::vector<pMesh>& meshes,                             // migrate a whole part
                    int source_pid,
		    int target_rank,
		    pmMigrationCallbacks &cb); 
							    
#endif



/*************************************
  General Mesh Info operators
**************************************/
void M_set_maxMeshDim(int dim);
int M_maxMeshDim();
int M_globalMaxDim(pMesh);
int M_globalMinDim(pMesh);
// it returns all the mesh entities of given dimension, which are on CB
// (ex)  dim=-1; all entities on CB
//       dim=0: vertices on CB
//       dim=1: edges on CB
//       dim=2: faces on CB
//       dim=3: regions on CB

void M_getCBEntities(pMesh,int dim, std::vector<pEntity>& cbEntities);
void M_getPOEntities(pMesh mesh, std::vector<pEntity>* poEntities);

/*************************************
  parallel meshAdapt specific operators
**************************************/
#ifdef FMDB_PARALLEL
void PM_setMaxNumParts(int);                 // for multiple parts per process

void M_unifyTaggedEntities(pMeshDataId tag, std::list<pEntity>*);
void M_unifyTaggedEntitiesWithValues(pMeshDataId tag, std::list<pEntity>*);
// sum up all tagged edges over all processors
void M_attachUniqueId(pMesh, pMeshDataId tag);
void M_update_CB_Links(std::list<pEntity> &ents_to_updt, pMeshDataId id);
int M_migrationForSnap(pMesh, pmMigrationCallbacks &, std::list<pEntity>&,                 
                       std::list<std::pair<pEntity,pEntity> > &, int dim, 
                       std::vector<pEntity>&, std::vector<pEntity>&,
                       std::vector<pEntityGroup>&, std::vector<pEntityGroup>&); 

int M_deleteDimReduction(pMesh, pmMigrationCallbacks &cb,std::vector<pEntity>*);
#endif
/*************************************
  parallel Trellis specific operators
**************************************/
void M_assignUniqueRange(pMesh pm, pMeshDataId tag1, pMeshDataId tag2, 
         std::vector<pEntity> &l1, std::vector<int> &l2, int initialId);

/*************************************
  DMUM + FLEXDB
**************************************/
void DMUM_startMonitoring(pMesh);
void DMUM_stopMonitoring(pMesh);
void DMUM_resumeMonitoring(pMesh);
void DMUM_pauseMonitoring(pMesh);
void DMUM_print(pMesh);
bool DMUM_isOn(pMesh);

int M_adjacencyCost(pMesh, int, int);
void M_printAdjacencyCost(pMesh);
void M_printAdjacency(pMesh, int, int);
int M_load_URR(pMesh, const char *, const char*);
  int M_load_MRM(pMesh, const char*, int MRM[4][4]);
int EN_numAdjacency(pEntity, int);
int EN_adjacency(pEntity, int, std::vector<pEntity>&);

// Miscellaneous
void computeCrossProduct( double a[], double b[], double n[] );
double computeDotProduct( double a[], double b[] );
double computeSignedDistance( pVertex vertex, pFace face);
pVertex findVertexOppositeFace( pRegion region , pFace face );


/*************************************
   MATCHING  
**************************************/

#ifdef MATCHING
  /** create matched vertices through vertex info */
  void M_createMatchVP(pMesh mesh, struct v_create_struct** vinfo, int size,  std::list<std::pair<pEntity, int> >& mlist);
  /** create matched edges through edge info */
  void M_createMatchE (pMesh mesh, struct e_create_struct** einfo, int size,  std::list<std::pair<pEntity, int> >& mlist);
  /** create matched faces through face_edge info */
  void M_createMatchF (pMesh mesh, struct f_create_struct** finfo, int size,  std::list<std::pair<pEntity, int> >& mlist);
  /** create matched faces through face_vertex info */
  void M_createMatchFV(pMesh mesh, struct fv_create_struct** fvinfo, int size,  std::list<std::pair<pEntity, int> >& mlist);
#endif

  /** check if an entity matches other entity */  
  int EN_isMatchEnt(pEntity ent);   
  /** get the matched entity list for an entity */
  void EN_getMatchEnts(pEntity ent, pGEntity filter, std::list<std::pair<int, pEntity> >& mlist, int lid=0); 
  /** build matching connections among the entities */
  void EN_addLocalMatchEnts(std::list<pEntity> mlist, int lid=0);
  void EN_addMatchEnts(std::list<std::pair<pEntity, int> > elist1, std::list<std::pair<pEntity, int> > elist2); 
  /** delete matched entity info from an entity */  
  void EN_deleteMatchEnts(pEntity ent);   

#ifdef __cplusplus
}
#endif

#endif
