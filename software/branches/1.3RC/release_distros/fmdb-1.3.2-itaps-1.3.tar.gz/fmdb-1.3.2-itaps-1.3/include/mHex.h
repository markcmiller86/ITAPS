/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MHEX_H_
#define _MHEX_H_
#include "mRegion.h"

class GEntity;
class mEdge;
class mVertex;
class mFace;
/**
  mHex implement specific templates for the hexaedral
  element.
 */
class mHex : public mRegion
{
 protected:
   mEntity* down_adj[12]; 
   short int down_adj_dim; 

 public:
  static short int Hev[12][2];
  static short int Hfv[6][4];
  static short int Hfe[6][4];
  static short int Hve[8][2];
  static short int Hvf[8][3];
  static short int Hef[12][2];
  
  virtual ~mHex();
  mHex ();
  /// Constructor using 8 vertices
  mHex (mVertex *v1, 
	mVertex *v2, 
	mVertex *v3, 
	mVertex *v4, 
	mVertex *v5, 
	mVertex *v6, 
	mVertex *v7, 
	mVertex *v8, 
	GEntity *classification);
  /// Constructor using 12 edges
  mHex (mEdge *e1, mEdge *e2, mEdge *e3, mEdge *e4, mEdge *e5, mEdge *e6, 
	mEdge *e7, mEdge *e8, mEdge *e9, mEdge *e10, mEdge *e11, mEdge *e12, 
	GEntity *classification);
  /// Constructor using 6 face
  mHex (mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, 
	mFace *f6, GEntity *classification);
  /// This is an mEntity::HEX
  inline mEntity::mType getType() const {return HEX;}
  /// Template members
  virtual int getNbTemplates (int what) const;
  /// Template members
  virtual mEntity* getTemplate (int ith , int what , int with) const;
  /// Debug stuff
  virtual void print() const;
      /// Get the dimension of the entity through a static function
      /// Useful for template algorithms
 inline static int getDim () {return 3;}
	
  // adjacency related
  void add (mEntity* m) {}
  void appendUnique (mEntity* m) {}
  void del (mEntity* m) {}
  int size (int what)const;

  mEntity* get(int what, int ith)const;
  void deleteAdjacencies(int what) {}
  mEntity * find(mEntity* m) const;
	
  inline void setFace (mEntity* me,  int pos)
  {
      if(down_adj_dim==2)
	 down_adj[pos]= me;
  }
		     
};

#endif 
