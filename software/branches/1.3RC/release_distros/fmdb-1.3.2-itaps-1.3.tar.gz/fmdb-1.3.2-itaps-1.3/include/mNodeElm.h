/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _H_NODEELM_
#define _H_NODEELM_
#include "oldFMDB.h"
#include "FMDB_Internals.h"

class inputNodeElm {

 public:
  inputNodeElm(pMesh  mesh, int dimension, int MRM[4][4]= 0, bool complete = 1); 
  pEntity addElement(pEntity *nodes, int Dim, mType entType, mType bdEntType, pGEntity gent);
  
 private:
  pMesh theMesh;
  bool complete;

  pEdge addEdge(pVertex v0, pVertex v1, pGEntity);
  pFace addFace(pEntity *ent, mType entType, mType bdEntType, pGEntity gent);
  pRegion addRegion(pEntity *ent, mType entType, mType bdEntType, pGEntity gent);
  
  static int Pmev[9][2], Pmfe[5][4];
  static int Tev[6][2], Tfe[4][3];
  static mType PmfType[5];
};

#endif
