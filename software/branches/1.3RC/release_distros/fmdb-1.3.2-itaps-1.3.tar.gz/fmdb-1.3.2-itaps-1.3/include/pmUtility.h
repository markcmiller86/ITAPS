/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef PM_UTILITY_H
#define PM_UTILITY_H

#include <list>
#include <vector>
#include <map>
#include <list>
#include "mPart.h"
#include "mEntity.h"
#include "mpi.h"

struct int4_struct
{
  int idata[4];
};

struct mEnt_struct
{
  mEntity* entity;
};

struct int_mEnt_struct
{
  int i;
  mEntity *entity;
};
 
struct int2_mEnt_struct
{
  int i;
  int j;
  mEntity *entity;
};

struct mEnt2_struct
{
  mEntity* ent1;
  mEntity* ent2;
};

struct int_mEnt2_struct
{
  int i;
  mEntity* ent1;
  mEntity* ent2;
};

struct int2_mEnt2_struct
{
  int i;
  int j;
  mEntity* ent1;
  mEntity* ent2;
};

struct rc_struct
{
  int from;
  mEntity* fromE;
  mEntity* toE;
  rc_struct(int i,mEntity* e1, mEntity* e2):from(i),fromE(e1),toE(e2) {}
};
 

struct rc_struct_1
{
  int pid;
  mEntity* entity;
  rc_struct_1(int i, mEntity* e): pid(i), entity(e){}
};

struct rc_struct_2
{
  mEntity* ent1;
  int pid;
  mEntity* ent2;
  rc_struct_2(mEntity* e1, int i, mEntity* e2): ent1(e1), pid(i), ent2(e2){}
};

struct rc_struct_3
{
  mEntity* ent1;
  int dest;
  mEntity* ent2;
  int src;    
  rc_struct_3(mEntity* e1, int i, mEntity* e2, int j): ent1(e1), dest(i), ent2(e2), src(j){}
};

struct rc_struct_4
{
  mEntity* ent;
  int lid;
  int rank; 
  rc_struct_4(mEntity* e, int i, int j): ent(e), lid(i), rank(j){}
};


void mergeArray(std::vector<int>& vec); 

struct int2_struct {            // global part ids: proc_rank + local_part_id
  int i;
  int j; 
}; 

struct part_struct {            // part_handle structure    
  mPart* mesh;                  // local part mesh 
  int pid;                      // local part_id 
}; 


struct partition_struct {      // partition_handle structure 
  int num_parts;               // local number of parts, assume this is equal on each process. 
  MPI_Comm mpi_comm; 
  //  std::set<int2_struct*> part_ids;        // global part ids: proc_rank(key) + local_part_id
  std::list<part_struct*> local_parts;     
}; 

struct mEnt_dbl3_struct {
  mEntity* ent; 
  double xyz[3]; 
}; 


struct mEnt_ptr_struct{
  mEntity* ent; 
  void* ptr; 
}; 

#endif
#endif /* FMDB_PARALLEL */
