/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef MPARALLEL_UTILITY_H
#define MPARALLEL_UTILITY_H

#include "mPart.h"
#include "mEntity.h"
#include "mEdge.h"
#include "FMDB_OwnerManager.h"
#include <assert.h>

#ifdef FMDB_PARALLEL
#include "ParUtil.h"
#include "mpi.h"
#endif

/* 
  This function assign the range to each mesh entity.
  IN: vector<mEntity*> entities   contains mesh entities on each processor
      vector<int> numInt          contains entities[i]'s # of integers to assign
      mPart* theMesh              mesh handle
      unsigned int tag            tag
      int starting_range          starting integral value of the range
  OUT:vector<pair<int,int>> range contains the range of entities[i]
                                  the first contains starting integer
                                  the second contains the # of intergers
  for example, if, in P1, entities=[v1,v2,v3], numInt=[1,2,4]
                   in P2, entities=[v4,v1,v3], numInt=[5,2,4] 
              then,in P1, range=[(1,2),(3,2),(5,4)]
                   in P2, range=[(9,5),(2,2),(5,4)]

output : 
  range[0] is the number of id's for THIS processor (not including the counterparts)
  range[1] is the starting number for this processor
  range[2] is the total number of id's for all processors

*/ 
void assignUniqueRange(mPart* theMesh,
                       std::vector<mEntity*> & entities,
	               std::vector<int> & numInt,
                       unsigned int startRangeTag,
                       unsigned int endRangeTag,
                       int initialRangeValue); 

void computeUniqueId(mPart* theMesh,unsigned int tag, int*, int*);
// void bdryLinkSetupWithMeshMod(mPart* theMesh, int,int);
void unify(double *max,double *min);
void unifyTaggedEdges(mPart* theMesh, unsigned int tag,
                      std::list<mEntity*> & VEC);

bool canDeleteAttachedData(mEntity*,int);
#endif 
