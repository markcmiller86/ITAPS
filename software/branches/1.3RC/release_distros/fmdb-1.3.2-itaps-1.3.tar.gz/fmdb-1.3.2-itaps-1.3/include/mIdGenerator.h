/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MIDGENERATOR_H
#define _MIDGENERATOR_H

#include <queue>

class mIdGenerator {
 private :
   int maximumValue;
   std::queue<int> Q;
#ifdef FMDB_PARALLEL
  int nbPE;
  int myPE;
#endif
 public:
  mIdGenerator();
  void addId(int Id);
  int generateId();
  virtual ~mIdGenerator();
  int getMaxValue() const;
  void setMaxValue(int);
#ifdef FMDB_PARALLEL
  void pmSetMaxValue(int);
#endif

#ifdef FMDB_PARALLEL
  void update(); 
#endif

};

#endif


