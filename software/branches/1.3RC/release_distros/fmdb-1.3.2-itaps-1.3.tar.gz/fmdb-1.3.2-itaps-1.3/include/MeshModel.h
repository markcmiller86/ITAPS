/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MESH_MODEL_
#define _MESH_MODEL_

#include "oldFMDB.h"
#include "FMDBInternals.h"

#ifdef __cplusplus
extern "C" {
#endif
  void MeshModel_middlePoint
  ( pMesh,
  pEdge pE,       // an edge to be split
    double * pin );   // the boundary location of the vertex created in splitting

  void Analytic_middlePoint (pMesh mesh, pEdge pE,     // an edge to be split
                           double *par,
                             double *pin);   // the boundary location of the vertex created in splitting
#ifdef __cplusplus
}
#endif
#endif
