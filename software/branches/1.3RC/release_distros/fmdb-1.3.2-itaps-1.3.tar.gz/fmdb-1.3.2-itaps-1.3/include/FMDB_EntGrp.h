/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef H_FMDB_ENTGRP
#define H_FMDB_ENTGRP

#include "FMDBfwd.h"

#include <list>
#include <vector>

  typedef std::vector<pEntityGroup>::iterator  EGIter;
  typedef std::list<pEntity>::iterator EntIter;

  /*************************/
  /* Mesh Level Operators */
  /*************************/

  pEntityGroup M_createEntGrp(pMesh, int dim);
  pEntityGroup M_createEntGrp(pMesh, std::list<pEntity>, int dim);
  void M_removeEntGrp(pMesh, pEntityGroup); 
  int M_numEntGrps(pMesh);  

  /*************************/
  /* EntityGroup Iter Ops  */
  /*************************/

  EGIter M_endEntGrp(pMesh mesh);
  EGIter M_beginEntGrp(pMesh mesh);


  /*******************************/
  /* EntityGroup Level Operators */
  /*******************************/

  void EG_clear(pEntityGroup);
  int EG_isEmpty(pEntityGroup);
  int EG_getNumOfEntities(pEntityGroup);
  
  void EG_unionEntGrp(pEntityGroup, pEntityGroup);    // not implemented yet
  void EG_substractEntGrp(pEntityGroup, std::list<pEntity>, pEntityGroup);  // not implemented yet

  void EG_addEntity(pEntityGroup, pEntity);
  void EG_removeEntity(pEntityGroup, pEntity);
   
  EntIter EG_beginEntity(pEntityGroup);
  EntIter EG_endEntity(pEntityGroup);
  
  /**************************/
  /* Entity Level Operators */
  /**************************/
  
  int EN_isInEntGrp(pEntity, pEntityGroup&);
  void EN_getAdjPOs(pEntity, std::list<void*>);      // not implemented yet

 /**************************/
 /* Attached Data Operators */
 /**************************/
     
  void EG_attachDataInt(pEntityGroup eg, pMeshDataId id, int value);
  void EG_attachDataDbl(pEntityGroup eg, pMeshDataId id, double value);
  void EG_attachDataPtr(pEntityGroup eg, pMeshDataId id, void * value);
  
  void EG_deleteData(pEntityGroup eg, pMeshDataId id);
  
  int EG_getDataInt(pEntityGroup eg, pMeshDataId id, int *value);
  int EG_getDataDbl(pEntityGroup eg, pMeshDataId id, double *value);
  int EG_getDataPtr(pEntityGroup eg, pMeshDataId id, void **value);

#endif
