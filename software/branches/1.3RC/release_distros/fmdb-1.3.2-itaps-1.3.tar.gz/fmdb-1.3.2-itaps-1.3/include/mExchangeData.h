/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_EXCHANGEDATA_H_
#define _FMDB_EXCHANGEDATA_H_

#include "mPart.h"
#include "FMDB_SharedInfo.h"


class mEntity;

/**
  FMDB_DataExchanger is a class that allow user to exchange
  data's between partitions and/or periodic boundaries. User
  has to provide a tag for non synchronous communications. 
  Basically, choose a tag that is higher that 200 for being
  sure that it does not interact with internal messages.
  User has to allocate buffers using AP_alloc from autopack.
  this should be changed... We already did the change in 
  load balancing callbacks.
  User will recieve its datas. If user wants to know the
  counterpart of mesh entity *e in the other partition,
  he has to sent the remote pointer si.getRemotePointer().
  This also should be automatized.
*/
  class FMDB_DataExchanger
  {
  public :
  /// get a tag
    virtual int tag() const = 0;
    /// user sends a message related to mesh entity *e to proc si.pid() to the counterpart si.getRemotePointer().
    virtual void * AP_alloc_and_fill_buffer (mEntity *e, FMDB_SharedInfo &si, int tag) = 0;
    /// user recieve data *buf form proc pid.
    virtual void receiveData (int pid, void *buf) = 0; 
  };

#endif
