/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MMESH_H_
#define _MMESH_H_

#include <vector>
#include "mPart.h"
#include "mEntitySet.h"

using std::vector;

class mMesh: public mAttachableDataContainer
{
private:
  std::vector<mPart*>*  parts;
  pGModel theGeomModel; 
  // tags for ITAPS (temporary - must be revisited)
  std::map<char*, unsigned int> name_tag_map;
  std::map<unsigned int, std::pair<int, int> > tag_att_map; // pair: type and size

public:
  short int MRM[4][4];  // MRM for itaps 

  static unsigned int partID;
  typedef vector<mPart*>::iterator partIter;
  mMesh(pGModel geom); 
  ~mMesh();
  void clearPart();
  void addPart(mPart* part);  
  void delPart(mPart* part);
  unsigned int getNumPart() {return parts->size(); }
  pGModel getGeomModel()  {  return theGeomModel;  }
  partIter partBegin()  {  return parts->begin(); }
  partIter partEnd()  {  return  parts->end();  }
  mPart* getPart(int ith);
  conType getContainerType() const  {return MESH;} 

  bool findTagID (unsigned int tag_id);
  int getTagID (const char *tag_name, unsigned int* tag_id);
  int nameTagID (unsigned int tag_id, char* name);
  int typeTagID (unsigned int tag_id, int* type);
  int sizeTagID (unsigned int tag_id, int* size);
  int createTagID (const char *tag_name, int type, int size, unsigned int* tag_id);
  int deleteTagID (unsigned int tag_id);
  void getAllTagID (std::vector<unsigned int>& ids);
  // entity set
  std::list<EntitySet<mEntity> * > allEntSets;
  void addEntSet(EntitySet<mEntity> *p) { allEntSets.push_back(p);}    
  void removeEntSet(EntitySet<mEntity> * p)
  {
    std::list<EntitySet<mEntity>* >::iterator loc = std::find(allEntSets.begin(), allEntSets.end(),p);
    allEntSets.erase(loc++);
  }
  std::list<EntitySet<mEntity>* >::iterator beginEntSet() {return allEntSets.begin(); }
  std::list<EntitySet<mEntity>* >::iterator endEntSet() {return allEntSets.end(); }
  bool hasEntSet(EntitySet<mEntity> *p)  
  {
    std::list<EntitySet<mEntity>* >::iterator loc = std::find(allEntSets.begin(), allEntSets.end(),p); 
    if(loc==allEntSets.end())
      return false; 
    return true; 
  }
  // last error happened in mesh
  int last_error;
};

#endif // _MMODEL_H_

