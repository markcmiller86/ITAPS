/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FUNCTION_TEMPLATE_H_
#define _FUNCTION_TEMPLATE_H_


#include <algorithm>
#include <malloc.h>

class mEntity; 
using std::find; 
using std::copy; 


/// mEntity class related function templates
#define APPEND_UNIQUE_ENTITY(ent) { if (find(ent)) return;  add(ent); }
#define SAFE_FREE_ARRAY(ARRAY, SIZE)  { (SIZE)=0; free(ARRAY); (ARRAY)=0; }

template<typename T>
void add_entity_to_array (T*& array, mEntity*& m, short int& arr_size)
{
   if(array==0)
      array = (mEntity**)malloc(sizeof(void*));
   else
      array = (mEntity**)realloc(array, (arr_size+1)*sizeof(void*));

   array[arr_size] = m;
   ++arr_size;
}

template<typename T>
mEntity* find_entity_in_array (T* array, short int arr_size, mEntity* me)
{
   if(array==0)
      return 0;

   mEntity** pos;
   pos = find(array, array + arr_size, me);
   if(pos==array + arr_size)
      return 0;
   else
      return me;
}


  template<typename T>
  void del_entity_from_array(T*& array, short int& arr_size, mEntity*me)
   {                                                                 
      if(arr_size==0 || array==0)
         return;

      mEntity** pos;
      pos = find(array, array + arr_size, me);
      if(pos==array + arr_size)
         return;

      if(arr_size-1==0)
      {
	 SAFE_FREE_ARRAY(array, arr_size); 
	 return; 
      }
      
      copy(pos+1, array + arr_size, pos);
      array = (mEntity**)realloc(array, (arr_size-1)*sizeof(void*));
      --arr_size;
   }


template<typename T>
void free_array(T*& array, short int& size)
{  
   if(size==0 || array==0)
      return; 
   SAFE_FREE_ARRAY(array, size);
}

#endif
