/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef DMUM

#ifndef _H_M_DMUM_
#define _H_M_DMUM_

class mPart;

class mDMUM {

private:
  static mDMUM* instance;
  mDMUM();
  ~mDMUM();

public:
  // return the only instance
  static mDMUM* Instance();

  bool is_on(mPart*);

  void startMonitor(mPart* mesh);   
  void pauseMonitor(mPart* mesh);  
  void resumeMonitor(mPart* mesh);  
  void stopMonitor(mPart* mesh);  

  void resetFlags(mPart* mesh);
  
  void write_MRM(mPart* mesh, const char* fName);
};

#endif
#endif
