/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef PM_MESHADAPT_H
#define PM_MESHADAPT_H

#include <list>
#include <vector>
#include <map>
#include <set>
#include "mPart.h"
#include "mEntity.h"
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"
#include "FMDBInternals.h"

using namespace std;

void unifyTaggedEntities(unsigned int attachTag, list<mEntity*> *LIST);
void unifyTaggedEntitiesWithValues(unsigned int attachTag, list<mEntity*> *LIST);
void unifyTaggedEntitiesWithValuesDbl(unsigned int attachTag, list<mEntity*> *LIST);
void attachUniqueId(mPart* theMesh, unsigned int FMDBtag);
void update_CB_Links(list<pEntity> &ents_to_updt, pMeshDataId id);
int deleteDimReduction(mPart*,pmMigrationCallbacks &cb, vector<mEntity*>*);

#endif
#endif /* FMDB_PARALLEL */
