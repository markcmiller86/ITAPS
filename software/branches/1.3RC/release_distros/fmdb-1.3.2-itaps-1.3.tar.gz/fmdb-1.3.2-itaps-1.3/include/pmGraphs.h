/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MGRAPHS_
#define _MGRAPHS_

#include <iosfwd>
#ifdef FMDB_PARALLEL
#include "pmMigrationCallbacks.h" // used by pmodel
#endif

class mPart;

/**
  One graph contains vertices and edges, these are not vertices and edges of 
  the mPart ! The idea is that the vertices of the graph are the mesh entities 
  of dimension from and the edges are entities of dimesion to.

  The graph is designed as a struct because it's a very internal structure.

  FMDB_graph::nn is the number of vertices of the graph
  
  FMDB_graph::xadj is a vector of "pointers", its dimension is (nn+1) 
  xadj[i] points to the first element of the adjacency of node i in adjncy. 
  The terminology is exactly the same as the one you can find in the METIS documentation.

  NOTE : EVERYTHING USES FORTRAN INDEXING so make j = xadj[k] - 1 to access adjncy[j]

  xadj [ 0 , ...,  i , ... , nn ]

  adjncy [ 0 , ... , xadj[i] - 1 , ... , xadj[i+1] - 1, ... ]
                     |__________________|
                            
                     indexes of vertices 
		       adjacent to i
   
  vwgt of size nn contains weights on vertices
  adjwgt of big size contains weights on edges

  In the constructor, you give a bool (doWeUseWeights) telling if you want to compute
  initial weights based on element sizes.
*/

struct FMDB_graph
{
  unsigned int tagDn;
  FMDB_graph(mPart *, int from, int to , bool doWeUseWeights);
  FMDB_graph(mPart *, int from, int to , bool doWeUseWeights, int level);
  FMDB_graph();
  virtual ~FMDB_graph();
  int nn;
  int *vid;      // the graph node id, 060107 
  int *xadj;
  int *adjncy;
  int *adjpid;    // the proc id of the process where a neighbor graph node resides, 060107  
  int * vwgt, *adjwgt;
  void print(std::ostream &);
};

class FMDB_LoadBalancerCallbacks;
void computeNbNodesPerProc(mPart *, int *nbNodesPerProc, int from, int level=-1);

/**
  Distributed graph, exactly the same as a mGraph except a new vector
  vtxdist that has to be the same in all processes.

  np is the number of processes
  vtxdist is of size np+1
  
  vertices are inexed, indexes have to be different on
  different processes, each process has a range of indexes.

  vtxdist[i] gives the initial vertex id on process i
*/


class FMDB_distributed_graph
{
 public:
  FMDB_distributed_graph(mPart *, int from, int to , 
			 FMDB_LoadBalancerCallbacks *dm = 0,
			 int level = -1);
  FMDB_distributed_graph();
  virtual ~FMDB_distributed_graph();
  FMDB_graph *theGraph;
  int *vtxdist;
  void print(std::ostream &);
};

#ifdef FMDB_PARALLEL
class FMDB_distributed_graph2
{
 public:
  FMDB_distributed_graph2(mPart *, int from, int to , 
			 pmMigrationCallbacks *dm = 0,
			 int level = -1);
  FMDB_distributed_graph2(); 
  virtual ~FMDB_distributed_graph2();
  FMDB_graph *theGraph;
  int *vtxdist;
  void print(std::ostream &);
};
#endif


#endif
