/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MENTITYGROUP_H_
#define _MENTITYGROUP_H_

#include <list>
#include <vector>

#include "mAttachableDataContainer.h"
#include "mFMDB.h"
#include "mEntitySet.h"

using std::list; 
using std::vector; 

  class mEntity;

  class mEntityGroup : public EntitySetUnordered<mEntity> 
  {
  private: 
    int dim; 
    unsigned int egTag;   
      
  public: 
   typedef std::list<mEntity*>::iterator entIter; 
   
    mEntityGroup(list<mEntity*>, int); 
    mEntityGroup(int);
    mEntityGroup() { egTag= FMDB_Util::Instance()->lookupMeshDataId("EntityGroupTag"); } 
    ~mEntityGroup(); 

    void addEntity(mEntity* ent); 
    void addEntity(mEntity* ent, int pos);
    void removeEntity(mEntity* ent);

    mEntity* getEntity(int pos);
    int getEntityOrder(mEntity* ent);
    conType getContainerType() const {return ENTITYGROUP; }

#ifdef FMDB_PARALLEL
    list<void*>* bdryEnts; 

    void getBdryEntities(); 
    void removeBdryEntities() {if(bdryEnts==NULL) return;  SAFE_DELETE(bdryEnts); }; 
    int  numBdryEntities() {if(bdryEnts==NULL) return 0;  bdryEnts->size(); }
#endif

#ifdef DEBUG
    void printEntList(); 
#endif

  }; 
#endif

