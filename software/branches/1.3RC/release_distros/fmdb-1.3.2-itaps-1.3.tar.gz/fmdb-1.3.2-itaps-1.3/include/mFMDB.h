/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _H_FMDB_Util_
#define _H_FMDB_Util_

#include <memory>
#include <iostream>
#include <iosfwd>
#include <map>
#include <utility>
#include <vector>
#include "modeler.h"
#include <cstring>
#ifdef FMDB_PARALLEL
#include "pmMigrationCallbacks.h"
#endif

const double accuracy=0.000005;
bool isEqual(double x, double y);

  class mPart;
  class mMesh;
  class FMDB_LoadBalancerCallbacks;
/**
 FMDB is a singleton i.e. a class having only
 one occurence for a given heap.
 This class contains all global FMDB
 functionalities like import and export files
*/
  class FMDB_Util {
    unsigned int _ATTFMOD,_ATTEMOD,_ATTPARENT,_ATTID,_ATTSIZE,_ATTDN,_ATT1,_ATT2,_ATT3;
    unsigned int _ATTPARAMETRIC;
    unsigned int _ATTWEIGHT;
    unsigned int _Node;
    std::map <char*, unsigned int> attachableDataIds;
    std::map <unsigned int, char*> attachableDataIds_rev;
    std::map <unsigned int, int> attachableDataIds_type;    
    std::map <unsigned int, int> attachableDataIds_size;    
  public:
    inline unsigned int getParametric() const {return _ATTPARAMETRIC;}
    inline unsigned int getParent() const {return _ATTPARENT;}
    inline unsigned int getId() const     {return _ATTID;}
    inline unsigned int getDn() const     {return _ATTDN;}
    inline unsigned int getSize() const {return _ATTSIZE;}
    inline unsigned int getFmod() const {return _ATTFMOD;}
    inline unsigned int getEmod() const {return _ATTEMOD;}
    inline unsigned int getAtt1() const {return _ATT1;}
    inline unsigned int getAtt2() const {return _ATT2;}
    inline unsigned int getAtt3() const {return _ATT3;}
    inline unsigned int getWeight() const {return _ATTWEIGHT;}
    inline unsigned int getNode() const {return _Node;}
    /// Get the only instance
    static FMDB_Util* Instance();    
#ifdef FMDB_PARALLEL

// defined in pmMeshIO.cc
//    void load_and_partition(const char *, mPart *, pmMigrationCallbacks &lb);
    void loadPartitionedMesh(mPart*,const char*, bool fixedFName=false, int numGrp=1, int numProc=1);
    void writePartitionedMesh(std::vector<mPart*>,const char*);
#endif
    /// export a mesh, check the extension of the files
    void ex_port (mMesh *, const char *);
    /// import a mesh, check the extension of the file
    int import (mMesh *, const char *);
    int getTag (int dim, int id);
    inline unsigned int  lookupMeshDataId (const char *tag);
    inline unsigned int  newMeshDataId    (const char *tag, int type=-1, int size=-1);
    inline int typeMeshDataId(unsigned int);
    inline int sizeMeshDataId(unsigned int);
    inline void nameMeshDataId(unsigned int, char*);
    inline int  lookupMeshDataId (const char *tag, unsigned int*);
    inline int  lookupMeshDataId (unsigned int);
    inline void deleteMeshDataId (unsigned int id);
    inline void getAllTagID (std::vector<unsigned int>& ids);
    /// Constructor and destructors should be private but I'm fed up of this
    /// c++ compiler always shouting
    ~FMDB_Util();

  private:
    /// Constructor and destructors are private
    FMDB_Util ();
    /// The only instance
    static std::auto_ptr<FMDB_Util> instance; 
  };



inline int FMDB_Util::lookupMeshDataId (const char *tag_name, unsigned int* tag_id)
{
  std::map <char*, unsigned int>::const_iterator it = attachableDataIds.begin();
  for (; it!=attachableDataIds.end(); ++it)
  {
    if (!strncmp((*it).first, tag_name, strlen(tag_name)))
    {
      *tag_id=(*it).second;
      return 1;
    }
  }
  return 0;
}
  
inline int FMDB_Util::lookupMeshDataId (unsigned int tag_id)
{
  if (attachableDataIds_type.find(tag_id) == attachableDataIds_type.end())
    return 0;
  else 
    return 1;
}

inline int FMDB_Util::typeMeshDataId(unsigned int tag_id)
{
  if(attachableDataIds_type.find(tag_id) == attachableDataIds_type.end())
  {
    return -1; 
  }    
  return attachableDataIds_type[tag_id];
}  

inline int FMDB_Util::sizeMeshDataId(unsigned int tag_id)
{
  if(attachableDataIds_size.find(tag_id) == attachableDataIds_size.end())
  {
    std::cerr<<"izeMeshDataId: No tag found with tag_id "<<tag_id<<std::endl;
    throw 1;
  }    
  return attachableDataIds_size[tag_id];
}  

inline void FMDB_Util::nameMeshDataId(unsigned int tag_id, char* tag_name)
{
  if(attachableDataIds_rev.find(tag_id) == attachableDataIds_rev.end())
  {
    std::cerr<<"nameMeshDataId: No tag found with tag_id "<<tag_id<<std::endl;
    throw 1;
  }    
  strcpy (tag_name, attachableDataIds_rev[tag_id]);
}  

inline unsigned int FMDB_Util::newMeshDataId(const char *tag, int type, 
  					     int size)
{
  std::map <char*, unsigned int>::const_iterator it = attachableDataIds.begin();
  for (; it!=attachableDataIds.end(); ++it)
    if (!strncmp((*it).first, tag, strlen(tag)))
    {
      std::cerr<<"FMDB cannot create an existing tag \""<<tag<<"\"\n";
      throw 1;
    }   

  char* tag_name = new char[strlen(tag)+1];
  strcpy (tag_name, tag);

  if (attachableDataIds.empty()) {
	attachableDataIds_rev[0] = tag_name;
	attachableDataIds_type[0] = type;
	attachableDataIds_size[0] = size;
	attachableDataIds[tag_name] = 0;
	return 0;
      }
  else {
	unsigned int biggest = (*(--attachableDataIds_rev.end())).first;
	attachableDataIds_rev[biggest+1] = tag_name;
        attachableDataIds_type[biggest+1] = type;
        attachableDataIds_size[biggest+1] = size;	
	attachableDataIds[tag_name] = biggest+1;
	return biggest+1;
  }
}

//nico added declaration needed by client code
inline unsigned int FMDB_Util::lookupMeshDataId (const char *tag)
{
  std::map <char*, unsigned int>::const_iterator it = attachableDataIds.begin();
  for (; it!=attachableDataIds.end(); ++it)
    if (!strncmp((*it).first, tag, strlen(tag)))
      return (*it).second;

  return newMeshDataId(tag);
}

inline void FMDB_Util::deleteMeshDataId (unsigned int id)
{
  delete [] attachableDataIds_rev[id];   
  attachableDataIds.erase(attachableDataIds_rev[id]);
  attachableDataIds_rev.erase(id);
  attachableDataIds_type.erase(id);
  attachableDataIds_size.erase(id);    
  }

inline void FMDB_Util::getAllTagID (std::vector<unsigned int>& ids)
{
  std::map <char*, unsigned int>::const_iterator it = attachableDataIds.begin();
  for (; it!=attachableDataIds.end(); ++it)
  {
    if ((*it).second<12)  continue;  // 1-11: RESERVED TAG FOR INTERNAL USE
    ids.push_back((*it).second);
  }
} 

#endif

