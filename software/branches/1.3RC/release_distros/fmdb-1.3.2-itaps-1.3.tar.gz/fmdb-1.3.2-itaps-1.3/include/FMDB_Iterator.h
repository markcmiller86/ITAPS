/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/

#ifndef _FMDB_ITERATOR_H_
#define _FMDB_ITERATOR_H_

#include "FMDBfwd.h"
#include "mEntity.h"
#include "GenIterator.h"
#include "mPart.h"
#include "mEntitySet.h"

class GEntity; 

typedef mPartEntityContainer::iter mesh_iter;

typedef EntitySetUnordered<mEntity>::iter entSetU_iter;
typedef EntitySetOrdered<mEntity>::iter entSetO_iter;

struct ptr_int_struct
{
   void* mesh;
   int pid;
};


inline void processingEntitySetOFilter(entSetO_iter& itbegin, entSetO_iter& itend, void* ptr, int type, int topo)
{
  if(itbegin==itend)
    return; 
  entSetO_iter it;
  
  switch (topo)
  {
    case (int)(mEntity::POINT):
    case (int)(mEntity::LINE_SEGMENT): 
      for (it= itbegin; it!=itend;++it)
	 if ((*it)!=NULL && (*it)->getLevel()==topo) {
	    itbegin = it; 
	    return; 
	 }  
	 break;
    case (int)(mEntity::ALL_TOPOLOGIES):
      if (type == 4) // ALL_TYPES
      {
	 return; 
      }
      else // SPECIFIC TYPE
      {
        for (it=itbegin; it!=itend;++it)
          if((*it)->getLevel()==type) {
            itbegin = it; 
	    return;
	  }
      }
      break;
    default: if (type == 4) // ALL_TYPES
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getTopo()==topo) {
                 itbegin = it; 
		 return; 
	       }
           }
           else // SPECIFIC TYPE & SPECIFIC TOPO
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getLevel()==type && (*it)->getTopo()==topo) {
                 itbegin = it; 
		 return; 
	       }
           }
           break;
  } // end of switch
  itbegin=itend; 
}

inline void processingEntitySetUFilter(entSetU_iter& itbegin, entSetU_iter& itend, void* ptr, int type, int topo)
{
  if(itbegin==itend)
    return; 
  entSetU_iter it;
  switch (topo)
  {
    case (int)(mEntity::POINT):
    case (int)(mEntity::LINE_SEGMENT): for (it= itbegin; it!=itend;++it)
                                          if ((*it)->getLevel()==topo) {
                                             itbegin = it; 
					     return;
					  }
                                      break;
    case (int)(mEntity::ALL_TOPOLOGIES):
      if (type == 4) // ALL_TYPES
      {
        return; 
      }
      else // SPECIFIC TYPE
      {
        for (it=itbegin; it!=itend;++it)
          if((*it)->getLevel()==type) {
            itbegin = it; 
	    return; 
	  }
      }
      break;
    default: if (type == 4) // ALL_TYPES
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getTopo()==topo) {
                 itbegin = it; 
		 return;
	       }
           }
           else // SPECIFIC TYPE & SPECIFIC TYPE
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getLevel()==type && (*it)->getTopo()==topo) {
                 itbegin = it; 
		 return; 
	       }
           }
           break;
  } // end of switch
  itbegin=itend; 
}
 
inline void processingMeshFilter(mesh_iter& itbegin, mesh_iter& itend, void* ptr, int type, int topo)
{
  mPart* mesh = (mPart*)ptr;  
  int dim; 
  if(mesh->size(3))
      dim = 3; 
  else
      dim = 2; 

  if(itbegin==itend)
    return; 
  mesh_iter it;
  switch (topo)
  {
    case (int)(mEntity::POINT):
    case (int)(mEntity::LINE_SEGMENT): for (it= itbegin; it!=itend;++it)
                                          if ((*it)->getLevel()==topo) {
                                            itbegin = it; 
					    return;
					  }
                                      break;
    case (int)(mEntity::ALL_TOPOLOGIES):
      if (type == 4) // ALL_TYPES
      {
	for(int idim = 0; idim < dim; ++idim )
	   if (itbegin == mesh->endall(idim) )
	    {
	       itbegin = mesh->beginall(idim +1 ); 
	       break; 
	    }
        return; 
      }
      else // SPECIFIC TYPE
      {
        for (it=itbegin; it!=itend;++it)
          if((*it)->getLevel()==type) {
            itbegin = it; 
	    return; 
	  }
      }
      break;
    default: 
	   if (type == 4) // ALL_TYPES
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getTopo()==topo) {
                 itbegin = it; 
		 return; 
	       }
           }
           else // SPECIFIC TYPE & SPECIFIC TOPO
           {
             for (it=itbegin; it!=itend;++it)
               if ((*it)->getLevel()==type && (*it)->getTopo()==topo) {
		  itbegin = it;
	          return; 
	       }
	  }
   }
   itbegin=itend; 
}

inline void processingPartBdryEntFilter(mesh_iter& itbegin, mesh_iter& itend, void* ptr, int type, int topo)
{
#ifdef FMDB_PARALLEL
  ptr_int_struct* mesh_pid = (ptr_int_struct*)ptr; 
  pMesh mesh = (pMesh)(mesh_pid->mesh); 
  int pid = mesh_pid->pid; 
  
  int dim; 
  if(mesh->size(3))
      dim = 3; 
  else
      dim = 2; 

  if(itbegin==itend)
    return; 
  mesh_iter it;
  switch (topo)
  {
    case (int)(mEntity::POINT):
    case (int)(mEntity::LINE_SEGMENT):
    case (int)(mEntity::POLYGON):
    case (int)(mEntity::TRIANGLE):
    case (int)(mEntity::QUADRILATERAL):
				    for (it= itbegin; it!=itend;++it)
                                          if ((*it)->getLevel()==topo && (*it)->getPClassification()) {
					    if ( pid != -1 ) {
						 for (mEntity::RCIter rcIter=(*it)->rcBegin(); rcIter!=(*it)->rcEnd();++rcIter)
						     if ( (*rcIter).first== pid ) {
						        itbegin = it;
							return; 
						     } 
					    }	
					    else{
                                               itbegin = it; 
					       return;
					    }
					  }
                                      break;
    case (int)(mEntity::ALL_TOPOLOGIES):
      if (type == 4) // ALL_TYPES
      {
        it=itbegin; 
	for(int idim = 0; idim < dim-1; ++idim ) {            // check the validity of itbegin
	   if (it == mesh->endall(idim) )
	    {
	       it = mesh->beginall(idim +1 );
	    }
        }
	int idim = (*it)->getLevel(); 
        while(1)
	{
	    for(; it!=mesh->endall(idim); ++it)
	      if ((*it)->getPClassification()) {                          
	       if ( pid != -1 ) {
		  for (mEntity::RCIter rcIter=(*it)->rcBegin(); rcIter!=(*it)->rcEnd();++rcIter)
		  if ( (*rcIter).first== pid ) {
		     itbegin = it;
		     return;
		  }
	       }
	       else{
		 itbegin = it;
		 return;
	       }
	     }
	     ++idim; 
	     if(idim<=dim-1) 
	       it = mesh->beginall(idim);
	     else
	       break;        
        }
      }
      else // SPECIFIC TYPE
      {
        for (it=itbegin; it!=itend;++it)
          if((*it)->getLevel()==type && (*it)->getPClassification()) {
	    if ( pid != -1 ) {
	       for (mEntity::RCIter rcIter=(*it)->rcBegin(); rcIter!=(*it)->rcEnd();++rcIter)
		  if ( (*rcIter).first== pid ) {
		     itbegin = it;
		     return;
		  }
	    }
	    else{
	       itbegin = it;
	       return;
	    }
	 }
      }
      break;
    default: 
      printf("\n  Input topo or type is invalid.\n"); 
      break;     
   }
   itbegin=itend; 
#endif
}


inline void processingGeomFilter(mesh_iter& ibegin, mesh_iter& iend, void* ptr, int type, int topo)
{
    if(ibegin==iend)
       return; 
    GEntity* gent = (GEntity*)ptr; 
    for(mesh_iter it = ibegin; it!= iend; ++it)
      if((*it)->getClassification() == gent) {
	 ibegin = it;  
	 return; 
      }
    ibegin = iend; 
}

inline void processingNonFilter(mesh_iter& ibegin, mesh_iter& iend, void* ptr, int type, int topo)
{}

#endif
