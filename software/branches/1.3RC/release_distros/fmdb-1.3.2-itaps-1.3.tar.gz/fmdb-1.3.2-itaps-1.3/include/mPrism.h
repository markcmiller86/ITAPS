/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MPRISM_H_
#define _MPRISM_H_
#include "mRegion.h"

  class mEdge;
  class mVertex;
  class mFace;
  /**
     mPrism implement specific templates for the prismatic (or wedge)
     element.
  */
  class mPrism : public mRegion
    {
    protected:
       mEntity* down_adj[9]; 
       short int down_adj_dim; 

    public:
          static short int pmev[9][2];
          static short int pmfv[5][4];
          static short int pmfe[5][4];

          static short int pmve[6][2];
          static short int pmvf[6][3];
          static short int pmef[9][2];
	  
      virtual ~mPrism();
      mPrism ();
      /// Constructor using 6 vertices
      mPrism (mVertex *v1, 
	      mVertex *v2, 
	      mVertex *v3, 
	      mVertex *v4, 
	      mVertex *v5, 
	      mVertex *v6,
	      GEntity *classification);
      /// Constructor using 9 edges
      mPrism (mEdge *e1, mEdge *e2, mEdge *e3, mEdge *e4, mEdge *e5, mEdge *e6, 
	      mEdge *e7, mEdge *e8, mEdge *e9, GEntity *classification);
      /// Constructor using 5 face
      mPrism (mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, 
	      GEntity *classification);
      /// This is an mEntity::PRISM
      inline mEntity::mType getType() const {return PRISM;}
      /// Template members
      virtual int getNbTemplates (int what) const;
      /// Template members
      virtual mEntity* getTemplate (int ith , int what , int with) const;
      /// Debug stuff
      virtual void print() const;
      /// Get the dimension of the entity through a static function
      /// Useful for template algorithms
      inline static int getDim () {return 3;}
    
          // adjacency related
      void add (mEntity* m) {}
      void appendUnique (mEntity* m) {}
      void del (mEntity* m) {}
      
      int size (int what)const;
      mEntity* get(int what, int ith)const;
      void deleteAdjacencies(int what) {}
      mEntity * find(mEntity* m) const;

      inline void setFace (mEntity* me,  int pos)
      {
	 if(down_adj_dim==2)
	    down_adj[pos]= me;
      }
			
    };

#endif 
