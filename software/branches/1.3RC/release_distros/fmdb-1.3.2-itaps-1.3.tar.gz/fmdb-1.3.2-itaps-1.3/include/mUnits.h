/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MUNITS_
#define _MUNITS_

const double mPi = 3.141592654;
const double mRad2Deg = 57.29577951;
const double mDeg2Rad = 0.017453292;
const double squareRootOf3 = 1.7320508;
const unsigned long bigprime =4294967291ul;

#endif
