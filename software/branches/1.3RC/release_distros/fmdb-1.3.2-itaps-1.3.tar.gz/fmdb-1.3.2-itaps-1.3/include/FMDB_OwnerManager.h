/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_OWNERMANAGER_H_
#define _FMDB_OWNERMANAGER_H_

/*
A container class for managing remote copies of
mesh entities in different partition boundaries
*/

#include <map>
#include <vector>
#include "FMDB_SharedInfo.h"
#include "mPart.h"

class mEntity;

class FMDB_OwnerManager 
{
  std::multimap <int,int> *theTopology;
  std::multimap <mEntity*,FMDB_SharedInfo> *allSharedInfos;
 public :
  typedef std::multimap<mEntity*,FMDB_SharedInfo>::const_iterator iter; 
  typedef std::multimap<int,int>::const_iterator iter_top; 
  FMDB_OwnerManager ();
  ~FMDB_OwnerManager ();
  void addRemoteCopy(mEntity* here, int pid, mEntity *there, bool p);
  // delete all the remote copies of this entity
  void deleteRemoteCopy(mEntity*); 
  void clearRemoteCopies();
  void addNeighbor(int, int otherside);
  bool isPeriodic(mEntity *);
  bool amITheOwnerOf (mEntity *);
  iter_top begin_top(int);
  iter_top end_top(int);
  iter_top begin_top();
  iter_top end_top();
  iter begin(mEntity*e);
  iter end(mEntity*e);
  iter begin();
  iter end();
  int count(mEntity*e);
  int count(int);
  void print();
  int find ( int nbProcs, int *procs);
  int create ( int nbProcs, int *procs);
  void getPartitionIds ( std::vector<int> &ids );
  void setPoorPid_asOwner(mPart* mesh);
};

#endif

