/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef PM_MODEL_UTIL_H
#define PM_MODEL_UTIL_H

#include "mPart.h"

void getSortedPids_poor_to_rich(mPart*,std::vector<int>&);
void getSortedPids_poor_to_rich_comm(mPart*, std::vector<int>&);
void getSortedPids_poor_to_rich(std::vector<mPart*>,std::list<int>&);
int comparePid(mPart*, int, int);

#endif
#endif /* FMDB_PARALLEL */
