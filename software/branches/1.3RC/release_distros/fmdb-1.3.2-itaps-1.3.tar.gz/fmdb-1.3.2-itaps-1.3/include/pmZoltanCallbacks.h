/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL
 
#ifndef _PM_ZOLTAN_CALLBACKS_H_
#define _PM_ZOLTAN_CALLBACKS_H_

#include "pmMigrationCallbacks.h"
#include "ParUtil.h"

/**
   A load balancer that uses Zoltan library.
   I have only implemented the interface for
   ParMetis graph partitioning method, it also
   can be used for HyperGraph method. 
*/
class pmZoltanCallbacks: public pmMigrationCallbacks
{
public :
  /// Algorithms available
  //  typedef enum Algorithm {LDiffusion,GDiffusion,Remap,MLRemap,Random,Octree,Serial, PARMETIS};   // add PARMETIS
  typedef enum Algorithm {PARMETIS, GRAPH, HYPERGRAPH};   // support PARMETIS through Zoltan
  typedef enum ParAlgorithm {PartKway, PartGeom, PartGeomKway, AdaptiveRepart ,RepartLDiffusion,RepartGDiffusion ,RepartRemap,RepartMLRemap, RefineKway};              // Sub methods of ParMetis 
private:
  /// save the algorithm
  Algorithm theAlgorithm;
  ParAlgorithm parAlgorithm;  // Sub methods of ParMetis
  int localNumParts;               // partition option: local number of parts 

public : 
  /// Constructor takes the algorithm as input
  //  pmZoltanCallbacks(Algorithm algo = Remap);
  pmZoltanCallbacks(Algorithm algo = PARMETIS);   
  /// this function interfaces with Zoltan
/*   virtual void partition(FMDB_distributed_graph2 &theGraph ,  */
/* 			 int *partitionVector); */

 virtual void partition(mPart* mesh, map<mEntity*, int>& POtoMove);
 virtual void partition(std::vector<mPart*>& , map<mEntity*, int*>& , map<mEntityGroup*, int*>& ); 
 virtual void partition(std::vector<mPart*>& , map<mEntity*, int*>& );
 /// change the algorithm
 void setAlgorithm (const Algorithm &algo);  
 void setParAlgorithm (const ParAlgorithm &algo);     // Set sub methods of ParMetis
//  Algorithm getAlgorithm();
 virtual int nbProcs() const { return ParUtil::Instance()->size();}

 void setLocalNumParts(int num) { localNumParts=num; }          // set local number of parts

};
 
bool deleteUserData(mEntity* ent,int);

class zoltanCB: public pmZoltanCallbacks
{
public :
  zoltanCB() 
    : pmZoltanCallbacks(pmZoltanCallbacks::PARMETIS){}
  virtual void * getUserData (mEntity* e, int dest_proc, int &size)
  {
    size = 0;
    return 0;
  } 
  virtual void recieveUserData (mEntity* e, int pid, int tag, void *buf) 
  {
  }
  virtual void deleteUserData (void *buf) 
  { free(buf); }  
  virtual void deleteEntityData (mEntity* e)
    {  }
    
 virtual void * getEntGrpUserData (mEntityGroup* e, int dest_proc, int &size) { size =0; return 0; }
 virtual void recieveEntGrpUserData (mEntityGroup* e, int pid, int tag, void *buf) {}
 virtual void deleteEntGrpUserData (void *buf)  { free(buf); }
 virtual void deleteEntGrpData (mEntityGroup* e) {} 

  bool useWeights() const {return false;} 
  float getWeight (mEntity*) const {return 1.0;}  
};

class migrationCB: public pmZoltanCallbacks
{
public :
  migrationCB() {}
  //   : pmZoltanCallbacks(pmZoltanCallbacks::LDiffusion){}
  virtual void * getUserData (mEntity* e, int dest_proc, int &size)
  {
    size = 0;
    return 0;
  } 
  virtual void recieveUserData (mEntity* e, int pid, int tag, void *buf) 
  {  }
  virtual void deleteUserData (void *buf) 
  { free(buf); }  
  virtual void deleteEntityData (mEntity* e)
    {  }

 virtual void * getEntGrpUserData (mEntityGroup* e, int dest_proc, int &size) { size =0; return 0; }
 virtual void recieveEntGrpUserData (mEntityGroup* e, int pid, int tag, void *buf) {}
 virtual void deleteEntGrpUserData (void *buf)  { free(buf); }
 virtual void deleteEntGrpData (mEntityGroup* e) {}

  bool useWeights() const {return false;} 
  float getWeight (mEntity*) const {return 1.0;}  
};
#endif  /* _PM_ZOLTAN_CALLBACKS_H_ */
#endif 	/* FMDB_PARALLEL */

