/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MREGION_H_
#define _MREGION_H_

#include "mEntity.h"
class mEdge;
class mFace;
/**
   mRegion is the base class for all 3D elements
   It's impossible to find a common template for
   all 3D elements like we did with faces. The only
   thing that is common is that the dimension is 3.
   
   Some members are also common to all regions.
*/
  class mRegion  : public mEntity
  {
  public:
    mRegion();
    virtual ~mRegion() {}
    /// Dimension is 3
    inline int getLevel()const{return 3;};
    /// Gives the common edge to 3 regions
    mEdge *commonEdge (mRegion *r1, mRegion *r2);
    /// Gives the common face to 2 regions
    mFace *commonFace (mRegion *r);
    /// Get the dimension of the entity through a static function
    /// Useful for template algorithms
    inline static int getDim () {return 3;}
  
    int getId() const {return 0; }
    void setId(int id) {}
  };
#endif 
