/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef PM_MIGRATE_UTIL_H
#define PM_MIGRATE_UTIL_H

#include <list>
#include <vector>
#include <map>
#include <set>
#include "mPart.h"
#include "mEntity.h"
#include "pmUtility.h"
#include "pmDataExchanger.h"
#include "pmMigrationCallbacks.h"
#include "mMesh.h"

#define REGULAR_MIGRATION 0
#define LOAD_BALANCE 1

// **********************************************
//     structure used for communication
// **********************************************
struct packedEnt
{
  mEntity *sender;
  short int numDE;
  short int gTag;
  short int gType;
  short int numRC;
  short int numBP;
#ifdef MATCHING
  int numMatch;
#endif
}__attribute__((aligned (8)));

struct packedVertex
{
  double coord[3];
  int iD;
  short int numParam;
#ifdef MATCHING
  int numMatch;
#endif
}__attribute__((aligned (8))); 

void set_subtract(std::set<int> A, std::set<int> B, std::set<int>& C);
void exchangeEntitiesToBounce(std::list<rc_struct_2>&);
void exchangeEntitiesToBroadcast(std::list<rc_struct_2>&);


void pmLoadBalance(mPart* mesh, pmMigrationCallbacks &cb);

void pmLoadBalance(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb);  // load balance on multiple parts per proc

int pmMerge(mPart* mesh, pmMigrationCallbacks &cb);

int pmPartMigration(mPart* mesh, int dimToMove,std::list<mEntity*>& entities,
                    pmMigrationCallbacks &cb,
                    std::list<mEntity*>* rmE, std::list<mEntity*>* newE,
                    std::vector<mEntityGroup*>& rmEG, std::vector<mEntityGroup*>& newEG); 

int pmPartMigration(std::vector<mPart*>&meshes,                             // migrate a whole part
		    int source_pid, 
		    int target_rank, 
		    pmMigrationCallbacks &cb); 

int pmPartMigration(mPart* mesh, pmMigrationCallbacks &cb,
 		    std::list<mEntity*>& vtsOnCB, 
		    std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
                    std::list<mEntity*>* rmE, std::list<mEntity*>* newE, 
 		    std::vector<mEntityGroup*>& rmEG, std::vector<mEntityGroup*>& newEG); 

int migrateMeshEntities(mPart* mesh, std::map<mEntity*,int>& POtoMove, pmMigrationCallbacks& cb);
int migrateMeshEntities(mPart*mesh, std::map<mEntity*,int>& POtoMove, pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE, std::list<mEntity*>* newE,
                        std::vector<mEntityGroup*>& rmEG, std::vector<mEntityGroup*>& newEG);
					  
int migrateMeshEntities(std::vector<mPart*>& meshes,  
                        std::map<mEntity*,int*>& POtoMove,
		        pmMigrationCallbacks& cb);

int migrateMeshEntities(std::vector<mPart*>& meshes, std::map<mEntity*,int*>& POtoMove,
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE, std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG, std::vector<mEntityGroup*>& newEG);

int migrateMeshEntities(std::vector<mPart*>& meshes, std::map<mEntity*,int*>& POtoMove,
			std::map<mEntityGroup*, int*>& EntGrpToMove, pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE, std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG, std::vector<mEntityGroup*>& newEG);

// migration helper functions
void getFamily(mEntity* ent, std::list<mEntity*>& family);
void printFamily(mEntity* ent);

void getEntitiesToHandle(std::map<mEntity*,int>& entitiesToMove,
 			 std::set<mEntity*>* entitiesToHandle);        

void getEntitiesToHandle(std::map<mEntity*, int*>& entitiesToMove,
			 std::map<mEntity*, int>* entitiesToHandle);           // local_part_id  

void getEntityGroupsToHandle(std::map<mEntity*,int*>& entitiesToMove,
                             std::map<mEntityGroup*, int*>& egsToHandle);

void setBPs(int, std::map<mEntity*,int*>& POToMove, std::map<mEntity*, int>* entitiesToHandle); 

void exchangeBPs(std::set<mEntity*>* entitiesToHandle); 
void exchangeBPs(map<mEntity*, int>* entitiesToHandle); 

 void getEntitiesToHandle_and_setBPs(int meshDim, std::map<mEntity*,int*>& POToMove, std::map<mEntity*,int>* entitiesToHandle);
void getEntsToHandle_setBPs_nbrs(int meshDim, std::map<mEntity*, int*>& POToMove, std::map<mEntity*, int>* entitiesToHandle);

void updatePC_and_collectEntitiesToRemove(map<mEntity*, int>* entitiesToHandle,
					  map<mEntity*, int>* entitiesToRemove);

void removeUnusedEntities(mPart*, pmMigrationCallbacks &cb, int, std::set<mEntity*>*);
void removeUnusedEntities(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb, int dim,
                           map<mEntity*, int>* entitiesToRemove);

void exchangeEntities(std::vector<mPart*>& meshes, int, pmMigrationCallbacks &cb,    
                     int, std::map<mEntity*,int>&, std::list<mEntity*>*,
		     std::vector<mEntityGroup*>& newEG); 

void unifyEntitiesToMove(mPart* mesh, std::list<mEntity*>& entities);
typedef std::map<mEntity*, int> entityPidMap;

void getPOsToMoveFromPartitionVector(mPart *mesh, int from,
                		int *partitionVector, int delta_id, 
				std::map<mEntity*, int>& entitiesToMove);

void getPOsToMove(mPart* mesh, std::list<mEntity*>& entities,int ent_dim, std::map<mEntity*,int>& entitiesToMove);
void getPOsToMove_nbrs(mPart* mesh, std::list<mEntity*>& entities,int ent_dim, std::map<mEntity*,int>& entitiesToMove);
void getPOsToMove_nbrs2(mPart* mesh, std::list<mEntity*>& entities,int ent_dim, std::map<mEntity*,int>& entitiesToMove);

// new one
void getPOsToMoveForSnap(mPart* mesh, std::list<mEntity*>& vtsOnCB, 
		      std::list<std::pair<mEntity*,mEntity*> > &vtfcPairs,
		      std::map<mEntity*,int>& entitiesToMove);
		      

/* Ghost entity creation & deletion functions (to be called by API)*/
int createGhost(mMesh* mesh, pmMigrationCallbacks & migrCB, int gDim, int bDim, int numLayer, int include_copy);

int deleteGhostEntities(mMesh* mesh);
#endif
#endif /* FMDB_PARALLEL */
