/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MITERATOR_H_
#define _MITERATOR_H_

#include "mEntityContainer.h"
#include "mEntity.h"
#include <vector>
#include <list>

#include "modeler.h"

using namespace std;

class mIterator: public std::iterator <mEntity*, int> {
  protected :
    typedef mPartEntityContainer::iter iter;
    typedef mPartEntityContainer::CONTAINER cntr;
    iter theBeg;
    iter theEnd;
    iter theIter;
    cntr container;
  public:
    inline mIterator(const iter &begin, const iter &end);
    inline mIterator(){};
    virtual ~mIterator();
    inline bool operator != (mIterator const &) const;
    inline bool operator == (mIterator const &) const;
    inline mEntity * operator *() const;
    inline bool end() const {return theIter == theEnd;}
    // This is being used for the C-interface. Don't use
    // it in C++! 
//    virtual void next() = 0;
    inline void reset() {theIter = theBeg;}
  };

  class mFullIterator : public mIterator 
  {
  private:
    int dim;
    mPartEntityContainer *allEntities;
    int typ;  // type 1 : entityset iterator
             // type -2 ~ 0 : mesh iterator
    GEntity *ge;

  public:
    inline mFullIterator(const iter &begin, const iter &end, mPartEntityContainer *mc, int d);
    inline mFullIterator(mPartEntityContainer *mc, int d, GEntity *gent);
    inline void erase_adj();
    inline mEntity* get() const;
    inline bool end() const;
    inline mPartEntityContainer * getEntities ();
    void (mFullIterator::*next_iter)();
    inline void next() {(this->*next_iter)();}
    void next_const();
    void next_dynamic();
    inline void set_dim(int d);
    inline int get_dim();

    inline mFullIterator& operator++()
    {
      theIter++;
      return *this;
    }

    inline mFullIterator operator++(int)
    {
      mFullIterator tmp = *this;
      ++(*this);
      return tmp;
    }
  };


  class mLeavesIterator : public mIterator 
  {
  public:
    inline mLeavesIterator(const iter &begin, const iter &end);
    inline mLeavesIterator& operator++()
    {
      while(1)
	{
	  ++theIter;
	  if(theIter == theEnd)break;
	  mEntity *e = *theIter;
	  if(!e->isAdjacencyCreated(e->getLevel()))break;
	}
      return *this;
    }
    inline mLeavesIterator operator++(int)
    {
      mLeavesIterator tmp = *this;
      ++(*this);
      return tmp;
    }
    virtual void next();
  };

  class mClassIterator : public mIterator 
  {
    int iClass;
    int iOnWhat;
  public:
    inline mClassIterator(const iter &begin, const iter &end, int i, int w);
    inline mClassIterator& operator++()
    {
      while(1)
	{
	  ++theIter;
	  if(theIter == theEnd)break;
	  mEntity *e = *theIter; 
	  pGEntity g = e->getClassification();
	  if(!e->isAdjacencyCreated(e->getLevel()))
	    if(GEN_tag(g) == iClass && GEN_type(g) == iOnWhat)
	      break;
	}
      return *this;
    }
    inline mClassIterator operator++(int)
    {
      mClassIterator tmp = *this;
      ++(*this);
      return tmp;
    }
    virtual void next();
  };

  class mClassClosureIterator : public mIterator 
  {
    int iClass;
    int iOnWhat;
    mPartEntityContainer *cont;
  public:
    inline mClassClosureIterator(const iter &begin, const iter &end, int i, int w);
    inline mClassClosureIterator& operator++();
    virtual void next();
  };


  inline mIterator :: mIterator (const iter &begin, const iter &end)
    : theBeg(begin), theEnd (end), theIter(begin)
  {
  }

  inline mEntity* mIterator :: operator * () const
  {
    return *theIter;
  }

  inline bool mIterator :: operator != (mIterator const & other) const
  {
    return theIter != other.theIter;
  }

  inline bool mIterator :: operator == (mIterator const & other) const
  {
    return theIter == other.theIter;
  }


  inline mFullIterator :: mFullIterator (const iter &begin, const iter &end, mPartEntityContainer *mc, int d)
    : mIterator(begin,end), dim(d), allEntities(mc)
  {
    dim = d;
    allEntities = mc;
    next_iter = &mFullIterator::next_const;
  }

  inline mFullIterator :: mFullIterator(mPartEntityContainer *mc, int d, GEntity *gent)
    : dim(d), allEntities(mc)
  {
    theBeg = allEntities->begin(dim);
    theEnd = allEntities->end(dim);
    for(mPartEntityContainer::iter it = theBeg; it != theEnd; ++it)
      if((*it)->getClassification() == gent)
        container.insert(*it);
    theBeg = container.begin();
    theIter = theBeg;
    theEnd = container.end();
    next_iter = &mFullIterator::next_const;
  }
  
  inline void mFullIterator::erase_adj()
  {
    if (theIter == theBeg)
    {
      theBeg++;
      theIter = theBeg;
    }
    else
    {
      theIter++;
    }
    next_iter = &mFullIterator::next_dynamic;
  }

  inline mEntity* mFullIterator::get() const
  {
    return *theIter;
  }

  inline bool mFullIterator::end() const
  {
    return theIter == theEnd;
  }

  inline mPartEntityContainer * mFullIterator::getEntities ()
  {
    return allEntities;
  }

  inline void mFullIterator::set_dim(int d)
  {
    dim = d;
  }

  inline int mFullIterator::get_dim()
  {
    return dim;
  }  



  inline mLeavesIterator :: mLeavesIterator (const iter &begin, const iter &end)
    : mIterator(begin,end)
  {
    while(1)
      {
        if(theIter == theEnd)break;
        mEntity *e = *theIter;
        if(!e->isAdjacencyCreated(e->getLevel()))break;
        ++theIter;
      }
  }


  inline mClassIterator :: mClassIterator (const iter &begin, const iter &end, int c, int w)
    : mIterator(begin,end), iClass(c),iOnWhat(w)
  {
    while(1)
      {
        if(theIter == theEnd)break;
        mEntity *e = *theIter;
        pGEntity g = e->getClassification();
        if(!e->isAdjacencyCreated(e->getLevel()))
          if(GEN_tag(g) == iClass && GEN_type(g) == iOnWhat)break;
        ++theIter;
      }
  }


  inline mClassClosureIterator :: mClassClosureIterator (const iter &begin, const iter &end, int c, int w)
    : mIterator(begin,end), iClass(c),iOnWhat(w)
  {
    throw 1;
  }

#endif



