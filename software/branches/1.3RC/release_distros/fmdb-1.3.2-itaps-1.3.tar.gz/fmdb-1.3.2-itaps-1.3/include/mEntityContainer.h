/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MENTITY_CONTAINER_H_
#define _MENTITY_CONTAINER_H_
	
#ifdef __cplusplus
#include <vector>
#include <set>
#include <list>
#include <algorithm>
#include "FMDBfwd.h"
#include "modeler.h"

const int _DIMS_ = 4;

  /**
     Less than operator for 2 mesh entities
  */
  class EntityLessThanKey 
    {
    public:
      bool operator()(mEntity* ent1, mEntity* ent2) const;
    };

  /**
     A container for upward and downward entities.
  */

  class mAdjacencyContainer
    {
    private:
      /// all adjacency containers are sdt::vectors<mEntity*>
      /// Design has changed because std::set for upwards was
      /// costy, pretty slow and was not allowing inlining because
      /// of virtual functions
      std::vector<mEntity*> mContainer;
    public:
      /// iter is the const iterator that you should use to browse
      /// adjacency
      typedef std::vector<mEntity*>::const_iterator iter;
      /// Constructor, reserves given room
      inline mAdjacencyContainer(int i=1){mContainer.reserve(i);}
      /// nothing to be done here
      inline ~mAdjacencyContainer() {}
      /// random access iterator
      inline mEntity* operator [] (int i); 
      /// add a mesh entity at the end of the container (push_back should be 
      /// more appropriate
      inline void add(mEntity* e);
      /// add a mesh entity to the container if it's not there yet
      inline void appendUnique(mEntity* e);
      /// deletes a mesh entity form the adjacency (do not delete the 
      /// mesh entity e itself !).
      inline void del(mEntity* e);
      /// same as operator []
      inline mEntity* get(int i) const;
      /// give how many adjacencies in the container
      inline int size() const;
      /// find if an adjacency is in the container
      inline mEntity* find(mEntity*) const;
      /// iterators
      inline iter begin() const {return mContainer.begin();}
      /// iterators
      inline iter end() const {return mContainer.end();}
      /// clear the container
      inline void clear();
    };

  inline mEntity*  mAdjacencyContainer::find(mEntity* ent) const 
    { 
      iter it = std::find (begin(),end(),ent);
      if(it == end())return 0;
      return *it;
    }

  inline void mAdjacencyContainer::clear(void) 
    {
      mContainer.clear();
    }
  
  inline mEntity* mAdjacencyContainer::operator[](int i) 
    { 
      return(mContainer[i]);
    }

  inline mEntity* mAdjacencyContainer::get(int i) const
    { 
      return(mContainer[i]);
    }

  inline void mAdjacencyContainer::del(mEntity* e)
    { 
      mContainer.erase ( std::remove (mContainer.begin(),mContainer.end(),e) , 
			 mContainer.end () );
    }

  inline void mAdjacencyContainer::add(mEntity* e)
    {
      mContainer.push_back(e);
    }

  inline void mAdjacencyContainer::appendUnique(mEntity* e)
    {
      if(!find(e))add(e);	
    }
  
  inline int mAdjacencyContainer::size() const 
    { 
      return mContainer.size();
    }

  /**
     A container for mesh entities (std::set).
  */

  class mPartEntityContainer
    {
      public :
  #ifdef _HAVE_LESS_THAN_
     /* keeps elements in order by verticies, good for debugging but very slow,
        recommended to use for same mesh comparison after changing the code, 
        otherwise can be omitted */ 
     typedef std::set<mEntity*,EntityLessThanKey> CONTAINER; 
  #else
     typedef std::set<mEntity*> CONTAINER;
  #endif
     typedef CONTAINER::iterator iter;
    private:
      std::list<mFullIterator*> curIterators[_DIMS_];
      CONTAINER *mEntities[_DIMS_];

    public:
      mPartEntityContainer();
      virtual ~mPartEntityContainer();
      iter begin(int what) const ;
      iter end(int what) const ;
      void add(mEntity* e);
      void del(mEntity* e);
      int  size(int what) const ;
      mEntity* find(mEntity*) const; 
      mFullIterator* getIterator(int dim);
      mFullIterator* getIterator(int dim, pGEntity gent);
      void deleteIterator (mFullIterator *it);
    };
#endif
#endif
