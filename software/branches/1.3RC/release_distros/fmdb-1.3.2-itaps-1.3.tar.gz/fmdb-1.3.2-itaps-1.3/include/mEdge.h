/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MEDGE_H_
#define _MEDGE_H_
#include "mEntity.h"

  class GEntity;
  typedef class mEntity * pPoint;

  class mVertex;
  /**
     The mEdge Class is the base class for
     edges i.e. entities of dimension 1.

     Edges have always 2 vertices, that's
     the only template that has to be provided.  
  */
  class mEdge : public mEntity 
    {
    protected:
      mEntity** up_adj; 
      mEntity* down_adj[2]; 
      short int up_adj_size; 
      
    public:
      virtual ~mEdge();
      /// Special constructor taking 2 vertices as input
      mEdge (mVertex *v1, mVertex *v2,GEntity *classification);
      /// getLevel returns 1 of course
      int getLevel()const;
      /// getType returns mEntity::EDGE
      inline mEntity::mType getType() const{return EDGE;}
      /// a shortcut for getting vertices easily
      inline mVertex *vertex(int) const;
      /// gives the common vertex of 2 edges
      inline mVertex *commonVertex (mEdge *) const;
      /// templates for an edge are basically none
      /// but function has to be overwritten
      virtual int getNbTemplates (int what) const;
      /// debug stuff
      virtual void print() const;
      /// Get the dimension of the entity through a static function
      /// Useful for template algorithms
      inline static int getDim () {return 1;}
      void setVertices (mVertex *v1, mVertex *v2);
      ///container for edge nodes
      std::vector <pPoint> pts;         /// higher-order node 

     // adjacency related    
     void add (mEntity* m);
     void appendUnique (mEntity* m); 
     void del (mEntity* m);   
     int size (int what)const 
     {
	 if(what==0)
	    return 2; 
	 if(what==2)
	    return up_adj_size; 

	 return getNbTemplates(what);  
     }
      
       mEntity* get(int what, int ith)const;
       void deleteAdjacencies(int what);
       mEntity * find(mEntity* m) const;

       int getId() const {return 0; }
       void setId(int id) {}
    };

  inline mVertex *mEdge::vertex(int i) const
    {
      // return (mVertex*)theAdjacencies[0]->get(i);
      return (mVertex*)down_adj[i]; 
    }

  inline mVertex *mEdge::commonVertex(mEdge *other) const
    {
      if(other->vertex(0) == vertex(0))return vertex(0);
      if(other->vertex(1) == vertex(0))return vertex(0);
      if(other->vertex(0) == vertex(1))return vertex(1);
      if(other->vertex(1) == vertex(1))return vertex(1);
      return 0;
    }

#endif 

