/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_ZOLTAN_LOADBALANCER_H_
#define _FMDB_ZOLTAN_LOADBALANCER_H_

#include "FMDB_LoadBalancer.h"
#include "ParUtil.h"

/**
   A load balancer that uses Zoltan library.
   I have only implemented the interface for
   ParMetis and the Octree.
*/
class FMDB_ZoltanLoadBalancer : public FMDB_LoadBalancerCallbacks
{
public :
  /// Algorithms available
  typedef enum Algorithm {LDiffusion,GDiffusion,Remap,MLRemap,Random,Octree,Serial};
private:
  /// save the algorithm
  Algorithm theAlgorithm;
public :
  /// Constructor takes the algorithm as input
  FMDB_ZoltanLoadBalancer (Algorithm algo = Remap);
  /// this function interfaces with Zoltan
  virtual void partition(FMDB_distributed_graph &theGraph , 
			 int *partitionVector);
  /// change the algorithm
  void setAlgorithm (const Algorithm &algo);  
  virtual int nbProcs() const { return ParUtil::Instance()->size();}
};

#endif //_FMDB_ZOLTAN_LOADBALANCER_H_

