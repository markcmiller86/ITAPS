/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _H_ParUtil
#define _H_ParUtil
#include <string>
#include <memory>
#include <iostream>
#include <vector>

#ifdef FMDB_PARALLEL
#include "mpi.h" 
#include "IPComMan.h"
#include <list>
#include "pmUtility.h"
#else 
typedef void* MPI_Comm;
#endif // end of #ifdef FMDB_PARALLEL
/**
   ParUtil is a Singleton. It gives some
   general services for parallel implementation.
*/

class ParUtil {
  ParUtil();
public:
    /// Constructor and destructors should be private but I'm fed up of this
    /// c++ compiler always shouting
  ~ParUtil();
  /// Message severity level
  typedef enum MessageLevel {DEBUG1,DEBUG2,INFO,WARNING,ERROR};
  /// returne the only instance
  static ParUtil* Instance();
  /// initialization, needed for mpi and IPComMan
  void init(MPI_Comm communicator=NULL); 

  /// adds a barrier
  void Barrier(int, const char*);
  /// close communications
  void Finalize(bool do_mpi_finalize);

  /// compute wall time
  double wTime () const;
  /// gets the processor name
  std::string processorName() const;
  /// set the verbosity level (0,1,2,3)
  inline void setVertbosityLevel(int i){vl = i;}
  /// prints a message, same format as printf
  void Msg(MessageLevel lev, char *fmt, ...);
  static void setBufferSize (int b) {buffer_size = b;}
  inline MPI_Comm setComm(MPI_Comm comm) { local_comm = comm; }
  inline MPI_Comm getComm() { return local_comm; }
#ifdef FMDB_PARALLEL
  inline int rank() { return myrank; }
  inline int size() { return mysize; }


  inline int getCurNumParts() {return curNumParts; }               // to support multiple parts per process 
  inline void setCurNumParts(int num) { curNumParts = num; }        
  inline void setTgtNumParts(int num) {tgtNumParts = num; }      
  inline int getTgtNumParts()  {return tgtNumParts; }
  inline void setUsrNumParts(int num) {usrNumParts = num; }
  inline int getUsrNumParts()  {return usrNumParts; }  
  inline int master() { return myrank==0; }
  /// Communication Manager
  inline IPComMan *ComMan() { return CM; }
  inline int get_maxMeshDim() { return maxMeshDim; }
  inline void set_maxMeshDim(int dim) { maxMeshDim = dim; }

  inline void getPartitions(std::list<partition_struct*>& pset) { pset=partitions; }
  inline int  getNumPartitions() {return partitions.size(); }
  inline void addPartition( partition_struct* par) { partitions.push_back(par);}
  inline void rmvPartition( partition_struct* par) { 
     partitions.pop_front();  // assume one partition in the whole mesh
  }

#else
  /// gets the processor id
  inline int rank() { return 0; }
  /// gets the number of processors
  inline int size() { return 1; }
  /// tells if it's processor 0
  inline int  master() { return 1; }
#endif
  inline void   resetBarrierSensor() { timeSpentOnBarriers = 0; }
  inline double getBarrierSensor()   { return timeSpentOnBarriers; }
private:
  static std::auto_ptr<ParUtil> instance;
  int vl;
  std::string procName;
  MPI_Comm local_comm; 
  double timeSpentOnBarriers;
#ifdef FMDB_PARALLEL
  int initialized;
  int finalized;
  int myrank;
  int mysize; 
  IPComMan *CM;
  int maxMeshDim;
  int curNumParts;                   // current_local_num_parts_per_process, max_num 
  int tgtNumParts;                   // target_local_num_parts_per_process, max_num
  int usrNumParts; 

  std::list<partition_struct*>  partitions; 

public: 
  std::vector<int> localPids;             // local part ids for on-process parts 
#endif
  static int buffer_size; 
};

#endif
