/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL

#ifndef _PM_DATA_EXCHANGER_H_
#define _PM_DATA_EXCHANGER_H_

#include "mPart.h"
#include "ParUtil.h"
#include "pmModel.h"

class mEntity;
class pmModel; 

class pmDataExchanger
{
  public :
 
  int numPart;  
  pmDataExchanger() {numPart=1; }; 

  /// get a message size 
  virtual int msg_size() = 0; 

  /// user sends a message related to mesh entity *e to proc si.pid() to the counterpart si.getRemotePointer(). 
  /// If the size of the message is not fixed, user is responsible for allocating it inside the function.
  /// src: source local pid, dest: destination local pid
  virtual void fill_buffer (mEntity *e, int src, int dest, mEntity *remoteEnt, void *&msg_send) = 0;

  /// user recieve data *buf form proc pid.
  virtual void receiveData (void *msg_recv, int pid_from) = 0; 
};

template <class Iterator>
void genericDataExchanger(const Iterator &beg, const Iterator &end, pmDataExchanger& de)
{
  IPComMan *CM = ParUtil::Instance()->ComMan();
//  CM->set_comm_validation(IPComMan::Neighbors);  
  CM->set_comm_validation(IPComMan::All_Reduce); 
  CM->set_tag(0);
  
  int m_size = de.msg_size();
  CM->set_fixed_msg_size(m_size);
  int num_sent = 0, num_recvd = 0;

  void *msg_send;
  if (m_size)
  {
    msg_send = CM->alloc_msg(m_size);
  }

  mEntity* ent;

  for( Iterator it=beg; it != end ; ++it)
  {
    ent = *it;
    if (ent->getNumRemoteCopies()==0)
      continue;
    for (mEntity::RCIter rcIter=ent->rcBegin(); rcIter!=ent->rcEnd();++rcIter)
    {
      de.fill_buffer(ent, -1, rcIter->first, rcIter->second, msg_send);
      if (msg_send)
      {
        if (m_size)
        {
          CM->send(rcIter->first/de.numPart, msg_send);
        }
        else
        {
          CM->send(rcIter->first/de.numPart, msg_send, de.msg_size());
          CM->free_msg(msg_send);
        }
      }
    }
  }
  CM->finalize_send();
  if (m_size)
  {
    CM->free_msg(msg_send);
  }
 
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    de.receiveData (msg_recv, pid_from);
    CM->free_msg(msg_recv);
  }
}

/// Iterator is for pair or map 
template <class Iterator>
void genericDataExchanger2(const Iterator &beg, const Iterator &end, pmDataExchanger& de)
{
  IPComMan *CM = ParUtil::Instance()->ComMan();
//  CM->set_comm_validation(IPComMan::Neighbors);  
   CM->set_comm_validation(IPComMan::All_Reduce);
/*
  set<int> nbrs;
  pmModel::Instance()->getNbrPTs(nbrs);
  /// Set new neighbors
  set<int> nbrs_proc;
  set<int>::iterator setIt;
  for(setIt=nbrs.begin(); setIt!=nbrs.end(); setIt++)
    nbrs_proc.insert((*setIt)/de.numPart);
  ParUtil::Instance()->ComMan()->set_Nbrs(nbrs_proc);
*/

  CM->set_tag(0);
  int m_size = de.msg_size();
  CM->set_fixed_msg_size(m_size);
  int num_sent = 0, num_recvd = 0;

  void *msg_send;
  if (m_size)
  {
    msg_send = CM->alloc_msg(m_size);
  }

  mEntity* ent;

  for( Iterator it=beg; it != end ; ++it)
  {
    ent = it->first; 
    int src = it->second; 

    if (ent->getNumRemoteCopies()==0)
      continue;
    for (mEntity::RCIter rcIter=ent->rcBegin(); rcIter!=ent->rcEnd();++rcIter)
    {
      de.fill_buffer(ent, src, rcIter->first, rcIter->second, msg_send);
      if (msg_send)
      {
        if (m_size)
        {
          CM->send(rcIter->first/de.numPart, msg_send);
        }
        else
        {
          CM->send(rcIter->first/de.numPart, msg_send, de.msg_size());
          CM->free_msg(msg_send);
        }
      }
    }
  }
  CM->finalize_send();
  if (m_size)
  {
    CM->free_msg(msg_send);
  }
 
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    de.receiveData (msg_recv, pid_from);
    CM->free_msg(msg_recv);
  }
}

#endif
#endif
