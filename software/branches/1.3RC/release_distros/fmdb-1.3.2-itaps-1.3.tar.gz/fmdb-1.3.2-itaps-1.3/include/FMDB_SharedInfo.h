/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_SHAREDINFO_H_
#define _FMDB_SHAREDINFO_H_


  class mEntity;
  
  struct ltshared
  {
    bool operator()(const mEntity* e1, const mEntity* e2) const
    {
      return e1 < e2;
    }
  };
  
  class FMDB_SharedInfo
  {
  private:
    int PID;
    mEntity *remote;
    bool periodic;
  public:
    inline FMDB_SharedInfo(int p, mEntity* e, bool per)
      :PID(p),remote(e), periodic(per)
    {}
    inline mEntity *getRemotePointer() {return remote;}
    inline int pid() const {return PID;}
    inline bool isPeriodic() const {return periodic;}
  };
#endif
