/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MFACE_H_
#define _MFACE_H_
#include "mEntity.h"

  class GEntity;
  class mVertex;
  class mEdge;
  /// The Face is implemented generally i.e a face can have N edges
  /// The assumption is that the number
  /// of edges is equal to the number of
  /// vertices and that 2 consecutive edges
  /// share one vertex, that's the template
  /// Special constructors for triangles & quads
  class mFace : public mEntity 
    {
    protected:
      mEntity** up_adj;
      mEntity* down_adj[4];
      /// for sppeeding (QUAD or TRI or FACE)
      mType typ;
      short int up_adj_size;
      short int down_adj_dim; 
      
     public:
      virtual ~mFace();
      mFace ();
      /// Special constructor for creating a triangle with vertices
      mFace (mVertex *v1, mVertex *v2, mVertex *v3, GEntity *classification);
      /// Special constructor for creating a triangle with edge
      mFace (mEdge *v1, mEdge *v2, mEdge *v3, GEntity *classification, int *dir = 0);
      /// Special constructor for creating a quad with vertices
      mFace (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4, GEntity *classification);
      /// Special constructor for creating a quad with edges
      mFace (mEdge *v1, mEdge *v2, mEdge *v3, mEdge *v4, GEntity *classification, int *dir = 0);
      /// getLevel returns 2
      int getLevel()const;
      /// getType could return QUAD, TRI or FACE
      inline mEntity::mType getType ()const{return typ;}
      /// Get the common vertex of 3 faces
      mVertex *commonVertex (mFace *f1, mFace *f2);
      /// Get the common edge of 2 faces
      mEdge *commonEdge (mFace *f1);
      /// Template members

      mEdge * subtractEdges (mEdge* e1, mEdge* e2); // Created by Alex 01.15.08 for TETs case in FMDB.cc, assumes
                                                    // that the face has 2 of the edges as parameters

      virtual int getNbTemplates (int what) const;
      /// Template members
      virtual mEntity* getTemplate (int ith , int what , int with) const;
      /// Debug stuff
      virtual void print() const;
      /// Get the dimension of the entity through a static function
      /// Useful for template algorithms
      inline static int getDim () {return 2;}
  
      // adjacency related 
       void add (mEntity* m);      
       void appendUnique (mEntity* m);  
       void del (mEntity* m); 
        int size (int what)const 
	{
	  if(what==1)
	  {
	    return (typ == TRI)?3:4; 
	  }
	  
	  if(what==3)
	    return up_adj_size; 
          return getNbTemplates(what);  
	}

       mEntity* get(int what, int ith)const; 
       void deleteAdjacencies(int what);
       mEntity* find(mEntity* me)const; 
       inline void setEdge (mEntity* me,  int pos)
       {
	 if(down_adj_dim==1)
  	   down_adj[pos]= me; 
       }
   
       int getId() const {return 0; }
       void setId(int id) {}
    };

#endif 

