/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MEXCEPTION_H_
#define _MEXCEPTION_H_

class mException  
{
  int theLine;
  char theFile[256];
  
public:
  mException(const int Line, const char *file, const char *text); 
  virtual ~mException();
  
};

#endif 
