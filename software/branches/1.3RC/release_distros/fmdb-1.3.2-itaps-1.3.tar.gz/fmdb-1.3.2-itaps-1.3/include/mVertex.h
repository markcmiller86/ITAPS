/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MVERTEX_H_
#define _MVERTEX_H_

#include "mPoint.h"
#include "mEntity.h"

  class GEntity;
  class mIdGenerator;
  /**
     mVertex is the vertex class i.e. entities of
     dimsnsion 0.
  */

  class mVertex : public mEntity 
    {
  
    protected:
      /// A point (position)
      SCOREC::Util::mPoint p;
      /// a random value computed from vertex iD
      /// we store this value because random values are
      /// expensive to compute
	//int RAND;
      int iD; 
      mEntity** up_adj;
      short int up_adj_size;

   public:      
      /// Constructor taking an id as input
      mVertex(int theId, const SCOREC::Util::mPoint & ,GEntity *classif);
      /// Constructor taking an idGenerator as input
      mVertex(mIdGenerator &theIdGenerator , const SCOREC::Util::mPoint &, GEntity *classif);
      /// returns a copy of the point
      inline SCOREC::Util::mPoint point() const {return p;}
      /// only for meshsim compatibility (DO NOT USE THAT)
      inline SCOREC::Util::mPoint* ppoint() {return &p;}
      /// returns RAND
	//int getRAND();
      /// delete the id in the id generator (destruction)
      void deleteId(mIdGenerator &theIdGenerator);
      virtual ~mVertex();
      /// Dimsnsion is 0
      virtual int getLevel() const;
      /// Type is mEntity::VERTEX
      virtual mEntity::mType getType() const{return VERTEX;}
      /// Debug stuff
      virtual void print() const;
      /// Get the dimension of the entity through a static function
      /// Useful for template algorithms
      inline static int getDim () {return 0;}
      /// move the vertex to another location
      inline void move (const SCOREC::Util::mPoint &pt) { p = pt;}
      
      /// change the iD of the Vertex (dangerous !!!)
      virtual int getId() const {return iD;} 
      inline void setId( int id ) {iD = id;}

      inline void setCoord(double x, double y, double z)
       { p[0] = x;
         p[1] = y;
	 p[2] = z;}
      inline void getCoord(double& x, double& y, double& z)
      {
        x = p[0];
	y = p[1];
	z = p[2]; 
      }

      // adjacency related
      virtual void add (mEntity* m);  
      virtual void appendUnique (mEntity* m);
      virtual void del (mEntity* m); 
      virtual int size (int what)const 
      { 
	 if(what==1) 
	    return up_adj_size;  
	 else
	    return 0; 
      } 
      
      virtual mEntity* get(int what, int ith)const; 
      virtual void deleteAdjacencies(int what); 
      virtual mEntity * find(mEntity* m) const;  
};

  class VertexLexicographicLessThan 
    {
      double EPS;
    public:
      VertexLexicographicLessThan (double eps = 1.e-6); 
      bool operator()(mVertex* ent1, mVertex* ent2) const;
    };

#endif 

