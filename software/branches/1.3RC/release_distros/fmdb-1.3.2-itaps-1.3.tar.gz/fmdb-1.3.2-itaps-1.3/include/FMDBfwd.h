/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef H_FMDBfwd
#define H_FMDBfwd

#ifdef __cplusplus

  class mPart;
  class mEntity;
  class fakeList;
  class mIterator;
  class mFullIterator;
  class mAttachableData;
  class FMDB_LoadBalancerCallbacks;
  class pmMigrationCallbacks;
  class mCommonBdry;
  class pmEntity;
  class mEntityGroup;
#endif /* __cplusplus */
#endif
