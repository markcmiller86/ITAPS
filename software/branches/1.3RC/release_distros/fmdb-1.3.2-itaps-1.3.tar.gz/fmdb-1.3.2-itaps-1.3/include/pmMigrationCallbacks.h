/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL
#ifndef _PM_MIGRATION_CALLBACKS_H_
#define _PM_MIGRATION_CALLBACKS_H_

#include <map>
#include <vector>

using std::map; 
using std::vector; 

class mEntity;
class mPart; 
class mEntityGroup;
// class FMDB_distributed_graph2;
/**
   Load balancing callbacks for FMDB. User must
   derive a class form FMDB_LoadBalancerCallbacks
   if he wants to load balance a mesh. mPart::loadBalance
   takes this callback as parameter.
*/
class pmMigrationCallbacks
{
public :
  /// from a given graph, we retrieve a partitionVector
  //  virtual void partition(FMDB_distributed_graph2 &theGraph , int *partitionVector) = 0;
  virtual void partition(mPart* mesh, map<mEntity*, int>& POtoMove) = 0;  // modify the parameters, do not use global part integer ids.
  virtual void partition(vector<mPart*>& mesh, map<mEntity*, int*>& POtoMove, map<mEntityGroup*, int*>& ) = 0;
  virtual void partition(vector<mPart*>& mesh, map<mEntity*, int*>& POtoMove) = 0; 
  /// do we use a weighted graph
  virtual bool useWeights() const = 0;
  /// node weight for a given mEntity
  virtual float getWeight (mEntity *) const = 0;
  /// user can create data's attached to a given mesh entity
  /// data's have size "size" 
  virtual void * getUserData (mEntity *, int dest_proc, int &size) = 0; 
  /// user has to provide a way to delete its own data (delete or free).
  virtual void deleteUserData (void *) = 0; 
  /// user has to take care of data associated with mesh entities (via pMeshDataId etc.)
  virtual void deleteEntityData (mEntity *) = 0; 
  /// user recieves its data's. mEntity is now the mesh entity on the 
  /// remote side.
  virtual void recieveUserData (mEntity *, int pid, int tag, void *buf) = 0;
  virtual int nbProcs() const = 0;

  virtual void * getEntGrpUserData (mEntityGroup *, int dest_proc, int &size) = 0;
  virtual void deleteEntGrpUserData (void *) = 0;
  virtual void deleteEntGrpData (mEntityGroup *) = 0;
  virtual void recieveEntGrpUserData (mEntityGroup *, int pid, int tag, void *buf) = 0;
};

#endif
#endif


