/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FLEXDB

#ifndef _H_M_SHAPE_DB_
#define _H_M_SHAPE_DB_

#include "mPart.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mHex.h"
#include "mPrism.h"
#include "mPyramid.h"
#include "oldFMDB.h"
#include "FMDB_cint.h"

// edge - basic
mEdge* createE(mPart* mesh, mVertex* v1, mVertex* v2, pGEntity gent);
void deleteE(mPart*,mEntity*);

// edge - ve
mEdge* createE_ve(mPart* mesh, mVertex* v1, mVertex* v2, pGEntity gent);
void deleteE_ve(mPart*,mEntity*);	

// tri - basic
mFace* createTri_E(mPart*, mEdge*, mEdge*, mEdge*,pGEntity,int*);
mFace* createTri_V(mPart*,mVertex*, mVertex*,mVertex*,pGEntity,int*);
void deleteF(mPart*,mEntity*);

// tri - vf
mFace* createTri_E_vf(mPart*, mEdge*, mEdge*, mEdge*,pGEntity,int*);
mFace* createTri_V_vf(mPart*,mVertex*, mVertex*,mVertex*,pGEntity,int*);
void deleteF_vf(mPart*,mEntity*);

// tri - ef
mFace* createTri_E_ef(mPart*, mEdge*, mEdge*, mEdge*,pGEntity,int*);
mFace* createTri_V_ef(mPart*,mVertex*, mVertex*,mVertex*,pGEntity,int*);
void deleteF_ef(mPart*,mEntity*);

// tri - vf_ef
mFace* createTri_E_vf_ef(mPart*, mEdge*, mEdge*, mEdge*,pGEntity,int*);
mFace* createTri_V_vf_ef(mPart*,mVertex*, mVertex*,mVertex*,pGEntity,int*);
void deleteF_vf_ef(mPart*,mEntity*);

// Quad - basic
mFace* createQuad_E(mPart*, mEdge*, mEdge*, mEdge*,  mEdge*, pGEntity,int*);
mFace* createQuad_V(mPart*,mVertex*, mVertex*,mVertex*,mVertex*,pGEntity,int*);

// Quad - vf
mFace* createQuad_E_vf(mPart*, mEdge*, mEdge*, mEdge*,  mEdge*, pGEntity,int*);
mFace* createQuad_V_vf(mPart*,mVertex*, mVertex*,mVertex*,mVertex*,pGEntity,int*);

// Quad - ef
mFace* createQuad_E_ef(mPart*, mEdge*, mEdge*, mEdge*, mEdge*, pGEntity,int*);
mFace* createQuad_V_ef(mPart*,mVertex*, mVertex*,mVertex*,mVertex*,pGEntity,int*);

// Quad - vf_ef
mFace* createQuad_E_vf_ef(mPart*, mEdge*, mEdge*, mEdge*, mEdge*, pGEntity,int*);
mFace* createQuad_V_vf_ef(mPart*,mVertex*, mVertex*,mVertex*,mVertex*,pGEntity,int*);

// Tet - basic
mTet* createTet_V(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR(mPart*,mEntity*);

// Tet - vr
mTet* createTet_V_vr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_vr(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_vr(mPart*,mEntity*);

// Tet - er
mTet* createTet_V_er(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_er(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_er(mPart*,mEntity*);

// Tet - fr
mTet* createTet_V_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_fr(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_fr(mPart*,mEntity*);

// Tet - vr_er
mTet* createTet_V_vr_er(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_vr_er(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_vr_er(mPart*,mEntity*);

// Tet - vr_fr
mTet* createTet_V_vr_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_vr_fr(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_vr_fr(mPart*,mEntity*);

// Tet - er_fr
mTet* createTet_V_er_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_er_fr(mPart*,mEntity*);

// Tet - vr_er_fr
mTet* createTet_V_vr_er_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mTet* createTet_F_vr_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
void deleteR_vr_er_fr(mPart*,mEntity*);

// Hex - basic
mHex* createHex_F(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - vr
mHex* createHex_F_vr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_vr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - er
mHex* createHex_F_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_er(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - fr
mHex* createHex_F_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - vr_er
mHex* createHex_F_vr_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_vr_er(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - er_fr
mHex* createHex_F_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_er_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - vr_fr
mHex* createHex_F_vr_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_vr_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Hex - vr_er_fr
mHex* createHex_F_vr_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* createHex_V_vr_er_fr(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);

// Prism - basic
mPrism* createPrism_F(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);

// Prism - vr
mPrism* createPrism_F_vr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_vr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);

// Prism - er
mPrism* createPrism_F_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_er(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);
			    
// Prism - fr
mPrism* createPrism_F_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);
			    
// Prism - vr_er
mPrism* createPrism_F_vr_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_vr_er(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);

// Prism - vr_fr
mPrism* createPrism_F_vr_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_vr_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);

// Prism - er_fr
mPrism* createPrism_F_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_er_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,mVertex*,pGEntity);

// Prism - vr_er_fr
mPrism* createPrism_F_vr_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* createPrism_V_vr_er_fr(mPart*,mVertex*,mVertex*,mVertex*
	
	            ,mVertex*,mVertex*,mVertex*,pGEntity);
// Pyramid - basic
mPyramid* createPyramid_F(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);

// Pyramid - vr
mPyramid* createPyramid_F_vr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_vr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);

// Pyramid - er
mPyramid* createPyramid_F_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_er(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);
			    
// Pyramid - fr
mPyramid* createPyramid_F_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);
			    
// Pyramid - vr_er
mPyramid* createPyramid_F_vr_er(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_vr_er(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);

// Pyramid - vr_fr
mPyramid* createPyramid_F_vr_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_vr_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);

// Pyramid - er_fr
mPyramid* createPyramid_F_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_er_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);

// Pyramid - vr_er_fr
mPyramid* createPyramid_F_vr_er_fr(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPyramid* createPyramid_V_vr_er_fr(mPart*,mVertex*,mVertex*,mVertex*
		            ,mVertex*,mVertex*,pGEntity);
// error functions 
mFace* error_createTri_E(mPart*, mEdge*, mEdge*, mEdge*,pGEntity,int*);
mFace* error_createQuad_E(mPart*, mEdge*, mEdge*, mEdge*, mEdge*,pGEntity, int*);
mTet* error_createTet_F(mPart*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mHex* error_createHex_F(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mPrism* error_createPrism_F(mPart*, mFace*, mFace*, mFace*, mFace*, mFace*, pGEntity);
mFace* error_createTri_V(mPart*,mVertex*, mVertex*,mVertex*,pGEntity,int*);
mFace* error_createQuad_V(mPart*,mVertex*,mVertex*,mVertex*,mVertex*,pGEntity, int*);
mTet* error_createTet_V(mPart*,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mHex* error_createHex_V(mPart*,mVertex*,mVertex*,mVertex*,mVertex*
                           ,mVertex*,mVertex*,mVertex*,mVertex*, pGEntity);
mPrism* error_createPrism_V(mPart*,mVertex*,mVertex*,mVertex*
			       ,mVertex*,mVertex*,mVertex*,pGEntity);
void error_deleteF(mPart*, mEntity*);
void error_deleteR(mPart*, mEntity*);

#endif

#endif // FLEXDB
