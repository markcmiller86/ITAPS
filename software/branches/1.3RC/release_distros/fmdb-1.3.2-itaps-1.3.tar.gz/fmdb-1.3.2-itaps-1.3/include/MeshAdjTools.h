/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _ADJTOOLS_H_
#define _ADJTOOLS_H_
#include "oldFMDB.h"


#ifdef __cplusplus
extern "C" {
#endif

pRegion R_fcOpRg(pRegion region, pFace face);
pVertex F_edOpVt(pFace face, pEdge edge);
pEdge F_vtOpEd(pFace face,pVertex vert);
pVertex R_fcOpVt(pRegion region, pFace face);
// calculate the normal vector of the mesh face in its natural orientation
void F_normalVector(pFace face, int dir, double* normal);
double E_lengthSq(pEdge edge);
pFace F_exists(eType type, pEntity e1, pEntity e2, pEntity e3, pEntity e4); 
pEdge E_exists(pVertex v1, pVertex v2);

#ifdef __cplusplus
}
#endif

#endif


