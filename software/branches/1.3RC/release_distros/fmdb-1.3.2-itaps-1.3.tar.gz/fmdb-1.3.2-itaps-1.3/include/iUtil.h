/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _H_IUTIL_
#define _H_IUTIL_

#include <map>
#include <list>
#include "mPart.h"
#include "mEntity.h"
#include "mEntitySet.h"
#include "GenIterator.h"
#include "mAttachableDataContainer.h" 

typedef mAttachableDataContainer mEntitySetBase; 
typedef EntitySet<mEntity> mEntitySet; 
typedef EntitySetOrdered<mEntity> mEntitySetOrdered; 
typedef EntitySetUnordered<mEntity> mEntitySetUnordered; 

typedef GenIterator<EntitySetUnordered<mEntity>::iter, mEntity>* pEntSetUIterator; 
typedef GenIterator<EntitySetOrdered<mEntity>::iter, mEntity>* pEntSetOIterator; 
typedef GenIterator<mPartEntityContainer::iter, mEntity>* pMeshIterator; 
typedef GenIterator<EntitySetUnordered<mEntity>::iter, mEntity> mEntSetUIterator;
typedef GenIterator<EntitySetOrdered<mEntity>::iter, mEntity> mEntSetOIterator;
typedef GenIterator<mPartEntityContainer::iter, mEntity> mPartIterator;

typedef EntitySet<mEntity>* pEntitySet;


struct Iterator
{
   short int type;      // type=2, mesh iterator; type=1, entset iterator, type=3, mesh part bdry entity iterator. 
   short int isList;    // type=1&isList=0: pEntSetOIterator;  type=1&isList=1: pEntSetUIterator
   void* iter; 
}; 

typedef Iterator* pIterator; 

class ITAPS_Util {
  private:
    static ITAPS_Util *instance;
    std::map <mPart*, int*> allNTEs;
    ITAPS_Util();
    std::list<pIterator > allIterators;
  public:

    typedef std::list<void*>::iterator topoIter;
    typedef std::list<pIterator>::iterator iterIter;

    static ITAPS_Util* Instance();
    ~ITAPS_Util();
    void computeNTE(mPart*);
    int getNTE(mPart*, int topo);   
    void increaseNTE(mPart*, int topo);
    void decreaseNTE(mPart*, int topo);
    void displayNTE(mPart*);

    void addIterator(pIterator);
    void eraseIterator(pIterator&);
    std::list<pIterator>::iterator iterBegin()
    {  return allIterators.begin(); }
    std::list<pIterator>::iterator iterEnd()
    {  return allIterators.end(); }
};

bool checkTypeTopo(int requested_entity_type, 
                   int requested_entity_topology);

// *************************************************
// iterator related
// *************************************************

void createIterator(mEntitySet*, pIterator& iter, 
                   int type=4, // ALL_TYPES
		   int topo=(int)(mEntity::ALL_TOPOLOGIES), 
		   int ws_size=1);
void createIterator(pMesh, pIterator& iter, 
                   int type=4, // ALL_TYPES
		   int topo=(int)(mEntity::ALL_TOPOLOGIES), 
		   int ws_size=1);

#ifdef FMDB_PARALLEL
void createIterator(pMesh, pIterator& iter, 
		    int* nbor_pid, 
		    int type=4, // ALL_TYPES
		    int topo=(int)(mEntity::ALL_TOPOLOGIES), 
		    int ws_size=1);
#endif 

void deleteIterator(pIterator& iter);

bool iterEnd(Iterator* iter);

pEntity iterData(Iterator* iter);

void iterNext(Iterator* iter);

void iterReset(Iterator* iter);

int wrkSize(Iterator* iter); 

#endif  // _H_IUTIL_
