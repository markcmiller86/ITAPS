/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MENTITY_H_
#define _MENTITY_H_

#include <list>
#include <set>
#include <string>
#include <map>

#include "modeler.h"
#include "mEntityContainer.h"
#include "mAttachableDataContainer.h"
#include "pmEntity.h"
#include <set>

#include <assert.h>
#include <vector>
#include "mPoint.h"

using std::set; 
using std::vector; 

  class mVertex;
  
  class mEntity : public mAttachableDataContainer
    {
#ifdef FMDB_PARALLEL
public:
// bouding partition ids operator
     typedef std::map<int, mEntity*> remoteCopyMap;
     typedef std::map<int, mEntity*> ghostCopyMap;
protected:
     pmEntity* thePClassification;
     remoteCopyMap* theRemoteCopies;

     /// Ghost copy iterator
     ghostCopyMap* theGhostCopies;
     int iIsGhost;
public:

     std::set<int>* tempBPs; 
      /* tempGPs store parts where the entity will be ghosted*/
     std::set<int>* tempGPs;

// bouding partition ids operator
     typedef std::map<int, mEntity*>::iterator RCIter;

     /// Ghost copy container
     typedef std::map<int, mEntity*>::iterator GCIter;

     typedef std::set<int>::iterator GPIter;
     typedef std::set<int>::const_iterator BPIter;


     void addBPs(int i)
     {
       if(tempBPs==NULL)
         tempBPs = new std::set<int>;
       tempBPs->insert(i);
     }
     void deleteBPs(int i)
     {
       if(tempBPs==NULL)
	 return; 
        tempBPs->erase(i);
	if(tempBPs->empty())  
	 SAFE_DELETE(tempBPs);
     }
     void clearBPs()
     {
       if(tempBPs==NULL)
         return;
       if(!tempBPs->empty()) tempBPs->clear();
     }
     int getNumBPs()
     {
       if(tempBPs==NULL)
         return 0;
       return tempBPs->size();
     }
     bool findPidInBPs(int pid)
     {
       if(tempBPs==NULL)
         return false;
       return (std::binary_search(tempBPs->begin(), tempBPs->end(),pid));
     }
     std::set<int>& getBPs() { return *tempBPs; }
     virtual BPIter bpBegin() { return tempBPs->begin(); }
     virtual BPIter bpEnd() { return tempBPs->end(); }

     void  getPidsExist(std::set<int>&);
     void  getPidsExist(std::vector<int>&);
    int getMinPidExist();
     void setPClassificationWithBPs();
     void printBPs();
     
      /* Ghost Part functions : Adds a part id to ghost parts tempGPs*/
    void setGPs(std::set<int>& tmpGPs)
      {
        if(tempGPs==NULL)
         tempGPs = new std::set<int>;

        for(std::set<int>::iterator itSet = tmpGPs.begin(); itSet != tmpGPs.end(); itSet++)
          tempGPs->insert(*itSet);

        //*tempGPs = tmpGPs;
      }

    void addGPs(int i)
     {
       if(tempGPs==NULL)
         tempGPs = new std::set<int>;
       tempGPs->insert(i);
     }

   void deleteGPs(int i)
     {
       if(tempGPs==NULL)
         return;
        tempGPs->erase(i);
        if(tempGPs->empty())
         SAFE_DELETE(tempGPs);
     }
     void clearGPs()
     {
       if(tempGPs==NULL)
         return;
       if(!tempGPs->empty()) tempGPs->clear();
     }
     int getNumGPs()
     {
       if(tempGPs==NULL)
         return 0;
       return tempGPs->size();
     }
     bool findPidInGPs(int pid)
     {
       if(tempGPs==NULL)
         return false;
       return (std::binary_search(tempGPs->begin(), tempGPs->end(),pid));
     }

    std::set<int>& getGPs() { return *tempGPs; }
     virtual GPIter gpBegin() { return tempGPs->begin(); }
     virtual GPIter gpEnd() { return tempGPs->end(); }
     void printGPs(); 
         
// remote copy operator
     mEntity* getRemoteCopy(int);                                // global part id 
     void getRemoteCopies(std::map<int, mEntity*>&);             
     void addRemoteCopy(int, mEntity*);
     void deleteRemoteCopy(int);
     void deleteRemoteCopy(RCIter rciter);
     void clearRemoteCopies();

     int getNumRemoteCopies()
     {
       if(theRemoteCopies==NULL)
         return 0;
       return theRemoteCopies->size();
     }
     virtual RCIter rcBegin() { return theRemoteCopies->begin(); }
     virtual RCIter rcEnd() { return theRemoteCopies->end(); }
     void printRCs();
    
     /*** Returns number of ghost copies, ghost copy iterator ***/
     mEntity* getGhostCopy(int);                                // global part id 
     void getGhostCopies(std::map<int, mEntity*>&);
     void addGhostCopy(int, mEntity*);
     void deleteGhostCopy(int);
     void deleteGhostCopy(GCIter rciter);
     void clearGhostCopies();

     int getNumGhostCopies()
     {
       if(theGhostCopies==NULL)
         return 0;
       return theGhostCopies->size();
     }
     virtual GCIter gcBegin() { return theGhostCopies->begin(); }
     virtual GCIter gcEnd() { return theGhostCopies->end(); }

      /*********************************************************/
     void setIsGhost(int isG)
        {
        iIsGhost = isG;
        }
     void printGCs();
  /************************************************************/

// PClassification operator
    void printPC();
#endif
    public:
     int getIsGhost()
       {
#ifdef FMDB_PARALLEL
        if(iIsGhost != 1)
           return 0;
        return iIsGhost;
#else
        return 0;
#endif
        }

     void setPClassification(pmEntity*);
     pmEntity* getPClassification();
     conType getContainerType() const {return ENTITY; } 

      // functions moved from gEntity
      double gSize();
      
      /// This is an enum of supported entities. This is useful to determine
      /// the exact type of a mesh entity. Mirror entities are used for symmetries
      /// and periodicity.
      typedef enum mType {VERTEX,EDGE,TRI,QUAD,HEX,PRISM,PYRAMID,TET,MIRROR,FACE};
      
      typedef enum mTopology { POINT,
                     LINE_SEGMENT,
                     POLYGON,
                     TRIANGLE, 
                     QUADRILATERAL, 
                     POLYHEDRON,
                     TETRAHEDRON, 
                     HEXAHEDRON, 
                     PRISM_, 
                     PYRAMID_, 
                     SEPTAHEDRON,
		     ALL_TOPOLOGIES,
		     UNDEFINED};
    protected:
      /// Classification of the mesh entity to a model entity (model topological entity)
#ifndef _POINTER2INT_
      pGEntity theClassification; 
#else
public: 
      static pGModel theSolidModel; 
protected: 
      short int gType; 
      short int gTag; 
#endif
      /// Constructor without parameters
      mEntity();

    public:

      /// virtual destructor
      virtual ~mEntity();
      /// returns the iD
      virtual int getId() const = 0; 
      virtual void setId(int id) = 0; 
      /// returns the classification
      pGEntity getClassification() const;
      /// returns the classification

      /** how many sub entities of dimension "what" (for a tet *tet, 
	  tet->getNbTemplates(2) returns 4 because a tet has 4 faces). Note
	  that getNbTemplates returns always something even if the adjacency list
	  is not present.
	  getNbTemplates(what) is only valid if the dimension of the mesh entity is 
	  greater than "what" !*/
      virtual int getNbTemplates (int what) const;
      /** create the ith sub entity of level "what" using "with"
	  getTemplate always returns a new mesh entity, even if it
	  already exists in the mesh. This member is used to create
	  new sets of mesh entities.*/
      virtual mEntity* getTemplate (int ith , int what , int with) const; 
      /** gives the dimension of the entity
	  This valus is 0,1,2 or 3. Note that we do not use enums
	  here because 0,1,2 and 3 have a meaning as integers.
	  I should rename this getDim()*/
      virtual int getLevel() const = 0;
      /** gives the type of the entity (mEntity::VERTEX, mEntity::EDGE,...)
	  This of course is an enum.*/
      virtual mType getType() const = 0;
      mTopology getTopo();
      /// add mEntity *m into adjacency list of the mesh entity
      virtual void add (mEntity* m) = 0; 
      /// adds e if it is not already there
      virtual void appendUnique (mEntity* m) = 0; 
      /// delete mEntity *m from adjacency list of the mesh entity
      virtual void del (mEntity* m) = 0; 
      /// lookup into adjacencies list if entity *m is present
      virtual mEntity *find(mEntity* m)const = 0; 
      /// size(what) gives the same result as getNbTemplates for
      /// downward entities. This really checks the size of adjacency containers.
      virtual int size (int what)const = 0; 
      
      /// Get the ith downward entity of level what
      virtual mEntity* get(int what, int ith)const = 0; 
      /// Copy the downward entities of level what to PList pl
      inline int getAdjList(int adjType, std::vector<mEntity*>& vecAdjEnt) const; 
      inline void getAppendPList(int what, pPList pl) const;
      void getHigherOrderUpward (int dim, std::set<mEntity*> &ents) const;  
      void getHigherOrderUpward (int dim, mAdjacencyContainer &ents) const;

      /// Set classification
      void classify(pGEntity);
      /// delete all adjacency set of dimension what
      virtual void deleteAdjacencies(int what) = 0; 
      /// asks if a given adjacency list has been created
      inline int isAdjacencyCreated(int what) const;

      /// equal operator between 2 entities
      bool equal    (mEntity *) const;
      /// less than operator between 2 entities
      bool lessthan (mEntity *) const;

      /// compute how a mesh entity (this) use another mesh entity e
      int getUse ( mEntity *e ) const;
      /// tree functions
      /// get the leaves of a mesh entity (octree related)
      void getLeaves(std::list<mEntity*> &leaves);
      /// get all the entities under a node of the tree
      void getAllSubTree(std::list<mEntity*> &family);
      /// gat all the family : all nodes, edges, faces of the whole family
      void getAllEntitiesOfAllDimensions(std::set<mEntity*,EntityLessThanKey> &the_whole_family);
      void getAllEntitiesOfAllDimensions(std::set<mEntity*> &the_whole_family);
      void getAllEntitiesOfAllDimensions_oneLevel(std::set<mEntity*> &);
      std::string getUid () const;
      int getOwner();
      /// debug functions 
      virtual void print() const;
      /// debug functions

#ifdef MATCHING
public:
    typedef std::multimap<int, mEntity*> matchEntMap;
    typedef std::multimap<int, mEntity*>::iterator MEIter;

protected:
    matchEntMap* theMatchEnts;
public:
    const std::multimap<int, mEntity*>* getMatchEnts();
    int hasMatchEnt() 
    { 
      if (theMatchEnts==NULL)
	 return 0; 
      if(theMatchEnts->empty()) 
	 return 0; 
      else return 1; 
    }
    int isMatchEnt(int, mEntity*);
    void addMatchEnt(int, mEntity*);
    void deleteMatchEnt(int, mEntity*);
    void deleteAllMatchEnts() {if (theMatchEnts==NULL)  return;  SAFE_DELETE(theMatchEnts); }
    void clearMatchEnts() {if (theMatchEnts==NULL)  return;  theMatchEnts->clear(); }
    int getNumMatchEnts() {  if (theMatchEnts==NULL) return 0;  return theMatchEnts->size(); }

    virtual MEIter meBegin() { return theMatchEnts->begin(); }
    virtual MEIter meEnd() { return theMatchEnts->end(); }
#ifdef DEBUG
    void printMatchEnts(); 
#endif
#endif 

    };

 inline int mEntity::isAdjacencyCreated(int what) const 
 {
     int dim = getLevel();
     if (what==dim+1 || dim==what+1)
      return 1;
     else
      return 0; 
 }

inline int mEntity::getAdjList(int adjType, std::vector<mEntity*>& vecAdjEnt) const
{
   int sz = size(adjType);
   if(!isAdjacencyCreated(adjType)) {
      for(int i=0;i<sz;i++)
      vecAdjEnt.push_back(getTemplate(i,adjType,0));
      return 1; 
   }
   else {
      for(int i=0; i<sz; ++i)
	 vecAdjEnt.push_back(get(adjType, i));
      return 1; 
   }
   return 0; 						
}

  /* assumes that plist is already created */
 inline void mEntity::getAppendPList(int what, pPList pl)const
  {
    int sz = size(what);
    if(!isAdjacencyCreated(what)) {
      for(int i=0;i<sz;i++)
	PList_append(pl, (void*) getTemplate(i,what,0));
    }
    else {
       for(int i=0; i<sz; ++i)	
	PList_append(pl, get(what, i));
    }
  }

#endif 
