/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _MATTACHABLEDATACONTAINER_H_
#define _MATTACHABLEDATACONTAINER_H_

#include "mPoint.h"
#include "mTensor2.h"
#include "mVector.h"
#include <algorithm>
#include <vector>
#include <iosfwd>
#include "oldFMDB.h"
#include "mFMDB.h"
#include <list>

#define SAFE_DELETE(p) {delete (p); (p)=NULL; }

  class mPart;

  /**
     Base class for attachable data's
  */
  class mAttachableData
  {
  public :
    virtual ~mAttachableData(){};
  public:
    enum DATA_TYPE {
      INTVECTOR,
      POINTVECTOR, 
      DBLVECTOR,
      ENTVECTOR,
      OPAQUE,
      INT ,
      DOUBLE ,
      POINT ,
      MVECTOR ,
      MTENSOR2 ,
      POINTER  
    };
    DATA_TYPE type;          
      virtual DATA_TYPE getType() = 0; 
  };

  /**
     Vector of ints as attachable data
  */
  class mAttachableIntVector : public mAttachableData
  {
  public :
    virtual ~mAttachableIntVector(){}
    std::vector<int> v;
    DATA_TYPE getType() {return INTVECTOR; }
  };

 /**
     Vector of ints as attachable data
  */
  class mAttachableDblVector : public mAttachableData
  {
  public :
    virtual ~mAttachableDblVector(){}
    std::vector<double> v;
     DATA_TYPE getType() {return DBLVECTOR; }
  };
  
  class mAttachablePntVector : public mAttachableData
  {
  public :
    virtual ~mAttachablePntVector(){}
    std::vector<void*> v;
    DATA_TYPE getType() {return ENTVECTOR; }
  };
  /**
     Vector of ints as attachable data
  */
  class mAttachablePointVector : public mAttachableData
  {
  public :
    virtual ~mAttachablePointVector(){}
    std::vector<SCOREC::Util::mPoint> v;
    DATA_TYPE getType() {return POINTVECTOR; }
  };


  /**
     Int as attachable data
  */
  class mAttachableInt : public mAttachableData
  {
  public :
    virtual ~mAttachableInt(){}
    int i;
    DATA_TYPE getType() {return INT; }
  };

  /**
     Double as attachable data
  */
  class mAttachableDouble : public mAttachableData
  {
  public :
    virtual ~mAttachableDouble(){}
    double d;
    DATA_TYPE getType() {return DOUBLE; }
  };

  /**
     Point as attachable data
  */
  class mAttachablePoint : public mAttachableData
  {
  public :
    SCOREC::Util::mPoint p;
    DATA_TYPE getType() {return POINT; }
  };

  /**
     Point as attachable data
  */
  class mAttachable_mVector : public mAttachableData
  {
  public :
    SCOREC::Util::mVector v;
    DATA_TYPE getType() {return MVECTOR; }
  };
  
  /**
     Point as attachable data
  */
  class mAttachable_mTensor2 : public mAttachableData
    {
  public :
    SCOREC::Util::mTensor2 t;
    DATA_TYPE getType() {return MTENSOR2; }
  };

  /**
     Mesh as attachable data
  */
  class mAttachableMesh : public mAttachableData
  {
  public :
    mPart *m;
    DATA_TYPE getType() {return POINTER; }
  };

  /**
     mesh entity as attachable data
  */
  class mAttachablePnt : public mAttachableData
  {
  public :
    void* e;
    DATA_TYPE getType() {return POINTER; }
  };

/*attachable data's*/
class mAttachableVoid : public mAttachableData
{
  public :
    ~mAttachableVoid ()
    {
      //      printf("possible memory leak in a data attachement \n");
      //      delete veryNastyPointer;
    }
    void *veryNastyPointer;
    DATA_TYPE getType() {return POINTER; }
};


  class mAttachableOpaque : public mAttachableData
  {
  public :
    char *o;
    int size;
    DATA_TYPE getType() {return OPAQUE; } 
  };

  /**
     Container for attachable data's Internal, mEntity, mEntitySet and mPart provide interfaces.
  */

  class mAttachableDataContainer  
  {
  public :
    typedef std::pair <unsigned int, mAttachableData *> info;
    //      typedef std::map< unsigned int, mAttachableData *> container;
    typedef std::vector< info > container;
    typedef container::iterator iter_attachdata;
    typedef container::const_iterator citer_attachdata;
  private :
    container* tab;
  public:
    mAttachableDataContainer(){tab = NULL; }
    ~mAttachableDataContainer();
    inline void attachData(unsigned int, mAttachableData *);
    inline void deleteData(unsigned int);
    inline bool hasData(unsigned int);
    inline mAttachableData * getData(unsigned int) ;
    inline citer_attachdata begin_attachdata() const {return tab->begin();};
    inline citer_attachdata end_attachdata() const {return tab->end();};

     /// specific data types for handles 
    inline void attachPnt(unsigned int,void*);
    inline void* getAttachedPnt(unsigned int);

    /// specific data types for int
    inline void attachInt(unsigned int, int);
    inline int getAttachedInt(unsigned int);
    inline int getAttachedInt(unsigned int, int*); // return 0 if no int attached
    
    /// specific data types for double
    inline void attachDouble(unsigned int, double);
    inline double getAttachedDouble(unsigned int);
    inline int getAttachedDouble(unsigned int, double*);

      /// specific data types for point (high-order node)
    inline void attachPoint(unsigned int, SCOREC::Util::mPoint);
    inline int getAttachedPoint(unsigned int, SCOREC::Util::mPoint*);  

    /// specific data types for vector
    inline void attachVector(unsigned int, const SCOREC::Util::mVector &t);
    inline SCOREC::Util::mVector getAttachedVector(unsigned int);

    /// specific data types for tensor
    inline void attachTensor(unsigned int, const SCOREC::Util::mTensor2 &t);
    inline SCOREC::Util::mTensor2 getAttachedTensor(unsigned int);

    typedef enum conType {ENTITY, ENTITYGROUP, PART, MESH, ENTITYSET, UNDEFINED};
    virtual conType getContainerType() const = 0; 

  inline bool isRootSet() const; 

  void attachOpaque(unsigned int c, const void*o, int size);
  int getSizeAttachedOpaque(unsigned int c);
  int getAttachedOpaque(unsigned int c, void* d);

  void getAllTagID(std::vector<pMeshDataId>&);

  void attachIntArr(unsigned int, int*, int);
  int getAttachedIntArr(unsigned int, int**, int*);
  void attachDblArr(unsigned int, double*, int);
  int getAttachedDblArr(unsigned int, double**, int*);
  void attachPntArr(unsigned int, void**, int);
  int getAttachedPntArr(unsigned int, void***, int*);
};

inline bool mAttachableDataContainer::isRootSet() const
{
   if (getContainerType()==MESH)
      return true;
   else
      return false;
}

  class equalInfoPred
    {
      const unsigned int c;
    public:
      equalInfoPred ( unsigned int i ) :c(i) {}
      inline bool operator () (const mAttachableDataContainer::info &i) const
	{
	  return (i.first == c);
	}
    };

  inline mAttachableDataContainer::~mAttachableDataContainer()
  {
    if (tab==NULL)
       return; 
    if(tab->empty()) {SAFE_DELETE(tab); return; } 
    citer_attachdata it = begin_attachdata();
    citer_attachdata itEnd = end_attachdata();
    for(;it!=itEnd;++it)
    {
       if (FMDB_Util::Instance()->typeMeshDataId((*it).first)==0) // byte
       {
	 mAttachableOpaque *a = (mAttachableOpaque *)((*it).second);
	 if(a)
	 {
	    delete [] a->o;
	    delete a;
	 }
      }
      else
      {
        mAttachableData *a = (*it).second;
        if (a) delete a;
      }
   }
    SAFE_DELETE(tab);
  }

  inline bool mAttachableDataContainer::hasData (unsigned int c)
  {
    if (tab==NULL) return false;
    iter_attachdata it = std::find_if (tab->begin(),tab->end(),equalInfoPred(c));
    if(it == tab->end())return false; 
    return true;
  }

  inline mAttachableData *mAttachableDataContainer::getData(unsigned int c) 
  {
       if(tab==NULL)
	 return 0;
       iter_attachdata it = std::find_if (tab->begin(),tab->end(),equalInfoPred(c));
       if(it == tab->end())return 0;
       return (*it).second;
  }
  
  inline void mAttachableDataContainer::attachData(unsigned int c, mAttachableData *v)
    {
     if (tab==NULL) 
       tab = new container; 
     tab->push_back(info(c,v));
    }
  
  inline void mAttachableDataContainer::deleteData(unsigned int c)
  {

    if (tab==NULL)
       return; 
    if (FMDB_Util::Instance()->typeMeshDataId(c)==0)  // byte type
    {
      mAttachableOpaque *data = (mAttachableOpaque *)getData(c);
      if(data)
      {
	 delete [] data->o;
	 delete data;
      }
    }
    else
    {
      mAttachableData *data = getData (c);
      if (data) delete data;
    }

    tab->erase ( std::remove_if (tab->begin(),tab->end(),equalInfoPred(c)) ,
                    tab->end () );
    if(tab->empty()) 
      SAFE_DELETE(tab); 
		    
  }
  
  inline void mAttachableDataContainer::attachInt(unsigned int c, int i)
  {
    mAttachableInt *ai = (mAttachableInt *)getData(c);
    if(!ai)
      {
	ai = new mAttachableInt;
	attachData(c,ai);
      }
    ai->i = i;
  }

  inline int mAttachableDataContainer::getAttachedInt (unsigned int c)
  {
    mAttachableInt *ai = (mAttachableInt *)getData(c);
    if(!ai)return 0;
    return ai->i;
  }

  inline void mAttachableDataContainer::attachDouble(unsigned int c, double d)
  {
    mAttachableDouble *ai = (mAttachableDouble *)getData(c);
    if(!ai)
      {
	ai = new mAttachableDouble;
	attachData(c,ai);
      }
    ai->d = d;
  }

  inline double mAttachableDataContainer::getAttachedDouble (unsigned int c)
  {
    mAttachableDouble *ai = (mAttachableDouble *)getData(c);
    if(!ai)return 0;
    return ai->d;
  }

  inline void mAttachableDataContainer::attachPoint(unsigned int c, SCOREC::Util::mPoint p)
  {
    mAttachablePoint *ai = (mAttachablePoint *)getData(c);
    if(!ai)
      {
        ai = new mAttachablePoint;
        attachData(c,ai);
      }
    ai->p = p;
  }

  inline void mAttachableDataContainer::attachPnt(unsigned int c, void* e)
  {
    mAttachablePnt *ai = (mAttachablePnt*)getData(c);
    if(!ai)
      {
	ai = new mAttachablePnt;
	attachData(c,ai);
      }
    ai->e = e;
  }

  inline void* mAttachableDataContainer::getAttachedPnt (unsigned int c)
  {
    mAttachablePnt *ai = (mAttachablePnt *)getData(c);
    if(!ai) return 0;
    return ai->e;
  }

  inline void mAttachableDataContainer::attachVector(unsigned int c, const SCOREC::Util::mVector &d)
  {
    mAttachable_mVector *ai = (mAttachable_mVector *)getData(c);
    if(!ai)
      {
	ai = new mAttachable_mVector;
	attachData(c,ai);
      }
    ai->v = d;
  }

  inline SCOREC::Util::mVector mAttachableDataContainer::getAttachedVector (unsigned int c)
  {
    mAttachable_mVector *ai = (mAttachable_mVector *)getData(c);
    if(!ai){
      throw 1;
      return SCOREC::Util::mVector();//was return 0; but 
    }
    return ai->v;
  }

  inline void mAttachableDataContainer::attachTensor(unsigned int c, const SCOREC::Util::mTensor2 &d)
  {
    mAttachable_mTensor2 *ai = (mAttachable_mTensor2 *)getData(c);
    if(!ai)
      {
	ai = new mAttachable_mTensor2;
	attachData(c,ai);
      }
    ai->t = d;
  }

  inline SCOREC::Util::mTensor2 mAttachableDataContainer::getAttachedTensor (unsigned int c)
  {
    mAttachable_mTensor2 *ai = (mAttachable_mTensor2 *)getData(c);
    if(!ai) {
	throw 1;
	return SCOREC::Util::mTensor2();
    }
    return ai->t;
  }

// added by E. Seol
// it returns 1 if succeed, 0 otherwise
  inline int mAttachableDataContainer::getAttachedInt (unsigned int c, int* i)
  {
    mAttachableInt *ai = (mAttachableInt *)getData(c);
    if(!ai)return 0;
    *i = ai->i;
    return 1;
  }

// added by E. Seol
// it returns 1 if succeed, 0 otherwise
  inline int mAttachableDataContainer::getAttachedDouble (unsigned int c,
  double* d)
  {
    mAttachableDouble *ai = (mAttachableDouble *)getData(c);
    if(!ai)return 0;
    *d = ai->d;
    return 1;
  }

// it returns 1 if succeed, 0 otherwise
  inline int mAttachableDataContainer::getAttachedPoint (unsigned int c,
  SCOREC::Util::mPoint* p)
  {
    mAttachablePoint *ai = (mAttachablePoint *)getData(c);
    if(!ai)return 0;
    *p = ai->p;
    return 1;
  }
#endif
