/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_pushTags(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iBase_TagHandle source_tag, 
            iBase_TagHandle dest_tag, 
            int entity_type, 
            int entity_topo, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_pushTagsEnt(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iBase_TagHandle source_tag, 
            iBase_TagHandle dest_tag, 
            const iBase_EntityHandle *entities,
            int entities_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_iPushTags(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iBase_TagHandle source_tag, 
            iBase_TagHandle dest_tag, 
            int entity_type, 
            int entity_topo, 
            iMeshP_RequestHandle *request,
             int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_iPushTagsEnt(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iBase_TagHandle source_tag, 
            iBase_TagHandle dest_tag, 
            const iBase_EntityHandle *entities,
            int entities_size,
            iMeshP_RequestHandle *request,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

