/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_waitForRequest(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle request,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_waitForAnyRequest(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle *requests,
            int requests_size,
            int *index,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_waitForAllRequests(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle *requests,
            int requests_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_waitForRequestEnt(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle request,
            iBase_EntityHandle **out_entities,
            int *out_entities_allocated,
            int *out_entities_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_testRequest(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle request,
            int *completed,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_pollForRequests(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            iMeshP_RequestHandle **requests_completed,
            int *requests_completed_allocated,
            int *requests_completed_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}
