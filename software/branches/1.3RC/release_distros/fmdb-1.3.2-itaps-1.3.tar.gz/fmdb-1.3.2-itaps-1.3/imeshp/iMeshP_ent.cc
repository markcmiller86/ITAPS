/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_getEntOwnerPart(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity_handle,
            iMeshP_Part *part_id,
            int *err)
{
  *err = iBase_SUCCESS; 
  FMDB_Ent_GetOwnPartID((pMeshEnt)entity_handle, (int*)part_id);
  return;
}

void iMeshP_getEntOwnerPartArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle *entity_handles,
            const int entity_handles_size,
            iMeshP_Part **part_ids,
            int *part_ids_allocated,
            int *part_ids_size,
            int *err)
{
  *err = iBase_SUCCESS; 
    
  if( *part_ids==0 || *part_ids_allocated==0 ) 
  { 
    
    *part_ids = (iMeshP_Part*)(calloc(entity_handles_size, sizeof(iMeshP_Part)));
    if( *part_ids==0 ) 
    {
      *err = iBase_MEMORY_ALLOCATION_FAILED; 
      return;
    }
  }
  else if( *part_ids_allocated< entity_handles_size ) { 
    *err = iBase_BAD_ARRAY_SIZE;
    return; 
  }    

  int pid; 
  for(int i=0; i<entity_handles_size; i++) 
  {
    FMDB_Ent_GetOwnPartID((pMeshEnt)(entity_handles[i]), &pid);
    (*part_ids)[i]=pid;       
  }
    
  *part_ids_allocated = entity_handles_size; 
  return;
}


void iMeshP_isEntOwner(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iMeshP_PartHandle part, 
            const iBase_EntityHandle entity, 
            int *is_owner, 
            int *err)
{
  *err = iBase_SUCCESS; 
  
  int myrank;
  FMDB_GetProcID(&myrank);
  int owner_pid;
  FMDB_Ent_GetOwnPartID ((pMeshEnt)entity, &owner_pid);

  if (owner_pid==myrank) {
    *is_owner = 1; 
  }
  else 
    *is_owner=0; 

  return;
}

void iMeshP_isEntOwnerArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iMeshP_PartHandle part, 
            const iBase_EntityHandle *entities, 
            const int entities_size, 
            int **is_owner, 
            int *is_owner_allocated, 
            int *is_owner_size, 
            int *err)
{
  *err = iBase_SUCCESS; 

  if( *is_owner==0 || *is_owner_allocated==0 ) {
    *is_owner = (int*)(calloc(entities_size, sizeof(int)));
    if(*is_owner==0) {
      *err =  iBase_MEMORY_ALLOCATION_FAILED;
      return; 
    }
  }
  else if( *is_owner_allocated<entities_size ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return; 
  }

  int myrank, owner_pid;
  FMDB_GetProcID(&myrank);

  for(int i=0; i<entities_size; i++) {      
    FMDB_Ent_GetOwnPartID ((pMeshEnt)(entities[i]), &owner_pid);
    if ( myrank==owner_pid ) 
      (*is_owner)[i]=1; 
    else 
      (*is_owner)[i]=0; 
  }
    
  *is_owner_allocated = entities_size; 
  return;
}

void iMeshP_getEntStatus(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iMeshP_PartHandle part, 
            const iBase_EntityHandle entity, 
            int *par_status,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getEntStatusArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iMeshP_PartHandle part, 
            const iBase_EntityHandle *entities, 
            const int entities_size, 
            int **par_status, /* enum iMeshP_EntStatus */
            int *par_status_allocated, 
            int *par_status_size, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED;
  return;
}


void iMeshP_getNumCopies(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity, 
            int *num_copies_ent,
            int *err)
{
  *err = iBase_SUCCESS;  
  FMDB_Ent_GetNumRmt ((pMeshEnt)entity, num_copies_ent); 
  return;
}

void iMeshP_getCopyParts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity, 
            iMeshP_Part **part_ids, 
            int *part_ids_allocated, 
            int *part_ids_size, 
            int *err)
{
 *err = iBase_SUCCESS;   
  
  int num_remote=0;
  FMDB_Ent_GetNumRmt ((pMeshEnt) entity, &num_remote);
  
  // allocate mem for part_ids
  if( *part_ids==0 || *part_ids_allocated==0) {
    *part_ids =(iMeshP_Part*)calloc(num_remote, sizeof(iMeshP_Part)); 
    if (*part_ids==0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return; 
    }
    *part_ids_allocated=num_remote; 
  }
  else if (*part_ids_allocated < num_remote) {
    *err = iBase_BAD_ARRAY_SIZE;
    return; 
  } 

  int icount=0;  
  std::vector<std::pair<int, pMeshEnt> > vecRmtCopy;
  FMDB_Ent_GetRmt ((pMeshEnt)entity, vecRmtCopy);
  for (std::vector<std::pair<int, pMeshEnt> >::iterator it=vecRmtCopy.begin(); 
       it != vecRmtCopy.end(); ++it)
  {
    (*part_ids)[icount] = it->first; 
    icount++; 
  }

  *part_ids_size=num_remote;                         
  return;
}

void iMeshP_getCopies(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity, 
            iMeshP_Part **part_ids, 
            int *part_ids_allocated, 
            int *part_ids_size, 
            iBase_EntityHandle **copies, 
            int *copies_allocated, 
            int *copies_size,
            int *err)
{
  *err = iBase_SUCCESS;   
  
  int num_remote=0;
  FMDB_Ent_GetNumRmt ((pMeshEnt) entity, &num_remote);
  
  // allocate mem for part_ids
  int part_ids_alloc_flag = (*part_ids==0);
  if( *part_ids==0 || *part_ids_allocated==0) {
    *part_ids =(iMeshP_Part*)calloc(num_remote, sizeof(iMeshP_Part)); 
    if (*part_ids==0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return; 
    }
    *part_ids_allocated=num_remote; 
  }
  else if (*part_ids_allocated < num_remote) {
    *err = iBase_BAD_ARRAY_SIZE;
    return; 
  } 

  if (*copies==0 || *copies_allocated==0 ) {
    *copies=(iBase_EntityHandle*)calloc(num_remote, sizeof(iBase_EntityHandle)); 
    if(*copies==0 ) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      // if memory failed for part_ids, clean-up entities before return
      if (part_ids_alloc_flag) {
        free(*part_ids);
        *part_ids=NULL;
        *part_ids_allocated = 0;
      }
      return; 
    }
    *copies_allocated=num_remote; 
  }
  else if (*copies_allocated < num_remote) {
    *err = iBase_BAD_ARRAY_SIZE;
    // if memory failed for copies, clean-up entities before return
    if (part_ids_alloc_flag) // free memory allocted to adj_entity_handles;
    {
      free(*part_ids);
      *part_ids=NULL;
      *part_ids_allocated = 0;
    }
    return;
  }

  int icount=0;  
  std::vector<std::pair<int, pMeshEnt> > vecRmtCopy;
  FMDB_Ent_GetRmt ((pMeshEnt)entity, vecRmtCopy);
  for (std::vector<std::pair<int, pMeshEnt> >::iterator it=vecRmtCopy.begin(); 
       it != vecRmtCopy.end(); ++it)
  {
    (*part_ids)[icount] = it->first; 
    (*copies)[icount]= (iBase_EntityHandle)(it->second);   
    icount++; 
  }

  *part_ids_size=num_remote;                         
  *copies_size=num_remote; 
  return;
}


void iMeshP_getCopyOnPart(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity, 
            const iMeshP_Part part_id, 
            iBase_EntityHandle *copy_entity, 
            int *err)
{
  *err = iBase_SUCCESS;  
  pMeshEnt ent = (pMeshEnt)entity;
  pMeshEnt rmtCopy;
  if (FMDB_Ent_GetRmtOnPart (ent, part_id, rmtCopy))
  {
    *err = iBase_FAILURE;
    return;
  }

  *copy_entity = (iBase_EntityHandle)rmtCopy;
  return;
}



void iMeshP_getOwnerCopy(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition, 
            const iBase_EntityHandle entity, 
            iMeshP_Part *owner_part_id, 
            iBase_EntityHandle *owner_entity, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED;   
  return;
}

