/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_getNumPartNbors(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            int entity_type,
            int *num_part_nbors,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getNumPartNborsArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle *parts,
            int parts_size,
            int entity_type,
            int **num_part_nbors,
            int *num_part_nbors_allocated,
            int *num_part_nbors_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getPartNbors(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            int entity_type,
            int *num_part_nbors,
            iMeshP_Part **nbor_part_ids,
            int *nbor_part_ids_allocated,
            int *nbor_part_ids_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getPartNborsArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle *parts,
            const int parts_size,
            int entity_type,
            int **num_part_nbors,
            int *num_part_nbors_allocated,
            int *num_part_nbors_size,
            iMeshP_Part **nbor_part_ids,
            int *nbor_part_ids_allocated,
            int *nbor_part_ids_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
} 

void iMeshP_getNumPartBdryEnts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part, 
            int entity_type, 
            int entity_topology, 
            iMeshP_Part target_part_id, 
            int *num_entities, 
            int *err)
{
  *err = iBase_SUCCESS; 
  FMDB_Part_GetNumPartBdry ((pPart)part, target_part_id, entity_type, 
                             entity_topology, num_entities);
  return;
}

void iMeshP_getPartBdryEnts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part, 
            int entity_type, 
            int entity_topology, 
            iMeshP_Part target_part_id, 
            iBase_EntityHandle **entities,
            int *entities_allocated,
            int *entities_size, 
            int *err)
{
  *err = iBase_SUCCESS; 

  return;
}

void iMeshP_initPartBdryEntIter(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part, 
            int entity_type, 
            int entity_topology, 
            iMeshP_Part target_part_id, 
            iBase_EntityIterator* entity_iterator, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_initPartBdryEntArrIter(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part, 
            int entity_type, 
            int entity_topology, 
            int array_size, 
            iMeshP_Part target_part_id, 
            iBase_EntityArrIterator* entity_iterator, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


