/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"
#include "mpi.h"

void iMeshP_createPartitionAll(
            iMesh_Instance instance,
            MPI_Comm communicator,
            iMeshP_PartitionHandle *partition,
            int *err)
{
  *err = iBase_SUCCESS; 
  FMDB_Init(MPI_COMM_WORLD);
  *partition = (iMeshP_PartitionHandle)instance;
  return;
}


void iMeshP_destroyPartitionAll(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            int *err)
{
  *err = iBase_SUCCESS;
  ParUtil::Instance()->Finalize(0); // this doesn't call MPI_Finalize
  return;
}

void iMeshP_loadAll(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iBase_EntitySetHandle entity_set,
            const char *name, 
            const char *options,
            int *err, 
            int name_len, 
            int options_len)
{
  *err = iBase_SUCCESS; 
  
  // load a partitioned mesh by default
  int distributed=0;
  // FMDB takes digits for options. 
  // If zero is given, a serial mesh is loaded and partitioned
  // if non-zero is given, a distributed mesh is loaded from multiple files
  if (options_len>0)
    distributed = 1;

  FMDB_Mesh_LoadFromFile ((pMeshMdl)instance, name, distributed); 
  
  // TO BE REMOVED
  int procID;
  FMDB_GetProcID (&procID);
  vector<pPart> parts;
  FMDB_Mesh_GetProcPart((pMeshMdl)instance, procID, parts);
  for (vector<pPart>::iterator pit=parts.begin(); pit!=parts.end(); ++pit)
    ITAPS_Util::Instance()->computeNTE(*pit);
  // END OF TO BE REMOVED

  // initialize adj table
  for (int i=0; i<4; ++i)
    for (int j=0; j<4; ++j)
      if (i==j) // diagonal
        ((pMeshMdl)instance)->MRM[i][j] = iBase_AVAILABLE;
      else // non-diagonal
        ((pMeshMdl)instance)->MRM[i][j] = iBase_ALL_ORDER_1;

  int mesh_dim;
  FMDB_Mesh_GetDim ((pMeshMdl)instance, &mesh_dim);
  if (mesh_dim!=3)
  {
    ((pMeshMdl)instance)->MRM[3][3] = iBase_UNAVAILABLE; 
    for (int i=0; i<3; ++i)
      ((pMeshMdl)instance)->MRM[3][i] = ((pMeshMdl)instance)->MRM[i][3] = iBase_UNAVAILABLE; 
  }
}

void iMeshP_saveAll(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iBase_EntitySetHandle entity_set,
            const char *name, 
            const char *options,
            int *err, 
            const int name_len, 
            int options_len)
{
  *err = iBase_SUCCESS;  
  FMDB_Mesh_WriteToFile((pMeshMdl)instance, name, 1);
  return;
}


void iMeshP_getPartitionComm(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            MPI_Comm *communicator,
            int *err)
{
  *err = iBase_SUCCESS; 
  FMDB_GetComm (communicator);
  return;
}


void iMeshP_syncPartitionAll(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getNumPartitions(
            iMesh_Instance instance,
            int *num_partitions,
            int *err)
{
  *err = iBase_SUCCESS; 
  *num_partitions=1;
  return;
}



void iMeshP_getPartitions(
            iMesh_Instance instance,
            iMeshP_PartitionHandle **partitions,
            int *partitions_allocated, 
            int *partitions_size, 
            int *err)
{
  *err = iBase_SUCCESS; 
  int size=1;
  if ( *partitions==0 || *partitions_allocated==0 ) {
    *partitions = (iMeshP_PartitionHandle*)( calloc(size, sizeof(iMeshP_PartitionHandle)) );
    if(*partitions==0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }

    *partitions_allocated = size;
  }
  else if( *partitions_allocated < size) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  (*partitions)[0]= (iMeshP_PartitionHandle)instance;
  *partitions_size=size;
 
  return;
}


void iMeshP_getNumOfTypeAll(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iBase_EntitySetHandle entity_set,
            int entity_type, 
            int *num_type, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getNumOfTopoAll(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iBase_EntitySetHandle entity_set,
            int entity_topology, 
            int *num_topo, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


