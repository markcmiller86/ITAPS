/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_getNumGlobalParts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            int *num_global_part, 
            int *err)
{
  *err = iBase_SUCCESS; 
  int localNumPart=0, procId=0;
  FMDB_GetProcID (&procId);
  FMDB_Mesh_GetNumPart((pMeshMdl)instance, procId, &localNumPart);
  MPI_Allreduce(&localNumPart,num_global_part,1,MPI_INT,MPI_SUM, MPI_COMM_WORLD); 
  return;
}

void iMeshP_getNumLocalParts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            int *num_local_part, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  int procId=0;
  FMDB_GetProcID (&procId);
  FMDB_Mesh_GetNumPart((pMeshMdl)instance, procId, num_local_part);
  return;
}


void iMeshP_getLocalParts(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_PartHandle **parts,
            int *parts_allocated,
            int *parts_size,
            int *err)
{
  *err = iBase_SUCCESS; 
  int procId=0;
  FMDB_GetProcID (&procId);
  std::vector<pPart> part_vec;
  FMDB_Mesh_GetProcPart((pMeshMdl)instance, procId, part_vec);
  int numParts = part_vec.size();
  if( *parts ==0 || *parts_allocated==0 ) {
    *parts = (iMeshP_PartHandle*)(calloc(numParts, sizeof(iMeshP_PartHandle) )); 
    if (*parts==0 ) { 
       *err = iBase_MEMORY_ALLOCATION_FAILED; 
       return;
    }
     
    *parts_allocated = numParts; 
  }
  else if ( *parts_allocated < numParts) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
   
  int count = 0; 
  for(vector<pPart>::iterator pit=part_vec.begin(); pit!=part_vec.end(); ++pit)
  { 
    *(*parts + count*sizeof(iMeshP_PartHandle)) = (iMeshP_PartHandle)(*pit); 
    count++; 
  }
   
  *parts_size = numParts; 
  return;
}

void iMeshP_getRankOfPart(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_Part part_id,
            int *rank,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getRankOfPartArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_Part *part_ids,
            const int part_ids_size,
            int **ranks, 
            int *ranks_allocated, 
            int *ranks_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_createPart(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            iMeshP_PartHandle *part,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_destroyPart(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            iMeshP_PartHandle part,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getPartIdFromPartHandle(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            iMeshP_Part *part_id,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getPartIdsFromPartHandlesArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle *parts,
            const int parts_size,
            iMeshP_Part **part_ids,
            int *part_ids_allocated,
            int *part_ids_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getPartHandleFromPartId(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            iMeshP_Part part_id,
            iMeshP_PartHandle *part,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getPartHandlesFromPartsIdsArr(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_Part *part_ids,
            const int part_ids_size,
            iMeshP_PartHandle **parts,
            int *parts_allocated,
            int *parts_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getNumOfType(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            const iBase_EntitySetHandle entity_set,
            int entity_type, 
            int *num_type, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_getNumOfTopo(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            const iBase_EntitySetHandle entity_set,
            int entity_topology, 
            int *num_topo, 
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getAdjEntIndices(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            iMeshP_PartHandle part,
            iBase_EntitySetHandle entity_set_handle,
            int entity_type_requester,
            int entity_topology_requester,
            int entity_type_requested,
            iBase_EntityHandle** entity_handles,
            int* entity_handles_allocated,
            int* entity_handles_size,
            iBase_EntityHandle** adj_entity_handles,
            int* adj_entity_handles_allocated,
            int* adj_entity_handles_size,
            int** adj_entity_indices,
            int* adj_entity_indices_allocated,
            int* adj_entity_indices_size,
            int** offset,
            int* offset_allocated,
            int* offset_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_getEntities(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            const iBase_EntitySetHandle entity_set,
            int entity_type,
            int entity_topology,
            iBase_EntityHandle **entities,
            int *entities_allocated,
            int *entities_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_initEntIter(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            const iBase_EntitySetHandle entity_set,
            const int requested_entity_type,
            const int requested_entity_topology,
            iBase_EntityIterator* entity_iterator,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_initEntArrIter(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iMeshP_PartHandle part,
            const iBase_EntitySetHandle entity_set,
            const int requested_entity_type,
            const int requested_entity_topology,
            const int requested_array_size,
            iBase_EntityArrIterator* entArr_iterator,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}
