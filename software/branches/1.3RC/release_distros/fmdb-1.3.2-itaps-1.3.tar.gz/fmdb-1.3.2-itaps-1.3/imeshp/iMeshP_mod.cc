/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_exchEntArrToPartsAll(
            iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            const iBase_EntityHandle *entities,
            const int entities_size,
            const iMeshP_Part *target_part_ids,
            int command_code,  
            int update_ghost,
            iMeshP_RequestHandle *request,
            int *err)
{
  *err = iBase_SUCCESS;  
    
  MigrCB cb;
  std::map<mEntity*, int> POtoMove[1];
  
  for(int i=0; i<entities_size; i++) 
  {
    if( ((int*)target_part_ids)[i]==ParUtil::Instance()->rank() )
      continue; 
    POtoMove[0][((mEntity**)entities)[i] ]= ((int*)target_part_ids)[i]; 
  }
  FMDB_Mesh_Migr((pMeshMdl)instance, cb, POtoMove);
  return;
}

void iMeshP_migrateEntity(
            iMesh_Instance instance, 
            const iMeshP_PartitionHandle partition,
            iMeshP_PartHandle part,
            iBase_EntityHandle local_entity,
            iMeshP_RequestHandle *request,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_updateVtxCoords(
            iMesh_Instance instance, 
            const iMeshP_PartitionHandle partition,
            const iBase_EntityHandle local_vertex,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_replaceOnPartBdry(
            iMesh_Instance instance, 
            const iMeshP_PartitionHandle partition,
            const iBase_EntityHandle *old_entities,
            const int old_entities_size,
            const iBase_EntityHandle *new_entities,
            const int new_entities_size,
            const int *offset,
            const int offset_size,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}
 
void iMeshP_syncMeshAll(
            iMesh_Instance instance, 
            iMeshP_PartitionHandle partition,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}
                            














