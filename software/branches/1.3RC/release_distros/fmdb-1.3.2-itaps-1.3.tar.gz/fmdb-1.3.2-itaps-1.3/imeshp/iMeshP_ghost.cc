/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iMeshP.h"
#include "FMDB.h"

void iMeshP_addGhostOf(
            iMesh_Instance instance, 
            const iMeshP_PartitionHandle partition,
            const iMeshP_Part target_part_id,
            iBase_EntityHandle entity_to_copy,
            iMeshP_RequestHandle *request,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}

void iMeshP_rmvGhostOf(
            iMesh_Instance instance, 
            const iMeshP_PartitionHandle partition,
            const iMeshP_Part target_part_id,
            iBase_EntityHandle copy_to_purge,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}


void iMeshP_createGhostEntsAll(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            int ghost_type,
            int bridge_type,
            int num_layers,
            int include_copies,
            int *err)
{
  *err = iBase_SUCCESS; 
  MigrCB cb;
  if (FMDB_Mesh_CreateGhost ((pMeshMdl)instance, cb, ghost_type, bridge_type, 
                         num_layers, include_copies)) 
    *err = iBase_FAILURE;
  return;
}

void iMeshP_deleteGhostEntsAll(
            iMesh_Instance instance,
            iMeshP_PartitionHandle partition,
            int *err)
{
  *err = iBase_SUCCESS;
  if (FMDB_Mesh_DelGhost ((pMeshMdl)instance))
    *err = iBase_FAILURE;
  return;
}

void iMeshP_ghostEntInfo(
            const iMesh_Instance instance,
            const iMeshP_PartitionHandle partition,
            int *ghost_rules_allocated, 
            int *ghost_rules_size, 
            int **ghost_type,
            int **bridge_type,
            int **num_layers,
            int *err)
{
  *err = iBase_NOT_SUPPORTED; 
  return;
}
