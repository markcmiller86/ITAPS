/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef SIM
#include <iostream>
#include <string.h>
#include <stdio.h>
#include <assert.h>
#include <list>

#include "oldFMDB.h"
#include "FMDBInternals.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mRegion.h"
#include "mPoint.h"
#include "mException.h"
#include "mAttachableDataContainer.h"
#include "mFMDB.h"
#include "mPart.h"
#include "LagrangeMapping.h"
#include "mIterator.h"
#include "ParUtil.h"
#include "PList.h"
#include "mBuildAdj.h"
#include "modeler.h"
#include "iUtil.h"

#include "FMDB_cint.h"
#include "mFlexDB.h"
#include "FMDB_Iterator.h"

#include "GenIterator.h"

typedef GenIterator<mPartEntityContainer::iter, mEntity> mPartIterator;

#ifdef FMDB_PARALLEL
#include "pmZoltanCallbacks.h"
#include "FMDB_ZoltanLoadBalancer.h"
#include "pmModel.h"
#endif


pMesh MS_newMesh(pGModel pm)
{
  mPart *m = new mPart(1,pm);
  return m;
} 


pGModel M_model(pMesh mesh)
{
  return mesh->getSolidModel();
}

void P_setParam1(pPoint, double param)
{
  throw 1;
}
void P_setParam2(pPoint, double p1, double p2, int ptch)
{
  throw 1;
}

void M_delete (pMesh pm)
{
  delete pm;
}

pPList  FMDB_createAdjPList ( pEntity pe , int dim )
{
  pPList pl = PList_new();
  if(pe->getLevel() >= dim)
      pe->getAppendPList(dim, pl);
  else
     {
      set<mEntity*> upward; 
      pe->getHigherOrderUpward(dim, upward);
      for(set<mEntity*>::iterator iter=upward.begin(); iter!=upward.end(); ++iter)
	 PList_append(pl, (void*)(*iter)); 
    }
  return pl;
}

/*#ifndef FLEXDB
int M_load (pMesh pm, const char *filename)
{
#ifdef DMUM
// pause DMUM temporarily
  bool wasOn=false;
  if (pm->DMUM_on) 
  {
    wasOn=true;
    pm->DMUM_on=false;
  }
#endif  
  double t1 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
    printf("\n***************\n  FMDB One-Level\n");  
    
  char ext[6];
  strcpy(ext,filename+(strlen(filename)-4));
#ifdef FMDB_PARALLEL
  zoltanCB zlb;
  FMDB_Util::Instance()->load_and_partition(filename,pm,zlb);
  int mDim = M_globalMaxDim(pm);
  ParUtil::Instance()->set_maxMeshDim(mDim);
#else
  FMDB_Util::Instance()->import(pm, filename);    
#endif
  double t2 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
  {  
    printf("   (t = %f sec)\n", t2-t1);
    printf("***************\n");  
  }
#ifdef DMUM
  if (wasOn) pm->DMUM_on=true;
#endif  

  return 1;
}
#endif

void M_writeSMS(pMesh pm, const char *name)
{
  char realName [256];
  char ext[5];
  strcpy(ext,name+(strlen(name)-4));
  if(strcmp(ext,".sms"))
  {
#ifdef FMDB_PARALLEL
  sprintf(realName,"%s%d.sms",name,ParUtil::Instance()->rank());
#else
  sprintf(realName,"%s.sms",name);
#endif
  FMDB_Util::Instance()->ex_port(pm,realName);
  }
  else{
   char without_extension[256];
   snprintf(without_extension,strlen(name)-3,"%s",name);
#ifdef FMDB_PARALLEL
     sprintf(realName,"%s%d.sms",without_extension,ParUtil::Instance()->rank());
#else
     sprintf(realName,"%s",name);
#endif
   FMDB_Util::Instance()->ex_port(pm,realName);
  }
}
*/
int M_numRegions (pMesh pm)
{
  return pm->size(3);
}

int M_numFaces (pMesh pm)
{
  return pm->size(2);
}

int M_numEdges (pMesh pm)
{
  return pm->size(1);
}

int M_numVertices (pMesh pm)
{
  return pm->size(0);
}

pRegion M_region(pMesh pm, int i)
{
  if(!i)return *(pm->begin(3));
  else throw new mException(__LINE__,__FILE__,"No random access iterators to regions in FMDB");
}

pFace M_face(pMesh pm, int i)
{
  if(!i)return *(pm->begin(2));
  else throw new mException(__LINE__,__FILE__,"No random access iterators to faces in FMDB");
}

pRegion M_edge(pMesh pm, int i)
{
  if(!i)return *(pm->begin(1));
  else throw new mException(__LINE__,__FILE__,"No random access iterators to edges in FMDB");
}

pVertex M_vertex(pMesh pm, int i)
{
  if(!i)return *(pm->begin(0));
  else throw new mException(__LINE__,__FILE__,"No random access iterators to vertices in FMDB");
}

RIter M_regionIter(pMesh mesh)
{
//  return mesh->getEntities().NewIterator (3);
//  return mesh->getEntities().getIterator(3);
   RIter iter = new mPartIterator(mesh->beginall(3), mesh->endall(3), 3, 0, 0, &processingNonFilter);
   return iter; 
}

FIter M_faceIter(pMesh mesh)
{
//  return mesh->getEntities().NewIterator (2);
//  return mesh->getEntities().getIterator (2);
   FIter iter = new mPartIterator(mesh->beginall(2), mesh->endall(2), 2, 0, 0, &processingNonFilter);
   return iter; 
}

EIter M_edgeIter(pMesh mesh)
{
//  return mesh->getEntities().NewIterator (1);
//  return mesh->getEntities().getIterator (1);
   EIter iter = new mPartIterator(mesh->beginall(1), mesh->endall(1), 1, 0, 0, &processingNonFilter);
   return iter; 
}

VIter M_vertexIter(pMesh mesh)
{
//  return mesh->getEntities().NewIterator (0);
//  return mesh->getEntities().getIterator (0);
    VIter iter = new mPartIterator(mesh->beginall(0), mesh->endall(0), 0, 0, 0, &processingNonFilter);
    return iter;
}

pRegion RIter_next(RIter it)
{
  if(it->end())return 0;
  mEntity *e = *(*it);
  it->next();
  return e;
}

void RIter_delete(RIter it)
{
//  it->getEntities()->deleteIterator(it);
   delete it; 
}

void RIter_reset(RIter it)
{
  it->reset();
}

pFace FIter_next(FIter it)
{
  return RIter_next(it);
}

void FIter_delete(FIter it)
{
  RIter_delete(it);
}

void FIter_reset(FIter it)
{
  RIter_reset(it);
}

pEdge EIter_next(EIter it)
{
  return RIter_next(it);
}

void EIter_delete(EIter it)
{
  RIter_delete(it);
}

void EIter_reset(EIter it)
{
  RIter_reset(it);
}

pVertex VIter_next(VIter it)
{
  return RIter_next(it);
}

void VIter_delete(VIter it)
{
  RIter_delete(it);
}

void VIter_reset(VIter it)
{
  RIter_reset(it);
}

/*
 Regions operators
*/

int R_numFaces(pRegion pr)
{
  assert (pr->getLevel() == 3);
  return pr->size(2);
}

pFace R_face(pRegion pr, int n)
{
  return pr->get(2,n);
}

int R_numEdges(pRegion pr)
{
  return pr->size(1);
}

pEdge R_edge(pRegion pr, int n)
{
  return pr->get(1,n);
}

int R_numVertices(pRegion pr)
{
  return pr->size(0);
}

pVertex R_vertex(pRegion pr, int n)
{
  return pr->get(0,n);
}

int R_faceDir (pRegion pr, int n)
{
  return pr->getUse ( pr->get (2,n) );
}

int F_edgeDir (pFace pf, int n)
{
  return pf->getUse (pf->get(1,n));
}

pGRegion R_whatIn(pRegion pr)
{
  if (pr->getClassification()) 
    return (pGRegion)pr->getClassification();
  else
    return (pGRegion)NULL;
}

pGEntity EN_whatIn(pEntity pe)
{
  return (pGEntity)R_whatIn (pe);
}

pGEntity F_whatIn(pFace pf)
{
  return (pGEntity)R_whatIn (pf);
}

pGEntity  E_whatIn(pEdge pe)
{
  return (pGEntity)R_whatIn (pe);
}

pGEntity  V_whatIn(pVertex pv)
{ 
  return (pGEntity)R_whatIn (pv);
}


int F_numEdges(pFace pf)
{
  return pf->size(1);
}

pEdge F_edge(pFace pg, int n)
{
  return pg->get(1,n);
}

int F_numVertices(pFace pf)
{
  return pf->size(0);
}

pVertex F_vertex(pFace pf, int n)
{
  return pf->get(0,n);
}

int E_numRegions(pEdge pv)
{
  // mAdjacencyContainer upward;
  set<mEntity*> upward; 
  pv->getHigherOrderUpward(3,upward);
  return upward.size();
}

int E_numVertices(pEdge pe)
{
  return pe->size(0);
}

pVertex E_vertex(pEdge pe, int n)
{
  //  printf("asking vertex %d of an edge ",n);pe->print();
  return pe->get(0,n);
}

pPList E_vertices(pEdge pe)
{
  pPList pl = PList_new();
  PList_append(pl,(void *)pe->get(0,0));
  PList_append(pl,(void *)pe->get(0,1));
  return pl;
}

int EN_type(pEntity pe)
{
  return pe->getLevel();
}

pFace E_face(pEdge pe, int n)
{
  return pe->get(2,n);
}

int E_numFaces(pEdge pe)
{
  if(pe->isAdjacencyCreated(2))
    return pe->size(2);
  else
    return 0;
}

RIter M_classifiedIter(pMesh mesh, pGEntity ent, int dim)
{
  /// look here for how to get dimension and id of the pGEntity
  /// in order to retrieve gEntity from pEntity
  
//  GEntity *gent = mesh->getGEntity (GEN_tag(ent),GEN_type(ent)); /* GEN_id 
//is changed to GEN_tag since tag is the identification for the gEntities in
//FMDB now - Mohan Nuggehally 06-12-03 */

//  assert (gent->getSolidModelEntity() == ent);
//  return mesh->getEntities().NewIterator (dim,ent);
//  return mesh->getEntities().getIterator (dim, ent);
   RIter riter = new mPartIterator(mesh->beginall(dim), mesh->endall(dim), dim, 0, (void*)ent, &processingGeomFilter);
   return riter; 
}

int F_numRegions(pFace pf)
{
  if(pf->isAdjacencyCreated(3))
    return pf->size(3);
  else
    return 0;
}

RIter M_classifiedRegionIter(pMesh mesh, pGEntity ent)
{
  return M_classifiedIter(mesh,ent, 3);
 // return mesh->getEntities().getIterator (3, ent);
}

FIter M_classifiedFaceIter(pMesh mesh, pGEntity ent, int closure)
{
  if(!closure)
    return M_classifiedIter(mesh,ent, 2);
//    return mesh->getEntities().getIterator (2, ent);
  else
    throw 1;
}

EIter M_classifiedEdgeIter(pMesh mesh, pGEntity ent, int closure)
{
  if(!closure)
    return M_classifiedIter(mesh,ent, 1);
//    return mesh->getEntities().getIterator (1, ent);
  else
    throw 1;
}

VIter M_classifiedVertexIter(pMesh mesh, pGEntity ent, int closure)
{
  if(!closure)
    return M_classifiedIter(mesh,ent, 0);
//    return mesh->getEntities().getIterator (0, ent);
  else
    throw 1;   
}

pVertex M_classifiedVertex(pMesh m, pGVertex gv) {
  VIter viter = M_classifiedVertexIter(m, (pGEntity) gv, 0);
  pVertex v = VIter_next(viter);
  VIter_delete(viter);
  return v;
}



pPList F_vertices(pFace pf, int dir)
{
  if (dir >= 1)
    return FMDB_createAdjPList ( pf, 0 );
  pPList pl = PList_new();
  int N = pf->size(0); 
  for (int i=0;i<N;i++)
    {
      PList_append(pl,pf->get(0,N-i-1));
    }
  return pl;
}

pPList V_regions(pVertex v)
{
  return FMDB_createAdjPList ( v, 3 );
}

pPList E_regions(pEdge e)
{
  return FMDB_createAdjPList ( e, 3 );
}

pPList V_faces(pVertex v)
{
  return FMDB_createAdjPList ( v, 2 );
}

int EN_id(pEntity pe)
{
  if(pe->getLevel() == 0)return pe->getId();
  else return pe->getAttachedInt(FMDB_Util::Instance()->getId());
}

void EN_setID(pEntity pe, int id)
{
  if (pe->getLevel() == 0)
  throw new mException(__LINE__,__FILE__,"Can't set ID to vertices in FMDB");
  pe->attachInt(FMDB_Util::Instance()->getId(),id);
}

pPList R_edges(pRegion pr,int)
{
  return FMDB_createAdjPList ( pr, 1 );
}


pPList R_faces(pFace pr, int)
{
  return FMDB_createAdjPList ( pr, 2 );
}

pPList R_vertices(pRegion pr, int)
{
  return FMDB_createAdjPList ( pr, 0 );
}

pPoint  V_point(pVertex pv)
{
  return pv;
}

pPList F_edges(pFace pf , int dir,pVertex vtx)
{
  return FMDB_createAdjPList ( pf, 1 );
}

pPList F_regions(pFace pf)
{
  return FMDB_createAdjPList ( pf, 3 );
}

pRegion F_region(pFace pf, int n)
{
  if(!pf->isAdjacencyCreated(3))return 0;
  if(n >= pf->size(3))return 0;
  if(pf->size(3) > 2)throw;
  return pf->get(3,n);
}

int V_numEdges(pVertex  pv)
{
  if(pv->isAdjacencyCreated(1))
    return pv->size(1);
  else
    return 0;
}

pEdge V_edge(pVertex pv, int n)
{
  return pv->get(1,n);
}

pPList V_edges(pVertex pv)
{
  return FMDB_createAdjPList ( pv, 1 );
}

int V_numFaces(pVertex pv)
{
//  mAdjacencyContainer upward;
  set<mEntity*> upward; 
  pv->getHigherOrderUpward(2,upward);
  return upward.size();
}

int V_numRegions(pVertex pv)
{
//  mAdjacencyContainer upward;
   set<mEntity*> upward; 
  pv->getHigherOrderUpward(3,upward);
  return upward.size();
}

double P_x(pPoint p){return ((mVertex*)p)->point()(0);}
double P_y(pPoint p){return ((mVertex*)p)->point()(1);}
double P_z(pPoint p){return ((mVertex*)p)->point()(2);}

pMeshDataId MD_newMeshDataId(const char *tag) {return FMDB_Util::Instance()->newMeshDataId(tag);}
pMeshDataId MD_lookupMeshDataId(const char *tag) {return FMDB_Util::Instance()->lookupMeshDataId   (tag);}
void MD_deleteMeshDataId(pMeshDataId id) {FMDB_Util::Instance()->deleteMeshDataId(id);}

void EN_attachDataI(pEntity pe, const char *tag, int data)
{
  pe->attachInt(MD_lookupMeshDataId(tag),data);
}

void EN_attachDataInt(pEntity pe, pMeshDataId id, int data)
{
  pe->attachInt(id,data);
}

int EN_dataI(pEntity pe, const char *tag)
{
  return pe->getAttachedInt(MD_lookupMeshDataId(tag));
}

int EN_getDataDbl(pEntity ent, pMeshDataId id, double *value)
{
//  *value = ent->getAttachedDouble(id);
//  return 1;
  return ent->getAttachedDouble(id, value);
}

void EN_attachDataDbl(pEntity ent, pMeshDataId id, double value)
{
  ent->attachDouble(id,value);
}

void Ent_AttachDataPt(pEntity ent, pMeshDataId id, double* param)
{
   SCOREC::Util::mPoint p(param[0], param[1], param[2]); 
   ent->attachPoint(id, p);
}

int EN_modifyDataI(pEntity pe, const char *tag, int data)
{
  pe->attachInt(MD_lookupMeshDataId(tag),data);
  return 1;
}

void EN_modifyDataInt(pEntity ent, pMeshDataId id, int value)
{
  ent->attachInt(id,value);
}

void EN_modifyDataDbl(pEntity ent, pMeshDataId id, double value)
{
  ent->attachDouble(id,value);
}

void MS_init(void)
{
}

void MS_exit(void)
{
}

double P_param1(pPoint p)
{
  if (!p->getData(FMDB_Util::Instance()->getParametric()))
    throw new mException(__LINE__,__FILE__,
			 "The mesh you have loaded does not have parametric coorinates");
  SCOREC::Util::mVector vec = p->getAttachedVector (FMDB_Util::Instance()->getParametric());
  return vec(0);
}
void P_param2(pPoint p, double *p1, double *p2, int *ptch)
{
  if (!p->getData(FMDB_Util::Instance()->getParametric()))
    throw new mException(__LINE__,__FILE__,
			 "The mesh you have loaded does not have parametric coorinates");
  SCOREC::Util::mVector vec = p->getAttachedVector (FMDB_Util::Instance()->getParametric());
  *p1   = vec(0);
  *p2   = vec(1);
//  *ptch = (int)vec(2);
}

pVertex  E_otherVertex(pEdge pe, pVertex v)
{
  mEdge *e = (mEdge*)pe;
  if(e->vertex(0) == v)return e->vertex(1);
  if(e->vertex(1) == v)return e->vertex(0);
  throw new mException(__LINE__,__FILE__,
		       "E_otherVertex failed");
}

pFace E_otherFace(pEdge edge, pFace face, pRegion region)
{
  mFace *f = (mFace*)face;
  mRegion *r = (mRegion*)region;

  for(int i=0;i<r->size(2);i++)
    {
      mFace *f2 = (mFace*)r->get(2,i);
      if(f2 != f && f2->find(edge))return f2;
    }  
  throw new mException(__LINE__,__FILE__,
		       "E_otherFace failed");
}

void V_coord(pVertex pv, double *xyz)
{
/*
   SCOREC::Util::mPoint p = ((mVertex*)pv)->point();
   xyz[0] = p(0);
   xyz[1] = p(1);
   xyz[2] = p(2);
*/
 ((mVertex*)pv)->getCoord(xyz[0],xyz[1],xyz[2]);
}


pPoint P_new(void)
{
  return new mVertex(0,SCOREC::Util::mPoint(0,0,0),0);
}

void P_delete(pPoint p)
{
  delete p;
}

void P_setPos(pPoint p , double x, double y, double z)
{
  SCOREC::Util::mPoint temp(x,y,z);
  ((mVertex*)p)->move(SCOREC::Util::mPoint(x,y,z));
}

void FMDB_P_setParametricPos ( pPoint p, double p1, double p2, double p3)
{
  p->attachVector (FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector(p1,p2,p3));
}

void EN_attachDataP(pEntity pe, const char *tag, void *data)
{
  unsigned int itag = MD_lookupMeshDataId(tag);
  EN_attachDataPtr(pe, itag, data);
}

void EN_attachDataPtr(pEntity ent, pMeshDataId id, void * value)
{
  mAttachableVoid *av = (mAttachableVoid *)ent->getData(id);
  if(!av)
    {
      av = new mAttachableVoid;
      ent->attachData(id,av);
    }
  else
    {
      //      delete av->veryNastyPointer;
    }
  //  printf ("attaching %s to ",tag);pe->print();
  av->veryNastyPointer = value;
}

void * EN_dataP(pEntity pe, const char *tag)
{  
  unsigned int itag = MD_lookupMeshDataId(tag);
  mAttachableVoid *av = (mAttachableVoid *)pe->getData(itag);
  if(!av)
    {
      //      printf("data %s not found on ",tag);pe->print();
      //      pe->printAllAttachable ();
    }
  if(!av)return 0;
  return av->veryNastyPointer;
}

int EN_modifyDataP(pEntity pe, const char *tag, void * data)
{
  EN_attachDataP(pe, tag, data);
  return 1;
}

void F_normalVector(pFace face, int dir, double* normal)
{
  SCOREC::Util::LagrangeMapping mapping(face);
  double u,v,w;
  SCOREC::Util::mTensor2 j;
  mapping.COG(u,v,w);
  mapping.jacInverse(u,v,w, j);
  
  // in reference coordinates, n = (0,0,1);
  SCOREC::Util::mVector n (0,0,1);
  n= j*n;
  
  normal[0] = n(0) * dir;
  normal[1] = n(1) * dir;
  normal[2] = n(2) * dir;  
}

void E_setPoint (pEdge e, pPoint p) {
  ((mEdge*)e)->pts.push_back (p);
}

int E_numPoints(pEdge e)
{
  return ((mEdge*)e)->pts.size();
}

pPoint E_point(pEdge e , int n)
{
  if (((mEdge*)e)->pts.size()<=n)
     std::cerr << "E_point Error: " << n << "'th higher order node does not exist\n";
  return ((mEdge*)e)->pts[n];
}

int EN_getDataPtr(pEntity ent, pMeshDataId id, void **value)
{

  mAttachableVoid *av = (mAttachableVoid *)ent->getData(id);
  if(!av)
    {
      //      printf("data %s not found on ",tag);pe->print();
      //      pe->printAllAttachable ();
    }
  if(!av)return 0;
  *value =  av->veryNastyPointer;
  return 1;
}

int EN_getDataInt(pEntity ent, pMeshDataId id, int *value)
{
//  *value = ent->getAttachedInt(id);
//  if(*value)return 1;
//  return 0;
   return ent->getAttachedInt(id, value); 
}

int Ent_GetDataPt(pEntity ent, pMeshDataId id, double* param)
{
   SCOREC::Util::mPoint p; 
   int val = ent->getAttachedPoint(id, &p);
   if(!val)
      return 0; 
   for(int i=0; i<3; ++i)
      param[i] = p(i);
   return 1; 
}

void R_setWhatIn(pRegion e, pGEntity what)
{
      e->classify (what);
      return;
}

void EN_setWhatIn(pMesh pm, pEntity e, pGEntity what)
{
  e->classify (what);
}

void F_setWhatIn(pFace   e, pGEntity what){R_setWhatIn(e,what);}
void E_setWhatIn(pEdge   e, pGEntity what){R_setWhatIn(e,what);}
void V_setWhatIn(pVertex e, pGEntity what){R_setWhatIn(e,what);}

pRegion M_createR(pMesh mesh, int nFace, pFace *faces, int *dirs, pGEntity gent)
{
#ifndef FLEXDB
  if(nFace == 4) 
    {
      pRegion r = (mRegion*)mesh->createTetWithFaces ((mFace*)faces[0],(mFace*)faces[1],
				(mFace*)faces[2],(mFace*)faces[3],gent);
      faces[0]->add(r);
      faces[1]->add(r);
      faces[2]->add(r);
      faces[3]->add(r);
      return r;
    }
  else if(nFace == 6)
   {
     pRegion r = (mRegion*)mesh->createHexWithFaces ((mFace*)faces[0],(mFace*)faces[1],
				(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],(mFace*)faces[5], gent);
      faces[0]->add(r);
      faces[1]->add(r);
      faces[2]->add(r);
      faces[3]->add(r);
      faces[4]->add(r);
      faces[5]->add(r);
      return r;
   }
  else if(nFace == 5)
   {
	 if(faces[0]->size(1) == 3) {
     pRegion r = (mRegion*)mesh->createPrismWithFaces ((mFace*)faces[0],(mFace*)faces[1],
				(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],gent);
      faces[0]->add(r);
      faces[1]->add(r);
      faces[2]->add(r);
      faces[3]->add(r);
      faces[4]->add(r);
      return r;
	  }
	  else if(faces[0]->size(1) == 4) {
	   pRegion r = (mRegion*)mesh->createPyramidWithFaces ((mFace*)faces[0],(mFace*)faces[1],
				(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],gent);
      faces[0]->add(r);
      faces[1]->add(r);
      faces[2]->add(r);
      faces[3]->add(r);
      faces[4]->add(r);
      return r;
	  }
   }
  else {
	std::cerr<<"M_createR unsupported element type\n";
    throw 1;
  }
#else
  if (nFace==4)
  {
    return (pRegion)(mesh->createTet_F_FP(mesh, (mFace*)faces[0], (mFace*)faces[1], 
                               (mFace*)faces[2], (mFace*)faces[3], gent));
  }
  else if(nFace==6)
    {
      return (pRegion)(mesh->createHex_F_FP(mesh, (mFace*)faces[0], (mFace*)faces[1], 
					    (mFace*)faces[2], (mFace*)faces[3], (mFace*)faces[4], (mFace*)faces[5], gent));
    }
  else if(nFace==5)
    {
      if(faces[0]->size(1) == 3)
	return (pRegion)(mesh->createPrism_F_FP(mesh, (mFace*)faces[0], (mFace*)faces[1], 
						(mFace*)faces[2], (mFace*)faces[3], (mFace*)faces[4], gent));
      else if(faces[0]->size(1) == 4)
	return (pRegion)(mesh->createPyramid_F_FP(mesh, (mFace*)faces[0], (mFace*)faces[1], 
						  (mFace*)faces[2], (mFace*)faces[3], (mFace*)faces[4], gent));								
    }
  else
  {
    std::cerr<<"M_createR unsupport element type...\n";
    throw 1;
  }
#endif
  return 0;
}

pFace M_createF(pMesh mesh, int nEdge, pEdge *edges, int *dirs, pGEntity gent)
{
#ifndef FLEXDB
  pFace f;
  if(nEdge == 3) 
    f = mesh->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],
 			          (mEdge*)edges[2],gent,dirs);
  else if (nEdge == 4)
    f =  mesh->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],
			           (mEdge*)edges[2],(mEdge*)edges[3],gent,dirs);
  else 
    return 0;
  for(int i=0;i<nEdge;i++)
    edges[i]->add(f);
  return f;
#else
  if (nEdge==3)
    return mesh->createTri_E_FP(mesh, (mEdge*)edges[0], (mEdge*)edges[1], 
                               (mEdge*)edges[2], gent, dirs);
  else
    return (pFace)(mesh->createQuad_E_FP(mesh, (mEdge*)edges[0], (mEdge*)edges[1], 
                               (mEdge*)edges[2], (mEdge*)edges[3], gent, dirs));
#endif
}

pEdge M_createE(pMesh mesh, pVertex v1, pVertex v2, pGEntity gent)
{
#ifdef DEBUG
  pEdge e = E_exist(v1, v2);
  if (e)
  {
    std::cerr<<"FATAL: Attemp to create existing edge "<<e->getUid()<<"\n  => ";
    e->print();
    assert(!e);
  }       
#endif
#ifndef FLEXDB
  pEdge p = (pEdge)mesh->createEdge ((mVertex*)v1,(mVertex*)v2,gent);
  v1->add (p);
  v2->add (p);
  return p;
#else
  if (!v1||!v2||v1->getLevel()!=0||v2->getLevel()!=0)
  {
    cerr<<"("<<P_pid()<<") mesh->createE FAILED!\n";
    throw 1;
  }
  assert(v1&&v2&&v1->getLevel()==0&&v2->getLevel()==0);
  
  return mesh->createE_FP(mesh, (mVertex*)v1, (mVertex*)v2, gent); 
#endif
}

pVertex M_createVP(pMesh mesh, double x, double y, double z, double *param,
		   int id, pGEntity gent)
{
  pVertex vv;
  if (id != 0)
    vv=(pVertex)mesh->createVertex (id,x,y,z,gent);
  else
    vv=(pVertex)mesh->createVertex (x,y,z,gent);

  vv->attachVector ( FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector (*param,*(param+1),*(param+2)) );
  return vv;
}

pVertex M_createVP2(pMesh mesh, double *xyz, double *param,
		    int id, pGEntity gent)
{
  pVertex vv;
  if (id!=0)
    vv=mesh->createVertex (id,xyz[0],xyz[1],xyz[2],gent);
  else 
    vv=mesh->createVertex (xyz[0],xyz[1],xyz[2],gent);
  vv->attachVector ( FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector (*param,*(param+1),*(param+2)) );
  return vv;
}

pPoint M_createP(pMesh mesh, double x, double y, double z, double *param,
		 int unused, pGEntity ent)
{
  throw 1;
}

pRegion M_createRV(pMesh mesh, int nVertex, pVertex* vertices, int *dirs, pGEntity gent)
{
mEntity* tmpEdges[4];
#ifndef FLEXDB
  if(nVertex == 4)
    {
      mVertex* v1 = (mVertex*)vertices[0];
      mVertex* v2 = (mVertex*)vertices[1];
      mVertex* v3 = (mVertex*)vertices[2];
      mVertex* v4 = (mVertex*)vertices[3];
      mEntity* edges[6];
      mEntity* faces[4];

      edges[0] = (mEntity*)E_exist(v1, v2);
       if (!edges[0])
           {
            edges[0]=M_createE(mesh,v1,v2, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
            }

      edges[1] = (mEntity*)E_exist(v2, v3);
      if (!edges[1])
          {
            edges[1]=M_createE(mesh,v2,v3,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

      edges[2] = (mEntity*)E_exist(v3, v1);
      if (!edges[2])
        {
         edges[2]=M_createE(mesh,v3,v1,gent);
         ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }

      edges[3]=(mEntity*)E_exist(v1, v4);
      if (!edges[3])
       {
        edges[3]=M_createE(mesh, v1,v4,gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }

      edges[4]=(mEntity*)E_exist(v2,v4);
      if (!edges[4])
        {
         edges[4]=M_createE(mesh,v2,v4,gent);
         ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }

      edges[5]=(mEntity*)E_exist(v3,v4);
      if (!edges[5])
        {
        edges[5]=M_createE(mesh, v3, v4,gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }

      faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], 0);
      if(!faces[0])
        {
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
        faces[0]= M_createF(mesh, 3, edges, 0, gent);
        }
      faces[1]=(mEntity*)F_exist(1, edges[0], edges[4], edges[3], 0);
      if(!faces[1])
          {
            tmpEdges[0]=edges[0];
            tmpEdges[1]=edges[4];
            tmpEdges[2]=edges[3];
            faces[1]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }

      faces[2]=(mEntity*)F_exist(1, edges[1], edges[5], edges[4], 0);
          if(!faces[2])
          {
            tmpEdges[0]=edges[1];
            tmpEdges[1]=edges[5];
            tmpEdges[2]=edges[4];
            faces[2]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }
      faces[3]=(mEntity*)F_exist(1, edges[2], edges[5], edges[3], 0);
          if(!faces[3])
          {
            tmpEdges[0]=edges[2];
            tmpEdges[1]=edges[5];
            tmpEdges[2]=edges[3];
            faces[3]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }

      pRegion ent=(mEntity*)M_createR(mesh, 4, faces, 0, gent);
      return ent;
    }
   else if(nVertex == 5)
    {
     //pyramid
      mVertex* v1 = (mVertex*)vertices[0];
      mVertex* v2 = (mVertex*)vertices[1];
      mVertex* v3 = (mVertex*)vertices[2];
      mVertex* v4 = (mVertex*)vertices[3];
      mVertex* v5 = (mVertex*)vertices[4];
      mEntity* faces[5];
      mEntity* edges[8];
      edges[0]=(mEntity*)E_exist(v1, v2);
          if (!edges[0])
           {
            edges[0]=M_createE(mesh,v1, v2, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[1]=(mEntity*)E_exist(v2, v3);
          if (!edges[1])
           {
            edges[1]=M_createE(mesh,v2,v3, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[2]=(mEntity*)E_exist(v3, v4);
          if (!edges[2])
            {
            edges[2]=M_createE(mesh, v3, v4, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
            }

          edges[3]=(mEntity*)E_exist(v4, v1);
          if (!edges[3])
           {
            edges[3]=M_createE(mesh, v4, v1, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[4]=(mEntity*)E_exist(v1, v5);
          if (!edges[4])
           {
            edges[4]=M_createE(mesh, v1, v5, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[5]=(mEntity*)E_exist(v2, v5);
          if (!edges[5])
           {
            edges[5]=M_createE(mesh, v2, v5, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[6]=(mEntity*)E_exist(v3, v5);
          if (!edges[6])
           {
            edges[6]=M_createE(mesh, v3, v5, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

          edges[7]=(mEntity*)E_exist(v4, v5);
          if (!edges[7])
           {
            edges[7]=M_createE(mesh, v4,v5,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

         faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], edges[3]);
          if(!faces[0])
            {
            faces[0]= M_createF(mesh, 4, edges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
            }
         faces[1]=(mEntity*)F_exist(1, edges[0], edges[5], edges[4], 0);
          if(!faces[1])
          {
            tmpEdges[0]=edges[0];
            tmpEdges[1]=edges[5];
            tmpEdges[2]=edges[4];
            faces[1]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }
         faces[2]=(mEntity*)F_exist(1, edges[1], edges[6], edges[5], 0);
          if(!faces[2])
          {
            tmpEdges[0]=edges[1];
            tmpEdges[1]=edges[6];
            tmpEdges[2]=edges[5];
            faces[2]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }
        faces[3]=(mEntity*)F_exist(1, edges[2], edges[7], edges[6], 0);
          if(!faces[3])
          {
            tmpEdges[0]=edges[2];
            tmpEdges[1]=edges[7];
            tmpEdges[2]=edges[6];
            faces[3]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }
        faces[4]=(mEntity*)F_exist(1, edges[3], edges[4], edges[7], 0);
          if(!faces[4])
          {
            tmpEdges[0]=edges[3];
            tmpEdges[1]=edges[4];
            tmpEdges[2]=edges[7];
            faces[4]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }
     pRegion ent = (mEntity*)M_createR(mesh, 5, faces, 0, gent);
	return ent;
    }
  else if(nVertex == 6)
   {
    // prism
     mEntity* faces[5];
     mEntity* edges[9];
     mVertex* v1 = (mVertex*)vertices[0];
      mVertex* v2 = (mVertex*)vertices[1];
      mVertex* v3 = (mVertex*)vertices[2];
      mVertex* v4 = (mVertex*)vertices[3];
      mVertex* v5 = (mVertex*)vertices[4];
      mVertex* v6 = (mVertex*)vertices[5];

     edges[0]=(mEntity*)E_exist(v1, v2);
      if (!edges[0])
        {
         edges[0]=M_createE(mesh, v1, v2, gent);
         ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }
      edges[1]=(mEntity*)E_exist(v2, v3);
      if (!edges[1])
       {
        edges[1]=M_createE(mesh, v2, v3, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }
       edges[2]=(mEntity*)E_exist(v3, v1);
      if (!edges[2])
       {
        edges[2]=M_createE(mesh, v3, v1, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }

       edges[3]=(mEntity*)E_exist(v1, v4);
      if (!edges[3])
       {
        edges[3]=M_createE(mesh, v1, v4, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }

        edges[4]=(mEntity*)E_exist(v2, v5);
       if (!edges[4])
        {
        edges[4]=M_createE(mesh, v2, v5, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }

         edges[5]=(mEntity*)E_exist(v3, v6);
       if (!edges[5])
        {
        edges[5]=M_createE(mesh, v3, v6, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
        }
         edges[6]=(mEntity*)E_exist(v4, v5);
      if (!edges[6])
       {
        edges[6]=M_createE(mesh, v4, v5, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }

       edges[7]=(mEntity*)E_exist(v5, v6);
      if (!edges[7])
       {
        edges[7]=M_createE(mesh, v5, v6, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }

      edges[8]=(mEntity*)E_exist(v6, v4);
      if (!edges[8])
       {
        edges[8]=M_createE(mesh, v6, v4, gent);
        ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
       }
 
          faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], 0);
          if(!faces[0])
           {
            faces[0]= M_createF(mesh, 3, edges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
           }

          faces[1]=(mEntity*)F_exist(1, edges[0], edges[4], edges[6], edges[3]);
          if(!faces[1])
          {
            tmpEdges[0]=edges[0];
            tmpEdges[1]=edges[4];
            tmpEdges[2]=edges[6];
            tmpEdges[3]=edges[3];
            faces[1]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);      
          }

          faces[2]=(mEntity*)F_exist(1, edges[1], edges[5], edges[7], edges[4]);
          if(!faces[2])
          {
            tmpEdges[0]=edges[1];
            tmpEdges[1]=edges[5];
            tmpEdges[2]=edges[7];
            tmpEdges[3]=edges[4];
            faces[2]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }

          faces[3]=(mEntity*)F_exist(1, edges[2], edges[3], edges[8], edges[5]);
          if(!faces[3])
          {
            tmpEdges[0]=edges[2];
            tmpEdges[1]=edges[3];
            tmpEdges[2]=edges[8];
            tmpEdges[3]=edges[5];
            faces[3]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }
         faces[4]=(mEntity*)F_exist(1, edges[6], edges[7], edges[8], 0);
          if(!faces[4])
          {
            tmpEdges[0]=edges[6];
            tmpEdges[1]=edges[7];
            tmpEdges[2]=edges[8];
            faces[4]= M_createF(mesh, 3, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::TRIANGLE);
          }

     pRegion ent=(mEntity*)M_createR(mesh, 5, faces, 0, gent);
     return ent;
   }
  else if(nVertex == 8)
    {
      mEntity* faces[6];
      mEntity* edges[12];

      mVertex* v1 = (mVertex*)vertices[0];
      mVertex* v2 = (mVertex*)vertices[1];
      mVertex* v3 = (mVertex*)vertices[2];
      mVertex* v4 = (mVertex*)vertices[3];
      mVertex* v5 = (mVertex*)vertices[4];
      mVertex* v6 = (mVertex*)vertices[5];
      mVertex* v7 = (mVertex*)vertices[6];
      mVertex* v8 = (mVertex*)vertices[7];

       edges[0]=(mEntity*)E_exist(v1,v2);
          if (!edges[0])
           {
            edges[0]=M_createE(mesh,v1,v2,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);            
           }
        edges[1]=(mEntity*)E_exist(v2,v3);
          if (!edges[1])
           {
            edges[1]=M_createE(mesh,v2,v3,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
       edges[2]=(mEntity*)E_exist(v3,v4);
          if (!edges[2])
           {
            edges[2]=M_createE(mesh,v3,v4,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
       edges[3]=(mEntity*)E_exist(v1,v4);
          if (!edges[3])
           {
            edges[3]=M_createE(mesh,v1,v4,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
       edges[4]=(mEntity*)E_exist(v1,v5);
          if (!edges[4])
           {
            edges[4]=M_createE(mesh,v1,v5,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
       edges[5]=(mEntity*)E_exist(v2,v6);
          if (!edges[5])
           {
            edges[5]=M_createE(mesh,v2,v6,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
       edges[6]=(mEntity*)E_exist(v3,v7);
          if (!edges[6])
           {
            edges[6]=M_createE(mesh,v3,v7,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
        edges[7]=(mEntity*)E_exist(v4,v8);
          if (!edges[7])
           {
            edges[7]=M_createE(mesh,v4,v8,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
        edges[8]=(mEntity*)E_exist(v5,v6);
          if (!edges[8])
           {
            edges[8]=M_createE(mesh,v5,v6,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
        edges[9]=(mEntity*)E_exist(v6,v7);
          if (!edges[9])
           {
            edges[9]=M_createE(mesh,v6,v7,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
        edges[10]=(mEntity*)E_exist(v7,v8);
          if (!edges[10])
           {
            edges[10]=M_createE(mesh,v7,v8,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }
        edges[11]=(mEntity*)E_exist(v8,v5);
          if (!edges[11])
           {
            edges[11]=M_createE(mesh,v8,v5,gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
           }

        faces[0]=(mEntity*)F_exist(1, edges[3], edges[2], edges[1], edges[0]);
        faces[1]=(mEntity*)F_exist(1, edges[0], edges[5], edges[8], edges[4]);
        faces[2]=(mEntity*)F_exist(1, edges[1], edges[6], edges[9], edges[5]);
        faces[3]=(mEntity*)F_exist(1, edges[2], edges[7], edges[10], edges[6]);
        faces[4]=(mEntity*)F_exist(1, edges[3], edges[4], edges[11], edges[7]);
        faces[5]=(mEntity*)F_exist(1, edges[8], edges[9], edges[10], edges[11]);
        
        if(faces[0] && faces[1] && faces[2] && faces[3] && faces[4] && faces[5])
           return (pRegion)0;

        if(!faces[0])
          {
            tmpEdges[0]=edges[3];
            tmpEdges[1]=edges[2];
            tmpEdges[2]=edges[1];
            tmpEdges[3]=edges[0];
            faces[0]= M_createF(mesh, 4, edges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          } 

         if(!faces[1])
           {
            tmpEdges[0]=edges[0];
            tmpEdges[1]=edges[5];
            tmpEdges[2]=edges[8];
            tmpEdges[3]=edges[4];
            faces[1]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }

         if(!faces[2])
          {
            tmpEdges[0]=edges[1];
            tmpEdges[1]=edges[6];
            tmpEdges[2]=edges[9];
            tmpEdges[3]=edges[5];
            faces[2]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }
         if(!faces[3])
           {
            tmpEdges[0]=edges[2];
            tmpEdges[1]=edges[7];
            tmpEdges[2]=edges[10];
            tmpEdges[3]=edges[6];
            faces[3]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }
          if(!faces[4])
           {
            tmpEdges[0]=edges[3];
            tmpEdges[1]=edges[4];
            tmpEdges[2]=edges[11];
            tmpEdges[3]=edges[7];
            faces[4]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }
         if(!faces[5])
           {
            tmpEdges[0]=edges[8];
            tmpEdges[1]=edges[9];
            tmpEdges[2]=edges[10];
            tmpEdges[3]=edges[11];
            faces[5]= M_createF(mesh, 4, tmpEdges, 0, gent);
            ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::QUADRILATERAL);
          }
         pRegion ent=(mEntity*)M_createR(mesh, 6, faces, 0, gent);
         return ent;
    }
else
{
cout << "\n Terminating as no shape matched " << endl;
throw 1;
}
#else // FLEXDB
  if(nVertex == 4) 
    return (pRegion)mesh->createTet_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
				(mVertex*)vertices[2],(mVertex*)vertices[3],gent);
  else if(nVertex == 8) 
    return (pRegion)mesh->createHex_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
					 (mVertex*)vertices[2],(mVertex*)vertices[3],(mVertex*)vertices[4],
					 (mVertex*)vertices[5],(mVertex*)vertices[6],(mVertex*)vertices[7],gent);
  if(nVertex == 6) 
    return (pRegion)mesh->createPrism_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
				(mVertex*)vertices[2],(mVertex*)vertices[3],(mVertex*)vertices[4],(mVertex*)vertices[5], gent);
  else if(nVertex == 5) 
    return (pRegion)mesh->createPyramid_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
				(mVertex*)vertices[2],(mVertex*)vertices[3],(mVertex*)vertices[4],gent);
  
  
  
  else throw 1;
#endif
}

pFace M_createFV(pMesh mesh, int nVertex, pVertex* vertices, int *dirs, pGEntity gent)
{
#ifndef FLEXDB
  pFace f;
  mEntity* edges[4];  
  if(nVertex == 3) // triangle
  {

    edges[0]=(mEntity*)E_exist(vertices[0],vertices[1]); 
    if (!edges[0])
      {
      edges[0] = M_createE(mesh, vertices[0],vertices[1], 0);        
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT); 
      }
    edges[1]=(mEntity*)E_exist(vertices[1],vertices[2]); 
    if (!edges[1])
     {
      edges[1] = M_createE(mesh, vertices[1],vertices[2], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    edges[2]=(mEntity*)E_exist(vertices[0],vertices[2]); 
    if (!edges[2])
     {
      edges[2] = M_createE(mesh, vertices[0],vertices[2], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    
    f = mesh->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],
 			          (mEdge*)edges[2],gent,dirs);
  }
  else if (nVertex == 4)
  {
    edges[0]=(mEntity*)E_exist(vertices[0],vertices[1]);      
    if (!edges[0])
     {
      edges[0] = M_createE(mesh, vertices[0],vertices[1], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    edges[1]=(mEntity*)E_exist(vertices[1],vertices[2]); 
    if (!edges[1])
     {
      edges[1] = M_createE(mesh, vertices[1],vertices[2], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    edges[2]=(mEntity*)E_exist(vertices[2],vertices[3]); 
    if (!edges[2])
     {
      edges[2] = M_createE(mesh, vertices[2],vertices[3], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    edges[3]=(mEntity*)E_exist(vertices[0],vertices[3]); 
    if (!edges[3])
     {
      edges[3] = M_createE(mesh, vertices[0],vertices[3], 0);
      ITAPS_Util::Instance()->increaseNTE(mesh, mEntity::LINE_SEGMENT);
     }
    f =  mesh->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],
			           (mEdge*)edges[2],(mEdge*)edges[3],gent,dirs);
  }
  else 
    return 0;
  for(int i=0;i<nVertex;i++)
    edges[i]->add(f);
  return f;
#else // FLEXDB
  if (nVertex==3)
    return (pFace)mesh->createTri_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
 			          (mVertex*)vertices[2],gent,dirs);
  else if (nVertex==4)
    return (pFace)mesh->createQuad_V_FP(mesh, (mVertex*)vertices[0],(mVertex*)vertices[1],
 			          (mVertex*)vertices[2],(mVertex*)vertices[3],gent,dirs);
  else 
    return 0;  
#endif
}

#ifdef MATCHING               

void M_createMatchVP (pMesh mesh, struct v_create_struct** vinfo, int size, std::list<mEntity*>& mlist)
{
  v_create_struct* info;  
  mlist.clear(); 
 
  pVertex vv; 
  for(int i=0; i<size; i++){
    info = vinfo[i];
    if(info->id!=0)
      vv = mesh->createVertex (info->id,info->xyz[0],info->xyz[1],info->xyz[2],info->gent);
    else
      vv=mesh->createVertex (info->xyz[0],info->xyz[1],info->xyz[2],info->gent);
    vv->attachVector( FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector(*(info->param),*(info->param+1),*(info->param+2)));
    mlist.push_back(vv);
  }

  if(!mlist.empty())
     EN_addLocalMatchEnts(mlist);
}

void M_createMatchE (pMesh mesh, struct e_create_struct** einfo, int size, std::list<mEntity*>& mlist)
{
  pVertex v1,v2; 
  mlist.clear(); 
    pEdge edge;

  for(int i=0; i<size; i++){
    v1 = einfo[i]->v1; 
    v2 = einfo[i]->v2; 
    if (!v1||!v2||v1->getLevel()!=0||v2->getLevel()!=0)
      {
	cerr<<" Mesh->createE FAILED!\n";
	throw 1;
      }
    // assert(v1&& v2&& v1->getLevel()==0&& v2->getLevel()==0);
    edge =  mesh->createE_FP(mesh, (mVertex*)v1, (mVertex*)v2, einfo[i]->gent); 
    mlist.push_back(edge);
  }
  
  if(!mlist.empty())
     EN_addLocalMatchEnts(mlist);
}

void M_createMatchF (pMesh mesh, struct f_create_struct** finfo, int size, std::list<mEntity*>& mlist)
{
  mlist.clear(); 
 
    pFace face; 
  for(int i=0; i<size; i++){
    if(finfo[i]->nedge==3)
      face =  mesh->createTri_E_FP(mesh, (mEdge*)finfo[i]->edges[0],  (mEdge*)finfo[i]->edges[1], 
				   (mEdge*)finfo[i]->edges[2],  finfo[i]->gent, finfo[i]->dirs);
    else
      face =  (pFace)mesh->createQuad_E_FP(mesh,  (mEdge*)finfo[i]->edges[0], (mEdge*)finfo[i]->edges[1], 
					   (mEdge*)finfo[i]->edges[2],  (mEdge*)finfo[i]->edges[3], finfo[i]->gent, finfo[i]->dirs);
    mlist.push_back(face);  
}
  
    if(!mlist.empty())
         EN_addLocalMatchEnts(mlist);
}

void M_createMatchFV(pMesh mesh, struct fv_create_struct** fvinfo, int size , std::list<mEntity*>& mlist)
{
  mlist.clear();  
    pFace face;  
  for(int i=0; i<size; i++){
    if(fvinfo[i]->nvertex==3)
      face = (pFace)mesh->createTri_V_FP(mesh, (mVertex*)fvinfo[i]->vertices[0], (mVertex*)fvinfo[i]->vertices[1],
					  (mVertex*)fvinfo[i]->vertices[2], fvinfo[i]->gent, fvinfo[i]->dirs); 
    else
      face = (pFace)mesh->createQuad_V_FP(mesh, (mVertex*)fvinfo[i]->vertices[0],(mVertex*)fvinfo[i]->vertices[1],
					  (mVertex*)fvinfo[i]->vertices[2],(mVertex*)fvinfo[i]->vertices[3], fvinfo[i]->gent, fvinfo[i]->dirs);
     mlist.push_back(face); 
  }

  if(!mlist.empty())
      EN_addLocalMatchEnts(mlist);
}

#endif // #ifdef MATCHING

void M_remove(pMesh m, pRegion region, bool do_delete = true) 
{
  int dim = region->getLevel();  
  if(region->isAdjacencyCreated(dim-1))
    {
      for(int i=0;i<region->size(dim-1);i++)
	region->get(dim-1,i)->del(region);  
    }
  if (do_delete)m->DEL(region);
}

void M_removeRegion(pMesh m, pRegion r)
{
#ifndef FLEXDB
  M_remove(m,r);
#else
  m->deleteR_FP(m, r);
#endif
}

void M_removeFace(pMesh m, pFace face)
{
#ifndef FLEXDB
  M_remove(m,face);
#else
  m->deleteF_FP(m, face);
#endif
}

void M_removeEdge(pMesh m, pEdge edge)
{
#ifndef FLEXDB
  M_remove(m,edge);
#else
  m->deleteE_FP(m, edge);
#endif 
}

void M_removeVertex(pMesh m, pVertex vertex)
{
  m->DEL(vertex);
}

void M_removePoint(pMesh, pPoint point){}


void F_chDir(pFace pf) 
{
  if(pf->size(0) == 3) {
    // flip a triangle face
    mEdge* e0 = (mEdge*)pf->get(1,0);
    mEdge* e1 = (mEdge*)pf->get(1,1);
    mEdge* e2 = (mEdge*)pf->get(1,2);
    ((mFace*)pf)->setEdge(e0, 0);
    ((mFace*)pf)->setEdge(e2, 1);
    ((mFace*)pf)->setEdge(e1, 2); 
  }
  else if (pf->size(0) == 4) {
    // flip a quad face
    mEdge* e0 = (mEdge*)pf->get(1,0);
    mEdge* e1 = (mEdge*)pf->get(1,1);
    mEdge* e2 = (mEdge*)pf->get(1,2);
    mEdge* e3 = (mEdge*)pf->get(1,3);
   
    ((mFace*)pf)->setEdge(e0, 0);
    ((mFace*)pf)->setEdge(e3, 1);
    ((mFace*)pf)->setEdge(e2, 2);
    ((mFace*)pf)->setEdge(e1, 3);
   }
}

int EN_whatInType(pEntity e)
{
  /// do something here
  return GEN_type(e->getClassification()); 
}

int R_whatInType(pRegion e) { return EN_whatInType(e);}
int F_whatInType(pFace e){ return EN_whatInType(e);}
int E_whatInType(pEdge e){ return EN_whatInType(e);}
int V_whatInType(pVertex e){ return EN_whatInType(e);}


void EN_getMatchEnts(pEntity ent, pGEntity filter, std::list<std::pair<int, pEntity> >& mlist, int lid)
{
#ifdef MATCHING  
  mlist.clear(); 
  if(!ent->hasMatchEnt())
    return;

  // cout<<"match list of "<<EN_getUid(ent)<<":"; 

#ifdef FMDB_PARALLEL
  int mypid = ParUtil::Instance()->rank();
  int numPart = ParUtil::Instance()->getCurNumParts();
  int owner = ent->getOwner(); 
  int flag=0;

  if(filter==0 || (filter!=0 && ent->getClassification()==filter) )  
  {
    //only put the owner copy into the list
   if(ent->getPClassification()) {
     for (mEntity::RCIter rciter=ent->rcBegin(); rciter!=ent->rcEnd();++rciter) {
       if(rciter->first==owner) {
         flag=1; 
	 mlist.push_back(make_pair(rciter->first, rciter->second));

//	 cout<<"("<<rciter->first<<","<<rciter->second<<"), "; 
	 break; 
       }
      }
    }
   if(flag==0)
      mlist.push_back(make_pair(mypid*numPart+lid, ent));
    //  cout<<"("<<mypid*numPart+lid<<","<<ent<<"), ";
  }
#else
  int mypid = 0;
  int numPart = 1;

  if(filter==0 || (filter!=0 && ent->getClassification()==filter) )
    mlist.push_back(make_pair(mypid, ent));
#endif
  
  for(mEntity::MEIter meiter=ent->meBegin(); meiter!=ent->meEnd(); ++meiter) {
    if(filter==0) {
      mlist.push_back(make_pair(meiter->first, meiter->second));
  //    cout<<"("<<meiter->first<<","<<meiter->second<<"), ";
    }
    else
      if((meiter->first)/numPart==mypid)                    // on the same process
         if ((meiter->second)->getClassification()==filter) {
	    mlist.push_back(make_pair(meiter->first, meiter->second));
//	    cout<<"("<<meiter->first<<","<<meiter->second<<"), ";   
	 }
  }

  // cout<<endl; 
#endif  
}

int EN_isMatchEnt(pEntity ent)
{
#ifdef MATCHING
 if(ent->hasMatchEnt())
   return 1;
 else
   return 0; 
#else
  return 0; 
#endif // MATCHING
}

void EN_addMatchEnts(std::list<pair<int, mEntity*> > elist1, std::list<pair<int, mEntity*> > elist2)       
{
#ifdef MATCHING
  pEntity ent; 
  std::list<pair<int, mEntity*> >::iterator iter1, iter2; 

  for(iter1=elist1.begin(); iter1!=elist1.end(); iter1++) 
    for(iter2=elist2.begin(); iter2!=elist2.end(); iter2++) 
    {
      ent = iter1->second; 
      ent->addMatchEnt(iter2->first, iter2->second);
    }
#endif // MATCHING
}

void EN_addLocalMatchEnts(std::list<mEntity*> mlist, int lid)
{
#ifdef MATCHING
  int pid = 0; 

#ifdef FMDB_PARALLEL
  int mypid = ParUtil::Instance()->rank(); 
  int numPart = ParUtil::Instance()->getCurNumParts();
  pid = mypid*numPart + lid;   
#endif

  // build match connections 
  std::list<mEntity*>::iterator iter1, iter2; 
  pEntity ent; 
  for(iter1=mlist.begin(); iter1!=mlist.end(); iter1++)
    for(iter2=mlist.begin(); iter2!=mlist.end(); iter2++) {
      ent = *iter1;
      if(ent!=*iter2)
         ent->addMatchEnt(pid, *iter2);    
    }
#endif 
}

void EN_deleteMatchEnts(pEntity ent)
{
#ifdef MATCHING
 ent->clearMatchEnts();
#endif 
}


void EN_removeData(pEntity pe, const char *tag)
{
  unsigned int itag = MD_lookupMeshDataId(tag);
  pe->deleteData (itag);
}

void EN_deleteData(pEntity pe, pMeshDataId id)
{
  pe->deleteData (id);
}

int E_inClosure(pEdge pe, pEntity ent)
{
  // return R_inClosure(pe, ent);

  pPList f = FMDB_createAdjPList(pe,ent->getLevel());
  int in = PList_inList(f,ent);
  PList_delete(f);
  return in;

}

int R_dirUsingFace(pRegion pr, pFace face)
{
  return pr->getUse(face);
}

int F_dirUsingEdge(pFace pf, pEdge edge)
{
   return pf->getUse(edge);
}

void EN_modifyDataPtr(pEntity ent, pMeshDataId id, void * value)
{
  EN_attachDataPtr(ent, id, value);
}


pRegion M_nextRegion(pMesh, void **restart)
{
  throw 1;
}

int M_numClassifiedEntities(pMesh mesh, pGEntity ent, int dim)
{
  mPart::iter it = mesh->begin(dim);
  mPart::iter ite = mesh->end(dim);
  int k=0;
  while(it != ite)
    {
      //if((*it)->getClassification()) k++; 
      if((*it)->getClassification() == ent) k++;
      ++it;
    }
  return k;
}

int M_numClassifiedRegions(pMesh mesh, pGEntity ent)
{
  return M_numClassifiedEntities(mesh, ent, 3);
}
int M_numClassifiedFaces(pMesh mesh, pGEntity ent)
{
  return M_numClassifiedEntities(mesh, ent, 2);
}
int M_numClassifiedEdges(pMesh mesh, pGEntity ent)
{
  return M_numClassifiedEntities(mesh, ent, 1);
}
int M_numClassifiedVertices(pMesh mesh, pGEntity ent)
{
  return M_numClassifiedEntities(mesh, ent, 0);
}

void V_setSize(pVertex pe,double s)
{
  pe->attachDouble(FMDB_Util::Instance()->getSize(),s);
}

double V_size (pVertex pe)
{
  return pe->getAttachedDouble(FMDB_Util::Instance()->getSize());
}

static unsigned int markIdsFirst = 1000000000;

MarkID MD_registerMark(char *name, unsigned int size, unsigned int flags)
{
  return 1;
}

MarkID MD_markID(char *name)
{
  return 1;
}
unsigned int EN_mark(pEntity entity, MarkID id)
{
  return entity->getAttachedInt(markIdsFirst+id);  
}

void EN_setMark(pEntity entity, MarkID id, unsigned int value)
{
  entity->attachInt(markIdsFirst+id,value);  
}

void V_setPoint(pVertex v, pPoint pt)
{
  ((mVertex*)v)->move (((mVertex*)pt)->point());
}

int R_inClosure(pRegion pe, pEntity ent)
{
  //fakeList f (pr, ent->getLevel());
  //return  f.inlist (ent);
  
  pPList f = FMDB_createAdjPList(pe,ent->getLevel());
  int in = PList_inList(f,ent);
  PList_delete(f);
  return in;
}

int F_inClosure(pFace pe, pEntity ent)
{
  //return R_inClosure(f, ent);

  pPList f = FMDB_createAdjPList(pe,ent->getLevel());
  int in = PList_inList(f,ent);
  PList_delete(f);
  return in;

  
  //fakeList f1 (f, ent->getLevel());
  //return  f1.inlist (ent);
}

void V_merge2(pMesh pM, pVertex, pVertex)
{
  throw 1;
}
void V_merge(pVertex, pVertex)
{
  throw 1;
}

void E_merge2(pMesh pM, pEdge, pEdge)
{
  throw 1;
}
void E_merge(pEdge, pEdge)
{
  throw 1;
}
void F_merge2(pMesh pM, pFace, pFace)
{
  throw 1;
}
void F_merge(pFace, pFace)
{
  throw 1;
}

struct four_ints
{
  int v[4];
  four_ints () {};  
  four_ints (pEntity e)    
  {
    v[0] = v[1] = v[2] = v[3] = -1;
    for (int i=0;i<e->size(0);i++)
      {
	v[i] = e->get(0,i)->getId();
      }
    std::sort(v,v+4);
  }
  four_ints (pEntity e, pEntity pV, pEntity pV2)    
  {
    v[0] = v[1] = v[2] = v[3] = -1;
    for (int i=0;i<e->size(0);i++)
      {
	v[i] = (e->get(0,i) == pV)?pV2->getId():e->get(0,i)->getId();
      }
    std::sort(v,v+4);
  }
};

struct lessthan_four_ints
{
  bool operator () (const four_ints &v1, const four_ints &v2) const
  {
    if (v1.v[0] < v2.v[0])return true;
    if (v1.v[0] > v2.v[0])return false;
    if (v1.v[1] < v2.v[1])return true;
    if (v1.v[1] > v2.v[1])return false;
    if (v1.v[2] < v2.v[2])return true;
    if (v1.v[2] > v2.v[2])return false;
    if (v1.v[3] < v2.v[3])return true;
    return false;
  }
};

static pGEntity getClassif (std::map<four_ints,GEntity*, lessthan_four_ints> &cr,
			   pEntity e)
{
  std::map<four_ints,GEntity*, lessthan_four_ints>::iterator it = 
    cr.find(four_ints(e));
  if (it == cr.end())
    return e->getClassification();
  return it->second;
}

static void updateClassif (std::map<four_ints,GEntity*, lessthan_four_ints> &cr,
			       pEntity e, pEntity pV1 = 0 , pEntity pV2  = 0)
{
  four_ints xxx;

  if (pV1)
    xxx = four_ints (e,pV1,pV2);
  else
    xxx = four_ints (e);
    
  std::map<four_ints,GEntity*, lessthan_four_ints>::iterator it = 
    cr.find(xxx);
  if (it == cr.end())
    {
      cr[xxx] = e->getClassification();
    }
  else
    {
      pGEntity ge = (*it).second;
      if (GEN_type(ge) > GEN_type(e->getClassification()))
	cr[xxx] = e->getClassification();
    }
}

pPList E_faces(pEdge e) 
{
  return FMDB_createAdjPList (e, 2);
}

int M_findE(pMesh mesh, pEntity ent, int i)
{
  if (std::find(mesh->beginall(i), mesh->endall(i), ent)!= mesh->endall(i))
    return 1;
  return 0;    
}

#endif
