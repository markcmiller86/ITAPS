/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "oldFMDB.h"
#include "FMDBInternals.h"
#include "FMDB_cint.h"
#include "PList.h"

pEdge E_exist(pVertex v1, pVertex v2)
{
  /*
  pVertex   v1    ; vertex  1 (I)
  pVertex   v2    ; vertex  2 (I)
  */

  pEdge edge ;
  pVertex evert[2] ;
  int nedge=0,i ;

  if (v1 == v2) return((pEdge)0);

  nedge = V_numEdges(v1) ;

  if(nedge == 0) return((pEdge)0);
 
  for(i=0;i<nedge;i++)
  {
    edge = V_edge(v1, i);
    /* check if both vertices of this edge match the given vertices */
    evert[0] = E_vertex(edge, 0);
    if(v2 == evert[0]) return(edge) ;
    evert[1] = E_vertex(edge, 1);
    if(v2 == evert[1]) return(edge) ;
  } 

  /* if here, then no valid connection found */
  return((pEdge)0);
}

pFace F_exist(int type, pEntity e1, pEntity e2, pEntity e3, pEntity e4)
{
 pEntity ents[4] = {e1, e2, e3, e4} ;
 pFace face ;
 int count = 3, i;
 pPList entities, faces;
 void *tmp = 0;

 if (e4) 
   count = 4;


 /* if ents are vertices get the vertices of the face
 */

 const int Tedge = 1;
 const int Tvertex =0;

 if(type>Tedge)
   return((pFace)0);

 if( type == Tvertex )
 {
   faces = V_faces((pVertex) ents[0]);
   /* For each face connected to ents[0] see if the other vertices are 
      connected to the face
   */
   
   for (;(face = (pFace)PList_next(faces, &tmp));) 
   {
     entities = F_vertices(face, 1);
     if(PList_size(entities) == count) {
       for( i = 1; i < count; i++)
	 if (!PList_inList(entities, ents[i]))
	   break;
       if (i == count){
	 PList_delete(entities);
	 PList_delete(faces);/* Face is connected to all entities */
	 return face;
       }
     }
     PList_delete(entities);
   }
 }
 else if (type == Tedge)
 {
   faces = E_faces((pEdge) ents[0]);
   /* For each face connected to ents[0] see if the other edges are 
      connected to the face
   */
   
   for (;(face = (pFace)PList_next(faces, &tmp));) {
     entities = F_edges(face, 1, (pVertex) 0);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count) {
       PList_delete(faces);/* Face is connected to all entities */
       return face;
     }
   }
 }
 PList_delete(faces);

 return (pFace)0 ;
}

pRegion R_exist(int type, pEntity e1, pEntity e2, pEntity e3, 
                         pEntity e4, pEntity e5, pEntity e6)
{
 pEntity ents[6] ;
 pRegion region;
 
 int i, count;

 pPList entities, regions;
 void *tmp = 0;

 ents[0] = e1;
 ents[1] = e2;
 ents[2] = e3;
 ents[3] = e4;
 count = 4;
 
 if (e5) {
   ents[4] = e5;
   count = 5;
 } 
 if (e6) {
   ents[5] = e6;
   count = 6;
 } 

 /* if ents are vertices get the vertices of the face
 */
 int Tface = 2;
 int Tedge = 1;
 int Tvertex =0;

 if(type>Tface)
   return((pRegion)0);

 if( type == Tvertex )
 {
   regions = V_regions((pVertex) ents[0]);
   /* For each face connected to ents[0] see if the other vertices are 
      connected to the face
   */
   
   for (;(region = (pRegion)PList_next(regions, &tmp));) 
   {
     entities = R_vertices(region, 1);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count){
       PList_delete(regions);/* Face is connected to all entities */
       return region;
     }
   }
 }
 else if (type == Tedge)
 {
   regions = E_regions((pEdge) ents[0]);
   /* For each face connected to ents[0] see if the other edges are 
      connected to the face
   */
   
   for (;(region = (pRegion)PList_next(regions, &tmp));) {
     entities = R_edges(region, 1);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count) {
       PList_delete(regions);/* Face is connected to all entities */
       return region;
     }
   }
 }
 
 else if (type == Tface)
 {
   regions = F_regions((pFace) ents[0]);
   /* For each face connected to ents[0] see if the other edges are 
      connected to the face
   */
   
   for (;(region = (pRegion)PList_next(regions, &tmp));) {
     entities = R_faces(region, 1);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count) {
       PList_delete(regions);/* Face is connected to all entities */
       return region;
     }
   }
 } 

 PList_delete(regions);

 return (pFace)0 ;
}

