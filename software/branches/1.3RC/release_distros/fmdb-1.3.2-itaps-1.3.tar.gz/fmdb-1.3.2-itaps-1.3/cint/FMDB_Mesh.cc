/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifndef SIM
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "FMDBfwd.h"
#include "ParUtil.h"
#include "mParallelUtility.h"
#include "mEntity.h"
#include "mPart.h"
#include "mEdge.h"
#include "mVector.h"
#include "mPoint.h"
#include "mVertex.h"
#include "mException.h"
#include "mFMDB.h"
#include "mDebugUtil.h"
#include "GUM.h"
#ifdef FMDB_PARALLEL
#include "pmModel.h"
#include "pmModelUtil.h"
#include "pmMigrateUtil.h"
#include "pmMigrationCallbacks.h"
#include "pmZoltanCallbacks.h"
#endif
#ifdef DMUM
#include "mDmum.h"
#endif
#include "FMDB_EntGrp.h"

#include <iostream>
#include <list>
#include <vector>
#include <algorithm>
#include <iterator>
#include <string>

using std::cout;
using std::endl;
using std::vector;
using std::copy;
using std::string;
using std::list; 

#define MAX_NUM_PARTS_PER_PROCESS 1000

// **********************************
// General mesh Info
// **********************************
int M_getMaxVId(pMesh mesh)
{
#ifndef FMDB_PARALLEL
  return mesh->getIdGenerator().getMaxValue(); 
#else
  return P_getMaxInt(mesh->getIdGenerator().getMaxValue());  
#endif   
}

int M_pid()
{
  return P_pid();
}

int M_size()
{
  return P_size();
}

int PM_load (pMesh pm, const char *fName, bool fixedFName, int numGrp, int numProc)
{
#ifdef FMDB_PARALLEL
  // check file extension
  char ext[6];
  strcpy(ext,fName+(strlen(fName)-4));
  if(strcmp(ext,".sms"))
  {
    char text[256];
    sprintf(text,"FMDB cannot load partitioned %s",fName);
    throw mException (__LINE__,__FILE__,text);
  }
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_load - %s\n",fName);
  double t1 = ParUtil::Instance()->wTime();

  FMDB_Util::Instance()->loadPartitionedMesh(pm,fName, fixedFName, numGrp, numProc);

  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n", t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n");
#endif
  return SCUtil_SUCCESS;
}
 
int PM_write(pMesh pm, const char *fName)
{
   vector<pMesh> meshes; 
   meshes.push_back(pm);

   PM_write2(meshes, fName);
}
 
int PM_write2(vector<pMesh> pm, const char *fName)
{
#ifdef FMDB_PARALLEL
  // check file extension
  char ext[6];
  char filename[256];
  strcpy(ext,fName+(strlen(fName)-4));
  if(strcmp(ext,".sms"))
    sprintf(filename,"%s.sms",fName); 
  else
    sprintf(filename,"%s",fName);

  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_write - %s\n",filename);
  double t1 = ParUtil::Instance()->wTime();

  FMDB_Util::Instance()->writePartitionedMesh(pm,filename);

  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n", t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n");
#endif
  return SCUtil_SUCCESS;
}
  

void M_getCBEntities(pMesh mesh,int dim, std::vector<pEntity>& cbEntities)
{
#ifdef FMDB_PARALLEL
   pmModel::Instance()->getCBEntities(dim, cbEntities);
#endif
}

void M_getPOEntities(pMesh mesh, std::vector<pEntity>* poEntities)
{
  for (int i=0; i<3; ++i)
    for (mPart::iterall it=mesh->beginall(i); it!=mesh->endall(i); ++it)
    {
      if ((*it)->size(i+1)==0)
        poEntities[i].push_back(*it);
    }
  for (mPart::iterall it=mesh->beginall(3); it!=mesh->endall(3); ++it)
    poEntities[3].push_back(*it);
}

void M_boundingPids(std::vector<int>& bps)
{
#ifdef FMDB_PARALLEL
  pmModel* pmodel=pmModel::Instance();
  pmodel->update();
  std::copy(pmodel->bpBegin(), pmodel->bpEnd(),back_inserter(bps));
#endif
}


void M_print(pMesh pm)
{
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");	  
  pm->printAll();
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");	  
}


bool M_compare(pMesh mesh, pMesh mesh2)
{
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_compare");
  
  mEntity* ent;
  mEntity* ent2;
  pmEntity* pe;
  pmEntity* pe2;
  for (int i=0; i<=3;++i)
  {
  // compare the total number of entities
    assert(mesh->size(i)==mesh2->size(i));
    mPart::iterall it=mesh->beginall(i);
    mPart::iterall it2=mesh2->beginall(i);
    mPart::iterall itend=mesh->endall(i);
    mPart::iterall itend2=mesh2->endall(i);
    // compare entity by entity
    for (;it!=itend&&it2!=itend2;)
    {
      ent=*it;
      ent2=*it2;
      assert(ent->getId()==ent2->getId());
      assert(ent->getUid().compare(ent2->getUid())==0);
      assert(ent->getLevel()==ent2->getLevel());
      assert(ent->getOwner()==ent2->getOwner());
      assert(ent->getClassification()==ent2->getClassification());
#ifdef FMDB_PARALLEL
      assert(ent->getNumRemoteCopies()==ent2->getNumRemoteCopies());
#endif
      pe = ent->getPClassification();
      if (pe)
      {
        pe2=ent2->getPClassification();
	assert(pe2!=0);
	assert(pe->getId()==pe2->getId());
	assert(pe->getLevel()==pe2->getLevel());
	assert(pe->getOwner()==pe2->getOwner());
	assert(pe->getNumBPs()==pe2->getNumBPs());
      }
      ++it;
      ++it2;
    }    
  }
  double t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO," SUCCEED\n  ");
  ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
  return true;
}

bool M_verify(pMesh mesh)
{
#ifdef FMDB_PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
  double t1 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
  {
    printf("\n****************************\n");
    printf("    M_verify");
  }
  bool ret=verify_mesh(mesh);
#ifdef FMDB_PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
  double t2 = ParUtil::Instance()->wTime();
  if (ParUtil::Instance()->rank()==0)
  {
    if(ret) printf(" SUCCEED\n");
    else printf(" FAIL\n");
    printf("   (t = %f sec)\n",t2-t1);
    printf("****************************\n\n");
  }
  return ret;
}

void M_printNumEntities(pMesh mesh)
{
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_printNumEntities\n\n");
  mesh->printNumEntities();  
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n\n");	  
}

int PM_merge(pMesh mesh)
{
#ifdef FMDB_PARALLEL
  if (P_size()==1) return 0;
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    PM_merge - ");
  double t1 = ParUtil::Instance()->wTime();
#endif
  zoltanCB zlb;
  int ret = pmMerge(mesh,zlb);
#ifdef DEBUG
  double t2 = ParUtil::Instance()->wTime(); 
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
#else
  return 0;
#endif
}


#ifdef FMDB_PARALLEL
void PM_setMaxNumParts(int num)                 // for multiple parts per process
{
  if(num>=MAX_NUM_PARTS_PER_PROCESS)  
     num=MAX_NUM_PARTS_PER_PROCESS;
  ParUtil::Instance()->Msg(ParUtil::INFO,"    MaxNumParts=%d\n", num); 
  ParUtil::Instance()->setTgtNumParts(num); 
}

void M_loadbalance(pMesh  mesh,pmMigrationCallbacks &cb)
{
  if (P_size()==1) return;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_loadbalance\n");
  pmLoadBalance(mesh, cb);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
  return;
}


void M_loadbalance2(vector<pMesh>& meshes,pmMigrationCallbacks &cb)   
{
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_loadbalance\n");
  pmLoadBalance(meshes, cb);
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");
  return;
}

int M_partMigration(std::vector<pMesh>&meshes,                             // migrate a whole part
		     int source_pid,
		     int target_rank,
		     pmMigrationCallbacks &cb)
{
   pmPartMigration(meshes, source_pid, target_rank, cb);
}

int M_migration(pMesh mesh, int dimToMove, std::list<pEntity>& entList,
                pmMigrationCallbacks &cb,
                int dimToKnow1, std::vector<pEntity>& rmE1, std::vector<pEntity>& newE1,
		int dimToKnow2, std::vector<pEntity>& rmE2, std::vector<pEntity>& newE2,
                std::vector<pEntityGroup>& rmEG, std::vector<pEntityGroup>& newEG)
{
  if (P_size()==1) return 0;
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  if (dimToMove==1)
  {
    if (dimToKnow1 == 3)
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Realign\n");
    else if (dimToKnow1==1)      
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Swap\n");
  }
  else
  {
    if (dimToKnow2==-1)
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Coarsen\n");
    else 
      ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Snap\n");
  }
#endif
  std::list<pEntity> rmE[4];
  std::list<pEntity> newE[4];
  int ret=pmPartMigration(mesh, dimToMove,entList,cb,rmE,newE, rmEG, newEG);
  if (dimToKnow1>=0)
  {  
    std::copy(rmE[dimToKnow1].begin(), rmE[dimToKnow1].end(), 
              std::back_inserter(rmE1));
    std::copy(newE[dimToKnow1].begin(), newE[dimToKnow1].end(), 
              std::back_inserter(newE1));
  }

  if (dimToKnow2>=0)
  {  
    std::copy(rmE[dimToKnow2].begin(), rmE[dimToKnow2].end(), 
              std::back_inserter(rmE2));
    std::copy(newE[dimToKnow2].begin(), newE[dimToKnow2].end(), 
              std::back_inserter(newE2));
  }
  #ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
}


int M_migrationForSnap(pMesh mesh, pmMigrationCallbacks &cb,
		std::list<pEntity>& vtsOnCB, 
  	        std::list<std::pair<pEntity,pEntity> > &vtfcPairs,
                int dimToKnow1, std::vector<pEntity>& rmE1, std::vector<pEntity>& newE1,
                std::vector<pEntityGroup>& rmEG, std::vector<pEntityGroup>& newEG)
{
  if (P_size()==1) return 0;
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_migration_Snap\n");
#endif
  std::list<pEntity> rmE[4];
  std::list<pEntity> newE[4];
  int ret=pmPartMigration(mesh, cb, vtsOnCB, vtfcPairs,rmE,newE, rmEG, newEG);
  if (dimToKnow1>=0)
  {  
    std::copy(rmE[dimToKnow1].begin(), rmE[dimToKnow1].end(), 
              std::back_inserter(rmE1));
    std::copy(newE[dimToKnow1].begin(), newE[dimToKnow1].end(), 
              std::back_inserter(newE1));
  }
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#ifdef DEBUG
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
  return ret;
}
			   
#endif

void M_set_maxMeshDim(int dim)
{
#ifdef FMDB_PARALLEL
  ParUtil::Instance()->set_maxMeshDim(dim);
#endif
}

int M_maxMeshDim()
{
#ifdef FMDB_PARALLEL
  return ParUtil::Instance()->get_maxMeshDim();
#endif
}

int M_globalMaxDim(pMesh mesh)
{
  int dim = mesh->getDimension();
  int maxDim = P_getMaxInt(dim);
  return maxDim;
}

int M_globalMinDim(pMesh mesh)
{
  int dim = mesh->getDimension();
  int maxDim = P_getMinInt(dim);
  return maxDim;
}

void M_numEntitiesOwned(pMesh mesh, int dim, vector<int>& output)
{
#ifdef FMDB_PARALLEL
  unsigned int numPE = ParUtil::Instance()->size();
  output.resize(numPE);
  int *in = new int;
  int *out = new int[numPE];
 
  mEntity* ent;
  int numEnt=0;
  for (mPart::iterall it=mesh->beginall(dim);it!=mesh->endall(dim);++it)
  {
    ent = *it;
    if (ent->getOwner()==ParUtil::Instance()->rank())
      numEnt++;
  }

  *in = numEnt;
  MPI_Allgather(in, 1, MPI_INT, out, 1, MPI_INT, ParUtil::Instance()->getComm());
  for (int i = 0; i < numPE; i++)
    output[i] = out[i];

  delete in;
  delete [] out;
#else
  output.push_back(mesh->size(dim));
#endif
}

void M_updateOwnership(pMesh mesh)
{ 
#ifdef FMDB_PARALLEL
  if (M_NumPE()==1)
    return;
#ifdef _DEBUG
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n****************************\n");
  ParUtil::Instance()->Msg(ParUtil::INFO,"    M_updateOwnership...\n");
#endif

  pmModel::Instance()->updateOwnership();

#ifdef _DEBUG
  double t2 = ParUtil::Instance()->wTime();      
  ParUtil::Instance()->Msg(ParUtil::INFO,
          "      (t = %f sec)\n",t2-t1);
  ParUtil::Instance()->Msg(ParUtil::INFO,"****************************\n\n");	  
#endif
#endif
  return;
}

void DMUM_startMonitoring(pMesh mesh)
{ 
#ifdef DMUM
  mDMUM::Instance()->startMonitor((mPart*)mesh); 
  if (!P_pid()) system("rm mRep.dat");
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif  
}

void DMUM_stopMonitoring(pMesh mesh)
{
#ifdef DMUM
  mDMUM::Instance()->stopMonitor((mPart*)mesh); 
  mDMUM::Instance()->write(mesh, "mRep.dat");
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void DMUM_resumeMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->resumeMonitor((mPart*)mesh); 
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void DMUM_pauseMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->pauseMonitor((mPart*)mesh); 
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void DMUM_print(pMesh mesh)
{
#ifdef DMUM
  mDMUM::Instance()->print((mPart*)mesh); 
#else 
  if (!P_pid()) cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

bool DMUM_isOn(pMesh mesh)
{
#ifdef DMUM
  return (mPart*)mesh->DMUM_on; 
#else
  return false;
#endif
}

#endif   /* ifndef SIM */
