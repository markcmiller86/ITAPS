/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <string.h>
#include <vector>
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "FMDBfwd.h"
#include "ParUtil.h"
#include "mFMDB.h"
#include "mPart.h"
#include "oldFMDB.h"
#include "PList.h"
#ifdef FLEXDB
#include "mFlexDB.h"
#endif

#ifdef DMUM
#include "mDmum.h"
#endif

using std::cout;
using std::endl;
using std::cerr;
using std::vector;


int M_load_URR(pMesh mesh, const char *filename, const char* MRM_file)
{
  FILE *in = fopen (MRM_file,"r");
  if(!in)
  {
    cerr<<"MRM file \""<<MRM_file<<"\" is not available for read\n";
    throw 1;
  }  
  // STEP 1: convert MRM to int-MRM consting of -1(for 0), 0 (for -), 1 (for 1)  
  char str_mrm[256];
  int MRM[4][4];
  int i,j;
  for (i=0; i<4;++i)
    for (j=0; j<4;++j)
      {
      fscanf(in,"%s",str_mrm);
      if (!strcmp(str_mrm,"1"))
        MRM[i][j]=1;
      else if (!strcmp(str_mrm,"-"))
        MRM[i][j]=0;
      else if (!strcmp(str_mrm,"0"))	
        MRM[i][j]=-1;	
      }
  fclose(in);
  return M_load_MRM(mesh, filename, MRM);
}

#ifdef FLEXDB
int M_load(pMesh mesh, const char *filename) {
  int MRM[4][4] =  {{ 1, 1, -1, -1},
		    { 1,  1, 1, -1},
		    { -1, 1,  1, 1},
		    { -1, -1, 1, 1}};
  return M_load_MRM(mesh, filename, MRM);
}
#endif
int M_load_MRM(pMesh mesh, const char *filename, int MRM[4][4]) {
#ifdef FLEXDB
#ifdef DMUM
  bool wasOn=false;
  if (mesh->DMUM_on) 
  {
    wasOn=true;
    mesh->DMUM_on=false;
  }
#endif 
  double t1 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n********************\n  FMDB v0.1 with URR \n");  
  char ext[6];
  strcpy(ext,filename+(strlen(filename)-4));

  if(!strcmp(ext,".sms")) // M_load
  {
    loadSms_MRM(mesh,filename, MRM); 
    double t2 = ParUtil::Instance()->wTime();
    ParUtil::Instance()->Msg(ParUtil::INFO,"   (t = %f sec)\n", t2-t1);
    ParUtil::Instance()->Msg(ParUtil::INFO,"********************\n");  
  }
  else
  {
    cerr<<" M_load_MRM supports only .sms\n"; throw 1;
  }
#ifdef DMUM
  if (wasOn) mesh->DMUM_on=true;
#endif 
#else // no FLEXDB
  cout<<"Compile FMDB with FLEXDB=1\n";
#endif
  return 1;
}

void M_startMonitoring(pMesh mesh)
{ 
#ifdef DMUM
  mDMUM::Instance()->startMonitor((mPart*)mesh); 
  if (!P_pid()) system("rm _DMUM_.mrm");
  for (int i=0; i<4; ++i)
    mesh->count_trvs[i] = 0;
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif  
}

void M_stopMonitoring(pMesh mesh)
{
#ifdef DMUM
  mDMUM::Instance()->stopMonitor((mPart*)mesh); 
  mDMUM::Instance()->write_MRM(mesh, "_DMUM_.mrm");
  cout<<"\n*** Stat. of Mesh Usage ***\n\n";
  cout<<"   # M_VIter "<<mesh->count_trvs[0]<<endl;
  cout<<"   # M_EIter "<<mesh->count_trvs[1]<<endl;
  cout<<"   # M_FIter "<<mesh->count_trvs[2]<<endl;
  cout<<"   # M_RIter "<<mesh->count_trvs[3]<<endl;
  cout<<"\n***************************\n\n";  
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void M_resumeMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->resumeMonitor((mPart*)mesh); 
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void M_pauseMonitoring(pMesh mesh)
{  
#ifdef DMUM
  mDMUM::Instance()->pauseMonitor((mPart*)mesh); 
#else 
  if (!P_pid())   cout<<"FMDB ERROR: Compile FMDB with DMUM=1\n";
#endif
}

void M_printMRM(pMesh mesh)
{
#ifdef FLEXDB
  print_MRM((mPart*)mesh); 
#else
  cout<<"FMDB Info: FMDB is set to the fixed general representation\n";
#endif  
}

bool M_isDMUMon(pMesh mesh)
{
#ifdef DMUM
  return (mPart*)mesh->DMUM_on; 
#else
  return false;
#endif    
}

// Return 0: if stored
//  	  1: if local traversal needed
//	  2: if global traversal needed or unavailable
int M_adjacencyCost(pMesh mesh, int i_dim, int j_dim)
{
  if (i_dim == j_dim) return 2; 
#ifndef FLEXDB
  // one-level adj
  if (abs(i_dim-j_dim)==1) return 0;
  else return 1;
#else
  if (!(mesh->MRM[i_dim][i_dim]==1 && mesh->MRM[j_dim][j_dim]==1)) return 2;

  if (mesh->MRM[i_dim][j_dim]==1) // stored adj
    return 0;
 
  if (i_dim > j_dim) return 1;
  
    // check if local traversal works
  int rec;
  for (int DIM = i_dim+1; DIM<j_dim; DIM++)
  {
    if (mesh->MRM[i_dim][DIM]!=1) continue;
    rec = M_adjacencyCost(mesh, DIM, j_dim);
    if (rec<2) return 1;
  }
  return 2;
#endif  
}

void M_printAdjacencyCost(pMesh mesh)
{
  if (P_pid()!=0) return;
  
  int adjCost[4][4];
  for (int i=0; i<=3; i++)
    for (int j=0; j<=3; ++j)
    {
      adjCost[i][j] = M_adjacencyCost(mesh, i, j);
    }
  cout<<"\n*** Adjacency Cost Table ***\n"
      <<"    (0 stored, 1 local, - global or unavailable)\n";
  for (int i=0; i<=3; i++)
  {
    cout<<"[";
    for (int j=0; j<=3; ++j)
    {
      if (adjCost[i][j]<=1) cout<<adjCost[i][j];
      else cout<<"-";
      if (j==3) cout<<"]";
      else cout<<"  ";
    }
    cout<<"\n";
  }
}

void M_printAdjacency(pMesh mesh, int i, int j)
{
  if (M_adjacencyCost(mesh, i, j)==2)
  {
    cout<<"WARNING: adj "<<i<<"->"<<j<<" unavailable with the current MRM\n";
    return;
  }
    
  cout<<"\n*** PRINT Adjacency From "<<i<<"-dim To "
      <<j<<"-dim ***\n";
  double xyz[3];      
  for (mPart::iterall it=mesh->beginall(i); it!=mesh->endall(i); ++it)
  {
    if (i==0)
    {
      V_coord(*it, xyz);
      cout<<EN_getUidStr(*it)<<"["<<xyz[0]<<","<<xyz[1]<<","<<xyz[2]<<"] : ";
    }
    else
      cout<<EN_getUidStr(*it)<<" : ";
    pPList adjList = PList_new();
    switch (i)
    {
      case 0: {
               switch (j)
	       {
	         case 1: adjList = V_edges(*it); break;
		 case 2: adjList = V_faces(*it); break;
		 case 3: adjList = V_regions(*it); break;
	       }
             }
	     break;
      case 1: {
               switch (j)
	       {
	         case 0: PList_append(adjList,(void*)(*it)->get(0,0));
		 	PList_append(adjList,(void*)(*it)->get(0,1));
			break;
		 case 2: adjList = E_faces(*it); break;
		 case 3: adjList = E_regions(*it); break;
	       }
             }
	     break;
      case 2: {
               switch (j)
	       {
	         case 0: adjList = F_vertices(*it,1); break;
		 case 1: adjList = F_edges(*it,1,0); break;
		 case 3: adjList = F_regions(*it); break;
	       }
             }
	     break;      
      case 3: {
               switch (j)
	       {
	         case 0: adjList = R_vertices(*it,1); break;
		 case 1: adjList = R_edges(*it,1); break;
		 case 2: adjList = R_faces(*it,1); break;
	       }
             }
	     break;      
    }
    void* iter=0;
    pEntity ent;
    while ((ent = (mEntity*)PList_next(adjList,&iter)))
      cout<<EN_getUidStr(ent)<<"  ";
    cout<<endl;
    PList_delete(adjList);
   }
   cout<<endl;
}

