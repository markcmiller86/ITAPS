/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#include "mFMDB.h"
#include "FMDB_cint.h"
#include "FMDB_Internals.h"
#include "FMDBfwd.h"
#include "mEntity.h"
#include "mPart.h"
#include "mPoint.h"
#include "mVertex.h"
#include "PList.h"
#include "MeshEntTools.h"  //for handling dArray and XYZ_volume

#ifdef FMDB_PARALLEL
#include "pmZoltanCallbacks.h"
#endif

#include <iostream>
#include <list>
#include <vector>

using std::cout;
using std::endl;
using std::vector;
using std::cerr;

int EN_getWeight(pEntity pe, double* weight)
{
  return pe->getAttachedDouble(FMDB_Util::Instance()->getWeight(), weight);
}

void EN_setWeight(pEntity pe, double weight)
{
  pe->attachDouble(FMDB_Util::Instance()->getWeight(),weight);
}

std::string EN_getUidStr(pEntity ent)
{
  return ent->getUid();
}

int EN_owner(pEntity ent)
{
  return ent->getOwner();
}

void EN_print(pEntity ent)
{
  ent->print();
}


bool EN_duplicate(pEntity ent)
{
  bool ret = false;
  if (ent->getPClassification())
    ret = true;
//  cout<<"("<<ParUtil::Instance()->rank()<<") EN_multiple("<<ent->getUid()<<")="<<ret<<endl;
  return ret;
}

/*************************************
  Remote Copy operators
**************************************/

int EN_getNumCopies(pEntity ent)
{
#ifdef FMDB_PARALLEL
   return ent->getNumRemoteCopies(); 
#endif
}

pEntity EN_getCopy(pEntity ent,int pid)
{
#ifdef FMDB_PARALLEL
  return ent->getRemoteCopy(pid); 
#else
  return (pEntity)0;
#endif  
}

void EN_getCopies(pEntity ent,
                        std::vector<std::pair<pEntity,int> >& remoteCopies)
{
#ifdef FMDB_PARALLEL
 if( ent->getNumRemoteCopies()==0) {
     return;
   }
   for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
        remoteCopies.push_back(std::pair<mEntity*,int> 
                                (rciter->second,rciter->first));
#endif
}

void EN_addCopy(pEntity ent, int remotePid, pEntity remoteCopy)
{
#ifdef FMDB_PARALLEL
  ent->addRemoteCopy(remotePid,remoteCopy);
#endif
}

void EN_clearCopies(pEntity ent)
{
#ifdef FMDB_PARALLEL
  ent->clearRemoteCopies();
#endif
}

/*************************************
  Partition Classification operators
**************************************/
pmEntity* EN_getPClassification(pEntity ent)
{
  return ent->getPClassification();
}

void EN_setPClassification(pEntity ent, pmEntity* pe)
{
#ifdef FMDB_PARALLEL
  ent->setPClassification(pe);
#endif
}

double R_Volume(mEntity* tet) 
{
  if(tet->size(0) == 4) {
    double x[4];
    double y[4];
    double z[4];
    double xyz[3];
    for (int i=0; i<4; ++i)
   {
     V_coord((mVertex*)(tet->get(0,i)), xyz);
     x[i] =xyz[0];
	 y[i] = xyz[1];
     z[i] = xyz[2];
   }
   double a[] = { x[1]-x[0], y[1]-y[0], z[1]-z[0] } ;
   double b[] = { x[2]-x[0], y[2]-y[0], z[2]-z[0] } ;
   double c[] = { x[3]-x[0], y[3]-y[0], z[3]-z[0] } ;
   double normal[3] ;
   computeCrossProduct( a, b, normal ) ;
   return computeDotProduct( normal, c )/6.0;
   }
   else{
   cout<<"Volume other than tet not support now!"<<endl;
   return 1.0;
   }
   return 0.0;
}

// do NOT use any BL info. (can be used for a general mesh)
// copy from onkar's BLUtils.cc in meshAdapt, please note R_Volume(large V)
double R_Volume2(pRegion region) {

  int topoType = M_GetElementType(region);

  int numChildTets;
  int elemType;
  // fit two tets. in a pyramid
  // (diagonal edge of a pyramid is : V0-V2)
  // fit three tets. in a prism/wedge
  // (diagonal edges of a prism are : V0-V4, V1-V5 and V5-V0)
  //  int tetVerts[3][4] = {{0,1,2,5}, {0,1,5,4}, {0,4,5,3}};
  int mapNodes[3][3][4] ={{{0,1,2,3}, {-1,-1,-1,-1}, {-1,-1,-1,-1}},
                          {{0,1,2,4}, {0,2,3,4}, {-1,-1,-1,-1}},
			  {{0,1,2,5}, {0,1,5,4}, {0,4,5,3}}};

  switch(topoType) {
  case TET :
    numChildTets = 1;
    elemType = 0;
    break;
  case PYRAMID :
    numChildTets = 2;
    elemType = 1;
    break;
  case PRISM :
    numChildTets = 3;
    elemType = 2;
    break;
 //  case HEX :
//     numChildTets = 6; 
//     elemType = 3; 
//     break; 
  default:
    cout<<"\nError in R_volume2()..."<<endl;
    cout<<"region topology ["<<topoType<<"] NOT supported"<<endl;
    exit(0);
  }

  dArray *X_Y_Z;
  pPList rverts = R_vertices(region,1);
  int numRVerts = PList_size(rverts);
  X_Y_Z = new dArray[numRVerts];
  pVertex vtx;
  for(int iRVert=0; iRVert<numRVerts; iRVert++) {
    vtx = (pVertex)PList_item(rverts,iRVert);
    V_coord(vtx,X_Y_Z[iRVert]);
  }
  PList_delete(rverts);

  double volume = 0.;
  dArray sub_xyz[4];
  for(int iTet=0; iTet<numChildTets; iTet++) {
    for(int iTVert=0; iTVert<4; iTVert++)
      for(int iComp=0; iComp<3; iComp++)
	sub_xyz[iTVert][iComp] = X_Y_Z[mapNodes[elemType][iTet][iTVert]][iComp];

    volume += XYZ_volume(sub_xyz);
  }

  delete [] X_Y_Z;

  return volume;
}

void R_center(pEntity ent, double xyz[3])
{
  xyz[0] = 0.; xyz[1] = 0.; xyz[2] = 0.;
  SCOREC::Util::mPoint pp;
  void *iter = 0;
  pEntity vt;
  int i;
  pPList vtxs = R_vertices((pRegion)ent,1);
  while (vt = (pEntity)PList_next(vtxs,&iter))
  {
    pp = ((mVertex*)vt)->point();
    xyz[0] += pp(0);
    xyz[1] += pp(1);
    xyz[2] += pp(2);
  }
  PList_delete(vtxs);
  if (ent->getType()==mEntity::TET)
  {
    for(i=0; i<3; i++) xyz[i] /= 4.0;
  }
  else if (ent->getType()==mEntity::PYRAMID)
  {
    for(i=0; i<3; i++) xyz[i] /= 5.0;
  }
  else if (ent->getType()==mEntity::PRISM)   
  {
    for(i=0; i<3; i++) xyz[i] /= 6.0;
  }
  else if (ent->getType()==mEntity::HEX)
  {
    for(i=0; i<3; i++) xyz[i] /= 8.0;
  }
  else
  {
    cerr<<"Unknow Element Type\n"; 
  }
}

void F_center(pEntity ent, double xyz[3])
{
  xyz[0] = 0.; xyz[1] = 0.; xyz[2] = 0.;
  SCOREC::Util::mPoint pp;
  void *iter = 0;
  pEntity vt;
  int i;
  pPList vtxs = F_vertices((pFace)ent,1);
  while (vt = (pEntity)PList_next(vtxs,&iter))
  {
    pp = ((mVertex*)vt)->point();
    xyz[0] += pp(0);
    xyz[1] += pp(1);
    xyz[2] += pp(2);
  }
  PList_delete(vtxs);
  if (ent->getType()==mEntity::TRI)
  {
    for(i=0; i<3; i++) xyz[i] /= 3.0;
  }
  else if (ent->getType()==mEntity::QUAD)
  {
    for(i=0; i<3; i++) xyz[i] /= 4.0;
  }
  else // mEntity::PRISM or mEntity::HEX
  {
   cerr<<"Unknown Face Type\n";
  }
}

void E_center(pEntity ent, double xyz[3])
{

  SCOREC::Util::mPoint pp;
  pEntity vt;
  int i;
  for (i=0; i<2; ++i)
  {
    vt = ent->get(0,i);
    pp = ((mVertex*)vt)->point();
    xyz[0] += pp(0);
    xyz[1] += pp(1);
    xyz[2] += pp(2);
  }
   for(i=0; i<2; i++) xyz[i] /= 2.0;
}

#ifdef FMDB_PARALLEL
bool EN_deleteUserData(pEntity ent,int d)
{
  return deleteUserData(ent,d);
}
#endif

