/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifndef SIM

#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "FMDBfwd.h"
#include "ParUtil.h"
#include "mParallelUtility.h"
#include "mEntity.h"
#include "mPart.h"
#include "mEdge.h"
#include "mVector.h"
#include "mPoint.h"
#include "mVertex.h"
#include "pmModelUtil.h"
#include "pmMeshAdapt.h"
#ifdef FMDB_PARALLEL
#include "pmUtility.h"
#include "FMDB_ZoltanLoadBalancer.h"
#endif

#include <iostream>
#include <list>
#include <vector>

using std::cout;
using std::endl;
using std::vector;

// **********************************
// mesh loading
// **********************************


void M_setRepresentationFlag(mPart* mesh, int i)
{
  mesh->setRepresentationFlag(i);
}


int M_getMaxDim(pMesh mesh){
  int dim = mesh->getDimension();
  int maxDim = M_getMaxNum(dim);  
  return maxDim;
}
  
  int M_NumUniqueVertices(pMesh pmesh)
{
 return pmesh->numUniqueEntities(0);
}

int M_NumUniqueEdges(pMesh pmesh)
{
 return pmesh->numUniqueEntities(1);
}  

int M_NumUniqueFaces(pMesh pmesh)
{
 return pmesh->numUniqueEntities(2);
}  

int M_NumUniqueRegions(pMesh pmesh)
{
 return pmesh->numUniqueEntities(3);
}  

// **********************************
// common boundary entity
// **********************************


pEntity EN_getRemoteCopy(pMesh mesh,pEntity ent,int pid)
{
#ifdef FMDB_PARALLEL
  return ent->getRemoteCopy(pid); 
#else
  return (pEntity)0;
#endif  
}

void EN_getRemoteCopies(pMesh mesh,pEntity ent,
                        std::vector<std::pair<pEntity,int> >& remoteCopies)
{
#ifdef FMDB_PARALLEL
 if( ent->getNumRemoteCopies()==0) 
   return; 
 for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
  remoteCopies.push_back(std::pair<mEntity*,int> 
                                (rciter->second,rciter->first));
#endif
}

void EN_addRemoteCopy(pMesh mesh, pEntity ent, int remotePid, pEntity remoteCopy)
{
#ifdef FMDB_PARALLEL
  ent->addRemoteCopy(remotePid,remoteCopy);
#endif
}
  
void EN_deleteRemoteCopy(pMesh mesh, pEntity ent)
{
#ifdef FMDB_PARALLEL
  if (P_numPE()>1)
    ent->clearRemoteCopies();
#endif
}

pmEntity* EN_getCommonBdry(pEntity ent)
{
  return EN_getPClassification(ent);
}

void EN_setCommonBdry(pEntity ent, pmEntity* cb)
{
  EN_setPClassification(ent,cb);
}

// **********************************
// entity info
// **********************************
int EN_ownerProc(pEntity ent)
{
  return ent->getOwner();
}
  
bool EN_onPB(pMesh pmesh,pEntity ent)		// return true if the entity is on PB
{
#ifdef FMDB_PARALLEL
  if (M_numRemoteCopies(pmesh,ent) > 0)
    return true;
  else 
    return false;
#else
  return false;
#endif
}

bool EN_onCB(pEntity ent)		// return true if the entity is on PB
{
  return EN_duplicate(ent);
  
}

const char* EN_getUid(pEntity ent)	// return unique id
{
  return ent->getUid().data();
}

bool EN_canDeleteAttachedData(pEntity ent,int proc)
{
#ifdef FMDB_PARALLEL
  if (M_NumPE()==1)
    return false;
  else
    return canDeleteAttachedData(ent,proc);
#else
 return false;
#endif
}
// **********************************
// Mesh migration
// **********************************
void M_setEntityOwnership(pMesh pm)
{
#ifdef FMDB_PARALLEL
  if (M_NumPE()==1)
    return;

  M_updateOwnership(pm);
#endif
  return;
}

// **********************************
//general parallel util
// **********************************
void M_sync()		//synchronization
{
  P_barrier();
}

int M_Pid()
{
  return P_pid();
}

int M_NumPE()
{
  return P_size();
}

void P_sync()           //synchronization
{
  P_barrier();
}
 
int P_numPE()
{
  return P_size();
}
// Unify the information max and min through all processors
void M_unify(double* max, double* min)
{
#ifdef FMDB_PARALLEL
  double globalMin=*min, globalMax=*max;
  MPI_Allreduce(max,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  MPI_Allreduce(min,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  *max=globalMax;  *min=globalMin;
#endif
}

int M_getMaxNum(int num)
{
  if (M_NumPE()==1)
    return num;
#ifdef FMDB_PARALLEL
  int localMax = num;
  int globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

// **********************************
// debug functions
// **********************************

  
  bool M_PrintAdjacencyInfo(pMesh pm,int dim,int adjDim)
  {
   for (mPart::iterall it = pm->beginall(dim); it!=pm->endall(dim);++it)
   { 
      pEntity e = *it;
      int numAdjEnt = e->size(adjDim);     
      cout<<"("<<M_Pid()<<") M_Test: "<<e->getUid()<<": ";
      for (int i=0;i<numAdjEnt;++i)
      {  
        pEntity adjEnt = e->get(adjDim,i);
        if (!adjEnt) 
        { cout<<"ERROR! ";
          cout<<"("<<M_Pid()<<") "<<i<<"'th adjEnt is not accessible\n";
          return false;
        }
        else
          cout<<adjEnt->getUid()<<", "; 
      } 
      cout<<endl;
   }
   cout<<"("<<M_Pid()<<") M_TestAdjacency("<<dim<<","<<adjDim<<") DONE!\n"; 
   return true;
}

// this will print the mesh entity information 
void M_PrintEntityInfo(pEntity pe)
{
  pe->print();
}

// this will print all the mesh entities information including 
// 	- classification
// 	- common boundary

// Note this funtion cannot be called for test/pFMDB3/main.cc
void M_PrintNumEntitiesInfo(pMesh theMesh)
{
  theMesh->printNumEntities();
}  

#endif   /* ifndef SIM */
