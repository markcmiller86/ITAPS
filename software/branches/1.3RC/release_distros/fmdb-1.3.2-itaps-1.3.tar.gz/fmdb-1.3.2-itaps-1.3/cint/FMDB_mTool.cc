/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB_cint.h"
#include "oldFMDB.h"
#include "PList.h"
#include <vector>
#include "FMDB.h"

void computeCrossProduct( double a[], double b[], double n[] )
{
  n[0] = a[1]*b[2] - b[1]*a[2] ;
  n[1] = a[2]*b[0] - a[0]*b[2] ;
  n[2] = a[0]*b[1] - a[1]*b[0] ;
}

double computeDotProduct( double a[], double b[] )
{
  double sum = 0.0 ;
  for( int i = 0 ; i < 3 ; ++i ) 
    sum += a[i]*b[i] ;
  return sum ;
}

double computeSignedDistance( pVertex vertex, pFace face) 
{

    // first compure the normal to the face
    pPList vertexList = F_vertices( face, 1 ) ;
    double x[3], y[3], z[3], normal[3] ;

    for( int i = 0 ; i < 3 ; ++i ) {
        pVertex pv = ( pVertex ) PList_item( vertexList, i ) ;
        double xyz[3] ;
        V_coord( pv, xyz ) ;
        x[i] = xyz[0] ;
        y[i] = xyz[1] ;
        z[i] = xyz[2] ;
    }

    double a[] = { x[1]-x[0], y[1]-y[0], z[1]-z[0] } ;
    double b[] = { x[2]-x[0], y[2]-y[0], z[2]-z[0] } ;

    computeCrossProduct( a, b, normal ) ;

    double A = normal[0] ;
    double B = normal[1] ;
    double C = normal[2] ;
    double D = -( A*x[0] + B*y[0] + C*z[0] ) ;

    double XYZ[3];
    V_coord( vertex, XYZ ) ;

    PList_delete( vertexList ) ;

    return ( A*XYZ[0] + B*XYZ[1] + C*XYZ[2] + D ) ;
}

pVertex findVertexOppositeFace( pRegion region , pFace face ) 
{
    pVertex pv ;
    std::vector<pMeshEnt> adjVtx;
    FMDB_Ent_GetAdj (region, 0, 1, adjVtx);

    for( int i = 0 ; i < adjVtx.size() ; ++i ) {
        pVertex vertex =(pVertex) adjVtx.at(i) ;
        if( 0 == F_inClosure( face, (pEntity) vertex ) ) {
            pv = vertex ;
        }
    }
    return pv ;
}
