/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef SIM
#ifdef FMDB_PARALLEL
#include "FMDB_cint.h"
#include "pmMeshAdapt.h"
#include "pmTrellis.h"

#include <iostream>
#include <list>
#include <vector>

using std::cout;
using std::endl;
using std::vector;
using std::list; 


void M_unifyTaggedEntities(pMeshDataId tag, list<pEntity> *edges)
{
  if (P_size()==1) return;
    
  unifyTaggedEntities(tag, edges);
}

void M_unifyTaggedEntitiesWithValues(pMeshDataId tag, list<pEntity> *edges)
{
  if (P_size()==1) return;

  unifyTaggedEntitiesWithValues(tag, edges);
}


void M_attachUniqueId(pMesh mesh, pMeshDataId tag)
{
  if (P_size()==1) return;
    
  attachUniqueId(mesh,tag);
}

void M_update_CB_Links(list<pEntity> &ents_to_updt, pMeshDataId id)
{
  if (P_size()==1) return;
 
  update_CB_Links(ents_to_updt, id);
}

int M_deleteDimReduction(pMesh pm, pmMigrationCallbacks &cb, std::vector<mEntity*>* rmE)
{
  // declared in include/pmPartAdapt.h
  int ret=deleteDimReduction(pm,cb,rmE);  
  return ret;
}

#endif  /* FMDB_PARALLEL */
#endif   /* ifndef SIM */
