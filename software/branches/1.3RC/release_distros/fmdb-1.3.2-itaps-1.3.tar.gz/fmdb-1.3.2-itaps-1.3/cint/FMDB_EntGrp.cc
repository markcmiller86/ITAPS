/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef SIM
#include <iostream>
#include "oldFMDB.h"
#include "FMDBInternals.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mRegion.h"
#include "mPoint.h"
#include "mException.h"
#include "mAttachableDataContainer.h"
#include "mFMDB.h"
#include "mPart.h"
#include "LagrangeMapping.h"
#include "ParUtil.h"
#include "PList.h"
//#include "GEntity.h"
#include "mBuildAdj.h"
#include "modeler.h"

#include <stdio.h>
#include <assert.h>
#include <list>
#include "FMDB_cint.h"
#include "mFlexDB.h"

#include "FMDB_EntGrp.h"

pEntityGroup M_createEntGrp(pMesh mesh, int dim)
{
  pEntityGroup eg = mesh->createEntGrp(dim); 
  return eg; 
}

pEntityGroup M_createEntGrp(pMesh mesh, std::list<pEntity> ents, int dim)
{
   pEntityGroup eg = mesh->createEntGrp(ents, dim);
   return eg; 
}

void M_removeEntGrp(pMesh mesh, pEntityGroup eg)
{
   mesh->deleteEntGrp(eg, 1);                 // also delete the attached entity-group info on entities 
}

int M_numEntGrps(pMesh mesh)
{
  return mesh->numEntGrp(); 
}


  /*************************/
  /* EntityGroup Iter Ops  */
  /*************************/

  EGIter M_beginEntGrp(pMesh mesh)
  {
    return mesh->beginEntGrp();    
  }

  EGIter M_endEntGrp(pMesh mesh)
  {
    return mesh->endEntGrp(); 
  }

 /*************************/
  /* EntityGroup Operators */
  /*************************/

  void EG_clear(pEntityGroup eg)
  {
    eg->clear(); 
  }
  
  int EG_isEmpty(pEntityGroup eg)
  {
    return eg->isEmpty(); 
  }
  
  int EG_getNumOfEntities(pEntityGroup eg)
  {
    return eg->numEntity(); 
  }
  
  void EG_unionEntGrp(pEntityGroup, pEntityGroup){               // not implemented yet
  }
  
  void EG_substractEntGrp(pEntityGroup, std::list<pEntity>, pEntityGroup){   // not implemented yet
  }

  EntIter EG_beginEntity(pEntityGroup eg)
  { 
    return eg->begin(); 
  }

  EntIter EG_endEntity(pEntityGroup eg) 
  {
    return eg->end(); 
  }
  
  void EG_addEntity(pEntityGroup eg, pEntity ent)
  { 
    eg->addEntity(ent);
  }
  
  void EG_removeEntity(pEntityGroup eg, pEntity ent)
  {
    eg->removeEntity(ent);
  }
  
  int EN_isInEntGrp(pEntity ent, pEntityGroup& eg)
  {
    unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");

    void* tmp; 
    if(!EN_getDataPtr(ent, egTag, &tmp)) 
       return 0; 

    eg = (pEntityGroup)tmp; 
    return 1;   
  }
  
  void EN_getAdjPOs(pEntity, std::list<void*>) {
    // not implemented yet
  }

  /**************************/
  /* Attached Data Operators */
   /**************************/

     void EG_attachDataInt(pEntityGroup eg, pMeshDataId id, int data)
     {
       eg->attachInt(id,data); 
     }
     
     void EG_attachDataDbl(pEntityGroup eg, pMeshDataId id, double value)
     {
       eg->attachDouble(id,value);
     }
     
     void EG_attachDataPtr(pEntityGroup eg, pMeshDataId id, void * value)
     {
  mAttachableVoid *av = (mAttachableVoid *)eg->getData(id);
  if(!av)
    {
      av = new mAttachableVoid;
      eg->attachData(id,av);
    }
  else
    {
      //      delete av->veryNastyPointer;
    }
  av->veryNastyPointer = value;
     }
     
     void EG_deleteData(pEntityGroup eg, pMeshDataId id)
     {
       eg->deleteData(id); 
     }
     
     int EG_getDataInt(pEntityGroup eg, pMeshDataId id, int *value)
     {
  *value = eg->getAttachedInt(id);
  if(*value)return 1;
  return 0;
     }
  
     int EG_getDataDbl(pEntityGroup eg, pMeshDataId id, double *value)
     {
      return eg->getAttachedDouble(id, value);
     }

     int EG_getDataPtr(pEntityGroup eg, pMeshDataId id, void **value)
     {
  mAttachableVoid *av = (mAttachableVoid *)eg->getData(id);
  if(!av)return 0;
  *value =  av->veryNastyPointer;
  return 1;
     }
#endif 


