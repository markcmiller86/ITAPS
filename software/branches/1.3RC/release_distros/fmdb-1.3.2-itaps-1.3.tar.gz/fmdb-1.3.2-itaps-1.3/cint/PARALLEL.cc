/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifndef SIM
#include <algorithm>
#include <iostream>

#include "FMDB_cint.h"
#include "ParUtil.h"

#ifdef FMDB_PARALLEL
#include "pmUtility.h"
#include "pmModel.h"
#endif

using std::cout;
using std::endl;
using std::vector;

double P_getMaxDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  double localMax = num;
  double globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

double P_getMinDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  double localMin = num;
  double globalMin = num;
  MPI_Allreduce(&localMin,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  return globalMin;
#endif
}

double P_getSumDbl(double num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  double localSum = num;
  double globalSum = num;
  MPI_Allreduce(&localSum,&globalSum,1,MPI_DOUBLE,MPI_SUM,MPI_COMM_WORLD);
  return globalSum;
#endif
}

double P_wtime()
{return ParUtil::Instance()->wTime(); }

void P_unifyMinMax(double* max, double* min)
{
#ifdef FMDB_PARALLEL
  double globalMin=*min, globalMax=*max;
  MPI_Allreduce(max,&globalMax,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  MPI_Allreduce(min,&globalMin,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
  *max=globalMax;  *min=globalMin;
#endif
}

int P_getMaxInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  int localMax = num;
  int globalMax = num;
  MPI_Allreduce(&localMax,&globalMax,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
  return globalMax;
#endif
}

int P_getMinInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  int localMin = num;
  int globalMin = num;
  MPI_Allreduce(&localMin,&globalMin,1,MPI_INT,MPI_MIN,MPI_COMM_WORLD);
  return globalMin;
#endif
}

int P_getSumInt(int num)
{
  if (P_size()==1)
    return num;
#ifdef FMDB_PARALLEL
  int localSum = num;
  int globalSum = num;
  MPI_Allreduce(&localSum,&globalSum,1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
  return globalSum;
#endif
}


void P_barrier()           //synchronization
{
#ifdef FMDB_PARALLEL
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
#endif
}

int P_size()
{
#ifdef FMDB_PARALLEL
  return ParUtil::Instance()->size() ;
#else
  return 1;
#endif
}
 
int P_pid()
{
#ifdef FMDB_PARALLEL
  return ParUtil::Instance()->rank();
#else
  return 0;
#endif
}

#endif   /* ifndef SIM */
