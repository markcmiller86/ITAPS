/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iUtil.h"
#include "mAttachableDataContainer.h"
#include "mPart.h"
#include "mEntity.h"
#include <iostream>
#include <list>
#include <map>
#include <algorithm>

using namespace std;

ITAPS_Util * ITAPS_Util::instance = 0;

ITAPS_Util::ITAPS_Util() {}

ITAPS_Util::~ITAPS_Util() 
{
  map<mPart*, int*>::iterator it=allNTEs.begin();
  for (; it!=allNTEs.end();++it)
  {
    delete [] (*it).second;
    delete (*it).first;
  }
  allNTEs.clear();
}

ITAPS_Util* ITAPS_Util::Instance()
{
  if(!instance)
  {
    instance = new ITAPS_Util;
  }
  return instance;
}

void ITAPS_Util::computeNTE(mPart* mesh)
{
  int* NTE = new int[12];
  allNTEs.insert(map<mPart*, int*>::value_type(mesh,NTE));
  for (int i=0; i<12; i++) NTE[i] = 0;

  // count point
  mPart::iterall it; 

  NTE[0] = mesh->size(0); 
  NTE[1] = mesh->size(1); 

  // count 2D
  for (it=mesh->beginall(2); it!=mesh->endall(2); it++)
   {
     switch((*it)->size(0))
     {
       case 3: NTE[3] += 1;	// Triangle;
	      break;
       case 4: NTE[4] += 1;	// Quadrilateral;
	      break;
       default: NTE[2] += 1;	// Polygon;
              break;
     }
   }
     
   for (it=mesh->beginall(3); it!=mesh->endall(3); it++)
   {
     if ((*it)->size(0) == 4 && (*it)->size(2) == 4) 
       NTE[6] += 1;	// Tetrahedron;
     else if ((*it)->size(0) == 8 && (*it)->size(2) == 6) 
       NTE[7] += 1;	// Hexahedron;
     else if ((*it)->size(0) == 6 && (*it)->size(2) == 5) 
       NTE[8] += 1;	// Prism;
     else if ((*it)->size(0) == 5 && (*it)->size(2) == 5) 
       NTE[9] += 1;	// Pyramid;       
     else if ((*it)->size(0) > 8)                  
       NTE[5] += 1;	// Polyhedron;
   }
}

int ITAPS_Util::getNTE(mPart* mesh, int topo)   
{
  std::map <mPart*, int*>::iterator mapit = allNTEs.find(mesh);
  if (mapit==allNTEs.end())
  {
    int* NTE = new int[12];
    allNTEs.insert(map<mPart*, int*>::value_type(mesh,NTE));
    for (int i=0; i<12; i++) NTE[i] = 0;
  }
  else {
    if (allNTEs[mesh][0] != mesh->size(0) ||  
        allNTEs[mesh][1] != mesh->size(1) ||  
        (allNTEs[mesh][2] + allNTEs[mesh][3] + allNTEs[mesh][4])!= mesh->size(2) ||  
        (allNTEs[mesh][5] + allNTEs[mesh][6] + allNTEs[mesh][7] + allNTEs[mesh][8] + allNTEs[mesh][9] + allNTEs[mesh][10]) != mesh->size(3)) 
    { // only consider vertex change, hack 
      //cout << "\n Vertex " << allNTEs[mesh][0] << " : " << mesh->size(0) << " Edges " << allNTEs[mesh][1] << endl;
      //cout << "\n Faces " << allNTEs[mesh][3] << " : " << mesh->size(2)<< " Regions " << allNTEs[mesh][3] << " : " << mesh->size(3) << endl;
      delete[] allNTEs[mesh]; 
      computeNTE(mesh);       
    }
    return allNTEs[mesh][topo];
  }
}

void ITAPS_Util::increaseNTE(mPart* mesh, int topo)
{
  std::map <mPart*, int*>::iterator mapit = allNTEs.find(mesh);
  if (mapit==allNTEs.end())
  {
    int* NTE = new int[12];
    allNTEs.insert(map<mPart*, int*>::value_type(mesh,NTE));
    for (int i=0; i<12; i++) NTE[i] = 0;
  }
  allNTEs[mesh][topo] += 1;
}

void ITAPS_Util::decreaseNTE(mPart* mesh, int topo)
{
  allNTEs[mesh][topo] -= 1;
}

void ITAPS_Util::displayNTE(mPart* mesh)
{
  cout<<"\n*** ITAPS_Util::displayNTE ***\n";
  cout<<"# point : "<<allNTEs[mesh][0]<<endl;
  cout<<"# line : "<<allNTEs[mesh][1]<<endl;
  cout<<"# polygon : "<<allNTEs[mesh][2]<<endl;
  cout<<"# tri : "<<allNTEs[mesh][3]<<endl;
  cout<<"# quad : "<<allNTEs[mesh][4]<<endl;
  cout<<"# polyhedron : "<<allNTEs[mesh][5]<<endl;
  cout<<"# tet : "<<allNTEs[mesh][6]<<endl;
  cout<<"# hexa : "<<allNTEs[mesh][7]<<endl;
  cout<<"# prism : "<<allNTEs[mesh][8]<<endl;
  cout<<"# pyramid : "<<allNTEs[mesh][9]<<endl;
  cout<<"# septahedron : "<<allNTEs[mesh][10]<<endl;
}

// VALID TYPE+TOPO
// VERTEX: POINT, ALL_TOPOLOGIES
// EDGE: LINE_SEGMENT, ALL_TOPOLOGIES
// FACE: TRIANGLE, QUADRILATERAL, POLYGON, ALL_TOPOLOGIES
// REGION: TETRAHEDRON, ..., ALL_TOPOLOGIES
// ALL_TYPES: POINT, ..., ALL_TOPOLOGIES

bool checkTypeTopo(int requested_entity_type, 
                             int requested_entity_topology)
{
  switch (requested_entity_type)
  {
    // VERTEX
    case 0: if (requested_entity_topology == (int)(mEntity::POINT) || 
               requested_entity_topology == (int)(mEntity::ALL_TOPOLOGIES))
             return true;
	   else break;    
    // EDGE
    case 1: if (requested_entity_topology == (int)(mEntity::LINE_SEGMENT) || 
               requested_entity_topology == (int)(mEntity::ALL_TOPOLOGIES))
             return true;
	   else break;
    // FACE
    case 2: if (requested_entity_topology == (int)(mEntity::TRIANGLE) || 
               requested_entity_topology == (int)(mEntity::QUADRILATERAL) ||
	       requested_entity_topology == (int)(mEntity::POLYGON) ||
               requested_entity_topology == (int)(mEntity::ALL_TOPOLOGIES))
             return true;
	   else break;
    // REGION
    case 3: if (requested_entity_topology == (int)(mEntity::TETRAHEDRON) || 
               requested_entity_topology == (int)(mEntity::PYRAMID_) ||
	       requested_entity_topology == (int)(mEntity::PRISM_) ||
	       requested_entity_topology == (int)(mEntity::HEXAHEDRON) ||
	       requested_entity_topology == (int)(mEntity::SEPTAHEDRON) ||
	       requested_entity_topology == (int)(mEntity::POLYHEDRON) ||
               requested_entity_topology == (int)(mEntity::ALL_TOPOLOGIES))
             return true;
	   else break;
    // ALL_TYPES
    default: if (0<=requested_entity_topology<=11) 
             return true;
	   else break;
    
  }
  return false;
}

