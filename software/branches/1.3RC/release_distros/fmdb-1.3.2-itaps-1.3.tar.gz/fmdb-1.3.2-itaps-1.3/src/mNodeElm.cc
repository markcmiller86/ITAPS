/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include "FMDB_Internals.h"
#include "oldFMDB.h"
#include "mPart.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mRegion.h"
#include "mException.h"
#include "mFMDB.h"
#include "mNodeElm.h"
#ifdef FLEXDB
#include "mFlexDB.h"
#endif

using std::cout;
using std::ofstream;
using std::ostream;
using std::istream;
using std::endl;
using std::vector;

  int inputNodeElm::Pmev[9][2] =  {{0,1},{1,2},{2,0},{0,3},{1,4},{2,5},
				   {3,4},{4,5},{5,3}}; 
  int inputNodeElm::Pmfe[5][4] =   {{0,1,2,-1},
				    {0,4,6,3},
				    {1,4,7,5},
				    {2,3,8,5},
				    {6,7,8,-1}};

  int inputNodeElm::Tev[6][2] =  {{0,1},{1,2},{2,0},{0,3},{1,3},{2,3}}; 
  int inputNodeElm::Tfe[4][3] =   {{0,1,2},
				   {0,4,3},
				   {1,5,4},
				   {2,5,3}};
				
  mType inputNodeElm::PmfType[5] = {TRI, QUAD, QUAD, QUAD, TRI};

  inputNodeElm::inputNodeElm (pMesh mesh, int dimension, int MRM[4][4], bool comp)
    : theMesh(mesh), complete(comp) 
  {
#ifdef FLEXDB
  if(MRM) {
    switch(dimension) {
    case 2: {
      set_MRM_2D(mesh, MRM);
      break;
    }
    case 3: {
      set_MRM_3D(mesh, MRM);
      break;
    }
    default:
      throw new mException (__LINE__,__FILE__,"bad dimension for setting MRM");
    }
  }
#endif
}
 
pEntity inputNodeElm::addElement(pEntity *nodes, int mDim,
				   mType entType, mType bdEntType, pGEntity gent) 
{
				   
 pEntity ent;
 
 switch(mDim) {
    case 1: {
      ent = addEdge((pVertex)nodes[0], (pVertex)nodes[1], gent);
      break;
    }
    case 2: {
	  ent = addFace(nodes, entType, bdEntType, gent);
      break;
    }
	case 3: {
	 ent = addRegion(nodes, entType, bdEntType, gent);
      break;
    }
    default: {
      cout << "Unknown mesh dimension\n";
      throw 1;
    }
    }
    return ent;
}

  pEdge inputNodeElm::addEdge(pVertex v0, pVertex v1, pGEntity gent) {
  pEdge e = E_exist(v0, v1);
  if(!e) 
    e = M_createE(theMesh, v0, v1, gent);
  return e;
}

pFace inputNodeElm::addFace(pEntity *ent, mType entType, mType bdEntType, 
			    pGEntity gent) 
{
  pFace f;
    
  if(bdEntType == VERTEX) {
    if(entType == TRI) {
      f = F_exist(0, ent[0], ent[1], ent[2], 0); 
      if(!f) {
        pEdge edges[3];
        edges[0] = addEdge(ent[0], ent[1], gent);
        edges[1] = addEdge(ent[1], ent[2], gent);
        edges[2] = addEdge(ent[2], ent[0], gent);
        f = M_createF(theMesh, 3, edges, 0, gent);
      }
    }
   else if(entType == QUAD) {
     f = F_exist(0,  ent[0], ent[1], ent[2], ent[3]);
     if(!f) {
      pEdge edges[4];
      edges[0] = addEdge(ent[0], ent[1], gent);
      edges[1] = addEdge(ent[1], ent[2], gent);
      edges[2] = addEdge(ent[2], ent[3], gent);
      edges[3] = addEdge(ent[3], ent[0], gent);
      f = M_createF(theMesh, 4, edges, 0, gent);
    }
   }
  }
  else if(bdEntType == EDGE) {
   if(entType == TRI){
      f = F_exist(1, ent[0], ent[1], ent[2], 0); 
      if(!f) {
	  f = M_createF(theMesh, 3, ent, 0, gent);
      }
    }
   else if(entType == QUAD) {
     f = F_exist(1,  ent[0], ent[1], ent[2], ent[3]);
     if(!f) {
      f = M_createF(theMesh, 4, ent, 0, gent);
    }
  }
 }
  return f;
}

pRegion inputNodeElm::addRegion(pEntity *ent, mType entType, mType bdEntType, 
				pGEntity gent) {
  //nodenumbers must be in canonical ordering...
  // may need to check on ordering of vertices of faces adjacent to the region
  pRegion r;
  pEntity fve[4], edges[12];
  pFace faces[6];
  int numFaces;
  
  switch(entType) {
   case PRISM:
     {
       switch(bdEntType) {
       case VERTEX:
	 {
	   if(!complete) {
	     int dirs[20];
	     r = M_createRV(theMesh, 6, ent, dirs, gent);
	     return r;
	   }

	   // create faces based on vertices;
	   // create edge first
	   for(int i=0; i<9; i++) {
	     edges[i] = addEdge(ent[Pmev[i][0]], ent[Pmev[i][1]], gent);
	   }
		   
	   // create the face based on the edges 
	   for(int i=0; i<5; i++) {
	     for(int j=0; j<4; j++) {
	       if(Pmfe[i][j] != -1)
		 fve[j] = edges[Pmfe[i][j]];
	     }
	     faces[i] = addFace(fve, PmfType[i], EDGE, gent); 
	   }
	   break;
	 }	 
	 
       case EDGE:
	 {
	   // create faces based on edges
		  for(int i=0; i<5; i++) {
		    for(int j=0; j<4; j++) {
		      if(Pmfe[i][j] != -1)
			fve[j] = ent[Pmfe[i][j]];
		    }
		    faces[i] = addFace(fve, PmfType[i], bdEntType, gent);
		  }
		  break;
	 }
       default:
	 {
	   for(int i=0; i<5; i++)
	     faces[i] = ent[i];
	 }
       }
       numFaces = 5;
       
       break;
     }
     
  case TET:
    {
      switch(bdEntType) {
      case VERTEX:
	{
	  // create faces based on vertices;
	  // create edge first
	  for(int i=0; i<6; i++) {
	    edges[i] = addEdge(ent[Tev[i][0]], ent[Tev[i][1]], gent);
	  }
	  
	   // create the face based on the edges 
	  for(int i=0; i<4; i++) {
	    for(int j=0; j<3; j++) 
	      fve[j] = edges[Tfe[i][j]];
	    
	    faces[i] = addFace(fve, TRI, EDGE, gent); 
	  }
	  break;
	 }	 
	 
       case EDGE:
	 {
	   // create faces based on edges
	   for(int i=0; i<4; i++) {
	     for(int j=0; j<3; j++) 
	       fve[j] = ent[Tfe[i][j]];
	     faces[i] = addFace(fve, TRI, EDGE, gent);
	   }
	   break;
	 }
       default:
	 {
	   for(int i=0; i<4; i++)
	     faces[i] = ent[i];
	 }
       }
       numFaces = 4;
       
       break;
      
    }
 }
   
  r = M_createR(theMesh, numFaces,faces , 0, gent);
  
  return r;
}
