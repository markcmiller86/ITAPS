/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <assert.h>
#include <stdio.h>
#include <iostream>
#include "mEntity.h"
#include "mException.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mEntityContainer.h"
#include "mFMDB.h"
#include "mCommonBdry.h"
#ifdef FMDB_PARALLEL
#include "ParUtil.h"
#endif

#include "modeler.h"

#include <stdlib.h>  
#include <math.h> 
#include <algorithm> 
#include <vector> 
#include <string> 
#include <map>

using std::cout;
using std::endl;
using std::sort;
using std::set;
using std::list;
using std::string;
using std::vector;
using std::multimap; 

#ifdef _POINTER2INT_
   pGModel mEntity::theSolidModel; 
#endif

  // create an empty entity
  mEntity::mEntity()
#ifndef _POINTER2INT_
  : theClassification((pGEntity)0)
#else
  : gType(0), gTag(0)
#endif
/////   ,theCommonBdry((mCommonBdry*)0),iD(0)
  {
#ifdef FMDB_PARALLEL
    thePClassification = (pmEntity*)0;
    theRemoteCopies = NULL;
    tempBPs = NULL;
    tempGPs = NULL;
    iIsGhost = -1;
    theGhostCopies = NULL;
#endif
#ifdef MATCHING
   theMatchEnts = NULL; 
#endif
//////    for(int i=0;i<4;i++)theAdjacencies[i] = (mAdjacencyContainer*)0;
  }
  // destructor
  mEntity::~mEntity()
  {
#ifdef FMDB_PARALLEL
   setPClassification(0);

   if(theRemoteCopies!= NULL) {
     SAFE_DELETE(theRemoteCopies);
   }
    if(tempBPs!= NULL) {
         SAFE_DELETE(tempBPs);
    }
#endif
#ifdef MATCHING
    if (theMatchEnts!=NULL)
      SAFE_DELETE(theMatchEnts); 
#endif
  }

  double mEntity::gSize ()
  {
    double lmin;
    //  std::cout << e->size(1) << " edges\n";

    if(getType() == TRI)
      {
	SCOREC::Util::mPoint p0 = ((mVertex*)get(0,0))->point();
	SCOREC::Util::mPoint p1 = ((mVertex*)get(0,1))->point();
	SCOREC::Util::mPoint p2 = ((mVertex*)get(0,2))->point();
	SCOREC::Util::mVector v1(p0-p1);
	SCOREC::Util::mVector v2(p0-p2);
	SCOREC::Util::mVector v3(p1-p2);
	
	SCOREC::Util::mVector v1xv2 = v1 % v2;

	double semi_perimeter = 0.5 * (v1.normValue() + v2.normValue() + v3.normValue());
	double area = v1xv2.normValue();

	return area / semi_perimeter;
	
      }

    if(getType() == TET)
      {
	SCOREC::Util::mPoint p0 = ((mVertex*)get(0,0))->point();
	SCOREC::Util::mPoint p1 = ((mVertex*)get(0,1))->point();
	SCOREC::Util::mPoint p2 = ((mVertex*)get(0,2))->point();
	SCOREC::Util::mPoint p3 = ((mVertex*)get(0,3))->point();
	SCOREC::Util::mVector v1(p0-p1);
	SCOREC::Util::mVector v2(p0-p2);
	SCOREC::Util::mVector v3(p0-p3);
	SCOREC::Util::mVector v4(p2-p1);
	SCOREC::Util::mVector v5(p3-p1);
	SCOREC::Util::mVector v1v2 = v1 % v2;
	SCOREC::Util::mVector v1v3 = v1 % v3;
	SCOREC::Util::mVector v2v3 = v2 % v3;
	SCOREC::Util::mVector v4v5 = v4 % v5;
	double V = v1v2 * v3;
	double A1 = sqrt (v1v2 * v1v2);
	double A2 = sqrt (v1v3 * v1v3);
	double A3 = sqrt (v2v3 * v2v3);
	double A4 = sqrt (v4v5 * v4v5);
	return fabs(V) / (A1+A2+A3+A4);
      }

    for(int i=0;i<size(1);i++)
      {
	SCOREC::Util::mPoint p1 = ((mEdge*)get(1,i))->vertex(0)->point();
	SCOREC::Util::mPoint p2 = ((mEdge*)get(1,i))->vertex(1)->point();
	SCOREC::Util::mVector v(p1-p2);
	double l = sqrt (v(0)*v(0) + v(1)*v(1) + v(2)*v(2));
	//      std :: cout << "edge " << i << " length " << l << "\n";
	if(!i)lmin = l;
	else lmin = (l<lmin)?l:lmin;
      }
    return lmin;
  }

// end of gEntity functions
//*****************************************

  int mEntity::getNbTemplates(int what) const
  {
    throw new mException (__LINE__,__FILE__,"no template in mEntity base class");
  }

  mEntity* mEntity::getTemplate(int,int,int)const 
  {
    throw new mException (__LINE__,__FILE__,"no template in mEntity base class");
  }

  void mEntity::classify(pGEntity g)
  {
#ifndef _POINTER2INT_
    theClassification = g;
#else
    gType = (short int)GEN_type(g);
    gTag = (short int)GEN_tag(g);
#endif
  }

  pGEntity mEntity::getClassification() const
  {
#ifndef _POINTER2INT_
    return theClassification;
#else
    return GM_entityByTag(mEntity::theSolidModel, gType, gTag); 
#endif
  }

/*
  mCommonBdry* mEntity::getCommonBdry() const
  {
    return theCommonBdry;
  }
*/

/*
  void mEntity::deleteAdjacencies(int what)
  {
    if(theAdjacencies[what])
      {
	delete theAdjacencies[what];
	theAdjacencies[what] = (mAdjacencyContainer*)0;
      }
  }

  mAdjacencyContainer::iter mEntity::begin(int what)
  {
    if(!theAdjacencies[what])throw new mException (__LINE__,__FILE__, "Adjacencies Not Created");
    return theAdjacencies[what]->begin();
  }

  mAdjacencyContainer::iter mEntity::end(int what)
  {
    if(!theAdjacencies[what])throw new mException (__LINE__,__FILE__, "Adjacencies Not Created");
    return theAdjacencies[what]->end();
  }
*/

  // are two mesh entities equal ?
  bool mEntity::equal (mEntity *other) const
  {
    if(this == other)return true;
    if(getId() != other->getId())return false;
    int dim = getLevel();
    if(dim != other->getLevel())return false;
    if(dim == 0)return getId() == other->getId();
  
    if(dim == 1)
      {
	int v11 = get(0,0)->getId();
	int v12 = get(0,1)->getId();
	int v21 = other->get(0,0)->getId();
	int v22 = other->get(0,1)->getId();
	if(v11 == v21 && v12 == v22)return true;
	if(v11 == v22 && v12 == v21)return true;
	return false;
      }
  
    int v1[100],v2[100];
    int s1 = size(0);
    int s2 = other->size(0);
    if(s1 != s2)return false;
    int i;
    for(i=0;i<s1;i++)
      {
	v1[i]=get(0,i)->getId();
	v2[i]=other->get(0,i)->getId();
      }
    sort(v1,v1+s1);
    sort(v2,v2+s2);
    for(i=0 ; i<s1 ;i++)
      {
	if(v1[i] != v2[i])return false;
      }
    return true;
  }

  // compare two entities
  bool mEntity::lessthan (mEntity *other) const
  {
    /* first do some fast checks**/
    int dim = getLevel();
    int other_dim = other->getLevel();
    if(dim != other_dim)return dim < other_dim;
    int id = getId();
    int other_id =  other->getId();
    if(dim == 0)return id < other_id;
    if(id < other_id)return true;
    if(id > other_id)return false;
  
    /*then do the whole comparison on vertices*/
    std::vector<mVertex*> thisVertices;
    std::vector<mVertex*> otherVertices;
    {  for(int i=0;i<getNbTemplates(0);i++)thisVertices.push_back((mVertex*)get(0,i));}
    {  for(int i=0;i<other->getNbTemplates(0);i++)otherVertices.push_back((mVertex*)other->get(0,i));}
    if(thisVertices.size() < otherVertices.size())return true;
    if(thisVertices.size() > otherVertices.size())return false;
    std::sort(thisVertices.begin(),thisVertices.end());
    std::sort(otherVertices.begin(),otherVertices.end());
    for( int i=0;i<thisVertices.size();i++)
      {      
	int id1 = thisVertices[i]->getId();
	int id2 = otherVertices[i]->getId();
	if(id1 < id2)return true;
	if(id1 > id2)return false;
      } 

    return false;
  }


  void mEntity::print() const
  {
  }

  void recur_get_leaves(mEntity * e, list<mEntity*> &leaves, int n)
  {
    for(int i=0;i<e->size(n);i++)
      {
	mEntity *sub = e->get(n,i);
	if(sub->isAdjacencyCreated(n))recur_get_leaves(sub,leaves,n);
	else leaves.push_back(sub);
      }
  }

  void mEntity::getLeaves(list<mEntity*> &leaves)
  {
    int n = getLevel();
    if (isAdjacencyCreated(n))recur_get_leaves(this,leaves,n);
    else leaves.push_back(this);
  }

  void recur_get_all(mEntity * e, list<mEntity*> &leaves, int n)
  {
    for(int i=0;i<e->size(n);i++)
      {
	mEntity *sub = e->get(n,i);
	leaves.push_back(sub);
	if(sub->isAdjacencyCreated(n))recur_get_all(sub,leaves,n);
      }
  }

  void mEntity::getAllSubTree(list<mEntity*> &leaves)
  {
    int n = getLevel();
    leaves.push_back(this);
    if (isAdjacencyCreated(n))recur_get_all(this,leaves,n);
  }


  /* 
     This function gets all sub-entities of all dimensions for the element. 
     I'm trying to make that efficient
  */

  void mEntity:: getAllEntitiesOfAllDimensions(std::set<mEntity*> &the_whole_family)
  {
    int n = getLevel();
    the_whole_family.insert(this);
    list<mEntity *> family;
    getAllSubTree(family);
  
    for(std::list<mEntity*>::iterator it = family.begin() ; it != family.end() ; ++it)
      {
	mEntity *e = *it;
	the_whole_family.insert(e);
	for(int dim = 1; dim<n ;dim++)
	  {
	    if(e->isAdjacencyCreated(dim))
	      {

		for(int j=0; j<e->size(dim);j++)
		  {
		    mEntity *sub = e->get(dim,j);
		    list<mEntity *> subfamily;
		    if(the_whole_family.find(sub) == the_whole_family.end())
		      {
			sub->getAllSubTree(subfamily);
			sub->getAllEntitiesOfAllDimensions (the_whole_family);
			for(std::list<mEntity*>::iterator it2 = subfamily.begin() ; it2 != subfamily.end() ; ++it2)
			  {
			    mEntity *sub_f = *it2;
			  
			    the_whole_family.insert(sub_f);
			    for(int k=0; k<sub_f->size(0);k++)
			      the_whole_family.insert(sub_f->get(0,k));
			  }		    
		      }
		  }
	      }
	  }
      }
  }

  void mEntity:: getAllEntitiesOfAllDimensions(std::set<mEntity*,EntityLessThanKey> &the_whole_family)
  {
    int n = getLevel();
    the_whole_family.insert(this);
    list<mEntity *> family;
    getAllSubTree(family);
  
    for(std::list<mEntity*>::iterator it = family.begin() ; it != family.end() ; ++it)
      {
	mEntity *e = *it;
	the_whole_family.insert(e);
	for(int dim = 1; dim<n ;dim++)
	  {
	    if(e->isAdjacencyCreated(dim))
	      {

		for(int j=0; j<e->size(dim);j++)
		  {
		    mEntity *sub = e->get(dim,j);
		    list<mEntity *> subfamily;
		    if(the_whole_family.find(sub) == the_whole_family.end())
		      {
			sub->getAllSubTree(subfamily);
			sub->getAllEntitiesOfAllDimensions (the_whole_family);
			for(std::list<mEntity*>::iterator it2 = subfamily.begin() ; it2 != subfamily.end() ; ++it2)
			  {
			    mEntity *sub_f = *it2;
			  
			    the_whole_family.insert(sub_f);
			    for(int k=0; k<sub_f->size(0);k++)
			      the_whole_family.insert(sub_f->get(0,k));
			  }		    
		      }
		  }
	      }
	  }
      }
  }


  void mEntity::getHigherOrderUpward (int dim, std::set<mEntity*>& ents) const
  {
    if(isAdjacencyCreated(dim))
      {
        for(int i=0;i<size(dim);i++)
	 ents.insert(get(dim,i));
      }
    else
      {
        int myDim = getLevel();
        // int DIMFlag=-1; 
        for(int DIM = myDim+1; DIM!=dim ,DIM <= 3; DIM++)
          {
            if(isAdjacencyCreated(DIM))
              {
                for(int i=0;i<size(DIM);i++)
		  get(DIM,i)->getHigherOrderUpward(dim,ents);
                // DIMFlag = DIM; 
                break;
              }
          }
        /* if(DIMFlag > -1)
            for(int i=0;i<size(DIMFlag);i++)
                 get(DIMFlag,i)->getHigherOrderUpward(dim,ents); */
      }
  }

 void mEntity::getHigherOrderUpward (int dim, mAdjacencyContainer &ents) const
  {
    if(isAdjacencyCreated(dim))
      {
        for(int i=0;i<size(dim);i++)ents.appendUnique(get(dim,i));
      }
    else
      {
        int myDim = getLevel();
        // int DIMFlag=-1;
        for(int DIM = myDim+1; DIM!=dim ,DIM <= 3; DIM++)
          {
            if(isAdjacencyCreated(DIM))
              {
                for(int i=0;i<size(DIM);i++)get(DIM,i)->getHigherOrderUpward(dim,ents);
                // DIMFlag = DIM;
                break;
              }
          }
        /* if(DIMFlag > -1)
            for(int i=0;i<size(DIMFlag);i++)
                 get(DIMFlag,i)->getHigherOrderUpward(dim,ents); */
      }
  }


  /**
     compute use of an entity
  */

  int mEntity :: getUse ( mEntity *e ) const
  {
    if (getLevel() == 2 && e->getLevel() == 1)
      {
	mEdge *ed = (mEdge*)e;
	mVertex *v1 = ed->vertex(0);
	mVertex *v2 = ed->vertex(1);
	int nbVert = size(0);
	for(int i=0;i<nbVert;i++)
	  {
	    mVertex *vv1 = (mVertex*)get(0,i);
	    mVertex *vv2 = (mVertex*)get(0,(i+1)%nbVert);
	    if(vv1 == v1 && vv2 == v2)return 1;
	    if(vv1 == v2 && vv2 == v1)return 0;
	  }
	throw 1;
      }

    if(this->size(0) == 4) {
      int tetfacedir [] = {1,0,0,1};
      int dim = e->getLevel();
      assert (dim < getLevel());
      
      mEntity *v1 = e->get (0,0);
      mEntity *v2 = e->get (0,1);
      
      for(int i=0 ; i< getNbTemplates (dim) ; i++)
	{
	  if ( get(dim,i) == e )
	    {
	      mEntity *other = getTemplate(i, dim, 0);
	      for(int j=0; j<other->size(0);j++)
		{
		  if(other->get(0,j) == v1)
		    {
		      mEntity *vtest = other->get(0,(j+1)%other->size(0));
		      if(vtest == v2)
			{
			  if(other != get(dim,i))delete other;
			  if(dim == 2)return ( 1 - tetfacedir[i] );
			  return 1;
			}
		      else
			{
			  if(other != get(dim,i))delete other;
			  if(dim == 2)return ( tetfacedir[i] );
			  return 0;
			}
		    }
		}
	      delete other;
	    }
	}
    }
      
    else if(this->size(0) == 8) {
      
      int heindex[6] = {0, 0, 1, 2, 3, 8};
      int hvindex[8] = {0, 1, 2, 3, 0, 5};
      
      int dim = e->getLevel(), dir = 1;
      assert (dim < getLevel());

      for(int i=0 ; i< getNbTemplates (dim) ; i++)
	{
	  if ( get(dim,i) == e )
	    {
	      mEntity *ed = get(1, heindex[i]);
	      mEntity *rv = ed->get(0, 0);
	      mEntity *fv = get(0, hvindex[i]);
	      
	      int dir = e->getUse(ed);

	      if(rv == fv)
		return !dir;
	      else
		return dir;
	    }
	}
      
    }
    else if(this->size(0) == 6) {
      int pmeindex[5] = {0, 0, 1, 2, 6};
      int pmvindex[5] = {0, 1, 2, 0, 4};
      
      int dim = e->getLevel(), dir = 1;
      assert (dim < getLevel());

      for(int i=0 ; i< getNbTemplates (dim) ; i++)
	{
	  if ( get(dim,i) == e )
	    {
	      mEntity *ed = get(1, pmeindex[i]);
	      mEntity *rv = ed->get(0, 0);
	      mEntity *fv = get(0, pmvindex[i]);
	      
	      int dir = e->getUse(ed);

	      if(rv == fv)
		return !dir;
	      else
		return dir;
	    }
	}
      
    }
    else if(this->size(0) == 5) {
      int preindex[5] = {0, 0, 1, 2, 3};
      int prvindex[5] = {0, 1, 2, 3, 0};
      
      int dim = e->getLevel(), dir = 1;
      assert (dim < getLevel());

      for(int i=0 ; i< getNbTemplates (dim) ; i++)
	{
	  if ( get(dim,i) == e )
	    {
	      mEntity *ed = get(1, preindex[i]);
	      mEntity *rv = ed->get(0, 0);
	      mEntity *fv = get(0, prvindex[i]);
	      
	      int dir = e->getUse(ed);

	      if(rv == fv)
		return !dir;
	      else
		return dir;
	    }
	}
    }

    throw 1;
  }
    
  mEntity::mTopology mEntity::getTopo()
  {
    int mDim;
    mDim=getLevel();
    switch(mDim)
      {
      case 0:
	return POINT;
	break;
      case 1:
	return LINE_SEGMENT;
	break;
      case 2:
	if     (size(0) == 3) return TRIANGLE;
	else if (size(0) == 4) return QUADRILATERAL;
	else if (size(0) >= 5) return POLYGON;
	break;
      case 3:
	if      (size(0) == 4 && size(2) == 4) return TETRAHEDRON;
	else if (size(0) == 8 && size(2) == 6) return HEXAHEDRON;
	else if (size(0) == 6 && size(2) == 5) return PRISM_;
	else if (size(0) == 5 && size(2) == 5) return PYRAMID_;
	else if (size(0) > 8)                  return POLYHEDRON;
	break;
      default:
	return UNDEFINED;
      }
  }

string mEntity::getUid() const
  {

    char cuid[256];
    //int uid;
    std::vector<int> uids;
    switch(getType())
    {
      case VERTEX : 
	uids.push_back(getId());
	break;
      default: 
        for (int i=0; i<size(0);++i)
          uids.push_back(get(0,i)->getId());
	std::sort(uids.begin(), uids.end());
	break;
    }
    
    switch(getType())
      {
      case VERTEX : 
	sprintf (cuid,"V%d",uids[0]);
	break;
      case EDGE : 
	sprintf (cuid,"E%d_%d",uids[0],uids[1]);
	break;
      case TRI : 
	sprintf (cuid,"F%d_%d_%d",uids[0],uids[1],uids[2]);
	break;  
      case QUAD : 
	sprintf (cuid,"F%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3]);
	break;
      case TET : 
	sprintf (cuid,"R%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3]);
	break;
      case HEX : 
	sprintf (cuid,"R%d_%d_%d_%d_%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3],
  		 				 uids[4],uids[5],uids[6],uids[7]);
	break;
      case PRISM : 
        sprintf (cuid,"R%d_%d_%d_%d_%d_%d",uids[0],uids[1],uids[2],uids[3],
	                                         uids[4],uids[5]);
	break;
								 
    }

    return string(cuid);
  }

#ifdef MATCHING
const std::multimap<int, mEntity*>* mEntity::getMatchEnts()
{
  return theMatchEnts; 
//  matchEnts.clear(); 
//  for(MEIter it=meBegin(); it!=meEnd(); ++it)
//    matchEnts.insert(matchEntMap::value_type(it->first, it->second));   
}

int mEntity::isMatchEnt(int pid, mEntity* ent)
{
  if(theMatchEnts==NULL)
    return 0; 
  if(theMatchEnts->empty())
    return 0; 
  multimap<int,mEntity*>::iterator mapit; 
  std::pair<multimap<int,mEntity*>::iterator,multimap<int,mEntity*>::iterator> ret; 
  ret = theMatchEnts->equal_range(pid);
  for (mapit=ret.first; mapit!=ret.second; ++mapit) {
    if (mapit->second == ent)
      return 1; 
  }
  return 0;  
}
 
void mEntity::addMatchEnt(int pid, mEntity* ent)
{
   if(theMatchEnts==NULL)
      theMatchEnts = new matchEntMap; 
   theMatchEnts->insert(matchEntMap::value_type(pid, ent));
}

void mEntity::deleteMatchEnt(int pid, mEntity* ent)
{
  if(theMatchEnts==NULL)
    return; 
  if(theMatchEnts->empty())
    return; 
    
  int flag=0; 
  multimap<int,mEntity*>::iterator mapit;
  std::pair<multimap<int,mEntity*>::iterator,multimap<int,mEntity*>::iterator> ret;
  ret = theMatchEnts->equal_range(pid);
  for (mapit=ret.first; mapit!=ret.second; ++mapit) {
   if (mapit->second == ent) {
      flag=1;
      break; 
   }
  }
  if(flag==1)
    theMatchEnts->erase(mapit);

  if(theMatchEnts->empty())
    SAFE_DELETE(theMatchEnts); 
}

#ifdef DEBUG
void mEntity::printMatchEnts()
{
  if(theMatchEnts==NULL) 
   return; 
   
#ifdef FMDB_PARALLEL
  int mypid = ParUtil::Instance()->rank();
  int numPart = ParUtil::Instance()->getCurNumParts();
  cout<<"("<<ParUtil::Instance()->rank()<<") Match of ("<<getUid()<<","<<this<<": ";
#else
   cout<<" Match of ("<<getUid()<<","<<this<<": ";
#endif

  for (MEIter meiter=meBegin(); meiter!=meEnd();++meiter)
#ifdef FMDB_PARALLEL
    if(meiter->first/numPart==mypid)
#endif
       cout<<"(P"<<meiter->first<<","<<(meiter->second)->getUid()<<","<<meiter->second<<"), ";
#ifdef FMDB_PARALLEL
     else
       cout<<"(P"<<meiter->first<<","<<meiter->second<<"), ";
#endif
  cout<<endl;
}
#endif

#endif   // MATCHING



