/****************************************************************************** 
  
  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "iUtil.h"
#include <assert.h>
#include <list>

#include "FMDB_cint.h"
#include "FMDB_Internals.h"

using namespace std;

// VALID TYPE+TOPO
// VERTEX: POINT, ALL_TOPOLOGIES
// EDGE: LINE_SEGMENT, ALL_TOPOLOGIES
// FACE: TRIANGLE, QUADRILATERAL, POLYGON, ALL_TOPOLOGIES
// REGION: TETRAHEDRON, ..., ALL_TOPOLOGIES
// ALL_TYPES: POINT, ..., ALL_TOPOLOGIES

void ITAPS_Util::addIterator(pIterator iter)
{
  allIterators.push_back(iter);
}

void ITAPS_Util::eraseIterator(pIterator& iter)
{
  list<pIterator>::iterator loc=find(allIterators.begin(),
  allIterators.end(),iter);
  if(iter->type==1)                   // entity set
  {
    if(iter->isList==1)
       delete ((pEntSetUIterator) iter->iter); 
    if(iter->isList==0)
       delete ((pEntSetOIterator) iter->iter);
  }
  if(iter->type==2)
    delete ((pMeshIterator) iter->iter); 

  if(iter->type==3){                   // the ptr inside iter is a structure
    delete (ptr_int_struct*)((pMeshIterator)(iter->iter))->getPtr(); 
    delete (pMeshIterator) (iter->iter); 
  }
  SAFE_DELETE(iter);
  allIterators.erase(loc++);
}


// type 1 iterator
void createIterator(mEntitySet* eset, pIterator& iter, int type, int topo,
int ws)
{
  iter= new Iterator; 
  iter->type=1; 
  if(eset->isList())
  {
     iter->isList=1; 
     iter->iter = new mEntSetUIterator(((mEntitySetUnordered*)eset)->begin(), ((mEntitySetUnordered*)eset)->end(),type,topo, (void*)eset, &processingEntitySetUFilter);
  }
  else
  {
     iter->isList=0; 
     iter->iter = new mEntSetOIterator(((mEntitySetOrdered*)eset)->begin(), ((mEntitySetOrdered*)eset)->end() ,type,topo, (void*)eset, &processingEntitySetOFilter );
  }
   ITAPS_Util::Instance()->addIterator((pIterator)iter);
}

// type 2 iterator
void createIterator(mPart* mesh, pIterator& iter, int type, int topo, int ws)
{
  iter= new Iterator;
  iter->type=2;
  iter->isList=-1;
  if(type>=4)  // all types
  {
     switch (topo)
     {
      case mEntity::POINT: 
	 iter->iter = new mPartIterator(mesh->beginall(0), mesh->endall(0), 0, topo, (void*)mesh, &processingMeshFilter); 
	 break; 
      case mEntity::LINE_SEGMENT:
	 iter->iter = new mPartIterator(mesh->beginall(1), mesh->endall(1), 1, topo, (void*)mesh, &processingMeshFilter);
	 break;
      case mEntity::POLYGON: 
      case mEntity::TRIANGLE:
      case mEntity::QUADRILATERAL:
	 iter->iter = new mPartIterator(mesh->beginall(2), mesh->endall(2), 2, topo, (void*)mesh, &processingMeshFilter);
	 break;
      case mEntity::POLYHEDRON:
      case mEntity::TETRAHEDRON:
      case mEntity::HEXAHEDRON:
      case mEntity::PYRAMID_: 
      case mEntity::PRISM_:
      case mEntity::SEPTAHEDRON:
	 iter->iter = new mPartIterator(mesh->beginall(3), mesh->endall(3), 3, topo, (void*)mesh, &processingMeshFilter);
	 break;
      default: // all topologies
       {
	 int dim = mesh->getDimension(); 
         iter->iter = new mPartIterator(mesh->beginall(0), mesh->endall(dim), 4, topo, (void*)mesh, &processingMeshFilter);
       }
       break;
     }
  }
  else // specific entity type iterator
  {
     iter->iter = new mPartIterator(mesh->beginall(type), mesh->endall(type), type, topo, (void*)mesh, &processingMeshFilter);
  }

  ITAPS_Util::Instance()->addIterator((pIterator)iter);
}

#ifdef FMDB_PARALLEL
void createIterator(mPart* mesh, pIterator& iter, int* nbor_pid, int type, 
		    int topo, int ws)
{
  iter= new Iterator;
  iter->type=3;                         // structure other than mesh and entityset
  iter->isList=-1; 

  ptr_int_struct* mesh_pid = new ptr_int_struct; 
  mesh_pid->mesh = mesh; 
  mesh_pid->pid =*nbor_pid; 
  
  if(type>=4)
  {
     switch (topo)
     {
      case mEntity::POINT: 
	 iter->iter = new mPartIterator(mesh->beginall(0), mesh->endall(0), 0, topo, (void*)mesh_pid, &processingPartBdryEntFilter); 
	 break; 
      case mEntity::LINE_SEGMENT:
	 iter->iter = new mPartIterator(mesh->beginall(1), mesh->endall(1), 1, topo, (void*)mesh_pid, &processingPartBdryEntFilter);
	 break;
      case mEntity::POLYGON: 
      case mEntity::TRIANGLE:
      case mEntity::QUADRILATERAL:
	 iter->iter = new mPartIterator(mesh->beginall(2), mesh->endall(2), 2, topo, (void*)mesh_pid, &processingPartBdryEntFilter);
	 break;
      default:
       {
	 int dim = mesh->getDimension(); 
         iter->iter = new mPartIterator(mesh->beginall(0), mesh->endall(dim-1), 4, topo, (void*)mesh_pid, &processingPartBdryEntFilter);
       }
       break;
     }
  }
  else
     iter->iter = new mPartIterator(mesh->beginall(type), mesh->endall(type), type, topo, (void*)mesh_pid, &processingPartBdryEntFilter);
  ITAPS_Util::Instance()->addIterator((pIterator)iter);
}
#endif

void deleteIterator(pIterator& iter)
{
   ITAPS_Util::Instance()->eraseIterator((pIterator&)iter);
}

bool iterEnd(Iterator* iter)
{
   if(iter->type==1)
   {
      if(iter->isList)
      {
	 ((pEntSetUIterator)iter->iter)->valid_check();
        return ((pEntSetUIterator)iter->iter)->end(); 
      }
      else
	return ((pEntSetOIterator)iter->iter)->end();
   }
   
   if(iter->type==2 || iter->type==3)
      return ((pMeshIterator)iter->iter)->end();
}

pEntity iterData(Iterator* iter)
{
   if(iter->type==1)
   { 
      if(iter->isList)
	 return *(*((pEntSetUIterator)iter->iter)); 
      else
	 return *(*((pEntSetOIterator)iter->iter));
   }
   
   if(iter->type==2 || iter->type==3)
      return  *(*((pMeshIterator)iter->iter)); 
}

void iterNext(Iterator* iter)
{
   if(iter->type==1)
   {
       if(iter->isList)
         ((pEntSetUIterator)iter->iter)->next();
       else
	 ((pEntSetOIterator)iter->iter)->next();
  }	 
   else if(iter->type==2 || iter->type==3)
      ((pMeshIterator)iter->iter)->next();    
}

void iterReset(Iterator* iter)
{
   if(iter->type==1)
   {
      if(iter->isList)
         ((pEntSetUIterator)iter->iter)->reset();
      else
	 ((pEntSetOIterator)iter->iter)->reset();
   }
   else if(iter->type==2 || iter->type==3)
      ((pMeshIterator)iter->iter)->reset();
}

int wrkSize(Iterator* iter)
{
   return 1; 
/*
   if(iter->type==1)
   {
       if(iter->isList)
         return ((pEntSetUIterator)iter->iter)->wrkSize();
       else
	 return ((pEntSetOIterator)iter->iter)->wrkSize();
    }   

   if(iter->type==2 || iter->type==3)
      return ((pMeshIterator)iter->iter)->wrkSize();
*/
}

