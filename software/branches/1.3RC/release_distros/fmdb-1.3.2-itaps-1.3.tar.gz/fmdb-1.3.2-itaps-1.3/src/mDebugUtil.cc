/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#include <assert.h>
#include <iostream>
#include "mDebugUtil.h"
#include "mPart.h"
#include "mEntity.h"
#include "mPoint.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mHex.h"
#include "mPrism.h"
#include "mException.h"
#include "mFMDB.h"
#include "FMDB_Internals.h"
#include "FMDB_cint.h"
#include "ParUtil.h"
//#include "MeshTools.h"

#ifdef FMDB_PARALLEL
#include "FMDB_OwnerManager.h"
#include "mCommonBdry.h"
#include "pmModel.h"
#include "pmUtility.h"
#endif

#include "modeler.h"

#include <stdlib.h>  
#include <math.h> 
#include <algorithm> 
#include <vector> 
#include <string> 
using std::cout;
using std::sort;
using std::set;
using std::list;
using std::string;
using std::vector;
using std::pair;
using std::endl;

// ***********************************************************
bool verify_mesh(mPart* mesh)
// ***********************************************************
{
  pmEntity* pe;
  mEntity *vertex, *vertex0, *vertex1;
  mEntity* edge;
  mEntity* face;
  mEntity *region, *region0, *region1;
  int gLevel;
  int manifold=1;
  int numAdjE;
  int numAdjF;
  int numAdjR;
  int mypid=P_pid();
  int meshDim = M_globalMaxDim(mesh);
  int ret=1; /* true */
  double value0, value1;
  int sameSidedRegionPairCnt=0;
  
#ifdef FMDB_PARALLEL  // data for communication
  int numRC, pid;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(int2_mEnt2_struct));
  int2_mEnt2_struct* msg_send = (int2_mEnt2_struct*)CM->alloc_msg(sizeof(int2_mEnt2_struct));
  int num_sent = 0, num_recvd = 0;
#endif 

  // check vertices
  for (mPart::iterall it=mesh->beginall(0); it!=mesh->endall(0);++it)
  {
    vertex = *it;
    numAdjE=V_numEdges(vertex);
    if (meshDim==3 && numAdjE<3)
    {  
      cout<<"FMDB INFO: V_numEdges= "<<numAdjE<<" for ";
      vertex->print();
      if (numAdjE==0) manifold=0;
    }
    if (meshDim==2 && numAdjE==0)
    {  
      cout<<"FMDB INFO: V_numEdges= "<<numAdjE<<" for ";
      vertex->print();
      manifold=0;
    }

    pe = vertex->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = vertex->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) vertex->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	vertex->printRCs();
	vertex->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = vertex->rcBegin();
          rciter!=vertex->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = vertex;
        msg_send->ent2 = rciter->second;
        msg_send->i=GEN_type(vertex->getClassification());
	msg_send->j=GEN_tag(vertex->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
   } // else
#endif    
  }
  
  // check edges
  for (mPart::iterall it=mesh->beginall(1); it!=mesh->endall(1);++it)
  {
    edge = *it;
    numAdjF = E_numFaces(edge);
    
    if (meshDim==3)
    {
      switch (numAdjF)
      { 
        case 0:
               cout<<"FMDB INFO: E_numFaces=0 for ";
               edge->print();
	       manifold=0;
	       break;
        case 1: if (!EN_duplicate(edge) && !edge->getIsGhost())	       
               {
	         cout<<"FMDB INFO: E_numFace=1 for ";
                 edge->print();
	         manifold=0;
	       }
	       break;
        default: break;
      } 
      gLevel=GEN_type(edge->getClassification());
      if (gLevel==1 || gLevel==2)
      {
        int bf_counter=0; // number of boundary faces adjacent
        for (int i=0; i<numAdjF; ++i)
        {
	  face = edge->get(2,i);
  	  if (GEN_type(face->getClassification())==2)
	    bf_counter++;
        }
        if (bf_counter!=2 && !EN_duplicate(edge) && !edge->getIsGhost())
        {
  	  cout<<"INFO: E_numFaces="<<bf_counter<<" for ";
          edge->print();
          manifold=0; 
        }

       // if (!EN_duplicate(edge))
//	  assert(bf_counter==2);
//	else //partition boundary edge
//	{ 
//	  assert(bf_counter==1); // SEOL: check when this happens
//	}
      } 
    }
    else if (meshDim==2) // edge in 2D
    {
      if (numAdjF==0)
      {  
        cout<<"FMDB INFO: E_numFaces=0 for ";
        edge->print();
        manifold=0;
      }
    
      gLevel=GEN_type(edge->getClassification());
      switch(gLevel)
      {
        case 1: // model edge
   	        if (numAdjF!=1) 
		{
  		  cout<<"["<<mypid<<"] FMDB WARNING: "<<numAdjF<<" faces with ";
		  edge->print();
		  manifold=0;
	        }
		break;
        case 2:  if (edge->getPClassification() && !edge->getIsGhost()) // CB edge
	          assert(numAdjF==1);
		else if (!edge->getIsGhost())  // non-CB edge
		  assert(numAdjF==2);
	      break;
        default:  cout<<"FMDB ERROR: wrong classification for ";
                edge->print();
                return false;
      } // switch
    } // else
    
    pe = edge->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = edge->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) edge->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	edge->printRCs();
	edge->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = edge->rcBegin();
          rciter!=edge->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = edge;
        msg_send->ent2 = rciter->second;
        msg_send->i = GEN_type(edge->getClassification());
        msg_send->j = GEN_tag(edge->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
    } // else
#endif     
  } // edges
 
  // check faces
  for (mPart::iterall it=mesh->beginall(2); it!=mesh->endall(2);++it)
  {
    face = *it;
#ifdef MTOOL
    IntersectionData idata;
    for (int k=0; k<3; ++k)
    {
       vtx = face->get(0,k);
       pPList vfaces=V_faces(vtx);
       iter=0;
       while ((adjfc=(mEntity*)PList_next(vfaces, &iter)))
       {
         if (face==adjfc) continue;
         idata = M_intersectionData_new() ;
	 if (1==M_intersectFaces(face, 0, adjfc, 0, &idata))
	   cout<<"FMDB FATAL: two intersecing faces: ";
           face->print();
	   adjfc->print();
         M_intersectionData_delete(idata);	       
       }
       PList_delete(vfaces);
    }
#endif    
    numAdjR = F_numRegions(face);
 
    if (meshDim==3)
    {
      gLevel=GEN_type(face->getClassification());
      switch(gLevel)
      {
        case 2: // face on model face
               if (numAdjR!=1)
	       {
                 cout<<" FMDB INFO: F_numRegions="<<numAdjR<<" for ";
                 face->print();
	         manifold=0;
               }
	       break;
        case 3: // interior face
               if (EN_duplicate(face)) // CB face
	       {
  	         if (numAdjR!=1) face->print();
	         assert(numAdjR==1);
  	       } 
	       else if (!face->getIsGhost())
	       {  
	         if (F_numRegions(face)!=2) 
		 {
                   cout<<"FMDB INFO: F_numRegions="<<F_numRegions(face)<<" for ";  face->print();
                   manifold=0;
                 }
//  	         assert(F_numRegions(face)==2);
                 if (F_numRegions(face) == 0)
                   continue;
// check if two regions are on the same side;
                 region0 = face->get(3,0);
                 if (F_numRegions(face)==2)
                 { 
		   region1 = face->get(3,1);
                   vertex0 = findVertexOppositeFace(region0, face);
                   vertex1 = findVertexOppositeFace(region1, face);
                   value0 = computeSignedDistance(vertex0, face);
                   value1 = computeSignedDistance(vertex1, face);

                   if (fabs(value0)>1E-5 && fabs(value1)>1E-5 && value0*value1>0.0 ) 
                     sameSidedRegionPairCnt++;
                 }
	       }
               break;
        default: cout<<"FMDB Error: wrong classification for";
               face->print();
	       return false;
      }
    } // face in 3D
    else if (meshDim==2)
    {
      if (numAdjR!=0)
      {  
        cout<<"["<<mypid<<"] FMDB ERROR: adj. regions with "<<face->getUid()<<" in 2D mesh\n";
        return false;
      }
      assert(F_numRegions(face)==0);
      assert(GEN_type(face->getClassification())==2);
    } // face in 2D

    pe = face->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = face->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) face->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	face->printRCs();
	face->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = face->rcBegin();
          rciter!=face->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = face;
        msg_send->ent2 = rciter->second;
        msg_send->i = GEN_type(face->getClassification());
        msg_send->j = GEN_tag(face->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
    } // else
#endif         
  }
  
   // check regions
  for (mPart::iterall it=mesh->beginall(3); it!=mesh->endall(3);++it)
  {
    region = *it;
    assert(!(region->getPClassification()));
    assert(GEN_type(region->getClassification())==3);
/*    if (R_Volume2(region)<0.0)
    {
      cout<<"FMDB WARNING: Negative volume for ";
      region->print();
    }
*/
  }

#ifdef FMDB_PARALLEL
// check partition boundary
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*) msg_recv;
    if (GEN_type(castbuf->ent2->getClassification())!=castbuf->i)
      castbuf->ent2->print();
    assert(GEN_type(castbuf->ent2->getClassification())==castbuf->i);
    if (GEN_tag(castbuf->ent2->getClassification())!=castbuf->j)
      castbuf->ent2->print();
    assert(GEN_tag(castbuf->ent2->getClassification())==castbuf->j);
    assert(castbuf->ent2->getRemoteCopy(pid_from)==castbuf->ent1);
    CM->free_msg(msg_recv);
  }  // end of while(!AP...)
#endif
  
//  if (sameSidedRegionPairCnt!=0)
//    cout<<"["<<mypid<<"] FMDB INFO: sameSidedRegionPairCnt = "<<sameSidedRegionPairCnt<<endl;
  int globalRetVal;
  if (P_getMinInt(ret)==1 && manifold) 
    return true;
  else 
    return false;
} // verify_mesh  

int mPart::numUniqueEntities(int type)
{
  if (ParUtil::Instance()->size()==1)
    return size(type);
  int mypid=ParUtil::Instance()->rank();
  int numEnt=0;
  for (iterall it=beginall(type); it!=endall(type); ++it)
    if ((*it)->getOwner()==mypid)
      numEnt++;
  return numEnt;
}

void mPart::printAll()
{
  for (int i=0; i<=getDimension();++i)
    print(i);
}

void mPart::print(int dim)
{
#ifdef FMDB_PARALLEL
  if (ParUtil::Instance()->master())
    cout<<endl;
    
  pmModel* pmodel = pmModel::Instance();
  for (pmModel::PEIter peiter=pmodel->peBegin(); peiter!=pmodel->peEnd();++peiter)
    (*peiter)->print();
  if (ParUtil::Instance()->master())
    cout<<endl;
#endif

  for (iterall it = beginall(dim); it!=endall(dim);++it)
    (*it)->print();
}

void mPart::printNumEntities()
{
  for (int i=0; i<=3;++i)
  {
    vector<int> output;
    M_numEntitiesOwned(this,i,output);
    if (P_pid()==0)
    {
      int sum=0;
      for (int j=0; j<P_size();++j)
        sum+=output[j];  
      cout<<"# dim["<<i<<"] = "<<sum<<" (";
      for (int j=0; j<P_size();++j)
      {  cout<<output[j];
         if (j!=P_size()-1)
	   cout<<",";
      }
      cout<<")"<<endl;
    }
  }
}

void mPart::printNumEntities_NonCfm()
{
#ifdef FMDB_PARALLEL
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_PrintNumEntities  ***\n");	  
  cout<<"   ["<<M_Pid()<<"] numVt="<<numUniqueEntities(0)<<"\n";
  cout<<"   ["<<M_Pid()<<"] numEg="<<numUniqueEntities(1)<<"\n"; 
  cout<<"   ["<<M_Pid()<<"] numFc="<<numUniqueEntities(2)<<"\n"; 
  cout<<"   ["<<M_Pid()<<"] numRg="<<numUniqueEntities(3)<<"\n"; 
  ParUtil::Instance()->Msg(ParUtil::INFO,"*****************************\n");	  
#else
  cout<<"\n***  M_PrintNumEntities  ***\n";
  cout<<"   numVt = "<<numUniqueEntities(0)<<endl;
  cout<<"   numEg = "<<numUniqueEntities(1)<<endl;
  cout<<"   numFc = "<<numUniqueEntities(2)<<endl;
  cout<<"   numRg = "<<numUniqueEntities(3)<<endl;
  cout<<"*****************************\n";
#endif
}

void mVertex::print() const
{
#ifndef FMDB_PARALLEL
      
      cout<<"en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
	  <<"(iD "<<iD
 	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
          <<"(iD "<<iD
   	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
	 <<", numRCs="<<theRemoteCopies->size()
	  <<")\n ";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"["<<p(0)<<","<<p(1)<<","<<p(2)<<"], "
          <<"(iD "<<iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }

#ifdef MATCHING
    if ( ((mEntity*)this)->hasMatchEnt() ){
    ((mEntity*)this)->printRCs(); 
    cout<<" Owner: "<< ((mEntity*)this)->getOwner()<<endl; 
#ifdef DEBUG
      ((mEntity*)this)->printMatchEnts(); 
#endif
    }
#endif
#endif
}

void mEdge::print()const
{
#ifndef FMDB_PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
         <<", numRCs="<<theRemoteCopies->size()
          <<") on CB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }
#endif
}

void mFace::print()const
{
#ifndef FMDB_PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
         <<", numRCs="<<theRemoteCopies->size()
          <<")\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }
#endif
}

void mTet::print()const
{
#ifndef FMDB_PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
#else    
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }
#endif
}


void mHex::print()const
{
#ifndef FMDB_PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }
#endif
}

void mPrism::print()const
{
#ifndef FMDB_PARALLEL
      cout<<"en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
#else
    if (thePClassification)
    { 
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
	  <<", peId "<<thePClassification->getId()
          <<") onCB\n";
    }
    else
    {
      cout<<"("<<ParUtil::Instance()->rank()<<") en_info: "<<getUid()
          <<"(iD "<<0 //iD
	  <<", mem "<<this
#ifndef _POINTER2INT_
	  <<", gLevel "<<GEN_type(theClassification)
  	  <<", gTag "<<GEN_tag(theClassification)
#else
	<<", gLevel "<<GEN_type(getClassification())
        <<", gTag "<<GEN_tag(getClassification()) 
#endif
          <<")\n";
    }
#endif
}
