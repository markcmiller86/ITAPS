/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "mException.h"

#include <string.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

mException::mException(const int i, const char *f, const char *text)
: theLine(i)
{
   strcpy(theFile,f);
   printf("an exception has been thrown at line %d in file %s\n",i,f);
   printf("TEXT : %s\n",text);
}

mException::~mException()
{

}
