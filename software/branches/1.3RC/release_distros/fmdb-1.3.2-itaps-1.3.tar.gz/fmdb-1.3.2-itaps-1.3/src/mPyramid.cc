/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mPyramid.h"
#include "mEntityContainer.h"
#include "mException.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "function_template.h"
#include <stdio.h>

 short int mPyramid::prev[8][2] = {{0,1},{1,2},{2,3},
                          {3,0},{0,4},{1,4},
                          {2,4},{3,4}};

 short int mPyramid::prfv[5][4] =   {{0,1,2,3},
                            {0,1,4,-1},
                            {1,2,4,-1},
                            {2,3,4,-1},
                            {3,0,4,-1}};

 short int mPyramid::prfe[5][4] =   {{0,1,2,3},
                            {0,5,4,-1},
                            {1,6,5,-1},
                            {2,7,6,-1},
                            {3,4,7,-1}};

 short int mPyramid::prve[5][2] = {{0,3},{0,1},{1,2},{2,3},{4,5}};
 short int mPyramid::prvf[5][3] = {{0,1,4},{0,1,2},{0,2,3},{0,3,4},{1,2,3}};
 short int mPyramid::pref[8][2] = {{0,1},{0,2},{0,3},
                           {0,4},{1,4},{1,2},
                           {2,3},{3,4}};

  mPyramid::mPyramid()
    : mRegion()  
  {
  }
  
  mPyramid::mPyramid(mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4,
		 mVertex *v5, 
		 GEntity *classification)
    : mRegion() 
  {

     down_adj_dim=0; 
     down_adj[0]=v1;
     down_adj[1]=v2;
     down_adj[2]=v3;
     down_adj[3]=v4;
     down_adj[4]=v5;

//    theClassification = classification;
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

  }
  
  
  mPyramid::mPyramid(mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, GEntity *classification)
  : mRegion() 
 {
     down_adj_dim=2; 
     down_adj[0]=f1;
     down_adj[1]=f2;
     down_adj[2]=f3;
     down_adj[3]=f4;
     down_adj[4]=f5;
   
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

  }

  int mPyramid:: getNbTemplates (int what) const
  {
    switch(what)
      {
      case 0: return 5;
      case 1: return 8;
      case 2: return 5;
	
      default : 
	{
	  char text[256];
	  sprintf(text,"trying to ask for adjacency list of level %d for a pyramid when it's not created",what);
	  throw new mException (__LINE__,__FILE__,text);
	}
      }
  }

 
  
  mEntity *mPyramid::getTemplate(int ith, int what, int with)const
  {
#ifndef _POINTER2INT_
  GEntity* classification = theClassification;
#else
  GEntity* classification = getClassification();  
#endif

    switch(what)
      {
      case 0:
	  if(down_adj_dim==0)
	    return down_adj[ith];

	  if(down_adj_dim==1)
	  {
	    mEdge *e1 = (mEdge*)get(1,prve[ith][0]);
	    mEdge *e2 = (mEdge*)get(1,prve[ith][1]);
	    return e1->commonVertex(e2);
	  }

	  if(down_adj_dim==2)
	  {
	    mFace *f1 = (mFace*)get(2,prvf[ith][0]);
	    mFace *f2 = (mFace*)get(2,prvf[ith][1]);
	    mFace *f3 = (mFace*)get(2,prvf[ith][2]);
	    return f1->commonVertex(f2,f3);
	  }
	break;
      case 1:
          if(down_adj_dim==2)
	  {
	    mFace *f1 = (mFace*)get(2,pref[ith][0]);
	    mFace *f2 = (mFace*)get(2,pref[ith][1]);
	    mEdge *e =  f1->commonEdge(f2);
	    if(e) return e;
	  }
	 return new mEdge ((mVertex*)get(0, prev[ith][0]),
	       	           (mVertex*)get(0, prev[ith][1]),
		            classification);
	break;
      case 2:
	if(prfv[ith][3] == -1)
	  {
	    if(with == 0) {
		  return new mFace ((mVertex*)get(0,prfv[ith][0]),
				(mVertex*)get(0, prfv[ith][1]),
				(mVertex*)get(0, prfv[ith][2]),
				classification);
	   }
	    else if (with == 1)
	      {
		return new mFace ((mEdge*)get(1, prfe[ith][0]),
				  (mEdge*)get(1, prfe[ith][1]),
				  (mEdge*)get(1, prfe[ith][2]),
				  classification);
	      }
	    else throw new mException (__LINE__,__FILE__,"weird adjacency asked");
	  }
	else
	  {
	    if(with == 0) {
		   return new mFace ((mVertex*)get(0,prfv[ith][0]),
				(mVertex*)get(0,prfv[ith][1]),
				(mVertex*)get(0,prfv[ith][2]),
				(mVertex*)get(0,prfv[ith][3]),
				classification);
				
	   }
	    else if (with == 1)
	      {
		return new mFace ((mEdge*)get(1, prfe[ith][0]),
				  (mEdge*)get(1, prfe[ith][1]),
				  (mEdge*)get(1, prfe[ith][2]),
				  (mEdge*)get(1, prfe[ith][3]),
				  classification);
	      }
	    else throw new mException (__LINE__,__FILE__,"weird adjacency asked");
	  }
      }
    return 0;
  }
  
  mPyramid::~mPyramid()
  {
    
  }

    // adjacency related

   int mPyramid::size (int what)const
   {
      return getNbTemplates(what);
   }

   mEntity* mPyramid::get(int what, int ith)const
   {
      if(what==down_adj_dim)
         return down_adj[ith];

      return getTemplate(ith, what, 0);
   }

   // void mPyramid::getAppendPList(int what, pPList pl) const;

   mEntity * mPyramid::find(mEntity* m) const
   {
      find_entity_in_array<mEntity*>((mEntity**)down_adj, 5, m);
   }
