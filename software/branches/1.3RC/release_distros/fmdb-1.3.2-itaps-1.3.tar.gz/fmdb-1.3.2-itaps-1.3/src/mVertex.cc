/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mVertex.h"
#include "mException.h"
#include "mVector.h"
#include "mIdGenerator.h"
#include <stdio.h>
#include "function_template.h"

using std::ostream;

mVertex::mVertex(mIdGenerator &theIdGenerator, const SCOREC::Util::mPoint &pt, GEntity *classif)
  :mEntity(),p(pt)
   , up_adj_size(0), up_adj(0)
{
  iD = theIdGenerator.generateId();
#ifndef _POINTER2INT_
  theClassification = classif;
#else
     gType = GEN_type(classif);
     gTag = GEN_tag(classif);
#endif
}


mVertex::mVertex(int theId, const SCOREC::Util::mPoint &pt, GEntity *classif)
  :mEntity(),p(pt)
   , up_adj_size(0), up_adj(0) 
{
  iD = theId;
#ifndef _POINTER2INT_
  theClassification = classif;
#else
   gType = GEN_type(classif);
   gTag = GEN_tag(classif);
#endif	    
}


void mVertex::deleteId(mIdGenerator &theIdGenerator)
{
  theIdGenerator.addId(iD);
  iD = 0;
}

mVertex::~mVertex()
{
   free_array<mEntity*>(up_adj, up_adj_size); 
}

int mVertex::getLevel()const
{
  return 0;
}

/*
  compart two vertices using lexicographic order
  EPS is the tolerance
*/

VertexLexicographicLessThan::VertexLexicographicLessThan(double eps)
  : EPS(eps)
{
}

bool VertexLexicographicLessThan :: operator()(mVertex* ent1, mVertex* ent2) const
{
  return ent1->point().lexicographicLessThan (ent2->point(),EPS);
}

void mVertex::add (mEntity* m)
{
   add_entity_to_array<mEntity*>(up_adj, m, up_adj_size); 
}

mEntity* mVertex::find(mEntity* me)const
{
   return find_entity_in_array<mEntity*>(up_adj, up_adj_size, me); 
}

  void mVertex::appendUnique(mEntity*me)   
  {
    APPEND_UNIQUE_ENTITY(me);
  }

   void mVertex::del(mEntity*me)  
   {
       del_entity_from_array<mEntity*>(up_adj, up_adj_size, me); 
   }
 
    mEntity* mVertex::get(int what, int i)const
    {
      if(what==1)
         return up_adj[i];
      return 0; 
    }

 void mVertex::deleteAdjacencies(int what) 
 {
    free_array<mEntity*>(up_adj, up_adj_size); 
 }
