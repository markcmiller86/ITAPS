/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <assert.h>

#include "mPart.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mHex.h"
#include "mPrism.h"
#include "mPoint.h"
#include "mException.h"
#include "mBuildAdj.h"
#include "mFMDB.h"

#include <stdio.h>

using std::list;
using std::set;
using std::istream;
using std::ostream;
using std::cout;
using std::endl;

void mPart :: DEL_updateAdj(mEntity *e)
  {
    for (int i=0; i<=getDimension();++i)
    {
      if (i==e->getLevel())
        continue;
      if(!e->isAdjacencyCreated(i))
        continue;
      int numAdj = e->size(i);
      for (int j=0; j<numAdj;++j)
        e->get(i,j)->del(e);
    }
    del(e);
    delete e;
  } 



void mPart::DEL_oneLevel(mEntity* e)
{
  int dim = e->getLevel();
  if(e->isAdjacencyCreated(dim-1))
    {
      for(int i=0;i<e->size(dim-1);i++)
        e->get(dim-1,i)->del(e);
    }
  DEL(e);
}

mEdge* mPart::createEdge_oneLevel(mVertex *v1, mVertex *v2, GEntity *classif)
{  
  mEdge* p = (mEdge*)createEdge (v1,v2,classif);
  v1->add (p);
  v2->add (p);
  return p;
}

mFace* mPart::createFaceWithEdges_oneLevel(mEdge *e1 , mEdge *e2, mEdge *e3,
                                      GEntity *classif)
{
  mFace* f;
  f =createFaceWithEdges(e1,e2,e3,classif);
  e1->add(f);
  e2->add(f);
  e3->add(f);
  return f;
}

mTet* mPart::createTetWithFaces_oneLevel(mFace *f1 , mFace *f2, mFace *f3, mFace *f4,
                                  GEntity *classif)
{
  mTet* r = createTetWithFaces(f1,f2,f3,f4,classif);
  f1->add(r);
  f2->add(r);
  f3->add(r);
  f4->add(r);
  return r;
}
