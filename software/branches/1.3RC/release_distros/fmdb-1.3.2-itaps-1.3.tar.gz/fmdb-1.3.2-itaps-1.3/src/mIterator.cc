/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mIterator.h"
#include "mEntity.h"

  mIterator::~mIterator ()
  {
  }


  void mFullIterator::next_const()
  {
    ++(*this);
  }

  void mFullIterator::next_dynamic()
  {
//    if (beyondBeg == 1)
//    {
//      beyondBeg = 0;
      next_iter = &mFullIterator::next_const;
//    }
//    else
//    {
//      ++(*this);
//    }
  }

/*
  void mFullIterator::next ()
  {

    if (beyondBeg == 1)
    {
      beyondBeg = 0;
    }
    else
    {

      ++(*this);
//    }
  }
*/

  void mLeavesIterator :: next ()
  {
    ++(*this);
  }


  void mClassIterator :: next ()
  {
    ++(*this);
  }
  

  void mClassClosureIterator :: next()
  {
    ++(*this);
  }

  mClassClosureIterator& mClassClosureIterator :: operator++()
  {
    throw 1;
  }




