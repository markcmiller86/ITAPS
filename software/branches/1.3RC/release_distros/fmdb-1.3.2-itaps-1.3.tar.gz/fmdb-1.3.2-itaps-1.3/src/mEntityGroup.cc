/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "mFMDB.h"
#include "mEntityGroup.h"
#include "mEntity.h"
#include "FMDBInternals.h"
#include <algorithm>

mEntityGroup::mEntityGroup(int d)
{
  dim = d; 
  egTag = MD_lookupMeshDataId("EntityGroupTag");
#ifdef FMDB_PARALLEL
   bdryEnts=NULL; 
#endif
}

mEntityGroup::mEntityGroup(list<mEntity*> ents, int d)
{
  iter entit; 
  ents.unique(); 
  for(entit=ents.begin(); entit!=ents.end(); entit++) {
    container.push_back(*entit); 
  }
  
  dim = d; 
  egTag = MD_lookupMeshDataId("EntityGroupTag"); 
#ifdef FMDB_PARALLEL
   bdryEnts=NULL; 
#endif
}

mEntityGroup::~mEntityGroup()
{
  container.clear(); 
#ifdef FMDB_PARALLEL
   if(bdryEnts!=NULL)
      SAFE_DELETE(bdryEnts); 
#endif
}

void mEntityGroup::addEntity(mEntity* ent) 
{
//   entIter entit = find(container.begin(), container.end(), ent);
//   if(entit!=container.end())
//      return; 
      
   container.push_back(ent);
//   unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag"); 
   EN_attachDataPtr(ent, egTag, this); 
   return;  
}

void mEntityGroup::removeEntity(mEntity* ent)
{
   iter entit = std::find(container.begin(), container.end(), ent); 
   if(entit==container.end())
      return; 
      
   container.erase(entit);
// unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");
   ent->deleteData(egTag);
   return; 
}

void mEntityGroup::addEntity(mEntity* ent, int pos)
{
   int con_size = container.size(); 
   
   if(pos==con_size ) {
      container.push_back(ent);
      return; 
   }
      
   if(pos>con_size ){
      container.resize(pos);
      container.push_back(ent);
      return; 
   }
   
   iter entit = container.begin(); 
   for(int i=0; i<pos; ++i)
      ++entit; 
   
   entit = container.erase(entit); 
   container.insert(entit, ent); 
}

mEntity* mEntityGroup::getEntity(int pos)
{
  if(pos>=container.size())
    return 0;
 
  iter entit = container.begin() ;
  for(int i=0; i<pos; ++i)
      ++entit;
	 
  return *entit;  
}

int mEntityGroup::getEntityOrder(mEntity* ent)
{
   iter entit = std::find(container.begin(), container.end(), ent);
   if(entit==container.end()) {
     printf("   The entity is not in the entity-group.\n");
     return -1; 
   }
      
   iter entit2 = container.begin(); 
   int i=0; 
   while(entit2!=entit) { 
     ++entit2; 
     ++i; 
   }

   return i; 
}

#ifdef DEBUG
void mEntityGroup::printEntList()
{
   iter entit;
   std::cout<<std::endl; 
   for(entit = container.begin(); entit!=container.end(); ++entit)
   {
      std::cout<<" "<<*entit; 
   }
   std::cout<<std::endl; 
}
#endif

#ifdef FMDB_PARALLEL
 void mEntityGroup::getBdryEntities() 
 {
     if(bdryEnts==NULL)
       bdryEnts = new list<void*>; 
       
     mEntity* ent; 
   //  unsigned int egTag = FMDB_Util::Instance()->lookupMeshDataId("EntityGroupTag"); 
     
     for(iter entit=begin(); entit!=end(); entit++) {
       ent=*entit; 
     
       for(int i=0; i<ent->size(dim-1); i++){

        // get the downward adjacency
         mEntity* down = ent->get(dim-1, i);

        // get the upward adjacency for down
	if(down->getPClassification()) {
	   bdryEnts->push_back(down); 
	   continue; 
        }
	
        for(int j=0; j<down->size(dim); j++) {
           mEntity* adj = down->get(dim, j);
         
           void* tmp; 
           if(!EN_getDataPtr(adj, egTag, &tmp))        // not in the entity-group  
             bdryEnts->push_back(down);  	   
	   else 
	     if(tmp!= (void*)this)                     // no overlap between entity-groups 
	       bdryEnts->push_back(down); 
         }      
      }
    }
    bdryEnts->unique(); 
 }
#endif
