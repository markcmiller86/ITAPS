/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <vector>
#include "mMesh.h"
#include "mPart.h"

unsigned int mMesh::partID =0;

mMesh::mMesh(pGModel geom) 
{
  parts = new vector<mPart*>;
  theGeomModel = geom;
}

mMesh::~mMesh() 
{
  allEntSets.clear();
  clearPart();
  delete parts;
}

void mMesh::addPart (mPart* part) 
{
  parts->push_back(part);
}

void mMesh::delPart (mPart* part)
{
  partIter pit = std::find(parts->begin(), parts->end(), part);
  if (pit != parts->end())
    parts->erase(pit); 
}
 
void mMesh::clearPart()
{
  for (partIter pit=partBegin(); pit!=partEnd(); ++pit)
    delete *pit;
  parts->clear();
}

mPart* mMesh::getPart(int ith)
{  
  if (parts->size()<=ith)
    return NULL;
  else
    return (*parts)[ith];
}

bool mMesh::findTagID (unsigned int tag_id)
{
  if(tag_att_map.find(tag_id)==tag_att_map.end()) 
    return false; // tag_id not found
  return true; 
}

int mMesh::getTagID (const char *tag_name, unsigned int* tag_id)
{
  std::map <char*, unsigned int>::const_iterator it = name_tag_map.begin();
  for (; it!=name_tag_map.end(); ++it)
  {
    if (!strncmp((*it).first, tag_name, strlen(tag_name)))  // tag found
    {
      *tag_id=(*it).second;
      return 0;  // success
    }
  }
  return 1;  // failure
}

int mMesh::nameTagID (unsigned int tag_id, char* name)
{
  std::map <char*, unsigned int>::const_iterator it = name_tag_map.begin();
  for (; it!=name_tag_map.end(); ++it)
    if (it->second==tag_id)
    {
      strcpy (name, it->first);
      return 0; // sucess
    }
  return 1; // tag_id not found
}

int mMesh::typeTagID (unsigned int tag_id, int* type)
{
  if(tag_att_map.find(tag_id)==tag_att_map.end()) // tag_id not found
    return 1; // failure
  *type=tag_att_map[tag_id].first;
  return 0; // sucess
}

int mMesh::sizeTagID (unsigned int tag_id, int* size)
{
  if(tag_att_map.find(tag_id)==tag_att_map.end()) // tag_id not found
    return 1; // failure
  *size=tag_att_map[tag_id].second;
  return 0; // sucess
}

int mMesh::createTagID (const char *name, int type, int size, unsigned int* tag_id)
{
  std::map <char*, unsigned int>::const_iterator it = name_tag_map.begin();
  for (; it!=name_tag_map.end(); ++it)
    if (!strncmp((*it).first, name, strlen(name)))
      return 1; // the tag exists  

  char* name_str = new char[strlen(name)+1];
  strcpy (name_str, name);
  unsigned int new_id = (unsigned int) name_tag_map.size()+1000; 
  name_tag_map[name_str] =new_id;
  tag_att_map[new_id] = std::pair<int, int>(type, size);
  *tag_id=new_id;
//  assert(new_id==name_tag_map.size()+1000-1);
//  cout<<"mMesh::createTagID id="<<name_tag_map.size()<<", name="<<name_str<<", type="<<type<<", size="<<size<<endl;
}

int mMesh::deleteTagID (unsigned int tag_id)
{
  std::map<unsigned int, std::pair<int, int> >::iterator it_att=tag_att_map.find(tag_id);
  if (it_att==tag_att_map.end()) // tag_id not found
    return 1; // failure

  std::map <char*, unsigned int>::iterator it_name = name_tag_map.begin();
  for (; it_name!=name_tag_map.end(); ++it_name)
    if (it_name->second==tag_id)
      name_tag_map.erase(it_name);  
  tag_att_map.erase(it_att);
  return 0; // sucess
}

void mMesh::getAllTagID (std::vector<unsigned int>& ids)
{
  std::map <char*, unsigned int>::const_iterator it = name_tag_map.begin();
  for (; it!=name_tag_map.end(); ++it)
    ids.push_back((*it).second);
}

