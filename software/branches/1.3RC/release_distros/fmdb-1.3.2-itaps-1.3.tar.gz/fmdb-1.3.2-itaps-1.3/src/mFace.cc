/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mFace.h"
#include "mEntityContainer.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mUnits.h"
#include "mException.h"
#include "function_template.h"

#include <stdio.h>

using std::set;
using std::cout;

  namespace {
    int faceCounter = 0;
  }

mFace::mFace()
  : mEntity()
{
}

mFace::mFace(mVertex *v1, mVertex *v2, mVertex *v3,GEntity *classification)
  : mEntity ()
   , up_adj_size(0), up_adj(0) 
{
  typ = TRI;
    down_adj[0] = v1; 
    down_adj[1] = v2;
    down_adj[2] = v3;
    down_adj_dim = 0; 
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif
}

mFace::mFace(mEdge *e1, mEdge *e2, mEdge *e3,GEntity *classification, int *dir)
  : mEntity ()
    , up_adj_size(0), up_adj(0) 
{
  typ = TRI;
  down_adj_dim=1; 
  if (!dir)
    {
      down_adj[0] = e1;
      down_adj[1] = e2;
      down_adj[2] = e3; 
    }
  else
    {
      down_adj[0] = e1; 
      mVertex *v0=(mVertex*)e1->get(0,0);
      if( dir[0]>0 ) 
	{
	  if( (mVertex*)e2->get(0,0)==v0 || (mVertex*)e2->get(0,1)==v0 )
	    {
	      down_adj[1] = e3;
	      down_adj[2] = e2; 
	    }
	  else
	    {
	       down_adj[1] = e2;
	       down_adj[2] = e3;
	    }
	}
      else
	{
	  if( (mVertex*)e2->get(0,0)==v0 || (mVertex*)e2->get(0,1)==v0 )
	    {
	       down_adj[1] = e2;
	        down_adj[2] = e3;
	    }
	  else
	    {
	       down_adj[1] = e3;
	       down_adj[2] = e2;
	    }
	}
    }

#ifndef _POINTER2INT_
  theClassification = classification;
#else
     gType = GEN_type(classification);
     gTag = GEN_tag(classification);
#endif
}

mFace::mFace(mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4, GEntity *classification)
  : mEntity ()
    , up_adj_size(0), up_adj(0)
{
  typ = QUAD;
   
   down_adj[0]=v1;
   down_adj[1]=v2; 
   down_adj[2]=v3; 
   down_adj[3]=v4; 
   down_adj_dim = 0; 
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif
}

mFace::mFace(mEdge *e1, mEdge *e2, mEdge *e3, mEdge *e4, GEntity *classification, int *dir)
   : mEntity ()
    , up_adj_size(0), up_adj(0)
{
  typ = QUAD; 
  down_adj_dim =1; 

  if (!dir || dir[0] > 0)
    {
          down_adj[0]=e1; 
          down_adj[1]=e2;
	  down_adj[2]=e3;
	  down_adj[3]=e4; 
    }
  else
    {
        down_adj[0]=e4;
	down_adj[1]=e3;
	down_adj[2]=e2;
	down_adj[3]=e1;		      
    }


#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

  mVertex *v1 = (mVertex*)get(0,0);
  mVertex *v2 = (mVertex*)get(0,1);
  mVertex *v3 = (mVertex*)get(0,2);
  mVertex *v4 = (mVertex*)get(0,3);
  if(!v1 || !v2 || !v3 || !v4)
    {
      char text[256];
      sprintf(text,"\terror in the creation of a quad with its edges\n\tedges (%d %d), (%d %d), (%d %d) and (%d %d) cannot be nested",
	      e1->vertex(0)->getId(),e1->vertex(1)->getId(),
	      e2->vertex(0)->getId(),e2->vertex(1)->getId(),
	      e3->vertex(0)->getId(),e3->vertex(1)->getId(),
	      e4->vertex(0)->getId(),e4->vertex(1)->getId()
	      );
      throw new mException (__LINE__,__FILE__,text);
    }
}

int mFace:: getNbTemplates (int what) const
{
  return(typ == TRI)?3:4;
}

mEntity *mFace::getTemplate(int ith, int what, int with)const
{
#ifndef _POINTER2INT_
  GEntity* classification = theClassification; 
#else
  GEntity* classification = getClassification();  
#endif
  const int nbT = (typ == TRI)?3:4;

  switch(what)
    {
    case 0:
	{
	  if(down_adj_dim==0)
	    return down_adj[ith];
	  
	  if(down_adj_dim==1)
	  {
	    mEdge *e1 = (mEdge*)get(1,(ith+nbT-1) % nbT);
	    mEdge *e2 = (mEdge*)get(1,ith);
	    return e1->commonVertex(e2);
	  }
	}
      break;
    case 1:
	{
	  return new mEdge ((mVertex*)get(0,ith),
			    (mVertex*)get(0,(ith+1)%(nbT)),
			    classification);
	}
      break;
    default:
      cout << "mFace::getTemplate error : level " << what << " is incorrect\n";
      throw 1;
      return 0;
    }
}

mVertex * mFace::commonVertex (mFace *f1, mFace *f2)
{
  const int thisSize = getNbTemplates(0);
  const int f1Size   = f1->getNbTemplates(0);
  const int f2Size   = f2->getNbTemplates(0);
  
  mVertex* vtx[2]; 
  mVertex * vertex;

  mEdge* e = commonEdge(f1);
  if(e){
    for(int i=0;i<2; i++)
      vtx[i] = (mVertex*)e->get(0,i); 
    
    for(int i=0;i<f2Size;i++){
      vertex = (mVertex*)f2->get(0,i);
      if( (vtx[0]==vertex) ||(vtx[1]==vertex ))
	return vertex; 
    }
  }  
  else {
    e = commonEdge(f2);
    if(e){
      for(int i=0;i<2; i++)
	vtx[i] = (mVertex*)e->get(0,i); 
      
      for(int i=0;i<f1Size;i++){
	vertex = (mVertex*)f1->get(0,i);
	if( (vtx[0]==vertex) ||(vtx[1]==vertex ))
	  return vertex; 
      }
    }
    else{
      e = f1->commonEdge(f2);
      if(e){
	for(int i=0;i<2; i++)
	  vtx[i] = (mVertex*)e->get(0,i); 
	
	for(int i=0;i<thisSize;i++){
	  vertex = (mVertex*)get(0,i);
	  if( (vtx[0]==vertex) ||(vtx[1]==vertex ))
	    return vertex; 
	}
      }  
      else{
	
	mVertex * thisVertices[5];
	mVertex * f1Vertices[5];
	mVertex * f2Vertices [5];
	
	{  for(int i=0;i<thisSize;i++)thisVertices[i] = (mVertex*)get(0,i);}
	{  for(int i=0;i<f1Size;i++)f1Vertices[i] = (mVertex*)f1->get(0,i);}
	{  for(int i=0;i<f2Size;i++)f2Vertices[i] = (mVertex*)f2->get(0,i);}
	
	for( int i=0;i<thisSize;i++)
	  {
	    if(std::find(f1Vertices,f1Vertices+f1Size,thisVertices[i]) != f1Vertices+f1Size &&
	       std::find(f2Vertices,f2Vertices+f2Size,thisVertices[i]) != f2Vertices+f2Size)
	      return thisVertices[i];
	  }
      }
    }
  }
  
  return 0;
}

mEdge * mFace::commonEdge (mFace *f1)
{
  if(!isAdjacencyCreated(1))return 0;

  mEdge* thisEdges[5]; 
  mEntity* e1; 
  int numEdges = size(1); 

  for(int i=0; i<numEdges; i++)
    thisEdges[i]=(mEdge*)get(1,i); 

  for(int i=0; i<f1->size(1); i++){
    e1=f1->get(1,i);
    if(std::find(thisEdges, thisEdges+numEdges, e1)!= thisEdges+numEdges)
      return (mEdge*)e1; 
  }

  return 0;
}

mEdge * mFace::subtractEdges (mEdge* e1, mEdge* e2)
{
  if(!isAdjacencyCreated(1))return 0;

  int numEdges = size(1);

  for(int i=0; i<numEdges; i++) {
    mEdge* ent = (mEdge*)get(1,i);
    if(ent!=e1 && ent!=e2)
      return ent;
  }

  return 0;
}


mFace::~mFace()
{
}

int mFace::getLevel()const
{
  return 2;
}

  // adjacency related    
   void mFace::add (mEntity* m)
   {
      add_entity_to_array<mEntity*>(up_adj, m, up_adj_size);	 
   }
     
     void mFace::appendUnique (mEntity* m)
     {
        APPEND_UNIQUE_ENTITY(m); 
     }
     
     void mFace::del (mEntity* m)
     {
        del_entity_from_array<mEntity*>(up_adj, up_adj_size, m);
     }
     
       mEntity* mFace::get(int what, int ith)const
       {
	 if(what==(int)down_adj_dim)
	    return down_adj[ith];

	 if(what==3)
            return up_adj[ith]; 

	 return getTemplate(ith, what, 0); 
       }
       
       void mFace::deleteAdjacencies(int what)
       {
	  if(what==3)
	    free_array<mEntity*>(up_adj, up_adj_size);
       }
       
       mEntity * mFace::find(mEntity* m) const
       {
	 int dim = m->getLevel(); 

	 if(dim==3)
            return find_entity_in_array<mEntity*>(up_adj, up_adj_size, m);
	 if(dim==1)
	    return find_entity_in_array<mEntity*>((mEntity**)down_adj,(typ == TRI)?3:4, m);
      }
