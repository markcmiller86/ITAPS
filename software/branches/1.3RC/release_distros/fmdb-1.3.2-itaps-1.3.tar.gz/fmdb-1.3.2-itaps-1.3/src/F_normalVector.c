/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "MeshEntTools.h"
#include "MeshAdjTools.h"

/* Computes the normal vector of the face */

void F_normalVector(pFace face, int dir,double* normal)

{

pPList vertices;
double xyz[3][3],x1[3],x2[3];
int i;
pVertex vertex;

 vertices=F_vertices(face,dir);

 for(i=0;i<PList_size(vertices) && i<3;++i){
  vertex=(pVertex)PList_item(vertices,i);
  V_coord(vertex,xyz[i]);
 }
 PList_delete(vertices);
 diffVt(xyz[1],xyz[0],x1);
 diffVt(xyz[2],xyz[0],x2);
 crossProd(x1,x2,normal);
}
 
