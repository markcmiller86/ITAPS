/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mIdGenerator.h"
#ifdef FMDB_PARALLEL
#include "ParUtil.h"
#endif

mIdGenerator::mIdGenerator()
{
#ifdef FMDB_PARALLEL
  nbPE = ParUtil::Instance()->size();
  myPE = ParUtil::Instance()->rank()+1;
  maximumValue = myPE - nbPE;
 // printf("nbPE: %d, myPE: %d, maxValue: %d,  in mIdGenerator()\n", nbPE, myPE, maximumValue);
#else
  maximumValue=0;
#endif
}
void mIdGenerator::addId(int Id){ Q.push(Id);}

int mIdGenerator::generateId()
{
#ifdef FMDB_PARALLEL
  maximumValue += nbPE;
  return maximumValue;
#else
  return ++maximumValue; 
#endif
}

mIdGenerator::~mIdGenerator(){}
int mIdGenerator::getMaxValue() const
{
  return maximumValue;
}

void mIdGenerator::setMaxValue(int v)
{
  maximumValue = (maximumValue >v)?maximumValue:v;
}

#ifdef FMDB_PARALLEL
void mIdGenerator::pmSetMaxValue(int v)
{ 
  maximumValue=v;
}
#endif

#ifdef FMDB_PARALLEL
void mIdGenerator::update()
{
  nbPE = ParUtil::Instance()->size();
  myPE = ParUtil::Instance()->rank()+1;
  maximumValue = myPE - nbPE;
//  printf("nbPE: %d, myPE: %d, maxValue: %d,  in mIdGenerator()\n", nbPE, myPE, maximumValue);
}
#endif

