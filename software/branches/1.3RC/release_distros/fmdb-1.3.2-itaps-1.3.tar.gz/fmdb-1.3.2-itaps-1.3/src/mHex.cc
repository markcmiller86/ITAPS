/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mHex.h"
#include "mEntityContainer.h"
#include "mException.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include <stdio.h>
#include "function_template.h"


mHex::mHex()
  : mRegion()  
{
}

short int mHex::Hev[12][2] = {{0,1},{1,2},{2,3},{3,0},
                         {0,4},{1,5},{2,6},{3,7},
                         {4,5},{5,6},{6,7},{7,4}};
short int mHex::Hfv[6][4] =   {{0,3,2,1},
                         {0,1,5,4},
                         {1,2,6,5},
                         {2,3,7,6},
                         {3,0,4,7},
                         {4,5,6,7}};
short int mHex::Hfe[6][4] =   {{3,2,1,0},
                          {0,5,8,4},
                          {1,6,9,5},
                          {2,7,10,6},
                          {3,4,11,7},
                          {8,9,10,11}};
short int mHex::Hve[8][2] = {{0,3},{0,1},{1,2},{2,3},{4,8},{5,9},{6,10},{7,11}};
short int mHex::Hvf[8][3] = {{0,1,4},{0,1,2},{0,2,3},{0,3,4},{1,4,5},{1,2,5},{2,3,5},{3,4,5}};
short int mHex::Hef[12][2] = {{0,1},{0,2},{0,3},{0,4},
                         {1,4},{1,2},{2,3},{3,4},
                         {1,5},{2,5},{3,5},{4,5}};

mHex::mHex(mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4,
	   mVertex *v5, mVertex *v6, mVertex *v7, mVertex *v8, 
	   GEntity *classification)
  : mRegion ()  
{
    down_adj_dim = 0; 
     down_adj[0]=(mEntity*)v1;
     down_adj[1]=(mEntity*)v2;
     down_adj[2]=(mEntity*)v3;
     down_adj[3]=(mEntity*)v4;
     down_adj[4]=(mEntity*)v5;
     down_adj[5]=(mEntity*)v6;
     down_adj[6]=(mEntity*)v7;
     down_adj[7]=(mEntity*)v8;
     
//  theClassification = classification;
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

}

mHex::mHex(mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, mFace *f6, GEntity *classification)
  : mRegion () 
{

   down_adj_dim = 2; 
   down_adj[0]=(mEntity*)f1;
   down_adj[1]=(mEntity*)f2;
   down_adj[2]=(mEntity*)f3;
   down_adj[3]=(mEntity*)f4;
   down_adj[4]=(mEntity*)f5;
   down_adj[5]=(mEntity*)f6;
   
//  theClassification = classification;
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

}

int mHex:: getNbTemplates (int what) const
{
  switch(what)
    {
    case 0: return 8;
    case 1: return 12;
    case 2: return 6;
      
    default : 
      {
	char text[256];
	sprintf(text,"trying to ask for adjacency list of level %d for an hex when it's not created",what);
	throw new mException (__LINE__,__FILE__,text);
      }
    }
}



mEntity *mHex::getTemplate(int ith, int what, int with)const
{
#ifndef _POINTER2INT_
  GEntity* classification = theClassification;
#else
  GEntity* classification = getClassification();  
#endif
  switch(what)
    {
    case 0:
        if(down_adj_dim==0)
	   return down_adj[ith];

         if(down_adj_dim==1)
	 {
	    mEdge *e1 = (mEdge*)get(1,Hve[ith][0]);
	    mEdge *e2 = (mEdge*)get(1,Hve[ith][1]);
	    return e1->commonVertex(e2);
	 }

	 if(down_adj_dim==2)
	{
	  mFace *f1 = (mFace*)get(2,Hvf[ith][0]);
	  mFace *f2 = (mFace*)get(2,Hvf[ith][1]);
	  mFace *f3 = (mFace*)get(2,Hvf[ith][2]);
	  return f1->commonVertex(f2,f3);
	}
      break;
    case 1:
        if(down_adj_dim==2)
	{
	  mFace *f1 = (mFace*)get(2,Hef[ith][0]);
	  mFace *f2 = (mFace*)get(2,Hef[ith][1]);
	  mEdge *e =  f1->commonEdge(f2);
	  if(e) return e;
	}
	return new mEdge ((mVertex*)get(0, Hev[ith][0]),
			  (mVertex*)get(0, Hev[ith][1]),
		           classification);
      break;
    case 2:
      if(with == 0)
	{
	    return new mFace ((mVertex*)get(0,Hfv[ith][0]),
				(mVertex*)get(0,Hfv[ith][1]),
				(mVertex*)get(0,Hfv[ith][2]),
				(mVertex*)get(0,Hfv[ith][3]),
				classification);
	}
      else if (with == 1)
	{
	  return new mFace ((mEdge*)get(1, Hfe[ith][0]),
			    (mEdge*)get(1, Hfe[ith][1]),
			    (mEdge*)get(1, Hfe[ith][2]),
			    (mEdge*)get(1, Hfe[ith][3]),
			    classification);
	}
      else throw new mException (__LINE__,__FILE__,"weird adjacency asked");
    }
  return 0;
}

mHex::~mHex()
{
  
}

    // adjacency related

   int mHex::size (int what)const
   {
      return getNbTemplates(what);
   }

   mEntity* mHex::get(int what, int ith)const
   {
      if(what==down_adj_dim)
         return down_adj[ith];

      return getTemplate(ith, what, 0);
   }

   mEntity * mHex::find(mEntity* m) const
   {
     find_entity_in_array<mEntity*>((mEntity**)down_adj, 6, m);
   }

