/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "MeshModel.h"
#include "mEdge.h"
#include "mPoint.h"
#include "mPart.h"
#include "mVertex.h"

#include "modeler.h"

#define PI 3.1415926535897932

void MeshModel_middlePoint (mPart* part, pEdge pE,     // an edge to be split
 double * pin)   // the boundary location of the vertex created in splitting
  
{

  mEdge *ed = (mEdge*) pE;
  SCOREC::Util::mPoint p1 = ed->vertex(0)->point();
  SCOREC::Util::mPoint p2 = ed->vertex(1)->point();
      
  pGEntity ge = pE->getClassification();   
  
  SCOREC::Util::mPoint pp ((p1+p2)*0.5);

  mClassIterator it = part->begin (GEN_type(ge), GEN_tag(ge), GEN_type(ge));
  mClassIterator ite = part->end  (GEN_type(ge), GEN_tag(ge), GEN_type(ge));      
      double min_sum_d = 1.e20;
  /// model edge 
      if (GEN_type(ge) == 1)
	{	  
	  while (it != ite)
	    {
	      mEdge *e = (mEdge *) *it;
	      SCOREC::Util::mPoint p1model = e->vertex(0)->point();
	      SCOREC::Util::mPoint p2model = e->vertex(1)->point();
	      
	      SCOREC::Util::mPoint pmid ((p1model+p2model)*0.5);

	      SCOREC::Util::mVector v1(pmid(0)-p1(0),pmid(1)-p1(1),pmid(2)-p1(2));
	      SCOREC::Util::mVector v2(pmid(0)-p2(0),pmid(1)-p2(1),pmid(2)-p2(2));

	      double sum = fabs(v1.normValue() - v2.normValue());

	      if (sum < min_sum_d)
		{
		  min_sum_d = sum;
		  pp = pmid;
		}
	      ++it;
	    }
	}
  pin[0] = pp(0);
  pin[1] = pp(1);
  pin[2] = pp(2);
}

void Analytic_middlePoint (pMesh mesh, pEdge pE,     // an edge to be split
                           double *par,
                           double *pin)   // the boundary location of the vertex created in splitting

{

  mEdge *ed = (mEdge*) pE;

  double u1, u2;
  u1 = P_param1(V_point(ed->vertex(0)));
  u2 = P_param1(V_point(ed->vertex(1)));

  // has to take care of the periodicity
  if(fabs(u1) < 1.e-7 || fabs(u2) < 1.e-7) {
    if((fabs(u1)+fabs(u2)) > PI)
      u1 += 2.*PI;
  }

  par[0] = (u1+u2)/2.;

  GE_point((pGEdge)E_whatIn(pE), par[0], pin);
  return;
}

void MeshModel_subdivision_middlePoint( pMesh mesh, pEdge edge, double *xyz) {
//  getISSPoint(mesh, edge, 0., 0., xyz);
}
