/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mEntityContainer.h"
#include "mEntity.h"
#include "mVertex.h"
#include "mException.h"
#include "mIterator.h"

#include <stdio.h>

using std::cout;
using std::list;

  mPartEntityContainer::mPartEntityContainer()
  {
    for(int i=0;i<_DIMS_;i++)mEntities[i] = new CONTAINER;
  }
  mPartEntityContainer::~mPartEntityContainer()
  {
    for(int i=0;i<_DIMS_;i++)delete mEntities[i];
  }
  
  mPartEntityContainer::iter mPartEntityContainer::begin(int what) const 
  {
    return mEntities[what]->begin();
  }
  
  mPartEntityContainer::iter mPartEntityContainer::end(int what)   const 
  {
    return mEntities[what]->end();
  }
  
  void mPartEntityContainer::add(mEntity* e)
  { 
    mEntities[e->getLevel()]->insert(e);
  }

  void mPartEntityContainer::del(mEntity* e)
  { 
    list<mFullIterator*>::iterator cit = curIterators[e->getLevel()].begin();
    for (; cit != curIterators[e->getLevel()].end(); cit++)
    {
      if ((*cit)->get() == e)
      {
        (*cit)->erase_adj();
      }
    }

    mEntities[e->getLevel()]->erase(e);
  }

  int mPartEntityContainer::size(int what) const 
  { 
    return mEntities[what]->size();
  } 
  
  mEntity* mPartEntityContainer::find (mEntity *e) const 
  {
    iter it=mEntities[e->getLevel()]->find(e);
    if(it!=end(e->getLevel()))
      return(*it);
    else
      return(mEntity*)0;
  }
  
  bool EntityLessThanKey::operator()(mEntity* ent1, mEntity* ent2) const 
  {
    return ent1->lessthan(ent2);
  }

  mFullIterator* mPartEntityContainer::getIterator(int dim)
  {
    mFullIterator *it = new mFullIterator(mEntities[dim]->begin(), mEntities[dim]->end(), this, dim);
    curIterators[dim].push_back(it);
    return it;
  }

  mFullIterator* mPartEntityContainer::getIterator(int dim, pGEntity gent)
  {
    mFullIterator *it = new mFullIterator(this, dim, gent);
    curIterators[dim].push_back(it);
    return it;
  }

  void mPartEntityContainer :: deleteIterator (mFullIterator *it)
  {
    std::list<mFullIterator*>::iterator iter;
    int dim = it->get_dim();
    iter = std::find(curIterators[dim].begin(), curIterators[dim].end(), it);
    delete *iter;
    curIterators[dim].erase(iter);
  }
