/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "FMDBfwd.h"
#include "mTet.h"
#include "mEntityContainer.h"
#include "mException.h"
#include "mVertex.h"
#include "mVector.h"
#include "mEdge.h"
#include "mFace.h"
#include "FMDB_Internals.h"
#include <stdio.h>
#include <math.h>
#include <iostream>
#include "function_template.h"

using std::cout;
using std::endl;

  short int mTet::Tev[6][2] = {{0,1},{1,2},{2,0},{0,3},
                        {1,3},{2,3}};

  // gives faces as a function of vertices
  short int mTet::Tfv[4][3] =   {{0,1,2},
                          {0,1,3},
                          {1,2,3},
                          {0,2,3}};

  // gives faces as a function of edges (composition of the 2 first ones)
  short int mTet::Tfe[4][3] = {{0,1,2},{0,4,3},{1,5,4},{2,3,5}};

  // --- INVERT TABLES ---
  // gives vertices as intersection of 2 edges
  short int mTet::Tve[4][2] = {{0,2},{0,1},{1,2},{3,4}};

  // gives edges as intersection of 2 faces
  short int mTet::Tef[6][2] = {{0,1},{0,2},{0,3},{1,3},{1,2},{2,3}};

  // gives vertices as intersection of 3 faces
  short int mTet::Tvf[4][3] = {{0,1,3},{0,1,2},{0,2,3},{1,2,3}};

  static double Volume (mTet *tet)
  {
    mVertex *v1 = (mVertex*)tet->get(0,0);
    mVertex *v2 = (mVertex*)tet->get(0,1);
    mVertex *v3 = (mVertex*)tet->get(0,2);
    mVertex *v4 = (mVertex*)tet->get(0,3);

    SCOREC::Util::mVector v12 (v1->point()-v2->point());
    SCOREC::Util::mVector v13 (v1->point()-v3->point());
    SCOREC::Util::mVector v14 (v1->point()-v4->point());
    
    return -(1./6.) * ((v12 % v13) * v14);
  }
  
  mTet::mTet()
    : mRegion()
  {
  }
  
  mTet::mTet(mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4, GEntity *classification)
    : mRegion()
  {
   down_adj_dim = 0; 
   down_adj[0]=v1; 
   down_adj[1]=v2;
   down_adj[2]=v3;
   down_adj[3]=v4; 
   
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

    double volume = Volume(this);
    if(volume < 0.0)
      {
	    down_adj[0]=v2;  
	    down_adj[1]=v1;
	    down_adj[2]=v3;
	    down_adj[3]=v4;
	    
        //cout<<"("<<M_Pid()<<") ERROR: negative region "<<getUid()<<" created\n" ;      
      } 
  }

mTet::mTet(mFace *f1, mFace *f2, mFace *f3, mFace *f4, GEntity *classification)
  : mRegion ()
{
       down_adj_dim = 2; 	
       down_adj[0]=f1;   
       down_adj[1]=f2;      
       down_adj[2]=f3; 
       down_adj[3]=f4;
		
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification);
#endif

  if(Volume(this) < 0.0)
    {
      down_adj[0]=f2;            
      down_adj[1]=f1;                        
      down_adj[2]=f3;
      down_adj[3]=f4;
    }  
}

int mTet:: getNbTemplates (int what) const
{
  switch(what)
    {
    case 0: return 4;
    case 1: return 6;
    case 2: return 4;
    default : throw new mException (__LINE__,__FILE__,"");
    }
}

mEntity *mTet::getTemplate(int ith, int what, int with)const
{
#ifndef _POINTER2INT_
  GEntity* classification = theClassification;
#else
  GEntity* classification = getClassification();  
#endif

  switch(what)
    {
    case 0:
        if(down_adj_dim==0)
	 return down_adj[ith];

        if(down_adj_dim==1)
	{
	    mEdge *e1 = (mEdge*)get(1,Tve[ith][0]);
	    mEdge *e2 = (mEdge*)get(1,Tve[ith][1]);
	    return e1->commonVertex(e2);	    
	}

	if(down_adj_dim==2)
	{
	  mFace *f1 = (mFace*)get(2,Tvf[ith][0]);
	  mFace *f2 = (mFace*)get(2,Tvf[ith][1]);
	  mFace *f3 = (mFace*)get(2,Tvf[ith][2]);
	  return f1->commonVertex(f2,f3);
	}
      break;
    case 1:
        if(down_adj_dim==2)
	{
	  mFace *f1 = (mFace*)get(2,Tef[ith][0]);
	  mFace *f2 = (mFace*)get(2,Tef[ith][1]);
	  mEdge *e =  f1->commonEdge(f2);
	  if(e) return e;
	} 

	return new mEdge ((mVertex*)get(0, Tev[ith][0]),
			  (mVertex*)get(0, Tev[ith][1]),
			   classification);
      break;
    case 2:
      if(with == 0)
	{
	      return new mFace ((mVertex*)get(0,Tfv[ith][0]),
				(mVertex*)get(0,Tfv[ith][1]),
				(mVertex*)get(0,Tfv[ith][2]),
				classification);
      }
      else if (with == 1) 
	return new mFace ((mEdge*)get(1,Tfe[ith][0]),
			  (mEdge*)get(1,Tfe[ith][1]),
			  (mEdge*)get(1,Tfe[ith][2]),
			  classification);
    default : throw new mException (__LINE__,__FILE__,"this tet template is not done");
    }
  return 0;
}

mTet::~mTet()
{
  
}

     // adjacency related
   
   int mTet::size (int what)const
   {
      return getNbTemplates(what); 
   }

   mEntity* mTet::get(int what, int ith)const
   {
      if(what==down_adj_dim)
	 return down_adj[ith]; 

      return getTemplate(ith, what, 0);
   }

   // void mTet::getAppendPList(int what, pPList pl) const;

   mEntity * mTet::find(mEntity* m) const
   {
      find_entity_in_array<mEntity*>((mEntity**)down_adj, 4, m);
   }
