/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <string.h>
#include "mFMDB.h"
#include "mMeshIO.h"
#include "mPart.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mException.h"
#include "FMDB_OwnerManager.h"
#include "ParUtil.h"
#include "M_writeVTKFile.h"
#include "modeler.h"

#include <utility>
#include <iostream>
#include<iomanip>
#include <fstream>
#include <stdio.h>

using std::vector;
using std::cout;
using std::ofstream;
using std::ostream;
using std::istream;
using std::endl;
using namespace std;


bool isEqual(double x, double y)
{  
  if (fabs(x)<accuracy && fabs(y)<accuracy) return true;
  if (fabs((x-y)/(0.5*(x+y))) < accuracy) return true;
  return false;
}

  std::auto_ptr<FMDB_Util> FMDB_Util::instance;

  FMDB_Util::FMDB_Util()
  {
    _ATTPARAMETRIC = lookupMeshDataId ("_parametric");
    _ATTPARENT = lookupMeshDataId ("_parent");
    _ATTFMOD = lookupMeshDataId   ("_fmod");
    _ATTEMOD = lookupMeshDataId   ("_emod");
    _ATTID   = lookupMeshDataId   ("_id");
    _ATTDN   = lookupMeshDataId   ("_dn");
    _ATTSIZE = lookupMeshDataId   ("_size");
    _ATT1 = lookupMeshDataId   ("_ATT1");
    _ATT2 = lookupMeshDataId   ("_ATT2");
    _ATT3 = lookupMeshDataId   ("_ATT3");
    _ATTWEIGHT = lookupMeshDataId   ("_weight");
    _Node = lookupMeshDataId   ("_node");
  }

  FMDB_Util::~FMDB_Util()
  {
  }

  FMDB_Util* FMDB_Util::Instance()
  {
    if(!instance.get())
      {
	instance.reset(new FMDB_Util);
      }
    return instance.get();
  }

  int FMDB_Util::import (mMesh* mesh, const char *fileName)
  {
    char ext[6];
    int err = SCUtil_SUCCESS;
    strcpy(ext,fileName+(strlen(fileName)-3));
    pPart part;
    FMDB_Mesh_GetPart (mesh, 0, part);

    if(!strcmp(ext,"cdf"))
      importNCDF(part, fileName);
#ifdef NCDF64
    else if(!strcmp(ext, ".nc"))
      importNCDFBin(part, fileName, 1);
#endif
    else if(!strcmp(ext,"vtk"))
      err = importVTK(part, fileName);
    else
      err = importSMS(mesh, fileName);
    if(err != SCUtil_SUCCESS)
      return err;
#ifdef FMDB_PARALLEL
      ParUtil::Instance()->set_maxMeshDim(part->getDimension());
#endif
   return SCUtil_SUCCESS;
  }
  
  void FMDB_Util::ex_port (mMesh *mesh, const char *fName)
  {
    char ext[6];
    char text[256];
    strcpy(ext,fName+(strlen(fName)-4));
    pPart part;
    FMDB_Mesh_GetPart (mesh, 0, part);

    if(!strcmp(ext,".sms"))
      exportSMS(mesh, fName);      
    else if(!strcmp(ext,".vtk"))
      M_writeVTKFile(part, fName);
    else
    {
      sprintf(text,"unknown extension %s in file %s",ext,fName);
      throw mException(__LINE__,__FILE__,text);
    }
  }
