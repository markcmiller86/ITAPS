/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <string.h>

#include "mPart.h"
#include "mVertex.h"
#include "mEdge.h"
#include "mFace.h"
#include "mTet.h"
#include "mHex.h"
#include "mPrism.h"
#include "mPyramid.h"
#include "mPoint.h"
#include "mException.h"
#include "FMDB_OwnerManager.h"
#include "ParUtil.h"
#include "mBuildAdj.h"
#include "mFMDB.h"
#include "pmModel.h"

#include "oldFMDB.h"
#include "FMDBInternals.h"

// added by Jie and Eunyoung, 09/2003
#include "NullModel.h"
#include "NullVertex.h"
#include "NullEdge.h"
#include "NullFace.h"
#include "NullRegion.h"
#include "modeler.h"
#include "iUtil.h"

using std::list;
using std::set;
using std::istream;
using std::ostream;
using std::cout;
using std::endl;
using std::find; 

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
  //////////////////////////////////////////////////////////////////////

  mPart::mPart(int id, pGModel model, mMesh* mesh)
    : iD(id), mesh_instance(mesh), theSolidModel (model),
      classif_fp(GM_entityByTag), representationFlag(0)
      ,mAttachableDataContainer()
      , dimension(0) 
  {
    theOwnerManager = new FMDB_OwnerManager;
#ifdef FMDB_PARALLEL
    pmModel::Instance()->setMesh(this);
#endif    
#ifdef DMUM
    DMUM_on = false;
    for (int i=0; i<4; ++i)
      count_trvs[i]=0;
#endif
  }

  mPart::~mPart()
  {
    for(int i=3;i>=0;i--)
      {
	iterall it  = beginall(i);
	iterall ite = endall(i);
	for(;it != ite;++it)
	  {
	    delete *it;
	  }
      }
    delete theOwnerManager;
  }
  int mPart::size(int what) const
  { return allEntities.size(what);}

  mPart::iterall mPart::beginall(int what) const
  {
    return allEntities.begin(what);
  }

  mPart::iterall mPart::endall(int what) const
  {
    return allEntities.end(what);
  }

  mPart::iter mPart::begin(int what) const
  {
    return mLeavesIterator(beginall(what),endall(what));
  }

  mPart::iter mPart::end(int what) const
  {
    return mLeavesIterator(endall(what),endall(what));
  }

  mClassIterator mPart::begin(int what, int which, int onwhat) const
  {
    return mClassIterator(beginall(what),endall(what),which, onwhat);
  }

  mClassIterator mPart::end(int what, int which, int onwhat) const
  {
    return mClassIterator(endall(what),endall(what),which, onwhat);
  }

  mVertex *mPart::getVertex (int theId)
  {
  //  mEntity* ent;
//     for (mPart::iterall it=beginall(0); it!=endall(0); ++it) {
//       ent = *it;
//       if(ent->getId()==theId)
//         return (mVertex*)ent;
//     }                    // not efficient 

    static mVertex v(0,SCOREC::Util::mPoint(0,0,0),0);
    v.setId(theId);
    return (mVertex*)find(&v);
  }

  mEdge *mPart::getEdge (mVertex *v1, mVertex *v2)
  {
    static mEdge e(0,0,0);
    e.setVertices(v1,v2);
    return (mEdge*)find(&e);
  }
               
  mFace *mPart::getTri (mVertex *v1, mVertex *v2, mVertex *v3)
  {
    mFace f(v1,v2,v3,0);
    return (mFace*)find(&f);
  }


  mFace *mPart::getQuad (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4)
  {
    mFace f(v1,v2,v3,v4,0);
    return (mFace*)find(&f);
  }


  mTet *mPart::getTet (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4)
  {
    mTet t(v1,v2,v3,v4,0);
    return (mTet*)find(&t);
  }


  mHex *mPart::getHex (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4,
		       mVertex *v5, mVertex *v6, mVertex *v7, mVertex *v8)
  {
    mHex h(v1,v2,v3,v4,v5,v6,v7,v8,0);
    return (mHex*)find(&h);
  }

  mVertex* mPart::createVertex (int theId, const double x, const double y, const double z, 
  			pGEntity classif)
  {
   mVertex* theNewVertex = new mVertex(theId,SCOREC::Util::mPoint(x,y,z),classif);
   add(theNewVertex);
   theIdGenerator.setMaxValue(theId);
   return theNewVertex;	  
  }

  mVertex* mPart::createVertex_noUpdateId(int theId, const double x, const double y, const double z, 
  			pGEntity classif)
  {
    mVertex* theNewVertex = new mVertex(theId,SCOREC::Util::mPoint(x,y,z),classif);
    add(theNewVertex);
    return theNewVertex;
  }


  // create entity-group
  mEntityGroup* mPart :: createEntGrp(int dim)
  {
    mEntityGroup* eg = new mEntityGroup(dim); 
    allEntGrps.push_back(eg);
    return eg; 
  }

  mEntityGroup* mPart :: createEntGrp(list<mEntity*> ents, int dim) 
  {
    mEntityGroup* eg = new mEntityGroup(ents, dim);
    allEntGrps.push_back(eg);

    list<mEntity*>::iterator listit; 

    unsigned int egTag=MD_lookupMeshDataId("EntityGroupTag"); 
    for(listit=ents.begin(); listit!=ents.end(); listit++) {
      mEntity* ent=*listit; 
      EN_attachDataPtr(ent, egTag, eg); 
    }
    
    return eg; 
  }

  void  mPart :: deleteEntGrp(mEntityGroup* entGrp, int force) 
  {
    iterEntGrp egIter = std::find(allEntGrps.begin(), allEntGrps.end(), entGrp);
    if(egIter!=allEntGrps.end())
       allEntGrps.erase(egIter); 
    
    if(force==1) {               
      unsigned int egTag=MD_lookupMeshDataId("EntityGroupTag");

    // delete attached data on interior entities 
      for(mEntityGroup::iter entIt=entGrp->begin(); entIt!=entGrp->end(); entIt++) {
        mEntity* ent = *entIt;
        ent->deleteData(egTag);
      }
    }
    
    delete entGrp;
  }

  int mPart :: getNewVertexId()
  {
    return theIdGenerator.generateId();
  }

  void mPart :: setNewVertexId(int theId)
  {
    theIdGenerator.setMaxValue(theId);
  }

#ifdef FMDB_PARALLEL
  void mPart :: pmSetNewVertexId(int theId)
  {
    theIdGenerator.pmSetMaxValue(theId);
  }
#endif

  mVertex *mPart::createVertex (const double x, const double y, const double z, 
  			pGEntity classif)
  {
    return createVertex(getNewVertexId(),x,y,z,classif);
  }

  mEdge *mPart::createEdge (int i1, int i2, pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    if(!v1 || !v2)
      {
	char text[256];
	sprintf(text,"unknown verex id's %d(%p) %d(%p) in new edge creation\n",i1,v1,i2,v2);
	throw new mException (__LINE__,__FILE__,text);
      }
    return createEdge(v1,v2,classif);
  }

  void mPart :: DEL (mEntity *e)
  {
    del(e);
    delete e;
  } 

  mEdge *mPart::createEdge (mVertex *v1, mVertex *v2, pGEntity classif)
  {
    mEdge *theNewEdge = new mEdge(v1,v2,classif);
//        theNewEdge->print();
    add(theNewEdge);
    return theNewEdge;
  }


mFace* mPart::createFaceWithVertices (int i1, int i2, int i3, pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    if(!v1 || !v2 || !v3)
      {
	throw new mException (__LINE__,__FILE__,"unknown verex id's in new face creation");
      }
    return createFaceWithVertices(v1,v2,v3,classif);
  }

  mFace *mPart::createFaceWithVertices (mVertex *v1, mVertex *v2, mVertex *v3, 
  			pGEntity classif)
  {
    mFace *theNewFace = new mFace(v1,v2,v3,classif);
//    theNewFace->print();
    add(theNewFace);
    return theNewFace;
  }

  mFace *mPart::createFaceWithVertices (int i1, int i2, int i3, int i4, 
  			pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    mVertex *v4 = getVertex(i4);
    if(!v1 || !v2 || !v3 || !v4)
      {
	char text[256];
	sprintf(text,"trying to create a quad with vertices %d %d %d %d, search gives %p %p %p %p\n", 
		i1,i2,i3,i4,v1,v2,v3,v4);
	throw new mException (__LINE__,__FILE__,text);
      }

    return createFaceWithVertices(v1,v2,v3,v4,classif);
  }

  mFace *mPart::createFaceWithVertices (mVertex *v1, mVertex *v2, mVertex *v3, 
  			mVertex *v4, pGEntity classif)
  {
    if(!v1 || !v2 || !v3 || !v4)
      {
	char text[256];
	sprintf(text,"trying to create a quad with %p %p %p %p\n",
		v1,v2,v3,v4);
	throw new mException (__LINE__,__FILE__,text);
      }
    

    mFace *theNewFace = new mFace(v1,v2,v3,v4,classif);
//    theNewFace->print();
    add(theNewFace);
    return theNewFace;
  }

  mTet *mPart::createTetWithVertices (mVertex*v1, mVertex*v2, mVertex*v3, mVertex*v4,
				      pGEntity classif)
  {
    mTet *theNewTet;
    theNewTet = new mTet(v1,v2,v3,v4,classif);
//    theNewTet->print();
    add(theNewTet);
    return theNewTet;
  }

  mTet *mPart::createTetWithVertices (int i1, int i2, int i3, int i4, pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    mVertex *v4 = getVertex(i4);
    if(!v1 || !v2 || !v3 || !v4)
      {
	throw new mException (__LINE__,__FILE__,"unknown verex id's in new face creation");
      }
    return createTetWithVertices(v1,v2,v3,v4,classif);
  }


  mTet *mPart::createTetWithFaces (mFace *f1, mFace *f2, mFace *f3, mFace *f4, 
  			pGEntity classif)
  {
    mTet *theNewTet;
    theNewTet = new mTet(f1,f2,f3,f4,classif);
//    theNewTet->print();
    add(theNewTet);
    return theNewTet;
  }

  mFace *mPart::createFaceWithEdges (mEdge *e1, mEdge *e2, mEdge *e3, mEdge *e4, 
  			pGEntity classif, int *dir)
  {
    mFace *theNewFace;
    theNewFace = new mFace(e1,e2,e3,e4,classif,dir);
//    theNewFace->print();
    add(theNewFace);
    return theNewFace;
  }

  mFace *mPart::createFaceWithEdges (mEdge *e1, mEdge *e2, mEdge *e3, 
  			pGEntity classif, int *dir)
  {
    mFace *theNewFace;
    theNewFace = new mFace(e1,e2,e3,classif,dir);
//    theNewFace->print();
    add(theNewFace);
    return theNewFace;
  }

  mHex *mPart::createHexWithVertices (mVertex *v1, mVertex *v2, mVertex *v3, mVertex *v4,
	      		mVertex *v5, mVertex *v6, mVertex *v7, mVertex *v8, pGEntity
			classif)
  {
    mHex *theNewHex = new mHex(v1,v2,v3,v4,v5,v6,v7,v8,classif);
//    theNewHex->print();  
    add(theNewHex);
    return theNewHex;
  }
   
  mHex *mPart::createHexWithFaces (mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, mFace *f6, pGEntity
			classif)
  {
    mHex *theNewHex = new mHex(f1,f2,f3,f4,f5,f6,classif);
//    theNewHex->print();  
    add(theNewHex);
    return theNewHex;
  }


  mPrism *mPart::createPrismWithVertices (mVertex*v1, mVertex*v2, mVertex*v3, mVertex*v4,
			mVertex*v5, mVertex*v6, pGEntity classif)
  {
    mPrism *theNewPrism = new mPrism(v1,v2,v3,v4,v5,v6,classif);
//    theNewPrism->print();
    add(theNewPrism);
    return theNewPrism;
  }
  
  mPrism *mPart::createPrismWithFaces (mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, pGEntity
			classif)
  {
    mPrism *theNewPrism = new mPrism(f1,f2,f3,f4,f5,classif);
//    theNewHex->print();  
    add(theNewPrism);
    return theNewPrism;
  }

  mPyramid *mPart::createPyramidWithVertices (mVertex*v1, mVertex*v2, mVertex*v3, mVertex*v4,
			mVertex*v5,pGEntity classif)
  {
    mPyramid *theNewPyramid = new mPyramid(v1,v2,v3,v4,v5,classif);
//    theNewPrism->print();
    add(theNewPyramid);
    return theNewPyramid;
  }
  
  mPyramid *mPart::createPyramidWithFaces (mFace *f1, mFace *f2, mFace *f3, mFace *f4, mFace *f5, pGEntity
			classif)
  {
    mPyramid *theNewPyramid = new mPyramid(f1,f2,f3,f4,f5,classif);
//    theNewHex->print();  
    add(theNewPyramid);
    return theNewPyramid;
  }

  mHex *mPart::createHexWithVertices (int i1, int i2, int i3, int i4, 
		      	int i5, int i6, int i7, int i8, pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    mVertex *v4 = getVertex(i4);
    mVertex *v5 = getVertex(i5);
    mVertex *v6 = getVertex(i6);
    mVertex *v7 = getVertex(i7);
    mVertex *v8 = getVertex(i8);
    if(!v1 || !v2 || !v3 || !v4 ||
       !v5 || !v6 || !v7 || !v8)
      {
	throw new mException (__LINE__,__FILE__,"unknown verex id's in new hex creation");
      }
#ifdef _DEBUG_
#endif
    return createHexWithVertices (v1,v2,v3,v4,v5,v6,v7,v8,classif);
  }

  mPrism *mPart::createPrismWithVertices (int i1, int i2, int i3, int i4, 
		  	int i5, int i6, pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    mVertex *v4 = getVertex(i4);
    mVertex *v5 = getVertex(i5);
    mVertex *v6 = getVertex(i6);
    if(!v1 || !v2 || !v3 || !v4 ||
       !v5 || !v6)
      {
	throw new mException (__LINE__,__FILE__,"unknown verex id's in new prism creation");
      }
    return createPrismWithVertices (v1,v2,v3,v4,v5,v6,classif);
  }
  
  mPyramid *mPart::createPyramidWithVertices (int i1, int i2, int i3, int i4, 
		  	int i5,  pGEntity classif)
  {
    mVertex *v1 = getVertex(i1);
    mVertex *v2 = getVertex(i2);
    mVertex *v3 = getVertex(i3);
    mVertex *v4 = getVertex(i4);
    mVertex *v5 = getVertex(i5);
    if(!v1 || !v2 || !v3 || !v4 ||
       !v5 )
      {
	throw new mException (__LINE__,__FILE__,"unknown verex id's in new pyramid creation");
      }
    return createPyramidWithVertices (v1,v2,v3,v4,v5,classif);
  }
  

  void mPart::modifyState (int from , int to , bool state, int with)
  {
    if(!state)
      {
	std::for_each (beginall(from), endall(from), deleteAdjFunctor (to));
      }
    else if(from>to)
      {
	std::for_each (beginall(from), endall(from), 
                       createDownwardFunctor (to,with,this));
      }
    else if (from<to)
      {
	std::for_each (begin(to), end(to), createUpwardFunctor(from));
      }
  }

pGEntity mPart::getGEntity (int tag,int type)
{
  return getGEntity(tag, type,classif_fp);
}

pGEntity mPart::getGEntity(int tag, int type,pGEntity (*pf)(pGModel,int,int))
{
  pGEntity theSolidModelEntity;
  bool flag_NullModel =false;
  if (!theSolidModel)
     theSolidModel =new NullModel (); 
  if (!strcmp ((char*)(theSolidModel->modeler ()), "null")) 
    flag_NullModel =true;  

#ifdef _POINTER2INT_
   mEntity::theSolidModel = theSolidModel;
#endif
 
  if (!flag_NullModel)
  {
    theSolidModelEntity = pf(theSolidModel,type,tag);
    if (!theSolidModelEntity) {
      printf ("model entity with dim %d and tag %d not found...\n", type,tag);
      throw;
    }
  }
  else
  {
    theSolidModelEntity = GM_entityByTag(theSolidModel,type,tag);
    if (!theSolidModelEntity) {
      // if the model entity has not been defined, define it
      switch (type) {
	case 0:    // model vertex
	  theSolidModelEntity =new NullVertex((NullModel*)theSolidModel, tag);
	  break;
	case 1:    // model edge
	  theSolidModelEntity =new NullEdge((NullModel*)theSolidModel, tag);
	  break;
	case 2:    // model face
	  theSolidModelEntity =new NullFace((NullModel*)theSolidModel, tag);
	  break;
	case 3:    // model region
	  theSolidModelEntity =new NullRegion((NullModel*)theSolidModel, tag);
	  break;
      }
    }
  }
  return theSolidModelEntity;
}

  mCommonBdry* mPart::getCommonBdry(int id, int l)
  {
/*
//    int tag=-1;
    mCommonBdry gg(id,l);
    std::set<mCommonBdry*,mCommonBdryLessThanKey>::const_iterator it =
    allCommonBdries.find(&gg);
    if(it != allCommonBdries.end())
      return *it;
    mCommonBdry* pg = new mCommonBdry(id,l);
    allCommonBdries.insert(pg);

    return pg;
*/  
  }

  mEntity* mPart::find(mEntity *e)
  {
    return allEntities.find(e);
  } 

  void mPart::add(mEntity *e)
  {
    allEntities.add(e);
  } 

  void mPart::del(mEntity *e)
  {
    allEntities.del(e);
  } 

  mEntity* mPart::getEntity (mEntity::mType type, mVertex *v[], pGEntity g)
  {  
    mEntity *e;
    switch(type)
      {
      case mEntity::HEX  : 
	e = (mEntity*)getHex(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7]);
	if(!e)e = (mEntity*) createHexWithVertices (v[0],v[1],v[2],v[3],v[4],
				v[5],v[6],v[7],g);
	break;
      case mEntity::TET  : 
	e = (mEntity*)getTet(v[0],v[1],v[2],v[3]);
	if(!e)e = (mEntity*) createTetWithVertices (v[0],v[1],v[2],v[3],g);
	break;
      case mEntity::QUAD : 
	e = (mEntity*)getQuad(v[0],v[1],v[2],v[3]);
	if(!e)e = (mEntity*) createFaceWithVertices (v[0],v[1],v[2],v[3],g);
	break;
      case mEntity::TRI  : 
	e = (mEntity*)getTri(v[0],v[1],v[2]);
	if(!e)e = (mEntity*) createFaceWithVertices (v[0],v[1],v[2],g);
	break;
      case mEntity::EDGE : 
	e = (mEntity*) getEdge (v[0],v[1]);
	if(!e)e = (mEntity*) createEdge(v[0],v[1],g);
	break;      
      }
    return e;  
  }

  mEntity* mPart::copyMeshEntity(mEntity *other)
  {
    mVertex *v[12];
    pGEntity g;

    if(!other->getClassification())
      {
	ParUtil::Instance()->Msg(ParUtil::WARNING,"Unclassified entity %d %d\n",other->getLevel(),other->getId());
	g = getGEntity(1000000,
		       other->getLevel());
      }
    else
      {
	g = getGEntity(GEN_tag(other->getClassification()),
		       GEN_type(other->getClassification()));
      }

    if(other->getLevel() == 0)
      {
	if(mVertex *v = getVertex(other->getId()))
	  {
	    return (mEntity*)v;
	  }
	else
	  {	  
	    mVertex *vv = (mVertex*)other;
	    SCOREC::Util::mPoint p(vv->point());
	    return (mEntity*)createVertex(vv->getId(),p(0),p(1),p(2),g);
	  }
      }


    for(int i=0;i<other->size(0);i++)
      {      
	v[i] = getVertex(other->get(0,i)->getId());
	if(!v[i])ParUtil::Instance()->Msg(ParUtil::ERROR,"Unable to find vertex %d\n",other->get(0,i)->getId());
      }  
    mEntity *e = 0;
    e = getEntity (other->getType(), v, g);
    return e;  
  }


  mPart & mPart::operator += (mPart &other)
  {
    for(int i=0;i<4;i++)
      {
	for(iterall it = other.beginall(i);it != other.endall(i);++it)
	  {
	    mEntity *e = copyMeshEntity(*it);
	    if(!find(e))
	      add(e);
	  }
      }
    return *this;
  }

  void mPart:: writeMEntity(ostream &o, mEntity *m)
  {
    o << m->getType() << " " ;
    for(int i=0;i<m->getNbTemplates(0);i++)
      {
	o << m->get(0,i)->getId() << " " ;
      }
    o << "\n";
  }

  mEntity * mPart:: readMEntity(istream &is)
  {
    int typ,iv[10];
    is >> typ;
    //printf("reading a mesh entity of typ %d\n",typ);
    switch(typ)
      {
      case mEntity::EDGE :
	is >> iv[0] >> iv[1];
	//      if(ParUtil::Instance()->master())
	//	printf("it's an edge (%d %d)\n",iv[0],iv[1]);
	return getEdge(getVertex(iv[0]),getVertex(iv[1]));
      case mEntity::TRI :
	is >> iv[0] >> iv[1] >> iv[2];
	return getTri(getVertex(iv[0]),getVertex(iv[1]),getVertex(iv[2]));
      case mEntity::QUAD :
	is >> iv[0] >> iv[1] >> iv[2] >> iv[3];
	return getQuad(getVertex(iv[0]),getVertex(iv[1]),getVertex(iv[2]),getVertex(iv[3]));
      case mEntity::TET :
	is >> iv[0] >> iv[1] >> iv[2] >> iv[3];
	return getTet(getVertex(iv[0]),getVertex(iv[1]),getVertex(iv[2]),getVertex(iv[3]));
      case mEntity::HEX :
	is >> iv[0] >> iv[1] >> iv[2] >> iv[3] >> iv[4] >> iv[5] >> iv[6] >> iv[7];
	return getHex(getVertex(iv[0]),
		      getVertex(iv[1]),
		      getVertex(iv[2]),
		      getVertex(iv[3]),
		      getVertex(iv[4]),
		      getVertex(iv[5]),
		      getVertex(iv[6]),
		      getVertex(iv[7]));
      }
  }

  /*
insure that all inter-processor entities have
the right classification
*/

  void mPart::updateCommonBdryEntities(int what)
  {
// to be removed
  }


  void mPart::reduceToMinumumRepresentation()
  {
    int dim = (size(3))?3:2;
    for(int DIM = dim-1 ; DIM > 0 ; DIM--)
      {
	std::list<mEntity*> todel;
	iterall it = beginall(DIM);
	iterall itend = endall(DIM);
	for ( ; it != itend ; ++it)
	  {
	    if (GEN_type((*it)->getClassification()) != (DIM) && !(*it)->getPClassification() )
		//	       !(*it)->getCommonBdry() )
	      todel.push_back(*it);
	  }
	for (std::list<mEntity*>::const_iterator itl = todel.begin(); 
	    itl != todel.end() ; ++itl)
	    DEL(*itl);
      }
  }

  int mPart::getDimension() const
  {
    if(size(3))return 3;
    if(size(2))return 2;
    if(size(1))return 1;
    return dimension;
  }

  SCOREC::Util::mPoint mPart::closestPoint (const SCOREC::Util::mPoint & pt , int dim , int tag ) const
  {
    mClassIterator it = begin (dim, tag, dim);
    mClassIterator ite = end  (dim, tag, dim);

    if (it == ite)throw;

    double mind = 1.e20;

    SCOREC::Util::mPoint pp;

    /// model edge 
    if (dim == 1)
      {
	while (it != ite)
	  {
	    mEdge *e = (mEdge *) *it;
	    SCOREC::Util::mVector v1 (e->vertex(1)->point()-e->vertex(0)->point());
	    SCOREC::Util::mVector v2 (pt-e->vertex(0)->point());
	    double nv1 = v1.normValue();
	    double nv2 = v2.normValue();
	    SCOREC::Util::mVector v1Xv2 (v1 % v2);
	    double d = fabs(v1Xv2.normValue() * nv2);
	    if (d < mind)
	      {
		double xx = fabs (v1 * v2);
		mind = d;
		pp = e->vertex(0)->point() * (1.-xx) + e->vertex(1)->point() * xx;
	      }
	    ++it;
	  }
      }
    else
      {
	throw;
      }
    return pp;
  }

  void mPart::setSolidModel (pGModel m)
  {
    theSolidModel=m;
  }
/***************************GHOST INFORMATION*********************/

void mPart::addGhostRule(int gType, int bType, int numLayer, int include_copy)
{
   vecGhostInfo.push_back(ghostInfo(gType, bType, numLayer, include_copy));
}

void mPart::clearGhostRules()
{
   vecGhostInfo.clear();
}

std::vector<ghostInfo>& mPart::getGhostRules()
{
   return vecGhostInfo;
}

int mPart::getNumGhostRules()
{
  return vecGhostInfo.size();
}
void mPart::getGhostTypes(int **gTypes, int* size)
{
   *gTypes = new int[vecGhostInfo.size()];
   *size = vecGhostInfo.size();
   int index = 0;

   for(std::vector<ghostInfo>::iterator itVec = vecGhostInfo.begin(); itVec != vecGhostInfo.end(); ++itVec)
        {
           (*gTypes)[index] = (*itVec).ghostType;
           ++index;
         }
}


