/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mRegion.h"
#include "mEdge.h"
#include "mException.h"

namespace {
  int regionCounter = 0;
}

mRegion::mRegion() : mEntity() {
  // iD = regionCounter++;
}

mEdge * mRegion::commonEdge (mRegion *r1, mRegion *r2)
{
  std::set<mEdge*,EntityLessThanKey> thisEdges;
  std::set<mEdge*,EntityLessThanKey> r1Edges;
  std::set<mEdge*,EntityLessThanKey> r2Edges;
 
  for(int i=0;i<size(1);i++)thisEdges.insert((mEdge*)get(1,i));
{  for(int i=0;i<r1->size(1);i++)r1Edges.insert((mEdge*)r1->get(1,i));}
{  for(int i=0;i<r2->size(1);i++)r2Edges.insert((mEdge*)r2->get(1,i));}

  for( std::set<mEdge*,EntityLessThanKey>::const_iterator iter = thisEdges.begin();
       iter != thisEdges.end();
       ++iter)
    {
      if(r1Edges.find(*iter) != r1Edges.end() &&
	 r2Edges.find(*iter) != r2Edges.end())return *iter;
    }
  return 0;


  throw new mException (__LINE__, __FILE__,"mRegion::commonEdge not none yet ...");
}

mFace * mRegion::commonFace (mRegion *r)
{
  for(int i=0;i<size(2);i++)
    {
      mEntity *f = get(2,i);
      for(int j=0;j<r->size(2);j++)
	{
	  if(f == r->get(2,j))return (mFace*)f;
	}      
    }
  return 0;
}
