/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <string.h>
#include <vector>
#include <algorithm>
#include <assert.h>
#include "oldFMDB.h"
#include "mAttachableDataContainer.h"
#include "mFMDB.h"
#include "mPoint.h"

using std::cout;
using std::endl;

  void mAttachableDataContainer::attachOpaque(pMeshDataId c, const void* o, int size)
  {
    mAttachableOpaque *ai = (mAttachableOpaque *)getData(c);
    
    if (ai)
    {
      delete [] ai->o;
    }
    else
    {
      ai = new mAttachableOpaque;
      attachData(c,ai);
    }    
    ai->size = size;
    ai->o = new char[size];
	
    memcpy(ai->o, o, size);
  }

   
  int mAttachableDataContainer::getSizeAttachedOpaque(/*unsigned int*/ pMeshDataId c)
  {
    mAttachableOpaque* ai = (mAttachableOpaque*)getData(c);
    if(!ai) return 0;
    return ai->size;
  }
  
  int mAttachableDataContainer::getAttachedOpaque (/*unsigned int*/ pMeshDataId c, void* o)
  {
  // we assume memory for char* o is allocated by application
    mAttachableOpaque* ai = (mAttachableOpaque*)getData(c);
    if(!ai) return 0;
    memcpy(o, ai->o, ai->size);
    return 1;
  }

  void mAttachableDataContainer::getAllTagID(std::vector<pMeshDataId> & id_list)
  {
    if (tab==NULL || tab->empty())
      return;
    
    int tag_type; 
    for(iter_attachdata it=tab->begin(); it<tab->end(); ++it){
      if (it->first<1000) continue;
      id_list.push_back(it->first);
    }
    return;
  }

  void mAttachableDataContainer::attachIntArr(unsigned int c,
  int* data_arr, int data_size)
  {
    mAttachableIntVector *ai = (mAttachableIntVector *)getData(c);
    if(!ai)  // create a new int vector
    {
      ai = new mAttachableIntVector;
      attachData(c,ai);
    }
    ai->v.clear();  // clear exiting int vector
    for (int i=0; i<data_size; ++i)
      ai->v.push_back(data_arr[i]);
  }

  int mAttachableDataContainer::getAttachedIntArr (unsigned int c,
  int** data_arr, int* data_size)
  {
    mAttachableIntVector *ai = (mAttachableIntVector *)getData(c);
    if(!ai) return 0;
    int data_pos=0;
    for (std::vector<int>::iterator it = ai->v.begin(); it!=ai->v.end(); ++it)
      (*data_arr)[data_pos++] = *it;    
    *data_size = (int)ai->v.size();
    return 1;
  }

  void mAttachableDataContainer::attachDblArr (unsigned int c,
  double* data_arr, int data_size)
  {
    mAttachableDblVector *ai = (mAttachableDblVector *)getData(c);
    if(!ai)  // create a new double vector
    {
      ai = new mAttachableDblVector;
      attachData(c,ai);
    }
    ai->v.clear();  // clear exiting double vector
    for (int i=0; i<data_size; ++i)
      ai->v.push_back(data_arr[i]);

  }

  int mAttachableDataContainer::getAttachedDblArr (unsigned int c,
  double** data_arr, int* data_size)
  {
    mAttachableDblVector *ai = (mAttachableDblVector *)getData(c);
    if(!ai)return 0;
    int data_pos=0;
    for (std::vector<double>::iterator it = ai->v.begin(); it!=ai->v.end(); ++it)
      (*data_arr)[data_pos++] = *it;    
    *data_size = (double)ai->v.size();
    return 1;
  }

  void mAttachableDataContainer::attachPntArr(unsigned int c,
  void** data_arr, int data_size)
  {
    mAttachablePntVector *ai = (mAttachablePntVector *)getData(c);
    if(!ai)
    {
      ai = new mAttachablePntVector;
      attachData(c,ai);
    }
    ai->v.clear();
    for (int i=0; i<data_size; ++i)
      ai->v.push_back(data_arr[i]);
  }

  int mAttachableDataContainer::getAttachedPntArr (unsigned int c,
  void*** data_arr, int* data_size)
  {
    mAttachablePntVector *ai = (mAttachablePntVector *)getData(c);
    if(!ai)return 0;
    int data_pos=0;
    for (std::vector<void*>::iterator it = ai->v.begin(); it!=ai->v.end(); ++it)
      (*data_arr)[data_pos++] =*it;    
    *data_size = (int)ai->v.size();
    return 1;
  }
