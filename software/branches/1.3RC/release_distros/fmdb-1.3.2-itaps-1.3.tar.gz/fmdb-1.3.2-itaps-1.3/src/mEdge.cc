/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include "mEdge.h"
#include "mUnits.h"
#include "mEntityContainer.h"
#include "mVertex.h"
#include <stdio.h>
#include <math.h>
#include "function_template.h"


  namespace {
    int edgeCounter = 0;
  }
mEdge::mEdge(mVertex *v1, mVertex *v2, GEntity *classification)
  : mEntity ()
   , up_adj_size(0), up_adj(0) 
{
  down_adj[0] = v1;
  down_adj[1] = v2;
#ifndef _POINTER2INT_
  theClassification = classification;
#else
   gType = GEN_type(classification);
   gTag = GEN_tag(classification); 
#endif
  if(!v1 || !v2)return;
}

mEdge::~mEdge()
{
}

int mEdge::getLevel()const
{
  return 1;
}

int mEdge::getNbTemplates(int what)const
{
  if(what == 0)
    return 2;
  else
    return 0;
}

void mEdge::setVertices(mVertex *v1, mVertex *v2)  
{
  down_adj[0] = v1; 
  down_adj[1] = v2; 
}

  // adjacency related    
   void mEdge::add (mEntity* m)
   {
      add_entity_to_array<mEntity*>(up_adj, m, up_adj_size);	 
   }
     
     void mEdge::appendUnique (mEntity* m)
     {
        APPEND_UNIQUE_ENTITY(m); 
     }
     
     void mEdge::del (mEntity* m)
     {
        del_entity_from_array<mEntity*>(up_adj, up_adj_size, m);
     }
    
       mEntity* mEdge::get(int what, int ith)const
       {
	 if(what==0)
	    return down_adj[ith];

	 if(what==2)
            return up_adj[ith]; 

	 return 0; 
       }
       
       void mEdge::deleteAdjacencies(int what)
       {
	  if(what==2)
	    free_array<mEntity*>(up_adj, up_adj_size);
       }
       
       mEntity * mEdge::find(mEntity* m) const
       {
	 int dim = m->getLevel(); 

	 if(dim==2)
            return find_entity_in_array<mEntity*>(up_adj, up_adj_size, m);
	 if(dim==0)
	    return find_entity_in_array<mEntity*>(((mEntity**)down_adj) , 2, m);

	 return 0; 
       }

