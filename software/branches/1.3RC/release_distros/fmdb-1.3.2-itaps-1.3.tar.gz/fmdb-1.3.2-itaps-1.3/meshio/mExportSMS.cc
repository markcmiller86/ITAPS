/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <fstream>
#include "FMDB.h"
#include "FMDB_Iterator.h"
#include "mMesh.h"

// **********************************************************
void exportSMS (mMesh *mesh, const char *fName)
// **********************************************************
{
  pPart part;
  FMDB_Mesh_GetPart(mesh, 0, part);

  std::map<int,int> numberid;	
  double loc[3];
  pVertex vertex;
  pRegion region;
  pEdge edge;
  pFace face;

  int gentitytype, genttag, i, j, numEdges, numFaces, ID;
  pGEntity classifyon;

  int NbRegions, NbFaces, NbEdges, NbVertices,NbPoints;
  NbRegions=part->size(3);
  NbFaces=part->size(2);
  NbEdges=part->size(1);
  NbVertices=part->size(0);
  NbPoints=NbVertices;
  double low, high;

  FILE* outFile = fopen(fName, "w");      

#ifdef MATCHING 
    vector<vector<pVertex>*>  matchVtxs;
    vector<vector<pEdge>*>  matchEdgs;
    vector<vector<pFace>*>  matchFcs;
    
    unsigned int matchId = MD_newMeshDataId("Visited_Match_Id");
#endif 
    
  fprintf(outFile, "sms 2\n");
  SCOREC::Util::mVector vec;

  fprintf(outFile, "%d %d %d %d %d\n", NbRegions, NbFaces
                                     , NbEdges, NbVertices, NbPoints);  
  cout<<"\n"<<fName<<": writing "<<NbVertices<<" vertices, "<<NbEdges<<" edges, "
      <<NbFaces<<" faces, "<<NbRegions<<" regions";

  int NbEntSets = mesh->allEntSets.size();
  std::vector<pMeshEnt> taggedEnt;
  std::vector<pEntSet> taggedEntSet;
  std::vector<pTag> tagID;
  std::vector<pTag>::iterator tagIter;

  if (NbVertices>0)
  {
    i=1;
	    
    for (mPart::iterall it=part->beginall(0); it!=part->endall(0); ++it)
    {  
      vertex = *it;
      numberid.insert(std::map<int,int>::value_type(EN_id(vertex),i++));
      V_coord(vertex,loc);
      classifyon=vertex->getClassification();
      if(classifyon!=0) {
	gentitytype=GEN_type(classifyon);
	genttag = GEN_tag(classifyon);  
      }
      else{
	gentitytype=3;
	genttag=1; 
      }

      fprintf(outFile, "%d %d %d\n%.15f %.15f %.15f ",
                      genttag, gentitytype, V_numEdges(vertex), 
		      loc[0], loc[1], loc[2]); 	  
      if (vertex->getData(FMDB_Util::Instance()->getParametric()))
      {
        vec = vertex->getAttachedVector (FMDB_Util::Instance()->getParametric());
        switch (gentitytype)
	{
	  case 1: //ofs << vec(0);
	         fprintf(outFile, "%le", vec(0));
		 break;
          case 2: //ofs << vec(0) <<" "<< vec(1) <<" "<< vec(2);
 	         fprintf(outFile, "%le %le %d", vec(0), vec(1), vec(2));
		 break;
          default: break;
        }
      }
      else
      {
        switch (gentitytype)
	{
          case 1: //ofs << " 0";
	         fprintf(outFile, "0");
		 break;
          case 2: //ofs << " 0" << " 0" << " 0";
	         fprintf(outFile, "0 0 0");
		 break;
          default: break;
        }
      }
      fprintf(outFile, "\n");      

      //for tagging file output
      tagID.clear();
      (*it)->getAllTagID (tagID);
      if (!tagID.empty())
        taggedEnt.push_back((pMeshEnt)vertex);

#ifdef MATCHING
      // matched vertex sets
      int tmpInt; 
      if(vertex->hasMatchEnt() && !EN_getDataInt(vertex, matchId, &tmpInt)) 
      { 
	vector<mEntity*>* tmpSet; 
	pVertex tmpVtx; 
        tmpSet = new vector<mEntity*>; 
	tmpSet->push_back(vertex);
        EN_attachDataInt(vertex, matchId, 1);
	for(mEntity::MEIter it=vertex->meBegin(); it!=vertex->meEnd(); ++it) 
        {
	  tmpVtx = it->second; 
	  tmpSet->push_back(tmpVtx);
          EN_attachDataInt(tmpVtx, matchId, 1);
	}
	matchVtxs.push_back(tmpSet);
      }
#endif 
    } // for each vertex
  } // if NbVertices > 0

  if (NbEdges>0)
  {	
    i=1;
    for (mPart::iterall it=part->beginall(1); it!=part->endall(1); ++it)
    { 
      edge = *it;
      classifyon=edge->getClassification();
      if(classifyon!=0) {
	gentitytype=GEN_type(classifyon);
	genttag = GEN_tag(classifyon);  
      }
      else {
	gentitytype=3;
	genttag=1; 
      }
      fprintf(outFile, "%d %d ",  genttag, gentitytype);
      EN_setID(edge,i++);
      for (j=0; j<2 ;j++)
	fprintf(outFile, "%d ", numberid[EN_id(E_vertex(edge,j))]);
      fprintf(outFile, "%d ", E_numFaces(edge)); 

      int npts = E_numPoints(edge);
      fprintf(outFile, "%d\n", npts);
      if(npts) {
	pPoint pt = E_point(edge, 0);
	fprintf(outFile,"%.15f %.15f %.15f ",P_x(pt), P_y(pt), P_z(pt));
	switch (GEN_type(edge->getClassification()))
	{
          case 1: //ofs << " 0";
	         fprintf(outFile, "0");
		 break;
          case 2: //ofs << " 0" << " 0" << " 0";
	         fprintf(outFile, "0 0 0");
		 break;
          default: break;
        }
	fprintf(outFile, "\n"); 
      }

      //for tagging file output
      tagID.clear();
      (*it)->getAllTagID (tagID);
      if (!tagID.empty())
        taggedEnt.push_back((pMeshEnt)edge);

#ifdef MATCHING
      int tmpInt; 
      if(edge->hasMatchEnt() && !EN_getDataInt(edge, matchId, &tmpInt)) 
      {
        vector<mEntity*>* tmpSet;
        pVertex tmpEdg;
        tmpSet = new vector<mEntity*>;
        tmpSet->push_back(edge);
        EN_attachDataInt(edge, matchId, 1);
        for(mEntity::MEIter it=edge->meBegin(); it!=edge->meEnd(); ++it) 
        {
          tmpEdg = it->second;
          tmpSet->push_back(tmpEdg);
          EN_attachDataInt(tmpEdg, matchId, 1);
        }
        matchEdgs.push_back(tmpSet);
      }
#endif       
    } // for each edge
  } // if NbEdges > 0			
 
  if (NbFaces>0)
  {	  
    i=1;
    for (mPart::iterall it=part->beginall(2); it!=part->endall(2); ++it)
    { 
      face = *it;
      classifyon=face->getClassification();
      if(classifyon!=0) {
	gentitytype=GEN_type(classifyon);
	genttag = GEN_tag(classifyon); 
      }
      else{
	gentitytype=3;
	genttag=1; 
      }
      fprintf(outFile, "%d %d ", genttag, gentitytype);
      EN_setID(face,i++);
      numEdges=F_numEdges(face);
      fprintf(outFile, "%d ", numEdges);
      for (j=0; j<numEdges ;j++)
      {
        edge = F_edge(face,j);
	ID=EN_id(edge);
        if (!F_edgeDir(face,j)) ID=-ID;
	fprintf(outFile, "%d ", ID);
      } 		
      fprintf(outFile, "0\n");
      
      //for tagging file output
      tagID.clear();
      (*it)->getAllTagID (tagID);
      if (!tagID.empty())
        taggedEnt.push_back((pMeshEnt)face);

#ifdef MATCHING
      int tmpInt; 
      if(face->hasMatchEnt() && !EN_getDataInt(face, matchId, &tmpInt)) {
        vector<mEntity*>* tmpSet;
        pVertex tmpFace;
        tmpSet = new vector<mEntity*>;
        tmpSet->push_back(face);
        EN_attachDataInt(face, matchId, 1);
        for(mEntity::MEIter it=face->meBegin(); it!=face->meEnd(); ++it) {
          tmpFace = it->second;
          tmpSet->push_back(tmpFace);
          EN_attachDataInt(tmpFace, matchId, 1);
        }
        matchFcs.push_back(tmpSet);
      }
#endif      
    } // while
  } // if NbFaces
  
  if (NbRegions>0)
  {
    i=1;
    for (mPart::iterall it=part->beginall(3); it!=part->endall(3); ++it)
    { 
      region = *it;
      if (NbEntSets) EN_setID(region, i++);
      classifyon =region->getClassification();
      if(classifyon!=0) {
	genttag = GEN_tag(classifyon);
      }
      else{
	genttag= 1; 
      }
      numFaces=R_numFaces(region);
      fprintf(outFile, "%d %d ",  genttag, numFaces);		
      for (j=0; j<numFaces ;j++)
      {		  
	face = R_face(region,j);
	ID=EN_id(face);
	if (!R_faceDir(region,j)) ID=-ID;
	fprintf(outFile, "%d ", ID);
      } 		
      fprintf(outFile, "0\n");

      //for tagging file output
      tagID.clear();
      (*it)->getAllTagID (tagID);
      if (!tagID.empty())
        taggedEnt.push_back((pMeshEnt)region);

    }  // for each region
  } // if

  if (NbEntSets) // save Entity Set info 
  {
    cout<<", "<<NbEntSets<<" entity sets";
    fprintf(outFile, "EntitySet\n");
    fprintf(outFile, "%d\n", NbEntSets);
   
    mEntitySet* eset;
    std::list<mEntitySet*>::iterator lit = mesh->beginEntSet();

    for (int eset_cnt=0; lit!=mesh->endEntSet(); ++lit)
    {
      eset = *lit;
      eset->attachInt(FMDB_Util::Instance()->getId(),eset_cnt++); // attach unique ID starting from 0 

      // write each entity set info; ID, list or set, entities
      if (eset->isList())
      {
        fprintf(outFile, "%d %d\n", eset->isList(), ((mEntitySetUnordered*)eset)->numEntity()); // list or set, num entities contained
        if (((mEntitySetUnordered*)eset)->numEntity()==0)
          continue;
        pEntSetUIterator iter = new mEntSetUIterator( ((mEntitySetUnordered*)eset)->begin(),
                                    ((mEntitySetUnordered*)eset)->end(), 4, 
                                    (int)(mEntity::ALL_TOPOLOGIES), 0, &processingEntitySetUFilter);
        for (; !iter->end(); ++(*iter))
        {
          if ((*(*iter))->getLevel()==0)
            fprintf(outFile, "0 %d\n", numberid[EN_id(**iter)]);
          else 
            fprintf(outFile, "%d %d\n", (**iter)->getLevel(), EN_id(**iter));
        }
      } // isList
      else // not a list
      {
        fprintf(outFile, "%d %d\n", eset->isList(), ((mEntitySetOrdered*)eset)->numEntity());
        if (((mEntitySetOrdered*)eset)->numEntity()==0)
          continue;
        pEntSetOIterator iter = new mEntSetOIterator( ((mEntitySetOrdered*)eset)->begin(), 
                                    ((mEntitySetOrdered*)eset)->end(), 4,   
                                    (int)(mEntity::ALL_TOPOLOGIES), 0, &processingEntitySetOFilter);
        for (; !iter->end(); ++(*iter)) 
        {
          if ((*(*iter))->getLevel()==0)
            fprintf(outFile, "0 %d\n", numberid[EN_id(**iter)]);
          else
            fprintf(outFile, "%d %d\n", (**iter)->getLevel(), EN_id(**iter));
        }
      } // else

      //for tagging file output
      tagID.clear();
      eset->getAllTagID (tagID);
      if (!tagID.empty())
        taggedEntSet.push_back(eset);

    } // for each ent set
     
     // write entity set relation info
    mEntitySet::SubIter siter;
    mEntitySet::ChildIter citer;
    for (lit=mesh->beginEntSet(); lit!=mesh->endEntSet(); ++lit)
    {
       eset = *lit;
       fprintf(outFile, "%d %d %d\n", eset->getAttachedInt(FMDB_Util::Instance()->getId()), // ID
                                     eset->numSubset(0), eset->numChildren(0));
       for (siter=eset->subBegin(); siter!=eset->subEnd(); ++siter)
         fprintf(outFile, "%d\n", (*siter)->getAttachedInt(FMDB_Util::Instance()->getId()));
       for (citer=eset->childBegin(); citer!=eset->childEnd(); ++citer)
         fprintf(outFile, "%d\n", (*citer)->getAttachedInt(FMDB_Util::Instance()->getId()));
     } // for 
   } // if part->EntSet.size()>0


  int numTaggedPart=0;
  tagID.clear();
  part->getAllTagID (tagID);
  if (!tagID.empty())
    numTaggedPart=1;

  int numTaggedEntSet=taggedEntSet.size();
  int numTaggedEnt=taggedEnt.size();
  if (!(numTaggedPart+numTaggedEntSet+numTaggedEnt))
      cout<<"\n";
  else
  {
    // get tag info
    tagID.clear();
    FMDB_Tag_GetAllID (mesh, tagID);

    // write tag info
    fprintf(outFile, "Tag\n");
    fprintf(outFile, "%d %d\n", tagID.size(), numTaggedPart+numTaggedEntSet+numTaggedEnt);
    cout<<", "<<tagID.size()<<" tags\n";

    unsigned int tag;
    int tag_type, tag_size;
    for (std::vector<unsigned int>::iterator tag_it=tagID.begin(); tag_it!=tagID.end(); ++tag_it)
    {
      tag = *tag_it;
      char name[256];
      FMDB_Tag_GetName (mesh, tag, name);
      FMDB_Tag_GetType (mesh, tag, &tag_type);
      FMDB_Tag_GetSize (mesh, tag, &tag_size);

      fprintf(outFile, "%d %s EndOfName %d %d\n", tag, name, tag_type, tag_size);
    }    
    
    int byte_size, arr_size, int_data;
    double dbl_data;
    char* tag_value;
    pMeshEnt ent_data, ent;
    pEntSet eset_data, eset;
    vector<int> int_arr;
    vector<double> dbl_arr;
    vector<pMeshEnt> ent_arr;
    vector<pEntSet> eset_arr;

    // write mesh tag info
    tagID.clear();
    part->getAllTagID (tagID);    
    if (tagID.size()) 
      fprintf(outFile, "P 0 1 %d\n", tagID.size()); // part iD, #tags
    for (tagIter = tagID.begin(); tagIter != tagID.end(); ++tagIter)
    {
      tag = *tagIter;
      FMDB_Tag_GetType (mesh, tag, &tag_type);
      FMDB_Tag_GetSize (mesh, tag, &tag_size);

      fprintf(outFile, "%d ", tag); // tag 
      switch (tag_type)
      {
        case 0:  // byte
                {
                  void* byte_data = (void*)calloc(tag_size, sizeof(char));
                  FMDB_Part_GetByteTag (part, tag, &byte_data, &byte_size);
                  fprintf(outFile, "%d %s\n", byte_size, byte_data);
                  delete [] byte_data;
                }
                break;

        case 1: // int
                if (tag_size==1)
                {
                  FMDB_Part_GetIntTag (part, tag, &int_data);
                  fprintf(outFile, "%d\n", int_data);
                }
                else
                {
                  int* arr_data = new int[tag_size];
                  FMDB_Part_GetIntArrTag (part, tag, &arr_data, &arr_size);
                  for (int i=0; i<arr_size; ++i)
                     fprintf(outFile, "%d ", arr_data[i]);
                  fprintf(outFile, "\n");
                  delete [] arr_data; 
                }
                break;
        case 2: // double
                if (tag_size==1)
                {
                  FMDB_Part_GetDblTag (part, tag, &dbl_data);
                  fprintf(outFile, "%lf\n",dbl_data);
                }
                else
                {
                  double* arr_data = new double[tag_size];
                  FMDB_Part_GetDblArrTag (part, tag, &arr_data, &arr_size);
                  for (int i=0; i<arr_size; ++i)
                     fprintf(outFile, "%lf ", arr_data[i]);
                  fprintf(outFile, "\n");
                  delete [] arr_data;
                }
                break;
        case 3: // entity handle
                if (tag_size==1)
                {
                  FMDB_Part_GetEntTag (part, tag, &ent_data);
                  if (ent_data->getLevel()==0)
                    fprintf(outFile, "0 %d\n", numberid[FMDB_Ent_GetID(ent_data)]);
                  else 
                    fprintf(outFile, "%d %d\n", ent_data->getLevel(), FMDB_Ent_GetID(ent_data));
                }
                else
                { 
                  pMeshEnt* arr_data = new pMeshEnt[tag_size];
                  FMDB_Part_GetEntArrTag (part, tag, &arr_data, &arr_size);
                  for (int i=0; i<arr_size; ++i)
                  {
                    if ((arr_data[i])->getLevel()==0)
                       fprintf(outFile, "0 %d ", numberid[FMDB_Ent_GetID(arr_data[i])]);
                    else
                       fprintf(outFile, "%d %d ", (arr_data[i])->getLevel(), FMDB_Ent_GetID(arr_data[i]));
                  }
                  fprintf(outFile, "\n");
                  delete [] arr_data;
                }
                break;                
        case 4: // entity set handle
               if (tag_size==1)
                { 
                  FMDB_Part_GetSetTag (part, tag, &eset_data);
                  fprintf(outFile, "%d\n", FMDB_Set_GetID(eset_data));
                }
                else
                {
                  pEntSet* arr_data = new pEntSet[tag_size];
                  FMDB_Part_GetSetArrTag (part, tag, &arr_data, &arr_size);
                  for (int i=0; i<arr_size; ++i)
                    fprintf(outFile, "%d ", FMDB_Set_GetID(arr_data[i]));
                  fprintf(outFile, "\n");
                  delete [] arr_data;
                }
                break;
        default: break;
      }  // switch
    }  // for mesh tag
     
    for (std::vector<pEntSet>::iterator es_it=taggedEntSet.begin();
         es_it != taggedEntSet.end(); ++es_it)
    {
      eset = *es_it;
      tagID.clear();
      eset->getAllTagID (tagID);    
      fprintf(outFile, "S 0 %d %d\n", FMDB_Set_GetID (eset), tagID.size());  //ent set ID and #tags
      for (tagIter = tagID.begin(); tagIter != tagID.end(); ++tagIter)
      {
        tag = *tagIter;
        FMDB_Tag_GetType (mesh, tag, &tag_type);
        FMDB_Tag_GetSize (mesh, tag, &tag_size);

        fprintf(outFile, "%d ", tag); // tag
        switch (tag_type)
        {   
          case 0:  // byte
                  {
                    void* byte_data = (void*)calloc(tag_size, sizeof(char));
                    FMDB_Set_GetByteTag (eset, tag, &byte_data, &byte_size);
                    fprintf(outFile, "%d %s\n", byte_size, byte_data);
                    delete [] byte_data;
                  }
                  break;
          case 1: // int
                  if (tag_size==1)
                  {
                    FMDB_Set_GetIntTag (eset, tag, &int_data);
                    fprintf(outFile, "%d\n", int_data);
                  }
                  else
                  {
                    int* arr_data = new int[tag_size];
                    FMDB_Set_GetIntArrTag (eset, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%d ", arr_data[i]);
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          case 2: // double
                  if (tag_size==1)
                  {
                    FMDB_Set_GetDblTag (eset, tag, &dbl_data);
                    fprintf(outFile, "%lf\n",dbl_data);
                  }
                  else
                  {
                    double* arr_data = new double[tag_size];
                    FMDB_Set_GetDblArrTag (eset, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%lf ", arr_data[i]);
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          case 3: // entity handle
                  if (tag_size==1)
                  {
                    FMDB_Set_GetEntTag (eset, tag, &ent_data);
                    if (ent_data->getLevel()==0)
                      fprintf(outFile, "0 %d\n", numberid[FMDB_Ent_GetID(ent_data)]);
                    else
                      fprintf(outFile, "%d %d\n", ent_data->getLevel(), FMDB_Ent_GetID(ent_data));
                  }
                  else
                  {
                    pMeshEnt* arr_data = new pMeshEnt[tag_size];
                    FMDB_Set_GetEntArrTag (eset, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                    {
                      if ((arr_data[i])->getLevel()==0)
                        fprintf(outFile, "0 %d ", numberid[FMDB_Ent_GetID(arr_data[i])]);
                      else
                        fprintf(outFile, "%d %d ", (arr_data[i])->getLevel(), FMDB_Ent_GetID(arr_data[i]));
                    }
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
        case 4: // entity set handle
                 if (tag_size==1)
                  {
                    FMDB_Set_GetSetTag (eset, tag, &eset_data);
                    fprintf(outFile, "%d\n", FMDB_Set_GetID(eset_data));
                  }
                  else
                  {
                    pEntSet* arr_data = new pEntSet[tag_size];
                    FMDB_Set_GetSetArrTag (eset, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%d ", FMDB_Set_GetID(arr_data[i]));
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          default: break;
        }  // switch
      } // for each tag of eset 
    }  // for eset

    for (std::vector<pMeshEnt>::iterator ent_it=taggedEnt.begin();
         ent_it != taggedEnt.end(); ++ent_it)
    {             
      ent = *ent_it;
/*
      switch (ent->getLevel())
      {
        case 0: cout<<"WRITE tagging V"<<numberid[EN_id(ent)]<<" UID="<<ent->getUid(); break;
        case 1: cout<<"WRITE tagging E"<<EN_id(ent)<<" UID="<<ent->getUid(); break;
        case 2: cout<<"WRITE tagging F"<<EN_id(ent)<<" UID="<<ent->getUid(); break;
        case 3: cout<<"WRITE tagging R"<<EN_id(ent)<<" UID="<<ent->getUid(); break;
        default: break;
      }
*/
      tagID.clear();
      ent->getAllTagID (tagID);
      if (ent->getLevel()==0)          
        fprintf(outFile, "E 0 %d %d\n", numberid[FMDB_Ent_GetID (ent)], tagID.size());
      else
        fprintf(outFile, "E %d %d %d\n", ent->getLevel(), FMDB_Ent_GetID (ent), tagID.size());
      for (tagIter = tagID.begin(); tagIter != tagID.end(); ++tagIter)
      {         
        tag = *tagIter;
        FMDB_Tag_GetType (mesh, tag, &tag_type);
        FMDB_Tag_GetSize (mesh, tag, &tag_size);
                    
        fprintf(outFile, "%d ", tag);
        switch (tag_type)
        {       
          case 0:  // byte
                  {
                    void* byte_data = (void*)calloc(tag_size, sizeof(char));
                    FMDB_Ent_GetByteTag (mesh, ent, tag, &byte_data, &byte_size);
                    fprintf(outFile, "%d %s\n", byte_size, byte_data);
                    delete [] byte_data;
                  } 
                  break;
          case 1: // int
                  if (tag_size==1)                  {
                    FMDB_Ent_GetIntTag (mesh, ent, tag, &int_data);
                    fprintf(outFile, "%d\n", int_data);
                  }
                  else
                  {
                    int* arr_data = new int[tag_size];
                    FMDB_Ent_GetIntArrTag (mesh, ent, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%d ", arr_data[i]);
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          case 2: // double
                  if (tag_size==1)
                  {
                    FMDB_Ent_GetDblTag (mesh, ent, tag, &dbl_data);
                    fprintf(outFile, "%lf\n",dbl_data);
                  }
                  else
                  {
                    double* arr_data = new double[tag_size];
                    FMDB_Ent_GetDblArrTag (mesh, ent, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%lf ", arr_data[i]);
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          case 3: // entity handle
                  if (tag_size==1)
                  {
                    FMDB_Ent_GetEntTag (mesh, ent, tag, &ent_data);
                    if (ent_data->getLevel()==0)
                      fprintf(outFile, "0 %d\n", numberid[FMDB_Ent_GetID(ent_data)]);
                    else
                      fprintf(outFile, "%d %d\n", ent_data->getLevel(), FMDB_Ent_GetID(ent_data));                  }
                  else
                  {
                    pMeshEnt* arr_data = new pMeshEnt[tag_size];
                    FMDB_Ent_GetEntArrTag (mesh, ent, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                    {
                      if ((arr_data[i])->getLevel()==0)
                        fprintf(outFile, "0 %d ", numberid[FMDB_Ent_GetID(arr_data[i])]);
                      else
                        fprintf(outFile, "%d %d ", (arr_data[i])->getLevel(), FMDB_Ent_GetID(arr_data[i]));
                    }
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
        case 4: // entity set handle
                 if (tag_size==1)
                  {
                    FMDB_Ent_GetSetTag (mesh, ent, tag, &eset_data);
                    fprintf(outFile, "%d\n", FMDB_Set_GetID(eset_data));
                  }
                  else
                  {
                    pEntSet* arr_data = new pEntSet[tag_size];
                    FMDB_Ent_GetSetArrTag (mesh, ent, tag, &arr_data, &arr_size);
                    for (int i=0; i<arr_size; ++i)
                      fprintf(outFile, "%d ", FMDB_Set_GetID(arr_data[i]));
                    fprintf(outFile, "\n");
                    delete [] arr_data;
                  }
                  break;
          default: break;
        }  // switch
      } // for each tag of ent 
    }  // for taggedEnt
  } // numTaggedPart + taggedEntSet + taggedEnt > 0

  // remove id's
  FMDB_Mesh_DelSetID(mesh);
  FMDB_Part_DelEntID(part, 4);  

#ifdef MATCHING
  if(!matchVtxs.empty() || !matchEdgs.empty() || !matchFcs.empty() ){
    fprintf(outFile, "Matching\n");
    
    fprintf(outFile, "%d %d %d\n", matchVtxs.size(), matchEdgs.size(), matchFcs.size());
    for(vector<vector<pVertex>* >::iterator iter1=matchVtxs.begin(); iter1!=matchVtxs.end();iter1++){
      vector<pVertex>* tmpSet = *iter1;
      fprintf(outFile, "%d ", tmpSet->size());
      int ID; 
      for(vector<pVertex>::iterator iter2=tmpSet->begin(); iter2!=tmpSet->end(); iter2++){
	vertex = *iter2;
        EN_deleteData(vertex, matchId);
	fprintf(outFile, "%d ", numberid[EN_id((pEntity)vertex)]);
      }
      fprintf(outFile, "\n");
      delete tmpSet; 
    }
    
    for(vector<vector<pEdge>*>::iterator iter1=matchEdgs.begin(); iter1!=matchEdgs.end();iter1++){
      vector<pEdge>* tmpSet = *iter1;
      fprintf(outFile, "%d ", tmpSet->size());
      for(vector<pEdge>::iterator iter2=tmpSet->begin(); iter2!=tmpSet->end(); iter2++){
	edge = *iter2;
        EN_deleteData(edge, matchId);
	pGEntity classifyon=edge->getClassification();
	fprintf(outFile, "%d %d ", GEN_tag(classifyon), GEN_type(classifyon));
	for (int j=0; j<2 ;j++)
          fprintf(outFile, "%d ",numberid[EN_id(E_vertex(edge,j))]);
      }
      fprintf(outFile, "\n");
      delete tmpSet; 
    }
    
    for(vector<vector<pFace>* >::iterator iter1=matchFcs.begin(); iter1!=matchFcs.end();iter1++){
      vector<pFace>* tmpSet = *iter1;
      int numEdges = F_numEdges(*(tmpSet->begin()));
      fprintf(outFile, "%d %d ", tmpSet->size(), numEdges);
      for(vector<pFace>::iterator iter2=tmpSet->begin(); iter2!=tmpSet->end(); iter2++){
	face = *iter2;
        EN_deleteData(face, matchId);
	pPList vlist = F_vertices(face, 1);
	void* it = 0;
	pVertex tmpVertex;
	while(tmpVertex = (pVertex)PList_next(vlist, &it))
	  fprintf(outFile, "%d ", numberid[EN_id((pEntity)tmpVertex)]);
      }
      fprintf(outFile, "\n");
      delete tmpSet; 
    }

  } // if(!matchVtxs.empty() || !matchEdgs.empty() || !matchFcs.empty())

  MD_deleteMeshDataId(matchId);
#endif 
  fclose(outFile);
}
