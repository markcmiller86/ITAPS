/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <fstream>
#include "FMDB.h"
#include "mMesh.h"

using std::vector;
using std::set; 
using std::cout;
using std::ofstream;
using std::ostream;
using std::istream;
using std::endl;

// **********************************************************
int importSMS(mMesh *mesh, const char *fName)
// **********************************************************
{
  pPart part;
  FMDB_Mesh_GetPart(mesh, 0, part);

  FILE *in = fopen (fName,"r");
  if(!in)
    return SCUtil_FILE_NOT_FOUND;
 
  char line[256];
  int i,j;
  
  int NbRegions=0,NbFaces,NbEdges,NbVertices,NbPoints;
  int GEntityType,GEntityId,EntityNbConnections;
  int Dummy;
  int VertexId1,VertexId2;
  int Edge1,Edge2,Edge3;
  int Face1, Face2, Face3, Face4;
  int nbPts,NbEdgesOnFace,NbFacesOnRegion;
  double x,y,z;

  fscanf(in,"%s %d",line,&Dummy);
  typedef GEntity* (*entityBy_FP)(SGModel*,int,int);
  entityBy_FP fp = GM_entityByTag;
    
  fscanf(in,"%d %d %d %d %d",&NbRegions,&NbFaces,&NbEdges,
                               &NbVertices,&NbPoints);

#ifdef FLEXDB
  if (NbRegions>0) 
    set_MRM_oneLevel(part,3);
  else 
    set_MRM_oneLevel(part,2);
  part->setMeshModFunctors(true); // one-level
#endif

  if (ParUtil::Instance()->rank()!=0) return SCUtil_SUCCESS;
  
  cout<<"\n"<<fName<<": reading "<<NbVertices<<" vertices, ";
  double u,v;
  int patch;

// *******************************
//	Read Vertices
// *******************************
  std::vector<mVertex*> vertices;
  mVertex* vv;        
  for(i=0;i<NbVertices;i++)
  {
    fscanf(in,"%d",&GEntityId); 
    if (GEntityId >= 0)
    {      fscanf(in,"%d %d %lf %lf %lf",&GEntityType,&EntityNbConnections,
	                                  &x,&y,&z);
      vv = part->createVertex(i+1,x,y,z,
	                 part->getGEntity(GEntityId,GEntityType,fp)); 
      vertices.push_back(vv);
	    
      switch(GEntityType)
      {
        case 1:
            fscanf(in,"%le",&u);
	    vv->attachVector (FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector (u,0,0) );
            break;
  	case 2:
	    fscanf(in,"%le %le %d",&u,&v,&patch);	
	    vv->attachVector (FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector (u,v,patch) );
   	    break;
 	default: break;
      }
    }
  } // end of reading vertices

// *******************************
//	Read Edges
// *******************************

  std::vector<mEntity*> edges;
  mVertex* v1;
  mVertex* v2;
  mEntity* e;
    
  cout<<NbEdges<<" edges, ";
  
  for(i=0;i<NbEdges;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if (GEntityId >= 0)
    {
      fscanf(in,"%d %d %d %d %d",&GEntityType, &VertexId1,&VertexId2,
	           &EntityNbConnections,&nbPts);
      
      v1 = vertices[VertexId1-1];
      v2 = vertices[VertexId2-1];
      e = M_createE(part, v1, v2, part->getGEntity(GEntityId,GEntityType,fp));
      edges.push_back(e);
      for(int j=0;j<nbPts;j++)
      {
	fscanf(in,"%lf %lf %lf ", &x, &y, &z);
	pPoint pt = P_new();
	P_setPos(pt, x, y, z);
        switch(GEntityType)
        {
   	  case 1: fscanf(in,"%le",&u);
                 FMDB_P_setParametricPos(pt, u, 0, 0);
		 break;
	  case 2: fscanf(in,"%le %le %d",&u,&v,&patch);
                 FMDB_P_setParametricPos(pt, u, v, 0);
		 break;
 	  default: break;
        }
        E_setPoint(e, pt);
      }
    }
  }  // end of reading edges

// *******************************
//	Read Faces
// *******************************

  std::vector<mEntity*> faces;
  mEntity* f;
  mEntity* eg[4];
  cout<<NbFaces<<" faces";
  
  for(i=0;i<NbFaces;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if(GEntityId >= 0)
    {
      fscanf(in,"%d %d",&GEntityType, &NbEdgesOnFace);
      for(int j=0; j<NbEdgesOnFace; j++) {
		fscanf(in, "%d ", &Edge1);
		eg[j] = edges[abs(Edge1)-1];
	  }
	  fscanf(in, "%d ",&nbPts);
      f = M_createF(part, NbEdgesOnFace, eg, 0, part->getGEntity(GEntityId,GEntityType,fp));
      faces.push_back(f);

      for(int j=0;j<nbPts;j++)
      {
	switch(GEntityType)
	{
	  case 0: break;
	  case 1: fscanf(in,"%le",&u);
		 break;
	  case 2: fscanf(in,"%le %le %d",&u,&v,&patch);
		 break;
	  case 3: break;
	}
      }
    }
  } // end of reading faces

// *******************************
//	Read Regions
// *******************************
  if (NbRegions>0)
    cout<<", "<<NbRegions<<" regions ";
  mEntity* fc[6];
  mEntity* r;
  std::vector<mEntity*> regions;
  for(i=0;i<NbRegions;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if (GEntityId >= 0)
    {
      fscanf(in,"%d",&NbFacesOnRegion);
      for(int j=0; j<NbFacesOnRegion; j++) {
	   fscanf(in, "%d ", &Face1);
	   fc[j] = faces[abs(Face1)-1];
	  }
	  fscanf(in, "%d ", &Dummy);
	  
	  r = M_createR(part,NbFacesOnRegion,fc,0,part->getGEntity(GEntityId,3,fp));
          regions.push_back(r);
    }
  } // end of reading regions


// *******************************
//	Read Entity Sets
// *******************************
  int MATCHING=0;
  int NbEntSets=0;
  if (fscanf(in, "%s", line)!= EOF)
    MATCHING=1;
  vector<pEntSet> entsets;
  pMeshEnt ent;
  pEntSet eset;
  int esetId;
 
  if (MATCHING==1 && !strcmp(line,"EntitySet"))
  {
    fscanf(in, "%d", &NbEntSets);
    cout<<", "<<NbEntSets<<" entity sets";
    int isList, numEnts, entType, entId, numSub, numChild, subId, childId;
    
    int eset_cnt=0;
    for (; eset_cnt<NbEntSets; ++eset_cnt)
    {
      fscanf(in, "%d %d", &isList, &numEnts); 
      eset = mEntitySet::createEntitySet(mesh, isList);
      eset->attachInt(FMDB_Util::Instance()->getId(),eset_cnt); // attach ID starting from 0
      mesh->addEntSet(eset);
      entsets.push_back(eset);
      for (int ent_cnt=0; ent_cnt<numEnts; ++ent_cnt)
      {
        fscanf(in, "%d %d", &entType, &entId);
        switch(entType)
        {
          case 0: eset->addEntity(vertices[entId-1]);
                  break;
          case 1: eset->addEntity(edges[entId-1]);
                  break;
          case 2: eset->addEntity(faces[entId-1]);
                  break;
          case 3: eset->addEntity(regions[entId-1]);
                  break;
          default: break;
        }  // switch (entType)
      } // for ent_cnt
    } // for eset_cnt
    
    
    for (eset_cnt=0; eset_cnt<NbEntSets; ++eset_cnt)
    {  // set entity set relations
      fscanf(in, "%d %d %d", &esetId, &numSub, &numChild); 
      for (i=0; i<numSub; ++i)
      {
        fscanf(in, "%d", &subId);
        entsets[esetId]->addSubset(entsets[subId]);
      } // for numSub
      for (i=0; i<numChild; ++i)
      {
        fscanf(in, "%d", &childId);
        entsets[esetId]->addChild(entsets[childId]);
      } // for numChild
    }  // for ent_cnt  
    if (fscanf(in, "%s", line) == EOF)
      MATCHING=0;
  }  // if (MATCHING==1 && strcmp(line,"EntitySet")) 

  int numTag=0;
  if (MATCHING==1 && !strcmp(line,"Tag"))
  {
    int i, tag_size, tag_type, numTaggedHandle;
    unsigned int old_tag, new_tag;
    int int_data, ent_type, ent_ID, ent_data_type, ent_data_ID, opq_data_size;
    double dbl_data;
    mEntity *ent, *ent_data;
    pEntSet eset;
    char* opq_data = (char*)calloc(256, sizeof(char));
    
    std::map<unsigned int, unsigned int> tag_map;
    fscanf(in, "%d %d", &numTag, &numTaggedHandle);
    cout<<", "<<numTag<<" tags\n";

    for (i=0; i<numTag; ++i) //restore tags
    {
      // this shall be rewritten to handle multi-word tag name
      fscanf(in, "%d", &old_tag);
      char dummy_str[256];
      std::string tag_name="";
      while (1) // read tag name
      {
        fscanf(in, "%s", dummy_str);
        if (strcmp(dummy_str, "EndOfName"))
          tag_name = tag_name + dummy_str + " "; 
        else
        {
          tag_name.erase(tag_name.end()-1);
          break;
        }
      } 
      fscanf(in, "%d %d", &tag_type, &tag_size);
      if (FMDB_Tag_Create (mesh, tag_name.c_str(), tag_type, tag_size, 1, &new_tag))
        FMDB_Tag_GetHandle (mesh, tag_name.c_str(), &new_tag);
      tag_map.insert(std::map<unsigned int, unsigned int>::value_type(old_tag, new_tag));
    } // numTag

    // restore tags
    int data_obj, data_type, data_ID, num_tag_data;
    for (int i_handle=0; i_handle<numTaggedHandle; ++i_handle) // restore part tags 
    {
      char dummy_str[2];
      fscanf(in, "%s %d %d %d",dummy_str, &data_type, &data_ID, &num_tag_data);
      if (!strcmp(dummy_str, "P"))
      {
        data_obj=1; // part
      }
      else if (!strcmp(dummy_str, "S"))
      {
        data_obj=2; // entity set
        eset = entsets[data_ID];
      }
      else if (!strcmp(dummy_str, "E"))
      {
        data_obj=3; // entity
        switch (data_type)
        {
          case 0: ent = vertices[data_ID-1]; break;
          case 1: ent = edges[data_ID-1]; break;
          case 2: ent = faces[data_ID-1]; break;
          case 3: ent = regions[data_ID-1]; break;
          default: break;
        }
      }
      for (int i_tag=0; i_tag<num_tag_data; ++i_tag)
      {
      fscanf(in, "%d", &old_tag); 

      new_tag = tag_map[old_tag];
      FMDB_Tag_GetType(mesh, new_tag, &tag_type);
      FMDB_Tag_GetSize(mesh, new_tag, &tag_size);

      switch (tag_type)
      {
        case 0: // bytes 
                fscanf(in, "%d %s", &opq_data_size, opq_data);
                if (data_obj==1) 
                  FMDB_Part_SetByteTag (part, new_tag, opq_data, opq_data_size);
                else if (data_obj==2) // entity set
                  FMDB_Set_SetByteTag (eset, new_tag, opq_data, opq_data_size);
                else // entity
                  FMDB_Ent_SetByteTag (mesh, ent, new_tag, opq_data, opq_data_size);
                break;
        case 1: // integer
                if (tag_size==1) // integer
                {
                  fscanf(in, "%d", &int_data);
                  if (data_obj==1)
                    FMDB_Part_SetIntTag (part, new_tag, int_data);
                  else if (data_obj==2)
                    FMDB_Set_SetIntTag (eset, new_tag, int_data);
                  else
                    FMDB_Ent_SetIntTag (mesh, ent, new_tag, int_data);
                }
                else // integer array
                {
                  int* arr_data =  new int[tag_size];
                  for (int i=0; i<tag_size; ++i)
                    fscanf(in, "%d", &arr_data[i]);
                  if (data_obj==1)
                    FMDB_Part_SetIntArrTag (part, new_tag, arr_data, tag_size);
                  else if (data_obj==2)
                    FMDB_Set_SetIntArrTag (eset, new_tag, arr_data, tag_size);
                  else
                    FMDB_Ent_SetIntArrTag (mesh, ent, new_tag, arr_data, tag_size);
                  delete [] arr_data;
                }
                break;
        case 2: // double
                if (tag_size==1) // double 
                {
                  fscanf(in, "%lf", &dbl_data);
                  if (data_obj==1)
                    FMDB_Part_SetDblTag (part, new_tag, dbl_data);
                  else if (data_obj==2)
                    FMDB_Set_SetDblTag (eset, new_tag, dbl_data);
                  else
                    FMDB_Ent_SetDblTag (mesh, ent, new_tag, dbl_data);
                }
                else // double array
                {
                  double* arr_data =  new double[tag_size];
                  for (int i=0; i<tag_size; ++i)
                    fscanf(in, "%lf", &arr_data[i]);
                  if (data_obj==1)
                    FMDB_Part_SetDblArrTag (part, new_tag, arr_data, tag_size);
                  else if (data_obj==2)
                    FMDB_Set_SetDblArrTag (eset, new_tag, arr_data, tag_size);  
                  else
                    FMDB_Ent_SetDblArrTag (mesh, ent, new_tag, arr_data, tag_size);
                  delete [] arr_data;                  
                }
                break;
        case 3: // entity
                if (tag_size==1) // double 
                {
                  fscanf(in, "%d %d", &ent_data_type, &ent_data_ID);
                  switch (ent_data_type)
                  {
                    case 0: ent_data = vertices[ent_data_ID-1]; break;
                    case 1: ent_data = edges[ent_data_ID-1]; break;
                    case 2: ent_data = faces[ent_data_ID-1]; break;
                    case 3: ent_data = regions[ent_data_ID-1]; break;
                    default: break;
                  }
                  if (data_obj==1)
                    FMDB_Part_SetEntTag (part, new_tag, ent_data);
                  else if (data_obj==2)
                    FMDB_Set_SetEntTag (eset, new_tag, ent_data);
                  else
                    FMDB_Ent_SetEntTag (mesh, ent, new_tag, ent_data);
                }
                else // entity array
                {
                  pMeshEnt* arr_data =  new pMeshEnt[tag_size];
                  for (int i=0; i<tag_size; ++i)
                  {
                    fscanf(in, "%d %d", &ent_data_type, &ent_data_ID);
                    switch (ent_data_type)
                    {
                      case 0: arr_data[i] = vertices[ent_data_ID-1]; break;
                      case 1: arr_data[i] = edges[ent_data_ID-1]; break;
                      case 2: arr_data[i] = faces[ent_data_ID-1]; break;
                      case 3: arr_data[i] = regions[ent_data_ID-1]; break;
                      default: break;
                    }
                  }
                  if (data_obj==1)
                    FMDB_Part_SetEntArrTag (part, new_tag, arr_data, tag_size);
                  else if (data_obj==2)
                    FMDB_Set_SetEntArrTag (eset, new_tag, arr_data, tag_size);
                  else
                    FMDB_Ent_SetEntArrTag (mesh, ent, new_tag, arr_data, tag_size);
                  delete [] arr_data;  
                }
                break;
        case 4: // entity set 
                if (tag_size==1) // entity set 
                {
                  fscanf(in, "%d", &esetId);
                  if (data_obj==1)
                    FMDB_Part_SetSetTag (part, new_tag, entsets[esetId]);
                  else if (data_obj==2)
                    FMDB_Set_SetSetTag (eset, new_tag, entsets[esetId]);
                  else
	            FMDB_Ent_SetSetTag (mesh, ent, new_tag, entsets[esetId]);
                }
                else // entity set array
                {
                  pEntSet* arr_data =  new pEntSet[tag_size];
                  for (int i=0; i<tag_size; ++i)
                  {
                    fscanf(in, "%d", &esetId);
                    arr_data[i] = entsets[esetId];
                  }
                  if (data_obj==1)
                    FMDB_Part_SetSetArrTag (part, new_tag, arr_data, tag_size);
                  else if (data_obj==2)
                    FMDB_Set_SetSetArrTag (eset, new_tag, arr_data, tag_size);
                  else 
                    FMDB_Ent_SetSetArrTag (mesh, ent, new_tag, arr_data, tag_size);
                  delete [] arr_data;
                }   
                break;
        default: break;
      } // switch tag_type
     } // for i_tag
    } // for i_handle

    if (fscanf(in, "%s", line) == EOF)
      MATCHING=0;
  } // if (MATCHING==1 && strcmp(line,"Tag")
  cout<<"\n";

#ifdef MATCHING
  pGModel model = M_model(part); 
  if( GM_pbc(model) ) 

  if(MATCHING)   
  {           // line = "matching" 
  
  // *******************************
  //    Read Matched Mesh Entity
  // *******************************
  int VertexId[4]; 
  int numVtxSet, numEdgeSet, numFaceSet; 
  fscanf(in, "%d %d %d", & numVtxSet, & numEdgeSet, &numFaceSet); 
 
  std::list<mEntity*> mlist;  // matched entities list   
  pVertex v; 
  std::list<mEntity*>::iterator iter1, iter2;
  pEntity ent;
  for(int icount=0; icount<numVtxSet; icount++){
    mlist.clear(); 
    fscanf(in, "%d", &NbVertices);
    for(int jcount=0; jcount< NbVertices; jcount++){
      fscanf(in, "%d", &VertexId[0]);
      v = (mVertex*)vertices[VertexId[0]-1];
      mlist.push_back(v);
    } 
    
   for(iter1=mlist.begin(); iter1!=mlist.end(); iter1++)
    for(iter2=mlist.begin(); iter2!=mlist.end(); iter2++) {
      ent = *iter1;
      if(ent!=*iter2)
         ent->addMatchEnt(0, *iter2);
    }
  }
   
  pEdge e; 
  for(int i=0; i<numEdgeSet; i++){
    mlist.clear(); 
    fscanf(in, "%d", &NbEdges);
    for(int j=0; j<NbEdges; j++){
      fscanf(in, "%d %d %d %d", &GEntityId, &GEntityType, &VertexId[0], &VertexId[1]);
      e = E_exist(vertices[VertexId[0]-1], vertices[VertexId[1]-1]);
      if(!e) {
        cerr<<"One mesh edge that matches any other edge does not exist."<<endl; 
	return SCUtil_FAILURE; 
      }  
      mlist.push_back(e);
    }
   
   for(iter1=mlist.begin(); iter1!=mlist.end(); iter1++)
    for(iter2=mlist.begin(); iter2!=mlist.end(); iter2++) {
      ent = *iter1;
      if(ent!=*iter2)
         ent->addMatchEnt(0, *iter2);
    } 
  }
  
  pFace f; 
  for(int i=0; i<numFaceSet; i++){
    mlist.clear(); 
    fscanf(in, "%d %d", &NbFaces, &NbEdgesOnFace);
    for(int j=0; j<NbFaces; j++){
      for(int k=0; k<NbEdgesOnFace; k++)
   fscanf(in, "%d", &VertexId[k]);
      if(NbEdgesOnFace==4)
   f = F_exist(0, vertices[VertexId[0]-1], vertices[VertexId[1]-1], vertices[VertexId[2]-1], vertices[VertexId[3]-1]);
      else
   f = F_exist(0, vertices[VertexId[0]-1], vertices[VertexId[1]-1], vertices[VertexId[2]-1], 0);
      if(!f){
   cout<<"One mesh face classified on model face is not loaded."<<endl; 
      }
      mlist.push_back(f);
    }

   for(iter1=mlist.begin(); iter1!=mlist.end(); iter1++)
    for(iter2=mlist.begin(); iter2!=mlist.end(); iter2++) {
      ent = *iter1;
      if(ent!=*iter2)
         ent->addMatchEnt(0, *iter2);
    }
  
  }
  }
#endif  // MATCHING  
  fclose (in);
  return SCUtil_SUCCESS;
}
