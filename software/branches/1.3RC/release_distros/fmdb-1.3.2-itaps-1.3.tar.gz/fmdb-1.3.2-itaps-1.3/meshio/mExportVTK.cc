/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "M_writeVTKFile.h" 

using namespace std; 


void exportPVTK(const char* fname, int numPtn)
{
  char realName[256];
  sprintf(realName,"%s.pvtu",fname); 

   FILE* outFile = fopen(realName, "w");  
   if (!outFile)
       throw new mException (__LINE__,__FILE__,"unable to create pvtu File");

  fprintf(outFile, "<?xml version=\"1.0\"?>\n"); 
  fprintf(outFile, "<VTKFile type=\"PUnstructuredGrid\" version=\"0.1\" byte_order=\"LittleEndian\">\n");
  fprintf(outFile, "<PUnstructuredGrid GhostLevel=\"0\">\n");

  //  fprintf(outFile, "<PCellData Scalars=\"mypid\" Scalars=\"partId\" >\n");
  //  fprintf(outFile, "<PDataArray type=\"Int32\" Name=\"mypid\" format=\"ascii\"/>\n");     // process rank   
  fprintf(outFile, "<PCellData Scalars=\"partId\" >\n");
  fprintf(outFile, "<PDataArray type=\"Int32\" Name=\"partId\" format=\"ascii\"/>\n");    // global part id
  // fprintf(outFile, "<PDataArray type=\"Int32\" Name=\"mypid\" format=\"ascii\"/>\n");     // process rank 
  fprintf(outFile, "</PCellData>\n");

  fprintf(outFile, "<PPoints>\n<PDataArray type=\"Float32\" NumberOfComponents=\"3\"/>\n </PPoints>\n"); 

  fprintf(outFile, "<PCells>\n");
  fprintf(outFile, "<PDataArray type=\"Int32\"  Name=\"connectivity\" format=\"ascii\"/>\n");
  fprintf(outFile, "<PDataArray type=\"Int32\" Name=\"offsets\" format=\"ascii\"/>\n");
  fprintf(outFile, "<PDataArray type=\"UInt8\" Name=\"types\" format=\"ascii\"/>\n");
  fprintf(outFile, "</PCells>\n");

  for (int pid=0; pid<numPtn; pid++)
    {
      fprintf(outFile, "<Piece Source=\"%s%d.vtu\"/>\n", fname,pid); 
    }

  fprintf(outFile, "</PUnstructuredGrid>\n</VTKFile>\n");
   fclose(outFile);    
}


void exportVTK(mPart *mesh, const char* fname, int partId) 
{
   FILE* outFile = fopen(fname, "w");  
   if (!outFile)
       throw new mException (__LINE__,__FILE__,"unable to create vtu File");

//    int mDim = M_getMaxDim(mesh);
   int mDim = M_dimension(mesh); 
  
   int numRgn; 
   int numVtc=M_numVertices(mesh);
   if(mDim==3)
     numRgn=M_numRegions(mesh); 
   else
     numRgn=M_numFaces(mesh);
     
   unsigned int tagId = FMDB_Util::Instance()->getId();   
   // int mypid = ParUtil::Instance()->rank(); 

  fprintf(outFile, "<?xml version=\"1.0\"?>\n"); 
  fprintf(outFile, "<VTKFile type=\"UnstructuredGrid\" version=\"0.1\" byte_order=\"LittleEndian\">\n");
  fprintf(outFile, "<UnstructuredGrid>\n"); 
  
  fprintf(outFile, "<Piece NumberOfPoints=\"%d\"  NumberOfCells=\"%d\">\n", numVtc, numRgn);
  fprintf(outFile, "<Points>\n "); 
  fprintf(outFile, "<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n");

  mEntity* ent; 
  VIter viter = M_vertexIter(mesh);
  int i=0, id; 
  while( ent = (mEntity*)VIter_next(viter)) {
    double loc[3];  
    EN_attachDataInt(ent, tagId, i);
    //  fprintf(outFile, " \n%d", EN_id(ent)); 
    V_coord((pVertex)ent,loc);  
   // SCOREC::Util::mPoint p(((mVertex*)ent)->point());
     fprintf(outFile, "  %.15f  %.15f  %.15f  \n", loc[0], loc[1], loc[2]); 
  //   fprintf(outFile, "  %.15f  %.15f  %.15f  \n", p(0), p(1), p(2)); 
    i++;
  }
//  VIter_reset(viter);
   VIter_delete(viter);

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n"); 
  fprintf(outFile, "</Points>\n"); 
 
  // Header for vtk
  fprintf(outFile, "<Cells>\n");  
  fprintf(outFile, "<DataArray type=\"Int32\"  Name=\"connectivity\" format=\"ascii\">\n");  

  int numV[numRgn];
  int type[numRgn];  

  if(mDim==3) {
    RIter riter = M_regionIter(mesh);
    numV[0]=0; 
    int iNum=0; 
    while(ent = (mEntity*)RIter_next(riter) ) {
      void *iter=0;  
      iNum++; 
      type[iNum]=M_GetElementType(ent);
      pEntity vt;
      pPList vtxs = R_vertices((pRegion)ent,1); 
      numV[iNum]=PList_size(vtxs)+numV[iNum-1];
      while ((vt = (pEntity)PList_next(vtxs,&iter))) 
	{	   
	  int id; 
	  EN_getDataInt(vt, tagId, &id);
	  fprintf(outFile, " %d", id); 
	}
      PList_delete(vtxs);
    }
    RIter_delete(riter);
  }
  else {
    FIter fiter = M_faceIter(mesh);
    numV[0]=0; 
    int iNum=0; 
    while(ent = (mEntity*)FIter_next(fiter) ) {
      void *iter=0;  
      iNum++; 
      type[iNum]=M_GetElementType(ent);
      pEntity vt;
      pPList vtxs = F_vertices((pFace)ent,1); 
      numV[iNum]=PList_size(vtxs)+numV[iNum-1];
      while ((vt = (pEntity)PList_next(vtxs,&iter))) 
	{	   
	  int id; 
	  EN_getDataInt(vt, tagId, &id);
	  fprintf(outFile, " %d", id); 
	}
      PList_delete(vtxs);
    }
    FIter_delete(fiter);
  }

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");
  fprintf(outFile, "<DataArray type=\"Int32\" Name=\"offsets\" format=\"ascii\">\n");
        
  for (int i=1; i<numRgn+1; i++)
      fprintf(outFile, " %d ", numV[i]);  

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n"); 
  fprintf(outFile, "<DataArray type=\"UInt8\" Name=\"types\" format=\"ascii\">\n"); 

  for (int i=1; i<numRgn+1; i++)
    switch(type[i]) {
    case TRI:
      fprintf(outFile, " 5 ");
      break; 
    case QUAD:
      fprintf(outFile, " 9 ");
      break; 
    case TET:
      fprintf(outFile, " 10 ");
      break; 
    case  PYRAMID :
      fprintf(outFile, " 14 ");
      break;
    case PRISM :
      fprintf(outFile, " 13 ");
      break;
    case HEX :
      fprintf(outFile, " 12  ");
      break; 
    default:
      cout<<"region topology ["<<i<<"] NOT supported"<<endl;
    exit(0);
    }
  
  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");  
  fprintf(outFile, "</Cells>\n"); 

  if(partId!=-1) {
    // fprintf(outFile, "<CellData Scalars=\"mypid\" Scalars=\"partId\">\n");
    fprintf(outFile, "<CellData Scalars=\"partId\">\n");
 /*    fprintf(outFile, "<DataArray type=\"Int32\" Name=\"mypid\" format=\"ascii\">\n"); */
/*     for (int i=1; i<numRgn+1; i++) */
/*       fprintf(outFile, " %d ", mypid); */
/*     fprintf(outFile, "\n</DataArray>\n"); */ 
    
    fprintf(outFile, "<DataArray type=\"Int32\" Name=\"partId\" format=\"ascii\">\n"); 
    for (int i=1; i<numRgn+1; i++)
      fprintf(outFile, " %d ", partId); 
    fprintf(outFile, "\n</DataArray>\n");
    
    fprintf(outFile, "</CellData>\n");  

    //    fprintf(outFile, "<CellData Scalars=\"mypid\">\n");

//    fprintf(outFile, "<DataArray type=\"Int32\" Name=\"mypid\" format=\"ascii\">\n"); 
  //  for (int i=1; i<numRgn+1; i++)
   //   fprintf(outFile, " %d ", ParUtil::Instance()->rank()); 
  //  fprintf(outFile, "\n</DataArray>\n");
    
  //  fprintf(outFile, "</CellData>\n");  
  }

  fprintf(outFile, "</Piece>\n</UnstructuredGrid>\n</VTKFile>\n");
  
  viter = M_vertexIter(mesh); 
  while( ent = (mEntity*)VIter_next(viter)) {
  //  if(EN_getDataInt(ent, tagId, &id))
      EN_deleteData(ent, tagId);
  }
  VIter_delete(viter);
  
 fclose(outFile);  
}

// fname can be given with any extension.
// Aug 05, 2007, add the functionality to display multiple parts per process.  
void M_writeVTKFile (vector<pMesh> meshes,const char * fname)
{
#ifdef FMDB_PARALLEL
///**********************************
///   writing XML VTK files
///**********************************

 int numPtn = ParUtil::Instance()->size(); 
 int mypid = ParUtil::Instance()->rank(); 

 int localNumPtn = meshes.size(); 
 int globalNumPtn; 
 // MPI_Allreduce(&localNumPtn, &globalNumPtn, 1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
/*  int maxNumPtn;  */
/*  MPI_Allreduce(&localNumPtn, &maxNumPtn, 1,MPI_INT,MPI_MAX,MPI_COMM_WORLD); */

/*  globalNumPtn = maxNumPtn * numPtn;               // Assume the localNumPtn is the same per process.    */  
 //  int dim=M_getMaxDim(mesh);

 // get the sum of local number of parts from previous processes
 int preSum = 0; 
 MPI_Allreduce(&localNumPtn, &globalNumPtn, 1,MPI_INT,MPI_SUM,MPI_COMM_WORLD);
 MPI_Scan(&localNumPtn, &preSum, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);  
 preSum = preSum-localNumPtn; 
 
 if(globalNumPtn>1)
   {
     // piece files 
     for (int pid=0; pid<localNumPtn; pid++)                   
       {
	 char realName[256];
	 sprintf(realName,"%s%d.vtu",fname,preSum+pid);  // Assume the localNumPtn is the same per process. 
	 exportVTK(meshes[pid], realName,  preSum+pid);  
       }  
     
     // PUnstructuredGrid file
     if (mypid == 0)
       { 
	 exportPVTK(fname,globalNumPtn); 
       }
   }
 else
#endif
   {
     char realName[256];
     sprintf(realName,"%s.vtu",fname);
     exportVTK(meshes[0], realName,  -1);                // Assume the first mesh in meshes is not empty.   
   }

#ifdef FMDB_PARALLEL
  ParUtil::Instance()->Barrier(1, "finish vtk"); 
#endif
}


void M_writeVTKFile (pMesh mesh,const char * fname)
{
  vector<pMesh> meshes; 
  meshes.push_back(mesh);

  M_writeVTKFile(meshes, fname);
}

/// Function for writing out a part of a mesh in vtu format
void write_3Dpart_vtu(const char* fname, vector<pRegion> &regs)
{

   char realName[256];
   sprintf(realName,"%s.vtu",fname);

   FILE* outFile = fopen(realName, "w");
   if (!outFile)
       throw new mException (__LINE__,__FILE__,"unable to create vtu File");

//    int mDim = M_getMaxDim(mesh);
   int numRgn = regs.size();
   int numVtc;

   unsigned int tagId = FMDB_Util::Instance()->getId();
   // int mypid = ParUtil::Instance()->rank();

  set<pVertex> verts;
  set<pVertex>::iterator vIt;

  pPList rverts; 
  for (int i = 0; i < numRgn; i++)
  {
    rverts = R_vertices(regs[i],1);
    for (int j = 0; j < PList_size(rverts); ++j)
      verts.insert((pVertex)PList_item(rverts,j));
    PList_delete(rverts);
  }

  numVtc = verts.size();

  fprintf(outFile, "<?xml version=\"1.0\"?>\n");
  fprintf(outFile, "<VTKFile type=\"UnstructuredGrid\" version=\"0.1\" byte_order=\"LittleEndian\">\n");
  fprintf(outFile, "<UnstructuredGrid>\n");

  fprintf(outFile, "<Piece NumberOfPoints=\"%d\"  NumberOfCells=\"%d\">\n", numVtc, numRgn);
  fprintf(outFile, "<Points>\n ");
  fprintf(outFile, "<DataArray type=\"Float32\" NumberOfComponents=\"3\" format=\"ascii\">\n");

  mEntity* ent;
  int i=0, id;
  for (vIt = verts.begin(); vIt != verts.end(); ++vIt) {
    ent = *vIt;
    double loc[3];
    EN_attachDataInt(ent, tagId, i);
    //  fprintf(outFile, " \n%d", EN_id(ent));
    V_coord((pVertex)ent,loc);
   // SCOREC::Util::mPoint p(((mVertex*)ent)->point());
     fprintf(outFile, "  %.15f  %.15f  %.15f  \n", loc[0], loc[1], loc[2]);
  //   fprintf(outFile, "  %.15f  %.15f  %.15f  \n", p(0), p(1), p(2));
    i++;
  }

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");
  fprintf(outFile, "</Points>\n");

  // Header for vtk
  fprintf(outFile, "<Cells>\n");
  fprintf(outFile, "<DataArray type=\"Int32\"  Name=\"connectivity\" format=\"ascii\">\n");

  int numV[numRgn];
  int type[numRgn];

  numV[0]=0;
  int iNum=0;
  pPList vtxs; 
  pEntity vt;
  for (int i = 0; i < numRgn; ++i){
    ent = regs[i];
    void *iter=0;
    iNum++;
    type[iNum]=M_GetElementType(ent);
    vtxs = R_vertices((pRegion)ent,1);
    numV[iNum]=PList_size(vtxs)+numV[iNum-1];
    while ((vt = (pEntity)PList_next(vtxs,&iter)))
    {
      int id;
      EN_getDataInt(vt, tagId, &id);
      fprintf(outFile, " %d", id);
    }
    PList_delete(vtxs);
  }

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");
  fprintf(outFile, "<DataArray type=\"Int32\" Name=\"offsets\" format=\"ascii\">\n");

  for (int i=1; i<numRgn+1; ++i)
      fprintf(outFile, " %d ", numV[i]);

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");
  fprintf(outFile, "<DataArray type=\"UInt8\" Name=\"types\" format=\"ascii\">\n");

  for (int i=1; i<numRgn+1; i++)
    switch(type[i]) {
    case TRI:
      fprintf(outFile, " 5 ");
      break;
    case QUAD:
      fprintf(outFile, " 9 ");
      break;
    case TET:
      fprintf(outFile, " 10 ");
      break;
    case  PYRAMID :
      fprintf(outFile, " 14 ");
      break;
    case PRISM :
      fprintf(outFile, " 13 ");
      break;
    case HEX :
      fprintf(outFile, " 12  ");
      break;
    default:
      cout<<"region topology ["<<i<<"] NOT supported"<<endl;
    exit(0);
    }

  // Header for vtk
  fprintf(outFile, "\n</DataArray>\n");
  fprintf(outFile, "</Cells>\n");

  fprintf(outFile, "</Piece>\n</UnstructuredGrid>\n</VTKFile>\n");

  for (vIt = verts.begin(); vIt != verts.end(); vIt++) {
    ent = *vIt;
    EN_deleteData(ent, tagId);
  }

 fclose(outFile);
}
