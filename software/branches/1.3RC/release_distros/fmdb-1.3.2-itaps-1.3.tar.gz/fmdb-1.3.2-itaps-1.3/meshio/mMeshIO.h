/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _H_MESHIO_
#define _H_MESHIO_

#include "mPart.h"
int importSMS(mMesh *, const char *);
int importVTK (mPart *, const char *);
int importNCDF(mPart* mesh, const char *fname, int mid_flag=-1);
#ifdef NCDF64
int importNCDFBin(mPart* mesh, const char *fname, int mid_flag=-1);
#endif/*NCDF64*/
void exportSMS (mMesh *, const char*);
void exportVTK(mPart *mesh, const char* fname, int partId=-1);
void exportNCDF(mPart*, pGModel, const char *, const char *);
#ifdef NCDF64
void exportNCDFBin(mPart* , pGModel, const char *, const char *);
#endif/*NCDF64*/
#endif
