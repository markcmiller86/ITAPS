/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <string>
#include "mMeshIO.h"
#include "FMDB_Internals.h"
#include "oldFMDB.h"
#include "FMDB_cint.h"
#include "mPart.h"
#include "mNodeElm.h"
#include "mException.h"
#include "mFMDB.h"
#include "MeshEntTools.h"
#include "mVertex.h"
#include "GUM.h"

using std::cout;
using std::ofstream;
using std::ifstream;
using std::ostream;
using std::istream;
using std::endl;
using std::vector;
using SCOREC::Util::mPoint;

// **********************************************************
int importNCDF(pMesh theMesh, const char *fName, int mid_flag)
// **********************************************************
{
  char buf[256];
  ifstream fin (fName, ios::in|ios::binary);
  int *tet_interior, *tet_exterior, *surf_midpt_vt;
  double *surf_midpoints, xyz[3], par[3]={0., 0.};
  pVertex *verts, rgn_vert[4], ed_vert[2], fc_vert[3];
  int i, j, num[4], size[4];
  int gentid, vtid[4], tagid[4], conn[4] = {0, 1, 2, 3};
  pRegion region;
  pMeshDataId fbc = MD_newMeshDataId("bcf");
  int fcid[4][3] = {{0, 2, 1},
  {0, 3, 2},
  {0, 1, 3},
  {1, 2, 3}};
  pGEntity gent;

  if (!fin.good ()) {
    printf ("*** Can not open the input file, %s, to read.", fName);
    exit(0);
  }

  //******************************************************
  // ********  output the BC
  // ******************************************************

  inputNodeElm *inp = new inputNodeElm(theMesh, 3);

  // read the data from NCDF
  for(; !fin.eof();) {
    
    // read by line
    fin >> buf;

    // ******************************************************
    // ********  dimensions description
    // ******************************************************

    if(!strcmp (buf, "tetinterior")) {
      fin >> buf;
      fin >> buf;
      num[0] = atoi(buf);
    }
    else if(!strcmp (buf, "tetinteriorsize")) {
      fin >> buf;
      fin >> buf;
      size[0] = atoi(buf);
    }
    
    else if(!strcmp (buf, "tetexterior")) {
      fin >> buf;
      fin >> buf;
      num[1] = atoi(buf);
    }
    else if(!strcmp (buf, "tetexteriorsize")) {
      fin >> buf;
      fin >> buf;
      size[1] = atoi(buf);
    }
    else if(!strcmp (buf, "ncoords")) {
      fin >> buf;
      fin >> buf;
      num[2] = atoi(buf);
    }
    else if(!strcmp (buf, "coord_size")) {
      fin >> buf;
      fin >> buf;
      size[2] = atoi(buf);
    }
    else if(!strcmp (buf, "surface_midpoint_size")) {
      fin >> buf;
      fin >> buf;
      size[3] = atoi(buf);
    }
    else if(!strcmp (buf, "nsurface_midpoint")) {
      fin >> buf;
      fin >> buf;
      num[3] = atoi(buf);
    }
    else if(!strcmp (buf, "variables:")) {
      tet_interior = new int[size[0]*num[0]];
      tet_exterior = new int[size[1]*num[1]];
      surf_midpoints = new double[(size[3]-2)*(num[3])];
      surf_midpt_vt = new int[num[3]*2];
      verts = new pVertex[num[2]];
    }
		
    // ******************************************************
    // ********  interior tet connectivity
    // ******************************************************
    else if(!strcmp(buf, "tetrahedron_interior")) { 
      fin >> buf;
      
      num[0]--;
      for(i=0; i<num[0]; i++)
	for(j=0; j<size[0]; j++){
	  fin >> buf;
	  buf[strlen(buf)-1] = '\0';
	  tet_interior[i*size[0] + j] = atoi(buf);
	}
      
      // the last tet
      for(j=0; j<size[0]-1; j++){
	fin >> buf;
	buf[strlen(buf)-1] = '\0';
	tet_interior[i*size[0] + j] = atoi(buf);
      }
      fin >> buf;
      tet_interior[i*size[0] + j] = atoi(buf);
      num[0]++;
    }

    // ******************************************************
    // ********  exterior tet connectivity
    // ******************************************************
    else if(!strcmp(buf, "tetrahedron_exterior")) {
      
      fin >> buf;
      num[1] --;
      for(i=0; i<num[1]; i++)
	for(j=0; j<size[1]; j++){
	  fin >> buf;
	  buf[strlen(buf)-1] = '\0';
	  tet_exterior[i*size[1] + j] = atoi(buf);
	}

      // the last one
      for(j=0; j<size[1]-1; j++){
	fin >> buf;
	buf[strlen(buf)-1] = '\0';
	tet_exterior[i*size[1] + j] = atoi(buf);
      }
      
      fin >> buf;
      tet_exterior[i*size[1] + j] = atoi(buf);
      num[1] ++;

    }


    // ******************************************************
    // ********  coords of vertices
    // ******************************************************
    else if(!strcmp(buf, "coords")) {
      fin >> buf;
      gent = theMesh->getGEntity(1,3);
      for(i=0; i<num[2]-1; i++) {
	for(j=0; j<3; j++) {
	  fin >> buf;
	  buf[strlen(buf)-1] = '\0';
	  xyz[j] = atof(buf);
	}
	
	verts[i] = M_createVP2(theMesh, xyz, par, i+1, gent);
      }
      
      for(j=0; j<2; j++) {
	fin >> buf;
	buf[strlen(buf)-1] = '\0';
	xyz[j] = atof(buf);
      }
      fin >> buf;
      xyz[2] = atof(buf);
      
      verts[i] = M_createVP2(theMesh, xyz, par, i+1, gent);
    }

    // ******************************************************
    // ********  surface  middle points
    // ******************************************************
    else if(!strcmp(buf, "surface_midpoint")) {
      fin >> buf;
      for(i=0; i<num[3]-1; i++) {
	for(j=0; j<2; j++) {
	  fin >> buf;
	  buf[strlen(buf)-1] = '\0';
	  surf_midpt_vt[i*2 + j] = atoi(buf);
	}
	for(j=2; j<size[3]; j++){
	  fin >> buf;
	  buf[strlen(buf)-1] = '\0';
	  surf_midpoints[i*(size[3]-2) + j-2] = atof(buf);
	}
      }
     
      for(j=0; j<2; j++) {
	fin >> buf;
	buf[strlen(buf)-1] = '\0';
	surf_midpt_vt[i*2 + j] = atoi(buf);
      }
      for(j=2; j<size[3]-1; j++){
	fin >> buf;
	buf[strlen(buf)-1] = '\0';
	surf_midpoints[i*(size[3]-2) + j-2] = atof(buf);
      }
      fin >> buf;
      surf_midpoints[i*(size[3]-2) + j-2] = atof(buf);
    }
  }
  fin.close();

  // ******************************************************
  // ********  create the interior tet region
  // ******************************************************
  pPList negR = PList_new();
  double vol;
  pEntity ent;
  double tmpvxyz[2][3];

  for(i=0; i<num[0]; i++){
  
    gentid = tet_interior[i*size[0]];
    
    for(j=1; j<size[0]; j++) {
      vtid[j-1] = tet_interior[i*size[0]+j];
      rgn_vert[j-1] = verts[vtid[j-1]];
    }
    
   
    SCOREC::Util::mVector v12 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[1])->point());
    SCOREC::Util::mVector v13 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[2])->point());
    SCOREC::Util::mVector v14 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[3])->point());

    vol =  -(1./6.) * ((v12 % v13) * v14);
    
    // if(gentid != 1)
//       printf("The gentid of the exterior tet %d is not equal to 1", i);

    

    gent = theMesh->getGEntity(gentid,3);
    ent = inp->addElement(rgn_vert, 3, TET, VERTEX, gent);
    
    if(vol < 0.0)
      PList_appUnique(negR, ent);
    
  }
  int numNegR = PList_size(negR);

  cout<<"The total number of interior regions with negative volume: "<<PList_size(negR)<<endl;
 
  
  // ******************************************************
  // ********  create the extrior tet region
  // ******************************************************

  for(i=0; i<num[1]; i++){
  
    gentid = tet_exterior[i*size[1]];

    for(j=1; j<5; j++) {
      vtid[j-1] = tet_exterior[i*size[1]+j];
      rgn_vert[j-1] = verts[vtid[j-1]];

      tagid[j-1] = tet_exterior[i*size[1]+j+4];
    }

    SCOREC::Util::mVector v12 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[1])->point());
    SCOREC::Util::mVector v13 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[2])->point());
    SCOREC::Util::mVector v14 (((mVertex*)rgn_vert[0])->point()-((mVertex*)rgn_vert[3])->point());

    vol =  -(1./6.) * ((v12 % v13) * v14);
    
    // if(gentid != 1)
//       printf("The gentid of the exterior tet %d is not equal to 1", i);
    
    
    gent = theMesh->getGEntity(gentid,3);
    ent = inp->addElement(rgn_vert, 3, TET, VERTEX, gent);
    
    if(vol < 0.0)
      PList_appUnique(negR, ent);
    
    
    // attach the bcs to the boundary faces
    int temp;
    for(j=0; j<4; j++) {
      if(tagid[j] != -1) {
	fc_vert[0] = rgn_vert[fcid[j][0]];
        FMDB_P_setParametricPos(V_point(fc_vert[0]), 0.0, 0.0, 0.0); 
	fc_vert[1] = rgn_vert[fcid[j][1]];
	FMDB_P_setParametricPos(V_point(fc_vert[1]), 0.0, 0.0, 0.0); 
	fc_vert[2] = rgn_vert[fcid[j][2]];
	FMDB_P_setParametricPos(V_point(fc_vert[2]), 0.0, 0.0, 0.0); 

	pFace face = F_exist(0, fc_vert[0], fc_vert[1], fc_vert[2], 0);
	if(!face) {
	  cout<<"face does not exist ----"<<endl;
	}
	else {
	  if(!EN_getDataInt((pEntity)face, fbc, &temp))
	    EN_attachDataInt((pEntity)face, fbc, tagid[j]);
	  else {
	    if(temp == tagid[j])
	      cout<<"The attached id are same-----"<<endl;
	    else
	      cout<<"The attached id are different-----"<<endl;
	  }
	}
	  
      }
    }
    

  }

  cout<<"The total number of exterior regions with negative volume: "<<PList_size(negR)-numNegR<<endl;
 
  //******************************************************
  // ********  output the mesh information
  // ******************************************************
  
  printf ("\n\t Vertices =%d", M_numVertices (theMesh));
  printf ("\n\t Edges    =%d", M_numEdges (theMesh));
  printf ("\n\t Faces    =%d", M_numFaces (theMesh));
  printf ("\n\t Regions  =%d", M_numRegions (theMesh));


  //******************************************************
  //******* analyze the boundary condition
  //******************************************************
  FIter fiter = M_faceIter(theMesh);
  pFace face, ef;
  pEdge edge;

  pPList gflist = PList_new();
  int attid;
  while(face = FIter_next(fiter)) {
    if(EN_getDataInt((pEntity)face, fbc, &attid)) {
      gent = theMesh->getGEntity(attid,2);
      // set up the face classification
      face->classify(gent);
      PList_appUnique(gflist, gent);
    }
  }

  FIter_reset(fiter);
  while(face = FIter_next(fiter)) {
    int f_num_r = F_numRegions(face);
    // face has one connected region
    if(f_num_r == 1) {
      if(F_whatInType(face) == 3)
	cout<<"The face connected to one mesh region does not attach the BC"<<endl;
    }
    // face has two connected region
    else if(f_num_r == 2) {
      int ok[2];
      ok[0] = GEN_tag((pGEntity)R_whatIn(F_region(face, 0)));
      ok[1] = GEN_tag((pGEntity)R_whatIn(F_region(face, 1)));

      // face is shared by two model regions
      if(ok[0] != ok[1]) {
	if(F_whatInType(face) == 3)
	 { 
	   //cout<<"The face connected to two material mesh regions does not attach the BC"<<endl;
	 }
      }
    }
  }
  FIter_delete(fiter);


  // get all of the edges on the gedges;
  void *temp_ptr, *ptr;
  pPList f_bc_eds;
  int geid = 1;
  int gvid = 1;
  int ecount, ve, vsize, ok, f_count, numef;
  pVertex vv, startv, vt;
  pEdge e;
  pGEdge ge;
  pGVertex gv[2];
  temp_ptr = 0;
  pGEntity gfent;
  cout<<endl;  

  cout<<"gfent id is : ";
  for(int k=0; k<PList_size(gflist); k++) {
    gfent = (pGEntity)PList_item(gflist, k);
    // gent =  theMesh->getGEntity(attid,2);
    cout<<GEN_tag(gfent)<<" ";
    f_bc_eds = PList_new();
    
    // get the mesh edges that possible on gface
    fiter = M_classifiedFaceIter(theMesh, gfent, 0);
    while(face = FIter_next(fiter)) {
      for(i=0; i<3; i++) {
	edge = F_edge(face, i);
	f_count = 0;
	numef = E_numFaces(edge);
	for(j=0; j<numef; j++) {
	  ef = E_face(edge, j);
	  if(F_whatIn(ef) == gfent)
	    f_count++;
	}
	if(f_count == 1){
	  if(E_whatInType(edge) != 1)
	    PList_appUnique(f_bc_eds, edge);
	}
	else
	  edge->classify(gfent);
      }
    }
    FIter_delete(fiter);

    if(PList_size(f_bc_eds)) {
      // process the edges to set up the correct gv and ge classification
      pPList endvlist = PList_new();
      ptr = 0;
    
      // find the vertices that only have one edge in the list
      while(edge = (pEdge)PList_next(f_bc_eds, &ptr)) {
	for(i=0; i<2; i++) {
	  pVertex vt = E_vertex(edge, i);
	  ecount =0;
	  ve = V_numEdges(vt);
	  
	  for(j=0; j<ve; j++) {
	    pEdge ee = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, ee))
	      ecount++;
	  }

	  if(ecount == 1)
	    PList_appUnique(endvlist, vt);	  
	}
      }
      ptr = 0;
      while(vv = (pVertex)PList_next(endvlist, &ptr)) {
	if(V_whatInType(vv) != 0) {
	  gent = theMesh->getGEntity(gvid++,0);
	  vv->classify(gent);
	}
	else
	  cout<<"vertex already has been set up with the gv"<<endl;
      }
      
      vsize = PList_size(endvlist);
      if(vsize%2 != 0)
	cout<<"the gv size is not in pair"<<endl;

      while(PList_size(endvlist)) {
	
	vt = (pVertex)PList_item(endvlist, 0);
	PList_remItem(endvlist, vt);
	gent = theMesh->getGEntity(geid++,1);

	ok = 1;
	while(ok) {
	  
	  ve = V_numEdges(vt);
	  for(j=0; j<ve; j++) {
	    e = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, e)){
	      PList_remItem(f_bc_eds, e);
	      e->classify(gent);
	      break;
	    }
	  }
	  
	  vt = E_otherVertex(e, vt);

	  if(PList_inList(endvlist, vt)) {
	    ok = 0;
	    PList_remItem(endvlist, vt);
	  }
	}
      }
      PList_delete(endvlist);

      // need to take care of the circular model edges
      while(PList_size(f_bc_eds)) {
	
	e = (pEdge)PList_item(f_bc_eds, 0);
	gent = theMesh->getGEntity(geid++,1);
	e->classify(gent);
	
	startv = E_vertex(e, 0);
	startv->classify(gent);
	
	vt = startv;
	ok = 1;

	while(ok) {
	  
	  ve = V_numEdges(vt);
	  for(j=0; j<ve; j++) {
	    e = V_edge(vt, j);
	    if(PList_inList(f_bc_eds, e)){
	      PList_remItem(f_bc_eds, e);
	      e->classify(gent);
	      break;
	    }
	  }

	  vt = E_otherVertex(e, vt);
	  vt->classify(gent);
	  
	  if(vt == startv) {
	    ok=0;
	    PList_remItem(endvlist, vt);
	  }
	}	
      }
    }
    
    PList_delete(f_bc_eds);

    // set up the rest of edges and vertices
    fiter = M_classifiedFaceIter(theMesh, gfent, 0);
    while(face = FIter_next(fiter)) {
      for(i=0; i<3; i++) {
	edge = F_edge(face, i);
	if(E_whatInType(edge)==3) 
	  edge->classify(gfent);
	for(j=0; j<2; j++){
	  vt = E_vertex(edge, j);
	  if(V_whatInType(vt) == 3)
	    vt->classify(gfent);	    
	}
      }
    }
    FIter_delete(fiter);
  }

  cout<<endl;
  
  //Traverse all the mesh and set up face classification for all of the faces
  //with only one region connected to it
 
  PList_delete(negR);


  
  // ******************************************************
  // ********  create the middle surface point
  // ******************************************************
  for(i=0; i<num[3]; i++) {
    
    for(j=0; j<2; j++){
      vtid[j] = surf_midpt_vt[i*2+j];
      ed_vert[j] = verts[vtid[j]];
    }

    for(j=0; j<3; j++) 
      xyz[j] = surf_midpoints[i*3+j];

    
    pEdge edge = E_exist(ed_vert[0], ed_vert[1]);
    if(!edge) {
      printf("can not get the edge %d - %d for the middle point \n", vtid[0], vtid[1]);
      printf("Please check the input NCDF.\n");
      exit(0);
    }

    if(mid_flag) {
      pPoint pt = P_new();
      P_setPos(pt, xyz[0], xyz[1], xyz[2]);
      E_setPoint(edge, pt);
      if(E_whatInType(edge) != 3) { // set parametric coords for boundary edges
        FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
    }
    else{
      if(E_whatInType(edge) != 3) {
	// since there are so many crazy curved shape for the interior edges, reset them to linear
	pPoint pt = P_new();
	P_setPos(pt, xyz[0], xyz[1], xyz[2]);
	E_setPoint(edge, pt);
        FMDB_P_setParametricPos(pt, 0.0, 0.0, 0.0);
      }
    }
  }
  
  fiter = M_faceIter(theMesh);
  while(face = FIter_next(fiter))
    if(EN_getDataInt((pEntity)face, fbc, &attid))
      EN_deleteData((pEntity)face, fbc);	
  MD_deleteMeshDataId(fbc);
  
  delete []tet_interior;
  delete []tet_exterior;
  delete []surf_midpoints;
  delete []surf_midpt_vt;
  delete []verts;
  delete inp;


  return SCUtil_SUCCESS;
}

// **********************************************************
void exportNCDF(mPart *inputMesh, pGModel model, 
                const char *mname, const char *tagFname)
// **********************************************************
{
  cout<<endl<<"Export to NCDF format..... "<<endl;
  int i, j, k, flag;
  pFace face;
  pGEntity gent;

  pMeshDataId match_tag = MD_newMeshDataId("bctag");
  if(tagFname) {
    ifstream fin(tagFname);
    int numBC, numfcs, ftag, bctag;;
    
    fin >> numBC;

    for(i=0; i<numBC; i++) {
      fin >> bctag;
      fin >> numfcs;
      for(j=0; j<numfcs; j++) {
	fin >> ftag;
	gent = GM_entityByTag(model, 2, ftag);

	FIter fiter = M_classifiedFaceIter(inputMesh, gent, 0);
	while(face = FIter_next(fiter)){
	  EN_attachDataInt(face, match_tag, bctag);
	}
	FIter_delete(fiter);
      }
    }
    fin.close();
  }


  pMeshDataId  entid = MD_newMeshDataId("vid");
  RIter riter = M_regionIter(inputMesh);
  pRegion region;
  pPList extRList = PList_new();
  pPList intRList = PList_new();

  ofstream outfile(mname);
  if (!outfile.good ()) {
    printf ("*** Can not open the output file, %s, to output",mname);
    return;
  }

  int intR=0, extR=0, midEdge = 0, count;
  int findex[4] = {0, 3, 1, 2};
  while(region = RIter_next(riter)) {
    flag = 0;
    for(i=0; i<4; i++) {
      face = R_face(region, i);
      if(F_whatInType(face) == 2){
	extR++;
	flag = 1;
	break;
      }
    }

    if(flag)
      PList_append(extRList, region);
    else
      PList_append(intRList, region);
  }
  RIter_delete(riter);
  intR = M_numRegions(inputMesh) - extR;
  
  if(intR != PList_size(intRList))
    cout<<"something wrong"<<endl;

  // Need to check the number of middle points
  EIter eiter = M_edgeIter(inputMesh);
  pEdge edge;

  while(edge = EIter_next(eiter)) {
    if(E_numPoints(edge))
      midEdge++;
  }
  EIter_reset(eiter);

  int numVert = M_numVertices(inputMesh);

  //out the header
  
  outfile<<"netcdf "<<mname<< "{"<<endl;
  outfile<<"dimensions:"<<endl;
  outfile<<"          "<<"tetinterior = "<<intR<<" ;"<<endl;
  outfile<<"          "<<"tetinteriorsize = 5 ;"<<endl;
  outfile<<"          "<<"tetexterior  = "<<extR<<" ;"<<endl;
  outfile<<"          "<<"tetexteriorsize = 9 ;"<<endl;
  outfile<<"          "<<"ncoords = "<<numVert<<" ;"<<endl;
  outfile<<"          "<<"coord_size = 3 ;"<<endl;
  outfile<<"          "<<"surface_midpoint_size = 5 ;"<<endl;
  outfile<<"          "<<"nsurface_midpoint = "<<midEdge<<" ;"<<endl;
  outfile<<"variables:"<<endl;
  outfile<<"          "<<"int tetrahedron_interior(tetinterior, tetinteriorsize) ;"<<endl;
  outfile<<"          "<<"int tetrahedron_exterior(tetexterior, tetexteriorsize) ;"<<endl;
  outfile<<"          "<<"double coords(ncoords, coord_size) ;"<<endl;
  outfile<<"          "<<"double surface_midpoint(nsurface_midpoint, surface_midpoint_size) ;"<<endl;
  outfile<<"data:"<<endl<<endl;
  
  outfile.precision(16);

 
  //output the coordinate
  void *temp;
  temp = 0;
  count = 0;
  outfile<<"coords ="<<endl;
  pVertex vertex;
  VIter viter = M_vertexIter(inputMesh);
  double xyz[3];
  while(vertex = VIter_next(viter)){
    EN_attachDataInt((pEntity)vertex, entid, count);
    V_coord(vertex, xyz);
    count++;
    if(count != numVert)
      outfile<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<", "<<endl;
    else
      outfile<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<" ; "<<endl;
  }
   
  VIter_delete(viter);
  outfile<<endl;

  
  count = 0;
  temp = 0;
  int vvid;
  outfile<<"tetrahedron_interior ="<<endl;
  while(region = (pRegion)PList_next(intRList, &temp)) {

    outfile<<" 1, ";
    count++;
    pPList rvlist = R_vertices(region, 1);
    if(count != intR) {
      for(i=0; i<4; i++) {
	vertex = (pVertex)PList_item(rvlist, i);
	EN_getDataInt((pEntity)vertex, entid, &vvid);
	outfile<<vvid<<", ";
      }
    }
    else {
      for(i=0; i<3; i++) {
	vertex = (pVertex)PList_item(rvlist, i);
	EN_getDataInt((pEntity)vertex, entid, &vvid);
	outfile<<vvid<<", ";
      }
      vertex = (pVertex)PList_item(rvlist, 3);
      EN_getDataInt((pEntity)vertex, entid, &vvid);
      outfile<<vvid<<" ;";
    }
    
    outfile<<endl;
    
    PList_delete(rvlist);
  }
  outfile<<endl;
  
  cout<<"interior region: "<<count<<endl;

  
  if(count != intR) {
    cout<<"something wrong on the interior region"<<endl;
  }
  temp = 0;
  count = 0;

  outfile<<"tetrahedron_exterior ="<<endl;
  temp = 0;
  count = 0;
  while(region = (pRegion)PList_next(extRList, &temp)) {
    
    outfile<<" 1, ";
    count++;
    pPList rvlist = R_vertices(region, 1);
    for(i=0; i<4; i++) {
      vertex = (pVertex)PList_item(rvlist, i);
      EN_getDataInt((pEntity)vertex, entid, &vvid);
      outfile<<vvid<<", ";
    }
    PList_delete(rvlist);


    if(count != extR) {
      for(i=0; i<4; i++) {
	face = R_face(region, findex[i]);
	
	if(F_whatInType(face) == 3)
	  outfile<<"-1, ";
	else{
	  int idd;
	  gent = F_whatIn(face);
	  if(!tagFname) {
	    idd = GEN_tag(gent) ;
	  }else{
	    EN_getDataInt((pEntity)face, match_tag, &idd);
	  }
	  outfile<<idd<<", ";
	}
      }
    }
    else{
      for(i=0; i<3; i++) {
	face = R_face(region, findex[i]);
	
	if(F_whatInType(face) == 3)
	  outfile<<"-1, ";
	else{
	  int idd;
	  gent = F_whatIn(face);
	  if(!tagFname) {
	    idd = GEN_tag(gent) ;
	  }else{
	    EN_getDataInt((pEntity)face, match_tag, &idd);
	  }
	  outfile<<idd<<", ";
	}
      }
      face = R_face(region, findex[3]);
	
	if(F_whatInType(face) == 3)
	  outfile<<"-1 ; ";
	else{
	  int idd;
	  gent = F_whatIn(face);
	  if(!tagFname) {
	    idd = GEN_tag(gent);
	  }else{
	    EN_getDataInt((pEntity)face, match_tag, &idd);
	  }
	  outfile<<idd<<" ; ";
	}
    }   
    outfile<<endl;
  }  

  outfile<<endl;

  cout<<"exterior region: "<<count<<endl;
   
  if(count != extR) {
    cout<<"something wrong on the exterior region"<<endl;
  }
  
  PList_delete(intRList);
  PList_delete(extRList);
  
  //write out the surface point
  count = 0;
  outfile<<"surface_midpoint ="<<endl;
  while(edge = EIter_next(eiter)) {
    if(!E_numPoints(edge))
      continue;
    
    count++;
    for(i=0; i<2; i++){
      vertex = E_vertex(edge, i);
      EN_getDataInt((pEntity)vertex, entid, &vvid);
       outfile<<vvid<<", ";
    }
    
    pPoint pt = E_point(edge, 0);
    xyz[0] = P_x(pt);
    xyz[1] = P_y(pt);
    xyz[2] = P_z(pt);
    
    if(count!=midEdge)
      outfile<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<",";
    else
      outfile<<xyz[0]<<", "<<xyz[1]<<", "<<xyz[2]<<" ;";
    
    outfile<<endl;
    
  }
  EIter_delete(eiter);
  outfile<<"}";
  // delete the attached data
  viter = M_vertexIter(inputMesh);
  while(vertex = VIter_next(viter)) {
    EN_deleteData((pEntity)vertex, entid);
  }
  VIter_delete(viter);

  if(model) {
    GFIter gfiter = GM_faceIter(model);
    while(gent = (pGEntity)GFIter_next(gfiter)){
      FIter fiter = M_classifiedFaceIter(inputMesh, gent, 0);
      while(face = FIter_next(fiter))
	EN_deleteData(face, match_tag);
      FIter_delete(fiter);
    }
  }
  
  MD_deleteMeshDataId(entid);
  MD_deleteMeshDataId(match_tag);
  
  outfile.close();
  
  return;
}

