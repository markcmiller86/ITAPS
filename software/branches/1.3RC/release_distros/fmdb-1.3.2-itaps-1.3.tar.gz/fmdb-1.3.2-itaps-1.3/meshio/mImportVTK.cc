/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <string.h>
#include "FMDB_Internals.h"
#include "oldFMDB.h"
#include "GUM.h"
#include "mPart.h"
#include "mEntity.h"
#include "mFMDB.h"
#include "mFlexDB.h"

using std::cout;
using std::ofstream;
using std::ostream;
using std::istream;
using std::endl;
using std::vector;

// **********************************************************
int importVTK(mPart *theMesh, const char *fName)
// **********************************************************
{
  FILE *in = fopen (fName,"r");
   if(!in)
    return SCUtil_FILE_NOT_FOUND; 
  int numStrPerLine[3] = {5, 1, 2};
  char dummy_str[256];
  char entity_type[256];
  bool point_flag=false, cell_flag=false;
  double x,y,z;
  int i, j, num_cells, num_cells2, num_pnts, num_cell_data;  
  int edges_count=0, faces_count=0, regs_count=0; 
  int cell_type; 
 
#ifdef FLEXDB 
  set_MRM_oneLevel(theMesh,3);
#endif
  
  while(1)
  {
     fscanf(in,"%s",dummy_str);
     if (strcmp(dummy_str, "DATASET")==0 )
     {
       break; 
     }
  }

  fscanf(in,"%s",dummy_str);
  if (strcmp(dummy_str, "UNSTRUCTURED_GRID")==0 )
     point_flag=true; 

  vector<mEntity*> vertices;    
  int vt1, vt2, vt3, vt4, vt5, vt6, vt7, vt8, vt9, vt10;   
  mVertex* vv;        
  mEntity* edges[20];
  mEntity* pVtxs[20];
  mEntity* faces[10];
  list<int*> list_cells; 
  mEntity* tmpEdges[4]; 
  int* int_vids; 

  if(point_flag)
  {
   fscanf(in,"%s",entity_type);
   if (strcmp(entity_type, "POINTS")==0)
    {
      fscanf(in,"%d %s", &num_pnts, dummy_str);

      for (int i=0; i<num_pnts; ++i)
      {
        fscanf(in,"%lf %lf %lf", &x, &y, &z);
        vv = theMesh->createVertex(i+1,x,y,z, theMesh->getGEntity(0,3)); 
        vertices.push_back((mEntity*)vv);
      }
   }
   
   fscanf(in,"%s",entity_type);
   if (strcmp(entity_type, "CELLS")==0)
    {
      fscanf(in,"%d %d", &num_cells, &num_cell_data); 
      for (j=0; j<num_cells; ++j) {
	fscanf(in,"%d ", &num_pnts);
	
	int_vids = new int[num_pnts]; 
        for(int icount=0; icount<num_pnts; ++icount){
	  fscanf(in, "%d", &int_vids[icount]); 
	}
	list_cells.push_back(int_vids); 
      }    	
     }
  
    fscanf(in,"%s %d",entity_type, &num_cells2);
    assert(num_cells==num_cells2);
    for(j=0; j<num_cells; ++j)
    {
      if(!list_cells.empty())
      {
	 int_vids = list_cells.front(); 
	 list_cells.pop_front(); 
      }
      else 
      {
	 break; 
	 cout<<"Error in loading vtk files!"<<endl; 
      }
	 
      fscanf(in, "%d", &cell_type); 
      switch(cell_type)
      {
	case 3: 	 
	 vt1 = int_vids[0]; 
	 vt2 = int_vids[1]; 
         edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
         if (!edges[0])
           edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
                               theMesh->getGEntity(0,3));
	 edges_count++; 
	 break; 
	
	case 5: // triangle
	  vt1 = int_vids[0];
	  vt2 = int_vids[1];
	  vt3 = int_vids[2];
	  
	  edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
	  if (!edges[0]) 
	    edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
			       theMesh->getGEntity(0,3)); 
	  edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
	  if (!edges[1])
	    edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
			       theMesh->getGEntity(0,3)); 
	  edges[2]=(mEntity*)E_exist(vertices[vt1],vertices[vt3]);
	  if (!edges[2])
	    edges[2]=M_createE(theMesh,vertices[vt1],vertices[vt3],
			       theMesh->getGEntity(0,3)); 
	  M_createF(theMesh, 3, edges, 0, theMesh->getGEntity(0,3));
	  faces_count++; 
	  break;
	  
        case 9: // quad
          vt1 = int_vids[0];
	  vt2 = int_vids[1];
	  vt3 = int_vids[2];
	  vt4 = int_vids[3]; 
	  
          edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
          if (!edges[0])
            edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
                               theMesh->getGEntity(0,3));
          edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
          if (!edges[1])
            edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
                               theMesh->getGEntity(0,3));
          edges[2]=(mEntity*)E_exist(vertices[vt3],vertices[vt4]);
          if (!edges[2])
            edges[2]=M_createE(theMesh,vertices[vt3],vertices[vt4],
                               theMesh->getGEntity(0,3));
          edges[3]=(mEntity*)E_exist(vertices[vt1],vertices[vt4]);
          if (!edges[3])
            edges[3]=M_createE(theMesh,vertices[vt1],vertices[vt4],
                               theMesh->getGEntity(0,3));
          M_createF(theMesh, 4, edges, 0, theMesh->getGEntity(0,3));
          faces_count++; 
	  break;
        
	case 10: // tet 
	  vt1 = int_vids[0];
          vt2 = int_vids[1];
          vt3 = int_vids[2];
          vt4 = int_vids[3];

          edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
          if (!edges[0])
            edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
                               theMesh->getGEntity(0,3)); 
          edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
          if (!edges[1])
            edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
                               theMesh->getGEntity(0,3)); 
          edges[2]=(mEntity*)E_exist(vertices[vt3],vertices[vt1]);
          if (!edges[2])
            edges[2]=M_createE(theMesh,vertices[vt3],vertices[vt1],
                               theMesh->getGEntity(0,3));
          edges[3]=(mEntity*)E_exist(vertices[vt1],vertices[vt4]);
          if (!edges[3])
            edges[3]=M_createE(theMesh,vertices[vt1],vertices[vt4],
                               theMesh->getGEntity(0,3));
          edges[4]=(mEntity*)E_exist(vertices[vt2],vertices[vt4]);
          if (!edges[4])
            edges[4]=M_createE(theMesh,vertices[vt2],vertices[vt4],
                               theMesh->getGEntity(0,3));
          edges[5]=(mEntity*)E_exist(vertices[vt3],vertices[vt4]);
          if (!edges[5])
            edges[5]=M_createE(theMesh,vertices[vt3],vertices[vt4],
                               theMesh->getGEntity(0,3));
          faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], 0);
          if(!faces[0])
            faces[0]= M_createF(theMesh, 3, edges, 0, theMesh->getGEntity(0,3)); 
          
	  faces[1]=(mEntity*)F_exist(1, edges[0], edges[4], edges[3], 0);
          if(!faces[1])
          {
	    tmpEdges[0]=edges[0]; 
	    tmpEdges[1]=edges[4]; 
	    tmpEdges[2]=edges[3]; 
            faces[1]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
          }
	  faces[2]=(mEntity*)F_exist(1, edges[1], edges[5], edges[4], 0);
          if(!faces[2])
          { 
	    tmpEdges[0]=edges[1]; 
	    tmpEdges[1]=edges[5]; 
	    tmpEdges[2]=edges[4]; 
            faces[2]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
          }
	  
	  faces[3]=(mEntity*)F_exist(1, edges[2], edges[5], edges[3], 0);
          if(!faces[3])
          {
	    tmpEdges[0]=edges[2]; 
	    tmpEdges[1]=edges[5]; 
	    tmpEdges[2]=edges[3]; 
            faces[3]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
          }
	  // mEntity* region = 
          M_createR(theMesh, 4, faces, 0, theMesh->getGEntity(0,3)); 
	 regs_count++;  
	 break; 	  
 
	case 12: // hex
	  vt1 = int_vids[0];
	  vt2 = int_vids[1];
	  vt3 = int_vids[2]; 
	  vt4 = int_vids[3];
	  vt5 = int_vids[4];
	  vt6 = int_vids[5]; 
	  vt7 = int_vids[6];
	  vt8 = int_vids[7];
	  
	  edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
	  if (!edges[0])
	    edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
	  if (!edges[1])
	    edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[2]=(mEntity*)E_exist(vertices[vt3],vertices[vt4]);
	  if (!edges[2])
	    edges[2]=M_createE(theMesh,vertices[vt3],vertices[vt4],
			       theMesh->getGEntity(0,3));
	  
	  edges[3]=(mEntity*)E_exist(vertices[vt1],vertices[vt4]);
	  if (!edges[3])
	    edges[3]=M_createE(theMesh,vertices[vt1],vertices[vt4],
			       theMesh->getGEntity(0,3));

	  edges[4]=(mEntity*)E_exist(vertices[vt1],vertices[vt5]);
	  if (!edges[4])
	    edges[4]=M_createE(theMesh,vertices[vt1],vertices[vt5],
			       theMesh->getGEntity(0,3));

	  edges[5]=(mEntity*)E_exist(vertices[vt2],vertices[vt6]);
	  if (!edges[5])
	    edges[5]=M_createE(theMesh,vertices[vt2],vertices[vt6],
			       theMesh->getGEntity(0,3));
	  
	  edges[6]=(mEntity*)E_exist(vertices[vt3],vertices[vt7]);
	  if (!edges[6])
	    edges[6]=M_createE(theMesh,vertices[vt3],vertices[vt7],
			       theMesh->getGEntity(0,3));
	  
	  edges[7]=(mEntity*)E_exist(vertices[vt4],vertices[vt8]);
	  if (!edges[7])
	    edges[7]=M_createE(theMesh,vertices[vt4],vertices[vt8],
			       theMesh->getGEntity(0,3));
	  
	  edges[8]=(mEntity*)E_exist(vertices[vt5],vertices[vt6]);
	  if (!edges[8])
	    edges[8]=M_createE(theMesh,vertices[vt5],vertices[vt6],
			       theMesh->getGEntity(0,3));
	  
	  edges[9]=(mEntity*)E_exist(vertices[vt6],vertices[vt7]);
	  if (!edges[9])
	    edges[9]=M_createE(theMesh,vertices[vt6],vertices[vt7],
			       theMesh->getGEntity(0,3));
	  
	  edges[10]=(mEntity*)E_exist(vertices[vt7],vertices[vt8]);
	  if (!edges[10])
	    edges[10]=M_createE(theMesh,vertices[vt7],vertices[vt8],
			       theMesh->getGEntity(0,3));
	  
	  edges[11]=(mEntity*)E_exist(vertices[vt8],vertices[vt5]);
	  if (!edges[11])
	    edges[11]=M_createE(theMesh,vertices[vt8],vertices[vt5],
			       theMesh->getGEntity(0,3));
	  
	  faces[0]=(mEntity*)F_exist(1, edges[3], edges[2], edges[1], edges[0]);
	  if(!faces[0])
	  {
            tmpEdges[0]=edges[3];
            tmpEdges[1]=edges[2];
            tmpEdges[2]=edges[1];
            tmpEdges[3]=edges[0]; 
	    faces[0]= M_createF(theMesh, 4, edges, 0, theMesh->getGEntity(0,3)); 
	  }
	  
	  faces[1]=(mEntity*)F_exist(1, edges[0], edges[5], edges[8], edges[4]);
	  if(!faces[1])
	  {
	    tmpEdges[0]=edges[0]; 
	    tmpEdges[1]=edges[5]; 
	    tmpEdges[2]=edges[8];
	    tmpEdges[3]=edges[4];
	    faces[1]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[2]=(mEntity*)F_exist(1, edges[1], edges[6], edges[9], edges[5]);
	  if(!faces[2])
	  {
	    tmpEdges[0]=edges[1]; 
	    tmpEdges[1]=edges[6]; 
	    tmpEdges[2]=edges[9];
	    tmpEdges[3]=edges[5];
	    faces[2]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[3]=(mEntity*)F_exist(1, edges[2], edges[7], edges[10], edges[6]);
	  if(!faces[3])
	  {
	    tmpEdges[0]=edges[2]; 
	    tmpEdges[1]=edges[7]; 
	    tmpEdges[2]=edges[10]; 
	    tmpEdges[3]=edges[6];
	    faces[3]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[4]=(mEntity*)F_exist(1, edges[3], edges[4], edges[11], edges[7]);
	  if(!faces[4])
	  {
	    tmpEdges[0]=edges[3]; 
	    tmpEdges[1]=edges[4]; 
	    tmpEdges[2]=edges[11]; 
	    tmpEdges[3]=edges[7];
	    faces[4]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  faces[5]=(mEntity*)F_exist(1, edges[8], edges[9], edges[10], edges[11]);
	  if(!faces[5])
	  {
	    tmpEdges[0]=edges[8]; 
	    tmpEdges[1]=edges[9]; 
	    tmpEdges[2]=edges[10]; 
	    tmpEdges[3]=edges[11];
	    faces[5]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  // mEntity* region = 
	  M_createR(theMesh, 6, faces, 0, theMesh->getGEntity(0,3)); 
	  regs_count++; 
          break; 
	  
	case 13: // wedge
	  vt1 = int_vids[0];
	  vt2 = int_vids[1];
	  vt3 = int_vids[2]; 
	  vt4 = int_vids[3];
	  vt5 = int_vids[4];
	  vt6 = int_vids[5]; 
	  
	  edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
	  if (!edges[0])
	    edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
	  if (!edges[1])
	    edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[2]=(mEntity*)E_exist(vertices[vt3],vertices[vt1]);
	  if (!edges[2])
	    edges[2]=M_createE(theMesh,vertices[vt3],vertices[vt1],
			       theMesh->getGEntity(0,3));
	  
	  edges[3]=(mEntity*)E_exist(vertices[vt1],vertices[vt4]);
	  if (!edges[3])
	    edges[3]=M_createE(theMesh,vertices[vt1],vertices[vt4],
			       theMesh->getGEntity(0,3));

	  edges[4]=(mEntity*)E_exist(vertices[vt2],vertices[vt5]);
	  if (!edges[4])
	    edges[4]=M_createE(theMesh,vertices[vt2],vertices[vt5],
			       theMesh->getGEntity(0,3));

	  edges[5]=(mEntity*)E_exist(vertices[vt3],vertices[vt6]);
	  if (!edges[5])
	    edges[5]=M_createE(theMesh,vertices[vt3],vertices[vt6],
			       theMesh->getGEntity(0,3));
	  
	  edges[6]=(mEntity*)E_exist(vertices[vt4],vertices[vt5]);
	  if (!edges[6])
	    edges[6]=M_createE(theMesh,vertices[vt4],vertices[vt5],
			       theMesh->getGEntity(0,3));
	  
	  edges[7]=(mEntity*)E_exist(vertices[vt5],vertices[vt6]);
	  if (!edges[7])
	    edges[7]=M_createE(theMesh,vertices[vt5],vertices[vt6],
			       theMesh->getGEntity(0,3));
	  
	  edges[8]=(mEntity*)E_exist(vertices[vt6],vertices[vt4]);
	  if (!edges[8])
	    edges[8]=M_createE(theMesh,vertices[vt6],vertices[vt4],
			       theMesh->getGEntity(0,3));
	  
	  faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], 0);
	  if(!faces[0])
	    faces[0]= M_createF(theMesh, 3, edges, 0, theMesh->getGEntity(0,3)); 

	  
	  faces[1]=(mEntity*)F_exist(1, edges[0], edges[4], edges[6], edges[3]);
	  if(!faces[1])
	  {
	    tmpEdges[0]=edges[0]; 
	    tmpEdges[1]=edges[4]; 
	    tmpEdges[2]=edges[6];
	    tmpEdges[3]=edges[3];
	    faces[1]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[2]=(mEntity*)F_exist(1, edges[1], edges[5], edges[7], edges[4]);
	  if(!faces[2])
	  {
	    tmpEdges[0]=edges[1]; 
	    tmpEdges[1]=edges[5]; 
	    tmpEdges[2]=edges[7];
	    tmpEdges[3]=edges[4];
	    faces[2]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[3]=(mEntity*)F_exist(1, edges[2], edges[3], edges[8], edges[5]);
	  if(!faces[3])
	  {
	    tmpEdges[0]=edges[2]; 
	    tmpEdges[1]=edges[3]; 
	    tmpEdges[2]=edges[8]; 
	    tmpEdges[3]=edges[5];
	    faces[3]= M_createF(theMesh, 4, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[4]=(mEntity*)F_exist(1, edges[6], edges[7], edges[8], 0);
	  if(!faces[4])
	  {
	    tmpEdges[0]=edges[6]; 
	    tmpEdges[1]=edges[7]; 
	    tmpEdges[2]=edges[8]; 
	    faces[4]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  // mEntity* region = 
	  M_createR(theMesh, 5, faces, 0, theMesh->getGEntity(0,3)); 
	  regs_count++; 
	  break; 
	 
	case 14: // pyramid
	  vt1 = int_vids[0];
	  vt2 = int_vids[1];
	  vt3 = int_vids[2]; 
	  vt4 = int_vids[3];
	  vt5 = int_vids[4];
	  
	  edges[0]=(mEntity*)E_exist(vertices[vt1],vertices[vt2]);
	  if (!edges[0])
	    edges[0]=M_createE(theMesh,vertices[vt1],vertices[vt2],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[1]=(mEntity*)E_exist(vertices[vt2],vertices[vt3]);
	  if (!edges[1])
	    edges[1]=M_createE(theMesh,vertices[vt2],vertices[vt3],
			       theMesh->getGEntity(0,3)); 
	  
	  edges[2]=(mEntity*)E_exist(vertices[vt3],vertices[vt4]);
	  if (!edges[2])
	    edges[2]=M_createE(theMesh,vertices[vt3],vertices[vt4],
			       theMesh->getGEntity(0,3));
	  
	  edges[3]=(mEntity*)E_exist(vertices[vt1],vertices[vt4]);
	  if (!edges[3])
	    edges[3]=M_createE(theMesh,vertices[vt1],vertices[vt4],
			       theMesh->getGEntity(0,3));

	  edges[4]=(mEntity*)E_exist(vertices[vt1],vertices[vt5]);
	  if (!edges[4])
	    edges[4]=M_createE(theMesh,vertices[vt1],vertices[vt5],
			       theMesh->getGEntity(0,3));

	  edges[5]=(mEntity*)E_exist(vertices[vt2],vertices[vt5]);
	  if (!edges[5])
	    edges[5]=M_createE(theMesh,vertices[vt2],vertices[vt5],
			       theMesh->getGEntity(0,3));
	  
	  edges[6]=(mEntity*)E_exist(vertices[vt3],vertices[vt5]);
	  if (!edges[6])
	    edges[6]=M_createE(theMesh,vertices[vt3],vertices[vt5],
			       theMesh->getGEntity(0,3));
	  
	  edges[7]=(mEntity*)E_exist(vertices[vt4],vertices[vt5]);
	  if (!edges[7])
	    edges[7]=M_createE(theMesh,vertices[vt4],vertices[vt5],
			       theMesh->getGEntity(0,3));
	  
	  faces[0]=(mEntity*)F_exist(1, edges[0], edges[1], edges[2], edges[3]);
	  if(!faces[0])
	    faces[0]= M_createF(theMesh, 4, edges, 0, theMesh->getGEntity(0,3)); 

	  
	  faces[1]=(mEntity*)F_exist(1, edges[0], edges[5], edges[4], 0); 
	  if(!faces[1])
	  {
	    tmpEdges[0]=edges[0]; 
	    tmpEdges[1]=edges[5]; 
	    tmpEdges[2]=edges[4];
	    faces[1]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[2]=(mEntity*)F_exist(1, edges[1], edges[6], edges[5], 0);
	  if(!faces[2])
	  {
	    tmpEdges[0]=edges[1]; 
	    tmpEdges[1]=edges[6]; 
	    tmpEdges[2]=edges[5];
	    faces[2]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[3]=(mEntity*)F_exist(1, edges[2], edges[7], edges[6], 0);
	  if(!faces[3])
	  {
	    tmpEdges[0]=edges[2]; 
	    tmpEdges[1]=edges[7]; 
	    tmpEdges[2]=edges[6]; 
	    faces[3]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  faces[4]=(mEntity*)F_exist(1, edges[7], edges[3], edges[4], 0);
	  if(!faces[4])
	  {
	    tmpEdges[0]=edges[7]; 
	    tmpEdges[1]=edges[3]; 
	    tmpEdges[2]=edges[4]; 
	    faces[4]= M_createF(theMesh, 3, tmpEdges, 0, theMesh->getGEntity(0,3));
	  }
	  
	  // mEntity* region = 
	  M_createR(theMesh, 5, faces, 0, theMesh->getGEntity(0,3)); 
	  regs_count++; 
	  break; 

	default: 
	  cout<<"FMDB Warning: the element type is not supported now.\n";
	  return SCUtil_INVALID_ENT_TYPE;
     } // switch
   
   delete[] int_vids; 

   } // for j
 } // point_flag 
 
 fclose (in);
return SCUtil_SUCCESS;

}
