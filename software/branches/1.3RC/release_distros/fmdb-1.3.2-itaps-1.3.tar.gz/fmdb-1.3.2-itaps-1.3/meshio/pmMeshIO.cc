/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL
#include <iostream>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <map>
#include <algorithm>
#include <assert.h>
#include <vector>
#include <set>
#include <list>

#include "oldFMDB.h"
#include "FMDBInternals.h"
#include "mFMDB.h"
#include "mPart.h"
#include "mEntity.h"
#include "mVertex.h"
#include "pmEntity.h"
#include "pmModel.h"
#include "pmUtility.h"
#include "mException.h"
#include "ParUtil.h"
#include "pmMigrationCallbacks.h"
#include "pmMigrateUtil.h"
#include "modeler.h"
#include "FMDB_cint.h"
#include "mFlexDB.h"
#include "FMDB_Internals.h"

using std::copy;
using std::map;
using std::cout;
using std::endl;
using std::vector;
using std::set;
using std::list; 

/*
void FMDB_Util::load_and_partition(const char *filename, mPart *mesh,
				    pmMigrationCallbacks &lb)
//********************************************************				    
{
  import(mesh, filename);
  if (ParUtil::Instance()->size()==1) return; 
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);  
  pmLoadBalance(mesh,lb);
}
*/
//********************************************************
void FMDB_Util::loadPartitionedMesh( mPart* mesh, const char* fName, 
                                     bool fixedFName, int numGrp, int numProc)
//********************************************************
{
  char line[256];
  int i;
  int NbRegions=0,NbFaces=0,NbEdges,NbVertices,NbPoints;
  int GEntityType,GEntityId,EntityNbConnections;
  int Dummy;
  int Version=3;                // default value 
  int VertexId1,VertexId2;
  int Edge1,Edge2,Edge3,Edge4;
  int Face1, Face2, Face3, Face4;
  int nbPts,NbEdgesOnFace,NbFacesOnRegion;
  double x,y,z;
  double u,v;
  int patch;
  int pclassid, ucbid, cbpid;
  pmEntity* pe;
  mEntity* ent;

  char inmesh[256]; 
  char without_extension[256];
  int mypid=ParUtil::Instance()->rank();
  int localNumPtn=0;
       
  if (!fixedFName)
  {  
    snprintf(without_extension,strlen(fName)-3,"%s",fName);
    sprintf(inmesh,"%s%d.sms",without_extension,mypid); 
  }
  else 
    sprintf(inmesh,fName); 
  
  map<int,mEntity*> CBEntities;                            // entity and its local unique id 
  list<rc_struct_4> entitiesToBounce; 

  FILE *in = fopen (inmesh,"r");
  if(!in)
  {
    cout<<"FMDB WARNING: unable to open file \""<<inmesh<<"\"\n";
    //   return;  
  }
  else {  

// *********************************
// STEP 1: setup format
// *********************************
  fscanf(in,"%s %d",line,&Version);
  typedef GEntity* (*entityBy_FP)(SGModel*,int,int);
  entityBy_FP fp = GM_entityByTag; 

// *********************************
// STEP 2: check number of partitions
// *********************************
  int pid, total, numPEs, totalCBEntities;                         // local totalCBEntities 
  fscanf(in,"%d %d %d %d",&total, &pid, &numPEs, &totalCBEntities);
  assert(total<=ParUtil::Instance()->size());

// *********************************
// STEP 3: setup partition model
// *********************************
  int peid, pedim, peowner, penumBPs;
  pmModel* pmodel=pmModel::Instance();
  int myGrp = mypid / numProc; 
  pmEntity* newPE;
  
  for (i=0; i<numPEs;++i)
  {
    fscanf(in,"%d %d %d %d",&peid, &pedim, &peowner, &penumBPs);
    set<int> bps;
    
    int bp;
    for (int j=0; j<penumBPs;++j)
    {  
      fscanf(in,"%d",&bp);
      if (fixedFName)  // PPPL case
        bps.insert(myGrp*numProc + bp);
      else
        bps.insert(bp);
    }
    
    if (fixedFName)  // PPPL case
      newPE = new pmEntity(numPEs*myGrp+peid, bps, pedim);
    else
      newPE = new pmEntity(peid, bps, pedim);
      
    pmodel->addPEntity(newPE);
  
    if (fixedFName) // PPPL case
      newPE->setOwner(myGrp*numProc + peowner);
    else
      newPE->setOwner(peowner);
  }

// *********************************
// STEP 4: setup CB entity container
// *********************************
 
  fscanf(in,"%d %d %d %d %d",&NbRegions,&NbFaces,&NbEdges,
                               &NbVertices,&NbPoints);

// *********************************
// STEP 5: read vertices
// *********************************
  std::vector<mVertex*> vertices;
  mVertex* vv;        
  int vid;
  for(i=0;i<NbVertices;i++)
  {
    fscanf(in,"%d",&vid);       
    fscanf(in,"%d",&GEntityId);       
    if (GEntityId)
    {
      fscanf(in,"%d %d %lf %lf %lf",&GEntityType,&EntityNbConnections,
	                                  &x,&y,&z); 
      vv = mesh->createVertex(vid,x,y,z,
	                 mesh->getGEntity(GEntityId,GEntityType,fp)); 
      vertices.push_back(vv);
	    
      switch(GEntityType)
      {
        case 0:
            break;
        case 1:
            fscanf(in,"%le",&u);
            vv->attachVector(getParametric(),SCOREC::Util::mVector (u,0,0) );
            break;
  	case 2:
	    fscanf(in,"%le %le %d",&u,&v,&patch);		
	    vv->attachVector(getParametric(),SCOREC::Util::mVector (u,v,patch) );
   	    break;
	case 3:
	    break;
 	default :
  	    if (!in)
	      throw new mException (__LINE__,__FILE__,"unknown tag in sms loadSmsFile");	      
      }
      if(Version==4) {
	 fscanf(in,"%d %d %d", &pclassid, &ucbid, &cbpid);
	 if (pclassid!=-1)
	 {
	   if (fixedFName)
	     pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
	   else
       	     pe = pmodel->getPartitionEntity(pclassid);
           assert(pe!=0);
	   vv->setPClassification(pe);

	   if(cbpid==mypid)                                // the owner 
	     CBEntities[ucbid]=(mEntity*)vv;
	   else
	     entitiesToBounce.push_back(rc_struct_4((mEntity*)vv, ucbid, cbpid));
	 }
      }
      
      if(Version==3) {
         fscanf(in,"%d %d", &pclassid, &ucbid);
         if (pclassid!=-1)
         {
           if (fixedFName)
             pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
           else
             pe = pmodel->getPartitionEntity(pclassid);

           assert(pe!=0);
           vv->setPClassification(pe);
           CBEntities[ucbid]=(mEntity*)vv;
         }
      }

    }
  } // end of reading vertices
  
 
// *********************************
// STEP 6: read edges
// *********************************
  std::vector<mEntity*> edges;
  mVertex* v1;
  mVertex* v2;
  mEntity* e;
    
  for(i=0;i<NbEdges;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if (GEntityId)
    {
      fscanf(in,"%d %d %d %d %d",&GEntityType, &VertexId1,&VertexId2,
	           &EntityNbConnections,&nbPts); 
      v1 = vertices[VertexId1-1];
      v2 = vertices[VertexId2-1];
      e = M_createE(mesh, v1, v2, mesh->getGEntity(GEntityId,GEntityType,fp));
      edges.push_back(e);

      for(int j=0;j<nbPts;j++)
      {
        fscanf(in,"%lf %lf %lf ", &x, &y, &z);
        pPoint pt = P_new();
        P_setPos(pt, x, y, z);
        switch(GEntityType)
        {
        case 1: {fscanf(in,"%le",&u);FMDB_P_setParametricPos(pt, u, 0, 0);}
                 break;
        case 2: {fscanf(in,"%le %le %d",&u,&v,&patch); FMDB_P_setParametricPos(pt, u, v, 0);}
                 break;
          default: break;
        }
        E_setPoint(e, pt);
      }

/////////////////////////////////////////////////

if(Version==4) {
      fscanf(in,"%d %d %d", &pclassid, &ucbid, &cbpid);
      if (pclassid!=-1)
      {
        if (fixedFName)
             pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
        else
             pe = pmodel->getPartitionEntity(pclassid);
	assert(pe!=0);
	e->setPClassification(pe);
	
	if(cbpid==mypid)                                // the owner 
	  CBEntities[ucbid]=e;
	else
	  entitiesToBounce.push_back(rc_struct_4(e, ucbid, cbpid));
      }
}
if(Version==3) {
      fscanf(in,"%d %d", &pclassid, &ucbid);
      if (pclassid!=-1)
      {
        if (fixedFName)
             pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
        else
             pe = pmodel->getPartitionEntity(pclassid);
        assert(pe!=0);
        e->setPClassification(pe);
        CBEntities[ucbid]=e;
      }
}


    }
  }  // end of reading edges

// *********************************
// STEP 7: read faces
// *********************************

  std::vector<mEntity*> faces;
  mEntity* f;
  mEntity* eg[4];
  
  for(i=0;i<NbFaces;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if(GEntityId)
    {
      fscanf(in,"%d %d",&GEntityType, &NbEdgesOnFace);
   
      for(int j=0; j<NbEdgesOnFace; j++)
      {
        fscanf(in, "%d", &Edge1);
        eg[j]=edges[abs(Edge1)-1]; 
      }

      fscanf(in, "%d", &nbPts);

      f = M_createF(mesh, NbEdgesOnFace, eg, 0, mesh->getGEntity(GEntityId,GEntityType,fp)); 
      faces.push_back(f);

      for(int j=0;j<nbPts;j++)
      {
	switch(GEntityType)
	{
	  case 0: break;
	  case 1: fscanf(in,"%le",&u);
		 break;
	  case 2: fscanf(in,"%le %le %d",&u,&v,&patch);
		 break;
	  case 3: break;
	  default: throw new mException (__LINE__,__FILE__,
					  "unknown tag in sms loadSmsFile");	      
	}
      } // for(int j=0;j<nbPts;j++)
      if(Version==4) {      
        fscanf(in,"%d %d %d", &pclassid, &ucbid, &cbpid);
        if (pclassid!=-1)
        {
          if (fixedFName)
            pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
          else
            pe = pmodel->getPartitionEntity(pclassid);
	  assert(pe!=0);
  	  f->setPClassification(pe);

	
  	  if(cbpid==mypid)                                // the owner 
	    CBEntities[ucbid]=f;
   	  else
	    entitiesToBounce.push_back(rc_struct_4(f, ucbid, cbpid));
        }
      } // if(Version==4) 

      if(Version==3) 
      {
        fscanf(in,"%d %d", &pclassid, &ucbid);
        if (pclassid!=-1)
        {
          if (fixedFName)
            pe = pmodel->getPartitionEntity(myGrp*numPEs + pclassid);
          else
            pe = pmodel->getPartitionEntity(pclassid);
          assert(pe!=0);
          f->setPClassification(pe);
          CBEntities[ucbid]=f;
        }
      } // if(Version==3) 
    } // if(GEntityId)
  } // end of reading faces
  
// *********************************
// STEP 8: read regions
// *********************************

  mEntity* fc[6];
  for(i=0;i<NbRegions;i++)
  {
    fscanf(in,"%d",&GEntityId);
    if(GEntityId)
    {
      fscanf(in,"%d",&NbFacesOnRegion);
     
      for(int j=0; j<NbFacesOnRegion; j++)
      {
        fscanf(in,"%d", &Face1);
        fc[j]=faces[abs(Face1)-1];
      }
      fscanf(in,"%d", &Dummy);
      
      M_createR(mesh,NbFacesOnRegion,fc,0,mesh->getGEntity(GEntityId,3,fp));
    }
  } // end of reading regions
  
  fclose (in);

  localNumPtn=total;     
 }

  /// Set neighboring parts based on the partition model information
  pmModel::Instance()->clean_up();
  pmModel::Instance()->setNbrPTs();
  set<int> nbrs;
  pmModel::Instance()->getNbrPids(nbrs);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_Nbrs(nbrs);
  CM->set_comm_validation(IPComMan::Neighbors);
  int msg_size = sizeof(mEntity*)+sizeof(int); 
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);
  int* s_id; 
  mEntity** s_ent; 

// *********************************
// STEP 9: setup common boundary
// *********************************

  CM->set_tag(0);
  int num_sent = 0, num_recvd = 0;

  if(Version==4) {
    list<rc_struct_2> entitiesToBroadcast;

    for(list<rc_struct_4>::iterator lit=entitiesToBounce.begin(); lit!=entitiesToBounce.end(); lit++) 
    {  
      s_ent = (mEntity**)msg_send; 
      *s_ent = (*lit).ent; 
      s_id =  (int*)((char*)msg_send + sizeof(mEntity*)); 
      *s_id = (*lit).lid;            // local pid 
      CM->send((*lit).rank, (void*)msg_send);
      num_sent++; 
    }
    CM->finalize_send();
    CM->free_msg(msg_send);

    void* msg_recv; 
    int pid_from; 
    
    // recieve phase
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;
      mEntity* ent = *(mEntity**)msg_recv;
      s_id = (int*)((char*)msg_recv + sizeof(mEntity*));

      CBEntities[*s_id]->addRemoteCopy(pid_from, ent);
      entitiesToBroadcast.push_back(rc_struct_2(CBEntities[*s_id], pid_from, ent));
      CM->free_msg(msg_recv);
    }
  
    for(map<int, mEntity*>::iterator mapit=CBEntities.begin(); mapit!=CBEntities.end(); mapit++) 
      entitiesToBroadcast.push_back(rc_struct_2(mapit->second, mypid, mapit->second)); 

    exchangeEntitiesToBroadcast(entitiesToBroadcast);
  } // if(Version==4)

  if(Version==3) 
  {
    for(map<int, mEntity*>::iterator CBEntitiesIter=CBEntities.begin();
        CBEntitiesIter!=CBEntities.end();CBEntitiesIter++)
    {
      int idx =  CBEntitiesIter->first;
      ent = CBEntitiesIter->second;
      if (!ent) continue;
      pe = ent->getPClassification();
      for (pmEntity::BPIter bpiter=pe->bpBegin(); bpiter!=pe->bpEnd();++bpiter)
      {
	if (*bpiter==mypid) continue;
        s_ent = (mEntity**)msg_send;
        *s_ent = ent;
        s_id = (int*)((char*)msg_send + sizeof(mEntity*));
        *s_id = idx;
        CM->send(*bpiter, (void*)msg_send);
	num_sent++; 
      }     
    }
    CM->finalize_send();
    CM->free_msg(msg_send);

    // receive phase begins
    void *msg_recv;
    int pid_from;

    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;
      s_ent = (mEntity**)msg_recv;
      s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
      CBEntities[*s_id]->addRemoteCopy(pid_from, *s_ent);
      CM->free_msg(msg_recv);
    }
  } // if(Version==3)
  
  int mDim = M_globalMaxDim(mesh);
  ParUtil::Instance()->set_maxMeshDim(mDim);
  
  return; 
}

class ucbidExchanger:public pmDataExchanger
{
public :
  virtual int msg_size();
  virtual void fill_buffer (mEntity *e, int, int, mEntity* remoteEnt, void *&msg_send);
  virtual void receiveData (void *msg_recv, int pid_from);
};

int ucbidExchanger::msg_size()
{
  return sizeof(mEntity*) + 2*sizeof(int);
}

void ucbidExchanger:: fill_buffer(mEntity *ent, int src, int dest, mEntity* remoteEnt, void *&msg_send)
{
  mEntity** s_ent = (mEntity**)msg_send;
  *s_ent = remoteEnt;
  int *s_id = (int*)((char*)msg_send + sizeof(mEntity*));
  void* pv;
  if(!EN_getDataPtr(ent, MD_lookupMeshDataId("uidOnCB"), &pv))
      return; 
  s_id[0] = ((int*)pv)[0]; 
  s_id[1] = ((int*)pv)[1];
}

void ucbidExchanger:: receiveData (void *msg_recv, int pid_from)
{
  mEntity** s_ent = (mEntity**)msg_recv;
  int *s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
  int *idata = new int[2]; 
  idata[0]=s_id[0]; 
  idata[1]=s_id[1]; 
  EN_attachDataPtr(*s_ent, MD_lookupMeshDataId("uidOnCB"), idata);
}


//********************************************************
void exchangeNblPids(vector<mPart*> meshes,    // construct pidMaps from local and neighborhood 
		     map<int, int>& pidMaps)   // original global_pid, new sequential global_pid 
//********************************************************  
{
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  int mypid = ParUtil::Instance()->rank(); 
  
  // get the sum of local number of parts from previous processes
  int usrNumPart = ParUtil::Instance()->getUsrNumParts();            // local number of parts   
  int preSum = 0; 
  MPI_Scan(&usrNumPart, &preSum, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);  
  preSum = preSum-usrNumPart; 

//*****************************************
// STEP 1: get pid maps from local parts 
//*****************************************
  if((ParUtil::Instance()->localPids).size()==0) 
  {  
    for(int ipart=0; ipart<meshes.size(); ++ipart)
      pidMaps[mypid*numPart+ipart]=preSum+ipart; 
  }
  else 
  { 
    int partSize = (ParUtil::Instance()->localPids).size(); 

    for(int ipart=0; ipart<partSize; ipart++) 
    {
      int lid = (ParUtil::Instance()->localPids)[ipart];
      pidMaps[mypid*numPart+lid]=preSum+ipart;                // new sequential global_pid
    }
  }

//*****************************************
// STEP 3: exchange pidMaps in neighborhood 
//*****************************************

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  CM->set_fixed_msg_size(0);   

  int num_sent = 0, num_recvd = 0;
  int size = pidMaps.size(); 
  int msg_size = 2*size*sizeof(int); 
  void* msg_send; 
  msg_send = CM->alloc_msg(msg_size); 

  map<int, int>::iterator mapIt; 
  int* local_gids = (int*)msg_send;
  int i=0; 
  for (mapIt=pidMaps.begin(); mapIt!=pidMaps.end(); mapIt++) {
    local_gids[i++]=mapIt->first; 
    local_gids[i++]=mapIt->second; 
  }

  num_sent = CM->send_to_nbrs((void*)msg_send, msg_size);
  
  CM->finalize_send();
  CM->free_msg(msg_send); 

  void *msg_recv;
  int pid_from;

  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    int map_size = rc/(sizeof(int));

    int* gids = (int*)msg_recv; 
    for (int i=0; i<map_size; i=i+2)
      pidMaps[gids[i]]=gids[i+1];

    CM->free_msg(msg_recv);
  }
}


// this function assumes one-level representation
//********************************************************
void FMDB_Util::writePartitionedMesh(vector<mPart*> meshes, const char* fName)
//********************************************************
{
  char outmesh[256];
  char without_extension[256];
  int mypid = ParUtil::Instance()->rank();
  int numP = ParUtil::Instance()->size();
  
  snprintf(without_extension,strlen(fName)-3,"%s",fName);
  unsigned int tagId= MD_lookupMeshDataId("uidOnCB");
  
  int numCBEntOwned=0; //any region is not on CB
  
  mPart::iterall it;
  mEntity* ent;
  int numPart = ParUtil::Instance()->getCurNumParts(); 

// STEP 0: global_pid map for local and neighborhood
  map<int, int> pidMaps; 
  exchangeNblPids(meshes, pidMaps); 
  
// STEP 1: Count # cb entities owned by the processor 
//         and compute initialId to start

  mPart* mesh; 
  map<mEntity*, int> entOnCB;                       // entity and local_pid 
  list<mEntity*> entOnCB_list; 

  for(int ipart=0; ipart<(int)(meshes.size()); ipart++) {
    mesh = meshes[ipart]; 
     for (int dim=0; dim < mesh->getDimension(); dim++)
     {
       for (it=mesh->beginall(dim);it!=mesh->endall(dim);++it)
       {
	 ent = *it;
         if (ent->getPClassification() )
	 {
	    entOnCB_list.push_back(ent);                  
	    int mygid = mypid*numPart+ipart; 
	    if((ParUtil::Instance()->localPids).size()>0) 
	      mygid = mypid*numPart+(ParUtil::Instance()->localPids)[ipart]; 
      	    if (ent->getOwner()==mygid )            
	    {
	      entOnCB[ent]= pidMaps[mygid]; 
	      numCBEntOwned++; 
	    }
	 } 
       }  // end of it 
     }  // end of dim 
  } // end of ipart 
  
   int totalCBEnt = P_getSumInt(numCBEntOwned);
   int* input= new int[numP]; 
   int* output = new int[numP];
   for(int i=0; i<numP; i++) {
     output[i]=numCBEntOwned;
     input[i]=numCBEntOwned;
   }
   MPI_Alltoall(input, 1, MPI_INT, output, 1, MPI_INT, ParUtil::Instance()->getComm());
   int initialId = 0;
   for (int i=0; i<mypid;++i)
     initialId+=output[i];
 
   delete[] input; 
   delete[] output; 

// STEP 2: attach uid to all local CB entities
   int* uids; 
  for (map<mEntity*,int>::iterator vit=entOnCB.begin();vit!=entOnCB.end();++vit)
  {
    uids = new int[2]; 
    uids[0]=initialId; 
    uids[1]=vit->second;                       
    EN_attachDataPtr(vit->first, tagId, uids); 

    initialId++;
  }
  
  ucbidExchanger deCallback;
  deCallback.numPart = numPart;  
  genericDataExchanger2(entOnCB.begin(), entOnCB.end(), deCallback);
  entOnCB.clear(); 

  for(unsigned int ipart=0; ipart<meshes.size(); ++ipart) {
     mesh = meshes[ipart];
   
     int mygid = mypid*numPart+ipart; 
     if((ParUtil::Instance()->localPids).size()>0) 
       mygid = mypid*numPart+(ParUtil::Instance()->localPids)[ipart]; 
     sprintf(outmesh,"%s%d.sms",without_extension,pidMaps[mygid]);          // new sequential global_pid 
     std::ofstream ofs(outmesh); 
     
// STEP 3: write header - 3 means partitioned mesh     
     ofs<<"sms 4\n";  

// STEP 4: write partition model info    
     ofs<<ParUtil::Instance()->size()<<" "<<pidMaps[mygid]<<" "
	<<pmModel::Instance()->getNumPEs()<<" "<<totalCBEnt<<endl;
     pmModel::PEIter peiter=pmModel::Instance()->peBegin();
     pmEntity* pe;
     for(;peiter!=pmModel::Instance()->peEnd();++peiter)
     {
       pe=(*peiter);
       ofs<<pe->getId()<<" "<<pe->getLevel()<<" "<<pidMaps[pe->getOwner()]<<" "
	  <<pe->getNumBPs()<<" ";
       for (pmEntity::BPIter bpiter=pe->bpBegin();bpiter!=pe->bpEnd();++bpiter)
	 ofs<<pidMaps[*bpiter]<<" ";
       ofs<<endl;
     }

     std::map<pVertex,int> numberid;	
     VIter vIter;
     EIter eIter;
     FIter fIter;
     RIter rIter;
     double loc[3];
     pVertex vertex;
     pRegion region;
     pEdge edge;
     pFace face;

     int gtype;
     int gtag;
     pGEntity gEntity;

     int NbRegions, NbFaces, NbEdges, NbVertices,NbPoints;
     NbRegions=mesh->size(3);
     NbFaces=mesh->size(2);
     NbEdges=mesh->size(1);
     NbVertices=mesh->size(0);
     NbPoints=NbVertices;

     ofs<< NbRegions << " " << NbFaces << " "<< NbEdges <<" " <<NbVertices << " " << NbPoints <<endl;

// STEP 5: write mesh vertices
     if (NbVertices>0)
     {
       vIter = M_vertexIter(mesh);
       int i=1;
	    
       while((vertex=VIter_next(vIter)))
       {  
	 numberid.insert(std::make_pair(vertex,i++));
	 V_coord(vertex,loc);
	 gEntity = vertex->getClassification(); 
	 if(gEntity!=0) {
	   gtype=GEN_type(gEntity); 
	   gtag = GEN_tag(gEntity); 
	 }
	 else{
	   gtype=3; 
	   gtag=1; 
	 } 
      // write coordinates and gclassification
	 ofs << numberid[vertex]<<" "
          << gtag << " " << gtype << " "
	  << V_numEdges(vertex) << endl << loc[0] << " " << loc[1] 
	  << " " << loc[2]<<" "; 
      // write parametric
	 if (vertex->getData(FMDB_Util::Instance()->getParametric()))
	 {
	   SCOREC::Util::mVector vec = vertex->getAttachedVector(getParametric());
	   switch (gtype)
	   {
	     case 1 :  // model edge
	     {  ofs << vec(0); break; }
	     case 2 : // model face
	     {  ofs << vec(0)<<" "<<vec(1)<<" 0"; break;  }
	     default: break;
	   }
	 }
	 else
	 {
	   switch (gtype)
	   {
          case 1 :  // model edge
	  {  ofs <<"0"; break; }
          case 2 : // model face
	  {  ofs <<"0 0 0"; break;  }
	  default: break;
	}
      }
      ofs << endl;
      // write pclassification
      if (vertex->getPClassification()) {
        ofs<<vertex->getPClassification()->getId()<<" "; 
	void* tmp_ptr;
	if(!EN_getDataPtr(vertex, tagId, &tmp_ptr)) {
	  return; 
        }
        ofs<<((int*)tmp_ptr)[0]<<" "<<((int*)tmp_ptr)[1]<<endl; 
      }
      else
	ofs<<"-1 -1 -1"<<endl;
    } // while vertex
    VIter_delete(vIter);
  }  // end of vertex

// STEP 6: write mesh edges

  if (NbEdges>0)
  {	
    eIter = M_edgeIter(mesh);
    int i=1;
    while((edge = EIter_next(eIter)))
    {
      gEntity = edge->getClassification(); 
      if(gEntity!=0) {
	gtype= GEN_type(gEntity); 
	gtag = GEN_tag(gEntity); 
      }
      else{
	gtype=3;
	gtag=1; 
      }
      ofs << gtag << " " << gtype << " " ;
      EN_setID(edge,i++);
      for (int j=0; j<2 ;j++)
      {
	vertex = E_vertex(edge,j);
        ofs << numberid[vertex] << " ";  
      } 		
      int npts = E_numPoints(edge); 
      ofs << E_numFaces(edge) << " " << npts <<" "<<endl;

      if(npts) {
        pPoint pt = E_point(edge, 0);
        ofs<<setprecision(15)<<P_x(pt)<<" "<<P_y(pt)<<" "<<P_z(pt);
        switch (E_whatInType(edge))
        {
          case 1: ofs << " 0";
                 break;
          case 2: ofs << " 0" << " 0" << " 0";
                 break;
          default: break;
        }
        ofs<<endl;
      }

      if (edge->getPClassification())
      {
        ofs<<edge->getPClassification()->getId()<<" "; 
        void* tmp_ptr;
        if(!EN_getDataPtr(edge, tagId, &tmp_ptr))
 	  return; 
        ofs<<((int*)tmp_ptr)[0]<<" "<<((int*)tmp_ptr)[1]<<endl;
      }
      else
	ofs<<"-1 -1 -1"<<endl;
    }

    EIter_delete(eIter);
  }  // end of edges
  			
  if (NbFaces>0)
  {	  
    int i=1;
    fIter = M_faceIter(mesh);
    while((face = FIter_next(fIter)))
    {
      gEntity = face->getClassification(); 
      if(gEntity!=0) {
	gtype= GEN_type(gEntity);
	gtag = GEN_tag(gEntity); 
      }
      else{
	gtype=3;
	gtag=1; 
      }
      ofs << gtag << " " << gtype << " ";
      EN_setID(face,i++);
      int numEdges=F_numEdges(face);
      ofs << numEdges << " ";
      for (int j=0; j<numEdges ;j++)
      {
	edge = F_edge(face,j);
	int ID=EN_id(edge);
	if (!F_edgeDir(face,j)) ID=-ID;
	ofs << ID << " ";
      } 		
      ofs <<"0"<<endl; 
      if (face->getPClassification())
      {
        ofs<<face->getPClassification()->getId()<<" "; 
        void* tmp_ptr;
        if(!EN_getDataPtr(face, tagId, &tmp_ptr)) {
	  return; 
        }
        ofs<<((int*)tmp_ptr)[0]<<" "<<((int*)tmp_ptr)[1]<<endl;
      }
      else
	ofs<<"-1 -1 -1"<<endl;
    }  // while face
    FIter_delete(fIter);
  }  // end of faces
  	
  if (NbRegions>0)
  {
    rIter = M_regionIter(mesh);
    while((region = RIter_next(rIter)))
    { 
      gEntity =(pGEntity)R_whatIn(region);
      if(gEntity!=0) 
	gtag = GEN_tag(gEntity);
      else
	gtag = 1; 
      int numFaces=R_numFaces(region);
      ofs << gtag << " " << numFaces << " ";		
      for (int j=0; j<numFaces ;j++)
      {		  
	face = R_face(region,j);
	int ID=EN_id(face);
	if (!R_faceDir(region,j)) ID=-ID;
	ofs << ID << " ";
      } 		
      ofs << "0"<<endl;
    }
    RIter_delete(rIter);
  } // end of regions 
  
  ofs.close();
 } // end of ipart 

  // STEP 7: deallocate the attached data for entOnCB 
  for(list<mEntity*>::iterator lit = entOnCB_list.begin(); lit!=entOnCB_list.end(); lit++) {
    void* tmp_ptr;
    if(!EN_getDataPtr(*lit, tagId, &tmp_ptr))
      return; 
   
    EN_deleteData(*lit, tagId); 
    delete[] ((int*)tmp_ptr); 
  }  
  MD_deleteMeshDataId(tagId); 
}


#endif
