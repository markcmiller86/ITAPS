/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"

int FMDB_Ent_HasTag (pMeshEnt ent, pTag tag, int* hasTag)
{
  if (ent->hasData(tag)) 
    *hasTag=1;
  else
    *hasTag=0;
  return 0;
}

int FMDB_Ent_DelTag (pMeshEnt ent, pTag tag)
{
  ent->deleteData(tag);
  return 0;
}

int FMDB_Ent_SetByteTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, const void* data, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }

  if(!data || !data_size)
  {
    cout<<__func__<<" failed: NULL tag_data\n";
    return 1;
  } 

  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);
  switch (tag_type)
  {
    case 0: {
              char* cData = (char*)data;
              ent->attachOpaque(tag,cData, data_size); 
            }
            break;
    case 1: {
              int* iData = (int*)data;
              if (tag_size==1)  // single int
                ent->attachInt(tag, *iData);
              else  // int array
              {
                 int* int_arr=new int[data_size/sizeof(int)];
                 for (int i=0; i<data_size/sizeof(int); ++i)
                   int_arr[i] = iData[i];
                 ent->attachIntArr(tag, int_arr, data_size/sizeof(int));
                 delete [] int_arr;
              }
            }
            break;
    case 2: { // double
              double* dData = (double*)data;
              if (tag_size==1)
                ent->attachDouble(tag, *dData);
              else  // double array
              {
                 double* dbl_arr=new double[data_size/sizeof(double)];
                 for (int i=0; i<data_size/sizeof(double); ++i)
                   dbl_arr[i] = dData[i];
                 ent->attachDblArr(tag, dbl_arr, data_size/sizeof(double));
                 delete [] dbl_arr;
              }
            }
            break;
    case 3: { // entity
              pMeshEnt* entData = (pMeshEnt*)data;	
              if (tag_size==1)
              {
                ent->attachPnt(tag, *entData);
               pMeshEnt entAttached = (pMeshEnt)ent->getAttachedPnt(tag);
              }
              else  // entity array
              {
                 pMeshEnt* ent_arr=new pMeshEnt[data_size/sizeof(void*)];
                 for (int i=0; i<data_size/sizeof(void*); ++i)
                   ent_arr[i] = entData[i];
                 ent->attachPntArr(tag, (void**)ent_arr, data_size/sizeof(void*));
                 delete [] ent_arr;
              }
            }
            break;
    case 4: { // entity set
              pEntSet* setData = (pEntSet*)data;
              if (tag_size==1)
                ent->attachPnt(tag, *setData);
              else  // entity set array
              {
                 pEntSet* set_arr=new pEntSet[data_size/sizeof(void*)];
                 for (int i=0; i<data_size/sizeof(void*); ++i)
                   set_arr[i] = setData[i];
                 ent->attachPntArr(tag, (void**)set_arr, data_size/sizeof(void*));
                 delete [] set_arr;
              }
            }
            break;
    default: break;
  }
  return 0;
}

int FMDB_Ent_GetByteTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, void** data, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);

  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }

  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  switch (tag_type)
  {
    case 0: { // byte
              int sz_tag_data = ent->getSizeAttachedOpaque(tag);
              char* char_data = (char*)(calloc(sz_tag_data, sizeof(char)));
              ent->getAttachedOpaque(tag, char_data);
              memcpy(*data, char_data, sizeof(char_data));
              *data_size = tag_size * sizeof(char);
              delete[] char_data;
            }
            break;
    case 1: { // int
              if (tag_size==1)  // int
              {
                int int_data = ent->getAttachedInt(tag);
                memcpy(*data, &int_data, sizeof(int));
                *data_size = sizeof(int);
              }
              else // int array
              {
                int* int_arr = new int[tag_size];
                int int_size;
                ent->getAttachedIntArr(tag, &int_arr, &int_size);
                memcpy(*data, int_arr, sizeof(int)*int_size);
                *data_size = sizeof(int)*int_size;
                delete [] int_arr;
              }
            }
            break;           
    case 2: { // double
              if (tag_size==1)
              {
                double double_data = ent->getAttachedDouble(tag);
                memcpy(*data, &double_data, sizeof(double_data));
                *data_size = sizeof(double);
              }
              else // double array
              {
                double* dbl_arr = new double[tag_size];
                int dbl_size;
                ent->getAttachedDblArr(tag, &dbl_arr, &dbl_size);
                memcpy(*data, dbl_arr, sizeof(double)*dbl_size);
                *data_size = sizeof(double)*dbl_size;
                delete [] dbl_arr;
              }
            }
            break;
    case 3: { // entity
              if (tag_size==1)
              {
                pMeshEnt ent_data = (pMeshEnt)(ent->getAttachedPnt(tag));
                if(!ent_data) return 1;
		memcpy(*data, &ent_data, sizeof(void*));
                *data_size = sizeof(pMeshEnt);
              }
              else // entity array
              {
                pMeshEnt* ent_arr = new pMeshEnt[tag_size];
                int ent_size;
                ent->getAttachedPntArr(tag, (void***)(&ent_arr), &ent_size);
                memcpy(*data, ent_arr, sizeof(void*)*ent_size);
                *data_size = sizeof(void*)*ent_size;
                delete [] ent_arr;
              }
	    }
            break;
    case 4: { // entity set
              if (tag_size==1)
              {
                pEntSet set_data = (pEntSet)(ent->getAttachedPnt(tag));
                if(!set_data) return 1;
                memcpy(*data, &set_data, sizeof(void*));
                *data_size = sizeof(void*);
              }
              else // entity set array
              {
                pEntSet* set_arr = new pEntSet[tag_size];
                int set_size;
                ent->getAttachedPntArr(tag, (void***)(&set_arr), &set_size);
                memcpy(*data, set_arr, sizeof(void*)*set_size);
                *data_size = sizeof(void*)*set_size;
                delete [] set_arr;
              }
	    }
            break;
    default: break;
  }
  return 0;
}

int FMDB_Ent_SetIntTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, int data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=1 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }

  ent->attachInt (tag, data);
  return 0;
}

int FMDB_Ent_GetIntTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, int* data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=1 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }
  if (ent->getAttachedInt(tag, data)==0)
    return 1;
  return 0;
}

int FMDB_Ent_SetDblTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, double data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=2 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  
  ent->attachDouble (tag, data);
  return 0;
}

int FMDB_Ent_GetDblTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, double* data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=2 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  
  if (ent->getAttachedDouble(tag, data)==0)
    return 1;
  return 0;
}

int FMDB_Ent_SetEntTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pMeshEnt data)
{ 
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=3 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  

  ent->attachPnt (tag, (void*)data);
  return 0;
} 
  
int FMDB_Ent_GetEntTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pMeshEnt *data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=3 || tag_size!=1)
  {
   cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  

  *data =(pMeshEnt) (ent->getAttachedPnt(tag));
  if (*data) return 0;
  return 1;
}
  
int FMDB_Ent_SetSetTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pEntSet data)
{ 
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=4 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  

  ent->attachPnt (tag, (void*)data);
  return 0;
}

int FMDB_Ent_GetSetTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pEntSet *data)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=4 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  
  *data = (pEntSet)(ent->getAttachedPnt(tag));
  if (*data) return 0;
  return 1;
}

// array tag
int FMDB_Ent_SetIntArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, int* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=1 || tag_size!=data_size)
  {
    cout<<__func__<<" ailed: tag type/size mismatch\n";
    return 1;
  }  

  ent->attachIntArr (tag, data_arr, data_size);
  return 0;

}

int FMDB_Ent_GetIntArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, int** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=1)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return 1;
  }  

  ent->getAttachedIntArr (tag, data_arr, data_size);
  return 0;
}

int FMDB_Ent_SetDblArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, double* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=2 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  
  ent->attachDblArr (tag, data_arr, data_size);
  return 0;
}

int FMDB_Ent_GetDblArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, double** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=2)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return 1;
  }  

  ent->getAttachedDblArr (tag, data_arr, data_size);
  return 0;
}

int FMDB_Ent_SetEntArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pMeshEnt* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=3 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  

  ent->attachPntArr (tag, (void**)data_arr, data_size);
  return 0;
}

int FMDB_Ent_GetEntArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pMeshEnt** data_arr, int* data_size)
{ 
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=3)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return 1;
  }  
  ent->getAttachedPntArr (tag, (void***)data_arr, data_size);
  return 0;
}

int FMDB_Ent_SetSetArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pEntSet* data_arr, int data_size)
{ 
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (mesh, tag, &tag_size);
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=4 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return 1;
  }  
  
  ent->attachPntArr (tag, (void**)data_arr, data_size);
  return 0;
}

int FMDB_Ent_GetSetArrTag (pMeshMdl mesh, pMeshEnt ent, pTag tag, pEntSet** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (mesh, tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return 1;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (mesh, tag, &tag_type);

  if (tag_type!=4)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return 1;
  } 

  ent->getAttachedPntArr (tag, (void***)data_arr, data_size);
  return 0;
}
