/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"
#include "mMeshIO.h"
#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "iUtil.h"
#include <assert.h>
#include <list>
#include "FMDB_cint.h"
#include "mDebugUtil.h"
#ifdef FMDB_PARALLEL
#include "mPartition.h"
#endif

int FMDB_Mesh_GetLastError (pMeshMdl mesh, int *error_type)
{
  *error_type = mesh->last_error;
  return SCUtil_SUCCESS;
}

/***************************************
      MESH/PART MANAGEMENT FUNCTIONS
****************************************/
int FMDB_Mesh_Create(pGeomMdl geom, pMeshMdl& mesh)
{
  mesh = new mMesh(geom);
  pPart part = new mPart(mesh->partID++,geom, mesh);
  mesh->addPart(part);
  return SCUtil_SUCCESS; //_Err::SUCCESS;
} 

int FMDB_Mesh_Del(pMeshMdl& mesh)
{
  mesh->clearPart();
  delete mesh;
  return SCUtil_SUCCESS; //_Err::SUCCESS;
}

/* 
If distributed = 0, load a serial mesh and partition if mesh has multi parts
if distributed = 1, load a distributed mesh (#total parts >= # mesh files)
*/
int FMDB_Mesh_LoadFromFile (pMeshMdl mesh, const char* fileName, int distributed)
{
  // the following block will guarantee the input string is
  //  null terminated and has no trailing whitespace -  {
  char terminatedInputString[MAX_STRING_LENGTH];
  strncpy(terminatedInputString, fileName, MAX_STRING_LENGTH-1);
  terminatedInputString[MAX_STRING_LENGTH-1] = 0;
  char *end = terminatedInputString + strlen(terminatedInputString) - 1;
  while (end >= terminatedInputString && 
         (isspace(*end) || iscntrl(*end)) ) {
    end--;
  }
  *(end + 1) = '\0';
  // }

  int err = SCUtil_SUCCESS;
  char ext[6];
  strcpy(ext,terminatedInputString+(strlen(terminatedInputString)-3));
  if (distributed)
  {
#ifdef FMDB_PARALLEL
    if(!strcmp(ext,"cdf") || !strcmp(ext, ".nc") || !strcmp(ext,"vtk"))
    {
      cout<<__func__<<" (distributed=1) is supported only for SMS mesh\n";
      return SCUtil_FAILURE;
    }
    FMDB_Util::Instance()->loadPartitionedMesh(*(mesh->partBegin()), terminatedInputString);
#else // serial
    cout<<__func__<<" (distributed=1) not implemented in SERIAL\n";
    return SCUtil_FAILURE;
#endif
  } // distributed=1
  else // load serial mesh and partition
  {
    if (mesh->getNumPart()>1)
    {
      cout<<__func__<<" with multiple parts not implemented\n";
      return SCUtil_FAILURE;
    }
    // load serial mesh
    pPart part = *(mesh->partBegin());
    if (ParUtil::Instance()->rank()==0)
      {
      err = FMDB_Util::Instance()->import (mesh, terminatedInputString);
      if(err != SCUtil_SUCCESS)
        return err;
      }
      else
      {
        FILE *in = fopen(fileName, "r");
        if(!in)
            return SCUtil_FILE_NOT_FOUND;
        fclose(in);
      }
#ifdef FMDB_PARALLEL
    if (ParUtil::Instance()->size()>1)
    {
      zoltanCB zlb;
      ParUtil::Instance()->Barrier(__LINE__,__FILE__);  
      vector<pPart> parts;
      FMDB_Mesh_GetProcPart (mesh, ParUtil::Instance()->rank(), parts);
      _partitionMesh(parts,zlb,1);
      ParUtil::Instance()->set_maxMeshDim(M_globalMaxDim(part));
    }
#endif
  }
  return SCUtil_SUCCESS; //_Err::SUCCESS;
}

int FMDB_Mesh_WriteToFile (pMeshMdl mesh, const char* fileName, int distributed)
{
  char ext[6];
  strcpy(ext,fileName+(strlen(fileName)-3)); 

#ifdef FMDB_PARALLEL
  if (distributed)
  {
    if(!strcmp(ext,"cdf") || !strcmp(ext, ".nc") || !strcmp(ext,"vtk"))
    {
      cout<<__func__<<" is supported only for SMS mesh\n";
      return SCUtil_FAILURE;
    }
    vector<pPart> parts;
    FMDB_Mesh_GetProcPart (mesh, ParUtil::Instance()->rank(), parts);
    FMDB_Util::Instance()->writePartitionedMesh(parts,fileName);
  }
  else
#endif
  if (ParUtil::Instance()->rank()==0 &&mesh->getNumPart()>1)
  {
    cout<<__func__<<" with multiple parts not implemented yet\n";
    return SCUtil_FAILURE;
  }

  pPart part = *(mesh->partBegin());
  if(!strcmp(ext,"cdf"))
    exportNCDF(part, mesh->getGeomModel(), fileName, NULL);
#ifdef NCDF64
  else if(!strcmp(ext,".nc"))
    exportNCDFBin(part, mesh->getGeomModel(), fileName, NULL);
#endif/*NCDF64*/
  else if(!strcmp(ext,"vtk"))
    exportVTK(part, fileName);
  else
    exportSMS(mesh, fileName);
  return SCUtil_SUCCESS; //_Err::SUCCESS;
}

int FMDB_Mesh_IsEmpty (pMeshMdl mesh, int* empty)
{
  int global_empty_flag=1, local_empty_flag=1;
  
  for (mMesh::partIter pit=mesh->partBegin(); pit!=mesh->partEnd(); ++pit)
    if ((*pit)->size(0))  // not empty
    {  
      global_empty_flag =0; 
      local_empty_flag=0;
      break;
    }
#ifdef FMDB_PARALLEL
  // do communication for global mesh
  MPI_Comm comm;
  FMDB_GetComm (&comm);
  int numProc;
  FMDB_GetNumProc (&numProc);
  if (numProc>1) MPI_Allreduce(&local_empty_flag,&global_empty_flag,1,MPI_INT,MPI_MIN,comm);
#endif
  *empty = global_empty_flag;
  return SCUtil_SUCCESS;   
}

int FMDB_Mesh_GetDim (pMeshMdl mesh, int* dim)
{
  if (mesh->getNumPart()>1)
  {
    cout<<__func__<<" with multiple parts not implemented yet\n";
    return SCUtil_FAILURE;
  }
  FMDB_Part_GetDim (*mesh->partBegin(), dim);
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_GetGeomMdl (pMeshMdl mesh, pGeomMdl& geom)
{
  geom = mesh->getGeomModel();
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_GetNumPart (pMeshMdl mesh, int procId, int* numPart)
{
  *numPart = mesh->getNumPart();
  return SCUtil_SUCCESS; 
}

int FMDB_Mesh_GetProcPart(pMeshMdl mesh, int procId, std::vector<pPart>& vecPart)
{
  std::copy (mesh->partBegin(), mesh->partEnd(), std::back_inserter (vecPart));
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_GetPart(pMeshMdl mesh, int ith, pPart& part)
{
  part = mesh->getPart(ith);
  if (!part) 
    return SCUtil_FAILURE;
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_GetProcPartID (pMeshMdl  mesh, int procId, std::vector<int>& vecPartID)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

int FMDB_Mesh_GetNumSet (pMeshMdl  mesh, int* numEntSet)
{
  *numEntSet = mesh->allEntSets.size();
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_GetSet (pMeshMdl  mesh, std::vector<pEntSet> &entsets)
{
  std::copy(mesh->allEntSets.begin(), mesh->allEntSets.end(), std::back_inserter(entsets));
  return SCUtil_SUCCESS;
}

// unique ent set ID gets invalid once new entity set is added (e.g. migration, modification)
int FMDB_Mesh_SetSetID (pMeshMdl  mesh)
{
  mEntitySet* eset;
  std::list<mEntitySet*>::iterator eset_it = mesh->beginEntSet();
  for (int eset_cnt=1; eset_it!=mesh->endEntSet(); ++eset_it)
    (*eset_it)->attachInt(FMDB_Util::Instance()->getId(),eset_cnt++); // attach unique ID to ent set
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_DelSetID (pMeshMdl mesh)
{
  mEntitySet* eset;
  std::list<mEntitySet*>::iterator eset_it = mesh->beginEntSet();
  for (int eset_cnt=0; eset_it!=mesh->endEntSet(); ++eset_it)
  {
      eset = *eset_it;
      eset->deleteData(FMDB_Util::Instance()->getId()); // attach unique ID to ent set
  }
  return SCUtil_SUCCESS;
}

