/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"

#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "iUtil.h"
#include <assert.h>
#include <list>
#include "FMDB_cint.h"

int FMDB_Set_NonPO_Create(pMeshMdl mesh, int isList, pEntSet& entSet)
{
  entSet = mEntitySet::createEntitySet(mesh, isList);
  mesh->addEntSet(entSet);
  return SCUtil_SUCCESS;
}

int FMDB_Set_PO_Create (pPart part, pEntityGroup& entSet)
{
  entSet = part->createEntGrp(part->getDimension()); 
  return SCUtil_SUCCESS; 
}

/* Remove the entity set from part & delete it*/
int FMDB_Set_Del (pMeshMdl mesh, pPart part, pEntSet entSet)
{
   if (entSet->getContainerType()== mAttachableDataContainer::ENTITYGROUP)
      part->deleteEntGrp((mEntityGroup*)entSet, 1); 
   else
   {
      mesh->removeEntSet((pEntSet)entSet);
      delete (pEntSet)entSet;
   }
   return SCUtil_SUCCESS; 
}

int FMDB_Part_Set_PO_GetNum (pPart part, int* numEntSet)
{
   *numEntSet = part->numEntGrp(); 
   return SCUtil_SUCCESS; 
}

int FMDB_Part_Set_PO_Iter_Init(pPart part, pPartSetIter& iter)
{
   iter =  part->beginEntGrp(); 
   return SCUtil_SUCCESS; 
}

int FMDB_Part_Set_PO_Iter_GetNext(pPart part, pPartSetIter& iter, pEntityGroup& entSet)
{
    if (iter == part->endEntGrp())
      return SCUtil_FAILURE; 
      
    entSet = *iter;
    ++iter; 
    return SCUtil_SUCCESS; 
}

int FMDB_Part_Set_PO_Iter_IsEnd(pPart part, pPartSetIter iter, int* isEnd)
{
   if (iter == part->endEntGrp())
      * isEnd = 1; 
   else
      * isEnd = 0; 
   return SCUtil_SUCCESS; 
}


int FMDB_Set_GetID (pEntSet eset)
{
  return eset->getAttachedInt(FMDB_Util::Instance()->getId());
}

int FMDB_EntSet_IsEmpty (pEntSet eset, int* isEmpty)
{
   *isEmpty = eset->isEmpty(); 
   return SCUtil_SUCCESS; 
}

int FMDB_Set_IsList (pEntSet eset, int* isList)
{
  *isList = eset->isList(); 
  return SCUtil_SUCCESS;
}

int FMDB_Set_IsPO (pEntSet eset, int* isPO)
{
   if (eset->getContainerType()== mAttachableDataContainer::ENTITYGROUP)
      *isPO = 1; 
   else
      *isPO = 0; 
   return SCUtil_SUCCESS; 
}


/* Given an entity set handle and a mesh entity handle, add the entity into the entity set.*/
int FMDB_Set_AddEnt (pEntSet /* inout */ entSet, pMeshEnt /* in */ meshEnt)
{
   entSet->addEntity(meshEnt);
   return SCUtil_SUCCESS;
}

int FMDB_Set_AddEnts (pEntSet entSet, vector<pMeshEnt> meshEnts)
{
   vector<pMeshEnt>::iterator iter = meshEnts.begin(); 
   for(; iter!= meshEnts.end(); ++iter)
   {
      entSet->addEntity(*iter); 
   }
   return SCUtil_SUCCESS; 
}

/* Given an entity set and a mesh entity handle, remove the entity from the entity set */
int FMDB_Set_RmvEnt (pEntSet /* inout */ entSet, pMeshEnt /* in */ meshEnt)
{
   entSet->removeEntity(meshEnt);
   return SCUtil_SUCCESS;
}

int FMDB_Set_Clr (pEntSet entSet)
{
   if(entSet->isList())
      ((mEntitySetUnordered*)entSet)->clear(); 
   else
      ((mEntitySetOrdered*)entSet)->clear();
   return SCUtil_SUCCESS; 
}


int FMDB_Set_GetNumEnt (pEntSet eset, int *num)
{
  *num = eset->numEntity(); 
  return SCUtil_SUCCESS;
}

int FMDB_Set_HasEnt (pEntSet eset, pMeshEnt ent, int* has)
{
  *has = (int)(eset->existEntity(ent)); 
  return SCUtil_SUCCESS;
}

int FMDB_Set_LoadFromFile (pPart part, pEntSet eset, char* fileName)
{
  cout<<__func__<<" is not implemented yet \n";
  return SCUtil_FAILURE;
}

int FMDB_Set_WriteToFile (pPart part, pEntSet eset, char* fileName)
{
  cout<<__func__<<" is not implemented yet\n";
  return SCUtil_FAILURE;
}

/* Given an entity set and an entity type (0 to 4), get a pointer to the first mesh entity of type.
If no entity exists or type is invalid, null is gotton for Iter.*/

int FMDB_SetEntIter_Init (pEntSet /* in */ entSet, int /* in */ type, int topo, pSetEntIter& /* out */ iter, pMeshEnt& ent)
{
  iter = new entSetIter;
  if(entSet->isList())
  {
    iter->isList=1;
    iter->iter = new mEntSetUIterator(((mEntitySetUnordered*)entSet)->begin(), ((mEntitySetUnordered*)entSet)->end(),type, topo, (void*)entSet, &processingEntitySetUFilter);
    if(((pEntSetUIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetUIterator)iter->iter);
  }
  else
  {
    iter->isList=0;
    iter->iter = new mEntSetOIterator(((mEntitySetOrdered*)entSet)->begin(), ((mEntitySetOrdered*)entSet)->end() ,type, topo, (void*)entSet, &processingEntitySetOFilter );
    if(((pEntSetOIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetOIterator)iter->iter);
  }
  return SCUtil_SUCCESS; 
}

/* Gets next entity in the entity set. If there are no more entities, the function returns error (1)*/
int FMDB_SetEntIter_GetNext(pSetEntIter& iter, pMeshEnt& ent)
{
  if(iter->isList)	
  {
    ((pEntSetUIterator)iter->iter)->next();
    if(((pEntSetUIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetUIterator)iter->iter);
  }
  else
  {
    ((pEntSetOIterator)iter->iter)->next();
    if(((pEntSetOIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetOIterator)iter->iter); 
  }
  return SCUtil_SUCCESS;
}

int FMDB_SetEntIter_IsEnd(pSetEntIter iter, int* isEnd)
{
  if(iter->isList)
  {
    ((pEntSetUIterator)iter->iter)->valid_check();
    if(((pEntSetUIterator)iter->iter)->end())
      *isEnd = 1;
    else
      *isEnd = 0;
  }
  else
  {  
    if (((pEntSetOIterator)iter->iter)->end())
      *isEnd = 1;
    else
      *isEnd = 0;
  }
  return SCUtil_SUCCESS;
}
/* Resets the iterator*/
int FMDB_SetEntIter_Reset(pSetEntIter iter, pMeshEnt& ent)
{
  if (iter->isList)
  {
    ((pEntSetUIterator)iter->iter)->reset();
    if (((pEntSetUIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetUIterator)iter->iter);
  }
  else
  {
    ((pEntSetOIterator)iter->iter)->reset();
    if (((pEntSetOIterator)iter->iter)->end())
      return SCUtil_FAILURE;
    ent = **((pEntSetOIterator)iter->iter);
  }
  return SCUtil_SUCCESS;
}

int FMDB_SetEntIter_Del(pSetEntIter iter)
{
  delete iter;
  return SCUtil_SUCCESS;
}

int FMDB_Set_SetWgt (pEntSet entSet, int wgt)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_NOT_SUPPORTED;
}

int FMDB_Set_GetWgt (pEntSet entSet, int wgt)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_NOT_SUPPORTED;
}

int FMDB_Set_PO_BuildPrismStacks(pPart part)
{
// construct entity groups 
  pFace oface, face; 
  pRegion oreg, reg; 
  mEntityGroup* entGrp;

  pPartEntIter iter; 
  int isEnd, iterEnd = FMDB_PartEntIter_Init (part, 2, FMDB_ALLTOPO, iter, face);
  int loop_counter=0;
  int inter_counter=0; 
  while (!iterEnd)
  {
    if(face->getType()==mEntity::TRI && GEN_type(F_whatIn(face))==2) {                  // on model face
      inter_counter++; 
    
      reg = F_region(face, 0);
      if(!reg)
	 reg = F_region(face, 1);
      if(!reg) {
	 cout<<__func__<<" failed: no region is connected to a surface face. "<<endl; 
	 return SCUtil_FAILURE; 
      }

      oface = face; 
      oreg = reg; 

      if(reg->getType() == mEntity::PRISM) {
	 entGrp = part->createEntGrp(part->getDimension()); 
	 ++loop_counter; 
      }
      else
      {
         iterEnd = FMDB_PartEntIter_GetNext(iter, face); 
	 continue; 
      }

      while (reg->getType()== mEntity::PRISM) {
   
	entGrp->addEntity(reg);                   // add an entity to the entity group
      
	pPList flist = R_faces(reg, 0);
	void* it=0; 
	while(face = (pFace)PList_next(flist, &it)) {
	 
	  if(face!=oface && face->getType()==mEntity::TRI) {
            
	    int i=0; 
	    for(; i< F_numRegions(face); i++) {
	      reg = F_region(face, i); 
	      if(reg!=oreg)
		break; 
	    }
	    
	    if(!reg || i==F_numRegions(face)) {
	      cout<<__func__<<" failed: the number of regions connected to a interior face is not correct. "<<endl;
	      return SCUtil_FAILURE;
	    }
	    
	    //  cout<<"oface:"<<oface<<","<<EN_getUid(oface)<<endl; 
	    //  cout<<", face:"<<face<<","<<EN_getUid(face)<<endl; 
	    oface = face; 
	    oreg = reg; 
	    break;   
	  }
	}
	PList_delete(flist);
      }
      
    }  
    iterEnd = FMDB_PartEntIter_GetNext(iter, face);
  }
  
  FMDB_PartEntIter_IsEnd(iter, &isEnd);
  FMDB_PartEntIter_Del (iter);
  return SCUtil_SUCCESS; 
}



