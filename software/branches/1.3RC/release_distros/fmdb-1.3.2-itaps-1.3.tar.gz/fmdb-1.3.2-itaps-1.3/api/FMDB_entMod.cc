/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"

#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "iUtil.h"
#include <assert.h>
#include <list>
#include "FMDB_cint.h"

/***************************************
      Entity Modification FUNCTIONS
****************************************/
/**
  * create a mesh entity
  */
int FMDB_Ent_Del (pPart part, pMeshEnt ent)
{
  // remove from upward adj of one-level downward entities
  int type = ent->getLevel();
  if (type>0)
    for(int i=0;i<ent->size(type-1);++i)
        ent->get(type-1,i)->del(ent);

  // remove from part
  part->DEL(ent);
  return SCUtil_SUCCESS;
}

/**
  * create a mesh vertex, edge, face and region
  */
int FMDB_Vtx_Create (pPart part, pGeomEnt geomEnt, double* xyz,
                     double* param, pMeshVtx& meshVtx)
{
  meshVtx = part->createVertex (xyz[0],xyz[1],xyz[2],geomEnt);
  meshVtx->attachVector (FMDB_Util::Instance()->getParametric(), 
                     SCOREC::Util::mVector (*param,*(param+1),*(param+2)) );
 ITAPS_Util::Instance()->increaseNTE(part, mEntity::POINT);  
  return SCUtil_SUCCESS;
}

int FMDB_Edge_Create (pPart part, pGeomEnt geomEnt, pMeshVtx meshVtx1, pMeshVtx meshVtx2, 
                      pMeshEdge& meshEdge)
{
  pMeshEdge edge;
  pMeshVtx vertices[2];

  vertices[0] = meshVtx1;
  vertices[1] = meshVtx2;

  FMDB_Ent_Find(part, FMDB_EDGE, vertices, 2, meshEdge);
  if (meshEdge)
    return SCUtil_ENTITY_ALREADY_EXISTS;
  meshEdge = (pMeshEnt)part->createEdge ((mVertex*)vertices[0], (mVertex*)vertices[1], geomEnt);
  meshVtx1->add (meshEdge);
  meshVtx2->add (meshEdge);
  ITAPS_Util::Instance()->increaseNTE(part, mEntity::LINE_SEGMENT);
  return SCUtil_SUCCESS;
}

int FMDB_Face_Create (pPart part, pGeomEnt geomEnt, int topo, pMeshEnt* downEnts, int* dirs, pMeshFace& meshFace)
{
  meshFace = (pMeshEnt)0;
  pMeshEnt tmpEdges[2];
  int downType = downEnts[0]->getLevel(); 
  int numDownEnts = FMDB_Topo_GetNumDownAdj(topo, downType);
  int err = SCUtil_SUCCESS;
  FMDB_Ent_Find(part, FMDB_FACE, downEnts, numDownEnts, meshFace);
  if(meshFace)
   return SCUtil_ENTITY_ALREADY_EXISTS;
  if (downType==FMDB_VERTEX)  // create face with vertices
  {
    pMeshEnt* edges = new pMeshEnt[numDownEnts];
    if(topo == FMDB_TRI) // triangle
    {
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[0],downEnts[1], edges[0]);
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[1], downEnts[2], edges[1]);
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[0], downEnts[2], edges[2]);
      meshFace = (pMeshEnt)part->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],(mEdge*)edges[2], geomEnt, dirs);
    }
    else if (topo == FMDB_QUAD)
    {
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[0],downEnts[1], edges[0]);
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[1],downEnts[2], edges[1]);
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[2], downEnts[3], edges[2]);
      FMDB_Edge_Create (part, (pGEntity)0, downEnts[0],downEnts[3], edges[3]);

      meshFace =  (pMeshEnt)part->createFaceWithEdges((mEdge*)edges[0],(mEdge*)edges[1],
                                   (mEdge*)edges[2],(mEdge*)edges[3],geomEnt,dirs);
    }
    else
    {
      cout<<__func__<<" failed: # bounding vertices should be 3 or 4\n";
      return SCUtil_FAILURE;
    }
    for(int i=0;i<numDownEnts;i++)
      edges[i]->add(meshFace);
  }
  else if (downType==FMDB_EDGE)  // create face with edges
  {
    if (topo == FMDB_TRI)
      meshFace = (pMeshEnt)part->createFaceWithEdges((mEdge*) downEnts[0],(mEdge*)downEnts[1],
                                  (mEdge*)downEnts[2],geomEnt,dirs);
   else if (topo == FMDB_QUAD)
     {
      meshFace = (pMeshEnt)part->createFaceWithEdges((mEdge*) downEnts[0],(mEdge*)downEnts[1],
                                  (mEdge*)downEnts[2], (mEdge*)downEnts[3], geomEnt,dirs);
     }
    else
    {
      cout<<__func__<<" failed: # bounding edges should be 3 or 4\n";
      return SCUtil_INVALID_ENTITY_COUNT;
    }
    for (int i=0; i<numDownEnts;i++)
      downEnts[i]->add(meshFace);
  }
  else
  {
    cout<<__func__<<" failed: downward adj entity type should be 0 or 1\n";
    return SCUtil_INVALID_ENTITY_COUNT;
  }
  if(topo == FMDB_TRI)
   ITAPS_Util::Instance()->increaseNTE(part, mEntity::TRIANGLE);
  else if(topo == FMDB_QUAD)
   ITAPS_Util::Instance()->increaseNTE(part, mEntity::QUADRILATERAL);
  return SCUtil_SUCCESS;
}

int FMDB_Rgn_Create (pPart part, pGeomEnt geomEnt, int topo, int numDownEnts,
                     pMeshEnt* downEnts, pMeshEnt& meshRgn)
{
mEntity* faces[8];

int downType = downEnts[0]->getLevel();
int numDownEntsTopo = FMDB_Topo_GetNumDownAdj(topo, downType);

  if (numDownEntsTopo != numDownEnts)
  {
    cout<<__func__<<" failed: new_topo="<<topo<<", downType="<<downType<<", expected #downEnt="<<numDownEntsTopo<<", input #downEnt="<<numDownEnts<<endl; 
    return SCUtil_INVALID_ENTITY_COUNT;
  }
//initialize the mesh region with NULL
meshRgn = (pMeshEnt)0;
FMDB_Ent_Find(part, FMDB_REGION, downEnts, numDownEnts, meshRgn);
if(meshRgn)
 return SCUtil_ENTITY_ALREADY_EXISTS;

if(downType == FMDB_FACE)
{
 for(int i = 0; i < numDownEnts; i++)
 {
  if(!downEnts[i] || downEnts[i]->getLevel() != downType)
   return SCUtil_INVALID_ARGUMENT;
  faces[i] = downEnts[i];  
 }
}
  if(downType < FMDB_VERTEX || downType > FMDB_FACE)
  {
    cout<<__func__<<" failed: downward adj entity type should be 0, 1 or 2\n";
    return SCUtil_INVALID_ENT_TYPE;
  }

  mEntity* tmpVtx[4];
  mEntity* tmpEdges[4];

int numFaces = 0;
if(topo == FMDB_TET && downType == FMDB_VERTEX)
 {
  FMDB_Face_Create(part, geomEnt, FMDB_TRI, downEnts, 0, faces[0]);
  // build tetrahedron edges using vertices
  tmpVtx[0] = downEnts[0];
  tmpVtx[1] = downEnts[1];
  tmpVtx[2] = downEnts[3];
  FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[1]);

  tmpVtx[0] = downEnts[1];
  tmpVtx[1] = downEnts[2];
  tmpVtx[2] = downEnts[3];
  FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[2]);

  tmpVtx[0] = downEnts[0];
  tmpVtx[1] = downEnts[2];
  tmpVtx[2] = downEnts[3];
  FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[3]);
 } 
  else if(topo == FMDB_PYRAMID && downType == FMDB_VERTEX)
   {
   //build pyramid edges using vertices
   FMDB_Face_Create(part, geomEnt,FMDB_QUAD, downEnts, 0, faces[0]);
   
   tmpVtx[0] = downEnts[0];
   tmpVtx[1] = downEnts[1];
   tmpVtx[2] = downEnts[4];
   FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[1]);

   tmpVtx[0] = downEnts[1];
   tmpVtx[1] = downEnts[2];
   tmpVtx[2] = downEnts[4];
   FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[2]);

   tmpVtx[0] = downEnts[2];
   tmpVtx[1] = downEnts[3];
   tmpVtx[2] = downEnts[4];
   FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[3]);

   tmpVtx[0] = downEnts[3];
   tmpVtx[1] = downEnts[0];
   tmpVtx[2] = downEnts[4];
   FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[4]);
   }
  else if(topo == FMDB_PRISM && downType == FMDB_VERTEX)
   {
    FMDB_Face_Create(part, geomEnt,FMDB_TRI, downEnts, 0, faces[0]);
    
    tmpVtx[0] = downEnts[0];
    tmpVtx[1] = downEnts[1];
    tmpVtx[2] = downEnts[4];
    tmpVtx[3] = downEnts[3];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[1]);

    tmpVtx[0] = downEnts[1];
    tmpVtx[1] = downEnts[2];
    tmpVtx[2] = downEnts[5];
    tmpVtx[3] = downEnts[4];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[2]);

    tmpVtx[0] = downEnts[2];
    tmpVtx[1] = downEnts[0];
    tmpVtx[2] = downEnts[3];
    tmpVtx[3] = downEnts[5];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[3]);

    tmpVtx[0] = downEnts[3];
    tmpVtx[1] = downEnts[4];
    tmpVtx[2] = downEnts[5];
    FMDB_Face_Create(part, geomEnt,FMDB_TRI, tmpVtx, 0, faces[4]);
   }
  else if(topo == FMDB_HEX && downType == FMDB_VERTEX)
   {
    tmpVtx[0] = downEnts[0];
    tmpVtx[1] = downEnts[3];
    tmpVtx[2] = downEnts[2];
    tmpVtx[3] = downEnts[1];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[0]);
 
    tmpVtx[0] = downEnts[0];
    tmpVtx[1] = downEnts[1];
    tmpVtx[2] = downEnts[5];
    tmpVtx[3] = downEnts[4];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[1]);

    tmpVtx[0] = downEnts[1];
    tmpVtx[1] = downEnts[2];
    tmpVtx[2] = downEnts[6];
    tmpVtx[3] = downEnts[5];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx,0, faces[2]);

    tmpVtx[0] = downEnts[2];
    tmpVtx[1] = downEnts[3];
    tmpVtx[2] = downEnts[7];
    tmpVtx[3] = downEnts[6];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[3]);

    tmpVtx[0] = downEnts[3];
    tmpVtx[1] = downEnts[0];
    tmpVtx[2] = downEnts[4];
    tmpVtx[3] = downEnts[7];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[4]);

    tmpVtx[0] = downEnts[4];
    tmpVtx[1] = downEnts[5];
    tmpVtx[2] = downEnts[6];
    tmpVtx[3] = downEnts[7];
    FMDB_Face_Create(part, geomEnt,FMDB_QUAD, tmpVtx, 0, faces[5]);
   }
 if(topo == FMDB_TET && downType == FMDB_EDGE)
  {
  // build tetrahedron faces using edges
  FMDB_Face_Create(part, geomEnt, FMDB_TRI, downEnts, 0, faces[0]);

  tmpEdges[0] = downEnts[0];
  tmpEdges[1] = downEnts[4];
  tmpEdges[2] = downEnts[3];
  FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges, 0, faces[1]);

  tmpEdges[0] = downEnts[1];
  tmpEdges[1] = downEnts[5];
  tmpEdges[2] = downEnts[4];
  FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[2]);

  tmpEdges[0] = downEnts[2];
  tmpEdges[1] = downEnts[3];
  tmpEdges[2] = downEnts[5];
  FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[3]);
  }
  else if(topo == FMDB_PYRAMID && downType == FMDB_EDGE) 
    {
    // build pyramid faces using edges   
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, downEnts,0,faces[0]);

   tmpEdges[0] = downEnts[0];
   tmpEdges[1] = downEnts[5];
   tmpEdges[2] = downEnts[4];
   FMDB_Face_Create(part, geomEnt, FMDB_TRI,tmpEdges,0,faces[1]);

   tmpEdges[0]= downEnts[1];
   tmpEdges[1]= downEnts[6];
   tmpEdges[2]= downEnts[5];
   FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[2]);

   tmpEdges[0]= downEnts[2];
   tmpEdges[1]= downEnts[7];
   tmpEdges[2]= downEnts[6];
   FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[3]);

   tmpEdges[0]= downEnts[3];
   tmpEdges[1]= downEnts[4];
   tmpEdges[2]= downEnts[7];
   FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[4]);
    }
  else if(topo == FMDB_PRISM && downType == FMDB_EDGE)
   {
    // build prism faces using edges
   FMDB_Face_Create(part, geomEnt, FMDB_TRI, downEnts,0,faces[0]);

   tmpEdges[0]=downEnts[0];
   tmpEdges[1]=downEnts[4];
   tmpEdges[2]=downEnts[6];
   tmpEdges[3]=downEnts[3];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[1]);

   tmpEdges[0]=downEnts[1];
   tmpEdges[1]=downEnts[4];
   tmpEdges[2]=downEnts[7];
   tmpEdges[3]=downEnts[5];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[2]);

   tmpEdges[0]=downEnts[2];
   tmpEdges[1]=downEnts[3];
   tmpEdges[2]=downEnts[8];
   tmpEdges[3]=downEnts[5];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[3]);

   tmpEdges[0]=downEnts[6];
   tmpEdges[1]=downEnts[7];
   tmpEdges[2]=downEnts[8];
   FMDB_Face_Create(part, geomEnt, FMDB_TRI, tmpEdges,0,faces[4]);
   }
  else if(topo == FMDB_HEX && downType == FMDB_EDGE)
   {
   // build hexahedron faces using edges
   tmpEdges[0]=downEnts[3];
   tmpEdges[1]=downEnts[2];
   tmpEdges[2]=downEnts[1];
   tmpEdges[3]=downEnts[0];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[0]); 

   tmpEdges[0]=downEnts[0];
   tmpEdges[1]=downEnts[5];
   tmpEdges[2]=downEnts[8];
   tmpEdges[3]=downEnts[4];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[1]);
  
   tmpEdges[0]=downEnts[1];
   tmpEdges[1]=downEnts[6];
   tmpEdges[2]=downEnts[9];
   tmpEdges[3]=downEnts[5];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[2]);

   tmpEdges[0]=downEnts[2];
   tmpEdges[1]=downEnts[7];
   tmpEdges[2]=downEnts[10];
   tmpEdges[3]=downEnts[6];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[3]);

   tmpEdges[0]=downEnts[3];
   tmpEdges[1]=downEnts[4];
   tmpEdges[2]=downEnts[11];
   tmpEdges[3]=downEnts[7];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[4]);

   tmpEdges[0]=downEnts[8];
   tmpEdges[1]=downEnts[9];
   tmpEdges[2]=downEnts[10];
   tmpEdges[3]=downEnts[11];
   FMDB_Face_Create(part, geomEnt, FMDB_QUAD, tmpEdges,0,faces[5]);
   }
 if(topo == FMDB_TET)
   {
   // build tetrahedron region using faces
   numFaces = 4;
   meshRgn= (pMeshEnt)part->createTetWithFaces ((mFace*)faces[0],(mFace*)faces[1],(mFace*)faces[2],(mFace*)faces[3],geomEnt);
   ITAPS_Util::Instance()->increaseNTE(part, mEntity::TETRAHEDRON);
    }
 else if(topo == FMDB_PYRAMID)
   {
    // build pyramid region using faces
    numFaces = 5;
    meshRgn = (pMeshEnt)part->createPyramidWithFaces ((mFace*)faces[0],(mFace*)faces[1],(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],geomEnt);
    ITAPS_Util::Instance()->increaseNTE(part, mEntity::PYRAMID_);
   }
  else if(topo == FMDB_PRISM)
   {
    // build prism region using faces
    numFaces = 5;
    meshRgn = (pMeshEnt)part->createPrismWithFaces ((mFace*)faces[0],(mFace*)faces[1],(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],geomEnt);
    ITAPS_Util::Instance()->increaseNTE(part, mEntity::PRISM_);
   }
  else if(topo == FMDB_HEX)
   {
    // build hexahedron region using faces
    numFaces = 6;
    meshRgn = (pMeshEnt)part->createHexWithFaces ((mFace*)faces[0],(mFace*)faces[1],(mFace*)faces[2],(mFace*)faces[3],(mFace*)faces[4],(mFace*)faces[5],geomEnt);
    ITAPS_Util::Instance()->increaseNTE(part, mEntity::HEXAHEDRON);
   }
for(int i = 0; i < numFaces; i++)
  faces[i]->add(meshRgn);
return SCUtil_SUCCESS;
}
int FMDB_Ent_Find(pPart part, int entType, pMeshEnt* downEnts, int numDownEnts, pMeshEnt& meshEnt)
{
  int err = SCUtil_SUCCESS;
  switch(entType)
   {
   case 1:
   case 2:
   case 3:
   {
    if(downEnts[0]->getLevel() >= entType)
     err = SCUtil_INVALID_ARGUMENT;
    meshEnt = (pMeshEnt)0;
    vector<pMeshEnt> vecAdjEnt;
    FMDB_Ent_GetAdj(downEnts[0], entType, 0, vecAdjEnt);
    int downType = downEnts[0]->getLevel();
    for(vector<pMeshEnt>::iterator itVec = vecAdjEnt.begin(); itVec != vecAdjEnt.end(); itVec++)
    {
     pMeshEnt upEnt = *itVec;
     vector<pMeshEnt> vecDownEnts;
     FMDB_Ent_GetAdj(upEnt, downType, 0, vecDownEnts);
     int count = 0;
     for(vector<pMeshEnt>::iterator itDown = vecDownEnts.begin(); itDown != vecDownEnts.end(); itDown++)
     {
     pMeshEnt pDownEnt = *itDown;
     bool bEntFound = false;
     for(int j = 0; j < numDownEnts; j++)
      if(downEnts[j] == pDownEnt)
       bEntFound = true;
     if(!bEntFound)
      break;
     ++count;
     if(count == numDownEnts)
      meshEnt = upEnt;
     }
    vecDownEnts.clear();
    }
    vecAdjEnt.clear();
    if(!meshEnt)
     err = SCUtil_ENTITY_NOT_FOUND;
   }
   break;
  default:
    err = SCUtil_INVALID_ENT_TYPE;
   }
  return err;
}

