/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mVertex.h"

int FMDB_Vtx_SetCoord(pMeshVtx meshVtx, double* xyz)
{
  ((mVertex*)meshVtx)->setCoord(xyz[0],xyz[1],xyz[2]);
  return SCUtil_SUCCESS;
}

int FMDB_Vtx_GetCoord (pMeshEnt meshVtx, double** xyz)
{
  (*xyz)[0] = ((mVertex*)meshVtx)->point()(0);
  (*xyz)[1]= ((mVertex*)meshVtx)->point()(1);
  (*xyz)[2] = ((mVertex*)meshVtx)->point()(2);
  return SCUtil_SUCCESS;
}

int FMDB_Vtx_SetParamCoord (pMeshVtx meshVtx, double* xyz)
{
  meshVtx->attachVector (FMDB_Util::Instance()->getParametric() , SCOREC::Util::mVector(xyz[0], xyz[1], xyz[2]));
  return SCUtil_SUCCESS;
}

int FMDB_Vtx_GetParamCoord1D (pMeshVtx meshVtx, double* param)
{
  if (!meshVtx->getData(FMDB_Util::Instance()->getParametric()))
  {
    cout<<__func__<<" failed: no parametric coordinates found with "<<FMDB_Ent_GetStrID(meshVtx)<<std::endl;
    return SCUtil_FAILURE;
  }

  SCOREC::Util::mVector vec = meshVtx->getAttachedVector (FMDB_Util::Instance()->getParametric());
  *param = vec(0);
  return SCUtil_SUCCESS;
}

int FMDB_Vtx_GetParamCoord2D (pMeshVtx meshVtx, double *param1, double *param2)
{
  if (!meshVtx->getData(FMDB_Util::Instance()->getParametric()))
  {
    cout<<__func__<<" failed: no parametric coordinates found with "<<FMDB_Ent_GetStrID(meshVtx)<<std::endl;
    return SCUtil_FAILURE;
  }

  SCOREC::Util::mVector vec = meshVtx->getAttachedVector (FMDB_Util::Instance()->getParametric());
  *param1   = vec(0);
  *param2   = vec(1);
  return SCUtil_SUCCESS;
}

