/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#include "FMDB.h"
#include "mMesh.h"

// mesh
int FMDB_Mesh_DspNumEnt (pMeshMdl mesh)
{
  (*mesh->partBegin())->printNumEntities();
  return SCUtil_SUCCESS;
}

int FMDB_Mesh_DspInfo (pMeshMdl mesh)
{
  if (mesh->getNumPart()>1)
  {
    cout<<__func__<<" with multiple parts not implemented yet\n";
    return SCUtil_FAILURE;
  }

  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");
  (*mesh->partBegin())->printAll();
  ParUtil::Instance()->Barrier(__LINE__,__FILE__);
  ParUtil::Instance()->Msg(ParUtil::INFO,"\n***  M_print(mesh)  ***\n");
  return SCUtil_SUCCESS;
}

// entity set
int FMDB_Set_DspInfo (pEntSet ent)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

// entity
int FMDB_Ent_DspInfo (pMeshEnt ent)
{
  ent->print();
  return SCUtil_SUCCESS;
}

int FMDB_Ent_DspAllAdj (pMeshEnt ent)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

