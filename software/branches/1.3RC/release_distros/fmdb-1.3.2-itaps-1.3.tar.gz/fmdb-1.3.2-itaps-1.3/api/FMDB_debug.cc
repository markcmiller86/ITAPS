/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#include "FMDB.h"
#include "mMesh.h"

int FMDB_Mesh_Verify (pMeshMdl mesh, int *isValid)
{
  if (mesh->getNumPart()>1)
  {
    cout<<__func__<<" with multiple parts not implemented yet\n";
    return SCUtil_NOT_SUPPORTED;
  }

  pPart part = *mesh->partBegin(); // get the first part

  pmEntity* pe;
  mEntity *vertex, *vertex0, *vertex1;
  mEntity* edge;
  mEntity* face;
  mEntity *region, *region0, *region1;
  int ret=1, gLevel, manifold=1, numAdjE, numAdjF, numAdjR, mypid, partDim, sameSidedRegionPairCnt=0;
  double value0, value1;
  
  FMDB_GetProcID (&mypid);
  FMDB_Part_GetDim (part, &partDim);

  
#ifdef FMDB_PARALLEL  // data for communication
  int numRC, pid;

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(sizeof(int2_mEnt2_struct));
  int2_mEnt2_struct* msg_send = (int2_mEnt2_struct*)CM->alloc_msg(sizeof(int2_mEnt2_struct));
  int num_sent = 0, num_recvd = 0;
#endif 

  // check vertices
  for (mPart::iterall it=part->beginall(0); it!=part->endall(0);++it)
  {
    vertex = *it;
    numAdjE=V_numEdges(vertex);
    if (partDim==3 && numAdjE<3)
    {  
      cout<<"FMDB INFO: V_numEdges= "<<numAdjE<<" for ";
      vertex->print();
      if (numAdjE==0) manifold=0;
    }
    if (partDim==2 && numAdjE==0)
    {  
      cout<<"FMDB INFO: V_numEdges= "<<numAdjE<<" for ";
      vertex->print();
      manifold=0;
    }

    pe = vertex->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = vertex->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) vertex->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	vertex->printRCs();
	vertex->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = vertex->rcBegin();
          rciter!=vertex->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = vertex;
        msg_send->ent2 = rciter->second;
        msg_send->i=GEN_type(vertex->getClassification());
	msg_send->j=GEN_tag(vertex->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
   } // else
#endif    
  }
  
  // check edges
  for (mPart::iterall it=part->beginall(1); it!=part->endall(1);++it)
  {
    edge = *it;
    numAdjF = E_numFaces(edge);
    
    if (partDim==3)
    {
      switch (numAdjF)
      { 
        case 0:
               cout<<"FMDB INFO: E_numFaces=0 for ";
               edge->print();
	       manifold=0;
	       break;
        case 1: if (!EN_duplicate(edge) && !edge->getIsGhost())	       
               {
	         cout<<"FMDB INFO: E_numFace=1 for ";
                 edge->print();
	         manifold=0;
	       }
	       break;
        default: break;
      } 
      gLevel=GEN_type(edge->getClassification());
      if (gLevel==1 || gLevel==2)
      {
        int bf_counter=0; // number of boundary faces adjacent
        for (int i=0; i<numAdjF; ++i)
        {
	  face = edge->get(2,i);
  	  if (GEN_type(face->getClassification())==2)
	    bf_counter++;
        }
        if (bf_counter!=2 && !EN_duplicate(edge) && !edge->getIsGhost())
        {
  	  cout<<"INFO: E_numFaces="<<bf_counter<<" for ";
          edge->print();
          manifold=0; 
        }

       // if (!EN_duplicate(edge))
//	  assert(bf_counter==2);
//	else //partition boundary edge
//	{ 
//	  assert(bf_counter==1); // SEOL: check when this happens
//	}
      } 
    }
    else if (partDim==2) // edge in 2D
    {
      if (numAdjF==0)
      {  
        cout<<"FMDB INFO: E_numFaces=0 for ";
        edge->print();
        manifold=0;
      }
    
      gLevel=GEN_type(edge->getClassification());
      switch(gLevel)
      {
        case 1: // model edge
   	        if (numAdjF!=1) 
		{
  		  cout<<"["<<mypid<<"] FMDB WARNING: "<<numAdjF<<" faces with ";
		  edge->print();
		  manifold=0;
	        }
		break;
        case 2:  if (edge->getPClassification() && !edge->getIsGhost()) // CB edge
	          assert(numAdjF==1);
		else if (!edge->getIsGhost() && numAdjF!=2)  // non-CB edge
                {
                  cout<<"E_numFaces="<<numAdjF<<" for "; edge->print();
		  assert(numAdjF==2);
                }
	      break;
        default:  cout<<"FMDB ERROR: wrong classification for ";
                edge->print();
                return false;
      } // switch
    } // else
    
    pe = edge->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = edge->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) edge->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	edge->printRCs();
	edge->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = edge->rcBegin();
          rciter!=edge->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = edge;
        msg_send->ent2 = rciter->second;
        msg_send->i = GEN_type(edge->getClassification());
        msg_send->j = GEN_tag(edge->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
    } // else
#endif     
  } // edges
 
  // check faces
  for (mPart::iterall it=part->beginall(2); it!=part->endall(2);++it)
  {
    face = *it;
#ifdef MTOOL
    IntersectionData idata;
    for (int k=0; k<3; ++k)
    {
       vtx = face->get(0,k);
       pPList vfaces=V_faces(vtx);
       iter=0;
       while ((adjfc=(mEntity*)PList_next(vfaces, &iter)))
       {
         if (face==adjfc) continue;
         idata = M_intersectionData_new() ;
	 if (1==M_intersectFaces(face, 0, adjfc, 0, &idata))
	   cout<<"FMDB FATAL: two intersecing faces: ";
           face->print();
	   adjfc->print();
         M_intersectionData_delete(idata);	       
       }
       PList_delete(vfaces);
    }
#endif    
    numAdjR = F_numRegions(face);
 
    if (partDim==3)
    {
      gLevel=GEN_type(face->getClassification());
      switch(gLevel)
      {
        case 2: // face on model face
               if (numAdjR!=1)
	       {
                 cout<<" FMDB INFO: F_numRegions="<<numAdjR<<" for ";
                 face->print();
	         manifold=0;
               }
	       break;
        case 3: // interior face
               if (EN_duplicate(face)) // CB face
	       {
  	         if (numAdjR!=1) face->print();
	         assert(numAdjR==1);
  	       } 
	       else if (!face->getIsGhost())
	       {  
	         if (F_numRegions(face)!=2) 
		 {
                   cout<<"FMDB INFO: F_numRegions="<<F_numRegions(face)<<" for ";  face->print();
                   manifold=0;
                 }
//  	         assert(F_numRegions(face)==2);
                 if (F_numRegions(face) == 0)
                   continue;
// check if two regions are on the same side;
                 region0 = face->get(3,0);
                 if (F_numRegions(face)==2)
                 { 
		   region1 = face->get(3,1);
                   vertex0 = findVertexOppositeFace(region0, face);
                   vertex1 = findVertexOppositeFace(region1, face);
                   value0 = computeSignedDistance(vertex0, face);
                   value1 = computeSignedDistance(vertex1, face);

                   if (fabs(value0)>1E-5 && fabs(value1)>1E-5 && value0*value1>0.0 ) 
                     sameSidedRegionPairCnt++;
                 }
	       }
               break;
        default: cout<<"FMDB Error: wrong classification for";
               face->print();
	       return false;
      }
    } // face in 3D
    else if (partDim==2)
    {
      if (numAdjR!=0)
      {  
        cout<<"["<<mypid<<"] FMDB ERROR: adj. regions with "<<face->getUid()<<" in 2D part\n";
        return false;
      }
      assert(F_numRegions(face)==0);
      assert(GEN_type(face->getClassification())==2);
    } // face in 2D

    pe = face->getPClassification();
#ifndef FMDB_PARALLEL 
    assert(!pe);
#else 
    numRC = face->getNumRemoteCopies();     
    if (!pe) // non-CB vertex
    {  
      if (numRC!=0) face->printRCs();
      assert(numRC==0);
      continue;
    }
    else  // CB vertex
    {
      if (numRC+1!=pe->getNumBPs())
      {
	face->printRCs();
	face->printBPs();
      }
      assert(numRC+1==pe->getNumBPs());
      for (mEntity::RCIter rciter = face->rcBegin();
          rciter!=face->rcEnd(); ++rciter)
      {
        pid = rciter->first;
        msg_send->ent1 = face;
        msg_send->ent2 = rciter->second;
        msg_send->i = GEN_type(face->getClassification());
        msg_send->j = GEN_tag(face->getClassification());
        CM->send(pid, (void*)msg_send);
        num_sent++;
      } // for rciter
    } // else
#endif         
  }
  
   // check regions
  for (mPart::iterall it=part->beginall(3); it!=part->endall(3);++it)
  {
    region = *it;
    assert(!(region->getPClassification()));
    assert(GEN_type(region->getClassification())==3);
/*    if (R_Volume2(region)<0.0)
    {
      cout<<"FMDB WARNING: Negative volume for ";
      region->print();
    }
*/
  }

#ifdef FMDB_PARALLEL
// check partition boundary
  CM->finalize_send();
  CM->free_msg(msg_send);

  void *msg_recv;
  int pid_from;
  while (int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    int2_mEnt2_struct* castbuf = (int2_mEnt2_struct*) msg_recv;
    if (GEN_type(castbuf->ent2->getClassification())!=castbuf->i)
      castbuf->ent2->print();
    assert(GEN_type(castbuf->ent2->getClassification())==castbuf->i);
    if (GEN_tag(castbuf->ent2->getClassification())!=castbuf->j)
      castbuf->ent2->print();
    assert(GEN_tag(castbuf->ent2->getClassification())==castbuf->j);
    assert(castbuf->ent2->getRemoteCopy(pid_from)==castbuf->ent1);
    CM->free_msg(msg_recv);
  }  // end of while(!AP...)
#endif
  
//  if (sameSidedRegionPairCnt!=0)
//    cout<<"["<<mypid<<"] FMDB INFO: sameSidedRegionPairCnt = "<<sameSidedRegionPairCnt<<endl;
  int globalRetVal;
  if (P_getMinInt(ret)==1 && manifold) 
    *isValid=1;
  else 
    *isValid=0;

  return SCUtil_SUCCESS;
}

