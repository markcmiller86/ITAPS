/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mEdge.h"

int FMDB_Edge_SetNode (pMeshEnt meshEdge, pNode node)
{
  if (meshEdge->getType()!=1)
  {
    cout<<__func__<<" failed: input entity is not edge\n";
    return SCUtil_INVALID_ENT_TYPE;
  }
  ((mEdge*)meshEdge)->pts.push_back (node);
  return SCUtil_SUCCESS;
}

int FMDB_Edge_GetNode (pMeshEnt meshEdge, int* numNode)
{
  if (meshEdge->getType()!=1)
  {
    cout<<__func__<<" failed: input entity is not edge\n";
    return SCUtil_INVALID_ENT_TYPE;
  }
  *numNode = ((mEdge*)meshEdge)->pts.size();
  return SCUtil_SUCCESS;
}

int FMDB_Edge_GetNumNode (pMeshEnt meshEdge, int n, pNode& node)
{
  if (meshEdge->getType()!=1)
  {
    cout<<__func__<<" failed: input entity is not edge\n";
    return SCUtil_INVALID_ENT_TYPE;
  }
  if (((mEdge*)meshEdge)->pts.size()<=n)
  {
    cout<<__func__<<" failed: " << n << "'th higher order node does not exist\n";
    return SCUtil_FAILURE;
  }
  node = ((mEdge*)meshEdge)->pts[n];
  return SCUtil_SUCCESS;
}
