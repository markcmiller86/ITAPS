/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"
#include "iUtil.h"
#include "FMDBInternals.h"
#include <string.h>
 
/* Note that the current form of the function does not take tagSize, tagType into account. One has to explicitly set the tagType (integer, double or other)*/
int FMDB_Tag_Create (pMeshMdl mesh, const char* tag_name, int tag_type, int tag_size, int traceable, pTag *tag)
{
  if (!traceable) 
  {
    cout<<__func__<<" without traceable option is not implemented yet\n";
    return SCUtil_FAILURE;
  }
  pTag temp_tag;
  if (!mesh->getTagID(tag_name, &temp_tag))  // tag with given name is found
    return SCUtil_FAILURE; // tag already exists 
 
  mesh->createTagID (tag_name, tag_type, tag_size, tag); 
  return SCUtil_SUCCESS;
}

int FMDB_Tag_Del (pMeshMdl mesh, pTag *tag, int forceDel)
{
  if (!mesh->findTagID(*tag))  // tag not found
     return SCUtil_INVALID_TAG_HANDLE; 

  /*************************/
  pPart part;

  // mesh
  if (mesh->hasData(*tag)) 
  {
    if (forceDel) mesh->deleteData(*tag);
    else  return SCUtil_TAG_IN_USE;
  }
  // part
  for (mMesh::partIter pit=mesh->partBegin(); pit!=mesh->partEnd(); ++pit)
  {
      part = *pit;
      if (part->hasData(*tag)) 
      {
        if (forceDel) part->deleteData(*tag);
        else return SCUtil_TAG_IN_USE;
      }
      
      // entity
      for (int i=0; i<=part->getDimension(); ++i)
        for (mPart::iterall ent_it=part->beginall(i); ent_it!=part->endall(i); ++ent_it)
          if ((*ent_it)->hasData(*tag)) 
          {
            if (forceDel) (*ent_it)->deleteData(*tag);
            else return SCUtil_TAG_IN_USE;
          }
  }  // for each part
  
  // entity set  
  for (std::list<pEntSet>::iterator eset_it = mesh->beginEntSet();
         eset_it!=mesh->endEntSet(); ++eset_it)
    if ((*eset_it)->hasData(*tag)) 
    {
       if (forceDel) (*eset_it)->deleteData(*tag);
       else return SCUtil_TAG_IN_USE;
    }

  /*************************/ 
  mesh->deleteTagID(*tag);
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetHandle (pMeshMdl mesh, const char* tag_name, pTag *tag)
{
  if (mesh->getTagID(tag_name, tag))  // tag not found
     return SCUtil_INVALID_TAG_HANDLE; 
  return SCUtil_SUCCESS;
}

int FMDB_Tag_Exist (pMeshMdl mesh, pTag tag, int *exist)
{
  if (mesh->findTagID (tag))
    *exist = 1;
  else
    *exist = 0;
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetName (pMeshMdl mesh, pTag tag, char* tag_name)
{
  if (!mesh->findTagID(tag))  // tag id not found
     return SCUtil_INVALID_TAG_HANDLE; 
  mesh->nameTagID(tag, tag_name);
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetType (pMeshMdl mesh, pTag tag, int* type)
{
  if (!mesh->findTagID(tag))  // tag not found
     return SCUtil_INVALID_TAG_HANDLE; 
  mesh->typeTagID (tag, type);
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetSize (pMeshMdl mesh, pTag tag, int* size)
{
  if (!mesh->findTagID(tag))  // tag not found
     return SCUtil_INVALID_TAG_HANDLE; 
  mesh->sizeTagID (tag, size);
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetAllID (pMeshMdl mesh, std::vector<pTag>& tags)
{
  mesh->getAllTagID (tags);
  return SCUtil_SUCCESS;
}

int FMDB_Tag_GetByte (pMeshMdl mesh, pTag tag, int* byte)
{
  if (!mesh->findTagID(tag))  // tag not found
     return SCUtil_INVALID_TAG_HANDLE; 
  int type, size;
  mesh->typeTagID (tag, &type);
  mesh->sizeTagID (tag, &size);
  switch (type)
  {
    case FMDB_BYTE: *byte=size; break;
    case FMDB_INT:  *byte=size*sizeof(int); break;
    case FMDB_DBL:  *byte=size*sizeof(double); break;
    case FMDB_ENT:  *byte=size*sizeof(void*); break;
    case FMDB_SET:  *byte=size*sizeof(void*); break;
    default: break;
  }
  return SCUtil_SUCCESS;
}

