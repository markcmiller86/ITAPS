/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
 
int FMDB_Part_HasTag (pPart part, pTag tag, int* hasTag)
{
  if (part->hasData(tag)) 
    *hasTag=1;
  else
    *hasTag=0;
  return SCUtil_SUCCESS;
}


int FMDB_Part_DelTag (pPart part, pTag tag)
{
  part->deleteData(tag);
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetByteTag (pPart part, pTag tag, const void* data, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }

  if(!data || !data_size)
  {
    cout<<__func__<<" failed: NULL tag_data\n";
    return SCUtil_FAILURE;
  } 

  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);
  switch (tag_type)
  { 
    case 0: part->attachOpaque(tag, (char*)data, data_size);
            break;
    case 1: { // integer
              int* iData = (int*)data;
              if (tag_size==1)  // single int
                part->attachInt(tag, *iData);
              else  // int array
              {
                 int* int_arr=new int[data_size/sizeof(int)];
                 for (int i=0; i<data_size/sizeof(int); ++i)
                   int_arr[i] = iData[i];
                 part->attachIntArr(tag, int_arr, data_size/sizeof(int));
                 delete [] int_arr;
              }
            }
            break;
    case 2: { // double
              double* dData = (double*)data;
              if (tag_size==1)
                part->attachDouble(tag, *dData);
              else  // double array
              {
                 double* dbl_arr=new double[data_size/sizeof(double)];
                 for (int i=0; i<data_size/sizeof(double); ++i)
                   dbl_arr[i] = dData[i];
                 part->attachDblArr(tag, dbl_arr, data_size/sizeof(double));
                 delete [] dbl_arr;
              }
            }
            break;
    case 3: { // entity
              pMeshEnt* entData = (pMeshEnt*)data;
              if (tag_size==1)
                part->attachPnt(tag, *entData);
              else  // entity array
              {
                 pMeshEnt* ent_arr=new pMeshEnt[data_size/sizeof(void*)];
                 for (int i=0; i<data_size/sizeof(void*); ++i)
                   ent_arr[i] = entData[i];
                 part->attachPntArr(tag, (void**)ent_arr, data_size/sizeof(void*));
                 delete [] ent_arr;
              }            
            }
            break;
    case 4: { // entity set
              pEntSet* setData = (pEntSet*)data;
              if (tag_size==1)
                part->attachPnt(tag, *setData);
              else  // entity set array
              { 
                 pEntSet* set_arr=new pEntSet[data_size/sizeof(void*)];
                 for (int i=0; i<data_size/sizeof(void*); ++i)
                   set_arr[i] = setData[i];
                 part->attachPntArr(tag, (void**)set_arr, data_size/sizeof(void*));
                 delete [] set_arr;
              }  
            }
            break;
    default: break;
  } // switch  
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetByteTag (pPart part, pTag tag, void** data, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }

  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  switch (tag_type) 
  {
    case 0: {
              int sz_tag_data = part->getSizeAttachedOpaque(tag);
              char* char_data = (char*)(calloc(sz_tag_data, sizeof(char)));
              part->getAttachedOpaque(tag, char_data);
              memcpy(*data, char_data, sizeof(char_data));
              *data_size = sz_tag_data * sizeof(char);
              delete[] char_data;
            }
            break;
    case 1: { 
              if (tag_size==1)  // int
              {
                int int_data = part->getAttachedInt(tag);
                memcpy(*data, &int_data, sizeof(int));
                *data_size = sizeof(int);
              } 
              else // int array
              {
                int* int_arr = new int[tag_size];
                int int_size;
                part->getAttachedIntArr(tag, &int_arr, &int_size);
                memcpy(*data, int_arr, sizeof(int)*int_size);
                *data_size = sizeof(int)*int_size;
                delete [] int_arr;
              }
            }
            break;           
    case 2: { // double
              if (tag_size==1)
              {
                double double_data = part->getAttachedDouble(tag);
                memcpy(*data, &double_data, sizeof(double_data));	
                *data_size = sizeof(double);
              }
              else // double array
              {
                double* dbl_arr = new double[tag_size];
                int dbl_size;
                part->getAttachedDblArr(tag, &dbl_arr, &dbl_size);
                memcpy(*data, dbl_arr, sizeof(double)*dbl_size);
                *data_size = sizeof(double)*dbl_size;
                delete [] dbl_arr;
              }
            }
            break;
    case 3: { // entity
              if (tag_size==1)
              {
                pMeshEnt ent_data = (pMeshEnt)(part->getAttachedPnt(tag));
                if(!ent_data) return SCUtil_FAILURE;
                memcpy(*data, &ent_data, sizeof(void*));
                *data_size = sizeof(void*);
              }
              else // entity array
              {
                pMeshEnt* ent_arr = new pMeshEnt[tag_size];
                int ent_size;
                part->getAttachedPntArr(tag, (void***)(&ent_arr), &ent_size);
                memcpy(*data, ent_arr, sizeof(void*)*ent_size);
                *data_size = sizeof(void*)*ent_size;
                delete [] ent_arr;
              }
	    }
            break;
    case 4: { // entity set
              if (tag_size==1)
              {
                pEntSet set_data = (pEntSet)(part->getAttachedPnt(tag));
                if(!set_data) return SCUtil_FAILURE;
                memcpy(*data, &set_data, sizeof(void*));
                *data_size = sizeof(void*);
              }
              else // entity set array
              {
                pEntSet* set_arr = new pEntSet[tag_size];
                int set_size;
                part->getAttachedPntArr(tag, (void***)(&set_arr), &set_size);
                memcpy(*data, set_arr, sizeof(void*)*set_size);
                *data_size = sizeof(void*)*set_size;
                delete [] set_arr;
              }
	    }
            break;
    default: break;
  }  // switch
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetIntTag (pPart part, pTag tag, int data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=1 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }

  part->attachInt (tag, data);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetIntTag (pPart part, pTag tag, int* data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=1 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }
  if (part->getAttachedInt(tag, data)==0)
    return SCUtil_FAILURE;
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetDblTag (pPart part, pTag tag, double data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=2 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->attachDouble (tag, data);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetDblTag (pPart part, pTag tag, double* data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=2 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  if (part->getAttachedDouble(tag, data)==0)
    return SCUtil_FAILURE;
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetEntTag (pPart part, pTag tag, pMeshEnt data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=3 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->attachPnt (tag, (void*)data);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetEntTag (pPart part, pTag tag, pMeshEnt *data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=3 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  *data = (pMeshEnt)(part->getAttachedPnt(tag));
  if (*data) return SCUtil_SUCCESS;
  return SCUtil_FAILURE;
}

int FMDB_Part_SetSetTag (pPart part, pTag tag, pEntSet data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=4 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  } 

  part->attachPnt (tag, (void*)data);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetSetTag (pPart part, pTag tag, pEntSet *data)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=4 || tag_size!=1)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }
  *data = (pEntSet)(part->getAttachedPnt(tag));
 return SCUtil_SUCCESS;
}

// array tag
int FMDB_Part_SetIntArrTag (pPart part, pTag tag, int* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=1 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->attachIntArr (tag, data_arr, data_size);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetIntArrTag (pPart part, pTag tag, int** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=1)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return SCUtil_FAILURE;
  }  
  part->getAttachedIntArr (tag, data_arr, data_size);
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetDblArrTag (pPart part, pTag tag, double* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=2 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->attachDblArr (tag, data_arr, data_size);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetDblArrTag (pPart part, pTag tag, double** data_arr, int* data_size)
{
   int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=2)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->getAttachedDblArr (tag, data_arr, data_size);  
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetEntArrTag (pPart part, pTag tag, pMeshEnt* data_arr, int data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=3 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  

  part->attachPntArr (tag, (void**)data_arr, data_size);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetEntArrTag (pPart part, pTag tag, pMeshEnt** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=3)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return SCUtil_FAILURE;
  } 

  part->getAttachedPntArr (tag, (void***)data_arr, data_size);  
  return SCUtil_SUCCESS;
}

int FMDB_Part_SetSetArrTag (pPart part, pTag tag, pEntSet* data_arr, int data_size)
{
   int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_size, tag_type = 0;   
  FMDB_Tag_GetSize (part->getMesh(), tag, &tag_size);
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=4 || tag_size!=data_size)
  {
    cout<<__func__<<" failed: tag type/size mismatch\n";
    return SCUtil_FAILURE;
  }  
  part->attachPntArr (tag, (void**)data_arr, data_size);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetSetArrTag (pPart part, pTag tag, pEntSet** data_arr, int* data_size)
{
  int exist=0;
  FMDB_Tag_Exist (part->getMesh(), tag, &exist);
  if (!exist)
  {
    cout<<__func__<<" failed: tag doesn't exist\n";
    return SCUtil_FAILURE;
  }
  int tag_type = 0;   
  FMDB_Tag_GetType (part->getMesh(), tag, &tag_type);

  if (tag_type!=4)
  {
    cout<<__func__<<" failed: tag type mismatch\n";
    return SCUtil_FAILURE;
  } 

  
  part->getAttachedPntArr (tag, (void***)data_arr, data_size);
  return SCUtil_SUCCESS;
}
