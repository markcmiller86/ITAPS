/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"
#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "FMDB_Internals.h"
#include "iUtil.h"
#include "mMeshIO.h"
#ifdef FMDB_PARALLEL
#include "mMigration.h"
#include "mPartition.h"
#endif
#include <assert.h>
#include <list>
#include <string.h>
#include "FMDB_cint.h"

/**********************************************
      DISRIBUTED MESH MANAGEMENT FUNCTIONS
***********************************************/

int FMDB_Mesh_LocalPtn(pMeshMdl mesh, pmMigrationCallbacks& migrCB)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_NOT_SUPPORTED;
}

int FMDB_Mesh_GlobPtn(pMeshMdl mesh, pmMigrationCallbacks& migrCB)
{
#ifdef FMDB_PARALLEL
  if (ParUtil::Instance()->size()==1) return 0;
  vector<pPart> parts;
  FMDB_Mesh_GetProcPart (mesh, ParUtil::Instance()->rank(), parts);
  _partitionMesh(parts, migrCB, 1);
#endif
  return SCUtil_SUCCESS;
}

// *****************************************
int FMDB_Mesh_Migr (pMeshMdl mesh, pmMigrationCallbacks& cb,
                    map<mEntity*,int>* POtoMove)
// *****************************************
{
#ifndef FMDB_PARALLEL
    return SCUtil_SUCCESS;
#else
  if (mesh->getNumPart()>1)
  {
    cout<<__func__<<" with multiple parts not implemented yet\n";
    return 1;
  }
  int procID;
  FMDB_GetProcID (&procID);
  
  std::vector<pPart> parts;
  FMDB_Mesh_GetProcPart (mesh, procID, parts);

  std::list<mEntity*> rmE[4]; 
  std::list<mEntity*> newE[4]; 
  std::vector<mEntityGroup*> rmEG;
  std::vector<mEntityGroup*> newEG; 

   map<mEntity*, int*> pos;
   map<mEntity*, int>::iterator iter;
   for(iter=POtoMove[0].begin(); iter!=POtoMove[0].end(); iter++) {
      int* pids=new int[3];
      pids[0]=0;
      pids[1]=iter->second;
      pids[2]=iter->second;
      pos[iter->first]=pids;
   }

   map<mEntityGroup*,int*> EntGrpToMove;  

   int err = _migrateMesh(parts, pos, EntGrpToMove, cb, rmE, newE, rmEG, newEG);

// CHECK! do we delete int* pid?

  return err;
#endif
}

int FMDB_Mesh_MigrAdv (pMeshMdl mesh, pmMigrationCallbacks& migrCB,
         map<mEntity*,int>* POtoMove, 
         std::vector<pMeshEnt>* newEnt, std::vector<pMeshEnt>* rmvEnt,
         std::vector<pEntityGroup>& newEntSet, std::vector<pEntityGroup>& rmvEntSet)
{
/*#ifdef FMDB_PARALLEL
  if (ParUtil::Instance()->size()==1) return 0;

  // temporary -- should be fixed
  std::list<pMeshEnt> ents;
  std::list<pMeshEnt> rmE[4];
  std::list<pMeshEnt> newE[4];
  std::copy (entList.begin(), entList.end(),  std::back_inserter(ents));
  // do migration
  int ret=pmPartMigration(part, dimToMove,ents,cb,rmE,newE, rmEntSet, newEntSet);
#endif
*/
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_NOT_SUPPORTED;
}

int FMDB_Part_MigrAll (pPart part, pmMigrationCallbacks& migrCB, int destPid)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_NOT_SUPPORTED;
}

int FMDB_Mesh_CreateGhost (pMeshMdl mesh, pmMigrationCallbacks& migrCB, int ghostType, int brgType, int numLayer, int includeCopy)
{
 #ifdef FMDB_PARALLEL
   createGhost(mesh, migrCB, ghostType, brgType, numLayer, includeCopy);
 #endif
   return SCUtil_SUCCESS; //_Err::SUCCESS;
}

int FMDB_Mesh_DelGhost (pMeshMdl mesh)
{
  #ifdef FMDB_PARALLEL
  deleteGhostEntities(mesh);
  #endif
  return SCUtil_SUCCESS;
}

