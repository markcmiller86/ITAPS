/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"
#include "oldFMDB.h"
#include "FMDB_Iterator.h"
#include "FMDB_Internals.h"
#include "iUtil.h"
#include "mMeshIO.h"
#include <assert.h>
#include <list>
#include <string.h>
#include "FMDB_cint.h"

/***************************************
      MESH/PART MANAGEMENT FUNCTIONS
****************************************/

int FMDB_Part_Create (pMeshMdl mesh, pPart& part)
{
  // part id shall be handled properly
  part = new mPart(mesh->partID++, mesh->getGeomModel(), mesh);
  mesh->addPart(part);
  return SCUtil_SUCCESS;
}

int FMDB_Part_Del (pMeshMdl mesh, pPart& part)
{
  if (mesh->getNumPart()==1)
    return SCUtil_FAILURE;
  mesh->delPart(part);
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetID (pPart part, int* partID)
{
  * partID = part->getId();
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetHandle (int partID, pPart& part)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

/* Given a part handle, get the dimension of the part. */
int FMDB_Part_GetDim (
        pPart /* in */ part,
        int* /* out */ dim)
{
  *dim = ((part->size(3))? 3 : ((part->size(2)) ? 2 : 1 ));
  return SCUtil_SUCCESS;
}

/* Part_Set deals with PO entity set */
int FMDB_Part_GetNumSet (pPart part, int* numEntSet)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

int FMDB_Part_GetSet (pPart part, std::vector<pEntSet> &entsets)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

// unique ent set ID gets invalid once new entity set is added (e.g. migration, modification)
int FMDB_Part_SetSetID (pPart part)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

int FMDB_Part_DelSetID (pPart part)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE;
}

// given entity type, set unique ent id
// unique ent ID gets invalid once the mesh is modified (e.g. migration, modification)
int FMDB_Part_SetEntID (pPart part, int type)
{
  int i=1;
  switch (type)
  {
    case 0: for (mPart::iterall it=part->beginall(type); it!=part->endall(type);++it)
              (*it)->setId(i++);
            break;
    case 1:
    case 2:
    case 3: for (mPart::iterall it=part->beginall(type); it!=part->endall(type);++it)
              (*it)->attachInt(FMDB_Util::Instance()->getId(),i++);
            break;
    case 4: for (int type=0; type<4; ++type)
              FMDB_Part_SetEntID (part, type);
            break;
    default: return SCUtil_FAILURE;  // invalid type
  }
  return SCUtil_SUCCESS;
}

int FMDB_Part_DelEntID (pPart part, int type)
{
  switch (type)
  {
    case 0: break;
    case 1:
    case 2:
    case 3: for (mPart::iterall it=part->beginall(type); it!=part->endall(type);++it)
              (*it)->deleteData(FMDB_Util::Instance()->getId());
            break;
    case 4: for (int type=1; type<4; ++type)
              FMDB_Part_DelEntID (part, type);
            break;
    default: return SCUtil_FAILURE;  // invalid type
  }
  return SCUtil_SUCCESS;
}

int FMDB_PartEntIter_InitPartBdry(pPart part, int destPart, int type, int topo, pPartEntIter& iter, pMeshEnt& ent)
{
  ptr_int_struct* mesh_pid = new ptr_int_struct; 
  mesh_pid->mesh = part; 
  mesh_pid->pid =destPart; 

   if(type >= 4)
   {
     int dim = part->getDimension();
     iter = new mPartIterator(part->beginall(0), part->endall(part->getDimension()), 4, topo,
                             (void*)mesh_pid, &processingPartBdryEntFilter);
   }
   else 
     iter = new mPartIterator(part->beginall(type), part->endall(type), type, topo, 
                             (void*)mesh_pid, &processingPartBdryEntFilter);
  
  if(iter->end())
    return SCUtil_FAILURE;
  ent = **iter;	
  return SCUtil_SUCCESS; 
} 
/* 
Get part boundary entities of a part with a specified type
*/
int FMDB_Part_GetNumPartBdry (pPart part, int target_part, int type, int topo, int* numEnt)
{
  pPartEntIter iter;
  pMeshEnt ent;

  FMDB_PartEntIter_InitPartBdry (part, target_part, type, topo, iter, ent);  

  int num = 0;
  for(; !iter->end(); ++(*iter))
    ++num;

   delete iter;
   *numEnt = num;

  return SCUtil_SUCCESS;
}

/* Given a part and an entity type (0 to 3), get a pointer to the ﬁrst mesh entity of the type.If no entity exists or type is invalid, null is gotton for Iter.
*/
int FMDB_PartEntIter_Init (
        pPart part, int type, int topo, pPartEntIter& iter, pMeshEnt& /* out */ ent)
{
  if(type >= 4)
   {
   int dim = part->getDimension();
   iter = new mPartIterator(part->beginall(0), part->endall(dim), 4, topo,(void*)part, &processingMeshFilter);
   }
  else
   iter = new mPartIterator(part->beginall(type), part->endall(type), type, topo,(void*)part, &processingMeshFilter);

   if(iter->end())
    return SCUtil_FAILURE;
   ent = **iter; 
   return SCUtil_SUCCESS;
}

/* Given a part handle and an integer specifying the entity type (0 to 3), get the total number
of entities of type in the part. If includeGhost is 0, ghost copies are excluded, otherwise ghost
copies are included. If type is 0, get the number of vertices in the part, if type is 1, get the number
of edges in the part, if type is 2, get the number of faces in the part, if type is 3, get the number of
regions in the part.
*/

int FMDB_Part_GetNumEnt(pPart part, int type, int topo, int* /* out */ numEnt)
{
  pPartEntIter iter;
  pMeshEnt ent;
  FMDB_PartEntIter_Init (part, type, topo, iter, ent);  

  int num = 0;
  for(; !iter->end(); ++(*iter))
    ++num;

   delete iter;
   *numEnt = num;
  return SCUtil_SUCCESS;
}

int FMDB_Part_GetNumGhost (
        pPart /* in */ part, 
        int /* in */ type,
        int* /* out */ numEnt)
{
  cout<<__func__<<" not implemented yet\n";
  return SCUtil_FAILURE; 
}

/* 
Given a part and a geometric entity, get a pointer to the first equal order mesh entity
classified on the geometric model entity. If no mesh entity exists, null is gotton for Iter.
*/
int FMDB_PartEntIter_InitRevClas (
	pPart /* in */ part,
	pGeomEnt /* in */ geomEnt,
        int /* in */  type,
	pPartEntIter& /* out */ iter,
        pMeshEnt& ent)
{
   iter = new mPartIterator(part->beginall(type), part->endall(type), type, 
                            0,(void*)geomEnt, &processingGeomFilter);  
   if(iter->end())
    return SCUtil_FAILURE;
   ent = **iter;
   return SCUtil_SUCCESS;
}

/* get
Get next element of the mesh iterator
*/
int FMDB_PartEntIter_GetNext(pPartEntIter iter, pMeshEnt& ent)
{
   iter->next();
   if(iter->end())
     return SCUtil_FAILURE;
   else
     ent = **iter;
   return SCUtil_SUCCESS;

}
/* Check if the iterator has reached its end */
int FMDB_PartEntIter_IsEnd(pPartEntIter iter, int * isEnd)
{
  if(iter->end())
     *isEnd = 1;
  else
    *isEnd = 0;
  return SCUtil_SUCCESS;
}                                                                                                                 
int FMDB_PartEntIter_Del (pPartEntIter iter)
{
  delete iter;
  return SCUtil_SUCCESS;
}

int FMDB_PartEntIter_Reset (pPartEntIter iter, pMeshEnt& ent)
{
  iter->reset();
  if (iter->end())
    return SCUtil_FAILURE;
  ent = **iter;
  return SCUtil_SUCCESS;
}

