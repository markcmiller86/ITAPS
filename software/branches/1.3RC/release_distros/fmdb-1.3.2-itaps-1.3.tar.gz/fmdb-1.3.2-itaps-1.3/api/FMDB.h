/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _FMDB_H_
#define _FMDB_H_

#include "GUM.h"
#include "GMI.h" 
#include "mAttachableDataContainer.h"
#include "pmZoltanCallbacks.h"
#include "pmMigrateUtil.h"
#include "pmUtility.h"
#include "pmModel.h"
#include "mFMDB.h"
#include "mPart.h"
#include "mEntity.h"
#include "mException.h"
#include "mVertex.h"
#include "ParUtil.h"
#include "FMDBInternals.h"
#include "pmMigrationCallbacks.h"
#include "FMDB_cint.h" 
#include "modeler.h"
#include "FMDBfwd.h"
#include "mEntityContainer.h"
#include "iUtil.h"

#ifdef __cplusplus
extern "C" {

  typedef class mMesh *  pMeshMdl;
  typedef class mPart  * pPart;  

  typedef EntitySet<mEntity>* pEntSet;

  typedef pGEntity pGeomEnt;

  typedef class mEntity * pMeshEnt;
  typedef class mEntity * pMeshRgn;
  typedef class mEntity * pMeshFace;
  typedef class mEntity * pMeshEdge;
  typedef class mEntity * pMeshVtx;
  typedef class mEntity * pNode;

  typedef unsigned int pTag;

  typedef std::pair<int, pMeshEnt> pairRemote;
  typedef class migrationCB MigrCB;
  struct entSetIter
   {
     short int isList;
     void* iter;
   };

  // typedef for iterator; 
  // pMeshSetIter needed
  typedef std::vector<pEntityGroup>::iterator  pPartSetIter;
  typedef GenIterator<mPartEntityContainer::iter, mEntity> *pPartEntIter;
  typedef entSetIter* pSetEntIter;

#else   /* not __cplusplus */

#endif /* not __cplusplus */

#ifndef FMDB_PARALLEL
typedef void* MPI_Comm;
#endif

#define MAX_STRING_LENGTH 2048

  typedef enum FMDB_TagType { FMDB_BYTE=0,       /*1*/ FMDB_INT,     /*2*/ FMDB_DBL, 
                              /*3*/ FMDB_ENT,    /*4*/ FMDB_SET};
  
  typedef enum FMDB_EntType { FMDB_VERTEX=0,     /*1*/ FMDB_EDGE,    /*2*/ FMDB_FACE,
                              /*3*/ FMDB_REGION, /*4*/ FMDB_ALLTYPE};

  typedef enum FMDB_EntTopo { FMDB_POINT=0,     /*1*/ FMDB_LINE,    /*2*/ FMDB_POLYGON, 
                              /*3*/ FMDB_TRI,   /*4*/ FMDB_QUAD,    /*5*/ FMDB_POLYHEDRON,
                              /*6*/ FMDB_TET,   /*7*/ FMDB_HEX,     /*8*/ FMDB_PRISM, 
                              /*9*/ FMDB_PYRAMID, /*10*/FMDB_SEPTA, /*11*/FMDB_ALLTOPO};

  typedef enum FMDB_EntStatus { FMDB_INTER=0, /*1*/ FMDB_BDRY,  /*2*/ FMDB_GHOST};

//************************************
//************************************
//      1- SYSTEM-LEVEL FUNCTIONS
//************************************
//************************************

int FMDB_Init(MPI_Comm comm);
int FMDB_SetComm (MPI_Comm comm);
int FMDB_GetComm (MPI_Comm *comm);
int FMDB_Finalize(void);

int FMDB_GetNumProc(int* numProc);
int FMDB_GetProcID (int* procID);

int FMDB_Sync(void);
int FMDB_GetWTime(double* wTime);

//************************************
//************************************
//      2- TAG FUNCTIONS
//************************************
//************************************

int FMDB_Tag_Create (pMeshMdl mesh, const char* tagName, int tagType, int tagSize, int traceable, pTag* tag);
int FMDB_Tag_Del (pMeshMdl mesh, pTag* tag, int forceDel);

int FMDB_Tag_GetType (pMeshMdl mesh, pTag tag, int* type);
int FMDB_Tag_GetName (pMeshMdl mesh, pTag tag, char* tag_name);
int FMDB_Tag_GetSize (pMeshMdl mesh, pTag tag, int* size);
int FMDB_Tag_GetByte (pMeshMdl mesh, pTag tag, int* byte);
int FMDB_Tag_GetHandle (pMeshMdl mesh, const char* tagName, pTag *tag);

int FMDB_Tag_Exist (pMeshMdl mesh, pTag tag, int *exist);
int FMDB_Tag_GetAllID (pMeshMdl mesh, std::vector<pTag>& tags);

//************************************
//************************************
//      3- MESH-PART FUNCTIONS
//************************************
//************************************

//************************************
//  3.1 Mesh/Part Management 
//************************************

int FMDB_Mesh_Create(pGeomMdl geom, pMeshMdl& mesh);
int FMDB_Mesh_Del(pMeshMdl& mesh);

int FMDB_Mesh_LoadFromFile (pMeshMdl mesh, const char* fileName, int distributed);
int FMDB_Mesh_WriteToFile (pMeshMdl mesh, const char* fileName, int distributed);

int FMDB_Part_Create (pMeshMdl mesh, pPart& part);
int FMDB_Part_Del (pMeshMdl mesh, pPart& part);

//************************************
//  3.2 Mesh/Part Information 
//************************************

int FMDB_Mesh_GetLastError (pMeshMdl mesh, int *error_type);
int FMDB_Mesh_IsEmpty (pMeshMdl mesh, int* empty);
int FMDB_Mesh_GetGeomMdl (pMeshMdl mesh, pGeomMdl& geom);
int FMDB_Mesh_GetDim (pMeshMdl mesh, int* dim);

int FMDB_Mesh_GetNumPart (pMeshMdl mesh, int procId, int* numPart);
int FMDB_Mesh_GetProcPart (pMeshMdl mesh, int procId, std::vector<pPart>& vecPart);
int FMDB_Mesh_GetPart (pMeshMdl mesh, int partId, pPart& part);
int FMDB_Mesh_GetProcPartID (pMeshMdl  mesh, int procId, std::vector<int>& vecPartID); 

int FMDB_Mesh_GetNumSet (pMeshMdl  mesh,  int* numEntSet);
int FMDB_Mesh_GetSet (pMeshMdl  mesh, std::vector<pEntSet>& vecEntset);


int FMDB_Part_GetID (pPart part, int* partID);
int FMDB_Part_GetHandle (int partID, pPart& part);
int FMDB_Part_GetDim (pPart part, int* dim);

int FMDB_Part_GetNumSet (pPart part, int* numEntSet);
int FMDB_Part_GetSet (pPart part, std::vector<pEntSet>& vecEntset);

int FMDB_Part_GetNumEnt (pPart part, int type, int topo, int* numEnt);
int FMDB_Part_GetNumPartBdry (pPart part, int destPart, int type, int topo, int* numEnt);
int FMDB_Part_GetNumGhost (pPart part, int type, int* numEnt);

//************************************
//  3.3 Mesh/Part Traversal
//************************************

int FMDB_PartEntIter_Init (pPart part, int type, int topo, pPartEntIter& iter, pMeshEnt& meshEnt);
int FMDB_PartEntIter_InitRevClas (pPart part, pGeomEnt geomEnt, int type, pPartEntIter& iter, pMeshEnt& meshEnt);
int FMDB_PartEntIter_InitPartBdry (pPart part, int destPart, int type, int topo, pPartEntIter& iter, pMeshEnt& meshEnt);

int FMDB_PartEntIter_GetNext(pPartEntIter iter, pMeshEnt& meshEnt);
int FMDB_PartEntIter_Del(pPartEntIter iter);
int FMDB_PartEntIter_IsEnd(pPartEntIter iter, int *isEnd);
int FMDB_PartEntIter_Reset(pPartEntIter iter, pMeshEnt& meshEnt);

//************************************
//  3.4 ID Management
//************************************
int FMDB_Mesh_SetSetID (pMeshMdl  mesh);
int FMDB_Mesh_DelSetID (pMeshMdl  mesh);

int FMDB_Part_SetEntID (pPart part, int type);
int FMDB_Part_DelEntID (pPart part, int type);
int FMDB_Part_SetSetID (pPart part);
int FMDB_Part_DelSetID (pPart part);

// ************************************
//  3.5 Part Tag 
//************************************

int FMDB_Part_DelTag (pPart part, pTag tag);
int FMDB_Part_HasTag (pPart part, pTag tag, int* hasTag);

int FMDB_Part_SetByteTag (pPart part, pTag tag, const void* tagVal, int tagByte);
int FMDB_Part_GetByteTag (pPart part, pTag tag, void** tagVal, int* tagByte);
int FMDB_Part_SetIntTag (pPart part, pTag tag, int tagVal);
int FMDB_Part_GetIntTag (pPart part, pTag tag, int* tagVal);
int FMDB_Part_SetDblTag (pPart part, pTag tag, double tagVal);
int FMDB_Part_GetDblTag (pPart part, pTag tag, double* tagVal);
int FMDB_Part_SetEntTag (pPart part, pTag tag, pMeshEnt tagVal);
int FMDB_Part_GetEntTag (pPart part, pTag tag, pMeshEnt* tagVal);
int FMDB_Part_SetSetTag (pPart part, pTag tag, pEntSet tagVal);
int FMDB_Part_GetSetTag (pPart part, pTag tag, pEntSet* tagVal);

int FMDB_Part_SetIntArrTag (pPart part, pTag tag, int* data_arr, int data_size);
int FMDB_Part_GetIntArrTag (pPart part, pTag tag, int** data_arr, int* data_size);
int FMDB_Part_SetDblArrTag (pPart part, pTag tag, double* data_arr, int data_size);
int FMDB_Part_GetDblArrTag (pPart part, pTag tag, double** data_arr, int* data_size);
int FMDB_Part_SetEntArrTag (pPart part, pTag tag, pMeshEnt* data_arr, int data_size);
int FMDB_Part_GetEntArrTag (pPart part, pTag tag, pMeshEnt** data_arr, int* data_size);
int FMDB_Part_SetSetArrTag (pPart part, pTag tag, pEntSet* data_arr, int data_size);
int FMDB_Part_GetSetArrTag (pPart part, pTag tag, pEntSet** data_arr, int* data_size);

//************************************
//  3.6 Distributed Mesh Functions
//************************************
// load balancing
int FMDB_Mesh_LocalPtn(pMeshMdl mesh, pmMigrationCallbacks& migrCB);
int FMDB_Mesh_GlobPtn(pMeshMdl mesh, pmMigrationCallbacks& migrCB);

// migration
int FMDB_Mesh_Migr (pMeshMdl mesh, pmMigrationCallbacks& migrCB,
                    map<mEntity*,int>* POtoMove);

int FMDB_Mesh_MigrAdv (pMeshMdl mesh, pmMigrationCallbacks& migrCB,
         map<mEntity*,int>* POtoMove, 
         std::vector<pMeshEnt>* newEnt, std::vector<pMeshEnt>* rmvEnt,
         std::vector<pEntityGroup>& newEntSet, std::vector<pEntityGroup>& rmvEntSet);

int FMDB_Part_Migr (pPart part, pmMigrationCallbacks& migrCB, int destPid);

// ghosting
int FMDB_Mesh_CreateGhost (pMeshMdl mesh, pmMigrationCallbacks& migrCB, 
                           int ghostType, int brgType, 
                           int numLayer, int includeCopy);

int FMDB_Mesh_DelGhost (pMeshMdl mesh);

//************************************
//  3.7 Misc
//************************************

int FMDB_Mesh_Verify (pMeshMdl mesh, int* isValid);
int FMDB_Mesh_DspNumEnt (pMeshMdl mesh);
int FMDB_Mesh_DspAllEnt (pMeshMdl mesh);

// ************************************
// ************************************
//      4- ENTITY FUNCTIONS      
// ************************************
// ************************************

//************************************
// 4.1 Entity Management
//************************************
/** create a mesh vertex, edge, face and region */
int FMDB_Vtx_Create (pPart part, pGeomEnt geomEnt, double* xyz,
                     double* param, pMeshEnt& meshVtx);
int FMDB_Edge_Create (pPart part, pGeomEnt geomEnt, pMeshEnt meshVtx1, pMeshEnt meshVtx2, pMeshEnt& meshEdge);
int FMDB_Face_Create (pPart part, pGeomEnt geomEnt, int topo, pMeshEnt* downEnt, int* dirs, pMeshFace& meshFace);

int FMDB_Rgn_Create (pPart part, pGeomEnt geomEnt, int topo, int numDownEnt,
                     pMeshEnt* downEnt, pMeshEnt& meshRgn);

int FMDB_Ent_Del (pPart part, pMeshEnt meshEnt);

int FMDB_Ent_Find(pPart part, int entType, pMeshEnt* downEnt, int numDownEnts, pMeshEnt& meshEnt);
//************************************
// 4.2 Entity Information
//************************************

int FMDB_Ent_GetID (pMeshEnt meshEnt);
std::string FMDB_Ent_GetStrID(pMeshEnt meshEnt);

int FMDB_Ent_GetType(pMeshEnt meshEnt, int* type);
int FMDB_Ent_GetTopo(pMeshEnt meshEnt, int* topo);

int FMDB_Ent_SetGeomClas (pMeshEnt meshEnt, pGeomEnt geomEnt);
int FMDB_Ent_GetGeomClas (pMeshEnt meshEnt, pGeomEnt& geomEnt);
int FMDB_Ent_GetGeomClasType (pMeshEnt meshEnt, int* geomType);
int FMDB_GeomEnt_GetNumRevClas (pGeomEnt geomEnt, pPart part, int* numEnt);

int FMDB_Ent_GetNumAdj (pMeshEnt meshEnt, int tgtType, int* numAdj);
int FMDB_Ent_GetAdj(pMeshEnt meshEnt, int tgtType, int dir, std::vector<pMeshEnt>& vecAdj);
int FMDB_Ent_Get2ndAdj (pMeshEnt meshEnt, int brgType, int tgtType, std::vector<pMeshEnt>& vecAdj);

//************************************
// 4.3 Vertex Functions
//************************************

int FMDB_Vtx_SetCoord (pMeshEnt meshVtx, double* xyz);

int FMDB_Vtx_GetCoord (pMeshEnt meshVtx, double** xyz);

int FMDB_Vtx_SetParamCoord (pMeshVtx meshVtx, double* xyz);

int FMDB_Vtx_GetParamCoord1D(pMeshVtx p, double* param);

int FMDB_Vtx_GetParamCoord2D(pMeshVtx p, double* param1, double* param2);

//************************************
// 4.4 Edge Functions 
//************************************

int FMDB_Edge_SetNode (pMeshEnt meshEdge, pNode node);

int FMDB_Edge_GetNode (pMeshEnt meshEdge, int* numNode);

int FMDB_Edge_GetNumNode (pMeshEnt meshEdge, int n, pNode& node);


//************************************
// 4.5 Face Functions
//************************************


//************************************
// 4.6 Region Functions
//************************************


//************************************
// 4.7 Entity Tag
//************************************

int FMDB_Ent_DelTag (pMeshEnt meshEnt, pTag tag);
int FMDB_Ent_HasTag (pMeshEnt meshEnt, pTag tag, int* hasTag);

int FMDB_Ent_SetByteTag (pMeshMdl mesh, pMeshEnt, pTag, const void*, int);
int FMDB_Ent_GetByteTag (pMeshMdl mesh, pMeshEnt, pTag, void**, int*);
int FMDB_Ent_SetIntTag (pMeshMdl mesh, pMeshEnt, pTag, int);
int FMDB_Ent_GetIntTag (pMeshMdl mesh, pMeshEnt, pTag, int*);
int FMDB_Ent_SetDblTag (pMeshMdl mesh, pMeshEnt, pTag, double);
int FMDB_Ent_GetDblTag (pMeshMdl mesh, pMeshEnt, pTag, double*);
int FMDB_Ent_SetEntTag (pMeshMdl mesh, pMeshEnt, pTag, pMeshEnt);
int FMDB_Ent_GetEntTag (pMeshMdl mesh, pMeshEnt, pTag, pMeshEnt*);
int FMDB_Ent_SetSetTag (pMeshMdl mesh, pMeshEnt, pTag, pEntSet);
int FMDB_Ent_GetSetTag (pMeshMdl mesh, pMeshEnt, pTag, pEntSet*);

int FMDB_Ent_SetIntArrTag (pMeshMdl mesh, pMeshEnt, pTag, int* data_arr, int data_size);
int FMDB_Ent_GetIntArrTag (pMeshMdl mesh, pMeshEnt, pTag, int** data_arr, int* data_size);
int FMDB_Ent_SetDblArrTag (pMeshMdl mesh, pMeshEnt, pTag, double* data_arr, int data_size);
int FMDB_Ent_GetDblArrTag (pMeshMdl mesh, pMeshEnt, pTag, double** data_arr, int* data_size);
int FMDB_Ent_SetEntArrTag (pMeshMdl mesh, pMeshEnt, pTag, pMeshEnt* data_arr, int data_size);
int FMDB_Ent_GetEntArrTag (pMeshMdl mesh, pMeshEnt, pTag, pMeshEnt** data_arr, int* data_size);
int FMDB_Ent_SetSetArrTag (pMeshMdl mesh, pMeshEnt, pTag, pEntSet* data_arr, int data_size);
int FMDB_Ent_GetSetArrTag (pMeshMdl mesh, pMeshEnt, pTag, pEntSet** data_arr, int* data_size);

//************************************
// 4.8 Entity @ Distributed Mesh 
//************************************

int FMDB_Ent_GetOwnPartID(pMeshEnt meshEnt, int* partID);
int FMDB_Ent_GetOwnEnt(pMeshEnt meshEnt, pMeshEnt& owner);

int FMDB_Ent_GetNumRmt (pMeshEnt meshEnt, int* numRmt);
int FMDB_Ent_GetRmt (pMeshEnt meshEnt, std::vector<std::pair<int, pMeshEnt> >& vecRmt);
int FMDB_Ent_GetRmtOnPart(pMeshEnt& meshEnt, int destPart, pMeshEnt& rmtEnt);
int FMDB_Ent_AddRmt(pMeshEnt meshEnt, int partID, pMeshEnt rmtEnt);
int FMDB_Ent_RmvRmt (pMeshEnt meshEnt, int partID);
int FMDB_Ent_ClrRmt (pMeshEnt meshEnt);
int FMDB_Ent_IsOnPartBdry (pMeshEnt meshEnt, int* isPrtBdry);

int FMDB_Ent_GetNumGhost (pMeshEnt meshEnt, int* numGhost);
int FMDB_Ent_GetGhost (pMeshEnt meshEnt, std::vector<std::pair<int, pMeshEnt> >& vecGhost);
int FMDB_Ent_IsGhost(pMeshEnt meshEnt, int* isGhost);
int FMDB_Ent_IsGhosted (pMeshEnt meshEnt,int* ghosted);

int FMDB_Ent_SetWgt (pMeshEnt ent, int wgt);
int FMDB_Ent_GetWgt (pMeshEnt ent, int* wgt);

//************************************
//  4.9 Misc
//************************************

int FMDB_Ent_DspInfo (pMeshEnt ent);
int FMDB_Ent_DspAllAdj (pMeshEnt ent);
int FMDB_Topo_GetType(int topo);
int FMDB_Topo_GetNumDownAdj (int topo, int downType);

// ************************************
// ************************************
//      5- ENTITY SET FUNCTIONS      
// ************************************
// ************************************

//************************************
//  5.1 Entity Set Management
//************************************

int FMDB_Set_NonPO_Create (pMeshMdl mesh, int isList, pEntSet& entSet);
int FMDB_Set_PO_Create (pPart part, pEntityGroup& entSet);
int FMDB_Set_Del (pMeshMdl mesh, pPart part, pEntSet entSet);
int FMDB_Part_Set_PO_GetNum (pPart part, int* numEntSet);

int FMDB_Part_Set_PO_Iter_Init(pPart part, pPartSetIter& iter);
int FMDB_Part_Set_PO_Iter_GetNext(pPart part, pPartSetIter& iter, pEntityGroup& entSet);
int FMDB_Part_Set_PO_Iter_IsEnd(pPart part, pPartSetIter iter, int* isEnd);

int FMDB_Set_LoadFromFile (pPart part, pEntSet entSet, char* fileName);
int FMDB_Set_WriteToFile (pPart part, pEntSet entSet, char* fileName);

int FMDB_Set_AddEnts (pEntSet entSet, vector<pMeshEnt> meshEnt);
int FMDB_Set_AddEnt (pEntSet entSet, pMeshEnt meshEnt);
int FMDB_Set_RmvEnt (pEntSet entSet, pMeshEnt meshEnt);
int FMDB_Set_Clr (pEntSet entSet);

int FMDB_Set_PO_BuildPrismStacks(pPart part); 

//************************************
//  5.2 Entity Set Information
//************************************

int FMDB_Set_GetID (pEntSet entSet);
int FMDB_Set_GetNumEnt (pEntSet entSet, int *num);
int FMDB_Set_HasEnt (pEntSet entSet, pMeshEnt meshEnt, int* has);
int FMDB_Set_IsEmpty (pEntSet entSet, int* isEmpty);
int FMDB_Set_IsList (pEntSet entSet, int* isList);
int FMDB_Set_IsPO (pEntSet entSet, int* isPO);

//************************************
//  5.3 Entity Set Traversal
//************************************

int FMDB_SetEntIter_Init (pEntSet entSet, int type, int topo, pSetEntIter& iter, pMeshEnt& meshEnt);

int FMDB_SetEntIter_GetNext(pSetEntIter& iter, pMeshEnt& meshEnt);
int FMDB_SetEntIter_IsEnd(pSetEntIter iter, int* isEnd);
int FMDB_SetEntIter_Reset(pSetEntIter iter, pMeshEnt& meshEnt);
int FMDB_SetEntIter_Del(pSetEntIter iter);

//************************************
//  5.4 Entity Set Tag
//************************************

int FMDB_Set_DelTag (pEntSet entSet, pTag tag);
int FMDB_Set_HasTag (pEntSet entSet, pTag tag, int* hasTag);

int FMDB_Set_SetByteTag (pEntSet entSet, pTag tag, const void* tagVal, int tagByte);
int FMDB_Set_GetByteTag (pEntSet entSet, pTag tag, void** tagVal, int* tagByte);
int FMDB_Set_SetIntTag (pEntSet entSet, pTag tag, int tagVal);
int FMDB_Set_GetIntTag (pEntSet entSet, pTag tag, int* tagVal);
int FMDB_Set_SetDblTag (pEntSet entSet, pTag tag, double tagVal);
int FMDB_Set_GetDblTag (pEntSet entSet, pTag tag, double* tagVal);
int FMDB_Set_SetEntTag (pEntSet entSet, pTag tag, pMeshEnt tagVal);
int FMDB_Set_GetEntTag (pEntSet entSet, pTag tag, pMeshEnt* tagVal);
int FMDB_Set_SetSetTag (pEntSet entSet, pTag tag, pEntSet tagVal);
int FMDB_Set_GetSetTag (pEntSet entSet, pTag tag, pEntSet* tagVal);

int FMDB_Set_SetIntArrTag (pEntSet entSet, pTag tag, int* data_arr, int data_size);
int FMDB_Set_GetIntArrTag (pEntSet entSet, pTag tag, int** data_arr, int* data_size);
int FMDB_Set_SetDblArrTag (pEntSet entSet, pTag tag, double* data_arr, int data_size);
int FMDB_Set_GetDblArrTag (pEntSet entSet, pTag tag, double** data_arr, int* data_size);
int FMDB_Set_SetEntArrTag (pEntSet entSet, pTag tag, pMeshEnt* data_arr, int data_size);
int FMDB_Set_GetEntArrTag (pEntSet entSet, pTag tag, pMeshEnt** data_arr, int* data_size);
int FMDB_Set_SetSetArrTag (pEntSet entSet, pTag tag, pEntSet* data_arr, int data_size);
int FMDB_Set_GetSetArrTag (pEntSet entSet, pTag tag, pEntSet** data_arr, int* data_size);

//************************************
//  5.5 Entity Set @ Distributed Mesh
//************************************

int FMDB_Set_SetWgt (pEntSet entSet, int wgt);
int FMDB_Set_GetWgt (pEntSet entSet, int* wgt);

//************************************
//  5.6 Misc
//************************************

int FMDB_Set_DspInfo (pEntSet entSet);

#ifdef __cplusplus
}
#endif

#endif /* ifndef _FMDB_H_ */


