/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "GUM.h"
#include "GMI.h"
#include "FMDB.h"
#include "ParUtil.h"

int FMDB_Init(MPI_Comm communicator)
{
  ParUtil::Instance()->init(communicator);
  return SCUtil_SUCCESS;
}

int FMDB_SetComm (MPI_Comm communicator)
{
  ParUtil::Instance()->setComm(communicator);
  return (int) 0;  //_Err::SUCCESS;
}

int FMDB_GetComm (MPI_Comm *communicator)
{
  *communicator = ParUtil::Instance()->getComm();
  return (int) 0;  //_Err::SUCCESS;
}

int FMDB_Finalize(void)
{
  ParUtil::Instance()->Finalize(1);
  return SCUtil_SUCCESS;
}

int FMDB_GetNumProc(int* numProc)
{
  *numProc =  ParUtil::Instance()->size();
  return SCUtil_SUCCESS;
}

int FMDB_GetProcID(int* procId)
{
  *procId =  ParUtil::Instance()->rank();
  return SCUtil_SUCCESS;
}

int FMDB_Sync(void)
{
  ParUtil::Instance()->Barrier(__LINE__,__FILE__); 
  return SCUtil_SUCCESS;
}


int FMDB_GetWTime(double* wtime)
{
  *wtime =  ParUtil::Instance()->wTime();
  return SCUtil_SUCCESS;
}

