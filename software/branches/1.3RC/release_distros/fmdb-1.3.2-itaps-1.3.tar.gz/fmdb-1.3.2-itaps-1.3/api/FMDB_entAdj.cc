/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "FMDB.h"
#include "mPart.h"
#include "mMesh.h"
#include "GUM.h"
#include "GMI.h"
#include "mEntity.h"
#include "mFMDB.h"
#include "FMDB_cint.h"
#include "MeshAdjTools.h"
#include <vector>
using std::vector;
using std::pair;


// get the number of adjacent entities of target type
int FMDB_Ent_GetNumAdj (pMeshEnt meshEnt, int tgtType, int* numAdj)
{
  std::vector<pMeshEnt> vecAdjEnt;
  FMDB_Ent_GetAdj(meshEnt, tgtType, 1, vecAdjEnt);
  *numAdj = vecAdjEnt.size();
  return SCUtil_SUCCESS;
}

/* Get adjacencies of the entity having a specified type.
dir specifies the order of vertices in the entity */
int FMDB_Ent_GetAdj(pMeshEnt meshEnt, int tgtType, int dir, std::vector<pMeshEnt>& vecAdjEnt)
{
  int entType;
  FMDB_Ent_GetType(meshEnt, &entType);
 
  if (entType==tgtType) return 1; // error
 
  if (tgtType==4 ) // all types
  {
    for (int i=0; i<4; ++i)
      if (i!=entType)
        FMDB_Ent_GetAdj(meshEnt, i, 1, vecAdjEnt);
    return SCUtil_SUCCESS; // success      
  } 

  if (dir<1 && entType==2 && tgtType==0) // f_vertices with negative direction
  {
    int N = meshEnt->size(0);  // num adj vertices
    for (int i=0;i<N;i++)
      vecAdjEnt.push_back(meshEnt->get(0,N-i-1));
  }
  else
   {
     if (entType==1 && tgtType==0) // e_vertices
     {
       vecAdjEnt.push_back(meshEnt->get(0,0));
       vecAdjEnt.push_back(meshEnt->get(0,1));
     }
     else
     {
       if (entType>tgtType)  // downward
         meshEnt->getAdjList(tgtType, vecAdjEnt);
       else // upward
       {
         std::set<pMeshEnt> UniqEnts;
         meshEnt->getHigherOrderUpward(tgtType, UniqEnts);
         copy(UniqEnts.begin(), UniqEnts.end(), back_inserter(vecAdjEnt));
       }
     }
   } 

  return SCUtil_SUCCESS; // success
}


int FMDB_Ent_Get2ndAdj (pMeshEnt meshEnt, int brgType, int tgtType, 
                        std::vector<pMeshEnt>& vecAdjEnt)
{
  int entType;
  FMDB_Ent_GetType(meshEnt, &entType);
  if (brgType==tgtType && brgType!=4) 
    return SCUtil_FAILURE;  // error

  // get adjacent entities of bridge type
  std::vector<pMeshEnt> brgAdjEnt;
  std::vector<pMeshEnt>::iterator iter;
  FMDB_Ent_GetAdj(meshEnt, brgType, 1, brgAdjEnt);
 
  // for brg adj entity, get tgt adj entities
  std::vector<pMeshEnt> tempAdjEnt;
  std::set<pMeshEnt> uniqAdjEnt;
  for (iter=brgAdjEnt.begin(); iter!=brgAdjEnt.end(); ++iter)
  {
    tempAdjEnt.clear();
    FMDB_Ent_GetAdj(*iter, tgtType, 1, tempAdjEnt);
    uniqAdjEnt.insert(tempAdjEnt.begin(), tempAdjEnt.end());
  }
  
  // remove original entity from vecAdjEnt;
  if (entType==tgtType || tgtType==4 /* all types */) 
    uniqAdjEnt.erase(meshEnt);

  std::copy(uniqAdjEnt.begin(), uniqAdjEnt.end(), std::back_inserter(vecAdjEnt));
  return SCUtil_SUCCESS;
}

// THE BELOW SHALL BE REVISITED

pEdge E_exists(pVertex v1, pVertex v2)
{
  pEdge edge ;
  pVertex evert[2] ;
  int nedge=0,i ;

  if (v1 == v2) return((pEdge)0);

  nedge = V_numEdges(v1) ;

  if(nedge == 0) return((pEdge)0);
 
  for(i=0;i<nedge;i++)
  {
    edge = V_edge(v1, i);
    /* check if both vertices of this edge match the given vertices */
    evert[0] = E_vertex(edge, 0);
    if(v2 == evert[0]) return(edge) ;
    evert[1] = E_vertex(edge, 1);
    if(v2 == evert[1]) return(edge) ;
  } 

  /* if here, then no valid connection found */
  return((pEdge)0);
}

pFace F_exists(eType type, pEntity e1, pEntity e2, pEntity e3, pEntity e4)
{
 pEntity ents[4] ;
 pFace face ;
 int nbr, count;
 int i;
 int j;
 pEdge edge ;
 pPList entities, faces;
 void *tmp = 0;

 ents[0] = e1;
 ents[1] = e2;
 ents[2] = e3;

 if (e4) {
   ents[3] = e4;
   count = 4;
 } else
   count = 3;

 /* if ents are vertices get the vertices of the face
 */

 if(type>Tedge)
   return((pFace)0);

 if( type == Tvertex )
 {
   faces = V_faces((pVertex) ents[0]);
   /* For each face connected to ents[0] see if the other vertices are 
      connected to the face
   */
   
   for (;face = (pFace)PList_next(faces, &tmp);) {
     entities = F_vertices(face, 1);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count){
       PList_delete(faces);/* Face is connected to all entities */
       return face;
     }
   }
 }
 else if (type == Tedge)
 {
   faces = E_faces((pEdge) ents[0]);
   /* For each face connected to ents[0] see if the other edges are 
      connected to the face
   */
   
   for (;face = (pFace)PList_next(faces, &tmp);) {
     entities = F_edges(face, 1, (pVertex) 0);
     for( i = 1; i < count; i++)
       if (!PList_inList(entities, ents[i]))
	 break;
     PList_delete(entities);
     if (i == count) {
       PList_delete(faces);/* Face is connected to all entities */
       return face;
     }
   }
 }
 PList_delete(faces);

 return (pFace)0 ;
}

double E_lengthSq(pEdge edge)
{
  pVertex v1,v2 ;
  pPoint  pt ;
  double  org[3],org2[3];

  v1 = E_vertex(edge,0) ;
  v2 = E_vertex(edge,1) ;
  V_coord(v1,org) ;
  V_coord(v2,org2) ;
  org[0] -= org2[0];
  org[1] -= org2[1];
  org[2] -= org2[2];

  return org[0]*org[0] + org[1]*org[1] + org[2]*org[2] ;
}

pVertex F_edOpVt(pFace face, pEdge edge)
{
int i , numEdges ;
pEdge edge_1 ;
pVertex vert ;

  numEdges = F_numEdges(face) ;
  for ( i = 0 ; i < numEdges ; i++ )
   {
     edge_1 = F_edge(face,i) ;
     if ( edge != edge_1 )
      {
        /* Found an edge other than the given edge */
        vert = E_vertex(edge_1,0) ;
        if ( vert != E_vertex(edge,0) &&
             vert != E_vertex(edge,1) )
          return vert ;
        else
          return E_vertex(edge_1,1) ;
      }
   }
  return NULL ;
}

pEdge F_vtOpEd(pFace face,pVertex vert)
{
  pEdge   edge ;
  int     i ;

  if ( F_numEdges(face)!=3 )
    return(0) ;
  for ( i=0 ; i<3 ; i++ ) {
    edge = F_edge(face,i);
    if ( E_vertex(edge,0)!=vert && E_vertex(edge,1)!=vert )
      return(edge) ;
  }
  return((pEdge)0) ;
}

pRegion R_fcOpRg(pRegion region, pFace face)
{

/*
 pRegion region ; Region (I)
 pFace face     ; Face (I)
 return value   ; Region on other side
*/

 pRegion region_0;

 region_0=F_region(face,0);
 if (region_0!=region) return region_0;
 else return (F_region (face, 1));
}

pVertex R_fcOpVt(pRegion region, pFace face)
{
pPList vrtLst ;
int i ;
void *temp = 0 ;
pVertex vert, verts[4] ;

  vrtLst = F_vertices(face,1) ;
  temp = 0 ;
  i = 0 ;

  /* Get the three vertices of the face */
  while ( vert = (pVertex)PList_next(vrtLst,&temp))
    verts[i++] = vert ;

  PList_delete(vrtLst) ;
  vrtLst = R_vertices(region,1) ;

  temp = 0 ;
  /* Loop over all the vertices of the region, if it is not
     any of the face vertices return it */
  while ( vert = (pVertex)PList_next(vrtLst,&temp) )
   {
     if ( vert != verts[0] && vert != verts[1] && vert != verts[2] )
      {
        PList_delete(vrtLst) ;
        return vert ; 
      }
   }
  
   PList_delete(vrtLst) ;
   return NULL ;
}



