/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _M_PARTITION_H_
#define _M_PARTITION_H_

#include <vector>

#ifdef FMDB_PARALLEL

int _partitionMesh(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb, int global);

#endif
#endif
