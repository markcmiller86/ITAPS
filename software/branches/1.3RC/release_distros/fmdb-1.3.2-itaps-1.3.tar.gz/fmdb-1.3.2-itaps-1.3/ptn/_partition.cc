/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "mMigration.h"
#include "ParUtil.h"
#include "pmModel.h"
#include "FMDB_cint.h"
#include "FMDB.h"

#ifdef FMDB_PARALLEL
#include "IPComMan.h"

// *****************************************
int _partitionMesh(std::vector<mPart*>& parts, pmMigrationCallbacks &cb, int global)
// *****************************************
{
  mPart* part = parts[0];
  // assume all part meshes have the same dimension
  int from = M_globalMaxDim(part);
  int to = from-1;
  ParUtil::Instance()->set_maxMeshDim(from);
 
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  
/**< STEP 1: get partition objects from Zoltan */
  map<mEntity*,int*> pos;       // POtoMove: entity_pointer, local_pid + tgt_glb_pid + tgt_proc_rank
  map<mEntityGroup*, int*> EntGrpToMove;
  cb.partition(parts, pos, EntGrpToMove);
/**< STEP 2: migrate entities */
  CM->set_comm_validation(IPComMan::All_Reduce);

  int numPart = (int)parts.size();
  int usrNumPart = ParUtil::Instance()->getUsrNumParts();    // usr_local_num_parts is set during partition

  // when local_num_part is increased 
  pGModel model = part->getSolidModel();
  if(numPart<usrNumPart)  {
    for(int i= numPart ; i<usrNumPart; ++i) {

      mPart* tmpPart = MS_newMesh(model);
      parts.push_back(tmpPart);
    }
  }

  std::list<mEntity*> rmE[4], newE[4];
  std::vector<mEntityGroup*> rmEG;
  std::vector<mEntityGroup*> newEG;
  int err = _migrateMesh(parts, pos, EntGrpToMove, cb, rmE, newE, rmEG, newEG);
  return err;
}
#endif
