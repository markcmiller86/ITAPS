/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include "mMesh.h"
#include <stdint.h>

void iMesh_rmvArrTag(iMesh_Instance instance,
                     /*in*/ const iBase_EntityHandle* entity_handles,
                     /*in*/ const int entity_handles_size,
                     /*in*/ const iBase_TagHandle tag_handle, int *err)
{
  *err = iBase_SUCCESS;

   pTag tag_id = (uintptr_t)tag_handle;
   // tag_id validity check
   int exist=0;
   FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &exist);
   if (!exist) {
     *err = iBase_INVALID_TAG_HANDLE;
     ((pMeshMdl)instance)->last_error=*err;
     return;
   }

  mEntity* ent;
  for (int i=0; i< entity_handles_size; ++i)
  {
    ent = (mEntity*)(entity_handles[i]);
    ent->deleteData(tag_id);
  }
}

// byte tagging with entity array
void iMesh_setArrData(iMesh_Instance instance,
                        /*in*/ const iBase_EntityHandle* entity_handles,
                        /*in*/ const int entity_handles_size,
                        /*in*/ const iBase_TagHandle tag_handle,
                        /*in*/ const void* tag_values,
                        /*in*/ const int tag_values_size,
                        /*out*/ int *err)

{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  int tag_byte_size;
  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  switch ((iBase_TagValueType)tag_type)
  {
    case iBase_BYTES: tag_byte_size = tag_size; break;
    case iBase_INTEGER: tag_byte_size = tag_size * sizeof(int); break;
    case iBase_DOUBLE: tag_byte_size = tag_size * sizeof(double); break;
    case iBase_ENTITY_HANDLE:
    case iBase_ENTITY_SET_HANDLE: tag_byte_size = tag_size * sizeof(void*); break;
    default: break;
  }
  if ( tag_values_size != entity_handles_size*tag_byte_size)  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  char* arr_data = new char[tag_byte_size];
  char* tag_char_values = (char*)tag_values;
  int tag_values_pos=0;
  for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
  {
    for (int arr_pos=0; arr_pos<tag_byte_size; ++arr_pos) 
      arr_data[arr_pos] = tag_char_values[tag_values_pos++]; 
    FMDB_Ent_SetByteTag((pMeshMdl)instance, (pMeshEnt)entity_handles[ent_pos], tag_id, arr_data, tag_byte_size);
  }
  delete [] arr_data; 
}

void iMesh_getArrData(iMesh_Instance instance,
                        /*in*/ const iBase_EntityHandle* entity_handles,
                        /*in*/ const int entity_handles_size,
                        /*in*/ const iBase_TagHandle tag_handle,
                        /*inout*/ void* tag_values,
                        /*inout*/int* tag_values_allocated,
                        /*out*/ int* tag_values_size,
                        /*out*/ int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle; 
  int tag_exist, tag_size, tag_byte_size, tag_type;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  switch ((iBase_TagValueType)tag_type)
  {
    case iBase_BYTES: tag_byte_size = tag_size; break;
    case iBase_INTEGER: tag_byte_size = tag_size * sizeof(int); break;
    case iBase_DOUBLE: tag_byte_size = tag_size * sizeof(double); break;
    case iBase_ENTITY_HANDLE:
    case iBase_ENTITY_SET_HANDLE: tag_byte_size = tag_size * sizeof(void*); break;
    default: break;
  }

  void** tag_v = reinterpret_cast<void**>(tag_values);
  if (*tag_v ==0 || *tag_values_allocated == 0) 
  {
    *tag_v = (char*)(calloc(tag_byte_size*entity_handles_size, sizeof(char)));
    if (*tag_v == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      ((pMeshMdl)instance)->last_error=*err;
      return;
    }
    *tag_values_allocated = tag_byte_size*entity_handles_size;
  }
  else if(*tag_values_allocated < tag_byte_size*entity_handles_size) 
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  *tag_values_size = tag_byte_size*entity_handles_size; 

  int tag_values_pos=0, arr_size;
  char* arr_data = (char*)calloc(tag_byte_size, sizeof(char));
  char** char_tag_values =  (char**)(tag_v);
  for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
  {
    FMDB_Ent_GetByteTag ((pMeshMdl)instance, (pMeshEnt)entity_handles[ent_pos], tag_id, (void**)(&arr_data), &arr_size);
    assert(arr_size == tag_byte_size);
    for (int arr_pos=0; arr_pos<arr_size;++arr_pos) 
      (*char_tag_values)[tag_values_pos++] = arr_data[arr_pos]; 
  }
  delete [] arr_data; 
}

// integer array tagging with entity array
void iMesh_setIntArrData(iMesh_Instance instance,
                                /*in*/ const iBase_EntityHandle* entity_handles,
                                /*in*/ const int entity_handles_size,
                                /*in*/ const iBase_TagHandle tag_handle,
                                /*in*/ const int* tag_values,
                                /*in*/ const int tag_values_size, int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle; 
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_INTEGER ) 
  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  if ( tag_values_size != entity_handles_size*tag_size) 
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  if(tag_size==1) // single integer
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
      FMDB_Ent_SetIntTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, tag_values[ent_pos]);
  else //(tag_size>1) int arr
  {
    int* data_arr = new int[tag_size];
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
    {
      for (int arr_pos=0; arr_pos<tag_size;++arr_pos)
        data_arr[arr_pos] = tag_values[ent_pos*tag_size+arr_pos];
      FMDB_Ent_SetIntArrTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, data_arr, tag_size);
    }
    delete [] data_arr;
  }
}

void iMesh_getIntArrData(iMesh_Instance instance,
                         /*in*/ const iBase_EntityHandle* entity_handles,
                         /*in*/ const int entity_handles_size,
                         /*in*/ const iBase_TagHandle tag_handle,
                         /*inout*/ int** tag_values,
                         /*inout*/ int* tag_values_allocated,
                         /*out*/ int* tag_values_size, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle; 
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist) {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_INTEGER )  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);

  if ( *tag_values ==0 || *tag_values_allocated == 0) 
  {
    *tag_values = (int*)(calloc(tag_size*entity_handles_size, sizeof(int)));
    if(*tag_values == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      ((pMeshMdl)instance)->last_error=*err;
      return;
    }
    *tag_values_allocated = tag_size*entity_handles_size;
  }
  else if(*tag_values_allocated < tag_size*entity_handles_size) {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  *tag_values_size = tag_size*entity_handles_size; 

  if(tag_size== 1)
  {
    int sing_data;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetIntTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &sing_data))   {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      (*tag_values)[ent_pos] = sing_data;
    }
  }  
  else // integer array
  {
    int* arr_data = new int[tag_size];
    int arr_size;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetIntArrTag((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &arr_data, &arr_size))   {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      for (int arr_pos=0; arr_pos<tag_size; ++arr_pos)
        (*tag_values)[ent_pos*tag_size+arr_pos] = arr_data[arr_pos]; 
    }
  } // else
}

// double array tagging with entity array
void iMesh_setDblArrData(iMesh_Instance instance,
                                /*in*/ const iBase_EntityHandle* entity_handles,
                                /*in*/ const int entity_handles_size,
                                /*in*/ const iBase_TagHandle tag_handle,
                                /*in*/ const double* tag_values,
                                /*in*/ const int tag_values_size, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)  {
    *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_DOUBLE)
  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  if ( tag_values_size != entity_handles_size*tag_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  if(tag_size==1) // single double 
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
      FMDB_Ent_SetDblTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, tag_values[ent_pos]);
  else //(tag_size>1) double array
  {
    double* data_arr = new double[tag_size];
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
    {
      for (int arr_pos=0; arr_pos<tag_size;++arr_pos)
        data_arr[arr_pos] = tag_values[ent_pos*tag_size+arr_pos];
      FMDB_Ent_SetDblArrTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, data_arr, tag_size);
    }
    delete [] data_arr;
  }
}

void iMesh_getDblArrData(iMesh_Instance instance,
                                /*in*/ const iBase_EntityHandle* entity_handles,
                                /*in*/ const int entity_handles_size,
                                /*in*/ const iBase_TagHandle tag_handle,
                                /*inout*/ double** tag_values,
                                /*inout*/ int* tag_values_allocated,
                                /*out*/ int* tag_values_size, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_DOUBLE) {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);

  if ( *tag_values ==0 || *tag_values_allocated == 0)
  {
    *tag_values = (double*)(calloc(tag_size*entity_handles_size, sizeof(double)));
    if(*tag_values == 0)
    {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      ((pMeshMdl)instance)->last_error=*err;
      return;
    }
    *tag_values_allocated = tag_size*entity_handles_size;
  }
  else if(*tag_values_allocated < tag_size*entity_handles_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  *tag_values_size = tag_size*entity_handles_size;

  if(tag_size== 1)
  {
    double sing_data;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetDblTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &sing_data))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      (*tag_values)[ent_pos] = sing_data;
    }
  }
  else // integer array
  {
    double* arr_data = new double[tag_size];
    int arr_size;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetDblArrTag((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &arr_data, &arr_size))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      for (int arr_pos=0; arr_pos<tag_size; ++arr_pos)
        (*tag_values)[ent_pos*tag_size+arr_pos] = arr_data[arr_pos];
    }
  } // else
}

// entity handle tagging with entity array
void iMesh_setEHArrData(iMesh_Instance instance,
                               /*in*/ const iBase_EntityHandle* entity_handles,
                               /*in*/ const int entity_handles_size,
                               /*in*/ const iBase_TagHandle tag_handle,
                               /*in*/ const iBase_EntityHandle* tag_values,
                               /*in*/ const int tag_values_size, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_ENTITY_HANDLE)
  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  if ( tag_values_size != entity_handles_size*tag_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  if(tag_size==1) // single entity
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
      FMDB_Ent_SetEntTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, (pMeshEnt)(tag_values[ent_pos]));
  else //(tag_size>1) entity arr
  {
    pMeshEnt* data_arr = new pMeshEnt[tag_size];
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
    {
      for (int arr_pos=0; arr_pos<tag_size;++arr_pos)
        data_arr[arr_pos] = (pMeshEnt)(tag_values[ent_pos*tag_size+arr_pos]);
      FMDB_Ent_SetEntArrTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, data_arr, tag_size);
    }
    delete [] data_arr;
  }
}

void iMesh_getEHArrData(iMesh_Instance instance,
                               /*in*/ const iBase_EntityHandle* entity_handles,
                               /*in*/ const int entity_handles_size,
                               /*in*/ const iBase_TagHandle tag_handle,
                               /*inout*/ iBase_EntityHandle** tag_values,
                               /*inout*/ int* tag_values_allocated,
                               /*out*/ int* tag_values_size, int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_ENTITY_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);

  if ( *tag_values ==0 || *tag_values_allocated == 0)
  {
    *tag_values = (iBase_EntityHandle*)(calloc(tag_size*entity_handles_size, sizeof(iBase_EntityHandle)));
    if(*tag_values == 0)
    {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      ((pMeshMdl)instance)->last_error=*err;
      return;
    }
    *tag_values_allocated = tag_size*entity_handles_size;
  }
  else if(*tag_values_allocated < tag_size*entity_handles_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  *tag_values_size = tag_size*entity_handles_size;

  if(tag_size== 1)
  {
    pMeshEnt sing_data;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetEntTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &sing_data))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      (*tag_values)[ent_pos] = (iBase_EntityHandle)sing_data;
    }
  }
  else // entity array
  {
    pMeshEnt* arr_data = new pMeshEnt[tag_size];
    int arr_size;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetEntArrTag((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &arr_data, &arr_size))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      for (int arr_pos=0; arr_pos<tag_size; ++arr_pos)
        (*tag_values)[ent_pos*tag_size+arr_pos] = (iBase_EntityHandle)(arr_data[arr_pos]);
    }
  } // else
}

void iMesh_setESHArrData(iMesh_Instance instance,
                          /*in*/ const iBase_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const iBase_TagHandle tag_handle,
                          /*in*/ const iBase_EntitySetHandle* tag_values,
                          /*in*/ const int tag_values_size,
                          /*out*/ int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_ENTITY_SET_HANDLE)
  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  if ( tag_values_size != entity_handles_size*tag_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  if(tag_size==1) // single entity set
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
      FMDB_Ent_SetSetTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, (pEntSet)(tag_values[ent_pos]));
  else //(tag_size>1) entity set array
  {
    pEntSet* data_arr = new pEntSet[tag_size];
    for (int ent_pos=0; ent_pos< entity_handles_size; ++ent_pos)
    {
      for (int arr_pos=0; arr_pos<tag_size;++arr_pos)
        data_arr[arr_pos] = (pEntSet)(tag_values[ent_pos*tag_size+arr_pos]);
      FMDB_Ent_SetSetArrTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, data_arr, tag_size);
    }
    delete [] data_arr;
  }
}

void iMesh_getESHArrData(iMesh_Instance instance,
                          /*in*/ const iBase_EntityHandle* entity_handles,
                          /*in*/ const int entity_handles_size,
                          /*in*/ const iBase_TagHandle tag_handle,
                          /*inout*/ iBase_EntitySetHandle** tag_values,
                          /*inout*/ int* tag_values_allocated,
                          /*out*/ int* tag_values_size,
                          /*out*/ int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int tag_exist, tag_type, tag_size;

  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &tag_exist);
  if (!tag_exist)
  {
     *err = iBase_INVALID_TAG_HANDLE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  if ((iBase_TagValueType)tag_type != iBase_ENTITY_SET_HANDLE) 
  {
    *err = iBase_INVALID_TAG_HANDLE ;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);

  if ( *tag_values ==0 || *tag_values_allocated == 0)
  {
    *tag_values = (iBase_EntitySetHandle*)(calloc(tag_size*entity_handles_size, sizeof(iBase_EntitySetHandle)));
    if(*tag_values == 0)
    {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      ((pMeshMdl)instance)->last_error=*err;
      return;
    }
    *tag_values_allocated = tag_size*entity_handles_size;
  }
  else if(*tag_values_allocated < tag_size*entity_handles_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    ((pMeshMdl)instance)->last_error=*err;
    return;
  }

  *tag_values_size = tag_size*entity_handles_size;

  if(tag_size== 1)
  {
    pEntSet sing_data;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetSetTag ((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &sing_data))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      (*tag_values)[ent_pos] = (iBase_EntitySetHandle)sing_data;
    }
  }
  else // entity array
  {
    pEntSet* arr_data = new pEntSet[tag_size];
    int arr_size;
    for (int ent_pos=0; ent_pos<entity_handles_size; ++ent_pos)
    {
      if (FMDB_Ent_GetSetArrTag((pMeshMdl)instance, (pMeshEnt)(entity_handles[ent_pos]), tag_id, &arr_data, &arr_size))
      {
        *err = iBase_TAG_NOT_FOUND;
        ((pMeshMdl)instance)->last_error=*err;
        return;
      }
      for (int arr_pos=0; arr_pos<tag_size; ++arr_pos)
        (*tag_values)[ent_pos*tag_size+arr_pos] = (iBase_EntitySetHandle)(arr_data[arr_pos]);
    }
  } // else
}
