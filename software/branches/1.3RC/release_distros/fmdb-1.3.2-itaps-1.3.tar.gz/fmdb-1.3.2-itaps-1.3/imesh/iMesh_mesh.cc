/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <assert.h>
#include <map>
#include <stdint.h>
#include <string.h>
#include "iMesh.h"
#include "FMDB.h"
#include "mMesh.h"
#include "mPart.h"
#include "GUM.h"
#include "mEntity.h"
#include "FMDB_Iterator.h"

using namespace std;

void iMesh_getErrorType(iMesh_Instance instance,
                          /*out*/ int *error_type)
{
  *error_type=((pMeshMdl)instance)->last_error;
}
  
void iMesh_getDescription(iMesh_Instance instance,
                            /*inout*/ char *descr, 
                            /*in*/ int descr_len)
{
  char *strDescriptions[] = {
      "Success!",
      "Mesh already loaded",
      "File not found",
      "File write error",
      "Nil array",
      "Bad array size",
      "Bad array dimension",
      "Invalid entity handle",
      "Invalid entity count",
      "Invalid entity type",
      "Invalid entity topology",
      "Bad type and topo",
      "Entity creation error",
      "Invalid tag handle",
      "Tag not found",
      "Tag already exists",
      "Tag in use",
      "Invalid entityset handle",
      "Invalid iterator handle",
      "Invalid argument",
      "Memory allocation failed",
      "Not supported",
      "Failure"
    };
  snprintf(descr, descr_len-1, "%s", strDescriptions[((pMeshMdl)instance)->last_error]);
}

void iMesh_newMesh(const char *options, 
		   iMesh_Instance *instance, int *err, int options_len)
{
  *err = iBase_SUCCESS;
  pMeshMdl mesh;
  FMDB_Mesh_Create (NULL, mesh);
  *instance = (iMesh_Instance)mesh;
}


void iMesh_dtor(iMesh_Instance instance, int *err)
{
  *err = iBase_SUCCESS;
 ((pMeshMdl)instance)->clearPart();
  delete (pMeshMdl)instance;
}

void iMesh_load(iMesh_Instance instance,
		const iBase_EntitySetHandle entity_set_handle,
		const char *name, const char *options,
		int *err, int name_len, int options_len)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
 
  if(((mEntitySetBase*)entity_set_handle)->isRootSet()) 
  { 
    int iFmdbErr = FMDB_Mesh_LoadFromFile ((pMeshMdl)instance, name, 0);
    if(iFmdbErr != SCUtil_SUCCESS)
      {
        *err = iBase_FAILURE;
         return;
      }
    ITAPS_Util::Instance()->computeNTE(part);
  }
  else
    *err = iBase_NOT_SUPPORTED;

  // initialize adj table
  for (int i=0; i<4; ++i)
    for (int j=0; j<4; ++j)
      if (i==j) // diagonal
        ((pMeshMdl)instance)->MRM[i][j] = iBase_AVAILABLE;
      else // non-diagonal
        ((pMeshMdl)instance)->MRM[i][j] = iBase_ALL_ORDER_1;

  if (part->size(3)==0) // 2d
  {
    ((pMeshMdl)instance)->MRM[3][3] = iBase_UNAVAILABLE; 
    for (int i=0; i<3; ++i)
      ((pMeshMdl)instance)->MRM[3][i] = ((pMeshMdl)instance)->MRM[i][3] = iBase_UNAVAILABLE; 
  }
}

void iMesh_save(iMesh_Instance instance,
		const iBase_EntitySetHandle entity_set_handle,
		const char *name, const char *options, 
		int *err, const int name_len, int options_len)
{
  *err = iBase_SUCCESS;
  
  if(((mEntitySetBase*)entity_set_handle)->isRootSet()) 
    FMDB_Mesh_WriteToFile((pMeshMdl)instance, name, 0);
  else  // entity set file I/O
    *err = iBase_NOT_SUPPORTED;
}


void iMesh_getRootSet(iMesh_Instance instance,
		      iBase_EntitySetHandle *root_set, int *err)
{
  *err = iBase_SUCCESS;
  *root_set = (iBase_EntitySetHandle)instance;
}

// All serial FMDB functions should not call parallel FMDB functions. 
void iMesh_getGeometricDimension(iMesh_Instance instance,
				 int *geom_dim, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  FMDB_Part_GetDim (part, geom_dim);
}


void iMesh_setGeometricDimension( iMesh_Instance instance,
                                    /*in*/ int geom_dim,
                                    /*out*/ int* err )
{
  *err = iBase_SUCCESS; 
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if(geom_dim<=0)
    *err= iBase_FAILURE; 
  else
    part->setDimension(geom_dim);
}

void iMesh_getDfltStorage(iMesh_Instance instance,
			  int *order, int *err)
{
  *err = iBase_SUCCESS;
  *order = iBase_INTERLEAVED;
}

void iMesh_setAdjTable (iMesh_Instance instance,
                          /*inout*/ int* adjacency_table,
                          /*in*/    int adjacency_table_size, 
                          /*out*/   int *err)
{
  *err = iBase_SUCCESS;
  if (adjacency_table_size!=16) 
  {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  
  for (int i=0; i<4; ++i)
     for (int j=0; j<4; ++j)
       ((pMeshMdl)instance)->MRM[i][j] = (adjacency_table)[4*i+j];
}

void iMesh_getAdjTable (iMesh_Instance instance,
			int** adjacency_table,
			/*inout*/ int* adjacency_table_allocated, 
			/*out*/ int* adjacency_table_size, int *err)
{
  *err = iBase_SUCCESS;

  if(*adjacency_table_allocated == 0 || *adjacency_table == 0){
    *adjacency_table = (int*)(calloc(16, sizeof(int)));
    if(*adjacency_table == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *adjacency_table_allocated = 16;
  }
  else if(*adjacency_table_allocated < 16) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  
  *adjacency_table_size = 16;

  for (int i=0; i<4; ++i)
    for (int j=0; j<4; ++j)
      (*adjacency_table)[4*i+j] = ((pMeshMdl)instance)->MRM[i][j];
}


void iMesh_getNumOfType(iMesh_Instance instance,
			/*in*/ const iBase_EntitySetHandle entity_set_handle,
			/*in*/ const int entity_type,
			int *num_type, int *err)
{
  *err = iBase_SUCCESS;
 
  if(entity_type<iBase_VERTEX || entity_type>iBase_ALL_TYPES)
  {
    *err = iBase_INVALID_ENTITY_TYPE; 
    return; 
  }
 
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if (((mEntitySetBase*)entity_set_handle)->isRootSet()) {
    if( entity_type != iBase_ALL_TYPES )
      *num_type =  part->size(entity_type);
    else
      *num_type = (part->size(0) + part->size(1) + part->size(2) + part->size(3));
  }
  else {
   if(((mEntitySet*)entity_set_handle)->isList() )
   {
      pEntSetUIterator iter = new mEntSetUIterator( ((mEntitySetUnordered*)entity_set_handle)->begin(), ((mEntitySetUnordered*)entity_set_handle)->end() , entity_type, (int)(mEntity::ALL_TOPOLOGIES), 0, &processingEntitySetUFilter);
   int num=0;
   for(; !iter->end(); ++(*iter))
       ++num;
   delete iter;
   *num_type = num;
   }
   else
   {
      pEntSetOIterator iter = new mEntSetOIterator( ((mEntitySetOrdered*)entity_set_handle)->begin(), ((mEntitySetOrdered*)entity_set_handle)->end(), entity_type, (int)(mEntity::ALL_TOPOLOGIES), 0, &processingEntitySetOFilter);
   int num=0;
   for(; !iter->end(); ++(*iter))
       ++num;
   delete iter;
   *num_type = num;
   }
  }
}


void iMesh_getNumOfTopo(iMesh_Instance instance,
			/*in*/ const iBase_EntitySetHandle entity_set_handle,
			/*in*/ const int entity_topology,
			int *num_topo, int *err)
{
  *err = iBase_SUCCESS;

  if(entity_topology<iMesh_POINT || entity_topology>iMesh_ALL_TOPOLOGIES)
  {
    *err = iBase_INVALID_ENTITY_TOPOLOGY; 
    return; 
  }

  if (!((mEntitySetBase*)entity_set_handle)->isRootSet()) { // entity set 
    
    if(((mEntitySet*)entity_set_handle)->isList() )
    {
      pEntSetUIterator iter = new mEntSetUIterator( ((mEntitySetUnordered*)entity_set_handle)->begin(), 
                                  ((mEntitySetUnordered*)entity_set_handle)->end(), 
                                  iBase_ALL_TYPES, entity_topology, 0, &processingEntitySetUFilter);
      int num=0;
      for(; !iter->end(); ++(*iter))
         ++num;
      delete iter;
      *num_topo = num;
    }
    else
    {
       pEntSetOIterator iter = new mEntSetOIterator( ((mEntitySetOrdered*)entity_set_handle)->begin(),
                                   ((mEntitySetOrdered*)entity_set_handle)->end(), iBase_ALL_TYPES,
                                   entity_topology, 0, &processingEntitySetOFilter);
       int num=0;
       for(; !iter->end(); ++(*iter))
         ++num;
       delete iter;
       *num_topo = num;
    }
  }  // entity set
  else // part
  {
    pPart part;
    FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

    *num_topo = 0;
    if (entity_topology != iMesh_ALL_TOPOLOGIES)
      *num_topo = ITAPS_Util::Instance()->getNTE(part, entity_topology);
    else
      for(int i=0; i<11; ++i) 
        *num_topo += ITAPS_Util::Instance()->getNTE(part,i);
  } // else part
}


void iMesh_areEHValid(iMesh_Instance instance,
		      int doReset, int *areHandlesInvariant, int *err)
{
  *err = iBase_SUCCESS;
  *areHandlesInvariant = true;
}


void iMesh_getEntities(iMesh_Instance instance,
		       const iBase_EntitySetHandle entity_set_handle,
		       const int entity_type,
		       const int entity_topology,
		       iBase_EntityHandle** entity_handles, 
		       int* entity_handles_allocated,
		       int* entity_handles_size,
		       int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  bool check = checkTypeTopo((int)entity_type,(int)entity_topology);
			   
  if (!check) {
    *err = iBase_BAD_TYPE_AND_TOPO; 
    * entity_handles_size = 0;
    return;
  }
  
  int numEnt=0, counter=0;
  
  if (!((mEntitySetBase*)entity_set_handle)->isRootSet()) {
     
    if(((mEntitySet*)entity_set_handle)->isList() )
    {
     pEntSetUIterator iter = new mEntSetUIterator( ((mEntitySetUnordered*)entity_set_handle)->begin(), ((mEntitySetUnordered*)entity_set_handle)->end(), (int)entity_type, (int)entity_topology, 0, &processingEntitySetUFilter);
     numEnt = 0;
     for(; !iter->end(); ++(*iter))
       ++numEnt;
 
     if (numEnt == 0) {
       *entity_handles_size = 0;
       return;
     }
 
   // allocate memory
   if (*entity_handles==0 || *entity_handles_allocated == 0)  {  // should check *entity_handles, not entity_handles. 0826
     *entity_handles = (iBase_EntityHandle*)(calloc(numEnt, sizeof(iBase_EntityHandle)));
     if(*entity_handles == 0) {
       *err = iBase_MEMORY_ALLOCATION_FAILED;
       return;
     }
     *entity_handles_allocated = numEnt;
    }
    else
       if(*entity_handles_allocated<numEnt) {
         *err = iBase_BAD_ARRAY_SIZE;
          return;
        }
    
      *entity_handles_size = numEnt;
    
      for (iter->reset();!iter->end();++(*iter))         
            (*entity_handles)[counter++]= (iBase_EntityHandle)(*(*iter));
      delete iter;
     }
     else
    {
     pEntSetOIterator iter = new mEntSetOIterator( ((mEntitySetOrdered*)entity_set_handle)->begin(), ((mEntitySetOrdered*)entity_set_handle)->end(), (int)entity_type, (int)entity_topology, 0, &processingEntitySetOFilter);
     numEnt = 0;
     for(; !iter->end(); ++(*iter))
       ++numEnt;
 
     if (numEnt == 0) {
       *entity_handles_size = 0;
       return;
     }
 
   // allocate memory
   if (*entity_handles==0 || *entity_handles_allocated == 0)  {  // should check *entity_handles, not entity_handles. 0826
     *entity_handles = (iBase_EntityHandle*)(calloc(numEnt, sizeof(iBase_EntityHandle)));
     if(*entity_handles == 0) {
       *err = iBase_MEMORY_ALLOCATION_FAILED;
       return;
     }
     *entity_handles_allocated = numEnt;
    }
    else
       if(*entity_handles_allocated<numEnt) {
         *err = iBase_BAD_ARRAY_SIZE;
          return;
        }
    
      *entity_handles_size = numEnt;
    
      for (iter->reset();!iter->end();++(*iter))         
            (*entity_handles)[counter++]= (iBase_EntityHandle)(*(*iter));
      delete iter; 
    }
    return;
  }
  else { // compute numEnt for mesh 
    if (entity_topology == iMesh_ALL_TOPOLOGIES)  {
      if (entity_type<4)
        numEnt = part->size(entity_type);
      else 
        numEnt = part->size(0)+part->size(1)+part->size(2)+part->size(3);
    }		  
    else // topology specified
      numEnt = ITAPS_Util::Instance()->getNTE(part, entity_topology);
  
  if (numEnt == 0) {
    *entity_handles_size = 0;
    return;
  }
  
  // allocate memory  
  if (*entity_handles==0 || *entity_handles_allocated == 0)  {  // should check *entity_handles, not entity_handles. 0826 
    *entity_handles = (iBase_EntityHandle*)(calloc(numEnt, sizeof(iBase_EntityHandle))); 
    if(*entity_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *entity_handles_allocated = numEnt;
  }
  else 
    if(*entity_handles_allocated<numEnt) {
      *err = iBase_BAD_ARRAY_SIZE; 
      return;
    }
  
  *entity_handles_size = numEnt;
  
  switch (entity_type)
    {
    case iBase_VERTEX: 
    case iBase_EDGE: 
      for (mPart::iterall it=part->beginall(entity_type); 
	   it!=part->endall(entity_type);++it)
	(*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 

      break;	     
    case iBase_FACE:
      {
	if (entity_topology == iMesh_ALL_TOPOLOGIES)      
	  {
	    for (mPart::iterall it=part->beginall(entity_type); 
	      it!=part->endall(entity_type);++it)
	      (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	  }
	if(entity_topology == iMesh_TRIANGLE ||
	   entity_topology == iMesh_QUADRILATERAL)   
	  {
	    for (mPart::iterall it=part->beginall(entity_type); 
		 it!=part->endall(entity_type);++it)
	      if(entity_topology == (iMesh_EntityTopology)(*it)->getTopo())  
		(*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	  }
        break;	 
      }
     case iBase_REGION:
       {
	 if (entity_topology == iMesh_ALL_TOPOLOGIES)   
	   {
	     for (mPart::iterall it=part->beginall(entity_type); 
		  it!=part->endall(entity_type);++it)
	       (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	   }
	if( entity_topology == iMesh_TETRAHEDRON ||
	    entity_topology == iMesh_HEXAHEDRON ||
	    entity_topology == iMesh_PYRAMID ||
	    entity_topology == iMesh_PRISM )  
	  {
	    for (mPart::iterall it=part->beginall(entity_type); 
		 it!=part->endall(entity_type);++it)
	      if(entity_topology == (iMesh_EntityTopology)(*it)->getTopo())    
		(*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	  }
	break;	 
       }
      case iBase_ALL_TYPES:
	{
	  switch (entity_topology)
	    {
	    case iMesh_POINT:
	      {
		for (mPart::iterall it=part->beginall(0); it!=part->endall(0);++it)
		  (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	    case iMesh_LINE_SEGMENT:
	      {
		for (mPart::iterall it=part->beginall(1); it!=part->endall(1);++it)
		  (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
		break;	 
	      }
	    case iMesh_TRIANGLE:
	      {
		for (mPart::iterall it=part->beginall(2); it!=part->endall(2);++it)
		  if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	       
	    case iMesh_QUADRILATERAL:      // QUAD
	      {
		for (mPart::iterall it=part->beginall(2); it!=part->endall(2);++it)
		  if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	      
	    case iMesh_TETRAHEDRON: 
	      {
		for (mPart::iterall it=part->beginall(3); it!=part->endall(3);++it)
		  if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	      
	    case iMesh_HEXAHEDRON:       // HEX
	      {
		for (mPart::iterall it=part->beginall(3); it!=part->endall(3);++it)
	      if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		(*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	      
	    case iMesh_PYRAMID:       //  PYR
	      {
		for (mPart::iterall it=part->beginall(3); it!=part->endall(3);++it)
		  if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	      
	    case iMesh_PRISM :       // WED
	      {
		for (mPart::iterall it=part->beginall(3); it!=part->endall(3);++it)
		  if(entity_topology == (iMesh_EntityTopology)((*it)->getTopo()))
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	
	    case iMesh_ALL_TOPOLOGIES:
	      {
		for (int dim=0; dim<4; ++dim)
		  for (mPart::iterall it=part->beginall(dim); it!=part->endall(dim);++it)
		    (*entity_handles)[counter++]= (iBase_EntityHandle)(*it); 
	      }
	      break;	 
	    default: assert(numEnt==0);
	      break;	
	    }
	} // case all_types
    } //switch
   }
}


void iMesh_getAdjEntIndices(iMesh_Instance instance,
                      /*in*/    iBase_EntitySetHandle entity_set_handle,
                      /*in*/    int entity_type_requestor,
                      /*in*/    int entity_topology_requestor,
                      /*in*/    int entity_type_requested,
                      /*inout*/ iBase_EntityHandle** entity_handles,
                      /*inout*/ int* entity_handles_allocated,
                      /*out*/   int* entity_handles_size,
                      /*inout*/ iBase_EntityHandle** adj_entity_handles,
                      /*inout*/ int* adj_entity_handles_allocated,
                      /*out*/   int* adj_entity_handles_size,
                      /*inout*/ int** adj_entity_indices,
                      /*inout*/ int* adj_entity_indices_allocated,
                      /*out*/   int* adj_entity_indices_size,
                      /*inout*/ int** offset,
                      /*inout*/ int* offset_allocated,
                      /*out*/   int* offset_size,
                      /*out*/   int *err)
{ 
  const int allocated_entity_handles = (*entity_handles_allocated == 0);
  const int allocated_indices = (*adj_entity_indices_allocated == 0);
  const int allocated_offset = (*offset_allocated == 0);

    // get source entities
  iMesh_getEntities( instance, 
                       entity_set_handle,
                       entity_type_requestor, 
                       entity_topology_requestor,
                       entity_handles,
                       entity_handles_allocated,
                       entity_handles_size,
                       err );
  if (iBase_SUCCESS != *err)
    return;
    
    // get adjacencies
    iBase_EntityHandle* all_adj_handles = 0;
    int size = 0, alloc = 0;
    iMesh_getEntArrAdj( instance,
                        *entity_handles, *entity_handles_size,
                        entity_type_requested,
                        &all_adj_handles, &alloc, &size,
                        offset, offset_allocated, offset_size,
                        err );
    if (*err != iBase_SUCCESS) {
      if (allocated_entity_handles) {
        free( *entity_handles );
        *entity_handles = 0;
        *entity_handles_allocated = 0;
      }
      return;
    }
    
    // allocate or check size of adj_entity_indices
    *adj_entity_indices_size = size;
    if (allocated_indices) {
      *adj_entity_indices = (int*)malloc(sizeof(iBase_EntityHandle)*size);
      if (!*adj_entity_indices) 
        *err = iBase_MEMORY_ALLOCATION_FAILED;
      else
        *adj_entity_indices_allocated = size;
    }
    else if (*adj_entity_indices_allocated < size) {
      *err = iBase_BAD_ARRAY_SIZE;
    }
    if (iBase_SUCCESS != *err) {
      free( all_adj_handles );
      if (allocated_entity_handles) {
        free( *entity_handles );
        *entity_handles = 0;
        *entity_handles_allocated = 0;
      }
      if (allocated_offset) {
        free( *offset );
        *offset = 0;
        *offset_allocated = 0;
      }
      return;
    }

  // Now create an array of unique sorted handles from all_adj_handles.
    // We need to create a copy because we still need all_adj_handles.  We
    // will eventually need to copy the resulting unique list into 
    // adj_entity_handles, so if adj_entity_handles is already allocated and
    // of sufficient size, use it rather than allocating another temporary.
    iBase_EntityHandle* unique_adj = 0;
    if (*adj_entity_handles_allocated >= size) {
      unique_adj = *adj_entity_handles;
    }
    else {
      unique_adj = (iBase_EntityHandle*)malloc(sizeof(iBase_EntityHandle) * size);
    }
    std::copy( all_adj_handles, all_adj_handles+size, unique_adj );
    std::sort( unique_adj, unique_adj + size );
    *adj_entity_handles_size = std::unique( unique_adj, unique_adj + size ) - unique_adj;
    
    // If we created a temporary array for unique_adj rather than using
    // already allocated space in adj_entity_handles, allocate adj_entity_handles
    // and copy the unique handle list into it
    if (*adj_entity_handles != unique_adj) {
      if (!*adj_entity_handles_allocated) {
        *adj_entity_handles = (iBase_EntityHandle*)malloc(
                              sizeof(iBase_EntityHandle) * *adj_entity_handles_size);
        if (!*adj_entity_handles)
          *err = iBase_MEMORY_ALLOCATION_FAILED;
        else
          *adj_entity_handles_allocated = *adj_entity_handles_size;
      }
      else if (*adj_entity_handles_allocated < *adj_entity_handles_size) 
        *err = iBase_BAD_ARRAY_SIZE;
      if (iBase_SUCCESS != *err) {
        free( unique_adj );
        free( all_adj_handles );
        if (allocated_entity_handles) {
          free( *entity_handles );
          *entity_handles = 0;
          *entity_handles_allocated = 0;
        }
        if (allocated_offset) {
          free( *offset );
          *offset = 0;
          *offset_allocated = 0;
        }
        if (allocated_indices) {
          free( *adj_entity_indices );
          *adj_entity_indices = 0;
          *adj_entity_indices_allocated = 0;
        }
        return;
      }

      std::copy( unique_adj, unique_adj + *adj_entity_handles_size, *adj_entity_handles );
      free( unique_adj );
      unique_adj = *adj_entity_handles;
    }
    
    // convert from adjacency list to indices into unique_adj
    for (int i = 0; i < *adj_entity_indices_size; ++i)
      (*adj_entity_indices)[i] = std::lower_bound( unique_adj, 
        unique_adj + *adj_entity_handles_size, all_adj_handles[i] ) - unique_adj;
    free( all_adj_handles );     
}
