/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include <stdint.h>


void iMesh_createTag(iMesh_Instance instance,
                     /*in*/ const char* tag_name,
                     /*in*/ const int tag_size,
                     /*in*/ const int tag_type,
                     /*out*/ iBase_TagHandle* tag_handle, int *err,
                     /*in*/ const int tag_name_len )
{
  *err = iBase_SUCCESS;

  if(tag_size<0)
  {
   *err = iBase_INVALID_ARGUMENT;
   *tag_handle = 0;
   return;
  }

  if(tag_type<iBase_TagValueType_MIN || tag_type>iBase_TagValueType_MAX)
  {
    *err = iBase_INVALID_ARGUMENT;
    *tag_handle = 0;
    return;
  }

  pTag tag;
  if (FMDB_Tag_Create((pMeshMdl)instance, tag_name, tag_type, tag_size, 1, &tag))
  {
    *err = iBase_TAG_ALREADY_EXISTS;
    *tag_handle = (iBase_TagHandle)(uintptr_t)tag;
    return;
  }

  *tag_handle = (iBase_TagHandle)(uintptr_t)tag;
}

void iMesh_destroyTag(iMesh_Instance instance,
                             /*in*/ iBase_TagHandle tag_handle,
                             /*in*/ const int forced, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag, &exist);

  // tag validity check
  if (!exist)  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  if (FMDB_Tag_Del ((pMeshMdl)instance, &tag, forced)) {
    *err = iBase_TAG_IN_USE;
    return;
  }
}

void iMesh_getTagHandle(iMesh_Instance instance,
                        /*in*/ const char* tag_name,
                        iBase_TagHandle *tag_handle, int *err,
                        int tag_name_len)
{
  *err = iBase_SUCCESS;

  pTag tag_id;

  if (FMDB_Tag_GetHandle((pMeshMdl)instance, tag_name, &tag_id)) { // no tag found
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  *tag_handle = (iBase_TagHandle)(uintptr_t)tag_id;
}

void iMesh_getTagType(iMesh_Instance instance,
                             /*in*/ const iBase_TagHandle tag_handle,
                             int *tag_type, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &exist);
  // tag_id validity check
  if (!exist)
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, tag_type);
}

void iMesh_getTagSizeBytes(iMesh_Instance instance,
                                  /*in*/ const iBase_TagHandle tag_handle,
                                  int *byte_tag_size, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist((pMeshMdl)instance, tag_id, &exist);
  // tag_id validity check
  if (!exist)
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  int tag_type, tag_size;
  FMDB_Tag_GetType ((pMeshMdl)instance, tag_id, &tag_type);
  FMDB_Tag_GetSize ((pMeshMdl)instance, tag_id, &tag_size);
    
  switch(tag_type)
  {
  case iBase_INTEGER:
    *byte_tag_size = (int)(sizeof(int)*tag_size);
    break; 
  case iBase_DOUBLE:           
    *byte_tag_size = (int)(sizeof(double)*tag_size);
    break;                     
  case iBase_ENTITY_HANDLE:    
    *byte_tag_size = (int)(sizeof(void*)*tag_size);
    break; 
  default:
    *byte_tag_size = (int)(sizeof(char)*tag_size);
    break;
  }     
}

void iMesh_getTagSizeValues(iMesh_Instance instance,
                                   /*in*/ const iBase_TagHandle tag_handle,
                                   int *tag_size, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist((pMeshMdl) instance, tag_id, &exist);
  // tag_id validity check
  if (!exist)
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, tag_size);
}

void iMesh_getTagName(iMesh_Instance instance,
                             /*in*/ const iBase_TagHandle tag_handle,
                             char *name, int *err,
                             int name_len)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t) tag_handle;
  int exist;
  FMDB_Tag_Exist((pMeshMdl) instance, tag_id, &exist);
  // tag_id validity check
  if (!exist)
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  FMDB_Tag_GetName ((pMeshMdl)instance, tag_id, name);
}

