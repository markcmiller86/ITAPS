/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include "mMesh.h"
#include <stdint.h>

void iMesh_getAllEntSetTags(iMesh_Instance instance,
                                   /*in*/ const iBase_EntitySetHandle entity_set_handle,
                                   /*out*/ iBase_TagHandle** tag_handles,
                                   /*out*/ int* tag_handles_allocated,
                                   /*out*/ int* tag_handles_size, int *err)
{

  *err = iBase_SUCCESS;

  if(* tag_handles_allocated!=0)
  {
   *err = iBase_BAD_ARRAY_SIZE;
   return;
  }

  int num_tags;
  std::vector<pTag> allIds;

  if(((mEntitySetBase*)entity_set_handle)->isRootSet())
     FMDB_Tag_GetAllID ((pMeshMdl) instance, allIds);
  else
    ((mEntitySet*)entity_set_handle)->getAllTagID(allIds);

  num_tags=allIds.size();

  if(*tag_handles == 0 || *tag_handles_allocated == 0) {
    *tag_handles =(iBase_TagHandle*)(calloc(num_tags, sizeof(iBase_TagHandle)));
    if(*tag_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *tag_handles_allocated = num_tags;
  }
  else if(*tag_handles_allocated < num_tags) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  *tag_handles_size = num_tags;

  int k=0;
  vector<pTag>::iterator iter;
  for(iter=allIds.begin(); iter!=allIds.end(); iter++)
    (*tag_handles)[k++] = (iBase_TagHandle)(uintptr_t)(*iter);
}

void iMesh_rmvEntSetTag(iMesh_Instance instance,
                               /*in*/ iBase_EntitySetHandle entity_set_handle, 
                               /*in*/ const iBase_TagHandle tag_handle, int *err)
{ 
  *err = iBase_SUCCESS;
                    
  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  if (((mEntitySetBase*)entity_set_handle)->isRootSet())
  { 
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_DelTag (part, tag_id);
  }
  else
    FMDB_Set_DelTag ((pEntSet)entity_set_handle, tag_id);
}  

// byte tagging with part/entity set
void iMesh_setEntSetData(iMesh_Instance instance,
                           /*in*/ iBase_EntitySetHandle entity_set_handle,
                           /*in*/ const iBase_TagHandle tag_handle,
                           /*in*/ const void* tag_value,
                           /*in*/ const int tag_value_size,
                           /*out*/ int *err)
{                              
  *err = iBase_SUCCESS;        
   
  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  /* generic setData functions */
  if(((mEntitySetBase*)entity_set_handle)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_SetByteTag(part, tag_id, tag_value, tag_value_size);
  }
  else        
    FMDB_Set_SetByteTag((mEntitySet*)entity_set_handle,  tag_id, tag_value, tag_value_size);
}

void iMesh_getEntSetData(iMesh_Instance instance,
                           /*in*/ const iBase_EntitySetHandle entity_set_handle,
                           /*in*/ const iBase_TagHandle tag_handle,
                           /*inout*/ void* tag_value,
                           /*inout*/ int* tag_value_allocated,
                           /*out*/ int* tag_value_size,
                           /*out*/ int *err)
{ 
  *err = iBase_SUCCESS;     

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  // compute the needed memory size
  int tag_type, tag_size, tag_type_sz;
  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  switch (tag_type)
  {
    case 0: // byte
            tag_type_sz = 1; break;
    case 1: // int
            tag_type_sz = sizeof(int); break;
    case 2: // double
            tag_type_sz = sizeof(double); break;
    case 3: // entity
            tag_type_sz = sizeof(void*); break;
    case 4: // entity set
            tag_type_sz = sizeof(void*); break;
    default: break;
  }

  void** tag_v = reinterpret_cast<void**>(tag_value);
  // allocate the memory
  if (*tag_v==0 || *tag_value_allocated==0)
  {
     *tag_v = (void*)malloc(tag_type_sz*tag_size);
     if (!*tag_v)
       *err = iBase_MEMORY_ALLOCATION_FAILED;
     else
       *tag_value_allocated =tag_type_sz*tag_size;
  }
  else if (*tag_value_allocated < tag_type_sz*tag_size)
  {
    *err = iBase_BAD_ARRAY_SIZE;
    *tag_value_size=0;
    return;
  }
  *tag_value_size = tag_type_sz*tag_size;

  int tSize = 0;

  if (((mEntitySetBase*)entity_set_handle)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);

    FMDB_Part_GetByteTag(part, tag_id, tag_v, &tSize);
  }
  else
    FMDB_Set_GetByteTag((mEntitySet*)entity_set_handle, tag_id, tag_v, &tSize);
}

// integer tagging with part/entity set
void iMesh_setEntSetIntData(iMesh_Instance instance,
                                   /*in*/ iBase_EntitySetHandle entity_set,
                                   /*in*/ const iBase_TagHandle tag_handle,
                                   /*in*/ const int tag_value, int *err)
{
   *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_INTEGER ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  if (((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_SetIntTag(part, tag_id, tag_value);
  }
  else
    FMDB_Set_SetIntTag((mEntitySet*)entity_set, tag_id, tag_value);
}

void iMesh_getEntSetIntData(iMesh_Instance instance,
                                   /*in*/ const iBase_EntitySetHandle entity_set,
                                   /*in*/ const iBase_TagHandle tag_handle,
                                   int *out_data, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_INTEGER ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  if (((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_GetIntTag (part, tag_id, out_data);
  }
  else
    FMDB_Set_GetIntTag ((mEntitySet*)entity_set, tag_id, out_data);
}


// double tagging with part/entity set
void iMesh_setEntSetDblData(iMesh_Instance instance,
                                   /*in*/ iBase_EntitySetHandle entity_set,
                                   /*in*/ const iBase_TagHandle tag_handle,
                                   /*in*/ const double tag_value, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_DOUBLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  if(((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_SetDblTag(part, tag_id, tag_value);
  }
  else
    FMDB_Set_SetDblTag((mEntitySet*)entity_set, tag_id, tag_value);
}

void iMesh_getEntSetDblData(iMesh_Instance instance,
                                   /*in*/ const iBase_EntitySetHandle entity_set,
                                   /*in*/ const iBase_TagHandle tag_handle,
                                   double *out_data, int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_DOUBLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  if (((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_GetDblTag (part, tag_id, out_data);
  }
  else
    FMDB_Set_GetDblTag ((mEntitySet*)entity_set, tag_id, out_data);
}


// entity tagging with part/entity set
void iMesh_setEntSetEHData(iMesh_Instance instance,
                           /*in*/ iBase_EntitySetHandle entity_set,
                           /*in*/ const iBase_TagHandle tag_handle,
                           /*in*/ const iBase_EntityHandle tag_value, int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    ((pMeshMdl)instance)->last_error = *err;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }


  if(((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_SetEntTag(part, tag_id, (pMeshEnt)tag_value);
  }
  else
     FMDB_Set_SetEntTag((mEntitySet*)entity_set, tag_id, (pMeshEnt)tag_value);
}

void iMesh_getEntSetEHData(iMesh_Instance instance,
                                  /*in*/ const iBase_EntitySetHandle entity_set,
                                  /*in*/ const iBase_TagHandle tag_handle,
                                  iBase_EntityHandle *out_data, int *err)
{
   *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  pMeshEnt ent;
  int fmdb_err=0;
  if (((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    fmdb_err = FMDB_Part_GetEntTag (part, tag_id, &ent);
  }
  else
    fmdb_err = FMDB_Set_GetEntTag ((mEntitySet*)entity_set, tag_id, &ent);

  if (fmdb_err) {
    *err = iBase_TAG_NOT_FOUND;
    ((pMeshMdl)instance)->last_error = *err;
    return;
  }
  *out_data = (iBase_EntityHandle)ent;
}

// entity set tagging with part/entity set
void iMesh_setEntSetESHData(iMesh_Instance instance,
                             /*in*/ iBase_EntitySetHandle entity_set,
                             /*in*/ const iBase_TagHandle tag_handle,
                             /*in*/ const iBase_EntitySetHandle tag_value,
                             /*out*/ int *err)
{
  *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_SET_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  if(((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_SetSetTag(part, tag_id, (pEntSet)tag_value);
  }
  else
    FMDB_Set_SetSetTag((mEntitySet*)entity_set, tag_id, (pEntSet)tag_value);
}

void iMesh_getEntSetESHData(iMesh_Instance instance,
                             /*in*/ const iBase_EntitySetHandle entity_set,
                             /*in*/ const iBase_TagHandle tag_handle,
                             /*out*/ iBase_EntitySetHandle *out_data,
                             /*out*/ int *err)
{
   *err = iBase_SUCCESS;

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_SET_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  pEntSet eset;
  if (((mEntitySetBase*)entity_set)->isRootSet())
  {
    pPart part;
    FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
    FMDB_Part_GetSetTag (part, tag_id, &eset);
  }
  else
    FMDB_Set_GetSetTag ((mEntitySet*)entity_set, tag_id, &eset);

  *out_data = (iBase_EntitySetHandle)eset;
}
