/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include <iostream>
#include <assert.h>
#include <map>
#include <stdint.h>
#include <string.h>
#include "iMesh.h"
#include "FMDB.h"
#include "GUM.h"
#include "mEntity.h"
#include "mVertex.h"

void iMesh_getVtxArrCoords(iMesh_Instance instance,
			   /*in*/ const iBase_EntityHandle* vertex_handles,
			   /*in*/ const int vertex_handles_size,
			   /*inout*/ int storage_order,
			   /*inout*/ double** coords,
			   /*inout*/ int* coords_allocated,
			   /*out*/ int* coords_size, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  if (vertex_handles==0) {
    *err = iBase_NIL_ARRAY;
    return;
  }

  if (vertex_handles_size==0)
    {
      *coords=0;
      *coords_size=0;
      return;
    }

  int dim = part->getDimension();
  if(dim==0)
  {
    dim=2; 
    if (part->size(3)) dim=3;
  }

  if(vertex_handles_size<=0) {
    *err = iBase_INVALID_ENTITY_COUNT; 
    return;
  }
  
  if (*coords==0 || *coords_allocated == 0) {
    *coords = (double*)(calloc(vertex_handles_size*dim, sizeof(double))); 
    if(*coords == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *coords_allocated = vertex_handles_size*dim;
  }
  else if(*coords_allocated<vertex_handles_size*dim) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  
  *coords_size = vertex_handles_size*dim; 

  int count=0;    
  mVertex* vt;
  for (int i=0; i<vertex_handles_size;++i) 
  {
    vt = (mVertex*) vertex_handles[i]; 
    if (!vt || vt->getLevel()!=0) {
      *err = iBase_INVALID_ENTITY_TYPE; 
      return;
    }
    
    if (storage_order == iBase_BLOCKED) 
     {
       (*coords)[count] =  vt->point()(0);
       if(dim>=2)
         (*coords)[vertex_handles_size+count] =  vt->point()(1);
       if (dim==3)
        (*coords)[2*vertex_handles_size+count] = vt->point()(2);
        count++;
     }
     else 
       if (storage_order == iBase_INTERLEAVED ) 
	 for (int k=0; k<dim; ++k)
         (*coords)[count++] = vt->point()(k);
       else {
	 *err = iBase_NOT_SUPPORTED; 
	 return; 
       }
    
  }  
  *coords_size = vertex_handles_size*dim;  

}


void iMesh_getEntArrTopo(iMesh_Instance instance,
			 /*in*/ const iBase_EntityHandle* entity_handles,
			 /*in*/ const int entity_handles_size,
			 /*inout*/ int** topology,
			 /*inout*/ int* topology_allocated,
			 /*out*/ int* topology_size, int *err)
{
  *err = iBase_SUCCESS;
  
  if (entity_handles==0 || entity_handles_size == 0) 
  {
    if (*topology==NULL)
      *topology_allocated=0;
    *topology_size=0;
    return;  
  }
  
  if (*topology==NULL || *topology_allocated == 0)
  {
    *topology = (int*)(calloc(entity_handles_size, sizeof(int)));
    if(*topology == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *topology_allocated = entity_handles_size;
  }
  else if(*topology_allocated<entity_handles_size) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  *topology_size = entity_handles_size;  
  
  mEntity* e;
  for (int i=0; i<entity_handles_size; ++i) 
  {
    e = (mEntity*)(entity_handles[i]); 
    (*topology)[i]= (iMesh_EntityTopology)((e)->getTopo());   
  }
}


void iMesh_getEntArrType(iMesh_Instance instance,
			 /*in*/ const iBase_EntityHandle* entity_handles,
			 /*in*/ const int entity_handles_size,
			 /*inout*/ int** type,
			 /*inout*/ int* type_allocated,
			 /*out*/ int* type_size, int *err)
{
  *err = iBase_SUCCESS;

  if (entity_handles_size == 0) 
  {
    if (*type == NULL)
      *type_allocated = 0;
    *type_size=0;
    return;  
  }
  
  if (*type==0 || *type_allocated == 0)
  {
    *type = (int*)(calloc(entity_handles_size, sizeof(int)));
    if(*type == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *type_allocated = entity_handles_size;
  }
  else if(*type_allocated<entity_handles_size) 
  {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  *type_size = entity_handles_size;

  mEntity* e;
  for (int i=0; i<entity_handles_size; ++i) 
  {
    e = (mEntity*)(entity_handles[i]);
    (*type)[i] = (iBase_EntityType)(e->getLevel());
  }
}


void iMesh_getEntArrAdj(iMesh_Instance instance,
			/*in*/ const iBase_EntityHandle* entity_handles,
			/*in*/ const int entity_handles_size,
			/*in*/ const int entity_type_requested,
			/*inout*/ iBase_EntityHandle** adj_entity_handles,
			/*inout*/ int* adj_entity_handles_allocated,
			/*out*/ int* adj_entity_handles_size,
			/*inout*/ int** offset,
			/*inout*/ int* offset_allocated,
			/*out*/ int* offset_size, int *err)
{
  *err = iBase_SUCCESS;
 
  // check if entity_handles is empty 
  if (entity_handles==0 || entity_handles_size==0) 
  {
    *adj_entity_handles_size=0; 
    *offset_size=1; 

    *offset = (int*)(calloc(1, sizeof(int)));
    *offset_allocated = 1;
    offset[0]=0;
    return;
  }

  int offset_allocated_flag = (*offset_allocated==0); // 1 if not allocated
  // allocate memory for offset if no memory allocated to it
  if (*offset==0 || *offset_allocated == 0) 
  {
    *offset = (int*)(calloc(entity_handles_size+1, sizeof(int))); 
    if(*offset == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *offset_allocated = entity_handles_size+1;
  }
  else if(*offset_allocated < entity_handles_size+1) {
    *err = iBase_BAD_ARRAY_SIZE; 
    return;
  }
  if (*err != iBase_SUCCESS)
  {
    *offset_size=1;
    return;
  }
  *offset_size = entity_handles_size+1;  
  
  // get Adj for each entity in entity_handles
  std::list<vector<pMeshEnt>* > entAdjList;
  pMeshEnt ent;
  int adj_ent_size=0;
  for (int i=0; i<entity_handles_size; ++i)
  {
    ent = (pMeshEnt)(entity_handles[i]);
    std::vector<pMeshEnt>* tempVec=new std::vector<pMeshEnt>;
    FMDB_Ent_GetAdj (ent, entity_type_requested, 1, *tempVec);
    entAdjList.push_back(tempVec);
    adj_ent_size += tempVec->size();
  }

  // allocate memory for adjacent entities
  if (*adj_entity_handles==0 || *adj_entity_handles_allocated == 0) {
    *adj_entity_handles = (iBase_EntityHandle*)(calloc(adj_ent_size, sizeof(iBase_EntityHandle))); 
    if(*adj_entity_handles == 0) 
      *err = iBase_MEMORY_ALLOCATION_FAILED;
    else 
      *adj_entity_handles_allocated =adj_ent_size;
  }
  else if(*adj_entity_handles_allocated < adj_ent_size) {
    *err = iBase_BAD_ARRAY_SIZE;
  }
  
  // if memory allocation failed, clean-up and return
  if (*err != iBase_SUCCESS)
  {
    if (offset_allocated_flag)
    {
      free(*offset);
      *offset=NULL;
      *offset_allocated=0;
    }
    *offset_size=1;
    return;
  } 

  *adj_entity_handles_size = adj_ent_size; 

  // fill adj_entity_handles and offset
  int adj_idx=0, offset_idx=1;
  (*offset)[0]=0;
  std::list<vector<pMeshEnt>* >::iterator adjVecIter;
  std::vector<pMeshEnt>::iterator entIter;

  for (adjVecIter=entAdjList.begin(); adjVecIter != entAdjList.end(); ++adjVecIter)
  {
    for (entIter=(*adjVecIter)->begin(); entIter!=(*adjVecIter)->end(); ++entIter)
      (*adj_entity_handles)[adj_idx++] = (iBase_EntityHandle)(*entIter);
    (*offset)[offset_idx] = (*offset)[offset_idx-1]+(*adjVecIter)->size();
    ++offset_idx;
  }
  // remove vectors
  for (adjVecIter=entAdjList.begin(); adjVecIter != entAdjList.end(); ++adjVecIter)
  {
    (*adjVecIter)->clear();
    delete (*adjVecIter);
  }
}

void iMesh_getEntArr2ndAdj( iMesh_Instance instance,
			    iBase_EntityHandle const* entity_handles,
			    int entity_handles_size,
			    int bridge_entity_type,
			    int requested_entity_type,
			    iBase_EntityHandle** adj_entity_handles,
			    int* adj_entity_handles_allocated,
			    int* adj_entity_handles_size,
			    int** offset,
			    int* offset_allocated,
			    int* offset_size,
			    int* err ) 
{
  *err = iBase_SUCCESS;

  // check bridge-target type compatibility
  if (bridge_entity_type==requested_entity_type && bridge_entity_type!=4)
  {
    *adj_entity_handles_size=0;
    // allocate memory for offset
    if (*offset_allocated==0) // memory is not alloc'ed to adj_entity_handles
    {
      *offset = (int*)malloc(sizeof(int)*(entity_handles_size+1));
      if (!*offset)
        *err = iBase_MEMORY_ALLOCATION_FAILED;
      else
        *offset_allocated = (entity_handles_size+1);
    }
    else if (*offset_allocated < entity_handles_size+1) 
      *err = iBase_BAD_ARRAY_DIMENSION;

    // if memory allocation failed for offset, clean-up and return
    if (*err != iBase_SUCCESS) 
      return;
    *offset_size = entity_handles_size + 1;
    for (int i=0; i<entity_handles_size+1;++i)
      (*offset)[i] = 0;
    *err = iBase_INVALID_ARGUMENT;
    return;
  }  

  // check whether entity_handles is empty
  if (entity_handles_size == 0) {
    if(*adj_entity_handles == 0) 
      *adj_entity_handles_allocated = 0;
    *adj_entity_handles_size = 0;
    if(*offset == 0)
      *offset_allocated = 0;
    *offset_size = 1;
    return;
  }

  // get 2ndAdj for each entity in entity_handles
  std::list<vector<pMeshEnt>* > entAdjList;

  pMeshEnt ent;
  int adj_ent_size=0;
  for(int i=0;i<entity_handles_size;i++) 
  {
    ent = (pMeshEnt)(entity_handles[i]);
    std::vector<pMeshEnt>* tempVec = new std::vector<pMeshEnt>;
    FMDB_Ent_Get2ndAdj(ent, bridge_entity_type, requested_entity_type, *tempVec);
    entAdjList.push_back(tempVec);
    adj_ent_size+=tempVec->size();
  }

  assert (entity_handles_size == entAdjList.size());

  // allocate memory for adj_entity_handles
  int adj_ent_alloc_flag = (*adj_entity_handles_allocated==0); // 1 if no memory alloc'ed to adj_entity_handles

  if (*adj_entity_handles_allocated==0) // memory is not alloc'ed to adj_entity_handles
  {
    *adj_entity_handles = (iBase_EntityHandle*)malloc(sizeof(iBase_EntityHandle)*adj_ent_size);
    if (!*adj_entity_handles)
      *err = iBase_MEMORY_ALLOCATION_FAILED;
    else
      *adj_entity_handles_allocated = adj_ent_size;
  }
  else if (*adj_entity_handles_allocated < adj_ent_size) 
    *err = iBase_BAD_ARRAY_DIMENSION;

  // if memory allocation failed for adj_entity_handles, clean-up and return
  if (*err != iBase_SUCCESS) 
    return;

  // set *adj_entity_handles_size
  *adj_entity_handles_size = adj_ent_size;

  // allocate memory for offset
  if (*offset_allocated==0) // memory is not alloc'ed to adj_entity_handles
  {
    *offset = (int*)malloc(sizeof(int)*(entity_handles_size+1));
    if (!*offset)
      *err = iBase_MEMORY_ALLOCATION_FAILED;
    else
      *offset_allocated = (entity_handles_size+1);
  }
  else if (*offset_allocated < entity_handles_size+1) 
    *err = iBase_BAD_ARRAY_DIMENSION;

  // if memory allocation failed for offset, clean-up and return
  if (*err != iBase_SUCCESS) 
  {
    if (adj_ent_alloc_flag) // free memory allocted to adj_entity_handles;
    {
      free(*adj_entity_handles);
      *adj_entity_handles=NULL;
      *adj_entity_handles=0;
      *adj_entity_handles_allocated = 0;
    }
    return;
  }
  // set *offset_size
  *offset_size = entity_handles_size + 1;

  // fill *adj_entity_handles and *offset
  (*offset)[0]=0;
  int adj_idx=0, offset_idx=1;
  std::list<vector<pMeshEnt>* >::iterator adjVecIter;
  std::vector<pMeshEnt>::iterator entIter;

  for (adjVecIter=entAdjList.begin(); adjVecIter != entAdjList.end(); ++adjVecIter)
  {
    for (entIter=(*adjVecIter)->begin(); entIter!=(*adjVecIter)->end(); ++entIter)
      (*adj_entity_handles)[adj_idx++] = (iBase_EntityHandle)(*entIter);
    (*offset)[offset_idx] = (*offset)[offset_idx-1]+(*adjVecIter)->size();
    ++offset_idx;
  }

  // remove vectors
  for (adjVecIter=entAdjList.begin(); adjVecIter != entAdjList.end(); ++adjVecIter)
  {
    (*adjVecIter)->clear();
    delete (*adjVecIter);
  }
}


void iMesh_setVtxArrCoords(iMesh_Instance instance,
			   /*in*/ const iBase_EntityHandle* vertex_handles,
			   /*in*/ const int vertex_handles_size,
			   /*in*/ const int storage_order,
			   /*in*/ const double* new_coords,
			   /*in*/ const int new_coords_size, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  if (vertex_handles==0) {
    *err = iBase_NIL_ARRAY; 
    return;
  }
  
  if (vertex_handles_size==0)
    return;      
  int dim = part->getDimension(); 
  if(dim==0)
   dim = (part->size(3))? 3: 2;

  if (new_coords_size/dim != vertex_handles_size) {
    *err = iBase_INVALID_ENTITY_COUNT; 
    return;
  }

  mVertex* vt;
  if (dim==1)
  {
    for (int i=0; i< vertex_handles_size; ++i)
    { 
      vt = (mVertex*)(vertex_handles[i]);
      if (storage_order == iBase_BLOCKED)
        vt->setCoord(new_coords[i],
                     0.0,
                     0.0);
      else // interleaved or undetermined (default)
        vt->setCoord(new_coords[i],
                     0.0,
                     0.0);
    }
   return; 
  }
  
  if (dim==3)
    for (int i=0; i< vertex_handles_size; ++i)
    {    
      vt = (mVertex*)(vertex_handles[i]);
      if (storage_order == iBase_BLOCKED)
        vt->setCoord(new_coords[i], 
                   new_coords[vertex_handles_size*1+i],
		   new_coords[vertex_handles_size*2+i]);		   
      else // interleaved or undetermined (default)
        vt->setCoord(new_coords[i*3+0], 
		     new_coords[i*3+1],
		     new_coords[i*3+2]);	      
    }  
  else // dim==2
    for (int i=0; i< vertex_handles_size; ++i)
      {    
	vt = (mVertex*)(vertex_handles[i]);
	if (storage_order == iBase_BLOCKED)
	  vt->setCoord(new_coords[i], 
		       new_coords[vertex_handles_size*1+i],
		       0.0);		   
	else // interleaved or undetermined (default)
	  vt->setCoord(new_coords[i*2+0], 
		       new_coords[i*2+1], 0.0);	      
      }
}	     


void iMesh_createVtxArr(iMesh_Instance instance,
			       /*in*/ const int num_verts,
			       /*in*/ const int storage_order,
			       /*in*/ const double* new_coords,
			       /*in*/ const int new_coords_size,
			       /*inout*/ iBase_EntityHandle** new_vertex_handles,
			       /*inout*/ int* new_vertex_handles_allocated,
			       /*inout*/ int* new_vertex_handles_size, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if (new_coords==0) {
    *err = iBase_NIL_ARRAY; 
    return;
  }
  
  if (num_verts==0)
  {
    if (*new_vertex_handles==0)
      *new_vertex_handles_allocated = 0;
    *new_vertex_handles_size = 0;
    return;  
  }
  
  int dim=part->getDimension();
  if(dim==0)
  {
     if (part->size(3)) 
      dim=3;   
     else
      dim=2; 
   }

  // allocate the memory
  if (*new_vertex_handles==0  || *new_vertex_handles_allocated == 0) {
    *new_vertex_handles = (iBase_EntityHandle*)(calloc(num_verts, sizeof(iBase_EntityHandle))); 
    if(*new_vertex_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *new_vertex_handles_allocated = num_verts;
  }
  else if(*new_vertex_handles_allocated < num_verts) {
    *err = iBase_BAD_ARRAY_SIZE; 
    return;
  }
  
  *new_vertex_handles_size = num_verts; 
  
  double param[3];
  double coords[3];
  coords[0] = coords[1] = coords[2] = 0.0;
  param[0] = param[1] = param[2] = 0.0;
  pMeshEnt vertex;

  if(dim==1)
  {
     for (int i=0; i< num_verts; ++i)
        {
         coords[0] = new_coords[i];
         FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);         
         (*new_vertex_handles)[i]= (iBase_EntityHandle)vertex;
        } // for
  }
 
 else if (dim==3)
    {
      for (int i=0; i< num_verts; ++i)
	{    
	  if (storage_order == iBase_BLOCKED)
          {
           coords[0] = new_coords[i];
           coords[1] = new_coords[num_verts*1+i];
           coords[2] = new_coords[num_verts*2+i];
           FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);    
           (*new_vertex_handles)[i]= (iBase_EntityHandle)vertex;
          }
	  else // interleaved or undetermined (default)
           {
            coords[0] = new_coords[i*3+0];
            coords[1] = new_coords[i*3+1];
            coords[2] = new_coords[i*3+2];
            FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);
            (*new_vertex_handles)[i]= (iBase_EntityHandle)vertex;
           }
	} // for
    }
  else // dim==2
    {
      for (int i=0; i< num_verts; ++i)
	{
	  if (storage_order == iBase_BLOCKED)
            {
             coords[0] = new_coords[i];
             coords[1] = new_coords[num_verts*1+i];
             FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);
             (*new_vertex_handles)[i]= (iBase_EntityHandle)vertex;
            }
	  else // interleaved or undetermined (default)
           {
            coords[0] = new_coords[i*2+0];
            coords[1] = new_coords[i*2+1];
            FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);
            (*new_vertex_handles)[i]= (iBase_EntityHandle)vertex; 
           }
	} // for
    }
}


void iMesh_createEntArr(iMesh_Instance instance,
			       /*in*/ const int new_entity_topology,
			       /*in*/ const iBase_EntityHandle* lower_order_entity_handles,
			       /*in*/ const int lower_order_entity_handles_size,
			       /*out*/ iBase_EntityHandle** new_entity_handles,
			       /*out*/ int* new_entity_handles_allocated,
			       /*out*/ int* new_entity_handles_size,
			       /*inout*/ int** status,
			       /*inout*/ int* status_allocated,
			       /*out*/ int* status_size, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  if (lower_order_entity_handles==0) {
    *err = iBase_NIL_ARRAY;
    return;
  }
  
  if (lower_order_entity_handles_size == 0)
  {
    if (*new_entity_handles==0)
      *new_entity_handles_allocated = 0;
    *new_entity_handles_size = 0;
   
    if (*status==0)
      *status_allocated = 0;
    *status_size = 0; 
    return;
  }

  int numNewEnts, numDownEnts, fmdb_err;  
  int newType=-1, downType = ((pMeshEnt)lower_order_entity_handles[0])->getLevel();

  if (new_entity_topology==iMesh_POINT || new_entity_topology==iMesh_LINE_SEGMENT)
    newType=(int)new_entity_topology;
  else if (iMesh_POLYGON<=new_entity_topology && new_entity_topology<=iMesh_QUADRILATERAL)
    newType=2;
  else if (iMesh_POLYHEDRON<=new_entity_topology && new_entity_topology<=iMesh_SEPTAHEDRON)
    newType=3;

  if (newType<=downType || newType==-1 || newType==0)
  {
    *err = iBase_INVALID_ENTITY_TYPE;
    return;
  }
  numDownEnts = FMDB_Topo_GetNumDownAdj(new_entity_topology, downType);
  if(lower_order_entity_handles_size < numDownEnts || (lower_order_entity_handles_size % numDownEnts != 0))
   {
    *err = iBase_INVALID_ENTITY_TYPE;
     return;
   }

  numNewEnts = lower_order_entity_handles_size/numDownEnts;
  // compute the number of new entities to create to allocate the memory
  
  // allocate the memory
  if(*new_entity_handles==0 || *new_entity_handles_allocated == 0) {
    *new_entity_handles = (iBase_EntityHandle*)(calloc(numNewEnts, sizeof(iBase_EntityHandle)));
    if(*new_entity_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *new_entity_handles_allocated = numNewEnts;
  }
  else if(*new_entity_handles_allocated <numNewEnts ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  *new_entity_handles_size = numNewEnts; 

  if(*status == 0 || *status_allocated == 0) {
    *status = (int*)(calloc(numNewEnts, sizeof(int)));
    if(*status == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *status_allocated = numNewEnts;
  }
  else if(*status_allocated <numNewEnts ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  *status_size = numNewEnts;
  pMeshEnt newEnt;
  pMeshEnt* lowEnts = new pMeshEnt[numDownEnts];
   for (int i=0; i<numNewEnts; ++i)
   {
    for(int j = 0; j < numDownEnts; j++)
     lowEnts[j] = (pMeshEnt)lower_order_entity_handles[(i * numDownEnts) + j];

    if(new_entity_topology == iMesh_TRIANGLE || new_entity_topology == iMesh_QUADRILATERAL) 
     *err = FMDB_Face_Create(part, (pGEntity)0, new_entity_topology, lowEnts, 0, newEnt);
    else 
    if(new_entity_topology == iMesh_LINE_SEGMENT)
     *err = FMDB_Edge_Create(part, (pGEntity)0, lowEnts[0], lowEnts[1], newEnt);
    else 
    if(new_entity_topology >= iMesh_POLYHEDRON && new_entity_topology <= iMesh_SEPTAHEDRON)
     *err = FMDB_Rgn_Create(part, (pGEntity)0, new_entity_topology, numDownEnts, lowEnts, newEnt); 

   /// Update the entity creation status
   if(*err == iBase_SUCCESS)
     (*status)[i] = iBase_NEW;

   else if(*err == SCUtil_ENTITY_ALREADY_EXISTS)
     (*status)[i] = iBase_ALREADY_EXISTED;
   else 
     (*status)[i] = iBase_CREATION_FAILED;

   (*new_entity_handles)[i] = (iBase_EntityHandle)newEnt;
   }
  delete[] lowEnts;
}


void iMesh_deleteEntArr(iMesh_Instance instance,
			       /*in*/ const iBase_EntityHandle* entity_handles,
			       /*in*/ const int entity_handles_size, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  if (entity_handles==0) 
  {
    *err = iBase_NIL_ARRAY; 
    return;
  }

  mEntity* ent;
  int numUpAdj, entType, entTopo;

  for (int i=0; i<entity_handles_size; ++i)
  {
    ent = (mEntity*) entity_handles[i];
    FMDB_Ent_GetType ((pMeshEnt)(entity_handles[i]), &entType);
    FMDB_Ent_GetTopo ((pMeshEnt)(entity_handles[i]), &entTopo);
    FMDB_Ent_GetNumAdj ((pMeshEnt)(entity_handles[i]), entType+1, &numUpAdj);
    if (numUpAdj!=0 && entType <= 2)
    {
      *err = iBase_INVALID_ENTITY_HANDLE;
      continue;
    } 
    ITAPS_Util::Instance()->decreaseNTE(part, entTopo);
    FMDB_Ent_Del (part, (pMeshEnt)(entity_handles[i]));
  }
}


void iMesh_setVtxCoord(iMesh_Instance instance,
			       /*in*/ iBase_EntityHandle vertex_handle,
			       /*in*/ const double x, /*in*/ const double y,
			       /*in*/ const double z, 
			       /*out*/ int *err)
{
  *err = iBase_SUCCESS;

  ((mVertex*)vertex_handle)->setCoord(x,y,z);
}

void iMesh_createVtx(iMesh_Instance instance,
		    /*in*/ const double x, /*in*/ const double y,
		    /*in*/ const double z,
		    /*out*/ iBase_EntityHandle* new_vertex_handle, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);
  
  double param[3];
  double coords[] = {0.0, 0.0, 0.0};
  param[0] = param[1] = param[2]=0.0;
  pMeshEnt vertex;
  if (part->size(3))
    {
     coords[0] = x;
     coords[1] = y;
     coords[2] = z;
     FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex);
    }
  else // dim==2
   {
     coords[0] = x;
     coords[1] = y;
     FMDB_Vtx_Create(part, (pGEntity)0, coords, param, vertex); 
   }
  *new_vertex_handle = (iBase_EntityHandle)vertex;
  *err = iBase_SUCCESS;
}

void iMesh_createEnt(iMesh_Instance instance,
			    /*in*/ const int new_entity_topology,
			    /*in*/ const iBase_EntityHandle* lower_order_entity_handles,
			    /*in*/ const int lower_order_entity_handles_size,
			    /*out*/ iBase_EntityHandle* new_entity_handle,
			    /*out*/ int* status, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if (lower_order_entity_handles==0) {
    *err = iBase_NIL_ARRAY; 
    return;
  }
  pMeshEnt* lowEnts = new pMeshEnt[lower_order_entity_handles_size];

  for (int j=0; j<lower_order_entity_handles_size; j++)
    lowEnts[j] = (pMeshEnt)lower_order_entity_handles[j];

  int newType=FMDB_Topo_GetType(new_entity_topology);
  int downType = ((pMeshEnt)lower_order_entity_handles[0])->getLevel();

  if (newType<=downType || newType==-1 || newType==0)
  {
    *err = iBase_INVALID_ENTITY_TYPE;
    return;
  }

   pMeshEnt newEnt; 
   switch (newType)
   {
      case 1: *err = FMDB_Edge_Create(part, (pGEntity)0, lowEnts[0], lowEnts[1], newEnt);
              break;
      case 2: *err = FMDB_Face_Create(part, (pGEntity)0, new_entity_topology, lowEnts, 0, newEnt);
              break;
      case 3: *err = FMDB_Rgn_Create(part, (pGEntity)0, new_entity_topology, lower_order_entity_handles_size, lowEnts, newEnt);
              break;
      default: break;
   } 
    
   *status = iBase_NEW;
   if (*err == SCUtil_ENTITY_ALREADY_EXISTS)
     *status =  iBase_ALREADY_EXISTED;
   else if (*err!=SCUtil_SUCCESS)
     *status = iBase_ENTITY_CREATION_ERROR;
   *new_entity_handle = (iBase_EntityHandle)newEnt;

  delete [] lowEnts;
}

void iMesh_deleteEnt(iMesh_Instance instance,
			    /*in*/ iBase_EntityHandle entity_handle, int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  int numUpAdj=0, entType;
  FMDB_Ent_GetType ((pMeshEnt)entity_handle, &entType);
  FMDB_Ent_GetNumAdj ((pMeshEnt)entity_handle, entType+1, &numUpAdj); 
  if (numUpAdj!=0 && entType <=2)
  {
    *err = iBase_FAILURE;
    return;
  }
  ITAPS_Util::Instance()->decreaseNTE(part, ((mEntity*)entity_handle)->getTopo());
  FMDB_Ent_Del(part, (pMeshEnt)entity_handle);
}


void iMesh_getEntTopo(iMesh_Instance instance,
			     /*in*/ const iBase_EntityHandle entity_handle,
			     int *out_topo, int *err)
{
  *err = iBase_SUCCESS; 
  *out_topo = (iMesh_EntityTopology)(((mEntity*)entity_handle)->getTopo());
}

void iMesh_getEntType(iMesh_Instance instance,
			     /*in*/ const iBase_EntityHandle entity_handle,
			     int *out_type, int *err)
{
  *err = iBase_SUCCESS; 
  * out_type = (iBase_EntityType)(((mEntity*)entity_handle)->getLevel());
}

void iMesh_getVtxCoord(iMesh_Instance instance,
			 /*in*/ const iBase_EntityHandle vertex_handle,
			 /*out*/ double *x, 
			 /*out*/ double *y, 
			 /*out*/ double *z, 
			 int *err)
{
  *err = iBase_SUCCESS; 
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if (vertex_handle==0) {
    *err = iBase_INVALID_ENTITY_HANDLE; 
    return;
  }
  
  *x = ((mVertex*)vertex_handle)->point()(0);
  *y = ((mVertex*)vertex_handle)->point()(1);
  if (part->size(3))
    *z = ((mVertex*)vertex_handle)->point()(2);
  else 
    *z = 0.0;
}

void iMesh_getEntAdj(iMesh_Instance instance,
		    /*in*/ const iBase_EntityHandle entity_handle,
		    /*in*/ const int entity_type_requested,
		    /*inout*/ iBase_EntityHandle** adj_entity_handles,
		    /*inout*/ int* adj_entity_handles_allocated,
		    /*out*/ int* adj_entity_handles_size, int *err)
{
  *err = iBase_SUCCESS; 
  
  pMeshEnt ent = (pMeshEnt) entity_handle;

  // check entType != entity_type_requested
  int entType;
  FMDB_Ent_GetType(ent, &entType);
  if (entType == entity_type_requested)
  {
    *adj_entity_handles_size=0;
    return;
  }  

  // get adj entities 
  std::vector<pMeshEnt> vecAdjEnt;
  FMDB_Ent_GetAdj(ent, entity_type_requested, 1, vecAdjEnt);

  // check # adj entities of given type and return if 0
  int numAdj = vecAdjEnt.size();  
  if (numAdj == 0) 
  {
    *adj_entity_handles_size = 0; 
    if (*adj_entity_handles == 0 )
      *adj_entity_handles_allocated = 0;
    return;
  }
 
  // allocate memory for adj_ent_handle array 
  if (*adj_entity_handles == 0 || *adj_entity_handles_allocated == 0)
    {
      *adj_entity_handles = (iBase_EntityHandle*)(calloc( numAdj, sizeof(iBase_EntityHandle))); 
      if(*adj_entity_handles == 0) {
	*err = iBase_MEMORY_ALLOCATION_FAILED;
	return;
      }
      *adj_entity_handles_allocated = numAdj;
    }
  else if (*adj_entity_handles_allocated < numAdj) 
  {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }
  *adj_entity_handles_size = numAdj; 
  
  int pos_index=0;
  for (std::vector<pMeshEnt>::iterator it=vecAdjEnt.begin(); it!=vecAdjEnt.end(); ++it)
    (*adj_entity_handles)[pos_index++] = (iBase_EntityHandle)(*it);  
}

void iMesh_getEnt2ndAdj( iMesh_Instance instance,
			 /*in*/ iBase_EntityHandle entity_handle,
			 /*in*/ int bridge_entity_type,      
			 /*in*/ int requested_entity_type,
			 /*inout*/ iBase_EntityHandle** adj_entity_handles,
			 /*inout*/ int* adj_entity_handles_allocated,
			 /*out*/ int* adj_entity_handles_size,
			 int* err ) 
{
  *err = iBase_SUCCESS; 
  
  if (bridge_entity_type==requested_entity_type && bridge_entity_type!=4)
  {
    * adj_entity_handles_size=0;
    *err = iBase_INVALID_ARGUMENT;
    return;
  }  

  pMeshEnt ent = (pMeshEnt) entity_handle;

  // get adj entities 
  std::vector<pMeshEnt> vecAdjEnt;
  FMDB_Ent_Get2ndAdj(ent, bridge_entity_type, requested_entity_type, vecAdjEnt);

  // check # adj entities of given type and return if 0
  int numAdj = vecAdjEnt.size();  
  if (numAdj == 0) 
  {
    *adj_entity_handles_size = 0; 
    return;
  }
 
  // allocate memory for adj_ent_handle array 
  if (*adj_entity_handles == 0 || *adj_entity_handles_allocated == 0)
    {
      *adj_entity_handles = (iBase_EntityHandle*)(calloc( numAdj, sizeof(iBase_EntityHandle))); 
      if(*adj_entity_handles == 0) 
	*err = iBase_MEMORY_ALLOCATION_FAILED;
      else 
        *adj_entity_handles_allocated = numAdj;
    }
  else if (*adj_entity_handles_allocated < numAdj) 
    *err = iBase_BAD_ARRAY_SIZE;

  if (*err != iBase_SUCCESS)
  {
    *adj_entity_handles_size = 0; 
    return;
  }
  *adj_entity_handles_size = numAdj; 
  
  int pos_index=0;
  for (std::vector<pMeshEnt>::iterator it=vecAdjEnt.begin(); it!=vecAdjEnt.end(); ++it)
    (*adj_entity_handles)[pos_index++] = (iBase_EntityHandle)(*it);
}

