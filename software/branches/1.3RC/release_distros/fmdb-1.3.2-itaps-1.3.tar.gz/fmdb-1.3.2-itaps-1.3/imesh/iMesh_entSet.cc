
/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include "mMesh.h"

void iMesh_createEntSet(iMesh_Instance instance,
                        /*in*/ const int isList,
                        /*out*/ iBase_EntitySetHandle* entity_set_created, int *err)
{   
  *err = iBase_SUCCESS;
     
  mEntitySet* pset = mEntitySet::createEntitySet((pMeshMdl) instance, isList);
  ((pMeshMdl)instance)->addEntSet(pset);      
  *entity_set_created = (iBase_EntitySetHandle) pset;          
}

void iMesh_destroyEntSet(iMesh_Instance instance,
                         /*in*/ iBase_EntitySetHandle entity_set, int *err)
{       
  *err = iBase_SUCCESS; 
  ((pMeshMdl)instance)->removeEntSet((mEntitySet*)entity_set);
        
  delete (mEntitySet*) entity_set;
}   

void iMesh_isList(iMesh_Instance instance,
                  /*in*/ const iBase_EntitySetHandle entity_set,
                  int *is_list, int *err)
{
  *err = iBase_SUCCESS;

  *is_list = ((mEntitySet*)entity_set)->isList();
}

void iMesh_getNumEntSets(iMesh_Instance instance,
                         /*in*/ const iBase_EntitySetHandle entity_set_handle,
                         /*in*/ const int num_hops,
                         int *num_sets, int *err)
{
  *err = iBase_SUCCESS;

  if(!((mEntitySetBase*)entity_set_handle)->isRootSet())
    *num_sets = (int)(((mEntitySet*)entity_set_handle)->numSubset(num_hops));
  else
    *num_sets = (int)(((pMeshMdl)instance)->allEntSets.size());
}

void iMesh_getEntSets(iMesh_Instance instance,
                      /*in*/ const iBase_EntitySetHandle entity_set_handle,
                      /*in*/ const int num_hops,
                      /*out*/ iBase_EntitySetHandle** contained_set_handles,
                      /*out*/ int* contained_set_handles_allocated,
                      /*out*/ int* contained_set_handles_size, int *err)
{
  *err = iBase_SUCCESS;

  std::list<void*> subsets;
  int sz_subsets;
  if(!((mEntitySetBase*)entity_set_handle)->isRootSet()){
    ((mEntitySet*)entity_set_handle)->getSubset(subsets, num_hops);
    sz_subsets=subsets.size();
  }
  else // mesh
    sz_subsets=((pMeshMdl)instance)->allEntSets.size();

  if (*contained_set_handles==0 || *contained_set_handles_allocated == 0) {
    *contained_set_handles = (iBase_EntitySetHandle*)(calloc(sz_subsets, sizeof(iBase_EntitySetHandle)));
    if(*contained_set_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *contained_set_handles_allocated = sz_subsets;
  }
  else // something is allocated
    if(*contained_set_handles_allocated<sz_subsets) {
      *err = iBase_BAD_ARRAY_SIZE;
      return;
    }

  *contained_set_handles_size = sz_subsets;

  if(!((mEntitySetBase*)entity_set_handle)->isRootSet()) // entity set            
  {
    std::list<void*>::iterator lit = subsets.begin();
    for (int i=0; lit!=subsets.end(); ++i, ++lit)
      (*contained_set_handles)[i] = (iBase_EntitySetHandle)(*lit);
  }
  else // mesh
  {
    std::list<mEntitySet*>::iterator lit = ((pMeshMdl)instance)->beginEntSet();
    for (int i=0; lit!=((pMeshMdl)instance)->endEntSet(); ++i, ++lit)
      (*contained_set_handles)[i] = (iBase_EntitySetHandle)(*lit);
  }
}

void iMesh_addEntToSet(iMesh_Instance instance,
                       /*in*/ iBase_EntityHandle entity_handle,
                       /*in*/ iBase_EntitySetHandle entity_set, int *err)
{
   *err = iBase_SUCCESS;

   ((mEntitySet*)(entity_set))->addEntity((mEntity*)entity_handle);
}

void iMesh_rmvEntFromSet(iMesh_Instance instance,
                         /*in*/ iBase_EntityHandle entity_handle,
                         /*in*/ iBase_EntitySetHandle entity_set, int *err)
{
  *err = iBase_SUCCESS;

   ((mEntitySet*)(entity_set))->removeEntity((mEntity*)entity_handle);
}


void iMesh_addEntArrToSet(iMesh_Instance instance,
                          /*in*/ const iBase_EntityHandle* entity_handles,
                          /*in*/ int entity_handles_size,
                          /*in*/ iBase_EntitySetHandle entity_set, int *err)
{
  *err = iBase_SUCCESS;

  if (entity_handles==0 && entity_handles_size != 0) {
    *err = iBase_NIL_ARRAY;
    return;
  }

  mEntitySet* eset = (mEntitySet*)(entity_set);
  for (int i=0; i<entity_handles_size; i++)
    //  ((mEntitySet*)(entity_set))->addEntity((mEntity*)(entity_handles[i]));
    eset->addEntity((mEntity*)(entity_handles[i]));

}

void iMesh_rmvEntArrFromSet(iMesh_Instance instance,
                                   /*in*/ const iBase_EntityHandle* entity_handles,
                                   /*in*/ int entity_handles_size,
                                   /*in*/ iBase_EntitySetHandle entity_set, int *err)
{
  *err = iBase_SUCCESS;

  if (entity_handles==0) {
    *err = iBase_NIL_ARRAY;
    return;
  }

  for (int i=0; i<entity_handles_size; i++)
    ((mEntitySet*)(entity_set))->removeEntity((mEntity*)entity_handles[i]);
}


void iMesh_addEntSet(iMesh_Instance instance,
                            /*in*/ iBase_EntitySetHandle entity_set_to_add,
                            /*in*/ iBase_EntitySetHandle entity_set_handle, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)entity_set_to_add || (void*)((pMeshMdl)instance)==(void*)entity_set_handle)
  {
     *err = iBase_INVALID_ARGUMENT;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set_to_add)) ) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set_handle))) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }


  ((mEntitySet*)(entity_set_handle))->addSubset((mEntitySet*)entity_set_to_add);
}

void iMesh_rmvEntSet(iMesh_Instance instance,
                            /*in*/ iBase_EntitySetHandle entity_set_to_remove,
                            /*in*/ iBase_EntitySetHandle entity_set_handle, int *err)
{
  *err = iBase_SUCCESS;
  if((void*)((pMeshMdl)instance)==(void*)entity_set_to_remove || (void*)((pMeshMdl)instance)==(void*)entity_set_handle)
  {
     *err = iBase_INVALID_ARGUMENT;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set_to_remove)) ) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set_handle))) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

   ((mEntitySet*)(entity_set_handle))->removeSubset((mEntitySet*)entity_set_to_remove);
}

void iMesh_isEntContained(iMesh_Instance instance,
                                 /*in*/ iBase_EntitySetHandle containing_entity_set,
                                 /*in*/ iBase_EntityHandle contained_entity,
                                 int *is_contained, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)containing_entity_set )
  {
     *err = iBase_INVALID_ARGUMENT;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(containing_entity_set))) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  *is_contained = ((mEntitySet*)containing_entity_set)->existEntity((mEntity*)contained_entity);
}

void iMesh_isEntArrContained( iMesh_Instance instance,
                         /*in*/ iBase_EntitySetHandle containing_set,
                         /*in*/ const iBase_EntityHandle* entity_handles,
                         /*in*/ int num_entity_handles,
                      /*inout*/ int** is_contained,
                      /*inout*/ int* is_contained_allocated,
                        /*out*/ int* is_contained_size,
                        /*out*/ int* err )
{
  *err = iBase_SUCCESS;

  if( *is_contained==0 || *is_contained_allocated==0 ) {

    *is_contained = (int*)(calloc(num_entity_handles, sizeof(int)));
    if(*is_contained==0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *is_contained_allocated = num_entity_handles;
  }
  else
    if( *is_contained_allocated<num_entity_handles ){
      *err = iBase_BAD_ARRAY_SIZE;
      return;
    }

  *is_contained_size = num_entity_handles;

  for(int i=0; i<num_entity_handles; i++) {
    (*is_contained)[i]= ((mEntitySet*)containing_set)->existEntity((mEntity*)entity_handles[i]);
  }

}

void iMesh_isEntSetContained(iMesh_Instance instance,
                                    /*in*/ const iBase_EntitySetHandle containing_entity_set,
                                    /*in*/ const iBase_EntitySetHandle contained_entity_set,
                                    int *is_contained, int *err)
{
  *err = iBase_SUCCESS;
  if((void*)((pMeshMdl)instance)==(void*)containing_entity_set || (void*)((pMeshMdl)instance)==(void*)contained_entity_set)
  {
     *err = iBase_INVALID_ARGUMENT;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(containing_entity_set)) ) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(contained_entity_set))) )
  {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  *is_contained = ((mEntitySet*)containing_entity_set)->isSubset((mEntitySet*)contained_entity_set);
}

void iMesh_addPrntChld(iMesh_Instance instance,
                              /*in*/ iBase_EntitySetHandle parent_entity_set,
                              /*in*/ iBase_EntitySetHandle child_entity_set, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)parent_entity_set || (void*)((pMeshMdl)instance)==(void*)child_entity_set)
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(parent_entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(child_entity_set))) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  ((mEntitySet*)(parent_entity_set))->addChild((mEntitySet*)(child_entity_set));
}

void iMesh_rmvPrntChld(iMesh_Instance instance,
                              /*in*/ iBase_EntitySetHandle parent_entity_set,
                              /*in*/ iBase_EntitySetHandle child_entity_set, int *err)
{
  *err = iBase_SUCCESS;
  
  if((void*)((pMeshMdl)instance)==(void*)parent_entity_set || (void*)((pMeshMdl)instance)==(void*)child_entity_set)
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(parent_entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(child_entity_set))) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

   ((mEntitySet*)(parent_entity_set))->removeChild((mEntitySet*)(child_entity_set));
}

void iMesh_isChildOf(iMesh_Instance instance,
                            /*in*/ const iBase_EntitySetHandle parent_entity_set,
                            /*in*/ const iBase_EntitySetHandle child_entity_set,
                            int *is_child, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)parent_entity_set|| (void*)((pMeshMdl)instance)==(void*)child_entity_set)
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(parent_entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(child_entity_set))) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  *is_child = ((mEntitySet*)parent_entity_set)->isChild((mEntitySet*)child_entity_set);
}

void iMesh_getNumChld(iMesh_Instance instance,
                             /*in*/ const iBase_EntitySetHandle entity_set,
                             /*in*/ const int num_hops,
                             int *num_child, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)entity_set )
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  *num_child = ((mEntitySet*)entity_set)->numChildren(num_hops);
}

void iMesh_getNumPrnt(iMesh_Instance instance,
                             /*in*/ const iBase_EntitySetHandle entity_set,
                             /*in*/ const int num_hops,
                             int *num_parent, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)entity_set)
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  *num_parent = ((mEntitySet*)entity_set)->numParents(num_hops);
}

void iMesh_getChldn(iMesh_Instance instance,                           /*in*/ const iBase_EntitySetHandle from_entity_set,
                           /*in*/ const int num_hops,
                           /*out*/ iBase_EntitySetHandle** entity_set_handles,
                           /*out*/ int* entity_set_handles_allocated,
                           /*out*/ int* entity_set_handles_size, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)from_entity_set )
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(from_entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  std::list<void*> children;
  ((mEntitySet*)from_entity_set)->getChildren(children, num_hops);

  if (children.size() == 0)
  {
    if (*entity_set_handles==0)
      *entity_set_handles_allocated = 0;
    *entity_set_handles_size = 0;
    return;
  }

  if (*entity_set_handles==0 || *entity_set_handles_allocated == 0) {
    *entity_set_handles = (iBase_EntitySetHandle*)(calloc((int)children.size(), sizeof(iBase_EntitySetHandle)));
    if(*entity_set_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *entity_set_handles_allocated = (int) children.size();
  }
  else if(*entity_set_handles_allocated <(int)children.size()) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;  }

  *entity_set_handles_size = (int)children.size();

  std::list<void*>::iterator lit = children.begin();
  for (int i=0; lit!=children.end(); ++i, ++lit)
    (*entity_set_handles)[i] = (iBase_EntitySetHandle)*lit;
}

void iMesh_getPrnts(iMesh_Instance instance,
                           /*in*/ const iBase_EntitySetHandle from_entity_set,
                           /*in*/ const int num_hops,
                           /*out*/ iBase_EntitySetHandle** entity_set_handles,
                           /*out*/ int* entity_set_handles_allocated,
                           /*out*/ int* entity_set_handles_size, int *err)
{
  *err = iBase_SUCCESS;

  if((void*)((pMeshMdl)instance)==(void*)from_entity_set )
  {
     *err = iBase_INVALID_ENTITYSET_HANDLE;
     return;
  }

  if(!(((pMeshMdl)instance)->hasEntSet((mEntitySet*)(from_entity_set)) ) )
  {
    *err = iBase_INVALID_ENTITYSET_HANDLE;
    return;
  }

  std::list<void*> parents;
  ((mEntitySet*)from_entity_set)->getParents(parents, num_hops);

  if (parents.size() == 0)
  {
    if (*entity_set_handles==0)
      *entity_set_handles_allocated = 0;
    *entity_set_handles_size = 0;
    return;
  }

  if (*entity_set_handles==0 || *entity_set_handles_allocated == 0) {
    *entity_set_handles = (iBase_EntitySetHandle*)(calloc((int)parents.size(), sizeof(iBase_EntitySetHandle)));
    if(*entity_set_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *entity_set_handles_allocated = (int)parents.size();
  }
  else if(*entity_set_handles_allocated <(int)parents.size()) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  *entity_set_handles_size = (int)parents.size();

  std::list<void*>::iterator lit = parents.begin();
  for (int i=0; lit!=parents.end(); ++i, ++lit)
    (*entity_set_handles)[i] = (iBase_EntitySetHandle)(*lit);
}

void iMesh_unite(iMesh_Instance instance,
                 /*in*/ const iBase_EntitySetHandle entity_set_1,
                 /*in*/ const iBase_EntitySetHandle entity_set_2,
                 /*out*/ iBase_EntitySetHandle* result_entity_set, int *err)
{     
  *err = iBase_SUCCESS; 
  pPart part;
  FMDB_Mesh_GetPart ((pMeshMdl)instance, 0, part);
  bool isList=false;
  mEntitySet* temp_set;
  if (((mEntitySetBase*)entity_set_1)->isRootSet() &&
               ((mEntitySetBase*)entity_set_2)->isRootSet())
  {   
    // return empty entset
    std::cerr<<"Not implemented yet\n";
    *err = iBase_NOT_SUPPORTED;
    return;
  }             
  else
    if (((mEntitySetBase*)entity_set_1)->isRootSet() ||
                ((mEntitySetBase*)entity_set_2)->isRootSet())
  {   
    assert(((pMeshMdl)entity_set_1)==((pMeshMdl)instance)|| ((pMeshMdl)entity_set_2)==((pMeshMdl)instance));
    // return the copy of rootset
    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);
    // copy entities
    for (int i=0; i<=3; ++i)
      for (mPart::iterall it=part->beginall(i); it!=part->endall(i); ++it)
        temp_set->addEntity(*it);
    // copy subsets 
    std::list<mEntitySet*>::iterator lit = ((pMeshMdl)instance)->allEntSets.begin();
    for (; lit!=((pMeshMdl)instance)->allEntSets.end(); ++lit)
      if (*lit!=temp_set)
        temp_set->addSubset(*lit);
  }  
  else // both are entity set
  {
    if (((mEntitySet*)entity_set_1)->isList() && ((mEntitySet*)entity_set_2)->isList())
      isList=true;
     
    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);  

    ((mEntitySet*)entity_set_1)->unite((mEntitySet*)entity_set_2,
                                        temp_set);
  }
  ((pMeshMdl)instance)->addEntSet(temp_set);                    /// add entity set to mesh 
  *result_entity_set = (iBase_EntitySetHandle) temp_set;
}

void iMesh_subtract(iMesh_Instance instance,
                           /*in*/ const iBase_EntitySetHandle entity_set_1,
                           /*in*/ const iBase_EntitySetHandle entity_set_2,
                           /*out*/ iBase_EntitySetHandle* result_entity_set, int *err)
{   
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  bool isList=false;
  mEntitySet* temp_set;
  if (((mEntitySetBase*)entity_set_2)->isRootSet())
  {
    // return empty entset
    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);
  }
  else if (((mEntitySetBase*)entity_set_1)->isRootSet())
  {
    // copy entire entity_set_1 mesh
    // copy entities
    assert(((pMeshMdl)entity_set_1)==((pMeshMdl)instance));
    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);
    for (int i=0; i<=3; ++i)
      for (mPart::iterall it=part->beginall(i); it!=part->endall(i); ++it)
      {
        if(((mEntitySet*)entity_set_2)->isList())
        {
        if (find(((mEntitySetUnordered*)entity_set_2)->begin(),
                 ((mEntitySetUnordered*)entity_set_2)->end(),*it)
            ==((mEntitySetUnordered*)entity_set_2)->end())
           temp_set->addEntity(*it);
        }
        else
       {
        if (find(((mEntitySetOrdered*)entity_set_2)->begin(),
                 ((mEntitySetOrdered*)entity_set_2)->end(),*it)
            ==((mEntitySetOrdered*)entity_set_2)->end())
           temp_set->addEntity(*it);
        }
      }
    // copy subsets
    std::list<mEntitySet*>::iterator lit = ((pMeshMdl)instance)->allEntSets.begin();

    for (; lit!=((pMeshMdl)instance)->allEntSets.end(); ++lit)
    {
      if (find(((mEntitySet*)entity_set_2)->subBegin(),
              ((mEntitySet*)entity_set_2)->subEnd(),*lit)
           ==((mEntitySet*)entity_set_2)->subEnd() &&
         *lit!=temp_set)
       temp_set->addSubset(*lit);
    }
  }
  else // both are entity set
  {
    if (((mEntitySet*)entity_set_1)->isList() && ((mEntitySet*)entity_set_2)->isList())
      isList=true;

    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);

    ((mEntitySet*)entity_set_1)->subtract((mEntitySet*)entity_set_2,
                                        temp_set);
  }

  ((pMeshMdl)instance)->addEntSet(temp_set);
  *result_entity_set = (iBase_EntitySetHandle) temp_set;
}

void iMesh_intersect(iMesh_Instance instance,
                            /*in*/ const iBase_EntitySetHandle entity_set_1,
                            /*in*/ const iBase_EntitySetHandle entity_set_2,
                            /*out*/ iBase_EntitySetHandle* result_entity_set, int *err)
{
  *err = iBase_SUCCESS;
  bool isList=false;
  mEntitySet* temp_set;
  if (((mEntitySetBase*)entity_set_1)->isRootSet() &&
                ((mEntitySetBase*)entity_set_2)->isRootSet())
    {
    // return empty entset
      temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);
    }
  else if (((mEntitySetBase*)entity_set_1)->isRootSet() ||
                ((mEntitySetBase*)entity_set_2)->isRootSet())
  {
    temp_set = mEntitySet::createEntitySet(((pMeshMdl)instance), isList);
    mEntitySet::SubIter siter, siterend;

    std::list<void*> tmp_subset;

    if (((mEntitySetBase*)entity_set_1)->isRootSet()) // entity_set_1 is a rootset
    {
      assert((pMeshMdl)entity_set_1==(pMeshMdl)instance);
      siter=((mEntitySet*)entity_set_2)->subBegin();
      siterend=((mEntitySet*)entity_set_2)->subEnd();
    }
    else
    {
      assert((pMeshMdl)entity_set_2==(pMeshMdl)instance);
      siter=((mEntitySet*)entity_set_1)->subBegin();
      siterend=((mEntitySet*)entity_set_1)->subEnd();
   }

    if (((mEntitySetBase*)entity_set_1)->isRootSet()) // entity_set_1 is a rootset
    {
      if (((mEntitySet*)entity_set_2)->isList() )
      {
         mEntitySetUnordered::iter iter = ((mEntitySetUnordered*)entity_set_2)->begin();
         mEntitySetUnordered::iter iterend = ((mEntitySetUnordered*)entity_set_2)->end();
         for (; iter!=iterend;++iter)
                temp_set->addEntity(*iter);
      }
      else
      {
         mEntitySetOrdered::iter iter = ((mEntitySetOrdered*)entity_set_2)->begin();
         mEntitySetOrdered::iter iterend = ((mEntitySetOrdered*)entity_set_2)->end();
         for (; iter!=iterend;++iter)
            temp_set->addEntity(*iter);
      }
    }
    else
    {
      if (((mEntitySet*)entity_set_1)->isList() )
      {
         mEntitySetUnordered::iter iter = ((mEntitySetUnordered*)entity_set_1)->begin();
         mEntitySetUnordered::iter iterend = ((mEntitySetUnordered*)entity_set_1)->end();
         for (; iter!=iterend;++iter)
                temp_set->addEntity(*iter);
      }
      else
      {
         mEntitySetOrdered::iter iter = ((mEntitySetOrdered*)entity_set_1)->begin();
         mEntitySetOrdered::iter iterend = ((mEntitySetOrdered*)entity_set_1)->end();
         for (; iter!=iterend;++iter)
            temp_set->addEntity(*iter);
      }
    }

    for (; siter!=siterend;++siter)
      temp_set->addSubset(*siter);
  }
  else // both are entity set
  {
    if (((mEntitySet*)entity_set_1)->isList() && ((mEntitySet*)entity_set_2)->isList())
    isList=true;

    temp_set = mEntitySet::createEntitySet((pMeshMdl)instance, isList);

    ((mEntitySet*)entity_set_1)->intersect((mEntitySet*)entity_set_2,
                                         temp_set);
  }

  ((pMeshMdl)instance)->addEntSet(temp_set);                    /// add entity set to mesh
  * result_entity_set = (iBase_EntitySetHandle) temp_set;
}

