/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include <stdint.h>

void iMesh_getAllTags(iMesh_Instance instance,
                             /*in*/ const iBase_EntityHandle entity_handle,
                             /*inout*/ iBase_TagHandle** tag_handles,
                             /*inout*/ int* tag_handles_allocated,
                             /*out*/ int* tag_handles_size, int *err)
{
  *err = iBase_SUCCESS;

  std::vector<pTag> allIds;
  ((pEntity)entity_handle)->getAllTagID(allIds);

  int num_tags = allIds.size();
  if(num_tags == 0) {
    if(*tag_handles == 0)
      *tag_handles_allocated = 0;
    *tag_handles_size = 0;
    return;
  }

  if(*tag_handles ==0 || *tag_handles_allocated == 0) {
    *tag_handles = (iBase_TagHandle*)(calloc(num_tags, sizeof(iBase_TagHandle)));            // sizeof(int), hack by TING
    if(*tag_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *tag_handles_allocated = num_tags;
  }
  else if(*tag_handles_allocated <num_tags  ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  * tag_handles_size = num_tags;
  int k=0;
  std::vector<pTag>::iterator iter;
  for(iter=allIds.begin(); iter!=allIds.end(); iter++)
    (*tag_handles)[k++] = (iBase_TagHandle)(uintptr_t)(*iter);
}

void iMesh_rmvTag(iMesh_Instance instance,
                  /*in*/ iBase_EntityHandle entity_handle,
                  /*in*/ const iBase_TagHandle tag_handle, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }
  ((mEntity*)entity_handle)->deleteData(tag_id);
}


// byte tagging with entity
void iMesh_setData(iMesh_Instance instance,
                     /*in*/ iBase_EntityHandle entity_handle,
                     /*in*/ const iBase_TagHandle tag_handle,
                     /*in*/ const void* tag_value,
                     /*in*/ const int tag_value_size,
                     /*out*/ int *err)
{     
  *err = iBase_SUCCESS;
  if (!tag_value_size)
  {
    *err = iBase_BAD_ARRAY_DIMENSION;
    return;
  }
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }
    
  FMDB_Ent_SetByteTag((pMeshMdl)instance, (pMeshEnt)entity_handle, tag_id, tag_value, tag_value_size);
}

void iMesh_getData(iMesh_Instance instance,
                     /*in*/ const iBase_EntityHandle entity_handle,
                     /*in*/ const iBase_TagHandle tag_handle,
                     /*inout*/ void* tag_value,
                     /*inout*/ int *tag_value_allocated,
                     /*out*/ int *tag_value_size,
                     /*out*/ int *err)
{
  *err = iBase_SUCCESS;

 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  // compute the needed memory size
  int tag_type, tag_size, tag_type_sz;
  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &tag_type);
  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &tag_size);
  switch (tag_type)
  {
    case 0: // byte
            tag_type_sz = 1; break;
    case 1: // int
            tag_type_sz = sizeof(int); break;
    case 2: // double
            tag_type_sz = sizeof(double); break;
    case 3: // entity
            tag_type_sz = sizeof(void*); break;
    case 4: // entity set
            tag_type_sz = sizeof(void*); break;
    default: break;
  }
  // allocate the memory
  void** tag_v = reinterpret_cast<void**>(tag_value);
  if (*tag_v==0 || *tag_value_allocated==0)
  {
     *tag_v = (void*)malloc(tag_type_sz*tag_size);
     if (!*tag_v)
       *err = iBase_MEMORY_ALLOCATION_FAILED;
     else
       *tag_value_allocated =tag_type_sz*tag_size;
  }
  else if (*tag_value_allocated < tag_type_sz*tag_size)
  {
    *err = iBase_BAD_ARRAY_DIMENSION;
    *tag_value_size=0;
    return;
  }
  *tag_value_size = tag_type_sz*tag_size;

  int tSize = 0;
  FMDB_Ent_GetByteTag((pMeshMdl)instance, (pMeshEnt)entity_handle, tag_id, tag_v, &tSize);
}

// integer tagging with entity
void iMesh_setIntData(iMesh_Instance instance,
                             /*in*/ iBase_EntityHandle entity_handle,
                             /*in*/ const iBase_TagHandle tag_handle,
                             /*in*/ const int tag_value, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_INTEGER ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_SetIntTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, tag_value);
}

void iMesh_getIntData(iMesh_Instance instance,
                             /*in*/ const iBase_EntityHandle entity_handle,
                             /*in*/ const iBase_TagHandle tag_handle,
                             int *out_data, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_INTEGER ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_GetIntTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, out_data);
}

// double tagging with entity
void iMesh_setDblData(iMesh_Instance instance,
                      /*in*/ iBase_EntityHandle entity_handle,
                      /*in*/ const iBase_TagHandle tag_handle,
                      /*in*/ const double tag_value, int *err)
{
  *err = iBase_SUCCESS;

 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_DOUBLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_SetDblTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, tag_value);
}

void iMesh_getDblData(iMesh_Instance instance,
                     /*in*/ const iBase_EntityHandle entity_handle,
                     /*in*/ const iBase_TagHandle tag_handle,
                     double *out_data, int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_DOUBLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_GetDblTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, out_data);
}

// entity handle tagging with entity
void iMesh_setEHData(iMesh_Instance instance,
                            /*in*/ iBase_EntityHandle entity_handle,
                            /*in*/ const iBase_TagHandle tag_handle,
                            /*in*/ const iBase_EntityHandle tag_value, int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_SetEntTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, (mEntity*)tag_value);
}

void iMesh_getEHData(iMesh_Instance instance,
                            /*in*/ const iBase_EntityHandle entity_handle,
                            /*in*/ const iBase_TagHandle tag_handle,
                            iBase_EntityHandle *out_data, int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  pMeshEnt ent;
  FMDB_Ent_GetEntTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, &ent);
  *out_data = (iBase_EntityHandle) ent;
}

// entity set handle tagging with entity
void iMesh_setESHData(iMesh_Instance instance,
                       /*in*/ iBase_EntityHandle entity_handle,
                       /*in*/ const iBase_TagHandle tag_handle,
                       /*in*/ const iBase_EntitySetHandle tag_value,
                       /*out*/ int *err)
{
  *err = iBase_SUCCESS;

  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
      *err = iBase_INVALID_ARGUMENT;
      return;
    }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_SET_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  FMDB_Ent_SetSetTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, (pEntSet)tag_value);
}

void iMesh_getESHData(iMesh_Instance instance,
                       /*in*/ const iBase_EntityHandle entity_handle,
                       /*in*/ const iBase_TagHandle tag_handle,
                       /*out*/ iBase_EntitySetHandle *out_data,
                       /*out*/ int *err)
{
  *err = iBase_SUCCESS;
 
  int empty_mesh=0;
  FMDB_Mesh_IsEmpty((pMeshMdl)instance, &empty_mesh);
  if (empty_mesh) {
    *err = iBase_INVALID_ENTITY_HANDLE;
    return;
  }

  pTag tag_id = (uintptr_t)tag_handle;
  int exist, type, size;
  FMDB_Tag_Exist ((pMeshMdl)instance, tag_id, &exist);
  if (!exist) {
    *err = iBase_INVALID_ARGUMENT;
    return;
  }

  FMDB_Tag_GetType((pMeshMdl)instance, tag_id, &type);

  if ( type != iBase_ENTITY_SET_HANDLE ) {
    *err = iBase_INVALID_TAG_HANDLE ;
    return;
  }

  FMDB_Tag_GetSize((pMeshMdl)instance, tag_id, &size);

  if ( size != 1 ) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  pEntSet eset;
  FMDB_Ent_GetSetTag ((pMeshMdl)instance, (mEntity*)entity_handle, tag_id, &eset);
  *out_data = (iBase_EntitySetHandle) eset;
}
