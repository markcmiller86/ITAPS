/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "iBase.h"
#include "iMesh.h"
#include "FMDB.h"
#include "FMDB_Iterator.h"

void iMesh_initEntIter(iMesh_Instance instance,
                       /*in*/ const iBase_EntitySetHandle entity_set_handle,
                       /*in*/ const int requested_entity_type,
                       /*in*/ const int requested_entity_topology,
                       /*out*/ iBase_EntityIterator* entity_iterator,
                       int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if(requested_entity_type<iBase_VERTEX || requested_entity_type>iBase_ALL_TYPES)
  {
    *err = iBase_INVALID_ENTITY_TYPE;
    *entity_iterator = 0;
    return;
  }

  if(requested_entity_topology<iMesh_POINT || requested_entity_topology>iMesh_ALL_TOPOLOGIES)
  {
    *err = iBase_INVALID_ENTITY_TOPOLOGY;
    *entity_iterator = 0;
    return;
  }

 bool check = checkTypeTopo((int)requested_entity_type,(int)requested_entity_topology);
 if (!check) {
   *err = iBase_BAD_TYPE_AND_TOPO;
   *entity_iterator = 0;
   return;
 }

  pIterator iter;

  if (((mEntitySetBase*)entity_set_handle)->isRootSet()==false) // mesh           
    createIterator((mEntitySet*)entity_set_handle, iter,
                   requested_entity_type, requested_entity_topology);
  else // mesh
    createIterator(part, iter, requested_entity_type, requested_entity_topology);

  *entity_iterator = (iBase_EntityIterator)iter;
}

void iMesh_getNextEntIter(iMesh_Instance instance,
                                 /*in*/ iBase_EntityIterator entity_iterator,
                                 /*out*/ iBase_EntityHandle* entity_handle,
                                 int *has_data, int *err)
{
  bool ret = !iterEnd((pIterator)entity_iterator);
  if (!ret) {
    *err = iBase_SUCCESS;
    *has_data = 0;
    return;
  }

  *entity_handle = (iBase_EntityHandle)iterData((pIterator)entity_iterator);
  iterNext((pIterator)entity_iterator);
  *has_data = 1;
  *err = iBase_SUCCESS;
}

void iMesh_resetEntIter(iMesh_Instance instance,
                               /*in*/ iBase_EntityIterator entity_iterator, int *err)
{
   *err = iBase_SUCCESS;

   iterReset((pIterator)entity_iterator);
}

void iMesh_endEntIter(iMesh_Instance instance,
                             /*in*/ iBase_EntityIterator entity_iterator, int *err)
{
  *err = iBase_SUCCESS;
  deleteIterator((pIterator&)entity_iterator);
}


void iMesh_resetEntArrIter(iMesh_Instance instance,
                           /*in*/ iBase_EntityArrIterator entArr_iterator, int *err)
{
  *err = iBase_SUCCESS;
  iterReset((pIterator)entArr_iterator);
}


// entity array iterator
 void iMesh_initEntArrIter(iMesh_Instance instance,
                           /*in*/ const iBase_EntitySetHandle entity_set_handle,
                           /*in*/ const int requested_entity_type,
                           /*in*/ const int requested_entity_topology,
                           /*in*/ const int requested_array_size,
                           /*out*/ iBase_EntityArrIterator* entArr_iterator,
                           int *err)
{
  *err = iBase_SUCCESS;
  pPart part;
  FMDB_Mesh_GetPart((pMeshMdl)instance, 0, part);

  if(requested_entity_type<iBase_VERTEX || requested_entity_type>iBase_ALL_TYPES)
  {
    *err = iBase_INVALID_ENTITY_TYPE;
    *entArr_iterator = 0;
    return;
  }

  if(requested_entity_topology<iMesh_POINT || requested_entity_topology>iMesh_ALL_TOPOLOGIES)
  {
    *err = iBase_INVALID_ENTITY_TOPOLOGY;
    *entArr_iterator = 0;
    return;
  }

 bool check = checkTypeTopo((int)requested_entity_type,(int)requested_entity_topology);
 if (!check) {
   *err = iBase_BAD_TYPE_AND_TOPO;
   *entArr_iterator = 0;
   return;
 }

  pIterator tsttIter;

  if (((mEntitySetBase*)entity_set_handle)->isRootSet()==false) // mesh
    createIterator((mEntitySet*)entity_set_handle, tsttIter,
                   requested_entity_type, requested_entity_topology);
  else // part
    createIterator(part, tsttIter, requested_entity_type, requested_entity_topology);

  *entArr_iterator = (iBase_EntityArrIterator)tsttIter;
}

void iMesh_getNextEntArrIter(iMesh_Instance instance,
                             /*in*/ iBase_EntityArrIterator entArr_iterator,
                             /*inout*/ iBase_EntityHandle** entity_handles,
                             /*inout*/ int* entity_handles_allocated,
                             /*out*/ int* entity_handles_size,
                             int *has_data, int *err)
{
  *err = iBase_SUCCESS;

  pIterator iter = (pIterator)entArr_iterator;
  bool ret = !iterEnd(iter);
  if (!ret)  {
    *entity_handles_size =0;
    *has_data = false;
    return;
  }

  // int wrkSize = iter->wrkSize(); 
  int wrksize = wrkSize(iter);
  if(wrksize == 0)
    if(*entity_handles == 0) {
      *entity_handles_allocated = 0;
      *has_data = false;
      return;
    }

  if(*entity_handles==0 || *entity_handles_allocated == 0) {
    *entity_handles = (iBase_EntityHandle*)(calloc(wrksize, sizeof(iBase_EntityHandle)));
    if(*entity_handles == 0) {
      *err = iBase_MEMORY_ALLOCATION_FAILED;
      return;
    }
    *entity_handles_allocated = wrksize;
  }
  else if(*entity_handles_allocated < wrksize) {
    *err = iBase_BAD_ARRAY_SIZE;
    return;
  }

  int size=0;
  for (; !iterEnd(iter)&&size<wrksize;iterNext(iter))
    {
      (*entity_handles)[size++] = (iBase_EntityHandle)iterData(iter);
    }

  *entity_handles_size = size;
  *has_data = true;

}



void iMesh_endEntArrIter(iMesh_Instance instance,
                         /*in*/ iBase_EntityArrIterator entArr_iterator, int *err)
{
  *err = iBase_SUCCESS;
  deleteIterator((pIterator&)entArr_iterator);
}

