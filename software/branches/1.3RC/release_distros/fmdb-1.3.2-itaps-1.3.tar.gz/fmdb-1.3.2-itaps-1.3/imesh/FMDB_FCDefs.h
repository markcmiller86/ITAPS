/* imesh/IMESH_FCDefs.h.  Generated from IMESH_FCDefs.h.in by configure.  */
/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#define FMDB_FC_FUNC(name,NAME) name ## _
    
/* As FMDB_FC_FUNC, but for C identifiers containing underscores. */
#define FMDB_FC_FUNC_(name,NAME) name ## _
