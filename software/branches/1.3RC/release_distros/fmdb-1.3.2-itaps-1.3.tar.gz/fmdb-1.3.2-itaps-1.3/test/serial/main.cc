/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center,
      Rensselaer Polytechnic Institute. All rights reserved.

  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.

*******************************************************************************/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <malloc.h>
#include "FMDB.h"

using std::cout;
using std::endl;
using std::vector;

void CHECK(char *msg, int oK, ...)
{     
  assert(oK);

  char buff[1024];
  va_list  args;
  va_start (args, msg);
  vsprintf(buff, msg, args);
  va_end (args);
  if (oK)
    fprintf(stdout,"%s OK \n",buff);
  else
    fprintf(stdout,"%s FAILED\n", buff);
  fflush(stdout);
}

int TEST_MESH(int argc, char *argv[], const char* mesh_file, const char* out_file);


int main (int argc, char *argv[])
{
  char mesh_file[1024], out_file [1024];
  if (argc==1)
  {
    strcpy(mesh_file, "../meshes/test3d_1Kr.sms");
    strcpy(out_file, "out_temp");
    TEST_MESH(argc, argv, mesh_file, out_file);
  }
  else if (argc==2)
  { 
    strcpy(mesh_file, argv[1]);
    strcpy(out_file, "out_temp");
    TEST_MESH(argc, argv, mesh_file, out_file);
  }
  else
  {
    strcpy(mesh_file, argv[1]);
    strcpy(out_file, argv[2]);
    TEST_MESH(argc, argv, mesh_file, out_file);
  }

  return 0;
}

int TEST_MESH(int argc, char *argv[], const char* mesh_file, const char* out_file)
{
  cout<<"\n***** MEMORY STAT @ BEGIN OF TEST_MESH *****\n"; 
  malloc_stats();

// variable declaration
  int err, numProc, procId, iType, iTopo, partDim, numEnt, numType, numTopo, entType, entTopo;
  int tag_type, tag_size, tag_byte, ID, int_data, byte_size, byte_data_alloc=0;
  int isValid=0, numEntSet, isList, hasEnt, traceable=1, forceDel=0, exist, part_id;
  int i, j, k, failed;
  double time, dbl_data;
  int type_topo[] = {0, 1, 2, 5, 11};
  int num_type[] = {0, 0, 0, 0};
  pTag byte_tag, int_tag, dbl_tag, ent_tag,  entset_tag;
  pTag intarr_tag, dblarr_tag, entarr_tag,  entsetarr_tag;
  pTag cloneTag;
  vector<pTag> tag_ids;
  char data[]= "abcdefg";
  char tag_name[256];
  pPart part;
  pPart newPart;
  pMeshEnt ent;
  pMeshEnt ent_data;
  vector<pMeshEnt> edges;
  pPartEntIter iter;

// end of variable declaration
#ifndef FMDB_PARALLEL
  MPI_Comm MPI_COMM_WORLD=0;
#endif
/*************************************************************************
@  SYSTEM-LEVEL FUNCTIONS:
@
@  FMDB_Init, MDB_GetWTime, FMDB_GetNumProc, FMDB_GetProcID
@ *************************************************************************/
  CHECK("\n* Starting FMDB service...", !FMDB_Init(MPI_COMM_WORLD));

  FMDB_GetWTime(&time);
  FMDB_GetNumProc(&numProc);
  FMDB_GetProcID(&procId);
  CHECK("\n* Checking System Level Functions...", numProc+procId);

/*************************************************************************
@  MESH/PART FUNCTIONS:
@
@  FMDB_Mesh_Create, FMDB_Mesh_Del, FMDB_Mesh_LoadFromFile
@  FMDB_Mesh_WriteToFile, FMDB_Mesh_DspNumEnt, FMDB_Mesh_Verify
@  FMDB_Part_Create, FMDB_Part_Del, FMDB_Mesh_GetParts, 
@  FMDB_Mesh_GetPart, FMDB_Part_GetID, FMDB_Mesh_GetNumPart
@ *************************************************************************/

  pMeshMdl mesh; 
  CHECK ("\n* Creating FMDB Mesh Instance...", !FMDB_Mesh_Create (NULL, mesh));

  err = FMDB_Mesh_LoadFromFile(mesh, mesh_file, 0);
  if(err != SCUtil_SUCCESS)
    {
      cout << "\n Unable to load file " << mesh_file << endl;
      return SCUtil_FILE_NOT_FOUND;
    }
  CHECK ("* Writing Mesh...", !FMDB_Mesh_WriteToFile(mesh, out_file, numProc-1));
  CHECK ("\n* Displaying Mesh Info...", !FMDB_Mesh_DspNumEnt (mesh));
  CHECK ("\n* Verifying Mesh...", !FMDB_Mesh_Verify(mesh, &isValid)); 
  
  CHECK ("\n* Checking Part Creation...", !FMDB_Part_Create(mesh, newPart));
  FMDB_Part_GetID(newPart, &part_id);
  CHECK ("\n* Checking Part ID...", part_id==1);  
  CHECK ("* Checking Part Deletion...", !FMDB_Part_Del(mesh, newPart));
  vector<pPart> parts;
  FMDB_Mesh_GetProcPart (mesh, procId, parts);
  part = parts.at(0);
  FMDB_Mesh_GetPart(mesh, 0, newPart);
  FMDB_Mesh_GetNumPart(mesh, procId, &i);
  CHECK ("* Checking Part Retrival...", parts.size()==1 && newPart==part && i==1);

/*************************************************************************
@  TAG FUNCTIONS:
@
@  FMDB_Tag_Create, FMDB_Tag_GetName, FMDB_Tag_GetType, FMDB_Tag_GetSize, 
@  FMDB_Tag_GetByte, FMDB_Tag_GetHandle, FMDB_Tag_Exist, FMDB_Tag_GetAllID
@ *************************************************************************/

  CHECK("\n* Creating Single Data Tags...", 
       !FMDB_Tag_Create (mesh, "byte", 0, 7, traceable, &byte_tag)
       && !FMDB_Tag_Create (mesh, "integer", 1 /* type=int */, 1, traceable, &int_tag) 
       && !FMDB_Tag_Create (mesh, "double", 2 /* type=double */, 1, traceable, &dbl_tag) 
       && !FMDB_Tag_Create (mesh, "entity", 3 /* type=entity */, 1, traceable, &ent_tag)
       && !FMDB_Tag_Create (mesh, "entity set", 4 /* type=entity set */, 1, traceable, &entset_tag));

  CHECK("* Checking Aborting Duplicate Tags...",
       FMDB_Tag_Create (mesh, "byte", 0, 7, traceable, &byte_tag) 
       && FMDB_Tag_Create (mesh, "integer", 1, 1, traceable, &int_tag) 
       && FMDB_Tag_Create (mesh, "double", 2, 1, traceable, &dbl_tag) 
       && FMDB_Tag_Create (mesh, "entity", 3, 1,traceable, &ent_tag) 
       && FMDB_Tag_Create (mesh, "entity set", 4, 1,traceable, &entset_tag));

  CHECK("\n* Creating Multiple Data (Array) Tags...", 
       !FMDB_Tag_Create (mesh, "integer array", 1, 3, traceable, &intarr_tag) 
       && !FMDB_Tag_Create (mesh, "double array", 2, 3, traceable, &dblarr_tag) 
       && !FMDB_Tag_Create (mesh, "entity array", 3, 3, traceable, &entarr_tag) 
       && !FMDB_Tag_Create (mesh, "entity set array", 4, 3, traceable, &entsetarr_tag));

  // verifying byte tag info
  FMDB_Tag_GetName(mesh, byte_tag, tag_name);
  FMDB_Tag_GetType (mesh, byte_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, byte_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, byte_tag, &tag_byte);
  CHECK ("* Verifying Byte Tag Information...",
         !strcmp(tag_name, "byte") && tag_type == 0 && tag_size == 7 && tag_size==tag_byte);

  // verifying int tag info
  FMDB_Tag_GetName(mesh, int_tag, tag_name);
  FMDB_Tag_GetType (mesh, int_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, int_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, int_tag, &tag_byte);
  CHECK("* Verifying Integer Tag Information...",
         !strcmp(tag_name, "integer") && tag_type == 1 
          && tag_size == 1 && tag_byte==tag_size*sizeof(int));
  
  // verifying double tag info
  FMDB_Tag_GetName(mesh, dbl_tag, tag_name);
  FMDB_Tag_GetType (mesh, dbl_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, dbl_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, dbl_tag, &tag_byte);
  CHECK("* Verifying Double Tag Information...",
        !strcmp(tag_name, "double") && tag_type == 2 
        && tag_size == 1 && tag_byte==tag_size*sizeof(double));

  // verifying entity tag info
  FMDB_Tag_GetName(mesh, ent_tag, tag_name);
  FMDB_Tag_GetType (mesh, ent_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, ent_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, ent_tag, &tag_byte);
  CHECK ("* Verifying Entity Tag Information...",
         !strcmp(tag_name, "entity") && tag_type == 3 
         && tag_size == 1 && tag_byte==tag_size*sizeof(void*));

  // verifying entity set tag info
  FMDB_Tag_GetName(mesh, entset_tag, tag_name);
  FMDB_Tag_GetType (mesh, entset_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, entset_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, entset_tag, &tag_byte);
  CHECK ("* Verifying Set Tag Information...", 
         !strcmp(tag_name, "entity set") && tag_type == 4 
         && tag_size == 1 && tag_byte==tag_size*sizeof(void*));

  // verifying integer array tag info
  FMDB_Tag_GetName(mesh, intarr_tag, tag_name);
  FMDB_Tag_GetType (mesh, intarr_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, intarr_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, intarr_tag, &tag_byte);
  CHECK ("* Verifying Integer Array Tag Information...", 
         !strcmp(tag_name, "integer array") && tag_type == 1 
         && tag_size == 3 && tag_byte==tag_size*sizeof(int));

  // verifying double array tag info
  FMDB_Tag_GetName(mesh, dblarr_tag, tag_name);
  FMDB_Tag_GetType (mesh, dblarr_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, dblarr_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, dblarr_tag, &tag_byte);
  CHECK ("* Verifying Double Array Tag Information...", 
         !strcmp(tag_name, "double array") && tag_type == 2 
         && tag_size == 3 && tag_byte==tag_size*sizeof(double));

  // verifying entity array tag info
  FMDB_Tag_GetName(mesh, entarr_tag, tag_name);
  FMDB_Tag_GetType (mesh, entarr_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, entarr_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, entarr_tag, &tag_byte);
  CHECK ("* Verifying Entity Array Tag Information...", 
         !strcmp(tag_name, "entity array") && tag_type == 3 
         && tag_size == 3 && tag_byte==tag_size*sizeof(void*));

  // verifying entity set array tag info
  FMDB_Tag_GetName(mesh, entsetarr_tag, tag_name);
  FMDB_Tag_GetType (mesh, entsetarr_tag, &tag_type);
  FMDB_Tag_GetSize (mesh, entsetarr_tag, &tag_size);
  FMDB_Tag_GetByte (mesh, entsetarr_tag, &tag_byte);
  CHECK ("* Verifying Set Array Tag Information...", 
         !strcmp(tag_name, "entity set array") && tag_type == 4 
         && tag_size == 3 && tag_byte==tag_size*sizeof(void*));

  FMDB_Tag_Exist(mesh, int_tag, &exist);
  CHECK ("\n* Checking Tag Existence...", exist);
  FMDB_Tag_GetHandle (mesh, "byte", &cloneTag);
  CHECK ("* Checking Tag Handle Retrieval by Name..", cloneTag == byte_tag);
  FMDB_Tag_GetAllID (mesh, tag_ids);
  CHECK ("* Checking All Tag Retrieval..", tag_ids.size()==9);

/*************************************************************************
@  MESH/MODEL INFO FUNCTIONS:
@
@  FMDB_Mesh_IsEmpty, FMDB_Mesh_GetGeomMdl, FMDB_Mesh_GetDim
@ *************************************************************************/
  FMDB_Mesh_IsEmpty(mesh, &i);
  CHECK ("* Checking Mesh Emptiness..", i==0);
  pGeomMdl geom;
  FMDB_Mesh_GetGeomMdl (mesh, geom);
  CHECK ("* Retrieving Geom Model...", geom==NULL);
  FMDB_Mesh_GetDim (mesh, &i);
  CHECK ("* Retrieving Mesh Dimension Information...", i > 0);    
  
/*************************************************************************
@  PART INFO FUNCTIONS:
@
@  FMDB_Part_GetDim, FMDB_Part_GetNumEnt, FMDB_Part_GetNumPartBdyEnt, 
@  FMDB_Part_SetEntID, 
@ *************************************************************************/

  for (iType=0; iType<4; ++iType)
  {
    FMDB_Part_GetNumEnt(part, iType, FMDB_ALLTOPO, &numType);
    num_type[iType] = numType;
    numTopo=0;
    for (iTopo=type_topo[iType]; iTopo<type_topo[iType+1]; ++iTopo)
    {
      FMDB_Part_GetNumEnt(part, iType, iTopo, &numEnt);
      numTopo += numEnt;
    }
    assert (numType==numTopo);
  }
  FMDB_Part_GetDim (part, &partDim);
  CHECK ("* Testing Part Dimension Information...", num_type[partDim] > 0);

  FMDB_Part_GetNumEnt(part, FMDB_ALLTYPE,  FMDB_ALLTOPO, &numType);
  FMDB_Part_GetNumEnt(part, FMDB_ALLTYPE, FMDB_ALLTOPO, &numTopo);
  CHECK ("* Checking Part Ent Type/Topo Functions...", numType==numTopo);

  FMDB_Part_SetEntID (part, 1);


/*************************************************************************
@  PART TAG FUNCTIONS:
@
@  FMDB_Part_Set/GetByteTag, FMDB_Part_Set/GetIntTag, FMDB_Part_Set/GetDblTag, 
@  FMDB_Part_Set/GetEntTag, FMDB_Part_Set/GetSetTag, FMDB_Part_Set/GetIntArrTag,
@  FMDB_Part_Set/GetDblArrTag, FMDB_Part_Set/GetEntArrTag, FMDB_Part_Set/GetSetArrTag
@  FMDB_Part_DelTag
@ *************************************************************************/

  int isEnd, iterEnd = FMDB_PartEntIter_Init (part, FMDB_EDGE, FMDB_ALLTOPO, iter, ent);
  
  CHECK ("\n* Checking Part Set Tag Functions...", !FMDB_Part_SetIntTag (part, int_tag, 1000) && !FMDB_Part_SetDblTag (part, dbl_tag, 1000.37) &&
        !FMDB_Part_SetEntTag (part, ent_tag, ent) && !FMDB_Part_SetByteTag (part, byte_tag, data, 7));  

  FMDB_Part_GetIntTag (part, int_tag, &int_data);
  FMDB_Part_GetDblTag (part, dbl_tag, &dbl_data);
  FMDB_Part_GetEntTag (part, ent_tag, &ent_data);

  void* byte_data = (void*)calloc(128, sizeof(char));
  FMDB_Part_GetByteTag (part, byte_tag, &byte_data, &byte_size);

  CHECK ("* Checking Part Get Tag Functions...", int_data == 1000 && dbl_data == 1000.37 && ent_data == ent && !strcmp((char*)byte_data, data) && byte_size==7);

  // FMDB_PartSet/GetByteTag with integer tag
  char byte_int_data[sizeof(int)];
  int* intPntData = new int(1000);
  char *charPntData = (char*)intPntData;
     
  for ( int i=0; i<sizeof(int); i++ )
    byte_int_data[i] =  charPntData[i];
  delete intPntData;

  FMDB_Part_SetByteTag(part, int_tag, byte_int_data, sizeof(int));
  FMDB_Part_GetByteTag (part, int_tag, &byte_data, &byte_size);
  CHECK ("* Checking Part Byte Tag Functions with Interger Tag...", 
        byte_size == (int)sizeof(int) && *(int*)byte_data == 1000);

  // FMDB_PartSet/GetByteTag with entity tag -- taken from iMesh compliance test
  int iNumChars = sizeof(void*);
  char aChars[iNumChars];
    {
      pMeshEnt* ppvData = new pMeshEnt(ent);
      char *pcData = (char*)ppvData;
      for ( int i=0; i<iNumChars; i++ )
        aChars[ i] =  pcData[i] ;
      delete ppvData;
    }
    FMDB_Part_SetByteTag(part, ent_tag, aChars, iNumChars);
    // ... then seeing if it comes back intact
    FMDB_Part_GetByteTag (part, ent_tag, &byte_data, &byte_size);
    CHECK ("* Checking Part Byte Tag Functions with Entity Tag...",  
           byte_size == sizeof(pMeshEnt) && ((pMeshEnt*)byte_data)[0] == ent);

  // FMDB_Part_Set/GetIntArrTag with integer arr tag
  int int_arr[] = {4,8,12};
  int arr_size;
  FMDB_Part_SetIntArrTag (part, intarr_tag, int_arr, 3);
  int* int_arr_back = new int[4];
  FMDB_Part_GetIntArrTag (part, intarr_tag, &int_arr_back, &arr_size);
  CHECK ("* Checking Part Integer Array Tag Functions...", 
         arr_size==3 && int_arr_back[0] == 4 && int_arr_back[1] == 8 && int_arr_back[2] == 12);
            
  // FMDB_PartSet/GetByteTag with integer arr tag
  char byte_intarr_data[sizeof(int)*3];
  charPntData = (char*)int_arr;  // {4,8,12}
     
  for ( int i=0; i<sizeof(int)*3; i++ )
    byte_intarr_data[i] =  charPntData[i];

  FMDB_Part_SetByteTag(part, intarr_tag, byte_intarr_data, sizeof(int)*3);
  FMDB_Part_GetByteTag (part, intarr_tag, &byte_data, &byte_size);

  CHECK ("\n * Cheking Part Byte Tag Functions with Interger Arr Tag...", 
        byte_size == sizeof(int)*3 && ((int*)byte_data)[0] == 4
        && ((int*)byte_data)[1]==8 && ((int*)byte_data)[2]==12);

  // FMDB_Part_Set/GetDblArrTag
  double dbl_arr[] = {4.1,8.2,12.3};
  FMDB_Part_SetDblArrTag (part, dblarr_tag, dbl_arr, 3);
  double* dbl_arr_back = new double[4];
  FMDB_Part_GetDblArrTag (part, dblarr_tag, &dbl_arr_back, &arr_size);
  CHECK ("* Checking Part Double Array Tag Functions...", 
         arr_size==3 && dbl_arr_back[0] == 4.1 && dbl_arr_back[1] == 8.2 && dbl_arr_back[2] == 12.3);

  // FMDB_PartSet/GetByteTag with double arr tag
  char byte_dblarr_data[sizeof(double)*3];
  charPntData = (char*)dbl_arr;  // {4.1,8.2,12.3}
     
  for ( int i=0; i<sizeof(double)*3; i++ )
    byte_dblarr_data[i] =  charPntData[i];

  FMDB_Part_SetByteTag(part, dblarr_tag, byte_dblarr_data, sizeof(double)*3);
  FMDB_Part_GetByteTag (part, dblarr_tag, &byte_data, &byte_size);

  CHECK ("* Cheking Part Byte Tag Functions with Double Arr Tag...", 
        byte_size == sizeof(double)*3 && ((double*)byte_data)[0] == 4.1
        && ((double*)byte_data)[1]==8.2 && ((double*)byte_data)[2]==12.3);

  // FMDB_Part_Set/GetEntArrTag
  pMeshEnt* ent_arr = new pMeshEnt[3];
  ent_arr[0] = ent_arr[1] = ent_arr[2] = ent;
  FMDB_Part_SetEntArrTag (part, entarr_tag, ent_arr, 3);
  pMeshEnt* ent_arr_back = new pMeshEnt[4];
  FMDB_Part_GetEntArrTag (part, entarr_tag, &ent_arr_back, &arr_size);
  CHECK ("* Checking Part Entity Array Tag Functions...", 
         arr_size==3 && ent_arr_back[0] == ent && ent_arr_back[1] == ent && ent_arr_back[2] == ent
          && ent_arr[0]==ent_arr_back[0] && ent_arr[1]==ent_arr_back[1] && ent_arr[2] == ent_arr_back[2]);

  // FMDB_PartSet/GetByteTag with entity arr tag
  char byte_entarr_data[sizeof(pMeshEnt)*3];
  charPntData = (char*)ent_arr;  // {ent, ent, ent}
     
  for ( int i=0; i<sizeof(pMeshEnt)*3; i++ )
    byte_entarr_data[i] =  charPntData[i];

  FMDB_Part_SetByteTag(part, entarr_tag, byte_entarr_data, sizeof(pMeshEnt)*3);
  FMDB_Part_GetByteTag (part, entarr_tag, &byte_data, &byte_size);
  CHECK ("\n * Cheking Part Byte Tag Functions with Entity Arr Tag...", 
        byte_size == sizeof(pMeshEnt)*3 && ((pMeshEnt*)byte_data)[0] == ent
        && ((pMeshEnt*)byte_data)[1]==ent && ((pMeshEnt*)byte_data)[2]==ent);

  // FMDB_Part_DelTag
  CHECK ("\n* Checking Part Tag Deletion...", !FMDB_Part_DelTag (part, byte_tag)
        && !FMDB_Part_DelTag (part, int_tag) 
        && !FMDB_Part_DelTag (part, dbl_tag) 
        && !FMDB_Part_DelTag (part, ent_tag) 
        && !FMDB_Part_DelTag (part, intarr_tag)
        && !FMDB_Part_DelTag (part, dblarr_tag)
        && !FMDB_Part_DelTag (part, entarr_tag));

/*************************************************************************
@  PART ITERATOR/TAG FUNCTIONS:
@
@  FMDB_PartEntIter_Init, FMDB_PartEntIter_IsEnd, FMDB_PartEntIter_GetNext
@  FMDB_PartEntIter_Reset
@ *************************************************************************/

/*************************************************************************
@  ENTITY TAG FUNCTIONS:
@
@  FMDB_Ent_Set/GetByteTag, FMDB_Ent_Set/GetIntTag, FMDB_Ent_Set/GetDblTag, 
@  FMDB_Ent_Set/GetEntTag, FMDB_Ent_DelTag
@ *************************************************************************/

  iterEnd = FMDB_PartEntIter_Init (part, FMDB_EDGE,  FMDB_ALLTOPO, iter, ent);
  FMDB_PartEntIter_IsEnd(iter, &isEnd);
  CHECK("\n* Getting edge iterator on part...", !iterEnd && !isEnd);

  int loop_counter=0;
  while (!iterEnd)
  {
    edges.push_back(ent);
    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
    ++loop_counter;
  }
  FMDB_PartEntIter_IsEnd(iter, &isEnd);
  FMDB_PartEntIter_Del (iter);
  CHECK ("* Checking Part Entity Traversal Through Iterator...", isEnd && loop_counter==num_type[1]);

  iterEnd = FMDB_PartEntIter_Init (part, FMDB_VERTEX,  FMDB_ALLTOPO, iter, ent);
  CHECK("\n* Getting vertex iterator on part...", !iterEnd);
  loop_counter=0;
  while (!iterEnd)
  {
    ID = FMDB_Ent_GetID (ent);
    if (ID<num_type[0]/4)
      FMDB_Ent_SetIntTag (mesh, ent, int_tag, ID);
    else if (num_type[0]/4<=ID && ID<(num_type[0]/4)*2)
      FMDB_Ent_SetDblTag (mesh, ent, dbl_tag, (double)ID*1.5);
    else if ((num_type[0]/4)*2<=ID && ID<(num_type[0]/4)*3)
      FMDB_Ent_SetEntTag (mesh, ent, ent_tag, edges.at(ID));
    else
      assert(!FMDB_Ent_SetByteTag (mesh, ent, byte_tag, data, 7)); 
  
    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
    ++loop_counter;
  }
  CHECK ("* Checking Part Traversal Functions...", loop_counter==num_type[0]); 
  CHECK ("\n* Checking Ent Set Tag Functions...", 1);

  iterEnd = FMDB_PartEntIter_Reset(iter, ent);
  CHECK("* Resetting vertex iterator on part...", !iterEnd);
  while (!iterEnd)
  {
    ID = FMDB_Ent_GetID (ent);
    if (ID<num_type[0]/4)
    {
      FMDB_Ent_GetIntTag (mesh, ent, int_tag, &int_data);
      assert (int_data == ID);
    }
    else if (num_type[0]/4<=ID && ID<(num_type[0]/4)*2)
    {
      FMDB_Ent_GetDblTag (mesh, ent, dbl_tag, &dbl_data);
      assert(dbl_data == (double)ID*1.5);
    }
    else if ((num_type[0]/4)*2<=ID && ID<(num_type[0]/4)*3)
    {
      FMDB_Ent_GetEntTag (mesh, ent, ent_tag, &ent_data);
      assert(ent_data == edges.at(ID));
    }
    else
    {
      assert(!FMDB_Ent_GetByteTag (mesh, ent, byte_tag, &byte_data, &byte_size));
      assert(!strcmp((char*)byte_data, data) && byte_size==7);
    }

    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
  }
  CHECK ("* Checking Ent Get Tag Functions...", 1);

  iterEnd = FMDB_PartEntIter_Reset(iter, ent);
  CHECK("* Resetting vertex iterator on part again...", !iterEnd);
  while (!iterEnd)
  {   
    ID = FMDB_Ent_GetID(ent);
    if (ID<num_type[0]/4) 
      FMDB_Ent_DelTag(ent, int_tag);
    else if (num_type[0]/4<=ID && ID<(num_type[0]/4)*2)
      FMDB_Ent_DelTag(ent, dbl_tag);
    else if ((num_type[0]/4)*2<=ID && ID<(num_type[0]/4)*3)
      FMDB_Ent_DelTag(ent, ent_tag);
    else
      FMDB_Ent_DelTag(ent, byte_tag);
    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
  }   
  cout<<endl;
  CHECK ("\n* Deleting Ent Tag Data...", 1);

  CHECK ("\n* Checking Tag File Output...", !FMDB_Mesh_WriteToFile(mesh, out_file, numProc-1));

/*************************************************************************
@  ENTITY ADJ FUNCTIONS:
@
@  FMDB_Ent_GetNumAdj, FMDB_Ent_GetAdj, FMDB_Ent_Get2ndAdj
@ *************************************************************************/

  pPartEntIter entIter; 
  vector<pMeshEnt> adjEnts;
  for (i=0; i<4; ++i)
  {
    iterEnd = FMDB_PartEntIter_Init (part, i,  FMDB_ALLTOPO, entIter, ent);
    failed=0;
    while (!iterEnd)
    {
      for (j=0; j<=4; ++j)
      {
        if (i==j) continue;
        adjEnts.clear();
        failed += FMDB_Ent_GetAdj(ent, j, 1, adjEnts);
        FMDB_Ent_GetNumAdj (ent, j, &k);
        if (adjEnts.size()!=k) ++failed;
      }
      iterEnd = FMDB_PartEntIter_GetNext(entIter, ent);
    }
    FMDB_PartEntIter_Del (entIter);
    switch (i)
    {
      case 0: CHECK ("* Checking Vertex Adjacency...", !failed); break;
      case 1: CHECK ("* Checking Edge Adjacency...", !failed); break;
      case 2: CHECK ("* Checking Face Adjacency...", !failed); break;
      case 3: CHECK ("* Checking Region Adjacency...", !failed); break;
    }
  }  // for i

  for (int i=0; i<1; ++i)
  {
    iterEnd = FMDB_PartEntIter_Init (part, i, FMDB_ALLTOPO, entIter, ent);
    failed=0;
    while (!iterEnd)
    {
      for (int brgType=0; brgType<=4; ++brgType)
        for (int tgtType=0; tgtType<=4; ++tgtType)
        {
          if (brgType==tgtType && brgType!=4) continue;
          adjEnts.clear();
          failed += FMDB_Ent_Get2ndAdj(ent, brgType, tgtType, adjEnts);
        }
      iterEnd = FMDB_PartEntIter_GetNext(entIter, ent);
    } // while
    FMDB_PartEntIter_Del (entIter);
    switch (i)
    {
      case 0: CHECK ("* Checking Vertex 2nd Adjacency...", !failed); break;
      case 1: CHECK ("* Checking Edge 2nd Adjacency...", !failed); break;
      case 2: CHECK ("* Checking Face 2nd Adjacency...", !failed); break;
      case 3: CHECK ("* Checking Region 2nd Adjacency...", !failed); break;
    }
  }  // for i

/*************************************************************************
@  NON-PO SET FUNCTIONS:
@
@  FMDB_Ent_GetNumAdj, FMDB_Ent_GetAdj, FMDB_Ent_Get2ndAdj
@ *************************************************************************/

  int initNumEntSet; 
  FMDB_Mesh_GetNumSet (mesh, &initNumEntSet);
  pEntSet listEntSet;
  pEntSet setEntSet;
  FMDB_Set_NonPO_Create(mesh, /*list*/ 1, listEntSet);
  FMDB_Set_NonPO_Create(mesh, /*set*/0, setEntSet);
  
  FMDB_Set_IsList (listEntSet, &isList);
  CHECK ("\n* Creating List-type Set...", isList);
  FMDB_Set_IsList (setEntSet, &isList);
  CHECK ("* Creating Set-type Set...", !isList);

  FMDB_Mesh_SetSetID (mesh);
  CHECK ("\n* Testing Set ID Functions...",  
         FMDB_Set_GetID (listEntSet)==initNumEntSet+1 && FMDB_Set_GetID (setEntSet)==initNumEntSet+2);

  FMDB_Mesh_GetNumSet (mesh, &numEntSet);
  CHECK ("* Checking Set Information...", initNumEntSet+2==numEntSet);

  iterEnd = FMDB_PartEntIter_Reset(iter, ent);
  while (!iterEnd)
  {  
    FMDB_Set_AddEnt (listEntSet, ent);
    FMDB_Set_AddEnt (listEntSet, ent);
    FMDB_Set_AddEnt (setEntSet, ent);
    FMDB_Set_AddEnt (setEntSet, ent);
    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
  }
  FMDB_Set_GetNumEnt (listEntSet, &numEnt);
  CHECK ("* Checking List-type Set Data Insertion...", numEnt==num_type[0]*2);
  FMDB_Set_GetNumEnt (setEntSet, &numEnt);
  CHECK ("* Checking Set-type Set Data Insertion...", numEnt==num_type[0]);

  iterEnd = FMDB_PartEntIter_Reset(iter, ent);
  int list_flag=1, set_flag=1;
  while (!iterEnd)
  {
    FMDB_Set_HasEnt (listEntSet, ent, &hasEnt);
    if (!hasEnt) list_flag=0;
    FMDB_Set_RmvEnt (listEntSet, ent); 
    FMDB_Set_HasEnt (listEntSet, ent, &hasEnt);
    if (!hasEnt) list_flag=0;

    FMDB_Set_HasEnt (listEntSet, ent, &hasEnt);
    if (!hasEnt) set_flag=0;
    FMDB_Set_RmvEnt (setEntSet, ent); 
    FMDB_Set_HasEnt (setEntSet, ent, &hasEnt);
    if (hasEnt) set_flag=0;
    iterEnd = FMDB_PartEntIter_GetNext(iter, ent);
  }
  CHECK ("* Checking List-type Set Data Removal...", list_flag); 
  CHECK ("* Checking Set-type Set Data Removal...", set_flag);

  pSetEntIter esIter;
  iterEnd = FMDB_SetEntIter_Init (listEntSet, FMDB_ALLTYPE, FMDB_POINT, esIter, ent);
 
  CHECK ("\n* Checking Set SetTag Functions...", !FMDB_Set_SetIntTag (listEntSet, int_tag, 1000) && !FMDB_Set_SetDblTag (listEntSet, dbl_tag, 1000.37) &&
        !FMDB_Set_SetEntTag (listEntSet, ent_tag, ent) && 
        !FMDB_Set_SetByteTag (listEntSet, byte_tag, data, 7));
    
  FMDB_Set_GetIntTag (listEntSet, int_tag, &int_data);
  FMDB_Set_GetDblTag (listEntSet, dbl_tag, &dbl_data);
  FMDB_Set_GetEntTag (listEntSet, ent_tag, &ent_data);
  FMDB_Set_GetByteTag (listEntSet, byte_tag, &byte_data, &byte_size);
  CHECK ("* Checking Set GetTag Functions...", int_data == 1000 && dbl_data == 1000.37 && ent_data == ent && !strcmp((char*)byte_data, data) && byte_size==7);

  CHECK ("* Checking Set Tag Deletion...", !FMDB_Set_DelTag (listEntSet, int_tag) &&
        !FMDB_Set_DelTag (listEntSet, dbl_tag) && !FMDB_Set_DelTag (listEntSet, ent_tag) &&
        !FMDB_Set_DelTag (listEntSet, byte_tag));

  CHECK ("\n* Checking Set File Output...", !FMDB_Mesh_WriteToFile(mesh, out_file, numProc-1));
    
  loop_counter=0;
  while (!iterEnd)
  {
    ++loop_counter;
    iterEnd = FMDB_SetEntIter_GetNext(esIter, ent);
  }
  CHECK ("\n* Checking List-type Set Traversal...", loop_counter==num_type[0]);
  FMDB_SetEntIter_Del (esIter);

  loop_counter=0;
  iterEnd = FMDB_SetEntIter_Init (setEntSet, FMDB_VERTEX,  FMDB_ALLTOPO, esIter, ent);
  while (!iterEnd)
  {
    ++loop_counter;
    iterEnd = FMDB_SetEntIter_GetNext(esIter, ent);
  }
  FMDB_SetEntIter_IsEnd (esIter, &isEnd);
  CHECK ("* Checking Set-type Set Traversal...", isEnd & loop_counter==0);

// delete array
  delete [] ent_arr;
  delete [] int_arr_back;
  delete [] dbl_arr_back;
  delete [] ent_arr_back;
  delete [] byte_data;
  edges.clear();

  CHECK ("\n* Deleting Ent ID...", !FMDB_Part_DelEntID (part, 1));
  CHECK ("\n* Deleting Set ID...",  !FMDB_Mesh_DelSetID(mesh));
  CHECK ("\n* Deleting Set-type Set...", !FMDB_Set_Del (mesh, part, setEntSet));
  CHECK ("* Deleting List-type Set...", !FMDB_Set_Del (mesh, part, listEntSet));

  CHECK ("\n* Deleting Set Entity Iterator...", !FMDB_SetEntIter_Del (esIter));

  CHECK ("\n* Deleting Byte Tag...", !FMDB_Tag_Del (mesh, &byte_tag, forceDel));
  CHECK ("* Deleting Integer Tag...", !FMDB_Tag_Del (mesh, &int_tag, forceDel));
  CHECK ("* Deleting Double Tag...", !FMDB_Tag_Del (mesh, &dbl_tag, forceDel));
  CHECK ("* Deleting Entity Tag...", !FMDB_Tag_Del (mesh, &ent_tag, forceDel));
  CHECK ("* Deleting Set Tag...", !FMDB_Tag_Del (mesh, &entset_tag, forceDel));

  CHECK ("* Deleting Integer Array Tag...", !FMDB_Tag_Del (mesh, &intarr_tag, forceDel));
  CHECK ("* Deleting Double Array Tag...", !FMDB_Tag_Del (mesh, &dblarr_tag, forceDel));
  CHECK ("* Deleting Entity Array Tag...", !FMDB_Tag_Del (mesh, &entarr_tag, forceDel));
  CHECK ("* Deleting Set Array Tag...", !FMDB_Tag_Del (mesh, &entsetarr_tag, forceDel));

  CHECK ("\n* Deleting FMDB Mesh Instance...", !FMDB_Mesh_Del (mesh));
  CHECK ("\n* Finalizing FMDB Service...", !FMDB_Finalize());
  cout<<endl;

  cout<<"\n***** MEMORY STAT @ END OF TEST_MESH *****\n"; 
  malloc_stats();
  return 0;
}

