/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/

#include <iostream>
#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include "FMDB.h"

using std::cout;
using std::endl;
using std::vector;

void CHECK(char *msg, int oK, ...)
{     
  assert(oK);

  char buff[1024];
  va_list  args;
  va_start (args, msg);
  vsprintf(buff, msg, args);
  va_end (args);
  if (oK)
    fprintf(stdout,"%s OK \n",buff);
  else
    fprintf(stdout,"%s FAILED\n", buff);
  fflush(stdout);
}

int TEST_MESH(int argc, char *argv[], const char* mesh_file, const char* out_file);


int main (int argc, char *argv[])
{
  FMDB_Init(MPI_COMM_WORLD);
  int numProc, mypid;
  FMDB_GetNumProc(&numProc);
  
  FMDB_GetProcID(&mypid);

  bool ghostFlag=false;
  if (argc<4)
  {
    if (!mypid)
      cout<<"ERROR: INSUFFICIENT INPUT ARGUMENTS\n       ./main mesh_file out_file distributed(0/1) #migration (default=100) ghosting(0/1)\n";
    FMDB_Finalize();
    return 1;
  }
  if (argc>5)
    ghostFlag=atoi(argv[5]);
/*
  int i;
  if (!mypid)
  {
    cout<<"Enter a digit..";
    cin>>i;
  }
  else
    cout<<"\nwaiting...";
  cout<<"\n";
  FMDB_Sync();
*/
  if (!mypid)
  {
    cout<<"\n***** MEMORY STAT @ BEGIN OF TEST_MESH *****\n"; 
    malloc_stats();
  }

// FMDB system level functions
  int ierr;
  if (!mypid) 
  {
    cout<<"\n***** SYS FUNCTIONS *****\n"; 
    cout<<"Running Test on "<<numProc<<" processes\n";
  }
  double time;
  FMDB_GetWTime(&time);

// FMDB mesh functions
  if (!mypid)  cout<<"\n***** MESH/PART FUNCTIONS *****\n"; 

  pGModel model=NULL;
  pMeshMdl mesh;
  FMDB_Mesh_Create (model, mesh);
  ierr = FMDB_Mesh_LoadFromFile (mesh, argv[1], atoi(argv[3]));
  if(ierr != 0)
    {
      cout << "\n File not found: " << argv[1] << endl;
      FMDB_Mesh_Del(mesh);
      FMDB_Finalize();
      return SCUtil_FILE_NOT_FOUND;
    }
  FMDB_Mesh_DspNumEnt (mesh);
//  if (!strcmp(argv[1], "../meshes/plate_14f.sms"))
//    FMDB_Mesh_DspAllEnt (mesh);
  
  pPart part;

  int isValid=0; 
  FMDB_Mesh_Verify(mesh, &isValid);

  if (!isValid) 
  { 
    if (!mypid) cout<<"The Mesh is non-manifold or invalid.. \nStop testing.. Please check with mesh provider for its validity.\n";
    FMDB_Mesh_Del (mesh);
    FMDB_Finalize();
    return 0;
  }
  else 
    if (!mypid) CHECK("\n* Checking Mesh Validity...", isValid);

  std::vector<pPart> vecPart;
  FMDB_Mesh_GetProcPart (mesh, mypid, vecPart);
  if (!mypid) CHECK("\n* Checking #parts on local proc...", vecPart.size());
  
  /* Mesh/Part traversal (part boundary iterator)*/
  /// For each part on the meshModel, get part boundary entities of different types 
  int iIsEnd = 0;

  for (vector<pPart>::iterator It = vecPart.begin(); It != vecPart.end(); It++ )
  {
    part = (pPart)(*It);
    int iPartId;
    FMDB_Part_GetID(part, &iPartId);
     
    set<pMeshEnt> bdryEnts;

    for(int type = 0; type < 3; type++)
    {
      pPartEntIter pBdryIter;
      pMeshEnt pEnt;
      iIsEnd = FMDB_PartEntIter_InitPartBdry(part, -1, type, FMDB_ALLTOPO, pBdryIter, pEnt); 
      while(!iIsEnd)
      {
        /* Cross check if the entity is on part boundary */
	int isOnPrtBdry;
        FMDB_Ent_IsOnPartBdry (pEnt, &isOnPrtBdry);
	assert(isOnPrtBdry == 1);

	/* Get next entity on part boundary having dimension type. Store the boundary entities*/
	bdryEnts.insert(pEnt);
	iIsEnd = FMDB_PartEntIter_GetNext(pBdryIter, pEnt);
      }       
      FMDB_PartEntIter_Del (pBdryIter);
    }
    if (!mypid) CHECK ("\n* Checking Part Boundary Traversal...", 1);
  
    /* Distributed entity functions (ownership, remote copies, ghosts)*/
    set<pMeshEnt>::iterator itSet;
    for(itSet = bdryEnts.begin(); itSet != bdryEnts.end(); itSet++)
    {
      pMeshEnt pEnt = *itSet;
      
      /* Now for each part boundary entity in the set, get its owning part id */
      int iOwnerPrt;
      FMDB_Ent_GetOwnPartID(pEnt, &iOwnerPrt);

      /* If the entity is a copy on local part then get its owning entity */
     
      if(iOwnerPrt != iPartId)
      {
        pMeshEnt pOwnerEnt;
        FMDB_Ent_GetOwnEnt(pEnt, pOwnerEnt);
        assert(pOwnerEnt != NULL);
      }

      /* Get all remote copies of the part boundary entity */    
      vector<pair<int, pMeshEnt> > vecRmtCpy;
      FMDB_Ent_GetRmt(pEnt, vecRmtCpy);
      
      /* Now iterate through the remote copies of each entity.*/
      vector<pair<int, pMeshEnt> >::iterator itVec;

      for(itVec = vecRmtCpy.begin(); itVec != vecRmtCpy.end(); itVec++ )
      {
        int pid = itVec->first;
	pMeshEnt pRmt = itVec->second;

        /* There should exist a remote copy on pid then, Cross-check with function 
           GetRmtCopyOnPart(A O(1) operation for getting remote copy on a target part id) */
    	pMeshEnt pRmtCopy;
        FMDB_Ent_GetRmtOnPart(pEnt, pid, pRmtCopy);
        assert(pRmtCopy == pRmt);
      }
  
      /*Now get the number of remote copies for each entity */
      int iNumRmtCopies;
      FMDB_Ent_GetNumRmt(pEnt, &iNumRmtCopies);
      assert(iNumRmtCopies == vecRmtCpy.size());

      /* Clear all remote copies */
      FMDB_Ent_ClrRmt(pEnt);
    
      // Now get number of remote copies again, should be zero now
      int iNumRmtEmpty;
      FMDB_Ent_GetNumRmt(pEnt, &iNumRmtEmpty);
      assert(iNumRmtEmpty == 0);     

      // Now add the remote copies again
      for(itVec = vecRmtCpy.begin(); itVec != vecRmtCpy.end(); itVec++ )
      {
	int pid = itVec->first;
        pMeshEnt pRmt = itVec->second;
        FMDB_Ent_AddRmt(pEnt, pid, pRmt);
      }
  
      // Get the number of remote copies again
      int iNumRmtCopiesN;
      FMDB_Ent_GetNumRmt(pEnt, &iNumRmtCopiesN);
      assert(iNumRmtCopiesN == iNumRmtCopies);

      vecRmtCpy.clear();
    } 
    bdryEnts.clear();
  }

  FMDB_Sync();

  // START MIGRATION & LOAD BALANCING TEST
  int numMigr=0;

  if (argc>4)
    numMigr=atoi(argv[4]);

  MigrCB cb;
  int meshDim;    
  FMDB_Mesh_GetDim (mesh, &meshDim);

  if (numProc>1 && numMigr)
  {
    if (!mypid) cout<<"\n **** START MIGRATION & LOAD BALANCING TEST ***\n";

  // get the PO to migrate (we do neighborhood migration)
  int owner, pid;
  for (int iter=0; iter<numMigr;++iter) // loop over niter times
  {
    if (!mypid) cout<<"\n*** "<<iter<<"'th migration ***\n";
    std::map<mEntity*, int> POsToMove[1];

    pMeshEnt ent;
    pPartEntIter entIter;

    int isEnd = FMDB_PartEntIter_Init (part, meshDim, FMDB_ALLTOPO, entIter, ent);
    int loop_counter = 0;

    while(!isEnd)
    {
      if (rand()%3==1)
        POsToMove[0][ent] =rand()%numProc;
      isEnd = FMDB_PartEntIter_GetNext(entIter, ent);
      ++loop_counter;
    }
    FMDB_PartEntIter_Del (entIter);
    FMDB_Mesh_Migr(mesh, cb, POsToMove);
    FMDB_Mesh_DspNumEnt (mesh);
    FMDB_Mesh_Verify(mesh, &isValid);
    if (!mypid) CHECK("\n* Checking Re-partitioned Mesh Validity...", isValid);

/*
    if (!strcmp(argv[1], "../meshes/plate_14f.sms"))
      FMDB_Mesh_DspAllEnt (mesh);
*/
  
    if ((iter+1)%10==0)
    {
      if (!mypid) cout<<"LOADBALANCE\n";
      FMDB_Mesh_GlobPtn (mesh, cb);
      FMDB_Mesh_Verify(mesh, &isValid);
      if (!mypid) CHECK("\n* Checking Re-partitioned Mesh Validity...", isValid);
    }
  }  // end of for loop
   /*          
  switch (atoi(argv[4]))
  {          
    case 0:  break;
    case 1:  PM_merge(mesh);
             if (P_pid()==0)
               M_writeSMS(mesh, "single.sms");
             break;
    case 2:  PM_write(mesh, "dist.sms");
             break;
    default: break;
  } */
  }

  FMDB_Sync();

  if (ghostFlag)
  {

    CHECK("\n* TESTING GHOST...",1);

     /* Create ghost entities for permissible combinations of ghost & bridge types*/
    int numLayer = 1;
    for(int iGhostType = 1; iGhostType <= meshDim; iGhostType++)
    {
      for(int iBrgType = 0; iBrgType < iGhostType; iBrgType++)
      {
        for(int include_copy = 0; include_copy <= 1; include_copy++)
        {
          FMDB_Mesh_CreateGhost(mesh, cb, iGhostType, iBrgType, numLayer, include_copy);
        
          FMDB_Mesh_DelGhost(mesh);
        }
      }
    }
  }

  FMDB_Mesh_Del (mesh);

  FMDB_Finalize();

  if (!mypid)
  {
    cout<<"\n***** MEM STAT *****\n";
    malloc_stats();
  }

  return 0;
}
