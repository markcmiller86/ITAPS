/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifndef _M_MIGRATION_H_
#define _M_MIGRATION_H_

#include <vector>
#include <map>
#include "mPart.h"
#include "mEntity.h"
#include "mEntityGroup.h"

#ifdef FMDB_PARALLEL

struct ent_struct
{
  mEntity *sender;
  short int numDE;
  short int gTag;
  short int gType;
  short int numRC;
  short int numBP;
#ifdef MATCHING
  int numMatch;
#endif
}__attribute__((aligned (8)));

struct vtx_struct
{
  double coord[3];
  int iD;
  short int numParam;
#ifdef MATCHING
  int numMatch;
#endif
}__attribute__((aligned (8))); 

struct exchg_struct_2
{
  mEntity* ent1;
  int pid;
  mEntity* ent2;
  exchg_struct_2(mEntity* e1, int i, mEntity* e2): ent1(e1), pid(i), ent2(e2){}
};

struct exchg_struct_3
{
  mEntity* ent1;
  int dest;
  mEntity* ent2;
  int src;    
  exchg_struct_3(mEntity* e1, int i, mEntity* e2, int j): ent1(e1), dest(i), ent2(e2), src(j){}
};



int _migrateMesh(vector<mPart*>& meshes,
                        map<mEntity*,int*>& POtoMove,
			map<mEntityGroup*,int*>& EntGrpToMove, 
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE,
                        std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG,
			std::vector<mEntityGroup*>& newEG);

void _exchangeEnt (vector<mPart*>& meshes, int meshDim, pmMigrationCallbacks &cb,
                     int entDim, map<mEntity*,int>& entitiesToSend,
                     list<mEntity*>* newE, std::vector<mEntityGroup*>& newEG);

void _collectEntToMigrate (int meshDim, map<mEntity*,int*>& POToMove,
             map<mEntity*,int>* entitiesToHandle);

void _collectEntToRemove(map<mEntity*,int>* entitiesToHandle, 
			 map<mEntity*,int>* entitiesToRemove);

void _removeEnt(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb,
                          int dim, map<mEntity*,int>* entitiesToRemove);

#endif
#endif
