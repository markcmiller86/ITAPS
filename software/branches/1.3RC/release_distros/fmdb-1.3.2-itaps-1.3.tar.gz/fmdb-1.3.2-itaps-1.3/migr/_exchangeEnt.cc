/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#include "mMigration.h"
#include "mEntity.h"
#include "ParUtil.h"
#include "FMDB_cint.h"
#include "FMDB.h"
#include "mVertex.h"
#include "pmModel.h"

#ifdef FMDB_PARALLEL
// **********************************************
//    forward function declaration
// **********************************************
void _exchangeEntitiesToBounce(list<exchg_struct_3>&);
void _exchangeEntitiesToBroadcast(list<exchg_struct_2>& entitiesToBroadcast);

void _pack_MEntity(mEntity *ent, int pid, int src, pmMigrationCallbacks &cb, void *&msg_send, int &msg_size, int meshDim);
void _unpack_MEntity(mPart* mesh, int meshDim, void *msg_recv, int pid,
                    pmMigrationCallbacks &cb, std::list<mEntity*>* newE, 
                    std::list<exchg_struct_3>& entitiesToBounce,
                    std::map<pair<mEntityGroup*, int>, mEntityGroup*>& entGrpMap);
		  		       
void _set_subtract(set<int> A, set<int> B, set<int>& C)
{
  set<int>::iterator aiter, biter;
  for (aiter=A.begin(); aiter!=A.end();++aiter)
  {
    biter = B.find(*aiter);
    if (biter==B.end()) C.insert(*aiter);
  }
}
// **********************************************
void  _exchangeEnt (vector<mPart*>& meshes, int meshDim, pmMigrationCallbacks &cb,
		     int entDim, map<mEntity*,int>& entitiesToSend, 
		     list<mEntity*>* newE, std::vector<mEntityGroup*>& newEG)
// **********************************************
{
  mEntity* ent;
  set<int>::iterator piter;
  int pid,newPid;
  int mypid=ParUtil::Instance()->rank();
  
  map<mEntity*, int>::const_iterator eit; 
  map<int, mEntity*>::iterator rcIter; 

  int numPart =  ParUtil::Instance()->getCurNumParts();
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();
  
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::All_Reduce);
  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  int num_sent = 0, num_recvd = 0;

  set<int> RCs, newRCs, temp; 
  set<int>::iterator bpIter; 
  for(eit=entitiesToSend.begin(); eit!=entitiesToSend.end();++eit)
    {
      ent = eit->first; 
      int lid = eit->second;                   // current local pid 
      int src = mypid*numPart+lid;             // current global pid
      RCs.clear(); 
      newRCs.clear(); 
      temp.clear(); 

      if(numPart==tgtNumPart) {
        ent->getPidsExist(newRCs);
        newRCs.insert(src);
        set<int>::iterator minit=std::min_element(newRCs.begin(),newRCs.end());
        if(src!=(*minit))
          continue;
      }
      else {
	 ent->getPidsExist(newRCs); 
	 for(bpIter=newRCs.begin(); bpIter!=newRCs.end(); ++bpIter) {
	   newPid=*bpIter; 	 
	   newRCs.insert(newPid); 
	   pid = (newPid/tgtNumPart)*numPart + newPid%tgtNumPart;          // original global pid 
	   RCs.insert(pid);
	 }
      
      // decide the broadcaster through current(original) pids of RCs 
	 RCs.insert(src); 
	 set<int>::iterator minit=std::min_element(RCs.begin(),RCs.end());
	 if(src!=(*minit))
	   continue;
      
	 newRCs.insert(mypid*tgtNumPart+lid);         // updated source pid if the source exists in the new partition
      }

      if(ent->tempBPs==NULL)
         temp.clear();
      else
         _set_subtract(*(ent->tempBPs),newRCs,temp);
 
      for (piter=temp.begin(); piter!=temp.end();++piter)
      {	      
        pid = *piter; 
        void *msg_send;
	int msg_size; 
        _pack_MEntity(ent,pid, lid, cb, msg_send, msg_size, meshDim);
        CM->send(pid/tgtNumPart, msg_send, msg_size);
        num_sent++;
	CM->free_msg(msg_send); 
      }
    }
  CM->finalize_send();

  map<pair<mEntityGroup*, int>, mEntityGroup*> entGrpMap; 

   // receive phase begins
  void *msg_recv;
  int pid_from;
  mPart* tgtMesh; 
  list<exchg_struct_3> entitiesToBounce;

  while(int rc = CM->receive(msg_recv, &pid_from))
   {
        num_recvd++; 
	
	// get the local part mesh 
	int* tmp_ptr = (int*)msg_recv;  
	int dest = *tmp_ptr; 
	if((ParUtil::Instance()->localPids).size()==0)
          tgtMesh = meshes[dest%tgtNumPart]; 	
        else {
	  int ipart; 
          int partSize = (ParUtil::Instance()->localPids).size(); 
	  for(ipart=0; ipart<partSize; ++ipart){
	    if((ParUtil::Instance()->localPids)[ipart]==(dest%tgtNumPart) || (ParUtil::Instance()->localPids)[ipart]+partSize==(dest%tgtNumPart)) {
	      tgtMesh = meshes[ipart]; 
	      break; 
	    }
	  }   
	  if(ipart==partSize) 
          {
            cout<<"Invalid destination part id received during mesh entity migration\n";
	    throw 1; 
          }
        }
	 
        _unpack_MEntity(tgtMesh,meshDim,msg_recv, pid_from, cb, newE, entitiesToBounce, entGrpMap);
        CM->free_msg(msg_recv);
      }

    map<pair<mEntityGroup*, int>, mEntityGroup*>::iterator entGrpMap_iter; 
    for(entGrpMap_iter=entGrpMap.begin(); entGrpMap_iter!=entGrpMap.end(); ++entGrpMap_iter)
      newEG.push_back(entGrpMap_iter->second); // collect new entity group

    if (meshDim > entDim)
      _exchangeEntitiesToBounce(entitiesToBounce);
}

// **********************************************
void _exchangeEntitiesToBounce(list<exchg_struct_2>& entitiesToBounce)
// **********************************************
{

  int msg_size = 2*sizeof(mEntity*);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  mEntity** msg_send = (mEntity**)CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;

  list<exchg_struct_2>::const_iterator rcvIter;
  for (rcvIter=entitiesToBounce.begin(); rcvIter!=entitiesToBounce.end();++rcvIter)
  {
    msg_send[0] = rcvIter->ent1;
    msg_send[1] = rcvIter->ent2;
    CM->send(rcvIter->pid, (void*)msg_send);
  }

  list<exchg_struct_2> entitiesToBroadcast;
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  mEntity** castbuf;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    castbuf = (mEntity**)msg_recv;
    castbuf[1]->addRemoteCopy(pid_from, castbuf[0]);
    entitiesToBroadcast.push_back(exchg_struct_2(castbuf[1], pid_from, castbuf[0]));
    CM->free_msg(msg_recv);
  }

  _exchangeEntitiesToBroadcast(entitiesToBroadcast);
}


// **********************************************
void _exchangeEntitiesToBounce(list<exchg_struct_3>& entitiesToBounce)
// **********************************************
{
  int msg_size = sizeof(int)+2*sizeof(mEntity*);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;

  list<exchg_struct_3>::const_iterator rcvIter;
  for (rcvIter=entitiesToBounce.begin(); rcvIter!=entitiesToBounce.end();++rcvIter)
  { 
    mEntity** s_ent = (mEntity**)msg_send; 
    s_ent[0] = rcvIter->ent1;
    s_ent[1] = rcvIter->ent2;
    int* s_id = (int*)((char*)msg_send+sizeof(mEntity*)*2);  
    *s_id = rcvIter->dest; 
    CM->send( rcvIter->src , (void*)msg_send);
    num_sent++; 
  }

  list<exchg_struct_2> entitiesToBroadcast;
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  mEntity** castbuf;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    mEntity** s_ent = (mEntity**)msg_recv;
    int* s_id = (int*)((char*)msg_recv+sizeof(mEntity*)*2); 
    s_ent[1]->addRemoteCopy(*s_id, s_ent[0]);
    entitiesToBroadcast.push_back(exchg_struct_2(s_ent[1], *s_id, s_ent[0]));
    CM->free_msg(msg_recv);
  }

  _exchangeEntitiesToBroadcast(entitiesToBroadcast);
}

// **********************************************
void _exchangeEntitiesToBroadcast(list<exchg_struct_2>& entitiesToBroadcast)
// **********************************************
{
  mEntity* ent;
  int pid;
  
  int msg_size = 2*sizeof(mEntity*) + sizeof(int);

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  void *msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;
 
  int numPart = ParUtil::Instance()->getTgtNumParts();   

#ifdef MATCHING
  list<exchg_struct_2> entMatchToBc;  
#endif

  list<exchg_struct_2>::const_iterator rcvIter;
  mEntity** castbuf;
  int *s_pid;
  for (rcvIter=entitiesToBroadcast.begin(); rcvIter!=entitiesToBroadcast.end();++rcvIter)
  {
    ent = rcvIter->ent1;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      pid = rciter->first;
      if (pid == rcvIter->pid)
        continue;
      castbuf = (mEntity**)msg_send;
      castbuf[0] = rciter->second;
      castbuf[1] = rcvIter->ent2;
      s_pid = (int*)((char*)msg_send + 2*sizeof(mEntity*));
      *s_pid = rcvIter->pid;
      CM->send(pid/numPart, (void*)msg_send);
    }
#ifdef MATCHING
   if (ent->hasMatchEnt())
      entMatchToBc.push_back(exchg_struct_2(rcvIter->ent1, rcvIter->pid, rcvIter->ent2)); 
#endif
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    castbuf = (mEntity**)msg_recv;
    s_pid = (int*)((char*)msg_recv + 2*sizeof(mEntity*));
    castbuf[0]->addRemoteCopy(*s_pid, castbuf[1]);
    CM->free_msg(msg_recv);
  }

#ifdef MATCHING
  CM->set_comm_validation(IPComMan::All_Reduce);
  CM->set_tag(0);
 
  msg_size = 2*sizeof(mEntity*) + sizeof(int); 
  CM->set_fixed_msg_size(msg_size);
  msg_send = CM->alloc_msg(msg_size);
  num_sent = 0; num_recvd = 0;
  
  int mypid = ParUtil::Instance()->rank();
  
  for (rcvIter=entMatchToBc.begin(); rcvIter!=entMatchToBc.end(); ++rcvIter) {
    ent = rcvIter->ent1;
    for (mEntity::MEIter meiter=ent->meBegin();meiter!=ent->meEnd();++meiter)
    {
      if ( (meiter->first)/numPart==mypid ) 
         (meiter->second)->addMatchEnt(rcvIter->pid, rcvIter->ent2);
    }
  }
  
  for (rcvIter=entMatchToBc.begin(); rcvIter!=entMatchToBc.end(); ++rcvIter) {
    ent = rcvIter->ent1;   
    for (mEntity::MEIter meiter=ent->meBegin();meiter!=ent->meEnd();++meiter)
    {
      if( (rcvIter->pid==meiter->first) && (meiter->second == rcvIter->ent2))
         continue;
      if ( (meiter->first)/numPart==mypid ) 
	 continue; 
	 
      pid = meiter->first;
      castbuf = (mEntity**)msg_send;
      castbuf[0] = meiter->second;
      castbuf[1] = rcvIter->ent2;
      s_pid = (int*)((char*)msg_send + 2*sizeof(mEntity*));
      *s_pid = rcvIter->pid;
      CM->send(pid/numPart, (void*)msg_send);
      num_sent ++; 
    }
  }

  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    castbuf = (mEntity**)msg_recv;
    s_pid = (int*)((char*)msg_recv + 2*sizeof(mEntity*));
    castbuf[0]->addMatchEnt(*s_pid, castbuf[1]);
    CM->free_msg(msg_recv);
  }
#endif

}

// **********************************************
void _pack_MEntity(mEntity *ent, int pid, int src, pmMigrationCallbacks &cb, void *&msg_send, int &msg_size, int meshDim)
// **********************************************
{
  char *buf_user;
  int user_size, user_size_part1, user_size_part2;
  int entity_size;

  char* eg_buf_user; 
  int eg_user_size; 

  int tgtNumPart = ParUtil::Instance()->getTgtNumParts(); 
  IPComMan *CM = ParUtil::Instance()->ComMan();

  // User may have some data to send to the other process. These data are of size user_size_part2.
  buf_user = (char*)cb.getUserData(ent, pid/tgtNumPart, user_size);
  if(!buf_user)
    user_size = 0; 

  short int numBP = ent->getNumBPs();
  if (numBP<2) numBP=0;
  short int numRC = ent->getNumRemoteCopies();
  short int entDim = ent->getLevel();
  short int numDE = entDim+1;

  entity_size = 2*sizeof(int) + sizeof(ent_struct) + numRC*(sizeof(int)+sizeof(mEntity*)) + numBP*sizeof(int) ;

#ifdef MATCHING
  int numMatch = ent->getNumMatchEnts(); 
  entity_size += numMatch*(sizeof(int)+sizeof(mEntity*)); 
#endif

  int n_bytes = 0;

  pGEntity gent = ent->getClassification();
  short int numParam=0, gType, gTag;
  if(gent!=0) {
    gType = GEN_type(gent);
    gTag = GEN_tag(gent);
  }
  else{
    gTag = 1;
    gType = 3;
  }

  if (entDim == 0)
  {
    if (ent->getData(FMDB_Util::Instance()->getParametric()))
    {
      if (gType==1) // vertex classified on model edge
        numParam=1;
      else if (gType==2) // vertex classified on model face
        numParam=2;
    }

    entity_size += sizeof(vtx_struct) + numParam*sizeof(double);

    msg_size = entity_size + user_size;
    msg_send = CM->alloc_msg(msg_size);

    // dest global pid and src local pid 
    int* tmp_pid; 
    tmp_pid = (int*)msg_send; 
    tmp_pid[0]=pid; 
    tmp_pid[1]=src; 
    n_bytes += 2*sizeof(int); 

    // fixed length data
    ent_struct *entbuf = (ent_struct*)((char*)msg_send + n_bytes);
    entbuf->numDE = numDE;
    entbuf->sender = ent;
    entbuf->gTag = gTag;
    entbuf->gType = gType;
    entbuf->numRC = numRC;
    entbuf->numBP = numBP;
#ifdef MATCHING
    entbuf->numMatch = numMatch; 
#endif
    n_bytes += sizeof(ent_struct);

    // vertex specific parameters
    vtx_struct *castbuf = (vtx_struct*)((char*)msg_send + n_bytes);
    castbuf->iD = ent->getId();
    double xyz[3];
    ((mVertex*)ent)->getCoord(xyz[0], xyz[1], xyz[2]);
    for(int i=0;i<3;i++) 
       castbuf->coord[i] = xyz[i]; 
    castbuf->numParam = numParam;
    n_bytes += sizeof(vtx_struct);

    if (numParam > 0)
    {
      double *Params = (double*)((char*)msg_send + n_bytes);
      SCOREC::Util::mVector vec = ent->getAttachedVector(FMDB_Util::Instance()->getParametric());
      for (int k=0; k<numParam;++k) 
      {
        Params[k] = vec(k);
      }
      n_bytes += numParam*sizeof(double);
    }
  }
  else
  {
    numDE = ent->size(0); 
    entity_size += sizeof(short int) + numDE*sizeof(mEntity*);   

  if(meshDim==ent->getLevel()) { 
    unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");
    entity_size += sizeof(mEntityGroup*); 
    void* tmp_ptr; 
    if(EN_getDataPtr(ent, egTag, &tmp_ptr)) {                   // in an entity-group 
      int pos = ((mEntityGroup*)tmp_ptr)->getEntityOrder(ent);

      if(pos==0) {	                                        // start from 0 
	 entity_size += 2*sizeof(int); 
	 eg_buf_user = (char*)cb.getEntGrpUserData((mEntityGroup*)tmp_ptr, pid/tgtNumPart, eg_user_size);
         if(!eg_buf_user)
	 {
	    eg_user_size = 0;
	 }
	 entity_size += eg_user_size;  
      }
      else
         entity_size += sizeof(int);
     }
   }

    msg_size = entity_size + user_size;
    msg_send = CM->alloc_msg(msg_size);

    // dest global pid and src local pid
    int* tmp_pid;
    tmp_pid = (int*)msg_send;
    tmp_pid[0]=pid;
    tmp_pid[1]=src;
    n_bytes += 2*sizeof(int); 

    // fixed length data
    ent_struct *entbuf = (ent_struct*)((char*)msg_send + n_bytes);
    entbuf->numDE = numDE;
    entbuf->sender = ent;
    entbuf->gTag = gTag;
    entbuf->gType = gType;
    entbuf->numRC = numRC;
    entbuf->numBP = numBP;
#ifdef MATCHING
    entbuf->numMatch = numMatch;
#endif    
    n_bytes += sizeof(ent_struct);

    short int *type = (short int*)((char*)msg_send + n_bytes);
    *type = ent->getType();
    n_bytes += sizeof(short int);
 
    mEntity** DEs = (mEntity**)((char*)msg_send + n_bytes);
    for (int i=0; i<numDE;++i)
    {
      DEs[i] = ent->get(0,i)->getRemoteCopy(pid);
    }
    n_bytes += numDE*sizeof(mEntity*);
  }

  // variable length data - RC and BP
  if (numRC>0)
  {
    int *RCs_pid;
    mEntity **RCs_ent;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      RCs_pid = (int*)((char*)msg_send + n_bytes);
      *RCs_pid = rciter->first;
      n_bytes += sizeof(int);
      RCs_ent = (mEntity**)((char*)msg_send + n_bytes);
      *RCs_ent = rciter->second;
      n_bytes += sizeof(mEntity*);
    }
  }

  if (numBP>1)
  {
    int i=0; 
    int* BPs = (int*)((char*)msg_send + n_bytes);
    for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
    {
      BPs[i] = *bpiter;
      i++; 
    }
    n_bytes += numBP*sizeof(int);
  }

  if(ent->getLevel()==meshDim) {
  
     unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag");
     mEntityGroup** entGrp = (mEntityGroup**)((char*)msg_send + n_bytes); 
     void* tmp_ptr; 
     if(EN_getDataPtr(ent, egTag, &tmp_ptr))                     // entity is in entity-group 
       *entGrp = (mEntityGroup*)tmp_ptr; 
     else 
       *entGrp = 0; 
       
     n_bytes += sizeof(mEntityGroup*);

     if( *entGrp!=0 ) {
       int* pos = (int*)((char*)msg_send+n_bytes); 
       *pos = (*entGrp)->getEntityOrder(ent);
       n_bytes += sizeof(int); 
     
       if(*pos==0) {                                          // the 1st entity in entity-group
	 int* size = (int*)((char*)msg_send + n_bytes);  
	 *size = eg_user_size; 
	 n_bytes += sizeof(int);

	 if(eg_user_size)  {
	    memcpy((void*)((char*)msg_send + n_bytes), eg_buf_user, eg_user_size);
	    cb.deleteEntGrpUserData(eg_buf_user);	    
	    n_bytes += eg_user_size; 
	 }
       }
     }
  }

#ifdef MATCHING
 if (numMatch>0)
  {
    int *MEs_pid;
    mEntity **MEs_ent;
    for (mEntity::MEIter meiter=ent->meBegin();meiter!=ent->meEnd();++meiter)
    {
      MEs_pid = (int*)((char*)msg_send + n_bytes);
      *MEs_pid = meiter->first;
      n_bytes += sizeof(int);
      MEs_ent = (mEntity**)((char*)msg_send + n_bytes);
      *MEs_ent = meiter->second;
      n_bytes += sizeof(mEntity*);
    }
  }
#endif

  if(user_size)
  {
    memcpy((void*)((char*)msg_send + n_bytes),buf_user,user_size);
    cb.deleteUserData(buf_user);
  }
}

// **********************************************
void _unpack_MEntity(mPart* mesh, int meshDim, void *msg_recv, int pid, 
                    pmMigrationCallbacks &cb, list<mEntity*>* newE, 
                    list<exchg_struct_3>& entitiesToBounce,
                    std::map<pair<mEntityGroup*, int>, mEntityGroup*>& entGrpMap)
// **********************************************
{
  int n_bytes = 0;
  short int numRC, numBP;
  int mypid = ParUtil::Instance()->rank();

  mEntity *ent, *sender;
  int numPart = ParUtil::Instance()->getTgtNumParts(); 

// PRE-STEP: add sender to remote copy and store entity to bounce
  // dest global pid and src local pid 
  int* tmp_pid = (int*)msg_recv; 
  int dest_pid = tmp_pid[0]; 
  int src_lid = tmp_pid[1]; 
  n_bytes += 2*sizeof(int); 

  ent_struct *entbuf = (ent_struct*)((char*)msg_recv + n_bytes);
  n_bytes += sizeof(ent_struct);

  sender = entbuf->sender;
  numRC = entbuf->numRC;
  numBP = entbuf->numBP;

#ifdef MATCHING
  int numMatch = entbuf->numMatch; 
#endif

  if (entbuf->numDE == 1)
  {
    // STEP 1: create entity
    vtx_struct *castbuf = (vtx_struct*)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(vtx_struct);

    ent = mesh->createVertex(castbuf->iD, castbuf->coord[0], castbuf->coord[1], castbuf->coord[2],
                                  mesh->getGEntity(entbuf->gTag, entbuf->gType));
    newE[0].push_back(ent);    

    if (castbuf->numParam > 0)
    {
      double* Params = (double*)((char*)msg_recv + n_bytes);
      if (castbuf->numParam == 1)
        ent->attachVector (FMDB_Util::Instance()->getParametric(),SCOREC::Util::mVector(Params[0],0,0));
      else // if (castbuf.numParam==2)
        ent->attachVector (FMDB_Util::Instance()->getParametric(),SCOREC::Util::mVector(Params[0],Params[1],0));
      n_bytes += castbuf->numParam*sizeof(double);
    }
  }
  else
  {
    short int *type = (short int*)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(short int);

    pGEntity g = mesh->getGEntity(entbuf->gTag, entbuf->gType);

// STEP 1: create an entity
    short int numDE;
    mEntity** DEs = (mEntity**)((char*)msg_recv + n_bytes);
    mEntity* tmpVerts[10];
    switch (*type)
    {
      case mEntity::EDGE:
      {
        numDE=2;
        mVertex *v1 = (mVertex*)DEs[0];
        mVertex *v2 = (mVertex*)DEs[1];
        FMDB_Edge_Create(mesh, g, (mEntity*)v1, (mEntity*)v2, ent);
        newE[1].push_back(ent);
      } break;

      case mEntity::TRI:
      {
        numDE=3;
        mEntity* edges[3];

        FMDB_Ent_Find(mesh, 1, DEs, 2, edges[0]);
        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[1]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[2]);

        FMDB_Face_Create(mesh, g, FMDB_TRI, edges, 0, ent);
        newE[2].push_back(ent);
      } break;

      case mEntity::QUAD:
      {
	numDE=4; 
	mEntity* edges[4];
        FMDB_Ent_Find(mesh, 1, DEs, 2, edges[0]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[1]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[2]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[3]);
        FMDB_Face_Create(mesh, g, FMDB_QUAD, edges, 0, ent);
	newE[2].push_back(ent);
	
      } break;

      case mEntity::TET:
      {
        numDE=4;
        mEntity* faces[4];    
        FMDB_Ent_Find(mesh, 2, DEs, 3, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[2]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[3]);
        FMDB_Rgn_Create(mesh, g, FMDB_TET, 4, faces, ent);
        newE[3].push_back(ent);
      } break;

      case mEntity::HEX: 
      {
	numDE=8; 
	mEntity* faces[6];
        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[2];
        tmpVerts[3] = DEs[1];
        FMDB_Ent_Find(mesh, 2, DEs, 4, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[5];
        tmpVerts[3] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[6];
        tmpVerts[3] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[7];
        tmpVerts[3] = DEs[6];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[4];
        tmpVerts[3] = DEs[7];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[4]);

        tmpVerts[0] = DEs[4];
        tmpVerts[1] = DEs[5];
        tmpVerts[2] = DEs[6];
        tmpVerts[3] = DEs[7];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[5]);
        FMDB_Rgn_Create(mesh, g, FMDB_HEX, 6, faces, ent);
	
	newE[3].push_back(ent);
      } break;
   
      case mEntity::PRISM: 
      {
	numDE=6; 

	mEntity* faces[5];
        FMDB_Ent_Find(mesh, 2, DEs, FMDB_TRI, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[4];
        tmpVerts[3] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, FMDB_QUAD, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[5];
        tmpVerts[3] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, FMDB_QUAD, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[3];
        tmpVerts[3] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, FMDB_QUAD, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[4];
        tmpVerts[2] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, FMDB_TRI, faces[4]);
        FMDB_Rgn_Create(mesh, g, FMDB_PRISM, 5, faces, ent);
	
	newE[3].push_back(ent);
      } break; 

      case mEntity::PYRAMID: 
      {
	numDE=5; 

	mEntity* faces[5];
        FMDB_Ent_Find(mesh, 2, DEs, 4, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[4]);

        FMDB_Rgn_Create(mesh, g, FMDB_PYRAMID, 5, faces, ent);
	newE[3].push_back(ent);
      } break;

      default :
        {
          cout<<"unpacking entity failed due to unknownn topology\n";
          throw 1;
        }
    }
    n_bytes += numDE*sizeof(mEntity*);
  }

// STEP 3: copy Remote Copies of sender
  if (numRC>0)
  {
    int RCs_pid;
    mEntity *RCs_ent;
    for (short int i=0; i < numRC; i++)
    {
      RCs_pid = *(int*)((char*)msg_recv + n_bytes);
      n_bytes += sizeof(int);
      RCs_ent = *(mEntity**)((char*)msg_recv + n_bytes);
      n_bytes += sizeof(mEntity*);
      ent->addRemoteCopy(RCs_pid, RCs_ent);
    }
  }

// STEP 4: copy bounding partition iDs and set PClassification
  if (numBP > 1)
  {
    int* BPs = (int*)((char*)msg_recv + n_bytes);
    set<int> BPset;
    for (short int i=0; i < numBP; i++)
      BPset.insert(BPs[i]);
    pmEntity* pe = pmModel::Instance()->getPartitionEntity(BPset);
    ent->setPClassification(pe);
    n_bytes += numBP*sizeof(int);
  }

#ifdef MATCHING
  if (numMatch>0)
  {
    int MEs_pid;
    mEntity *MEs_ent;
    for (int i=0; i < numMatch; i++)
    {
      MEs_pid = *(int*)((char*)msg_recv + n_bytes);
      n_bytes += sizeof(int);
      MEs_ent = *(mEntity**)((char*)msg_recv + n_bytes);
      n_bytes += sizeof(mEntity*);
      ent->addMatchEnt(MEs_pid, MEs_ent);
    }
  }
#endif

  if (ent->getLevel() < meshDim)
  {
    ent->addRemoteCopy(pid*numPart+src_lid, sender);  
    entitiesToBounce.push_back(exchg_struct_3(ent, dest_pid, sender, pid));            // pid is proc_rank of the sender 
  }
  else 
  {
    void** tmp = (void**)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(mEntityGroup*); 
    
    if((*tmp)!=0) {                                          // in entity-group 
      pMeshDataId egTag = MD_lookupMeshDataId("EntityGroupTag");
      mEntityGroup* entGrp = (mEntityGroup*)(*tmp);
      
      map<pair<mEntityGroup*, int>, mEntityGroup*>::iterator mapIt; 
      for(mapIt=entGrpMap.begin(); mapIt!=entGrpMap.end(); ++mapIt) 
	 if( (mapIt->first).first==entGrp && (mapIt->first).second==pid )
	    break; 

      if(mapIt!=entGrpMap.end()) {                          // already in the map 
         EN_attachDataPtr(ent, egTag, mapIt->second);
         int* pos = (int*)((char*)msg_recv + n_bytes);
         (mapIt->second)->addEntity(ent, *pos);
	 n_bytes += sizeof(int);

         if(*pos==0) {
	    int* eg_user_size = (int*)((char*)msg_recv + n_bytes);
	    n_bytes += sizeof(int);

	    if( (*eg_user_size) !=0) {
	       IPComMan *CM = ParUtil::Instance()->ComMan();
	       cb.recieveEntGrpUserData(mapIt->second, pid, CM->get_tag(), (void*)((char*)msg_recv + n_bytes));	    
	    }
	    
	    n_bytes += *eg_user_size;
	 }
      }
      else {                                                 // create one item in the map 
	 mEntityGroup* newEntGrp = mesh->createEntGrp(meshDim); 
	
	 entGrpMap.insert(make_pair(make_pair(entGrp, pid), newEntGrp)); 

	  EN_attachDataPtr(ent, egTag, newEntGrp); 
            int* pos = (int*)((char*)msg_recv + n_bytes);
         newEntGrp->addEntity(ent, *pos);
         n_bytes += sizeof(int);


         if(*pos==0) {
            int* eg_user_size = (int*)((char*)msg_recv + n_bytes);
            n_bytes += sizeof(int);

            if( (*eg_user_size) !=0) {
               IPComMan *CM = ParUtil::Instance()->ComMan();
               cb.recieveEntGrpUserData(newEntGrp, pid, CM->get_tag(), (void*)((char*)msg_recv + n_bytes));
            }

            n_bytes += *eg_user_size;
         }
      }
    }
  }

// STEP 6: process user attached data
  IPComMan *CM = ParUtil::Instance()->ComMan(); 
  cb.recieveUserData(ent,pid,CM->get_tag(),(void*)((char*)msg_recv + n_bytes));
}

#endif /* FMDB_PARALLEL */
