/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#ifdef FMDB_PARALLEL
#include "mMigration.h"
#include "ParUtil.h"
#include "pmModel.h"
#include "FMDB_cint.h"

#include "IPComMan.h"

void _printPOtoMove(map<mEntity*, int*>& POtoMove)
{
  map<mEntity*, int*>::const_iterator mapit;
  int mypid=ParUtil::Instance()->rank();
  for (mapit=POtoMove.begin(); mapit!=POtoMove.end();++mapit)
    cout<<"("<<mypid<<") move "<<mapit->first->getUid()<<" to Part"<<(mapit->second)[1]<<" of P"<<(mapit->second)[2] <<", (mapit->second)[0]="<<(mapit->second)[0]<<")"<<endl;
}

void _printEntToHandle(map<mEntity*, int>* EntToHandle)
{
  map<mEntity*,int>::iterator iter;
  for (int i=0; i<=3; ++i)
    for (iter=EntToHandle[i].begin(); iter!=EntToHandle[i].end(); ++iter)
      iter->first->printBPs();
}

// *****************************************
int _migrateMesh(vector<mPart*>& meshes,
                        map<mEntity*,int*>& POtoMove,
			map<mEntityGroup*,int*>& EntGrpToMove, 
                        pmMigrationCallbacks& cb,
                        std::list<mEntity*>* rmE,
                        std::list<mEntity*>* newE,
			std::vector<mEntityGroup*>& rmEG,
			std::vector<mEntityGroup*>& newEG)
// *****************************************
{
  double t1, t2;
  int mypid = ParUtil::Instance()->rank();

  //_printPOtoMove(POtoMove);

  set<int> nbrs;
  pmModel::Instance()->getNbrPids(nbrs);
  ParUtil::Instance()->ComMan()->set_Nbrs(nbrs);

  int dim = M_globalMaxDim(meshes[0]); 

#ifdef _DEBUG
  double t1, t2;
#endif
  map<mEntity*,int> entitiesToRemove[4];
  map<mEntity*,int> entitiesToHandle[4];
 
// ********************************************
// STEP 1: reset BPs
// ********************************************
  // unify entitiesToHandle and clear their BPs and PCs
#ifdef DEBUG
  t1 = ParUtil::Instance()->wTime();
#endif
#ifdef DEBUG  
  double ts = ParUtil::Instance()->wTime();
#endif

  _collectEntToMigrate(dim, POtoMove, entitiesToHandle);
  //_printEntToHandle(entitiesToHandle);

#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) set bounding partition ids \n",t2-t1);

// ********************************************
// STEP 2: update PClassification and collect entities to remove
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif
  _collectEntToRemove(entitiesToHandle, entitiesToRemove);

#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update PClassification\n",t2-t1);

// ********************************************
// STEP 3: update RC when maxNumParts is changed (costly) 
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  int curNumPart = ParUtil::Instance()->getCurNumParts();    // current_local_num_parts
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();    // target_local_num_parts 
  mEntity* ent; 
  mPart* mesh; 
  if(curNumPart!=tgtNumPart) {

    for(int ipart=0; ipart<(int)meshes.size(); ipart++) {
      mesh = meshes[ipart];
      for(int idim=0; idim<dim; idim++)
	for (mPart::iterall it=mesh->beginall(idim); it!=mesh->endall(idim);++it){ 

	  // update remote copy
     	  ent=*it; 
	  if(ent->getNumRemoteCopies()) {       
	    map<int, mEntity*> tmpRemoteCopies;
	    ent->getRemoteCopies(tmpRemoteCopies);
	    ent->clearRemoteCopies();
	    
	    for(mEntity::RCIter rcIter=tmpRemoteCopies.begin(); rcIter!=tmpRemoteCopies.end(); ++rcIter) {
	      int pid=(*rcIter).first; 	 
	      int newPid = (pid/curNumPart)*tgtNumPart + pid%curNumPart;          // target global pid 
	      ent->addRemoteCopy(newPid, (*rcIter).second);          
	    }

	    // update partition classification
	    if(entitiesToHandle[idim].find(ent)==entitiesToHandle[idim].end() ) { 
	      set<int> BPset; 
	      ent->getPidsExist(BPset);
	      BPset.insert(mypid*tgtNumPart+ipart);
	      pmEntity* pe = pmModel::Instance()->getPartitionEntity(BPset);
	      ent->setPClassification(pe);
	    }
	  }
#ifdef MATCHING
	  if(ent->hasMatchEnt()) {

            const multimap<int, mEntity*>* tmpMatchEnts;
	    multimap<int, mEntity*> tmpMatchEnts2; 
            tmpMatchEnts = ent->getMatchEnts();

	    int pid, newPid; 
            for(multimap<int, mEntity*>::const_iterator meIter=tmpMatchEnts->begin(); meIter!=tmpMatchEnts->end(); ++meIter) 
	    {
              pid=(*meIter).first;
              newPid = (pid/curNumPart)*tgtNumPart + pid%curNumPart;          // target global pid
	      tmpMatchEnts2.insert(mEntity::matchEntMap::value_type(newPid, meIter->second));
            } 
	    
	    ent->clearMatchEnts(); 
	    for(multimap<int, mEntity*>::iterator meIter=tmpMatchEnts2.begin(); meIter!=tmpMatchEnts2.end(); ++meIter)
	       ent->addMatchEnt(meIter->first, meIter->second);
	       
	  }
#endif
	}
    }
  }

#ifdef DEBUG
  t2=ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update remote copies when numParts is changed.\n",t2-t1);
// ********************************************
// STEP 4: Migrate entities
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  for (int i=0; i<=dim;++i)
    _exchangeEnt(meshes, dim, cb, i, entitiesToHandle[i], newE, newEG);

#ifdef DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) exchange entities\n",t2-t1);

// ********************************************
// STEP 5: collect entities removed to return
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  map<mEntity*,int>::iterator mapit; 
  for (int i=0; i<=dim;++i)
    for(mapit=entitiesToRemove[i].begin(); mapit!=entitiesToRemove[i].end(); mapit++)
      rmE[i].push_back(mapit->first); 

#ifdef DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) gather removed entities to return to the user\n", t2-t1);

// ********************************************
// STEP 6: delete unused entities
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  ParUtil::Instance()->setCurNumParts(tgtNumPart);
  _removeEnt(meshes, cb, dim, entitiesToRemove); 

// ********************************************
// STEP : delete unused entity groups 
// ********************************************
    map<mEntityGroup*, int*>::iterator egIter;
    mEntityGroup::entIter eiter; 
    int pid;
    mEntityGroup* eg; 
    for(egIter=EntGrpToMove.begin(); egIter!=EntGrpToMove.end(); ++egIter) {
      eg=egIter->first;
      pid = (egIter->second)[0];        // local part id
      for(eiter=eg->begin(); eiter!=eg->end(); ++eiter) {
        POtoMove.erase(*eiter);
      }
      
      meshes[pid]->deleteEntGrp(eg, 0);
      rmEG.push_back(eg);  // collect removed entity group
      delete[] (egIter->second); 
    }

   map<mEntity*,int*>::iterator iter;
   for(iter = POtoMove.begin(); iter!=POtoMove.end(); ++iter) {
      int* pid = (*iter).second;
       delete[] pid;
   }

#ifdef DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove unused entities\n", t2-t1);

// ********************************************
// STEP 7: delete empty parts and update localPids 
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  int usrNumPart = ParUtil::Instance()->getUsrNumParts(); 
  int size = (int)meshes.size(); 
  if(usrNumPart< size)                   // local_num_parts is reduced     
    if((ParUtil::Instance()->localPids).size()==0 )              
      for(int i=usrNumPart; i< size; ++i) {
	mPart* tmpMesh = meshes[i];
	M_delete(tmpMesh);
	meshes.pop_back(); 
    }
    else{

      vector<int>::iterator vecit; 
      int ipart=0; 
      set<mPart*> meshSet; 
      set<int> pidSet; 
      for(vecit=(ParUtil::Instance()->localPids).begin(); vecit!=(ParUtil::Instance()->localPids).end(); ++vecit, ++ipart) {
	if(*vecit<0) {
	  meshSet.insert(meshes[ipart]); 
	  pidSet.insert(*vecit); 
	}
      }
      
      vector<mPart*>::iterator meshIt; 
      for(set<mPart*>::iterator setit=meshSet.begin(); setit!=meshSet.end(); ++setit) {
	meshIt = std::find(meshes.begin(), meshes.end(), *setit);
	if(meshIt!=meshes.end())
	  meshes.erase(meshIt);
      }
      
      for(set<int>::iterator setit=pidSet.begin(); setit!=pidSet.end(); ++setit){
	vecit = std::find((ParUtil::Instance()->localPids).begin(), (ParUtil::Instance()->localPids).end(), *setit); 
	if(vecit!=(ParUtil::Instance()->localPids).end())
	  (ParUtil::Instance()->localPids).erase(vecit); 
      }
    }


#ifdef DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) remove empty parts and update localPids\n",t2-t1);

// ********************************************
// STEP 5: update partition model in terms of ownership
// ********************************************
  t1 = ParUtil::Instance()->wTime();
#endif

  /// Set neighboring parts based on the new partition model information
  pmModel::Instance()->clean_up();
  pmModel::Instance()->setNbrPTs();
  nbrs.clear();
  pmModel::Instance()->getNbrPids(nbrs);  
   
  ParUtil::Instance()->ComMan()->set_Nbrs(nbrs);
  pmModel::Instance()->updateOwnership(meshes);

#ifdef DEBUG
  t2 = ParUtil::Instance()->wTime();
  ParUtil::Instance()->Msg(ParUtil::INFO,"\t* %f (sec) update partition model\n",t2-t1);
#endif
#ifdef DEBUG
  if (mypid==0)
    cout<<"     TOTAL TIME = " <<" (t = "<<ParUtil::Instance()->wTime()-ts<<" sec)\n";
#endif
  return 1;
}

#endif
