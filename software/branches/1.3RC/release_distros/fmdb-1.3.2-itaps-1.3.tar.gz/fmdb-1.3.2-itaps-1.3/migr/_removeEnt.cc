/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/
#ifdef FMDB_PARALLEL
#include "mMigration.h"
#include "ParUtil.h"
#include "FMDB_cint.h"
#include "IPComMan.h"

// ***********************************************************
void _collectEntToRemove(map<mEntity*,int>* entitiesToHandle, 
			 map<mEntity*,int>* entitiesToRemove)
// ***********************************************************
{
  mEntity* ent;
  map<mEntity*, int>::const_iterator eit; 

  int mypid = ParUtil::Instance()->rank();
  int numPart = ParUtil::Instance()->getTgtNumParts();
  
  for (int dim=0; dim<=3; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();
      eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first; 
      int lid = eit->second; 
      if (lid >= numPart)                                        // the whole part will be removed 
	 (entitiesToRemove[dim])[ent]=lid; 
      else if (!ent->findPidInBPs(mypid*numPart+lid))               // stay in the current part 
	(entitiesToRemove[dim])[ent]=lid; 
      else //if (!ent->getPClassification()) 
        ent->setPClassificationWithBPs();
    }    
  }
}

// ***********************************************************
void _removeEnt(std::vector<mPart*>& meshes, pmMigrationCallbacks &cb,
                          int dim, map<mEntity*,int>* entitiesToRemove)
// ***********************************************************
{

  map<mEntity*, int>::iterator eiter;
  map<mEntity*, int> entitiesOnCB; 
  int numPart = ParUtil::Instance()->getCurNumParts(); 
  mEntity* ent; 
  int mypid = ParUtil::Instance()->rank(); 

  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::All_Reduce);
  CM->set_tag(0);
  int msg_size = sizeof(mEntity*)+sizeof(int);
  CM->set_fixed_msg_size(msg_size);
  void* msg_send = CM->alloc_msg(msg_size);
  int num_sent = 0, num_recvd = 0;
  mEntity** s_ent; 
  int* s_id; 

  for (int i=dim; i>=0; --i)  // region to vertex
    for (eiter=entitiesToRemove[i].begin(); eiter!=entitiesToRemove[i].end();++eiter) 
    {
      ent = eiter->first; 
      cb.deleteEntityData(ent);
      if (ent->getNumRemoteCopies())
      {
        for (mEntity::RCIter rcIter=ent->rcBegin(); rcIter!=ent->rcEnd();++rcIter)
        {
	  s_ent = (mEntity**)msg_send; 
	  *s_ent = rcIter->second;
	  s_id = (int*)((char*)msg_send+sizeof(mEntity*)); 
	  *s_id = mypid*numPart + eiter->second;                        // ent's global pid
          CM->send((rcIter->first)/numPart, (void*)msg_send);
	  num_sent++; 
        }
      }
    }
  
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    s_ent = (mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv+sizeof(mEntity*)); 
    (*s_ent)->deleteRemoteCopy(*s_id);
    CM->free_msg(msg_recv);
  }

   unsigned int egTag = MD_lookupMeshDataId("EntityGroupTag"); 
   void* tmp; 

#ifdef MATCHING
    CM->set_tag(0);
    msg_size = 2*sizeof(mEntity*)+ sizeof(int);
    CM->set_fixed_msg_size(msg_size);
    void* msg_send2 = CM->alloc_msg(msg_size);
    num_sent = 0; num_recvd = 0;

    for (int i=dim-1; i>=0; --i)  // region to vertex
      for (eiter=entitiesToRemove[i].begin(); eiter!=entitiesToRemove[i].end();++eiter)
      {
        ent = eiter->first;
        if( !ent->hasMatchEnt() )
	  continue; 
        for (mEntity::MEIter meIter=ent->meBegin(); meIter!=ent->meEnd();++meIter)
        {
          if((meIter->first)/numPart==mypid) {
	    (meIter->second)->deleteMatchEnt(mypid*numPart + eiter->second, ent);
	    continue; 
	  }  
	
          s_ent = (mEntity**)msg_send2;
          s_ent[0] = meIter->second;
          s_ent[1] = ent;
          s_id = (int*)((char*)msg_send2 + 2*sizeof(mEntity*));
          *s_id = mypid*numPart + eiter->second;                        // ent's global pid
          CM->send((meIter->first)/numPart, (void*)msg_send2);
          num_sent++;
       }
     }
    CM->finalize_send();
    CM->free_msg(msg_send2);

  // receive phase begins
    while(int rc = CM->receive(msg_recv, &pid_from))
    {
      num_recvd++;
      s_ent = (mEntity**)msg_recv;
      s_id = (int*)((char*)msg_recv+ 2*sizeof(mEntity*));
      (s_ent[0])->deleteMatchEnt(*s_id, s_ent[1]);
      CM->free_msg(msg_recv);
    }
#endif

  if (dim==3)
    for (eiter=entitiesToRemove[3].begin(); eiter!=entitiesToRemove[3].end();++eiter){
      if(EN_getDataPtr(eiter->first, egTag, &tmp)) {
	 (eiter->first)->deleteData(egTag);
      }
      M_removeRegion(meshes[eiter->second], eiter->first);
    }
      
  for (eiter=entitiesToRemove[2].begin(); eiter!=entitiesToRemove[2].end();++eiter) {
      if(dim==2 && EN_getDataPtr(eiter->first, egTag, &tmp)) {
	  (eiter->first)->deleteData(egTag); 
       }
      M_removeFace(meshes[eiter->second], eiter->first );
  }

  for (eiter=entitiesToRemove[1].begin(); eiter!=entitiesToRemove[1].end();++eiter)
       M_removeEdge(meshes[eiter->second], eiter->first );
  
  for (eiter=entitiesToRemove[0].begin(); eiter!=entitiesToRemove[0].end();++eiter)
       M_removeVertex(meshes[eiter->second], eiter->first );

}
#endif
