/****************************************************************************** 

  (c) 2004-2011 Scientific Computation Research Center, 
      Rensselaer Polytechnic Institute. All rights reserved.
  
  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.
 
*******************************************************************************/ 
#include "mMigration.h"
#include "FMDB.h"
#include "ParUtil.h"

#ifdef FMDB_PARALLEL
// *****************************************
void _collectEntToMigrate (int meshDim, map<mEntity*,int*>& POToMove,
             map<mEntity*,int>* entitiesToHandle)
// *****************************************
{
  int mypid=ParUtil::Instance()->rank();
  int pid;
  int tgtNumPart = ParUtil::Instance()->getTgtNumParts();
  int numPart = ParUtil::Instance()->getCurNumParts();
//  cout<<"_collectEntToMigrate: tgtNumPart = "<<tgtNumPart<<", numPart = "<<numPart<<endl;

  IPComMan *CM = ParUtil::Instance()->ComMan();
   CM->set_comm_validation(IPComMan::All_Reduce);

  map<mEntity*, int*>::iterator mapit;
  mEntity *ent, *r;
  vector<mEntity*> adjVec;
  vector<mEntity*> upAdjVec;
  vector<mEntity*>::iterator adjIt;
  vector<mEntity*>::iterator upIt;
  
  int poLid; 
  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    // make sure POToMove does not include PO whose target part equals the local part 
    if (mypid==(mapit->second)[2] && mypid*tgtNumPart+(mapit->second)[0]==(mapit->second)[1])
      continue;
    //if (mypid==(mapit->second)[2]) continue;
    mapit->first->clearBPs();
    mapit->first->setPClassification((pmEntity*)0);
    mapit->first->addBPs((mapit->second)[1]);
    (entitiesToHandle[mapit->first->getLevel()])[mapit->first]=(mapit->second)[0];   
  }

  for (mapit=POToMove.begin();mapit!=POToMove.end();++mapit)
  {
    pid = (mapit->second)[1];               // dest global pid
    if (mypid==(mapit->second)[2] && mypid*tgtNumPart+(mapit->second)[0]==(mapit->second)[1])
      continue;
    r = mapit->first;
    adjVec.clear();
    FMDB_Ent_GetAdj(r, 4, 1, adjVec);
//    FMDB_Ent_DspAllAdj(r);

    for (adjIt=adjVec.begin();adjIt!=adjVec.end();++adjIt)
    {
      ent = *adjIt;

      if (ent->getLevel() == meshDim)
        continue;

      int entCount = entitiesToHandle[ent->getLevel()].count(ent);
      if (!entCount)  // if entity is not found in entitiesToHandle container
      {
        ent->clearBPs();
        ent->setPClassification((pmEntity*)0);
        entitiesToHandle[ent->getLevel()][ent]=(mapit->second)[0];        // src local pid

        //mAdjacencyContainer upward;
        //ent->getHigherOrderUpward(meshDim,upward);
        upAdjVec.clear();
        FMDB_Ent_GetAdj(ent, meshDim, 1, upAdjVec);
        for (upIt=upAdjVec.begin(); upIt!=upAdjVec.end(); ++upIt)
        {
          if ((*upIt)->getNumBPs()==0)
          {
            ent->addBPs(mypid*tgtNumPart+(mapit->second)[0]); 
            break;  // exit for loop
          }
        } // for
      } // if (!entCount)
      ent->addBPs(pid);
    } // for family
  } // for POtoMove

  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  int num_sent = 0, num_recvd = 0;
  void *msg_send;
  mEntity** s_ent;
  int* s_id; 

  map<mEntity*, int>::iterator eit;
  int msg_size, numBP;
  for (int dim = 0; dim <= meshDim; ++dim)
  {
    for (eit=entitiesToHandle[dim].begin();eit!=entitiesToHandle[dim].end();++eit)
    {
      ent = eit->first;
      if (ent->getNumRemoteCopies()==0)
        continue;

      numBP = ent->getNumBPs();
      for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
      {
        pid = (rciter->first)/numPart;
        msg_size=sizeof(mEntity*) +sizeof(int) + numBP*sizeof(int);
        msg_send = CM->alloc_msg(msg_size);
        
        s_ent = (mEntity**)msg_send; 
        s_id = (int*)((char*)msg_send+sizeof(mEntity*));
	
        *s_ent = rciter->second; 
        *s_id = rciter->first; 

        int *BPs = (int*)((char*)msg_send + sizeof(mEntity*) + sizeof(int));
        int i = 0;
        for (mEntity::BPIter bpiter=ent->bpBegin();bpiter!=ent->bpEnd();++bpiter)
        {
          BPs[i]=*bpiter;
          i++;
        }
        CM->send(pid, (void*)msg_send, msg_size);
        num_sent++;
        CM->free_msg(msg_send);
      }
    }
  }
  CM->finalize_send();

  map<mEntity*,int> restToMove;
  map<mEntity*,int>::iterator rest_iter;

  // recieve phase
  void *msg_recv;
  int pid_from;
  int* BPs;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *((mEntity**)msg_recv); 
    int* src_pid = (int*)((char*)msg_recv+sizeof(mEntity*)); 
    BPs = (int*)((char*)msg_recv+sizeof(mEntity*)+sizeof(int)); 
    numBP = (rc-sizeof(mEntity*)-sizeof(int)) / INT_SIZE;

    if (!entitiesToHandle[ent->getLevel()].count(ent))
    {
      ent->clearBPs();
      ent->setPClassification((pmEntity*)0);
//      mAdjacencyContainer upward;
//      ent->getHigherOrderUpward(meshDim,upward);
//      for (int i=0; i<upward.size();++i)
      upAdjVec.clear();
      FMDB_Ent_GetAdj(ent, meshDim, 1, upAdjVec);
      
      for (upIt=upAdjVec.begin(); upIt!=upAdjVec.end(); ++upIt)
      {
        if ((*upIt)->getNumBPs()==0)
        {
          ent->addBPs(mypid*tgtNumPart+(*src_pid) % numPart); ///send to rem copies info about mypid
          if (ent->getNumRemoteCopies())
            restToMove[ent] = mypid*tgtNumPart + (*src_pid) % numPart ;
          break;  // exit for loop
        }
      } // upward
      entitiesToHandle[ent->getLevel()][ent] = (*src_pid) % numPart;
    }

    for (int i = 0; i < numBP; i++)
    {
      ent->addBPs(BPs[i]);
    }
    CM->free_msg(msg_recv);
  }

  msg_size = sizeof(mEntity*) + sizeof(int);
  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  msg_send = CM->alloc_msg(msg_size);
  num_sent = 0; num_recvd = 0;

  for (rest_iter = restToMove.begin(); rest_iter != restToMove.end(); rest_iter++)
  {
    ent = rest_iter->first;
    for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
    {
      pid = (rciter->first)/numPart;
      s_ent = (mEntity**)msg_send;
      *s_ent = rciter->second;
      s_id = (int*)((char*)msg_send + sizeof(mEntity*));
      *s_id = rest_iter->second;
      CM->send(pid, (void*)msg_send);
      num_sent++;
    }
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // recieve phase
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
    num_recvd++;
    ent = *(mEntity**)msg_recv;
    s_id = (int*)((char*)msg_recv + sizeof(mEntity*));
    ent->addBPs(*s_id);
    CM->free_msg(msg_recv);
  }  
}
#endif

