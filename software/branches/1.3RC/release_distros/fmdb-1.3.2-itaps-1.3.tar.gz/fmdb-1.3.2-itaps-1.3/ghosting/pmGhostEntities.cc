/******************************************************************************

  (c) 2004-2011 Scientific Computation Research Center,
      Rensselaer Polytechnic Institute. All rights reserved.

  The LICENSE-SCOREC file included with this distribution describes the terms
  of the SCOREC Non-Commercial License this program is distributed under.

*******************************************************************************/
#ifdef FMDB_PARALLEL

#include <stdio.h>
#include <iostream>

#include <vector>
#include <set>
#include <map>
#include <string>
#include <mpi.h>
#include <cstring>

#include <malloc.h>
#include <mcheck.h>

#include "FMDB.h"
#include "FMDBfwd.h"

#include "pmMigrationCallbacks.h"
#include "pmMigrateUtil.h"
#include "pmModelUtil.h"
#include "pmModel.h"
#include "pmZoltanCallbacks.h"

#include "mPart.h"
#include "mEntity.h"
#include "mVertex.h"

using std::set;
using std::pair;
using std::map;
using std::cout;
using std::endl;

struct packedGhostVertex
{
  pMeshEnt sender;
  pMeshEnt ownerEnt;
  int ownerPid;
  int iD;
  int gTag;
  int gType;
  double coord[3];
  short int numRC;
};

struct packedGhostNonVertex
{
  int type;
  int gTag;
  int gType;
  mEntity* sender;
  mEntity* ownerEnt;
  int ownerPid;
  int numDE;
};

void getGhostEnts(pPart part, int partId, int bDim, int gDim, int include_copy, set<pMeshEnt>* entitiesToGhost, int numLayer, pTag tagVisited);

void setGhostDestination(pPart part, int partId, pMeshEnt bridgeEnt, int gDim, pTag tag, int numLayer, set<pMeshEnt>* entitiesToGhost);

void getDownwardAdjacencies(pPart part, int partId, int gDim, pMeshEnt ent, int destId, set<pMeshEnt>* entitiesToGhost);

void eliminateDuplicateEnts(pPart part, int partId, set<pMeshEnt>& entitiesToGhost);

void exchangeGhostEntities(pPart part, int partId, int gDim, int dim, pmMigrationCallbacks &cb, set<pMeshEnt>& entitiesToGhost);

void exchangeEntities2Bounce(list<rc_struct_2>& entitiesToBounce, int gDim, int dim);

void pack_Ghost_MEntity(pMeshEnt, int, pmMigrationCallbacks &, void *&, int &);

void unpack_Ghost_MEntity(pPart mesh, int ghostDim, void *msg_recv, int msg_size, int pid,
                  pmMigrationCallbacks &cb, list<rc_struct_2>& entitiesToBounce);

void removeEntities(pPart part, set<pMeshEnt>* entitiesToRemove, int gDim);

void removeLyrEnts(pPart part, int gDim, int bDim, set<pMeshEnt> inAdjs, int lyr, set<pMeshEnt>* entitiesToRemove, set<pMeshEnt>& out, pTag tag, set<pMeshEnt>&);

int deleteGhostEntities(pMeshMdl mesh);

void deleteDownwardAdj(pPart part, pMeshEnt pEnt, set<pMeshEnt>* entitiesToRemove, int gDim);

void getLayerEnts(pPart part, int partId, int gDim, int bDim, int lyr, int includeCopy, pTag tag, set<pMeshEnt>* entitiesToGhost, set<pMeshEnt>&);

int createGhost(pMeshMdl mesh, pmMigrationCallbacks & migrCB, int gDim, int bDim, int numLayer, int include_copy)
{
   /* Get current process id */
  int procId;
  FMDB_GetProcID (&procId);

  /* Get all parts in the current mesh instance. Right now we have one part per mesh instance */
  std::vector<pPart> vecPart;
  FMDB_Mesh_GetProcPart(mesh, procId, vecPart);
  double t1, t2, t4;

  int iNumProc;
  FMDB_GetNumProc(&iNumProc);

   /* Visited tag is for numLayer > 1 only*/
  char* tagName = (char*)"visited";
  int tagSize=1; // isn't being used right now.
  int tagType = 0; // for integer
  pTag tagVisited;

  if(numLayer > 1)	
    FMDB_Tag_Create (mesh, tagName, tagSize, tagType, /*traceable*/ 1, &tagVisited);

  for (std::vector<pPart>::iterator It = vecPart.begin(); It != vecPart.end(); It++ )
   {
    pPart part = (pPart)(*It);
	
    /* Store all entities that need to be ghosted*/
    set<pMeshEnt>* entitiesToGhost = new set<pMeshEnt>[gDim + numLayer];

    FMDB_GetWTime(&t1);

    getGhostEnts(part, procId, bDim, gDim, include_copy, entitiesToGhost, numLayer, tagVisited);

    FMDB_GetWTime(&t2);

    for(int dim = 0; dim < gDim + numLayer; dim++)
      exchangeGhostEntities(part, procId, gDim, dim, migrCB, entitiesToGhost[dim]);
    	
     FMDB_GetWTime(&t4);

     long lLocalMove = 0, lTotalMove=0;
    long lInc = 0;
    for(int i = gDim; i < gDim + numLayer; i++ )
    {
     for(set<pMeshEnt>::iterator setIter = entitiesToGhost[i].begin(); setIter != entitiesToGhost[i].end(); setIter++ )
      {
       lLocalMove += (*setIter)->getNumGPs();
      }
     lInc += entitiesToGhost[i].size();
    }

    //cout << "\n Time in collecting ghost entities: " << t2 - t1 << endl;

     // cout << "\n Time in exchanging ghost entities: " << t4 - t2 << endl;

      /// commented out due to performance reasons
     /*double localTime = t4 - t1, totalTime;
     MPI_Allreduce(&localTime,&totalTime,1,MPI_DOUBLE,MPI_MAX, MPI_COMM_WORLD);
     MPI_Allreduce(&lLocalMove,&lTotalMove,1,MPI_LONG,MPI_SUM, MPI_COMM_WORLD);

     if(!procId)
       cout << "\n Time in creating ghosts " << totalTime << ": total ghosts " << lTotalMove << endl;*/
 
     
     /* Deallocate memory */

     for(int i = 0; i < (gDim + numLayer); i++ )
	  entitiesToGhost[i].clear();

     delete[] entitiesToGhost;

     part->addGhostRule(gDim, bDim, numLayer, include_copy); 
     
     if(!procId)
      cout << "\n Ghosts created of type : " << gDim << " bridge dimension: " << bDim << " Copies " << include_copy << " Num layers: " << numLayer;
      }
    vecPart.clear();    
}

/* collect entities of dimension 'gDim' adjacent to part boundary entities of dimension 'bDim'. Set the destination part ids of the entities to be ghosted. */
void getGhostEnts(pPart part, int partId, int bDim, int gDim, int include_copy, set<pMeshEnt>* entitiesToGhost, int numLayer, pTag tag)
{
 int ierr;
 int iIsEnd = 0;

 set<pMeshEnt> tagEnts;

 /* Step 1 First get all part boundary entities of bridge dimension 'bdim' */
 pPartEntIter it;
 pMeshEnt pBrgEnt;
 iIsEnd = FMDB_PartEntIter_InitPartBdry(part, -1, bDim, FMDB_ALLTOPO, it, pBrgEnt);
 if(iIsEnd == 1)
  {
   cout << "\n Cannot continuing entity collection... Unable to get part boundary iterator." << endl;
   return;
  }
 
 while(!iIsEnd)
   {
   /* If we don't want to consider copies of bridge entities (include_copy = 0) and the owner part id is different than current part id, skip the bridge entity*/
    if((include_copy == 1) || (pBrgEnt->getOwner() == partId))
     setGhostDestination(part, partId, pBrgEnt, gDim, tag, numLayer, entitiesToGhost); 

   if(numLayer > 1)
   {
   pBrgEnt->attachInt( tag, 1);
   tagEnts.insert(pBrgEnt);
   }
    /* Get next entity on part boundary having dimension bdim*/
    iIsEnd = FMDB_PartEntIter_GetNext(it, pBrgEnt);
   } // end while

  int pDim, upLimit = gDim - 1;
  FMDB_Part_GetDim(part, &pDim);

  if((gDim == 1 || gDim == 2) && pDim > gDim)
   upLimit = gDim + (numLayer - 1);

  for(int lyr = 2; lyr <= numLayer; lyr++ )
   {
   getLayerEnts(part, partId, gDim, bDim, lyr, include_copy, tag, entitiesToGhost, tagEnts);
 
   /// Keep attaching tags to process the next layer, if this is the last layer, stop attaching tags.  
   if(lyr < numLayer)
   {
   for(set<pMeshEnt>::iterator setIter = entitiesToGhost[gDim + (lyr - 1)].begin(); setIter != entitiesToGhost[gDim + (lyr - 1)].end(); setIter++ )
     (*setIter)->attachInt( tag, 1);
   }
  }// for lyr

  if(numLayer > 1)
  {
   for(int i = gDim; i < gDim + numLayer; i++ )
    {
    for(set<pMeshEnt>::iterator setIter = entitiesToGhost[i].begin(); setIter != entitiesToGhost[i].end(); setIter++ )
      {
      pMeshEnt pTmpEnt = *setIter;
      if(pTmpEnt->getAttachedInt(tag) == 1)
        pTmpEnt->deleteData(tag);
       }
     }
    for(set<pMeshEnt>::iterator itSet = tagEnts.begin(); itSet != tagEnts.end(); itSet++)
     FMDB_Ent_DelTag(*itSet, tag);
   tagEnts.clear();
   }
  /* For ghost type edges, we want to avoid multiple parts sending the same ghosts to destination when include_copy = 1 & when ghosting remote copies*/
  for(int dim = 0; dim <= upLimit; dim++ ) 
    eliminateDuplicateEnts(part, partId, entitiesToGhost[dim]);
}

/* Entity collection procedure for number of layers > 1*/
void getLayerEnts(pPart part, int partId, int gDim, int bDim, int lyr, int include_copy, pTag tagVisited, set<pMeshEnt>* entitiesToGhost, set<pMeshEnt>& tagEnts)
{
  int dir = 0;
  int procId;
  FMDB_GetProcID(&procId);

  vector<pMeshEnt> vecDownAdjEnt;
  vector<pMeshEnt> vecUpAdjEnt;

  for(set<pMeshEnt>::iterator setIter = entitiesToGhost[gDim + (lyr - 2)].begin(); setIter != entitiesToGhost[gDim + (lyr - 2)].end(); setIter++ )
   {
   /* For each entity of gDim, get downward adjacent entities of type bdim and check if they are visited or not*/
   pMeshEnt pEnt= (pMeshEnt)(*setIter);
   FMDB_Ent_GetAdj(pEnt, bDim, dir, vecDownAdjEnt); 

   for(vector<pMeshEnt>::iterator itAdj = vecDownAdjEnt.begin(); itAdj != vecDownAdjEnt.end(); itAdj++ )
   {
    pMeshEnt pBrgEnt = (pMeshEnt)(*itAdj);

    if(pBrgEnt->getAttachedInt(tagVisited) == 1)
       continue;

    pBrgEnt->attachInt(tagVisited, 1);
    tagEnts.insert(pBrgEnt);
    
    if(include_copy == 0 && (pBrgEnt->getOwner() != procId))
     continue;
	
    int dir = 0;
    FMDB_Ent_GetAdj(pBrgEnt, gDim, dir, vecUpAdjEnt);
  
    for(vector<pMeshEnt>::iterator itUpAdj = vecUpAdjEnt.begin(); itUpAdj != vecUpAdjEnt.end(); itUpAdj++ )
     {
      pMeshEnt pUpEnt = (pMeshEnt)(*itUpAdj);
      if(pUpEnt->getAttachedInt(tagVisited) == 1)
       continue;


      for(set<int>::iterator gpiter = pEnt->gpBegin(); gpiter != pEnt->gpEnd(); gpiter++)
      {
      int gId = *gpiter;
   
      if(pUpEnt->getRemoteCopy(gId))
       continue;
       
       pUpEnt->addGPs(gId);
       getDownwardAdjacencies(part, partId, gDim, pUpEnt, gId, entitiesToGhost);
      }
      
      if(pUpEnt->getNumGPs() > 0)
        entitiesToGhost[gDim + (lyr - 1)].insert(pUpEnt);
       } // itUpAdj
      vecUpAdjEnt.clear();
     } // end for itAdj
    vecDownAdjEnt.clear();
    } // end for setIter
}
/* If different parts want to send the same entity information to a destination part, this method will communicate with them so that only a single part sends the entity information to the destination part. */
void eliminateDuplicateEnts(pPart part, int partId, set<pMeshEnt>& gEnts)
{
   /* ipcomman setting for send/recieve messages*/
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  int msg_size = sizeof(pMeshEnt) + sizeof(short int);
  CM->set_fixed_msg_size(msg_size);
  void *msg_send = CM->alloc_msg(msg_size);
  short int* s_pid;
  int iNumSent = 0, iNumRcvd = 0;
  vector<pairRemote> vecRmtCopy;

  for(set<pMeshEnt>::iterator itSet = gEnts.begin(); itSet != gEnts.end(); itSet++ )
   {
   pMeshEnt pDownEnt = *itSet;

   /* if the entity is not a remote copy or its ghost destinations have already been deleted in previous duplicate elimination rounds then skip it */
   if(!pDownEnt->getPClassification() || pDownEnt->getNumGPs() == 0)
    continue;

   FMDB_Ent_GetRmt (pDownEnt, vecRmtCopy);

   for(mEntity::GPIter gpiter = pDownEnt->gpBegin(); gpiter != pDownEnt->gpEnd(); gpiter++)
    {
    int destId = *gpiter;
	
    /* If there exist other remote copies then check with other remote copies if they want to send the entity to the same destination */
    for(vector<pairRemote>::iterator It = vecRmtCopy.begin(); It != vecRmtCopy.end(); It++ )
     {
     int pid = It->first;
     pMeshEnt pRmtCopy = It->second;

     pMeshEnt* s_ent = (pMeshEnt*)msg_send;
     s_ent[0] = pRmtCopy;

     s_pid = (short int*)((char*)msg_send + sizeof(pMeshEnt));
     s_pid[0] = destId;
     CM->send(pid, (void*)msg_send);
      ++iNumSent;
     }
   }
     
    vecRmtCopy.clear();
  }// end for itSet

  CM->finalize_send();
  CM->free_msg(msg_send);
 
  // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
   {
    ++iNumRcvd;
    int sendTo;
    pMeshEnt* s_ent = (mEntity**)msg_recv;
    pMeshEnt pRmtEnt = s_ent[0];

    s_pid = (short int*)((char*)msg_recv + sizeof(mEntity*));
    sendTo = *s_pid;

     CM->free_msg(msg_recv);	

     if(pid_from < partId)
      {
      pRmtEnt->deleteGPs(sendTo);
     /* If after deletion, it has no more destination part ids then delete that entity from entitiesToSend*/
      if(pRmtEnt->getNumGPs() == 0)	
        gEnts.erase(pRmtEnt);	
      }	
    }
}
/* Decides the destination part ids of the entity being ghosted. If entity copies already exists on all parts on which the bridge entity exists then it does not insert it in the ghosting list*/
void setGhostDestination(pPart part, int partId, pMeshEnt bridgeEnt, int gDim, pTag tag, int numLayer, set<pMeshEnt>* entitiesToGhost)
{
  /* 1.1 For each bridge entity, get adjacent entities of ghost dimension 'dim' */
  vector<pMeshEnt> vecAdjEnt;

  int dir = 0,ierr;
  FMDB_Ent_GetAdj (bridgeEnt, gDim, dir, vecAdjEnt);

  int dim = part->getDimension();	
    
 /* if any part does not belong to residence parts of pAdjEnt and belongs to residence parts of bridge entity bridgeEnt, we need a ghost on that part*/
  for (vector<pMeshEnt>::iterator It = vecAdjEnt.begin(); It != vecAdjEnt.end(); It++ )
   {
   pMeshEnt pAdjEnt = (pMeshEnt)(*It);

   /* Get remote copies of the bridge entity*/
   vector<pairRemote> vecBrgRmtCopy;
   ierr = FMDB_Ent_GetRmt (bridgeEnt, vecBrgRmtCopy);
   
   for(vector<pairRemote>::iterator itBrgRmtCpy = vecBrgRmtCopy.begin(); itBrgRmtCpy != vecBrgRmtCopy.end(); itBrgRmtCpy++)
    {
    pairRemote pr = (pairRemote)(*itBrgRmtCpy);
    int prtBId = pr.first;
				
    pMeshEnt pRemoteCopy = pAdjEnt->getRemoteCopy(prtBId);

    if(!pRemoteCopy)
     {
     pAdjEnt->addGPs(prtBId);
	
    if(pAdjEnt->getNumGPs() > 0)
     entitiesToGhost[gDim].insert(pAdjEnt);
			
    /* Get downward adjacencies of the ghost entity*/
     getDownwardAdjacencies(part, partId, gDim, pAdjEnt, prtBId, entitiesToGhost);
      }
     } //end itBrgRmtCpy
      
     vecBrgRmtCopy.clear();
     /* Attach visited tag for processing subsequent layers*/
     if(numLayer > 1)
      {
      int iHasTag = -1;
      iHasTag = pAdjEnt->getAttachedInt(tag);

      if(iHasTag != 1 && (pAdjEnt->getNumGPs()>0))
      {
       pAdjEnt->attachInt(tag, 1);
      }
      }
 } // end vecAdjEnt
    vecAdjEnt.clear();
} // end function

/* Collects the downward adjacent entities of the entity to be ghosted 'ghostEnt'*/
void getDownwardAdjacencies(pPart part, int partId, int gDim, pMeshEnt ghostEnt, int destId, set<pMeshEnt>* entitiesToGhost)
{
  vector<pMeshEnt> vecDownEnts;
  for(int dim = 0; dim < gDim; dim++)
   {
   FMDB_Ent_GetAdj(ghostEnt, dim, 0, vecDownEnts);

   /* Get downward adjacencies of the ghost entity*/
    for (vector<pMeshEnt>::iterator veciter = vecDownEnts.begin(); veciter!=vecDownEnts.end();++veciter)
      {
        /*  We dont want to send duplicate remote copies to the same destination part. Niether we want to send the entity if it already has a remote copy on the destination part*/
     pMeshEnt pDownEnt = *veciter;

    /* If the downward adjacency already exists on remote part in the form of remote or ghost copy then skip it*/
     pMeshEnt pRmtCopy;
     pRmtCopy = pDownEnt->getRemoteCopy(destId);

      if(pRmtCopy)
       continue;

     entitiesToGhost[dim].insert(pDownEnt);
     pDownEnt->addGPs(destId);
     } // end adj vec
    vecDownEnts.clear();
    } // end dim
} // end function 

void exchangeGhostEntities(pPart part, int partId,int gDim,int dim, pmMigrationCallbacks &cb, set<pMeshEnt>& entitiesToSend)
{
  /* ipcomman settings for send/recieve message. We need neighborhood communication only */
  IPComMan *CM = ParUtil::Instance()->ComMan();
  CM->set_comm_validation(IPComMan::Neighbors);
  CM->set_tag(0);
  CM->set_fixed_msg_size(0);
  void *msg_send;
  int num_sent = 0, num_recvd = 0;
  list<rc_struct_2> entitiesToBounce;
 
  unsigned long totalSize = 0;

  /*For numLayer > 1*/
  if(dim > gDim)
    dim = gDim;

  for(set<pMeshEnt>::iterator gcIter=entitiesToSend.begin(); gcIter!=entitiesToSend.end(); gcIter++)
   {
    pMeshEnt pEnt = *gcIter;
    if(pEnt->getNumGPs() == 0)
     continue;

    for(mEntity::GPIter gpiter = pEnt->gpBegin(); gpiter != pEnt->gpEnd(); gpiter++)
       {
       int destId = *gpiter;
       int msg_size;
	
       pack_Ghost_MEntity(pEnt, destId, cb, msg_send, msg_size);
       
       /// Send message to destId
       CM->send(destId, msg_send, msg_size);
       totalSize += msg_size;
       num_sent++;
       CM->free_msg(msg_send);
	}
   } // end for set

  CM->finalize_send();

   // receive phase begins
  void *msg_recv;
  int pid_from;

  while(int rc = CM->receive(msg_recv, &pid_from))
   {
   num_recvd++;
   unpack_Ghost_MEntity(part, gDim, msg_recv, rc, pid_from, cb, entitiesToBounce);
   CM->free_msg(msg_recv);
   }

  /* We only bounce back information about vertices and reg*/
  if(dim == 0 || dim == gDim) 
   exchangeEntities2Bounce(entitiesToBounce, gDim, dim);
}

// **********************************************
void exchangeEntities2Bounce(list<rc_struct_2>& entitiesToBounce, int gDim, int dim)
// **********************************************
{
     int mypid=ParUtil::Instance()->rank();
  int numPtn = ParUtil::Instance()->size();

  list<rc_struct_2> entitiesToBroadcast;

  int msg_size = 2*sizeof(pMeshEnt);
  IPComMan *CM = ParUtil::Instance()->ComMan();

  if(dim == 0)
    CM->set_comm_validation(IPComMan::All_Reduce);
   else 
    CM->set_comm_validation(IPComMan::Neighbors);

  CM->set_tag(0);
  CM->set_fixed_msg_size(msg_size);
  mEntity** msg_send = (mEntity**)CM->alloc_msg(msg_size);
  int iNumSent = 0, iNumRecvd = 0;

  list<rc_struct_2>::const_iterator rcvIter;
  for (rcvIter=entitiesToBounce.begin(); rcvIter!=entitiesToBounce.end();++rcvIter)
  {
    msg_send[0] = rcvIter->ent1;
    msg_send[1] = rcvIter->ent2;
    CM->send(rcvIter->pid, (void*)msg_send);
  }
  CM->finalize_send();
  CM->free_msg(msg_send);

  // receive phase begins
  void *msg_recv;
  int pid_from;
  mEntity** castbuf;
  while(int rc = CM->receive(msg_recv, &pid_from))
  {
  iNumRecvd++;
  castbuf = (mEntity**)msg_recv;
   
  /* For vertices, we need to check if their the parts having their remote copies have destId in their destinations.*/
  if(dim == 0)
   {
   bool bIsThere = false;
   pMeshEnt pVtx = castbuf[1];

  /* 1.1 For each bridge entity, get adjacent entities of ghost dimension 'dim' */
   vector<pMeshEnt> vecAdjEnt;
   int dir = 0;
   FMDB_Ent_GetAdj(pVtx, gDim, dir, vecAdjEnt);
 
 /* Get adjacencies of ghostType using the bridge. If the isGhost flag is set then we need to remove that entity*/
   for (vector<pMeshEnt>::iterator It = vecAdjEnt.begin(); It != vecAdjEnt.end(); It++ )
    {
     pMeshEnt pAdjEnt = (pMeshEnt)(*It);
     if(pAdjEnt->findPidInGPs(pid_from))
     {
     bIsThere = true;
     break;
     }
    }
  if(bIsThere)
   castbuf[1]->addGhostCopy(pid_from, castbuf[0]);
   
   vecAdjEnt.clear();
  } // end if
  else if(dim == gDim)
    castbuf[1]->addGhostCopy(pid_from, castbuf[0]);
    CM->free_msg(msg_recv);
  }

}

void pack_Ghost_MEntity(mEntity* ent, int pid, pmMigrationCallbacks &cb, void *&msg_send, int &msg_size)
{
  char *buf_user;
  int user_size;
  int entity_size;

  IPComMan *CM = ParUtil::Instance()->ComMan();

  /* User may have some data to send to the other process
     These data are of size user_size */
  buf_user = (char*)cb.getUserData(ent, pid, user_size);
  if(!buf_user)
  {
    user_size = 0;
  }

  int entDim = ent->getLevel();

  entity_size = sizeof(bool);

  int n_bytes = 0;

  pMeshEnt ownerEnt;
  FMDB_Ent_GetOwnEnt(ent, ownerEnt);

  /* Pack the remote copies of vertex. We want to notify back the ghost information to all remote copies of vertices. */
  if (entDim == 0)
  {
     short int numRC =  ent->getNumRemoteCopies();
    entity_size += sizeof(packedGhostVertex) + numRC * (sizeof(int) + sizeof(pMeshEnt));

    msg_size = entity_size + user_size;
    msg_send = CM->alloc_msg(msg_size);

   bool *not_vertex = (bool*)msg_send;
    *not_vertex = 0;
    n_bytes++;

  // fixed length data
    packedGhostVertex *castbuf = (packedGhostVertex*)((char*)msg_send + n_bytes);
    castbuf->sender = ent;
    
    castbuf->ownerEnt = ownerEnt;
    castbuf->ownerPid = ent->getOwner();
    castbuf->iD = ent->getId();

   
   castbuf->numRC = numRC;

    pGEntity gent = ent->getClassification();
    if(gent!=0) {
      castbuf->gTag = GEN_tag(ent->getClassification());
      castbuf->gType = GEN_type(ent->getClassification());
    }
    else{
      castbuf->gTag = 1;
      castbuf->gType = 3;
    }
    SCOREC::Util::mPoint p(((mVertex*)ent)->point());
    for(int i=0;i<3;i++)
      castbuf->coord[i] = p(i);
    n_bytes += sizeof(packedGhostVertex);

  
   if(numRC > 0)
     {
       int *RCs_pid;
       pMeshEnt* RCs_ent;	
       
       for (mEntity::RCIter rciter=ent->rcBegin();rciter!=ent->rcEnd();++rciter)
        {
         RCs_pid = (int*)((char*)msg_send + n_bytes);
        *RCs_pid = rciter->first;
         n_bytes += sizeof(int);
         RCs_ent = (mEntity**)((char*)msg_send + n_bytes);
         *RCs_ent = rciter->second;
         n_bytes += sizeof(mEntity*);
       }

     }
  }
  else
  {
//    int numDE = entDim + 1;
    int numDE = ent->size(0);
    entity_size += sizeof(packedGhostNonVertex) + numDE*sizeof(mEntity*);

    msg_size = entity_size + user_size;
    msg_send = CM->alloc_msg(msg_size);

    bool *not_vertex = (bool*)msg_send;
    *not_vertex = 1;
    n_bytes++;

    // fixed length data
    packedGhostNonVertex *castbuf = (packedGhostNonVertex*)((char*)msg_send + n_bytes);
    castbuf->sender = ent;
    castbuf->ownerEnt = ownerEnt;
    castbuf->ownerPid = ent->getOwner();
    castbuf->type = ent->getType();
    castbuf->numDE = numDE;
    pGEntity gent = ent->getClassification();
    if(gent!=0)
       {
      castbuf->gTag = GEN_tag(ent->getClassification());
      castbuf->gType = GEN_type(ent->getClassification());
    }
    else
    {
      castbuf->gTag = 1;
      castbuf->gType = 3;
    }
    n_bytes += sizeof(packedGhostNonVertex);

    mEntity** DEs = (mEntity**)((char*)msg_send + n_bytes);
    mEntity* vtx;
    for (int i=0; i < numDE; i++)
    {
      vtx = ent->get(0,i)->getRemoteCopy(pid);
      if(vtx!=0)
      {
        DEs[i] = vtx;                    // remote copy
      }
      else
      {
	DEs[i] = ent->get(0,i)->getGhostCopy(pid);
      }
     int mypid = ParUtil::Instance()->rank();
    }
    n_bytes += numDE*sizeof(mEntity*);
  }

  if(user_size)
  {
    memcpy((void*)((char*)msg_send + entity_size),buf_user,user_size);
    cb.deleteUserData(buf_user);
  }
}

void unpack_Ghost_MEntity(pPart mesh, int ghostDim, void *msg_recv, int msg_size, int pid,
                  pmMigrationCallbacks &cb, list<rc_struct_2>& entitiesToBounce)
{
  int n_bytes = 0;
  int mypid = ParUtil::Instance()->rank();

  mEntity *ent, *sender, *ownerEnt;
  int ownerPid;

  bool *not_vertex = (bool*)msg_recv;
  n_bytes++;

  if (*not_vertex == 0)
  {
  // STEP 1: create entity
  packedGhostVertex *castbuf = (packedGhostVertex*)((char*)msg_recv + n_bytes);
  n_bytes += sizeof(packedGhostVertex);

  ent = mesh->createVertex(castbuf->iD, castbuf->coord[0], castbuf->coord[1], castbuf->coord[2],
                                  mesh->getGEntity(castbuf->gTag, castbuf->gType));
  sender = castbuf->sender;
  ownerPid = castbuf->ownerPid;
  ownerEnt = castbuf->ownerEnt;

  short int numRC = castbuf->numRC;
  if (numRC>0)
   {
    int RCs_pid;
    pMeshEnt RCs_ent;
    for (short int i=0; i < numRC; i++)
    {
    RCs_pid = *(int*)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(int);
    RCs_ent = *(mEntity**)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(mEntity*);
    entitiesToBounce.push_back(rc_struct_2(ent, RCs_pid, RCs_ent));	  
    }
   }
  }
  else
  {
    packedGhostNonVertex *castbuf = (packedGhostNonVertex*)((char*)msg_recv + n_bytes);
    n_bytes += sizeof(packedGhostNonVertex);

    pGEntity g = mesh->getGEntity(castbuf->gTag, castbuf->gType);
    sender = castbuf->sender;
    ownerPid = castbuf->ownerPid;
    ownerEnt = castbuf->ownerEnt;

// STEP 1: create an entity
    int numDE = castbuf->numDE;
    mEntity** DEs = (mEntity**)((char*)msg_recv + n_bytes);
    mEntity* tmpVerts[10];
    switch (castbuf->type)
    {
      case mEntity::EDGE:
      {
        numDE=2;
        mVertex *v1 = (mVertex*)DEs[0];
        mVertex *v2 = (mVertex*)DEs[1];
        FMDB_Edge_Create(mesh, g, (mEntity*)v1, (mEntity*)v2, ent);
      } break;

      case mEntity::TRI:
      {
        numDE=3;
        mEntity* edges[3];
        FMDB_Ent_Find(mesh, 1, DEs, 2, edges[0]);
        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[1]);
        
        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[2]);

        FMDB_Face_Create(mesh, g, FMDB_TRI, edges, 0, ent);
      } break; 

     case mEntity::QUAD:
      {
        numDE=4;
        mEntity* edges[4];
        FMDB_Ent_Find(mesh, 1, DEs, 2, edges[0]);
       
        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[1]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[2]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        FMDB_Ent_Find(mesh, 1, tmpVerts, 2, edges[3]);
        FMDB_Face_Create(mesh, g, FMDB_QUAD, edges, 0, ent);
      } break;

     case mEntity::TET:
      {
        numDE=4;
        mEntity* faces[4];
        FMDB_Ent_Find(mesh, 2, DEs, 3, faces[0]);
        
        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[2]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[3]);
        FMDB_Rgn_Create(mesh, g, FMDB_TET, 4, faces, ent);
      } break;

	 case mEntity::HEX:
      {
        numDE=8;

        mEntity* faces[6];
        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[2];
        tmpVerts[3] = DEs[1];
        FMDB_Ent_Find(mesh, 2, DEs, 4, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[5];
        tmpVerts[3] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[6];
        tmpVerts[3] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[7];
        tmpVerts[3] = DEs[6];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[4];
        tmpVerts[3] = DEs[7];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[4]);

        tmpVerts[0] = DEs[4];
        tmpVerts[1] = DEs[5];
        tmpVerts[2] = DEs[6];
        tmpVerts[3] = DEs[7];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[5]);
        FMDB_Rgn_Create(mesh, g, FMDB_HEX, 6, faces, ent);

      } break;

       case mEntity::PRISM:
      {
        numDE=6;

        mEntity* faces[5];
        FMDB_Ent_Find(mesh, 2, DEs, 3, faces[0]);
        
        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[4];
        tmpVerts[3] = DEs[3];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[5];
        tmpVerts[3] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[3];
        tmpVerts[3] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 4, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[4];
        tmpVerts[2] = DEs[5];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[4]);
        FMDB_Rgn_Create(mesh, g, FMDB_PRISM, 5, faces, ent);

      } break;

      case mEntity::PYRAMID:
      {
        numDE=5;

        mEntity* faces[5];
        FMDB_Ent_Find(mesh, 2, DEs, 4, faces[0]);

        tmpVerts[0] = DEs[0];
        tmpVerts[1] = DEs[1];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[1]);

        tmpVerts[0] = DEs[1];
        tmpVerts[1] = DEs[2];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[2]);

        tmpVerts[0] = DEs[2];
        tmpVerts[1] = DEs[3];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[3]);

        tmpVerts[0] = DEs[3];
        tmpVerts[1] = DEs[0];
        tmpVerts[2] = DEs[4];
        FMDB_Ent_Find(mesh, 2, tmpVerts, 3, faces[4]);

        FMDB_Rgn_Create(mesh, g, FMDB_PYRAMID, 5, faces, ent);
      } break;

      default :
      {  
        cout<<"unpack_Ghost_MEntity error: unpacking not done for this type of mesh entity\n";
        return;
      }
    }
    n_bytes += numDE*sizeof(mEntity*);
  }

// STEP 2: add sender to ghost copy
  ent->addGhostCopy(ownerPid, ownerEnt);
  ent->addGPs(ownerPid);
  ent->setIsGhost(1);

  // STEP 3: add sender to remote copy and store entity to bounce
  if (ent->getLevel() < 1)                                      
  // only consider ghost vertex now
    entitiesToBounce.push_back(rc_struct_2(ent, pid, sender));
  else
   if(ent->getLevel() == ghostDim)
    entitiesToBounce.push_back(rc_struct_2(ent, ownerPid, ownerEnt));

  IPComMan *CM = ParUtil::Instance()->ComMan();

// STEP 4: process user attached data
  cb.recieveUserData(ent,pid,CM->get_tag(),(void*)((char*)msg_recv + n_bytes));
}

/* deletes existing ghost entities from dimension gDim to 0*/

int deleteGhostEntities(pMeshMdl mesh)
{
  double t1, t2;

  int ierr;
  int iIsEndG = 0;

  /* Get current process id */
  int procId;
  FMDB_GetProcID (&procId);

  /* Get all parts in the current mesh instance. Right now we have one part per mesh instance */
  std::vector<pPart> vecPart;
  FMDB_Mesh_GetProcPart(mesh, procId, vecPart);

  char* tagName = (char*)"visited";
  int tagSize=1; // isn't being used right now.
  int tagType = 0; // for integer
  pTag tagVisited;

  for (vector<pPart>::iterator It = vecPart.begin(); It != vecPart.end(); It++ )
   {
   pPart part = (pPart)(*It);

   /* Get ghosting & bridging information in the part*/
   vector<ghostInfo> gInfo;
   gInfo = part->getGhostRules();

 for(vector<ghostInfo>::iterator itVec = gInfo.begin(); itVec != gInfo.end(); itVec++)
  {
 /* Step 1 First get all part boundary entities of bridge dimension 'bdim' */
  int gDim = itVec->ghostType;
  int bDim = itVec->bridgeType;
  int numLayer = itVec->numLayer;
  int includeCopy = itVec->include_copy;     
   
  if(numLayer > 1)
   FMDB_Tag_Create (mesh, tagName, tagSize, tagType, /*traceable*/ 1, &tagVisited);

   pPartEntIter it;
   pMeshEnt pBrgEnt;
   iIsEndG = FMDB_PartEntIter_InitPartBdry(part, -1, bDim, FMDB_ALLTOPO, it, pBrgEnt);

  if(iIsEndG == 1)
    {
    cout << "\n Cannot continuing entity collection... Unable to get part boundary iterator." << endl;
    return 1;
    }

  set<pMeshEnt>* entitiesToRemove = new set<pMeshEnt>[gDim + 1];
  set<pMeshEnt> setIn, setOut;

  FMDB_GetWTime(&t1);
  while(!iIsEndG)
  {
   setIn.insert(pBrgEnt);
   /* Get next entity on part boundary having dimension bdim*/
   iIsEndG = FMDB_PartEntIter_GetNext(it, pBrgEnt);
  } // end while

   /* Forced tag deletion is an expensive operation so for time being store entities being tagged */
   set<pMeshEnt> tagEnts;

 for(int lyr = 1; lyr <= numLayer; lyr++)
  { 
  removeLyrEnts(part, gDim, bDim, setIn, lyr, entitiesToRemove, setOut, tagVisited, tagEnts);   
  if(lyr < numLayer)
   {
    setIn = setOut;
    setOut.clear();
   }
  }
 
  if(numLayer > 1)
   {
    for(set<pMeshEnt>::iterator itSet = tagEnts.begin(); itSet != tagEnts.end(); itSet++)
     FMDB_Ent_DelTag(*itSet, tagVisited);
    tagEnts.clear();
   }
  
   removeEntities(part, entitiesToRemove, gDim);

  FMDB_GetWTime(&t2);
  // commented out due to performance reasons
 /* double maxTime = 0, localTime = t2 - t1;
  MPI_Allreduce(&localTime,&maxTime,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  if(!procId)
   cout << "\n Maximum deletion time " << maxTime << endl;*/
  }
  part->clearGhostRules();
 } // end vec part
  vecPart.clear();
  if(!procId)
   cout << "\n Ghosts deleted "<< endl;
}

void removeLyrEnts(pPart part,int gDim,int bDim, set<pMeshEnt> inAdjs,int lyr, set<pMeshEnt>* entsRm, set<pMeshEnt>& outAdjs, pTag tag, set<pMeshEnt>& tagEnts)
{
/* Get current process id */
   int procId;
   FMDB_GetProcID (&procId);

for (set<pMeshEnt>::iterator iter = inAdjs.begin(); iter!=inAdjs.end();++iter)
{
  pMeshEnt pDownEnt = *iter;

  if(pDownEnt->getAttachedInt(tag) == 1)
   continue;

  if(lyr > 1)
   {
   pDownEnt->attachInt(tag, 1);
   tagEnts.insert(pDownEnt);
   }

  vector<pMeshEnt> vecUpAdjs;
  FMDB_Ent_GetAdj(pDownEnt, gDim, 0, vecUpAdjs);

  for(vector<pMeshEnt>::iterator iter2 = vecUpAdjs.begin(); iter2!=vecUpAdjs.end();++iter2)
   {
    vector<pMeshEnt> tmpVec;
    pMeshEnt pEnt = *iter2;
    if(pEnt->getAttachedInt(tag) == 1)
      continue;
    /* Clear all ghosting references*/
    pEnt->clearGPs();
    pEnt->clearGhostCopies();

    if(pEnt->getIsGhost() == 1)
    {
     pEnt->attachInt(tag, 1);
     entsRm[gDim].insert(pEnt);
    }
     
    FMDB_Ent_GetAdj(pEnt, bDim, 0, tmpVec);

    deleteDownwardAdj(part, pEnt, entsRm, gDim);

    for(vector<pMeshEnt>::iterator itAdj = tmpVec.begin(); itAdj != tmpVec.end(); itAdj++)
     outAdjs.insert(*itAdj);        

    tmpVec.clear();
   }
  }
}
void deleteDownwardAdj(pPart part, pMeshEnt pEnt, set<pMeshEnt>* entitiesToRemove, int gDim)
{
  for(int dim = 0; dim < gDim; dim++)
    {
    vector<pMeshEnt> vecDownEnts;
    FMDB_Ent_GetAdj(pEnt, dim, 0, vecDownEnts);

    /* Get downward adjacencies of the ghost entity*/
    for (vector<pMeshEnt>::iterator veciter = vecDownEnts.begin(); veciter!=vecDownEnts.end();++veciter)
     {
      pEntity pDownEnt = *veciter;

      pDownEnt->clearGPs();
      pDownEnt->clearGhostCopies();

     if(pDownEnt->getIsGhost() == 1)
      entitiesToRemove[dim].insert(pDownEnt);
    }
  vecDownEnts.clear();
 } // end dim
}
void removeEntities(pPart part, set<pMeshEnt>* entitiesToRemove, int gDim)
{
  for(int dim = gDim; dim >= 0; dim-- )  
  {
  for(set<pMeshEnt>::iterator it = entitiesToRemove[dim].begin(); it != entitiesToRemove[dim].end(); it++ )
   {
   pMeshEnt pEnt = *it; 
   if(dim >= 3)
     M_removeRegion(part, pEnt);
	     
    else if(dim == 2)
    M_removeFace(part, pEnt);

    else if(dim == 1)
    M_removeEdge(part, pEnt);
	    
   else if (dim == 0)
   M_removeVertex(part, pEnt);
	     
   else
   cout<< "\n Entity dimension unknown! " << dim << endl;		
  } // end set
 } // end for dim
} // end fn
#endif
