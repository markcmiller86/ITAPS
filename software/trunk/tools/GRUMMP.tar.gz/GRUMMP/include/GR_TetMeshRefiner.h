#ifndef GR_TETMESHREFINER_H
#define GR_TETMESHREFINER_H

#include "GR_BFace.h"
#include "GR_Subseg.h"

#include <deque>
#include <map>
#include <queue>
#include <set>
#include <utility>
#include <vector>
#include <functional>

class Length3D;
class Vert;
class VolMesh;

//This class is basically a wrapper around a TR1 unordered_map
//used to store vertex to subsegment connectivity. This is needed by curved
//boundary as a surface face can actually be connected to 3 vertices
//on the same curve. In such a situation, it is impossible to 
//determine which of the face's three edges are actually subsegments.

class SubsegMap {
 
  typedef std::set<Subseg*> SubsegSet;
  typedef GR_map<Vert*, SubsegSet> SubsegMapType;
  
  SubsegMapType m_map;

  std::vector<Subseg*> m_to_release;

  //Forbid copy construction and operator= since not needed right now.
  SubsegMap(const SubsegMap&);
  SubsegMap& operator=(const SubsegMap&);

 public:

  //Creates and empty map;
  SubsegMap() : m_map(), m_to_release() { }

  ~SubsegMap();

  //Release the deleted subsegs in m_to_release.
  void release_deleted_subsegs();
  
  //Clears the map.
  void clear() { m_map.clear(); }

  //Checks if the map is empty.
  bool empty() const { return m_map.empty(); }

  //How many entries in the map?
  int size() const { return static_cast<int>(m_map.size()); } 

  //Add connectivity info for subseg vert0-vert1 to the map.
  void add_subseg(Subseg* const subseg);

  //Removes subseg vert0-vert1 from the map.
  void remove_subseg(Subseg* const subseg);

  //Checks if vertex is connected to subseg.
  bool vert_has_subseg(Vert* const vertex, Subseg* const subseg) const;

  //Returns the subseg connecting the two verts (if there is one).
  //Otherwise, returns NULL.
  Subseg* verts_are_connected(Vert* const vert0, Vert* const vert1) const;
 
  //Returns the set of subsegs attached to a given vert.
  const std::set<Subseg*>& get_subsegs(Vert* const vert0) const;

  //Returns the set iterator range containing the subsegs of vert0. 
  std::pair<SubsegSet::const_iterator, SubsegSet::const_iterator> get_subseg_range(Vert* const vert0) const;
    
  //Populates all_subsegs with all subsegs in the map.
  void get_all_subsegs(std::set<Subseg*>& all_subsegs) const;

  //Gets a vector of vertices connected to vert0.
  void get_connected_verts(Vert* const vert0, std::vector<Vert*>& verts) const;

  void update_vert_data_after_purge(const std::map<Vert*, Vert*>& vert_map);

  //Checks the validity of the map entries.
  bool valid() const;

  //Prints the content of the map;
  void print() const;

 private:

  struct SubsegHasVert {
    const Vert* m_vert;
    SubsegHasVert(const Vert* const vert) : m_vert(vert) { }
    bool operator()(const Subseg* const subseg) const { return subseg->has_vert(m_vert); }
  };

};

//This is used to identify edges that already have been checked
//for encroachment while computing the Watson cavity around
//a new vertex.

class TetRefinerEdge {

 protected:

  Vert *m_v0, *m_v1;
  BFace* m_bface;

 public:

  TetRefinerEdge() : m_v0(NULL), m_v1(NULL), m_bface(NULL) { }
  TetRefinerEdge(Vert* const v0, Vert* const v1)
    : m_v0( v0 < v1 ? v0 : v1 ), m_v1( v0 < v1 ? v1 : v0 ), m_bface(NULL) { assert( valid() ); }
  TetRefinerEdge(Vert* const v0, Vert* const v1, BFace* const bface)
    : m_v0( v0 < v1 ? v0 : v1 ), m_v1( v0 < v1 ? v1 : v0 ), m_bface(bface) { assert( valid() ); }
  TetRefinerEdge(const TetRefinerEdge& edge)
    : m_v0(edge.m_v0), m_v1(edge.m_v1), m_bface(edge.m_bface) { assert( valid() ); }
  TetRefinerEdge& operator=(const TetRefinerEdge& edge) 
    { 
      if (&edge != this) {
	m_v0 = edge.m_v0; m_v1 = edge.m_v1; 
	m_bface = edge.m_bface; 
	assert( valid() ); 
      }
      return *this; 
    }
  virtual ~TetRefinerEdge() { }

  Vert* vert(int i) const { assert( i == 0 || i == 1 ); return i == 0 ? m_v0 : m_v1; }
  Vert* beg_vert() const { return m_v0; }
  Vert* end_vert() const { return m_v1; } 

  BFace* get_bface() const { return m_bface; }

  int is_reflex() const;

  bool operator<(const TetRefinerEdge& edge) const {
    assert( valid() && edge.valid() );
    return ( (m_v0 <  edge.m_v0) ||
	     ( (m_v0 == edge.m_v0) && (m_v1 < edge.m_v1) ) );
  }
  bool operator==(const TetRefinerEdge& edge) const {
    assert( valid() && edge.valid() );
    return ( m_v0 == edge.m_v0 && m_v1 == edge.m_v1 );
  }
  bool operator!=(const TetRefinerEdge& edge) const {
    return !( *this == edge );
  }
  bool valid() const {
    if(!m_v0 || !m_v1) return false;
    return (m_v0 < m_v1);
  }

};

//This derived class is used to infer subsegments given
//a tetrahedral mesh using GRUMMP's native geometry. Note
//that this native geometry does not allow orphaned edges
//or surfaces not bounding at least on meshed region.

class TetRefinerEdgeBFace : public TetRefinerEdge { 

  std::set<BFace*> m_bfaces;

 public:

  TetRefinerEdgeBFace() : TetRefinerEdge(), m_bfaces() { }

  TetRefinerEdgeBFace(Vert* const v0, Vert* const v1)
    : TetRefinerEdge(v0, v1), m_bfaces() { assert( valid() ); }
  TetRefinerEdgeBFace(const TetRefinerEdgeBFace& edge)
    : TetRefinerEdge(edge), m_bfaces(edge.m_bfaces) { assert( valid() ); }
  TetRefinerEdgeBFace& operator=(const TetRefinerEdgeBFace& edge) 
    { m_v0 = edge.m_v0; m_v1 = edge.m_v1; m_bfaces = edge.m_bfaces; assert( valid() ); return *this; }
  virtual ~TetRefinerEdgeBFace() { }

  const std::set<BFace*>& get_bfaces() const { return m_bfaces; }

  void add_bface(BFace* const bface) { m_bfaces.insert(bface); }

  void remove_bface(BFace* const bface) { m_bfaces.erase(bface); }

  void clear_bfaces() { m_bfaces.clear(); }

};

//Class in which all the functions to compute 
//a cell's priority are defined. Should be easily expandable.

class PriorityCalculator {

 public:

  enum PrioType { EDGE_RADIUS, SIN_DIHED, BIAS_SIN_DIHED, VOLUME_LENGTH,
		  MIN_SOLID, NORMALIZED_SHAPE_RATIO, MEAN_RATIO,
		  VOLUME_AREA_RATIO, INRAD_ALTITUDE, INRAD_LENGTH, LONGEDGE_MINALT,
		  UNKNOWN };

 private:

  PrioType m_type;

  //The object to compute the length scale.
  //Instantiated elsewhere, pointer is passed to the constructor.
  Length3D* m_length;

  PriorityCalculator(const PriorityCalculator&) 
    : m_type(UNKNOWN), m_length(NULL) { assert(0); }

  PriorityCalculator& operator=(const PriorityCalculator&) { assert(0); return *this; }

 public:

  PriorityCalculator(PrioType type = UNKNOWN) 
    : m_type(type), m_length(NULL) { }
  
  virtual ~PriorityCalculator();

  void set_length_calculator(Length3D* const length);

  void set_priority_type(PrioType type) { m_type = type; }

  //Return the shape priority and the length priority separately.

  void compute_priority(const Cell* const cell, double& length_prio, double& shape_prio) const;

  //This function is set up to return:
  // . 0 if the cell is small enough with respect to the sizing field.
  // . -LARGE_DBL if the cell MUST NOT BE SPLIT (useful for small angles)
  // . A positive size priority if the cell must be split.

  double compute_length_priority(const Cell* const cell) const;
  
  //Static functions computing different quality measures for a tet.

  static double edge_radius_ratio(const Cell* const cell);

  static double min_sin_dihed(const Cell* const cell);

  static double bias_min_sin_dihed(const Cell* const cell);

  static double volume_length(const Cell* const cell);

  static double min_solid(const Cell* const cell);

  static double normalized_shape_ratio(const Cell* const cell);

  static double mean_ratio(const Cell* const cell);

  static double volume_area_ratio(const Cell* const cell);

  static double inrad_altitude_ratio(const Cell* const cell);

  static double inrad_longest_edge_ratio(const Cell* const cell);

  static double long_edge_min_altitude_ratio(const Cell* const cell);
};

class CellQueueEntry {

  Cell* m_cell;
  double m_priority;

  CellQueueEntry() : m_cell(NULL), m_priority(LARGE_DBL) { assert(0); }
  CellQueueEntry(const CellQueueEntry&) : m_cell(NULL), m_priority(LARGE_DBL) { assert(0); }
  CellQueueEntry& operator=(const CellQueueEntry&) { assert(0); return *this; }

 public:

  CellQueueEntry( Cell* const cell, double priority = LARGE_DBL ) 
    : m_cell(cell), m_priority(priority) { }

  virtual ~CellQueueEntry() {}

  Cell* get_cell() const { assert(m_cell); return m_cell; }
  double get_priority() const { assert(m_cell); return m_priority; }

  void set_cell(Cell* cell) { m_cell = cell; }

  bool deleted() const { assert(m_cell); return m_cell->isDeleted(); }
  
  class PrioOrder {
    bool m_reverse;
   public:
    PrioOrder(const bool& reverse = false) : m_reverse(reverse) {}
    bool max_on_top() const { return !m_reverse; }
    bool operator() (const CellQueueEntry* const entry0,
		     const CellQueueEntry* const entry1) const {
      return ( m_reverse ? 
	       (entry0->m_priority > entry1->m_priority) : 
	       (entry0->m_priority < entry1->m_priority) );
    }
  };

};

typedef std::priority_queue
< CellQueueEntry*, std::vector<CellQueueEntry*>, CellQueueEntry::PrioOrder > 
  RefinementPrioQueue;

//Priority queue to control refinement.
class RefinementQueue : public RefinementPrioQueue {

  typedef std::vector<CellQueueEntry*> EntryVec;

  PriorityCalculator* m_calculator;

  double m_min_shape_priority, m_max_shape_priority;

  // Never defined
  RefinementQueue(const RefinementQueue&);
  RefinementQueue& operator=(const RefinementQueue&);

 public:

  RefinementQueue() 
    : RefinementPrioQueue(), 
      m_calculator( new PriorityCalculator(PriorityCalculator::UNKNOWN) ),
      m_min_shape_priority(-LARGE_DBL), m_max_shape_priority(LARGE_DBL) { }

  RefinementQueue( PriorityCalculator::PrioType prio_type, bool max_prio_top = true,
		   double min_shape_priority = 0.,
		   double max_shape_priority = LARGE_DBL )
    : RefinementPrioQueue( max_prio_top ? CellQueueEntry::PrioOrder() : CellQueueEntry::PrioOrder(true) ),
      m_calculator( new PriorityCalculator(prio_type) ),
      m_min_shape_priority(min_shape_priority),
      m_max_shape_priority(max_shape_priority) { }

  virtual ~RefinementQueue();

  //Access to the vector upon which the queue is built.
  //EntryVec& impl() const { return c; }

  //Returns the first UNDELETED cell at the top of the queue. 
  //All the deleted entries at the top will get removed.
  //Returns NULL if the queue no longer contains valid cells.
  Cell* get_top_valid_cell();

  //Pops the top entry from the queue. Returns false is the queue is empty.
  bool pop_top_entry();

  //Adds a cell to the queue. 
  //(builds a CellQueueEntry and computes priority in the background)
  //Returns true if the cell is actually inserted (it is within the 
  //refinement bounds of the refinement criterion).
  void add_entry(Cell* const cell);

  //Removes all deleted entries from the queue.
  void clean_queue();

  //Empties the queue completely
  void empty_queue() { while(pop_top_entry()) {} assert(empty()); }

  void update_entries_after_purge(const std::map<Cell*, Cell*>& cell_map);

  //
  void set_priority_type(PriorityCalculator::PrioType type) 
  { assert(m_calculator); m_calculator->set_priority_type(type); }

  void set_min_shape_priority(double min_shape_priority) 
  { assert(min_shape_priority >= 0.); m_min_shape_priority = min_shape_priority; }

  void set_max_shape_priority(double max_shape_priority) 
  { assert(max_shape_priority >= 0.); m_max_shape_priority = max_shape_priority; }

  void set_length_calculator(Length3D* const length)
  { assert(length && m_calculator); m_calculator->set_length_calculator(length); } 

  //Prints the content of the queue and aborts.
  void print_queue();

};

//This class acts as a driver for the Delaunay refinement
//algorithm.

class TetMeshRefiner {

  //The tetrahedral mesh to refine.
  VolMesh* m_mesh;
  
  //The length scale calculator.
  Length3D* m_length;

  //The queues "controlling" the refinement.
  std::deque<Subseg*> m_subseg_queue;
  std::deque<BFace*>  m_subface_queue;
  RefinementQueue*    m_cell_queue;

  //At this point, we do not want to store subsegments explicitely
  //in the mesh data structure. 
  SubsegMap m_subseg_map;

  //Make these private (for now).
  TetMeshRefiner();
  TetMeshRefiner(const TetMeshRefiner&);
  TetMeshRefiner& operator=(const TetMeshRefiner&);

  //To initialize the queues with encroached boundary and
  //cells that do not meet refinement criteria.
  void initialize_queues();
  void queue_encroached_subsegs();
  void queue_encroached_subfaces();
  void queue_cells();

  //Clears the deleted entries at the top of m_subseg_queue and m_subface_queue
  //Returns false if the queue is empty after clearing, true otherwise.
  bool clear_top_subseg_queue();
  bool clear_top_subface_queue();

 public:

  //The possible types of split. 
  enum SplitType { SUBSEG, SUBFACE, CELL, LOCKED, NONE, UNKNOWN };

  //The constructor...
  TetMeshRefiner(VolMesh* const mesh, 
		 const std::set<Subseg*>* const subsegs = NULL,
		 const eEncroachType encroach_type = eBall,
		 const PriorityCalculator::PrioType = PriorityCalculator::EDGE_RADIUS,
		 double refine = 1., double grade = 1.);

  //... and destructor.
  virtual ~TetMeshRefiner();

  //Returns the mesh pointer.
  VolMesh* get_mesh() const { return m_mesh; }

  void print_quality_data() const;

  //A BUNCH OF THE FOLLOWING SHOULD DEFINITELY BE PRIVATE.

  //Refines the boundary entities until they satisfy the sizing field.  
  int refine_subsegs_for_length();
  int refine_subfaces_for_length();

  //Runs a refinement loop, inserts all vertices it can 
  //until all queues are empty.
  //Returns total number of vertices inserted.
  int run_refinement_loop(int inserts_since_purge);

  //Refine the mesh for quality (and size).
  void refine_for_quality();

  //(deprecated) This will refine the mesh until the queues are empty.
  //Actually calls refine_for_quality().
  void refine();
  
  //Functions to split a mesh entity.
  SplitType split_subseg(Subseg* const subeg_to_split,
			 std::pair<Subseg*, Subseg*>* new_subsegs = NULL,
			 std::vector<BFace*>* new_subfaces = NULL,
			 std::vector<Cell*>* new_tets = NULL);

  SplitType split_subface(BFace* const subface_to_split,
			  std::vector<BFace*>* new_bfaces = NULL,
			  std::vector<Cell*>* new_tets = NULL);

  SplitType split_tetra(Cell* const tetra,
			std::vector<Cell*>* new_cells = NULL);

  //Returns the sizes of the different queues.
  int subseg_queue_size() const { return static_cast<int>(m_subseg_queue.size()); }
  int subface_queue_size() const { return static_cast<int>(m_subface_queue.size()); }
  int cell_queue_size() const { assert(m_cell_queue); return static_cast<int>(m_cell_queue->size()); }

  //Check for encroachment of boundary entities.
  bool subface_is_encroached(const BFace* const bface) const;
  bool subseg_is_encroached(const Subseg* const subseg) const;

  //this is dangerous. I only use it for development / debuging purposes.
/*   Subseg* get_top_subseg() const { return m_subseg_queue.front(); } */
/*   BFace* get_top_subface() const { return m_subface_queue.front(); } */

 private:
  
  //This function initializes m_subseg_map with either a set of
  //subsegs that was obtain somewhere else, or by infering the
  //susbegs from m_mesh (this last case should only be used with
  //GRUMMP's native geometry).
  void initialize_subsegs( const std::set<Subseg*>* const subsegs );

  // *** The following functions are used to compute the Watson cavity *** //

  //Computes the Watson cavity that is formed by inserting vertex
  //into the mesh. seed_cells contains one or more tets having vertex 
  //in their circumsphere (used to initialize marching).
  //Returns false if the vertex in not-insertable (influence small angle)
  bool compute_watson_cavity( Vert* const vertex, 
			      const std::vector<Cell*>& seed_cells, 
			      std::set<Cell*>& cells_to_remove,
			      std::set<BFace*>& bfaces_hit,
			      std::set<Subseg*>& encroached_subsegs,
			      bool exit_on_encroachment = false ) const;

  // Called when computing Watson cavity.
  // If cell has one (or more) of its edges corresponding to 
  // a subsegment, this function checks if the subsegment is encroached. 
  bool has_encroached_subseg( Cell* const cell,
			      Vert* const vertex,
			      std::set<TetRefinerEdge>& edges_visited,
			      std::set<Subseg*>& encroached_subsegs,
			      bool exit_on_encroachment ) const;

  //Called when computing Watson cavity. 
  //Basically looks at cell's neighbors:
  // - If it is a tet, adds it to the cells_to_visit.
  // - If it is a bface, adds it to bfaces_hit.
  void update_visit_queue( Cell* const cell,
			   std::queue<Cell*>& cells_to_visit,
			   std::set<BFace*>& bfaces_hit ) const;
  
  //Finds the seed cells for a subsegment.
  void find_seed_cells( Vert* const vertex,
			Subseg* const subseg,
			std::vector<Cell*>& cells ) const;

  //Finds the seed cells for a subface.
  void find_seed_cells( Vert* const vertex,
			BFace* const bface,
			std::vector<Cell*>& cells ) const;

  //After computing the Watson cavity, all bfaces that were hit
  //need to be classified as faces to remove or faces that are encroached.
  //If this is a subsegment split, the subseg_to_split must be passed.
  bool classify_bfaces( Vert* const vertex,
			const std::set<Cell*>& cells_to_remove,
			const std::set<BFace*>& cavity_bfaces,
			const std::set<BFace*>& seed_bfaces,
			std::set<BFace*>& bfaces_to_remove,
			std::set<BFace*>& bfaces_encroached,
			std::set<TetRefinerEdge>& edges_with_bface,
			const Subseg* const subseg_to_split = NULL ) const;

  //Given cells and bfaces to remove from the mesh, computes the
  //faces to remove and the faces forming the Watson hull.
  void build_watson_hull( const std::set<Cell*>& cells_to_remove,
			  std::set<Face*>& faces_to_remove,
			  std::map<Face*, int>& faces_of_hull,
			  const std::set<BFace*>* bfaces_to_remove = NULL) const;


  // ********************************************************************* //

  //Purges deleted mesh data and updates maps, queues, etc.
  //Most be called when m_subseg_queue and m_subface_queue are empty.
  void purge();

  //Functor that determines if m_vertex is encroaching on boundary faces.
  struct BFaceIsEncroached : public std::unary_function<BFace*, bool> {

    const Vert* m_vertex; 
    //The plan is to only support eBall for now, but thinking
    //forward, add it to the interface just in case plans change.
    eEncroachType m_enc_type; 

    BFaceIsEncroached(const Vert* const vertex, eEncroachType enc_type) 
      : m_vertex(vertex), m_enc_type(enc_type) 
    { assert( m_enc_type == eBall ); }

    bool operator() (const BFace* const bface) const {
      return ( bface->isPointEncroaching( m_vertex->getCoords(), m_enc_type ) != eClean );
    }

  };

  //Functor that checks if a given BFace (must be a TriBFaceBase descendent)
  //has the two vertices passed.
  struct BFaceHasTwoVerts : public std::unary_function<BFace*, bool> {

    const Vert *m_vert0, *m_vert1;

    BFaceHasTwoVerts(const Vert* const vert0, const Vert* const vert1) 
      : m_vert0(vert0), m_vert1(vert1) { }

    bool operator() (const BFace* const bface) const;

  };

  //Functor that checks if a BFace has some given vertex.
  struct BFaceHasVert : public std::unary_function<BFace*, bool> {

    const Vert *m_vert;

    BFaceHasVert(const Vert* const vert) : m_vert(vert) { }

    bool operator() (const BFace* const bface) const;

  };

/*   //A bunch of functions outputting stuff in medit format. Mostly */
/*   //useful for debugging purposes. */

/*   void output_cavity(const char* const filename, */
/* 		     const std::set<Cell*>& cells_to_remove, */
/* 		     const std::set<BFace*>& bfaces_to_remove, */
/* 		     const std::set<BFace*>& bfaces_encroached) const; */

/*   void output_bfaces(const char* const filename, */
/* 		     const std::set<BFace*>* const bfaces_to_print = NULL) const; */

/*   void output_subsegs(const char* const filename) const; */

/*   void output_faces(const char* const filename, */
/* 		    std::set<Face*>& faces_to_print) const; */

 public:

  static bool vert_inside_diam_sphere(const Vert* vertex, 
				      const Vert* vert0, const Vert* vert1) {
    double mid[] = { 0.5 * (vert0->x() + vert1->x()), 
		     0.5 * (vert0->y() + vert1->y()),
		     0.5 * (vert0->z() + vert1->z()) };
    return ( dDIST3D(vertex->getCoords(), mid) < 
	     dDIST3D(vert0->getCoords(), vert1->getCoords()) );
  }

  static bool vert_inside_equat_sphere(const Vert* vertex, const BFace* bface) {
    assert(bface->getType() == Cell::eTriBFace || 
	   bface->getType() == Cell::eIntTriBFace);
    double circcent[3];
    bface->calcCircumcenter(circcent);
    return ( dDIST3D(vertex->getCoords(), circcent) < 
	     dDIST3D(bface->getVert(0)->getCoords(), circcent) );
  }

/*   static void output_cells(const char* const filename, */
/* 			   const std::set<Cell*>& cells_to_print) ; */

/*   static void output_mesh_to_file(const VolMesh* const mesh, */
/* 				  const char* const filename); */

};

//This function is necessary to correct possible error from the insphere predicate.
//Given a tet in the Watson cavity, ONE of its face will be on the cavity's boundary. 
//The vertex opposite this face and the vertex getting inserted MUST BE ON THE SAME SIDE
//of this face. Otherwise, the tet is declared invisible and removed from the Watson cavity.
//The function is called recursively until the cavity is reconnectable.

bool correct_cavity(const Vert* const vertex,
		    std::set<Cell*>& cells_to_remove,
		    std::set<Face*>& faces_to_remove, 
		    std::map<Face*, int>& faces_of_hull,
		    std::set<BFace*>* const bfaces_to_remove = NULL,
		    std::set<TetRefinerEdge>* const edges_with_bface = NULL );
#endif
