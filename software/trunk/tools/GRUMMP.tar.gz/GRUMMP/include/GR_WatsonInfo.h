#ifndef GR_WatsonInfo
#define GR_WatsonInfo 1

#include <set>
#include <vector>

#include "GR_config.h"
#include "GR_InsertionQueue.h"
#include "GR_Mesh2D.h"
#include "GR_VolMesh.h"

// This is the old WatsonInfo class, which is being replaced. Don't ues it in
// new code.  CFO-G Oct 16, 2012

class WatsonInfo_deprecated {
private:
  // All the data you might need to do Watson insertion into a mesh.
  std::set<Cell*> spCToRemove;
  std::set<BFace*> spBFEncroached;
  std::set<Face*> spFHull, spFToRemove;

  // The InsertionQueueEntry that is causing all the fuss...
  InsertionQueueEntry IQE;

  // The mesh that we're working on refining...
  const Mesh *pM;

  // Location of new point that -might- be inserted
  double adNewPoint[3];

  // Also, storage for newly created entities, so that these can be
  // added to the queue if necessary.  All new cells and bface are added
  // to the appropriate lists.  
  std::vector<Cell*> vecpCNew;
  std::vector<BFace*> vecpBFNew;

  WatsonInfo_deprecated(const WatsonInfo_deprecated&); // Never defined
  WatsonInfo_deprecated(); // Never defined
  WatsonInfo_deprecated& operator=(const WatsonInfo_deprecated&); // Never defined

  bool qIs3DHullOkay(const enum eEncroachType eET) const;
  void vStrip3DHull();
public:
  WatsonInfo_deprecated(const InsertionQueueEntry& IQEIn,
                        const Mesh* const pMIn);
  ~WatsonInfo_deprecated()
  {
  }

  InsertionQueueEntry::eEntryType eType() const
  {
    return IQE.eType();
  }

  // This function will only be called in one place; it exists to avoid
  // the need for returning the set of encroached BFaces.  Defining it
  // here makes in inline-able, which eliminates all the call overhead.
  int iQueueEncroachedBdryEntities(InsertionQueue& IQ, const double dOffset)
  {
    std::set<BFace*> spBFModEncr(spBFEncroached);
    std::set<BFace*>::iterator iterBF;
    // Remove BFaces incident on an encroached subsegment; they won't
    // survive anyway.
    for (iterBF = spBFModEncr.begin(); iterBF != spBFModEncr.end();) {
      BFace *pBF = *iterBF;
      if (IQE.eType() == InsertionQueueEntry::eSubSeg
          && (pBF->hasVert(IQE.pVVert(0)) || pBF->hasVert(IQE.pVVert(1)))) {
        std::set<BFace*>::iterator iterTmp = iterBF++;
        spBFModEncr.erase(iterTmp);
      }
      else {
        iterBF++;
      }
    }
    // If a BFace was encroached, it's already queued; don't requeue it.
    if ((IQE.eType() == InsertionQueueEntry::eTriBFace
        || IQE.eType() == InsertionQueueEntry::eBdryEdge)
        && spBFModEncr.size() > 1) {
      spBFModEncr.erase(IQE.pBFBFace());
    }
    return (pM->queueEncroachedBdryEntities(IQ, spBFModEncr, adCoords(),
                                             dOffset));
  }

  // Cells that should be deleted
  size_t iNumCellsToRemove() const
  {
    return spCToRemove.size();
  }

  // Location of new vertex
  const double *adCoords() const
  {
    return adNewPoint;
  }
  int iAddNewEntitiesToQueue(InsertionQueue& IQ) const;

  friend int VolMesh::insertPointWatson_deprecated(WatsonInfo_deprecated&);
  friend void VolMesh::cleanupWatson_deprecated(WatsonInfo_deprecated&);

  friend int Mesh2D::insertPointWatson_deprecated(WatsonInfo_deprecated&);
  friend void Mesh2D::cleanupWatson_deprecated(WatsonInfo_deprecated&);
};

#endif
