#ifndef GR_Mesh
#define GR_Mesh 1

#include <map>
#include <set>

#include "GR_CellQueue.h"
#include "GR_config.h"
#include "GR_BFace.h"
#include "GR_Cell.h"
#include "GR_EntContainer.h"
#include "GR_Face.h"
#include "GR_Observable.h"
#include "GR_Quality.h"
#include "GR_Vertex.h"

enum eSwap {eNone, eDelaunay, eMaxDihed, eMinSine, eFromQual, eRandom};

class CellQueue;
class AnisoRefinement;

/**\brief This is the base class for all mesh data.
 *
 * Vertex data is the primary thing stored internally; connectivity data is
 * declared in the derived classes.
 */
// The publishing side of the Observer paradigm is implemented in the
// Observable class.
class Mesh : public GRUMMP::Observable {
private:
  /// Operator= disallowed.
  Mesh& operator=(const Mesh&) {assert(0); return(*this);}
protected:
  std::set<Vert*> m_vertsToUpdateLenScale;
  ///
 public:
  /// Variable-sized array for storing vertex data.
  EntContainer<Vert> m_ECVerts;
  /// Size factor: this is the approx number of edges per
  /// feature size.
  double m_resolution;
  /// Grading constant
  double m_LipschitzAlpha;
  /// Quality measure.  Will eventually not be a Mesh member.
  mutable Quality *m_qual;
 
public:
  void setAlpha(const double dA) {m_LipschitzAlpha = dA;}
  double getAlpha() const {return m_LipschitzAlpha;}
protected:
  // Used for coarsening.
  int m_interiorSkip;
  bool m_fillBdry:1;
  ///
 protected:
  ///
  bool m_swapRecursively:1;
  ///
  bool m_allowBdryChanges:1;
  ///
  bool m_isLengthScaleInitialized:1;
  bool m_isLengthScaleFromCellSizes:1;
  bool m_interpolateLengthScale:1;
  ///
  bool m_simplexMesh:1;
  ///
  eSwap m_swapMeasure:3;
  ///
  eEncroachType m_encroachType:3;
  ///
  /// Pointer to Cell Queue
 public:
  // These next two variables are strictly for 2D aniso insertion.
  // TODO: Factor these out of Mesh, and even out of Mesh2D.
  CellQueue* pCellQueue;          //A pointer to the meshes InsertionQueue
  AnisoRefinement* pAnisoRef;   //A pointer to the meshes Anisotropic Refinement
  //Pointer to a set of Faces
  //  std::set<Face*>* psetPFaces;  //used in anisotropic meshing
/// Constructor and destructor
public:
  enum eMeshType {eMesh2D, eSurfMesh, eVolMesh};
  enum eInsertType {eBadCell, eBdryFaceEncroach, eBdrySegEncroach};
  ///
  Mesh() :
  m_vertsToUpdateLenScale(), m_ECVerts(), m_resolution(1),
    m_LipschitzAlpha(1),
    m_qual(NULL), m_interiorSkip(3),
    m_fillBdry(true), m_swapRecursively(true), m_allowBdryChanges(true),
    m_isLengthScaleInitialized(false), m_isLengthScaleFromCellSizes(false),
    m_interpolateLengthScale(false),
    m_simplexMesh(true), m_swapMeasure(eDelaunay), m_encroachType(eLens),
    pCellQueue(NULL), pAnisoRef(NULL)
    {
      // The value of m_interiorSkip is the correct default for all meshes.
      // The value of m_fillBdry is the proper default for 2D and surface;
      // the 3D constructors override this.
      // Can't initialize Quality at the Mesh level.      
    }
  ///
  Mesh(const EntContainer<Vert>& ECPts) :
    m_vertsToUpdateLenScale(), m_ECVerts(), m_resolution(1),
    m_LipschitzAlpha(1),
    m_qual(NULL), m_interiorSkip(3),
      m_fillBdry(true), m_swapRecursively(true),
    m_allowBdryChanges(true), m_isLengthScaleInitialized(false),
    m_isLengthScaleFromCellSizes(false),
    m_interpolateLengthScale(false),
    m_simplexMesh(true), m_swapMeasure(eDelaunay), m_encroachType(eLens),
      pCellQueue(NULL), pAnisoRef(NULL)
    {
      // The value of m_interiorSkip is the correct default for all meshes.
      // The value of m_fillBdry is the proper default for 2D and surface;
      // the 3D constructors override this.
      int iDim = ECPts.getEntry(0)->getSpaceDimen();
      for (GR_index_t i = 0; i < ECPts.lastEntry(); i++) {
	Vert *pVOld = ECPts.getEntry(i);
	Vert *pVNew = m_ECVerts.getNewEntry();
	pVNew->setCoords(iDim, pVOld->getCoords());
	pVNew->copyAllFlags(pVOld);
	// Don't copy vertex data any deeper than this.
      }
    }
  ///
  Mesh(const Mesh& M) :
    m_vertsToUpdateLenScale(M.m_vertsToUpdateLenScale), m_ECVerts(),
    m_resolution(M.m_resolution), m_LipschitzAlpha(M.m_LipschitzAlpha), m_qual(NULL),
      m_interiorSkip(M.m_interiorSkip), m_fillBdry(M.m_fillBdry), m_swapRecursively(M.m_swapRecursively),
      m_allowBdryChanges(M.m_allowBdryChanges),
      m_isLengthScaleInitialized(M.m_isLengthScaleInitialized),
      m_isLengthScaleFromCellSizes(M.m_isLengthScaleFromCellSizes),
      m_interpolateLengthScale(M.m_interpolateLengthScale),
      m_simplexMesh(M.m_simplexMesh),
      m_swapMeasure(M.m_swapMeasure), m_encroachType(M.m_encroachType),
      pCellQueue(M.pCellQueue), pAnisoRef(M.pAnisoRef)
    {
      int iDim = M.m_ECVerts.getEntry(0)->getSpaceDimen();
      for (GR_index_t i = 0; i < M.m_ECVerts.lastEntry(); i++) {
	Vert *pVOld = M.m_ECVerts.getEntry(i);
	Vert *pVNew = m_ECVerts.getNewEntry();
	pVNew->setCoords(iDim, pVOld->getCoords());
	pVNew->copyAllFlags(pVOld);
	// Don't copy vertex data any deeper than this.
      }
      m_qual = new Quality(*M.m_qual);
      m_qual->vSetMesh(this);
    }
  ///
  virtual ~Mesh()
    {
      if (m_qual) delete m_qual;
    }
  ///
  virtual void readFromFile(const char strBaseFileName[]) = 0;
/// Inquiry functions
public:

  ////////////////////////////////////////////////////////
  /// Functions that directly query the mesh database. ///
  ////////////////////////////////////////////////////////
  
  // This function returns a pointer to internal data.  This isn't a great idea.
  // TODO: Come up with a better alternative method to replace the three calls
  // to this function.
  const EntContainer<Vert>* pECGetVerts() const {return (&m_ECVerts);}
  ///checks all verts until (if) it finds pV. slow...
  bool hasVert(const Vert* const pV) const;
  ///
  GR_index_t getVertIndex(const Vert* const pV) const
  { return (m_ECVerts.getIndex(pV)); }
  ///
  virtual GR_index_t getFaceIndex(const Face* const pF) const = 0;
  ///
  virtual GR_index_t getBFaceIndex(const BFace* const pBF) const = 0;
  ///
  virtual GR_index_t getCellIndex(const Cell* const pC) const = 0;
#ifdef ITAPS
  ///
  virtual bool isValidEntHandle(void* pvEnt) const = 0;
#endif
  ///
  virtual eMeshType getType() const = 0;
  ///
  /// perimeter length or  area:
  virtual double calcBoundarySize() const {assert(0); return 0;}
  /// interior   area  or volume:
  virtual double calcInteriorSize() const  {assert(0); return 0;}
  virtual bool isWatertight() const  {assert(0); return 0;}
  /// 
  /// Validity checking
  virtual bool isValid() const = 0;
  ///
  int calcNumFacesNonDelaunay() const;

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////
  /// Create a vertex at the given location.
  virtual Vert* createVert(const double dX, const double dY,
			   const double dZ) = 0;
  virtual Vert* createVert(const double adCoords[]) = 0;
/*   virtual Face* createFace(Vert * const apV[], const int iNVerts) = 0; */
  virtual BFace* createBFace(Face * const pF,
			     BFace * const pBF = pBFInvalidBFace) = 0;
/*   virtual Cell* createCell(Face * const apF[], const int iNFaces, */
/* 			   const int iReg = iDefaultRegion) = 0; */
/*   virtual Cell* createCell(Vert * const apV[], const int iNVerts, */
/* 			   const int iReg = iDefaultRegion) = 0; */
  virtual Cell* createCell(Vert* const vert, Face* const face,
                             const int iReg = iDefaultRegion) = 0;
  virtual bool deleteVert(Vert * const pV) = 0;
  virtual bool deleteFace(Face * const pF) = 0;
  virtual bool deleteBFace(BFace * const pBF) = 0;
  virtual bool deleteCell(Cell * const pC) = 0;
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  
  /// The following routine adds bdry faces where needed after ITAPS
  /// modification.  Doesn't put BFaces on the right patches, though...
  void checkForITAPSBdryErrors();
  ///
  virtual void purgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL) = 0;
  ///
  virtual void purgeFaces(std::map<Face*, Face*>* face_map = NULL) = 0;
  ///
  virtual void purgeCells(std::map<Cell*, Cell*>* cell_map = NULL) = 0;
  ///
  virtual void purgeVerts(std::map<Vert*, Vert*>* vert_map = NULL) = 0;
  ///
  virtual void purgeAllEntities(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL,
		      std::map<BFace*, BFace*>* bface_map = NULL) = 0;

  ///
  void reorderAllEntities(void) {
    reorderVerts_RCM();
    reorderCells();
    reorderFaces();

    //Modified by SG July 2007:
    //The following seems to be used to keep consistent face normal orientation.
    //However, the most recent iteration of the 2D tri meshing code with curved boundaries 
    //needs to go through BdryEdge and IntBdryEdge objects to obtain normals. To achieve this,
    //the faces must be oriented in the SAME direction as their underlying curve. 
    //Interchanging the vertices will in obviously change the face orientation and
    //therefore, the normal direction will become inconsistent. Hence, the skipping of this
    //piece of code for 2D triangular meshes.

    if(getType() == Mesh::eMesh2D) return;

    for (GR_index_t iF = 0; iF < getNumFaces(); iF++) {
      Face *pF = getFace(iF);
      if (pF->isBdryFace() && pF->getLeftCell()->isBdryCell()) {
	pF->interchangeCellsAndVerts();
      }
    }

  }
 protected:
  virtual void reorderVerts_RCM(void) = 0;
  virtual void reorderCells(void) = 0;
  virtual void reorderFaces(void) = 0;
 public:
  ///

  void setAllHintFaces();
  void clearAllHintFaces();

  virtual void setVertFaceNeighbors();
  void clearVertFaceNeighbors();

  ////////////////////////////////////////////////////////
  /// Functions that affect the behavior of algorithms ///
  ////////////////////////////////////////////////////////

  ///
  eSwap getSwapType() const {return m_swapMeasure;}
  ///
  void setSwapType(const eSwap eSwapIn) {m_swapMeasure = eSwapIn;}
  ///
  bool areBdryChangesAllowed() const {return m_allowBdryChanges;}
  ///
  void allowBdryChanges() {m_allowBdryChanges = true;}
  ///
  void disallowBdryChanges() {m_allowBdryChanges = false;}
  ///
  bool isSwapRecursionAllowed() const {return m_swapRecursively;}
  ///
  void allowSwapRecursion() {m_swapRecursively = true;}
  ///
  void disallowSwapRecursion() {m_swapRecursively = false;}
  ///
  void initLengthScale(const double dRes = 1, const double dGrade = 1);
  void setInterpolatedLengthScale() {m_interpolateLengthScale = true;}
  void recomputeLengthScale();
  void updateLengthScale(Vert * const pV = pVInvalidVert);
  /// FIX ME:  The following interface is a kludge so that 2D meshing
  //  can easily use the new length scale stuff.  This should go away
  //  once 2D is also using the new insertion code.
  void updateLengthScale(std::set<Vert*>& spV);
  void setLengthScale(Vert * const pV);
  void setLengthScale(const double dLen);
  void markForLengthScaleCheck(Vert * const pV) {
    m_vertsToUpdateLenScale.insert(pV);
  }
  void updateInfluence();
  void checkEdgeLengths() const;
  /// Return the number of vertices in the database; some may be deleted.
  GR_index_t getNumVerts() const {return m_ECVerts.lastEntry();}

  GR_index_t getNumVertsInUse() const {return m_ECVerts.size();}
  virtual GR_index_t getNumEdgesInUse() const = 0;
  virtual GR_index_t getNumTrisInUse() const = 0;
  virtual GR_index_t getNumQuadsInUse() const = 0;
  virtual GR_index_t getNumTetsInUse() const = 0;
  virtual GR_index_t getNumPyrsInUse() const = 0;
  virtual GR_index_t getNumPrismsInUse() const = 0;
  virtual GR_index_t getNumHexesInUse() const = 0;

  /// Return the number of faces in the database; some may be deleted.
  virtual GR_index_t getNumFaces() const = 0;
  ///
  virtual GR_index_t getNumBdryFaces() const = 0;
  ///
  virtual GR_index_t getNumIntBdryFaces() const = 0;
  ///
  GR_index_t getNumTotalBdryFaces() const {return getNumBdryFaces() + getNumIntBdryFaces();}

  /// Return the number of cells in the database; some may be deleted.
  virtual GR_index_t getNumCells() const = 0;

  /// Return a cell by index.
  virtual Cell* getCell(const GR_index_t i) const = 0;

  /// Return a vertex by index.
  Vert* getVert(const GR_index_t i) const {return m_ECVerts.getEntry(i);}

  /// Return a face by index.
  virtual Face* getFace(const GR_index_t i) const = 0;

  /// Return the handle of an unused vertex in the database.
  Vert* getNewVert()
    {
      Vert *pV = m_ECVerts.getNewEntry();
      pV->setDefaultFlags();
      pV->clearFaceConnectivity();
      return (pV);
    }
  ///
  virtual BFace* getBFace(const GR_index_t i) const = 0;
  /// Conversion to/from simplicial form
  bool isSimplicial() const {return m_simplexMesh;}
  ///
  virtual void makeSimplicial() {assert(0);}
  ///
  void allowNonSimplicial() {m_simplexMesh = false;}
  ///
  void setQualityMeasure(const int iQual) {
    delete m_qual;
    m_qual = new Quality(this, iQual);
  }
  void evaluateQuality() const {m_qual->vEvaluate();}
  double evaluateQuality(const CellSkel* const pCS) const
    {return m_qual->dEvaluate(pCS);}
  void writeQualityToFile(const char strQualFileName[]) const
    {m_qual->vWriteToFile(strQualFileName);}
  
  // The next three functions are used only for Doug's aniso insertion.
  void attachCellQueue(CellQueue* pCellQueueIn){pCellQueue=pCellQueueIn;}
  void removeCellQueue(){pCellQueue=NULL;}

  void attachAnisoRef(AnisoRefinement* pAnisoRefIn){pAnisoRef=pAnisoRefIn;}

/*   void vAttachFaceSet(std::set<Face*>* psetPFacesIn){assert(psetPFaces==NULL);psetPFaces=psetPFacesIn;} */
/*   void vRemoveFaceSet(){psetPFaces=NULL;} */

public:
  virtual int insertPointWatson_deprecated(WatsonInfo_deprecated&) = 0;
  // Generic Watson hull cleanup, probably only needs to be implemented in 3D.
  virtual void cleanupWatson_deprecated(WatsonInfo_deprecated&) {}
  virtual void getWatsonData_deprecated(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const = 0;
  // Use this next function to clear out all points lying within a given
  // ball when doing insertion on / near boundaries.  Returns true iff
  // the ball has no interior points left.
  virtual bool deleteInteriorPointsInBall(const Cell *pCSeed,
					   const double adLoc[],
					   const double dRadius,
					   int& iNDeleted) = 0;
  int queueEncroachedBdryEntities(InsertionQueue&) const;
  virtual int queueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&) const = 0;
  virtual int queueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF,
					   const double adLoc[],
					   const double dOffset = 0) const = 0;
  ///
  void setEncroachmentType(const eEncroachType eET) { m_encroachType = eET; }
  eEncroachType getEncroachmentType() const {return m_encroachType;}

  // The worst shape quality measure (shortest edge to circumradius) allowed.
  virtual double getWorstAllowedCellShape() const = 0;

  // Mesh coarsening routines
private:
  int markChain(Vert * const pVSurf, Vert * const pVFirst,
		 const VertConnect aVC[],
		 const double dMaxDist, const int iSkipNum);
  void deactivateChain(Vert * const pVSurf, Vert * const pVFirst,
			const VertConnect aVC[], const double dMaxDist) const;
  void addNormalVerts(const VertConnect aVC[],
		       const Vert::VertType VTVertTypeToStartFrom);
  void addToCoarseVerts(const VertConnect aVC[]) const;
  void selectCoarseVerts(VertConnect aVC[]);
  void deactivateAll() const;
  int activate(const Vert::VertType VT) const;
  int getInteriorSkip() const {return m_interiorSkip;}
  bool fillBoundary() const {return m_fillBdry;}
  virtual Cell* beginPipe(const Vert* const pVLast,
			    const Vert* const pVNew) const = 0;
public:
  void setInteriorSkip(const int iNewSkip)
    {
      assert(iNewSkip > 0);
      m_interiorSkip = iNewSkip;
    }
  void setBoundaryFill(const bool qNewFill) {m_fillBdry = qNewFill;}
  virtual double getCoarseningConstant() const = 0;
  void coarsen(const double dLengthRatio = 2);
  void coarsenToLengthScale(const bool qHeal = false);
  virtual void identifyVertexTypesGeometrically() const = 0;
  void initConflictGraph(VertConnect aVC[]) const;
  void updateConflictGraph(VertConnect aVC[]) const;
  void removeTaggedVerts();
  virtual GR_index_t getNumBdryPatches() = 0;
  virtual void buildBdryPatches() {}
  virtual bool removeVertByContraction(Vert * const pV, int& iNewSwaps,
					Vert * apVPreferred[] = NULL,
					const int iNPref = 0) = 0;
  virtual bool removeVert(Vert * const pV, int& iNewSwaps) = 0;

  // This call is deprecated; don't use it in new code.  It's still used
  // in a couple of places, but those are slated for change: coarsening,
  // aniso refinement in 2D, and the STL mesher.
  virtual int iSwap_deprecated(const int iMaxPasses = 2,
			       const bool qAlreadyMarked = false) = 0;

// Mesh adaptation and related routines
  virtual bool makeDelaunay() = 0;
  virtual void adaptToLengthScale(const eEncroachType eET);
  // Iterator functions
  EntContainer<Vert>::iterator vert_begin() const
  { return m_ECVerts.begin(); }
  EntContainer<Vert>::iterator vert_end() const
  { return m_ECVerts.end(); }
};

/// Return info about entities in the one-cell ball around the vertex.
void findNeighborhoodInfo(const Vert* const pVert,
		   std::set<Cell*>& spCInc,
		   std::set<Vert*>& spVNeigh,
		   std::set<BFace*>* pspBFInc = NULL,
		   bool *pqBdryVert = NULL,
		   std::set<Face*>* pspFNearby = NULL);

#endif // Done with class Mesh
