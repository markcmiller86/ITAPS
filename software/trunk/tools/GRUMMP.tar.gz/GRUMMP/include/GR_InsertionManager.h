/*
 * GR_InsertionManager.h
 *
 *  Created on: May 16, 2012
 *      Author: cfog
 */

#ifndef GR_INSERTION_MANAGER_H_
#define GR_INSERTION_MANAGER_H_

// There are three levels of abstraction for insertion, because there are (at
// least) three important activities:
//
// 1.  At a high level, there's a driver that makes decisions about why and 
//     where to add points to the mesh. (Generic name: Refiners; these are
//     the ones that are Observers of Mesh objects.)
// 2.  At a low level, there's code that does the actual insertion (valid mesh
//     to valid mesh).  (Generic name: Inserters)
// 3.  Finally, at the middle level, there's a need to be able to insert a point
//     with some additional guarantees on the properties of the mesh other than 
//     just validity (that the mesh is always Delaunay, for instance).
//     (Generic name: InsertionManagers)
// An inserter needs to be able to do several things:
//
// insertPoint   This is the obvious, general purpose call.
//
// After some internal dispatch, as well as for special purposes, specific
// calls are helpful:
//
// insertPointInCell
// insertPointOnFace
// insertPointOnEdge
// insertPointOnBdryFace
// insertPointOnBdryEdge
//
// In 2D, the face and edge calls will be the same; if possible, make the edge 
// calls private.  For Watson, it may be possible to make all the interior calls
// the same and the two bdry calls the same.
//
// Each also needs some internal state data:  the mesh it's operating on and a 
// (typically Delaunay) SwapManager, at a minimum.

#include "GR_SwapManager.h"

namespace GRUMMP {
  class Inserter {
  protected:
    Mesh* m_pMesh;
    GR_index_t m_nInCell, m_nOnTri, m_nOnEdge, m_nOnBdryTri, m_nOnBdryEdge,
        m_nOnIntBdryTri, m_nOnIntBdryEdge;
    BdryEdgeBase::SplitType m_splitType;
    bool m_force;
  private:
    /// Default construction is a really, really bad idea.
    Inserter();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    Inserter(Inserter&);
    /// Operator= isn't obviously helpful, either.
    Inserter& operator=(Inserter&);
    //
  public:
    /// Constructor; the mesh must be supplied at construction time.
    Inserter(Mesh* pMesh) :
        m_pMesh(pMesh), m_nInCell(0), m_nOnTri(0), m_nOnEdge(0), m_nOnBdryTri(
            0), m_nOnBdryEdge(0), m_nOnIntBdryTri(0), m_nOnIntBdryEdge(0), m_splitType(
            BdryEdgeBase::MID_TVT), m_force(false)
    {
    }
    virtual ~Inserter()
    {
    }

    /// True iff points are required to be inserted at precisely the specified
    /// location.
    bool forceInsertion() const
    {
      return m_force;
    }

    /// Set whether to force insertion at the specified point; returns the old
    /// value of this parameter, in case you need to restore the value later.
    bool setForcedInsertion(const bool newForce)
    {
      bool retVal = m_force;
      m_force = newForce;
      return retVal;
    }

    virtual Vert* insertPoint(const double newPtLoc[], Cell* const cellGuess,
                              Vert* const existingVert = NULL) = 0;

    virtual Vert*
    insertPointInCell(const double newPtLoc[], Cell* const cell,
                      Vert* const existingVert = NULL) = 0;
    virtual Vert*
    insertPointOnFace(const double newPtLoc[], Face* const face,
                      Vert* const existingVert = NULL) = 0;
    /*     virtual bool insertPointOnEdge(const double newPtLoc[], Face* const face, */
    /*                                    Vert* const vert0, Vert* const vert1) = 0; */

    /*     virtual bool insertPointOnBdry(const double newPtLoc[], */
    /*                                    Face*  const faceGuess) = 0; */
    virtual Vert* insertPointOnBdryFace(const double newPtLoc[],
                                        Face* const face,
                                        Vert* const existingVert = NULL)
    {
      return insertPointOnFace(newPtLoc, face, existingVert);
    }
    virtual Vert* insertPointOnInternalBdryFace(const double newPtLoc[],
                                                Face* const face,
                                                Vert* const existingVert = NULL)
    {
      return insertPointOnFace(newPtLoc, face, existingVert);
    }
    /*     virtual bool insertPointOnBdryEdge(const double newPtLoc[], */
    /* 				       Face* const face, Vert* const vert0, */
    /* 				       Vert* const vert1) = 0; */
  };

  class SwappingInserter2D: public Inserter {
    SwapManager2D* m_swapper;
    GR_index_t m_swapsDone;
  private:
    /// Default construction is a really, really bad idea.
    SwappingInserter2D();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SwappingInserter2D(SwappingInserter2D&);
    /// Operator= isn't obviously helpful, either.
    SwappingInserter2D& operator=(SwappingInserter2D&);
    //
  public:
    /// Constructor; the mesh must be supplied at construction time.
    SwappingInserter2D(Mesh2D* mesh, SwapManager2D* swapper) :
        Inserter(mesh), m_swapper(swapper), m_swapsDone(0)
    {
    }
    virtual ~SwappingInserter2D()
    {
    }

    virtual Vert* insertPoint(const double newPtLoc[], Cell* const cellGuess,
                              Vert* const existingVert = NULL);

    /*     virtual bool insertPointInInterior(const double newPtLoc[], */
    /*                                        Cell* const cellGuess); */
    virtual Vert* insertPointInCell(const double newPtLoc[], Cell* const cell,
                                    Vert* const existingVert = NULL);
    virtual Vert* insertPointOnFace(const double newPtLoc[], Face* const face,
                                    Vert* const existingVert = NULL);
    /*     virtual bool insertPointOnEdge(const double newPtLoc[], Face* const face, */
    /*                                    Vert* const vert0, Vert* const vert1); */

    /*     virtual bool insertPointOnBdry(const double newPtLoc[], */
    /*                                    Face* const faceGuess); */
    virtual Vert* insertPointOnBdryFace(const double newPtLoc[],
                                        Face* const face,
                                        Vert* const existingVert = NULL);
    virtual Vert* insertPointOnInternalBdryFace(
        const double newPtLoc[], Face* const face, Vert* const existingVert =
            NULL);
    /*     virtual bool insertPointOnBdryEdge(const double newPtLoc[], */
    /*                                        Face* const face, Vert* const vert0, */
    /*                                        Vert* const vert1); */
    /// Insert a new vertex at the location of newPtLoc, which is known
    /// to be near hintVert.
    Vert* insertPointNearVert(const double newPtLoc[],
                              const Vert* const hintVert);

    GR_index_t getNumSwapsDone() const
    {
      return m_swapsDone;
    }
    GR_index_t getNumInCell() const
    {
      return m_nInCell;
    }
    GR_index_t getNumOnEdge() const
    {
      return m_nOnEdge;
    }
    GR_index_t getNumOnBdryEdge() const
    {
      return m_nOnBdryEdge;
    }
    GR_index_t getNumOnIntBdryEdge() const
    {
      return m_nOnIntBdryEdge;
    }

  private:
    Cell* findCell(const double newPtLoc[], Cell* const cellGuess,
                   int &numViolated, Face *facesViolated[3], int &numTies,
                   Face *facesTied[3]);
  };

  class SwappingInserter3D: public Inserter {
    SwapManager3D* m_swapper;
    GR_index_t m_swapsDone;
  private:
    /// Default construction is a really, really bad idea.
    SwappingInserter3D();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SwappingInserter3D(SwappingInserter3D&);
    /// Operator= isn't obviously helpful, either.
    SwappingInserter3D& operator=(SwappingInserter3D&);
    //
  public:
    /// Constructor; the mesh must be supplied at construction time.
    SwappingInserter3D(VolMesh* mesh, SwapManager3D* swapper) :
        Inserter(mesh), m_swapper(swapper), m_swapsDone(0)
    {
    }
    virtual ~SwappingInserter3D()
    {
    }

    SwapManager3D* changeSwapManager(SwapManager3D* newSwapper) {
      SwapManager3D* retVal = m_swapper;
      m_swapper = newSwapper;
      return retVal;
    }
    virtual Vert* insertPoint(const double newPtLoc[], Cell* const cellGuess,
                              Vert* const existingVert = NULL);

    /*     virtual bool insertPointInInterior(const double newPtLoc[], */
    /*                                        Cell* const cellGuess); */
    virtual Vert* insertPointInCell(const double newPtLoc[], Cell* const cell,
                                    Vert* const existingVert = NULL);
    virtual Vert* insertPointOnFace(const double newPtLoc[], Face* const face,
                                    Vert* const existingVert = NULL);
    virtual Vert* insertPointOnEdge(const double newPtLoc[], Vert* const vert0,
                                    Vert* const vert1,
                                    Vert* const existingVert = NULL);

    /*     virtual bool insertPointOnBdry(const double newPtLoc[], */
    /*                                    Face* const faceGuess); */
//    virtual bool insertPointOnBdryFace(const double newPtLoc[],
//                                       Face* const face);
//    virtual bool insertPointOnInternalBdryFace(const double newPtLoc[],
//                                               Face* const face);
//    virtual bool insertPointOnBdryEdge(const double newPtLoc[],
//                                       Face* const face, Vert* const vert0,
//                                       Vert* const vert1);
    GR_index_t getNumSwapsDone() const
    {
      return m_swapsDone;
    }
    GR_index_t getNumInCell() const
    {
      return m_nInCell;
    }
    GR_index_t getNumOnEdge() const
    {
      return m_nOnEdge;
    }
    GR_index_t getNumOnBdryEdge() const
    {
      return m_nOnBdryEdge;
    }
    GR_index_t getNumOnIntBdryEdge() const
    {
      return m_nOnIntBdryEdge;
    }
    GR_index_t getNumOnFace() const
    {
      return m_nOnTri;
    }
    GR_index_t getNumOnBdryFace() const
    {
      return m_nOnBdryTri;
    }
    GR_index_t getNumOnIntBdryFace() const
    {
      return m_nOnIntBdryTri;
    }

  private:
    Cell* findCell(const double newPtLoc[], Cell* const cellGuess,
                   bool& status);
  };

  /// This class stores all the data needed for inserting a point into a known
  /// cavity in the mesh.
  ///
  /// Cavity insertion removes all cells within the cavity, then "spraypaints"
  /// the hull faces of that cavity with new cells, all connected to a given
  /// vertex.
  ///
  /// In the interior, this is *very* easy.
  ///
  /// On boundaries, it's harder, because of the bdry face split.  Some old bdry
  /// faces are removed and replaced with others.  This is essentially the same
  /// process at one dimension lower, but that's not as well / generically
  /// supported by GRUMMP data structures.
  ///
  /// This functionality has obvious usage in Watson insertion, but it's also
  /// useful when removing a vertex from the mesh by edge collapse, which
  /// is why this functionality and the Watson cavity formation are segregated
  /// into separate classes.
  ///
  /// The CavityInserter also keeps track of faces that should be removed,
  /// but these are auto-deleted when cells are deleted.
  ///
  /// Responsibility for the semantics of Ruppert / Shewchuk insertion are
  /// divided into several phases.
  ///
  /// First, WatsonInfo computes the insertion hull for a candidate point.
  ///
  /// Second, the Watson insertion driver handles bdry encroachment, and
  /// may decide to abort an interior or bdry face insertion in favor of
  /// bdry face  or bdry segment insertion.  For some bdry
  /// protection schemes, bdry insertion may require removal of some
  /// interior vertices, which happens at this stage as well.  Also, especially
  /// for multicore implementation, some filtering of points that are too
  /// close together may happen at this stage.
  ///
  /// Finally, the WatsonInfo objects for points that are actually being
  /// inserted are passed to a HullInserter for action.
  class CavityInserter {
  protected:
    typedef std::set<Cell*> cellContainer_t;
    typedef std::set<Face*> faceContainer_t;
    typedef std::set<BFace*> bfaceContainer_t;

    typedef cellContainer_t::iterator cellIter_t;
    typedef faceContainer_t::iterator faceIter_t;
    typedef bfaceContainer_t::iterator bfaceIter_t;

    /// Cells in the hull that will be deleted on insertion.
    cellContainer_t m_cellsToRemove;

    /// Bdry faces on the part of the bdry being remeshed
    bfaceContainer_t m_bfacesToRemove;

    /// Faces on the insertion hull will have new cells attached to them.
    faceContainer_t m_facesOnHull;

    /// Faces inside the hull are deleted on insertion.
    faceContainer_t m_hullInteriorFaces;

    /// The mesh into which points will be inserted.
    Mesh* m_mesh;

    /// Need to know which region the new cell associated with a face
    /// should be in.
    std::vector<std::pair<Face*, int> > m_hullFaceData;
  public:
    CavityInserter(Mesh* const mesh);
    virtual ~CavityInserter()
    {
    }

    void clear()
    {
      m_cellsToRemove.clear();
      m_bfacesToRemove.clear();
      m_facesOnHull.clear();
      m_hullInteriorFaces.clear();
    }

    Mesh* getMesh() {return m_mesh;}

  private:
    /// Record info about the regions of cells incident onto hull faces, which
    /// is going to be needed when it's time to reconnect the mesh later.
    ///
    /// Data is stored in a vector of Face*-int pairs: the int tells what
    /// region the new cell incident on the Face will be in.
    ///
    /// Pre-condition: The collection of hull faces must be up to date.
    /// Post-condition: The regions for all new cells will be recorded.
    void recordRegions();

    /// Delete all entities inside the hull.
    ///
    /// Cells are deleted directly.  Faces are auto-deleted if/when they no
    /// longer have any incident cells.  (This is handled automatically by the
    /// mesh database.)
    ///
    /// Pre-condition:  The collection of cells in the cavity is complete.
    /// Post-condition:  Cavity is empty, with no entities inside the given
    /// hull.
    void deleteHullInterior() const;

    /// Reconnect all the faces in the hull to a given vertex.
    ///
    /// For every face in the hull that doesn't contain vert, a new cell is
    /// created connecting them.  Other entities inside the cavity are
    /// auto-created.
    ///
    /// Pre-condition: The cavity must be empty, and all its faces must be
    /// visible from vert and non-degenerate.
    /// Post-condition: The cavity is filled with fully-connected cells with
    /// positive volumes.  All faces of these cells are also properly connected.
    void connectHullToVert(Vert* const vert) const;

  protected:
    /// Remesh parts of the bdry that must be changed during bdry insertion.
    /// This is virtual because it's done differently for topologically 2D and
    /// 3D meshes.
    virtual void updateMeshBdry(Vert* const newVert) const = 0;
  public:
    /// Retriangulate/retetrahedralize a cavity with all faces connected to a
    /// new vertex created at the given location.  This form is especially
    /// useful as the execution phase of Watson vertex insertion.  The hull
    /// must be initialized in advance.
    ///
    /// This routine creates a vertex, then calls the vertex version of this
    /// overloaded function.
    ///
    /// Arguments:
    ///   candPtLoc[in]   The location of the new vert to which all faces on
    ///                     the hull of the cavity will be connected.
    ///   vertType[in]    Tells what flavor of vert this is (interior, bdry,
    ///                     bdry curve, etc).
    ///
    /// Pre-condition:  candPtLoc must be in or on the cavity and all faces of the
    ///   hull must be visible from it, except faces on the bdry that will be
    ///   deleted and replaced.
    /// Post-condition: The cavity is filled with fully-connected cells with
    /// positive volumes.  All faces of these cells are also properly connected.
    Vert* insertPointInHull(const double candPtLoc[],
                            const Vert::VertType vertType);

    /// Retriangulate/retetrahedralize a cavity with all (non-incident) faces
    /// connected to a particular vert.  This form is especially useful for
    /// vertex removal.
    ///
    /// Arguments:
    ///   targetVert[in]  The vertex to which faces of the hull will be
    ///      connected.
    ///
    /// Pre-condition / post-condition: same as point version of this overloaded
    ///   function.
    Vert* insertPointInHull(Vert* targetVert);

    /// Add a cell to the cavity.  In the process, maintain the collections of
    /// interior and hull skin faces.
    ///
    /// If a face of the cell is currently listed as on the skin (because the
    /// opposite cell is in the cavity, this call will remove it from the skin
    /// and add it to the interior.  Otherwise, the face is added to the skin.
    ///
    /// Arguments:
    ///   cellToAdd[in]  The cell to be added to the cavity.
    ///
    /// Pre-condition: None.
    /// Post-condition:  cellToAdd has been added to the list of cells inside
    ///   the cavity, and the hull and interior face lists are up to date.
    void addCellToCavity(Cell* cellToAdd);

    /// Add a bdry face to the hull of the cavity; these bfaces are going to be
    /// deleted and replaced.
    ///
    /// Arguments:
    ///   bfaceToAdd[in]  The BFace to be added to the cavity.
    ///
    /// Pre-condition: None.
    /// Post-condition:  bfaceToAdd has been added to the list of BFaces on
    /// the hull of the cavity that must be replaced.  No changes to hull and
    /// interior face lists.
    void addBFaceToCavity(BFace* bfaceToAdd);
  };

  class CavityInserter2D: public CavityInserter {
  protected:
    /// Remesh parts of the bdry that must be changed during bdry insertion. (2D version)
    ///
    /// In 2D, only one bdry face can be the one on which the vertex is
    /// being inserted.  Two new bdry faces are created: one connected
    /// to each end point of that edge.  This works for multi-region interior
    /// bdry cases as well.
    ///
    /// Pre-condition: Exactly one bdry face to replace.  The interior of the
    ///   cavity has already been properly re-connected.
    /// Post-condition: Old bface has been deleted, two new bfaces take its
    ///   place.
    virtual void updateMeshBdry(Vert* const newVert) const;
  public:
    CavityInserter2D(Mesh* const mesh) :
        CavityInserter(mesh)
    {
    }
  };

  class CavityInserter3D: public CavityInserter {
  protected:
    /// Remesh parts of the bdry that must be changed during bdry insertion. (2D version)
    /// This is virtual because it's done differently for topologically 2D and
    /// 3D meshes.
    ///
    /// In 3D, we can replace an arbitrary number of bdry faces N.  Typically
    /// these will be coplanar and on a single bdry patch.  However, insertion
    /// on a bdry curve (that is, adding a point on an edge that separates two
    /// parts of the surface) is supported, too, as is the case of curved bdrys.
    /// Curved bdrys are a geometric flourish on what is, here, a strictly
    /// topological process.  The N old bfaces are replaced by N+2 new ones.
    /// New bdry tris will fall on the same piece of the geometric bdry as the
    /// existing edge they are connected to.  Old bfaces are deleted.
    /// This works for multi-region interior bdry cases as well.
    ///
    /// Pre-condition: N bdry face to replace.  The interior of the
    ///   cavity has already been properly re-connected.
    /// Post-condition: Old bfaces have been deleted, new bfaces take their
    ///   place.
    virtual void updateMeshBdry(Vert* const newVert) const;
  public:
    CavityInserter3D(Mesh* const mesh) :
        CavityInserter(mesh)
    {
    }
  };

  /// This class stores all the data needed for Watson insertion of a point.
  ///
  /// Watson insertion uses the CavityInserter for actual mesh modification.
  ///
  /// When a point is inserted near or on the mesh boundary, the point may fall
  /// inside the protection zone for a face on the boundary ("encroach" on that
  /// bdry face).  In this case, the boundary faces must be split before the
  /// interior point can be inserted; for bdry points that encroach bdry faces
  /// that aren't being replaced, those encroached bdry faces should be split as
  /// well, but this should happen after inserting the current point, to avoid
  /// infinite loops.
  ///
  /// WatsonInfo also keeps track of faces that should be removed, but these are
  /// auto-deleted when cells are deleted.
  ///
  /// Responsibility for the semantics of Ruppert / Shewchuk insertion are
  /// divided into several phases.
  ///
  /// First, WatsonInfo computes the insertion hull for a candidate point.
  ///
  /// Second, the Watson insertion driver handles bdry encroachment, and
  /// may decide to abort an interior or bdry face insertion in favor of
  /// bdry face (interior only) or bdry segment insertion.  For some bdry
  /// protection schemes, bdry insertion may require removal of some
  /// interior vertices, which happens at this stage as well.  Also, especially
  /// for multicore implementation, some filtering of points that are too
  /// close together may happen at this stage.
  ///
  /// Finally, the CavityInserter is called to do the actual insertion.
  class WatsonInfo {
    /// The bulk of information about mesh entities to be modified is stored in
    /// in the CavityInserter.
    CavityInserter *m_CI;

    /// All bdry faces for which the new point lies in their protection zone.
    std::set<BFace*> m_bfacesEncroached;

    /// The location of the current candidate point for insertion.
    double m_candPtLoc[3];

    /// The type of vertex (interior, bdry, bdry curve, etc)
    Vert::VertType m_vertType;

    /// Retrieve the mesh pointer, which is stored by the cavity inserter.
    Mesh* getMesh() const {return m_CI->getMesh();}
  public:
    /// This constructor deliberately contains no info about the point to
    /// insert.  Instead, a new point can be specifiedvia a separate member
    /// function and the object re-used for multiple insertions.
    WatsonInfo(Mesh* mesh) :
        m_CI(NULL), m_bfacesEncroached(), m_vertType(Vert::eUnknown)
    {
      if (mesh->getType() == Mesh::eVolMesh) {
        m_CI = new CavityInserter3D(mesh);
      }
      else {
        m_CI = new CavityInserter2D(mesh);
      }
      m_candPtLoc[0] = m_candPtLoc[1] = m_candPtLoc[2];
    }

    virtual ~WatsonInfo()
    {
      delete m_CI;
    }

    /// Computes the hull, but doesn't do anything with that information yet.
    virtual void computeHull(const double candPt[], Cell* const seedCell,
                             const bool testForBdryEncroachment = true);

    /// Inserts the point into its hull.  This call assumes that any
    /// encroachment fixes or hull repair is done elsewhere.  The point
    /// is specified through a previous call to computeHull.
    Vert* insertPointInHull();

    /// Gathers all the necessary information about a potential insertion hull.
    ///
    /// Starting from a seed cell, which must contain the vertex in its circum-
    /// ball, find all cells that contain the vertex in their circumballs.
    void computeHull(const double adPoint[], Cell* const seedCell,
                     const bool testForBdryEncroachment,
                     const eEncroachType encroachType);
  private:
    /// Find a cell that circumscribes a given location by checking all
    /// cells in the mesh until it finds one.
    SimplexCell* findSeedNaively(const double newLoc[]) const;

    /// Find a cell that circumscribes a given location.
    ///
    /// First, checks the cells in the given set.  If none of them
    /// circumscribes the location, then call findSeedNaively to check
    /// every cell in the mesh.
    SimplexCell* findSeedFromGuesses(
        const double newLoc[],
        const std::set<SimplexCell*>* const guesses) const;
  };

} // End namespace

#endif /* GR_INSERTIONMANAGER_H_ */
