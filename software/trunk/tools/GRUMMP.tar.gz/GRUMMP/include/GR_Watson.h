#ifndef GR_Watson
#define GR_Watson 1

#include "GR_config.h"
#include "GR_Sort.h"

class EdgeToBFace {
private:
  Vert *pV0, *pV1;
  BFace* pBF;
public:
  EdgeToBFace() : pV0(pVInvalidVert), pV1(pVInvalidVert), pBF(NULL) {}
  EdgeToBFace(const EdgeToBFace& EBF) : pV0(EBF.pV0), pV1(EBF.pV1),
    pBF(EBF.pBF) {}
  EdgeToBFace(Vert * const pV0In, Vert * const pV1In,
	      BFace * const pBFIn = NULL) :
    pV0(pV0In), pV1(pV1In), pBF(pBFIn)
    {
      assert(pV0In->isValid() && pV1In->isValid());
      if (pV0 > pV1) {
	Vert *pVTmp = pV1;
	pV1 = pV0;
	pV0 = pVTmp;
      }
    }
  EdgeToBFace& operator=(const EdgeToBFace& EBF)
    {
      if (this != &EBF) {
	pV0 = EBF.pV0;
	pV1 = EBF.pV1;
	pBF = EBF.pBF;
      }
      return (*this);
    }
  Vert *pVVert(const int i) const
    {
      assert(i == 0 || i == 1);
      return (i == 0) ? pV0 : pV1;
    }
  //  BdryPatch* pPatchPointer() const {return pBF;}
  BFace *pBFace() const {return pBF;}
  bool operator!=(const EdgeToBFace& EBF) const
    { return !(*this == EBF); }
  bool operator==(const EdgeToBFace& EBF) const
    {
      return ((pV0 == EBF.pV0 && pV1 == EBF.pV1) ||
	      (pV0 == EBF.pV1 && pV1 == EBF.pV0));
    }
  bool operator<(const EdgeToBFace& EBF) const
    {
      return ((pV0 < EBF.pV0) || (pV0 == EBF.pV0 && pV1 < EBF.pV1));
    }
};

void vCheckBdryFragmentForSubsegEncroachment
(const std::set<BFace*>& spBF, std::set<FaceSort>& sESEncSubseg,
 const double * const adPoint = NULL);

#endif
