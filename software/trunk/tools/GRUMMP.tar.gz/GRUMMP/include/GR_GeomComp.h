#ifndef GR_GEOMCOMP_H
#define GR_GEOMCOMP_H

#include "GR_config.h"

//Find the closest point on a 3D triangle from a 3D point.
void closest_on_triangle( const double pt[3], 
			  const double t0[3], const double t1[3], const double t2[3], 
			  double close[3] );

#endif
