#ifndef GR_Geometry
#define GR_Geometry 1

#include "GR_config.h"
#include "GR_Vec.h"
#include "GR_Vertex.h"

/// Distance between two points
inline double dDist(const Vert * const pV0, const Vert * const pV1)
{
  assert(pV1->getSpaceDimen() == pV0->getSpaceDimen());
  if (pV0->getSpaceDimen() == 2) {
    return dDIST2D(pV0->getCoords(), pV1->getCoords());
  }
  else {
    return dDIST3D(pV0->getCoords(), pV1->getCoords());
  }
}    

/// Normal of an edge in 2D
void vNormal(const double adA[2], const double adB[2], double adResult[2]);
/// Normal of a triangle in 2D
void vNormal2D(const double adA[2], const double adB[2],
	       const double adC[2], double * const adResult);
/// Normal of a triangle in 3D
void vNormal3D(const double adA[3], const double adB[3],
	       const double adC[3], double * const adResult);
///
int iOrient3D(const Face* const pF, const double ad[3]);
///
int iOrient3D(const Face* const pF, const Vert* const pV);
///
int iOrient3D(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC, const Vert* const pVD);
///
int iOrient3D(const double adA[3], const double adB[3],
	      const double adC[3], const double adD[3]); 
///
int iInsphere(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC, const Vert* const pVD,
	      const Vert* const pVE);
///
int iInsphere(const double adA[3], const double adB[3],
	      const double adC[3], const double adD[3],
	      const double adE[3]);
/// Is testPt inside the tet formed by ptA-ptD (right-handed order).
int iIsInTet(const double testPt[3], const double ptA[3], const double ptB[3],
             const double ptC[3], const double ptD[3]);

/// Is testPt inside the tet?
int iIsInTet(const double testPt[3], const Cell* const cell);

/// Is the vert inside this tet?
int iIsInTet(const Vert* const pV, const Cell* const cell);
//
int iCoplanarInTet(const Vert* const pV,     const Vert* const pVertA,
		   const Vert* const pVertB, const Vert* const pVertC,
		   const Vert* const pVertD);
///
int iIsInTri(const Vert* const pV,     const Vert* const pVertA,
	     const Vert* const pVertB,	const Vert* const pVertC);
///
int
iIsInTri (const double adVert[2],const double adVertA[2],
	  const double adVertB[2], const double adVertC[2]);
///
int iOrient2D(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC);
///
int iOrient2D(const double adA[2], const double adB[2],
	      const double adC[2]);
/// int iOrient2D(const EdgeFace* const pFE, const double ad[3]);
int iIncircle(const Vert* const pVA, const Vert* const pVB,
	      const Vert* const pVC, const Vert* const pVD);
int iIncircle(const double adA[2], const double adB[2],
	      const double adC[2], const double adD[2]);
///
int iIsReflex(const EdgeFace* const pF);

///If line passing by pVA and pVB intersect line passing
///by pVC and pVD, return intersection coords. 
bool LineLineIntersection(const Vert* const pVA, const Vert* const pVB,
			  const Vert* const pVC, const Vert* const pVD,
			  double intersection[2]);

/// Does ray starting from pVA towards pVB intersect
/// line going from pVC to pVD.
/// return -1 if no intersection, 
///         0 if intersect at either end of the line
///         1 if intersect the line.
/// This might be somewhat unstable, use with care...
int iRayIntersect(const Vert* const pVA, const Vert* pVB,
		  const Vert* const pVC, const Vert* pVD,
		  double* intersection = NULL);

/// Does the segment going from pVA to pVB intersect 
/// the segement going from pVC to pVD?
int iSegmentIntersect(const Vert* const pVA, const Vert* pVB,
		      const Vert* const pVC, const Vert* pVD);

#endif
