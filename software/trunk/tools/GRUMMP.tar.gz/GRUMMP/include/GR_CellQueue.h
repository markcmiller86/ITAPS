#ifndef GR_CellQueue
#define GR_CellQueue 47

#include <map>

#include <GR_Mesh.h>
#include <GR_Vertex.h>
#include <GR_Cell.h>
#include <GR_Face.h>

//Compares cells for insertion priority
struct biggerthenCell
{
  bool operator()(const Cell* pC1,const Cell* pC2) const
  {
    if(pC1==pC2) return false;    //So that equality is dependant only on the pointer

    double dPri1,dPri2;
    dPri1=pC1->getAnisoCircumradius();
    dPri2=pC2->getAnisoCircumradius();

    if(iFuzzyComp(dPri1,dPri2)==0)
      {
	//If the cells have the same priority, they are sorted by pointer.
	return (pC1>pC2);
      }
    return (dPri1>dPri2);
  }
};

struct smallerthenFace
{
  bool operator()(const Face* pF1,const Face* pF2) const
  {
  if(pF1==pF2) return false;    //So that equality is dependant only on the pointer
    double dPri1,dPri2;
    //  dPri1=pC1->pVVert(0)->dX();
    //   dPri2=pC2->pVVert(0)->dX();
   
    dPri1=-(pF1->getLength());
    dPri2=-(pF2->getLength());

    if(iFuzzyComp(dPri1,dPri2)==0)
      {
	//If the cells have the same priority, they are sorted by pointer.
	return (pF1>pF2);
      }
    return (dPri1>dPri2);
  }
};


class CellQueue {
  CellQueue(const CellQueue&) :
    pM(NULL), setpCBig(), setpFSmall(), dMaxBig(), dMinSmall()
  {assert(0);}
  CellQueue& operator=(const CellQueue&) {assert(0); return(*this);}
 public:  
  CellQueue(): pM(NULL), setpCBig(), setpFSmall(), dMaxBig(), dMinSmall()
  {assert(0);}
   
  CellQueue(Mesh* pM_In,double dMinSize_,double dMaxAngle_,bool qAttachToMesh);

  ~CellQueue(); //need to detach cell queue (TODO)

  Mesh* pM;
  std::set<Cell*,biggerthenCell> setpCBig;
  std::set<Face*,smallerthenFace> setpFSmall;

  double  dMaxBig;
  double  dMinSmall;

  size_t iBig(){return setpCBig.size();}
  size_t iSmall(){return setpFSmall.size();}
  size_t iSize(){return iBig()+iSmall();}

  Cell* pCTopCell();
  Face* pFSmallestFace();

  void vReset();
  void vRemoveCell( Cell* pC);
  void vRemoveFace(Face* pF);
  void vAddCell(Cell* pC);
  bool qHasCell(Cell* pC);
  bool qNeverAdd(const Cell* const pC);
  void vTest();
};

#endif 
