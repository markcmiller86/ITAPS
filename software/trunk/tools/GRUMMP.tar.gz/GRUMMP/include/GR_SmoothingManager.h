#ifndef GR_SmoothingManager_h
#define GR_SmoothingManager_h

#include <set>

#include "GR_Cell.h"
#include "GR_Mesh.h"
#include "GR_Observer.h"
#include "GR_Vertex.h"
#include "SMsmooth.h"

namespace GRUMMP {
  class SmoothingManager: public Observer {
  protected:
    Mesh* m_pMesh;
  private:
    /// Default construction is a really, really bad idea.
    SmoothingManager();
    /// Copy construction isn't harmful, but it isn't clear that it's
    /// helpful, either.
    SmoothingManager(SmoothingManager&);
    /// Operator= isn't obviously helpful, either.
    SmoothingManager& operator=(SmoothingManager&);
    // Need to have a queue and ways to access it, but that can wait for
    // specializations --- OpenMP, MPI, etc --- and/or Observer giving
    // feedback about faces that should be looked at.
    //
    // The following set is the simple serial version.  For parallel
    // (either version) it isn't going to be adequate.
    std::set<Vert*> vertQueue;
  public:
    /// Set the mesh at construction time.
    SmoothingManager(Mesh* pMeshToSmooth) :
      m_pMesh(pMeshToSmooth), vertQueue()
    {
      m_pMesh->addObserver(this, Observable::cellCreated
          | Observable::vertDeleted | Observable::vertMoved);
    }
    virtual ~SmoothingManager();

    // Observer function overrides
    void receiveDeletedVerts(std::vector<Vert*>& deletedVerts);
    void receiveMovedVerts(std::vector<Vert*>& movedVerts);
    void receiveCreatedCells(std::vector<Cell*>& createdCells);

    virtual int smoothAllVerts(const int passes);
    int smoothAllQueuedVerts();
    virtual int smoothVert(Vert* vert) = 0;
  };

  class OptMSSmoothingManager: public SmoothingManager {
  protected:
    /// An opaque struct that contains context data for mesh smoothing.
    SMsmooth_data *m_smoothData;
    double **m_neighCoords;
    int **m_faceConn;
  public:
    OptMSSmoothingManager(Mesh * const pMeshToSmooth,
                          const int iDim);
    ~OptMSSmoothingManager()
    {
    }
    static OptMSSmoothingManager* Create(Mesh * const pMeshToSmooth);
    virtual int smoothVert(Vert* vert) = 0;
    virtual int smoothAllVerts(const int passes = 5) {
      SMinitSmoothStats (m_smoothData);
      int retVal = SmoothingManager::smoothAllVerts(passes);
      SMprintSmoothStats (m_smoothData);
      resetThreshold();
      return retVal;
    }
    // Set a new smoothing measure
    virtual void setSmoothingGoal(const int goal) = 0;
    // Set a new smoothing technique (default: floating threshold, which is
    // quite good).
    void setSmoothingTechnique(const int technique)
      {
        SMsetSmoothTechnique(m_smoothData, technique);
      }
    // Set a cutoff below which optimization will be applied.
    void setSmoothingThreshold(const double threshold)
      {
        SMsetSmoothThreshold(m_smoothData, threshold);
      }
    // Reset the cutoff based on the results from the last pass of smoothing.
    void resetThreshold()
      {
        // For floating threshold after at least one smoothing pass, this
        // will reset the threshold using the global minimum value from
        // the last pass.  In other cases, the threshold value remains
        // unchanged.
        double threshold =
          m_smoothData->smooth_param->lap_accept_value;
        SMconvertToDegrees(m_smoothData->smooth_param->function_id, &threshold);
        SMsetSmoothThreshold(m_smoothData, threshold);
      }
    // Access info about quality
    // Spew smoothing stats
  };

  class OptMSSmoothingManager2D: public OptMSSmoothingManager {
  private:
    int smoothBdryVert(Vert* const vert, Face *const face,
                       BdryEdge* const bdryEdgeInit);
  public:
    OptMSSmoothingManager2D(Mesh2D * const pMeshToSmooth,
                            int qualMeasure = OPTMS_DEFAULT);
    virtual ~OptMSSmoothingManager2D();
    void setSmoothingGoal(const int goal);
    int smoothVert(Vert* vert);
  };

  class OptMSSmoothingManager3D: public OptMSSmoothingManager {
  private:
    std::set<Cell*>  m_incCells;
    std::set<Vert*>  m_neighVerts;
    std::set<BFace*> m_incBdryFaces;
    std::set<Face*>  m_nearFaces; // All faces in tets incident on pV.
  public:
    OptMSSmoothingManager3D(VolMesh * const pMeshToSmooth,
                            int qualMeasure = OPTMS_DEFAULT);
    virtual ~OptMSSmoothingManager3D();
    void setSmoothingGoal(const int goal);
    int smoothVert(Vert* vert);
  };
}
;

#endif
