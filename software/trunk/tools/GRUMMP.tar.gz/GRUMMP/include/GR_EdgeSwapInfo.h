#ifndef GR_EdgeSwapInfo_h
#define GR_EdgeSwapInfo_h

#include "GR_config.h"

namespace GRUMMP {
  class FaceSwapInfo3D;
  
  /// \brief A data carrier for the information needed for edge
  /// swapping.
  ///
  /// At creation time, this includes only the edge identity.  Decisions
  /// about whether to reconfigure an edge are made by a SwapDecider,
  /// which knows about quality measures.  During the decision process,
  /// info about the "after" configuration is added.  Then this info is 
  /// passed to a SwapManager reconfiguration function.
  class EdgeSwapInfo {
  public:
    EdgeSwapInfo(const FaceSwapInfo3D& FC);
    unsigned getNumOrigCells() const {
      return m_numFaces - (m_isBdryEdge ? 1 : 0);
    }
    unsigned getNumOrigVerts() const {return m_numFaces;}
    Cell *getOrigCell(const unsigned u) const
    {
      assert(u < getNumOrigCells());
      return m_origCells[u];
    }
    BFace *getBFace(const int i) const
    {
      assert(i == 0 || i == 1);
      return (i == 0 ? m_origBFace0 : m_origBFace1);
    }      
    Vert *getNorthVert() const {return m_northVert;}
    Vert *getSouthVert() const {return m_southVert;}
    Vert *getVert(const unsigned u) const
    {
      assert(u < m_numFaces);
      return m_outerVerts[u];
    }
    void setNewConfig(const unsigned bestCanon, const unsigned bestPerm)
    {
      m_bestCanon = bestCanon;
      m_bestPerm = bestPerm;
    }
    void getNewConfig(unsigned& bestCanon, unsigned& bestPerm) const
    {
      bestCanon = m_bestCanon;
      bestPerm = m_bestPerm;
    }
    bool isBdryEdge() const {return m_isBdryEdge;}
    bool isSwappableEdge() const {return !m_tooManyFaces && m_numFaces > 0;}
  private:
    // Private data
    enum {m_maxFaces = 10};
    // The "+1" in these arrays is to allow space for bdry edge swapping
    Vert *m_outerVerts[m_maxFaces+1];
    Cell *m_origCells[m_maxFaces+1];
    BFace *m_origBFace0, *m_origBFace1;

    Vert *m_northVert, *m_southVert;
    // These variables are all small, so packing them in is no problem.
    // Number of faces should never be more than 10.
    // The number of canonical configurations is no larger than 7 for
    // cases currently coded.
    // The number of permutations is no larger than numFaces
    unsigned m_numFaces:8, m_bestCanon:6, m_bestPerm:6;
    // Some status indicators.
    bool m_tooManyFaces:1, m_isBdryEdge:1;
    EdgeSwapInfo();
    EdgeSwapInfo(const EdgeSwapInfo&);
    EdgeSwapInfo& operator=(const EdgeSwapInfo&);
    // These are called (directly or indirectly) from the constructor.
    void gatherEdgeInfo(Face* const face, Vert* const otherVert);
    void gatherBdryEdgeInfo(Face* const face, Vert* const otherVert);
  };
} // namespace GRUMMP
#endif
