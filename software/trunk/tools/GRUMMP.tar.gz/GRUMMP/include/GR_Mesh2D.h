#ifndef GR_Mesh2D
#define GR_Mesh2D 1

#include "GR_config.h"
#include "GR_Classes.h"
#include "GR_BFace2D.h"
#include "GR_Cell.h"
#include "GR_CellCV.h"
#include "GR_Face.h"
#include "GR_GRCurve.h"
#include "GR_Mesh.h" 
#include "GR_EntContainer.h"
#include <map>

class GRGeom2D;

/**\brief The 2D specialization of the Mesh base class.
 *
 * Functions inherited from Mesh will not be documented again here.
 */
class Mesh2D : public Mesh {
protected:
  /// Variable size array containing faces in the 2D mesh
  EntContainer<EdgeFace>      m_ECEdgeF;      

  /// Variable size array containing bdry faces in the 2D mesh
  EntContainer<BdryEdge>      m_ECEdgeBF; 

  /// Variable sized array containing triangular cells in the 2D mesh
  EntContainer<TriCell>       m_ECTri; 

  /// Variable sized array containing quadrilateral cells in the 2D mesh
  EntContainer<QuadCell>      m_ECQuad;
  
  /// Variable size array containing internal bdry faces in the 2D mesh
  EntContainer<IntBdryEdge>   m_ECIntEdgeBF; 

private:
  /// The copy constructor currently appears to be unnecessary.
  Mesh2D(const Mesh2D& );
  
  /// operator= has probably always been unnecessary.
  Mesh2D& operator=(const Mesh2D&);

public:


  ///This constructor is used by MeshOpt2D and Coarsen2D executables.
  ///It requires a good rework to make it work with the new geometry interface.
  Mesh2D(const char strInFileName[], GRGeom2D* const geometry = NULL,
	 const int iQualMeas = 2);
  /// Read mesh data from a file.
  void readFromFile(const char strFileName[]);
  ///
  void relateMeshToGeometry(GRGeom2D* const geometry);

  ///Default constructor called by TriMeshBuilder.
  Mesh2D(const int iQualMeas = 2);

  ///This constructor is deprecated, but still required for 3D initial
  ///tetrahedralization until Serge's facet branch merges in -and- can
  ///read .bdry and .smesh files.
  Mesh2D(const Bdry2D& B2D, const int iQualMeas = 2);

  //Creating a Delaunay mesh from a set of vertices.
  //THIS SHOULD BE REIMPLEMENTED IN THE TriMeshBuilder CLASS.
  // This is only used in the scat2d executable, apparently, so it can wait. 
  Mesh2D(const EntContainer<Vert>& EC);

  ///Destructor.
  virtual ~Mesh2D() { }

  /// Inquiry functions


  //////////////////////////////////////////////////////////////////////
  /// Functions that directly manipulate or query the mesh database. ///
  //////////////////////////////////////////////////////////////////////
  
  GR_index_t iVertIndex(const Vert* const pV) const { return (m_ECVerts.getIndex(pV)); }
  GR_index_t iNumVerts() const {return m_ECVerts.lastEntry();}

  /// Given a face pointer, find the corresponding integer index.
  virtual GR_index_t getFaceIndex(const Face* const pF) const;
  virtual GR_index_t getNumFaces() const {return m_ECEdgeF.lastEntry();}
  virtual Face* getFace(const GR_index_t i) const;
  ///
  virtual GR_index_t getBFaceIndex(const BFace* const pBF) const;
  virtual GR_index_t getNumBdryFaces() const {return m_ECEdgeBF.lastEntry();}
  virtual GR_index_t getNumIntBdryFaces() const {return m_ECIntEdgeBF.lastEntry();}
  virtual BFace* getBFace(const GR_index_t i) const;
  virtual GR_index_t getNumBdryPatches() {assert(0); return (~0);/*B2D.iNumPatches();*/}
  virtual void buildBdryPatches();
  ///
  virtual GR_index_t getCellIndex(const Cell* const pC) const;
  GR_index_t getNumTriCells() const {return m_ECTri.lastEntry();}
  GR_index_t getNumQuadCells() const {return m_ECQuad.lastEntry();}
  virtual GR_index_t getNumCells() const {return getNumTriCells() + getNumQuadCells();}

  GR_index_t getNumEdgesInUse() const {return m_ECEdgeF.size();}
  GR_index_t getNumBdryEdgesInUse() const {return m_ECEdgeBF.size();}
  GR_index_t getNumIntBdryEdgesInUse() const {return m_ECIntEdgeBF.size();}
  GR_index_t getNumTrisInUse() const {return m_ECTri.size();}
  GR_index_t getNumQuadsInUse() const {return m_ECQuad.size();}
  GR_index_t getNumTetsInUse() const {return 0;}
  GR_index_t getNumPyrsInUse() const {return 0;}
  GR_index_t getNumPrismsInUse() const {return 0;}
  GR_index_t getNumHexesInUse() const {return 0;}

  virtual Cell* getCell(const GR_index_t i) const;
#ifdef ITAPS
  ///
  virtual bool isValidEntHandle(void* pvEnt) const;
#endif
  ///
  virtual eMeshType getType() const {return Mesh::eMesh2D;}
  ///
  /// perimeter length or  area:
  virtual double calcBoundarySize() const;
  /// interior   area  or volume:
  virtual double calcInteriorSize() const;
  virtual bool isWatertight() const;
  /// 
  /// Validity checking
  virtual bool isValid() const;
public:
  ///
  bool isLocallyDelaunay() const;

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////

  // The generic, ITAPS-style calls
/*   Face* createFace(Vert * const apV[], const int iNVerts); */
/*   Cell* createCell(Face * const apF[], const int iNFaces, const int iReg); */
/*   Cell* createCell(Vert * const apV[], const int iNFaces, const int iReg); */

  // The size-specific (and more efficient) calls; the ITAPS-style calls
  // will either call these or switch on number of verts and execute the
  // same code.
  Vert* createVert(const double dX, const double dY, const double dZ = 0);
  Vert* createVert(const double adCoords[]);
  BFace* createBFace(Face * const pF, BFace * const pBF = pBFInvalidBFace);
  /// This form is deprecated, but currently needed to read native format.
  BFace* createBFace(Face * const pF, const int i);
  Face* createFace(bool& qAlreadyExisted, Vert * const pV0, Vert * const pV1,
		   const bool qForceDuplicate = false);
  /// This form will almost certainly be deprecated in future
  IntBdryEdge* createIntBdryEdge(Face * const pFA, Face * const pFB,
				 BFace * const pBF = pBFInvalidBFace);
  /// Create a new internal bdry edge, including setting geometry info.
  IntBdryEdge* createIntBdryEdge(Vert* const pVBeg, Vert* const pVEnd,
				 GRCurve* const curve,
				 double dBegParam, double dEndParam );
  /// Create a new bdry edge, including setting geometry info.
  BdryEdge* createBdryEdge(Vert* const pVBeg, Vert* const pVEnd,
			   GRCurve* const curve,
			   double dBegParam, double dEndParam );
  TriCell* createTriCell(Face * const pF0, Face * const pF1,
			 Face * const pF2,
			 const int iReg = iDefaultRegion);
  QuadCell* createQuadCell(Face * const pF0, Face * const pF1,
				   Face * const pF2, Face * const pF3,
				   const int iReg = iDefaultRegion);
  TriCell* createTriCell(Vert * const pV0, Vert * const pV1,
				 Vert * const pV2,
				 const int iReg = iDefaultRegion);
  QuadCell* createQuadCell(Vert * const pV0, Vert * const pV1,
				   Vert * const pV2, Vert * const pV3,
				   const int iReg = iDefaultRegion);
  Cell* createCell(Vert * const vert, Face * const face,
                    const int iReg) {
    return createTriCell(vert, face->getVert(0), face->getVert(1), iReg);
  }
  bool deleteVert(Vert * const pV);
  bool deleteFace(Face * const pF);
  bool deleteBFace(BFace * const pBF);
  bool deleteCell(Cell * const pC);
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  

  ///
  virtual void purgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL);
  ///
  virtual void purgeFaces(std::map<Face*, Face*>* face_map = NULL);
  ///
  virtual void purgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  ///
  virtual void purgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  /// Return the number of triangular cells.
  virtual void purgeAllEntities(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL,
		      std::map<BFace*, BFace*>* bface_map = NULL);

  void resetVertexConnectivity();
  ///
 protected:
  virtual void reorderVerts_RCM(void);
  virtual void reorderCells(void);
  virtual void reorderFaces(void);
 public:

  ////////////////////////////////////////////////////////
  /// Functions that affect the behavior of algorithms ///
  ////////////////////////////////////////////////////////

  virtual void makeSimplicial() {assert(0);}

  // Insertion:
  // The worst shape quality measure (shortest edge to circumradius) allowed.
  // The worst shape quality measure allowed.
  virtual double getWorstAllowedCellShape() const
    {
      // These should correspond to minimum angles of 20.7, 25.7, and 30 deg,
      // respectively.
      switch (m_encroachType) {
      case eBall:
	return sqrt(1./6.); // = sin(20.7 deg) / sin(60 deg)
      case eLens:
	return 0.5;         // = sin(25.7 deg) / sin(60 deg)
      case eNewLens:
	return sqrt(1./3.); // = sin(30 deg) / sin(60 deg)
      default:
	assert(0);
	return 0;
      }
    }
  // End insertion

  // Coarsen:
  virtual double getCoarseningConstant() const {return 0.45;}
  // End coarsen

  ///////////////////////////////////////////////////////
  /// Low-level algorithms that change mesh geom/topo ///
  ///////////////////////////////////////////////////////

  // Swapping
 private:
  virtual bool doSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE = pVInvalidVert) const;
 public:
  virtual int iFaceSwap_deprecated(Face*& pF);

  // Vertex removal
  virtual bool removeVertByContraction(Vert * const pV, int& iNewSwaps,
					Vert * apVPreferred[] = NULL,
					const int iNPref = 0);
  virtual bool removeVert(Vert * const pV, int& iNewSwaps);

  ///
#ifndef FACET_MERGED
  void getNeighborVertsAndFaces(Vert* pV,
				 List<Vert*>& LpVNear,
				 List<Face*>& LpFNear );
#endif

  /////WATSON INSERTION DECLARATIONS/////

  friend class TriMeshBuilder;
  friend class TriMeshRefiner;
    
  //Define this struct to make function calls a little "cleaner".
  struct WatsonData {
    std::map<Face*, int> hull_faces;
    std::set<Face*> faces_to_remove;
    std::set<Cell*> cells_to_remove;
    std::set<BdryEdgeBase*> encroached_bdry_edges;
    WatsonData() : hull_faces(), faces_to_remove(), cells_to_remove(),
		   encroached_bdry_edges() {}
  };


  //
  typedef std::pair<BdryEdgeBase*, BdryEdgeBase*> BEdgePair; 

  //This is a pure virtual function in the base class.
  virtual int insertPointWatson_deprecated(WatsonInfo_deprecated& WI);
   
  /// The following function is deliberately blank; it's not needed in 2D.
  void cleanupWatson_deprecated(WatsonInfo_deprecated&) {}

  //////////////////////////////////////////////////
  /// High-level algorithms that change the mesh ///
  //////////////////////////////////////////////////

  // This call is deprecated; don't use it in new code.  It's still used
  // in a couple of places, but those are slated for change: coarsening,
  // aniso refinement in 2D, and the STL mesher.
  virtual int iSwap_deprecated(const int iMaxPasses = 2,
			       const bool qAlreadyMarked = false);

  virtual bool makeDelaunay();

  ////////////////////////////////////////////////////////
  /// Internal routines to assist with mesh coarsening ///
  ////////////////////////////////////////////////////////

private:
  // Find the cell incident on pV0 that covers the ray towards pV1 (may be
  // a multiple choice question if pV0 and pV1 are adjacent, or if there
  // is a face containing one but not the other and colinear with both.
  virtual Cell* beginPipe(const Vert* const pVLast,
			    const Vert* const pVNew) const;
public:
  virtual void identifyVertexTypesGeometrically() const;

  /////////////////////////////////////////////
  /// Quasi-internal routines for insertion ///
  /////////////////////////////////////////////

  //This will actually call compute_watson_data with default arguments. 
  //It is a pure virtual function in the base class so needs to be defined here.
  virtual void getWatsonData_deprecated(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const;

  //New functions to compute data necessary for Watson insertion
  void computeWatsonData_deprecated( const CubitVector& point,
			    const Cell* const seed_cell,
			    WatsonData& watson_data,
			    const bool test_bdry_for_encroachment = true,
			    const bool exit_on_encroached_bdry    = true ) const;
  
  void computeWatsonData_deprecated( const Vert* const vertex,
			    const Cell* const seed_cell,
			    WatsonData& watson_data,
			    const bool test_bdry_for_encroachment = true,
			    const bool exit_on_encroached_bdry    = true ) const;

  //Public interface to insert a point in the mesh using Watson insertion.
  //NOTE: This call will always prevent any boundary edge from being
  //encroached. Therefore, it is possible that many vertices get
  //inserted on the boundary, even though the initial intent was to
  //insert a single vertex in the interior.
  void insertWatson_deprecated(const CubitVector& insert_location,
		     Cell* seed_cell = NULL,
		     const std::set<Cell*>* const seed_guesses = NULL,
		     std::vector<Cell*>* new_cells = NULL,
		     std::vector<Face*>* new_faces = NULL);

  void markCleanNeighbors (Cell * pC);
  
  //MAKE PRIVATE!
  //Inserts a new vertex in the interior.
  void insertWatsonInterior_deprecated(Vert* const new_vert,
			      WatsonData& watson_data,
			      std::vector<Cell*>* new_cells = NULL,
			      std::vector<Face*>* new_faces = NULL);
  //MAKE PRIVATE!
  //Inserts a new vertex on the mesh boundary. Returns a pair 
  //containing the newly created boundary edges.
  BEdgePair insertWatsonBoundary_deprecated(Vert* const new_vert,
				   BdryEdgeBase* const edge_to_split,
				   WatsonData& watson_data,
				   double new_param = LARGE_DBL,
				   std::vector<Cell*>* new_cells = NULL,
				   std::vector<Face*>* new_faces = NULL);

  //This function is no longer defined in 2D, it is replaced by
  //delete_interior_verts_in_ball (accepting different arguments).
  //Since it is a pure virtual function in the base class, a definition
  //is still needed.
  virtual bool deleteInteriorPointsInBall(const Cell*, const double[],
					   const double, int&) {
    vFatalError("This function is not defined in 2D",
		"Mesh2D::qDeleteInteriorPointsInBall");
    return false;
  }

 private:

  //Marks the set contents as deleted. Also removes face-cell connectivity.
  void deleteWatsonHull_deprecated(std::set<Cell*>& cells_to_remove,
			  std::set<Face*>& faces_to_remove,
			  BdryEdgeBase* const edge_to_split = NULL);

  //Rebuilds the Watson hull.
  void reconnectWatsonHull_deprecated(Vert* const new_vertex,
			     const std::map<Face*, int>& hull_faces,
			     std::vector<Cell*>* new_cells,
			     std::vector<Face*>* new_faces);

  //Deletes the INTERIOR vertices located in the boundary edge's 
  //diametral ball from the mesh. 
  void deleteVertsInEdgeBall_deprecated(BdryEdgeBase* const edge_to_split,
				 std::vector<Cell*>* new_cells = NULL);

  //The following two should only be used with a Delaunay triangulation
  //(not a constrained Delaunay one).

  //Finds a cell with vertex in its circumcenter among guesses.
  //If none is found, then calls find_seed_naively.
  Cell* findSeedGuesses_deprecated(const Vert* const vertex,
			  const std::set<Cell*>* const guesses = NULL) const;

  //Finds a cell with vertex in its circumcenter with a cell by cell test.
  Cell* findSeedNaively_deprecated(const Vert* const vertex) const;

  ///// END WATSON INSERTION DECLARATIONS ///// 

 public:
  
  //The following two are called by InsertionQueue to add encroached entities
  //at the top of the priority queue. The new mesh refinement implementation in 
  //TriMeshRefiner no longer queues encroached entities. These functions are 
  //no longer necessary. The implementation is commented out in Mesh2D.cxx

  virtual int queueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&) const {
    vFatalError("Function no longer defined in 2D",
		"Mesh2D::iQueueEncroachedBdryEntities()");
    return 0;
  }

  virtual int queueEncroachedBdryEntities(InsertionQueue&,
					   const std::set<BFace*>&,
					   const double[],
					   const double) const {
    vFatalError("Function no longer defined in 2D",
		"Mesh2D::iQueueEncroachedBdryEntities()");
    return 0;
  }



  IntBdryEdge* getIntBdryEdge(const GR_index_t i) const;

  void setupVerts(const GR_index_t i) {m_ECVerts.reserve(i);}
  void setupFaces(const GR_index_t i)     {m_ECEdgeF .reserve(i);}
  void setupBFaces(const GR_index_t i)    {m_ECEdgeBF.reserve(i);}
  void setupIntBFaces(const GR_index_t i)    {m_ECIntEdgeBF.reserve(i);}
  void setupTriCells(const GR_index_t i)  {m_ECTri   .reserve(i);}
  void setupQuadCells(const GR_index_t i) {m_ECQuad  .reserve(i);}

  /// Add entries to connectivity tables
  Face*  getNewFace(const int iNV = 2);
  BFace* getNewBFace(const int iNBV = 2);
  IntBdryEdge* getNewIntBdryEdge(const int iNBV = 2);
  Cell*    getNewCell(const int iNF = 3);

  /// Prints a summary of the patches...
  void checkPatches();
  /// Take cell-vert data and convert in into a 2D connectivity
/*   virtual void vConvertFromCellVert(const EntContainer<TriCellCV>& ECTriCV, */
/* 				    const EntContainer<QuadCellCV>& ECQuadCV */
/* 				    = EntContainer<QuadCellCV>(), */
/* 				    const EntContainer<EdgeBFaceCV>& ECBFCV */
/* 				    = EntContainer<EdgeBFaceCV>()); */

  // Mesh optimization, point insertion, etc
  int reconfigure(Face*& pF);
  ///
  bool recoverEdge(const int iV0, const int iV1);
  bool recoverEdge(Vert* const pV0, Vert* const pV1);
  bool recoverEdge(Vert* const pV0, Vert* const pV1,
		    Face*& pF);
  ///
  bool removeEdge(Face *& pF);

  bool removeVertCheaply(Vert* const pV, int& iNewSwaps);
  ///
  void insertWatsonInterior_deprecated(Vert* const pVNew,
			     const List<Cell*>& LpCToRemove,
			     const List<Face*>& LpFToRemove,
			     const List<Face*>& LpFHull);
public:
  /// PreProcessing for Ruppert - 1
  void checkForLargeAngles(const double dMaxAngle = M_PI_2); // 90 deg
  /// PreProcessing for Ruppert - 2
  void checkForSmallAngles();
  /// Performs Ruppert's algorithm on the mesh..
  bool refineRuppert(const int iNumInsertions = 0);

  ///
  bool isCellBadRuppert(const Cell *pC, bool *qInCorner);
  //
  // The following three functions are used in the experimental
  // anisotropic meshing code.
  void generateAnisotropic(const int iNStructBC, const int aiStructBC[],
			    const double dScale, const double dGrading);
  void refineBoundaryToLengthScale(const int iNStructBC,	
			    const int aiStructBC[]);

  bool createQuadFromTris(Cell* const pCA, Cell* const pCB);
  bool createQuadFromVerts(Vert* const pVA, Vert* const pVB,
			    Vert* const pVC, Vert* const pVD);

  void setLSChecking(bool qCheck);

protected:
  void getBdry2DInfo(const Bdry2D& B2DInfo);

  ///
 
public:

  void writeBdryPatchFile(const char strBaseFileName[], 
			   const char strExtraFileSuffix[]) const;

public:
  /// Iterator functions
  EntContainer<EdgeFace>::iterator edgeFace_begin() const
  { return m_ECEdgeF.begin(); }
  EntContainer<EdgeFace>::iterator edgeFace_end() const
  { return m_ECEdgeF.end(); }

  friend class AnisoRefinement;
};

/** Unlikely ever to be called from user code. */
/// Write as dictated by a file format template.  Deprecate?
void writeFile_Mesh2D(Mesh2D & Mesh,
		       const char strBaseFileName[],
		       const char strExtraFileSuffix[] = "");
/// Write a file in GRUMMP native format
void writeNative(Mesh2D& OutMesh,
		 const char strBaseFileName[],
		 const bool qHighOrder = true,
		 const char strExtraFileSuffix[] = "");
/// Write a file in generic finite element (cell-vertex) format
void writeFEA(Mesh2D& OutMesh,
	      const char strBaseFileName[],
	      const int iOrder = 2,
	      const char strExtraFileSuffix[] = "");
/// Write a file in the VTK legacy format (.vtk, uncompressed)
void writeVTKLegacy(Mesh2D& OutMesh,
		    const char strBaseFileName[],
		    const char strExtraFileSuffix[] = "");

/// Read as dictated by a file format template; needs translation backend.
void readFile_Mesh2D(const char * const strBaseFileName,
		      int& iNumVerts,
		      int& iNumFaces,
		      int& iNumCells,
		      int& iNumBdryFaces,
		      int& iNumIntBdryFaces,
		      bool& qFaceVert,
		      bool& qCellVert,
		      bool& qFaceCell,
		      bool& qCellFace,
		      bool& qCellRegion,
		      bool& qBFaceFace,
		      bool& qBFaceVert,
		      bool& qBFaceBC,
		      bool& qIntBFaceFace,
		      bool& qIntBFaceVert,
		      bool& qIntBFaceBC,
		      EntContainer<Vert>& ECVerts,
		      int (*&a2iFaceVert)[2],
		      int (*&a2iFaceCell)[2],
		      int (*&a2iCellVert)[3],
		      int (*&a2iCellFace)[3],
		      int *&aiCellRegion,
		      int *&aiBFaceFace,
		      int *&aiBFaceBC,
		      int (*&a2iBFaceVert)[2],
		      int (*&a2iIntBFaceFace)[2],
		      int *&aiIntBFaceBC,
		      int (*&a2iIntBFaceVert)[2]);

/// Read a file in GRUMMP native format
void readNative(Mesh2D& OutMesh,
		const char strFileName[]);

/// Read a file in generic finite element (cell-vertex) format
void readFEA(Mesh2D& OutMesh,
	     const char strFileName[]);

/// Read a file in the VTK legacy format (.vtk, uncompressed)
void readVTKLegacy(Mesh2D& OutMesh,
		   const char strFileName[]);


#endif
