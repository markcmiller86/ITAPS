#ifndef GR_TRIMESHREFINER_H
#define GR_TRIMESHREFINER_H

#include "GR_config.h"
#include "GR_Mesh2D.h"
#include <deque>
#include <utility>

class BdryEdgeBase;
class Cell;
class Length2D;
class InsertionQueue;
class TriCell;

class TriMeshRefiner {
  TriMeshRefiner(const TriMeshRefiner&);
  TriMeshRefiner operator=(const TriMeshRefiner&);

  //The mesh we want to refine.
  Mesh2D* m_mesh;

  //The sizing field for size refinement
  Length2D* m_sizing_field;

  //The queue containing encroached boundary edges.
  std::deque<BdryEdgeBase*> m_edge_split_queue;

  //The priority queue for circumcenter insertion.
  InsertionQueue* m_IQ;

 public:

  TriMeshRefiner(Mesh2D* const mesh, 
		 bool check_for_encroachment = true);

  TriMeshRefiner(Mesh2D* const mesh,
		 Length2D* const sizing_field,
		 bool check_for_encroachment = true);

  ~TriMeshRefiner();
  
  void refine_mesh();

  void refine_boundary_for_length();

  void output_triangulation_to_file(const char* const filename) const;

 private:

  void init_tri_mesh_refiner(bool check_for_encroachment);

  void fix_boundary_encroachment();

  void split_triangle(TriCell* const cell_to_split);

  bool split_bdry_edge(BdryEdgeBase* const bedge_to_split,
		       std::pair<BdryEdgeBase*, BdryEdgeBase*>* new_bedges = NULL);
  
  void add_to_priority_queue(Cell* const cell);

  void queue_encroached_bdry_edges();

};


#endif
