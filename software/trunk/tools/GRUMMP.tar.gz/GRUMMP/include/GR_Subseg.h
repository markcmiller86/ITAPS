#ifndef GR_SUBSEG_H
#define GR_SUBSEG_H

#include "GR_config.h"
#include <vector>

class CubitBox;
class CubitVector;
class RefEdge;
class RefFace;
class RefVertex;
class Subseg;
class Vert;

class SubsegBridge {
  
  RefFace* m_ref_face; //The surface to which we are bridging with this entity
  Subseg* m_parent;    //The parent subseg on a neighboring curve.
  Vert* m_verts[2];    //The two SURFACE vertices (not the same as the Subseg verts).

  SubsegBridge(const SubsegBridge&);
  SubsegBridge& operator=(const SubsegBridge&);

 public:

  SubsegBridge() : m_ref_face(NULL), m_parent(NULL) 
  { m_verts[0] = NULL; m_verts[1] = NULL; }

  ~SubsegBridge();

  void set_ref_face(RefFace* const ref_face) 
  { m_ref_face = ref_face; }

  RefFace* get_ref_face() const 
    { return m_ref_face; } 

  void set_parent(Subseg* const parent) 
    { m_parent = parent; }

  Subseg* get_parent() const 
    { return m_parent; }

  void set_vert(int i, Vert* const vertex) 
    { assert(i == 0 || i == 1); m_verts[i] = vertex; }

  Vert* get_vert(int i) const 
    { assert(i == 0 || i == 1); return m_verts[i]; }

  bool has_vert(Vert* const vertex) const 
    { return (m_verts[0] == vertex || m_verts[1] == vertex); }

  void replace_vert( Vert* const old_vert, Vert* const replace_by ) {
    assert(has_vert(old_vert));
    if(m_verts[0] == old_vert) m_verts[0] = replace_by;
    else                       m_verts[1] = replace_by;
  }

  bool parent_deleted() const;

};

class Subseg {

 public:

  //We are storing the vertex and its parameter on the RefEdge
  struct VertData {

    Vert* vertex;
    double param;
    
    VertData() : vertex(NULL), param(-LARGE_DBL) {}

    ~VertData() {}

    VertData(Vert* const _vertex_, double _param_) 
      : vertex(_vertex_), param(_param_) {}

    VertData(const VertData& VD) 
      : vertex(VD.vertex), param(VD.param) {}

    VertData& operator=(const VertData& VD) {
      if (&VD != this) {
	vertex = VD.vertex;
	param  = VD.param;
      }
      return *this;
    }

  };

 private:

  VertData *m_vd1, *m_vd2;

  RefEdge* m_parent_edge;

  std::vector<SubsegBridge*> m_children;

  bool m_deleted, m_locked;  

 public:

  Subseg(const VertData& vd1, const VertData& vd2,
	 RefEdge* const edge) 
    : m_vd1(new VertData(vd1.vertex, vd1.param)), 
      m_vd2(new VertData(vd2.vertex, vd2.param)), 
    m_parent_edge(edge), m_children(), m_deleted(false), m_locked(false) {}

  Subseg(Vert* const v1, Vert* const v2, 
	 double param1, double param2,
	 RefEdge* const edge) 
    : m_vd1(new VertData(v1, param1)), 
      m_vd2(new VertData(v2, param2)), 
    m_parent_edge(edge), m_children(), m_deleted(false), m_locked(false) {}

  Subseg(Vert* const v1, Vert* const v2) 
    : m_vd1(new VertData(v1, 0.)), 
      m_vd2(new VertData(v2, 1.)), 
    m_parent_edge(NULL), m_children(), m_deleted(false), m_locked(false) {}

  Subseg() 
    : m_vd1(new VertData()), m_vd2(new VertData()), 
    m_parent_edge(NULL), m_children(), m_deleted(false), m_locked(false) {}

  Subseg(const Subseg& SS) 
    : m_vd1(new VertData(SS.m_vd1->vertex, SS.m_vd1->param)), 
      m_vd2(new VertData(SS.m_vd2->vertex, SS.m_vd2->param)), 
      m_parent_edge(SS.m_parent_edge), m_children(SS.m_children), 
      m_deleted(SS.m_deleted), m_locked(SS.m_locked) {}

  Subseg& operator=(const Subseg& SS) { 
    if (&SS != this) {
      m_vd1->vertex = SS.m_vd1->vertex;
      m_vd2->vertex = SS.m_vd2->vertex;
      
      m_vd1->param  = SS.m_vd1->param;
      m_vd2->param  = SS.m_vd2->param;
      
      m_parent_edge = SS.m_parent_edge;
      
      m_children = SS.m_children;
      
      m_deleted = SS.m_deleted;
      m_locked = SS.m_locked;
    }
    return *this;
 
  }

  ~Subseg();

  //Marks this subseg as deleted
  void mark_deleted() { m_deleted = true; }

  //Checks if the subseg is marked as deleted (or not).
  bool is_deleted() const { return m_deleted; }
  bool is_not_deleted() const { return !m_deleted; }

  //
  void lock() { m_locked = true; }
  void unlock() { m_locked = false; }
  bool locked() { return m_locked; } 

  //Returns the vertices defining this subseg.
  Vert* get_beg_vert() const { return m_vd1->vertex; }
  Vert* get_end_vert() const { return m_vd2->vertex; }

  //Returns the vertices' parametric location
  double get_beg_param() const { return m_vd1->param; }
  double get_end_param() const { return m_vd2->param; }

  double get_vert_param(const Vert* const vert0) const 
  { assert(has_vert(vert0)); return vert0 == m_vd1->vertex ? m_vd1->param : m_vd2->param; }

  void get_other_vert(const Vert* const vert0, Vert*& vert1) const 
  { assert(has_vert(vert0)); vert1 = vert0 == m_vd1->vertex ? m_vd2->vertex : m_vd1->vertex; }

  void get_other_vert_data(const Vert* const vert0, Vert*& vert1, double& param1) const { 
    assert(has_vert(vert0)); 
    if(vert0 == m_vd1->vertex) { vert1 = m_vd2->vertex; param1 = m_vd2->param; } 
    else { vert1 = m_vd1->vertex; param1 = m_vd1->param; }
  }

  //Returns the attached RefEdge.
  RefEdge* get_ref_edge() const { return m_parent_edge; }

  //Adds a child to this subseg.
  void add_bridge(SubsegBridge* const child) { 
    if(child->get_parent() == NULL) child->set_parent(this);
    assert(child->get_parent() == this); 
    m_children.push_back(child); 
  }

  //Populates the children vector with the children of this subseg.
  void get_children(std::vector<SubsegBridge*>& children) const { children = m_children; }

  //Computes the length of this subsegment
  double get_length() const;

  //Checks if Subseg has Vert vert;
  bool has_vert(const Vert* const vertex) const {
    return (m_vd1->vertex == vertex ||
	    m_vd2->vertex == vertex);
  }

  //If m_vd1 or m_vd2 have have a RefVertex as parent
  //topological entity, returns the pointer to this RefVertex.
  //Otherwise, a NULL pointer is returned.
  RefVertex* get_beg_ref_vert() const;
  RefVertex* get_end_ref_vert() const;

  //
  void replace_vert(Vert* const old_vert, Vert* const new_vert) {
    assert(has_vert(old_vert));
    if(m_vd1->vertex == old_vert) m_vd1->vertex = new_vert;
    else                          m_vd2->vertex = new_vert;
  }

  double param_at_distance_from_vert(const double distance, 
				     const Vert* const vert) const;

  //Returns the parameter ON m_edge at a given distance for an end point.
  double param_at_distance_from_beg(const double distance) const
  { return param_at_distance_from_vert(distance, get_beg_vert()); }
  double param_at_distance_from_end(const double distance) const
  { return param_at_distance_from_vert(distance, get_end_vert()); }

  //This call is used when performing refinement. It decides between the various
  //types of splits which one is appropriate for this subsegment, computes the
  //insertion location and then performs the split:
  // - REGULAR CASE: Splits at mid param.
  // - NO PARENT CURVE DEFINED: Splits at mid point.
  // - SMALL ANGLE SPLIT: Computes the concentric shell point and splits at this point.

  //This computes the split data only, does not do or assign anything.
  void compute_refinement_split_data(double split_coords[3], double& split_param);
  //Performs the split if split_coords and split_param are known (for function above).
  void refinement_split(const double split_coords[3], const double split_param,
			Vert* const new_vert, Subseg* const new_subseg1, Subseg* const new_subseg2);
  //Performs the split if split_coords and split_param are not yet known.
  void refinement_split(Vert* const new_vert, Subseg* const new_subseg1, Subseg* const new_subseg2);

  //Splits the subsegment at param.
  //new_subseg1, new_subseg2 and new_vert must be declared
  //and instantiated elsewhere before calling the function
  void split_at_param(const double split_param,
		      Subseg* const new_subseg1, 
		      Subseg* const new_subseg2,
		      Vert* const new_vert);

  //Same as above expect that split is done at middle parameter
  //between m_vd1->param and m_vd2->param.
  void split_mid_param(Subseg* const new_subseg1,
		       Subseg* const new_subseg2,
		       Vert* const new_vert) 
  { split_at_param( 0.5 * (m_vd1->param + m_vd2->param), 
		    new_subseg1, new_subseg2, new_vert ); }

  //Assuming that we know where to split the subsegment,
  //then go ahead and split it.
  //NOTE: this call does not set the parameter at the subseg's
  //vertices. It needs to be done manually somewhere else is this road is taken.
  void split_at_coords(const double split_coords[3],
		       Vert* const new_vert,
		       Subseg* const new_subseg1, Subseg* const new_subseg2) 
  { split( split_coords, new_vert, new_subseg1, new_subseg2 ); }

  void split_at_coords(const CubitVector& split_coords,
		       Vert* const new_vert,
		       Subseg* const new_subseg1, Subseg* const new_subseg2);

  //Returns the subseg midpoint
  CubitVector mid_point() const;

  //Returns the ball radius = 0.5 * subseg length
  double ball_radius() const;
    
  //Returns a coordinate-aligned box containing a ball of radius
  //0.5 * subsegment's length and centered at the subsegment's mid point 
  CubitBox bounding_box() const;

  //Computes closest point from pt on the subseg 
  //(projects to the underlying curve if it is curved)
  void closest_on_subseg(const double pt[3], double close[3]) const;

 private:

  void split( const double split_coords[3], 
	      Vert* const new_vert,
	      Subseg* const new_subseg1, Subseg* const new_subseg2 );

};

inline bool SubsegBridge::parent_deleted() const { return m_parent->is_deleted(); }

#endif
