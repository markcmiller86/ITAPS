#ifndef GR_VolMesh
#define GR_VolMesh 1

#include "GR_config.h"
#include "GR_BFace3D.h"
#include "GR_Cell.h"
#include "GR_Face.h"
#include "GR_List.h"
#include "GR_Mesh.h"
#include "GR_EntContainer.h"

class CubitBox;
class TetRefinerEdge;

///
class VolMesh : public Mesh {
private:
  ///
  bool m_OKToSwapSurfaceEdges:1, m_doEdgeSwaps:1,
    m_strictPatchChecking:1; 
  ///
  // This angle is used to determine when swapping of surface edges is
  // allowed, and also to decide when a surface edge is actually on a
  // bdry curve or not (in the absence of other info and of surface
  // patch recovery code)
  double m_maxAngleForSurfSwap; // In degrees
  /// Three-dimensional topology
  EntContainer<TriFace>       m_ECTriF;      /// Faces  
  EntContainer<QuadFace>      m_ECQuadF;     /// Faces
  EntContainer<TriBFace>      m_ECTriBF;     /// BFaces
  EntContainer<QuadBFace>     m_ECQuadBF;    /// BFaces 
  EntContainer<TetCell>       m_ECTet;       /// Cells  
  EntContainer<PyrCell>       m_ECPyr;       /// Cells
  EntContainer<PrismCell>     m_ECPrism;     /// Cells
  EntContainer<HexCell>       m_ECHex;       /// Cells
  EntContainer<IntTriBFace>   m_ECIntTriBF;  /// Internal bdry faces
  EntContainer<IntQuadBFace>  m_ECIntQuadBF; /// Internal bdry faces
  Bdry3D          *m_Bdry3D;       /// Bdry info
  bool            m_bdryFromMesh; 
private:
  /// Operator= is disabled, because I can't see a use case for it.
  VolMesh& operator=(const VolMesh&) {assert(0); return *this;}
public:
  /// 
  VolMesh(const VolMesh&);
  ///
  VolMesh(const char strBaseFileName[], const int iQualMeas = 2,
	  const double dMaxAngle = 0, Bdry3D * const pB3DIn = NULL);
  ///Added March 2007 by SG.
  VolMesh(const CubitBox& box, const int iQualMeas = 2,
	  const double dMaxAngle = 0);
  ///Modified March 2007 by SG.
  VolMesh(const EntContainer<Vert>& EC, const int iQualMeas = 2,
	  const double dMaxAngle = 0, const CubitBox* const = NULL);
  ///
  VolMesh(SurfMesh &SM, const int iQualMeas = 2,
	  const double dRes = 1, const double dGrade = 1,
	  const double dMaxAngle = 0);
  ///
  VolMesh(const int iQualMeas = 2);
  ///
  virtual ~VolMesh();
  ///
  void readFromFile(const char strBaseFileName[]);
 public:
  void createPatchesFromBdryFaces(const int aiBCList[]);
public:
  void initMeshInBrick(const double dXMin, const double dXMax,
		    const double dYMin, const double dYMax,
		    const double dZMin, const double dZMax);
  ///
  void convertFromCellVert(const GR_index_t iNCells, const GR_index_t iNBdryFaces,
			    const GR_index_t a2iCellVert[][4],
			    const GR_index_t a2iBFaceVert[][3],
			    const int aiBFaceBC[], int*& aiBCList);
  ///
  void convertFromCellVert(const GR_index_t nTet, const GR_index_t nPyr,
			    const GR_index_t nPrism, const GR_index_t nHex,
			    const GR_index_t nBdryTri, const GR_index_t nBdryQuad,
			    const GR_index_t tetToVert[][4],
			    const GR_index_t pyrToVert[][5],
			    const GR_index_t prismToVert[][6],
			    const GR_index_t hexToVert[][8],
			    const GR_index_t bdryTriToVert[][3],
			    const GR_index_t bdryQuadToVert[][4]);
  ///
  eMeshType getType() const {return eVolMesh;}
  ///
  GR_index_t getNumFaces() const {return m_ECTriF.lastEntry() + m_ECQuadF.lastEntry();}
  
  GR_index_t getNumEdgesInUse() const {return 0;}
  ///
  GR_index_t getNumTriFaces() const {return m_ECTriF.lastEntry();}
  GR_index_t getNumTrisInUse() const {return m_ECTriF.size();}
  ///
  GR_index_t getNumQuadFaces() const {return m_ECQuadF.lastEntry();}
  GR_index_t getNumQuadsInUse() const {return m_ECQuadF.size();}
  ///
  GR_index_t getNumBdryFaces() const {return m_ECTriBF.lastEntry() + m_ECQuadBF.lastEntry();}
  GR_index_t getNumBdryFacesInUse() const {return m_ECTriBF.size() + m_ECQuadBF.size();}
  ///
  GR_index_t getNumTriBdryFaces() const {return m_ECTriBF.lastEntry();}
  ///
  GR_index_t getNumQuadBdryFaces() const {return m_ECQuadBF.lastEntry();}
  ///
  GR_index_t getNumIntBdryFaces() const
    {return m_ECIntTriBF.lastEntry() + m_ECIntQuadBF.lastEntry();}
  ///
  GR_index_t getNumIntTriBdryFaces() const {return m_ECIntTriBF.lastEntry();}
  ///
  GR_index_t getNumIntQuadBdryFaces() const {return m_ECIntQuadBF.lastEntry();}
  ///
  GR_index_t getNumCells() const {return m_ECTet.lastEntry() + m_ECPyr.lastEntry() +
			   m_ECPrism.lastEntry() + m_ECHex.lastEntry();}
  ///
  GR_index_t getNumTetCells() const {return m_ECTet.lastEntry();}
  GR_index_t getNumTetsInUse() const {return m_ECTet.size();}
  ///
  GR_index_t getNumPyrCells() const {return m_ECPyr.lastEntry();}
  GR_index_t getNumPyrsInUse() const {return m_ECPyr.size();}
  ///
  GR_index_t getNumPrismCells() const {return m_ECPrism.lastEntry();}
  GR_index_t getNumPrismsInUse() const {return m_ECPrism.size();}
  ///
  GR_index_t getNumHexCells() const {return m_ECHex.lastEntry();}
  GR_index_t getNumHexesInUse() const {return m_ECHex.size();}
  ///
  Face*    getFace(const GR_index_t i) const;
  ///
  BFace* getBFace(const GR_index_t i) const;
  ///
  BFace* getIntBFace(const GR_index_t i) const;
  ///
  Cell*    getCell(const GR_index_t i) const;
  /// Index retrieval
  virtual GR_index_t getFaceIndex(const Face* const pF) const;
  ///
  virtual GR_index_t getBFaceIndex(const BFace* const pBF) const;
  ///
  virtual GR_index_t getCellIndex(const Cell* const pC) const;
#ifdef ITAPS
  ///
  virtual bool isValidEntHandle(void* pvEnt) const;
#endif
  /// Add entries to connectivity tables
  Face*    getNewFace(const int iNV = 3);
  ///
  BFace* getNewBFace(const int iNBV = 3, const bool qIsInternal = false);
  ///
  Cell*    getNewCell(const int iNF = 4, const int iNV = 4);
  ///
  Cell*    getNewCell(const Cell* const pC); // Returned cell has
						  // same type and
						  // data as old one. 
  /// New topology modifiers, a la ITAPS
  virtual Face* createFace(Vert * const /*apV*/[], const int /*iNVerts*/)
  {return pFInvalidFace;}
  virtual BFace* createBFace(Face * const pF,
			     BFace * const pBF = pBFInvalidBFace);
/*   virtual Cell* createCell(Face * const /\* apF *\/[], const int /\* iNFaces *\/, */
/* 			   const int /\* iReg = iDefaultRegion *\/) */
/*   {return pCInvalidCell;} */
/*   virtual Cell* createCell(Vert * const /\* apV *\/[], const int /\* iNVerts *\/, */
/* 			   const int /\* iReg = iDefaultRegion *\/) */
/*   {return pCInvalidCell;} */

  Vert* createVert(const double dX, const double dY, const double dZ);
  Vert* createVert(const double adCoords[]);
  Vert* createVert(const Vert* pVIn);
  Face* createFace(bool &qExistedAlready, Vert * const pVA, Vert * const pVB,
		   Vert * const pVC, Vert * const pVD = pVInvalidVert,
		   bool qForceDuplicate = false);
  TetCell* createTetCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 const int iRegion = iDefaultRegion);
  /// The following version should only be used if the correct vertex
  /// ordering isn't known in advance.
  TetCell* createTetCell(bool &qExistedAlready,
			 Vert * const pV, Face * const pF,
			 const int iRegion = iDefaultRegion);
  TetCell* createTetCell(bool &qExistedAlready,
			 Face * const pFA, Face * const pFB,
			 Face * const pFC, Face * const pFD,
			 const int iRegion = iDefaultRegion);
  Cell* createCell(Vert * const vert, Face * const face,
                     const int region)
  {
    assert(face->getType() == Face::eTriFace);
    bool temp;
    return createTetCell(temp, vert, face, region);
  }

  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom.
  PyrCell* createPyrCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE,
			 const int iRegion = iDefaultRegion);
  // Faces are: tris in cyclic order, then quad.  Verts, if given, are
  // the verts in the same order as above.  See implementation for a
  // sketch.
  PyrCell* createPyrCell(bool &qExistedAlready,
			 Face* const pF014, Face* const pF124,
			 Face* const pF234, Face* const pF304,
			 Face* const pF0123,
			 const int iRegion = iDefaultRegion,
			 Vert * pVA = pVInvalidVert, 
			 Vert * pVB = pVInvalidVert,
			 Vert * pVC = pVInvalidVert, 
			 Vert * pVD = pVInvalidVert,
			 Vert * pVE = pVInvalidVert);
  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom, out for top.
  PrismCell* createPrismCell(bool &qExistedAlready,
			     Vert * const pVA, Vert * const pVB,
			     Vert * const pVC, Vert * const pVD,
			     Vert * const pVE, Vert * const pVF,
			     const int iRegion = iDefaultRegion);
  // Faces are: quads in cyclic order, bottom tri, top tri. Verts, if
  // given, are the verts in the same order as above. 
  PrismCell* createPrismCell(bool &qExistedAlready,
			     Face * const pFA, Face * const pFB,
			     Face * const pFC, Face * const pFD,
			     Face * const pFE,
			     const int iRegion = iDefaultRegion,
			     Vert * pVA = pVInvalidVert, 
			     Vert * pVB = pVInvalidVert,
			     Vert * pVC = pVInvalidVert, 
			     Vert * pVD = pVInvalidVert,
			     Vert * pVE = pVInvalidVert, 
			     Vert * pVF = pVInvalidVert);
  // Vertex order: cyclic around bottom, then top.  RH normal points in
  // for bottom, out for top.
  HexCell* createHexCell(bool &qExistedAlready,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE, Vert * const pVF,
			 Vert * const pVG, Vert * const pVH,
			 const int iRegion = iDefaultRegion);
  // Faces are: sides in cyclic order, bottom, top. Verts, if
  // given, are the verts in the same order as above. 
  HexCell* createHexCell(bool &qExistedAlready,
			 Face* const pFA, Face* const pFB, 
			 Face* const pFC, Face* const pFD, 
			 Face* const pFE, Face* const pFF, 
			 const int iRegion = iDefaultRegion,
			 Vert * pVA = pVInvalidVert, 
			 Vert * pVB = pVInvalidVert,
			 Vert * pVC = pVInvalidVert, 
			 Vert * pVD = pVInvalidVert,
			 Vert * pVE = pVInvalidVert, 
			 Vert * pVF = pVInvalidVert,
			 Vert * pVG = pVInvalidVert, 
			 Vert * pVH = pVInvalidVert);

/*   Cell* createCell(bool &qExistedAlready, */
/* 		   Face * const pFA, Face * const pFB, Face * const pFC, */
/* 		   Face * const pFD, Face * const pFE, */
/* 		   const int iRegion = iDefaultRegion); */
  
  bool deleteVert(Vert * const pV);
  bool deleteFace(Face * const pF);
  bool deleteBFace(BFace * const pBF);
  bool deleteCell(Cell * const pC);

  /// Clean up connectivity tables
  void purgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  ///
  void purgeBdryFaces(std::map<BFace*, BFace*>* bface_map = NULL);
  ///
  void purgeFaces(std::map<Face*, Face*>* face_map = NULL);
  ///
  void purgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  ///
  void purgeAllEntities(std::map<Vert*, Vert*>*   vert_map  = NULL,
	      std::map<Face*, Face*>*   face_map  = NULL,
	      std::map<Cell*, Cell*>*   cell_map  = NULL,
	      std::map<BFace*, BFace*>* bface_map = NULL);

/*   /// Ensure that the correct number of verts exist */
/*   void vSetupVerts(const int i, */
/* 		   const bool qExact = false) {ECVerts.vSetup(i, qExact);} */
  ///
  void assignInitialLengthScales(double dRes, double dAlpha);
protected:
  virtual void reorderVerts_RCM(void);
  virtual void reorderCells(void);
  virtual void reorderFaces(void);
public:
  /// perimeter area:
  double calcBoundarySize() const;
  /// interior volume:
  double calcInteriorSize() const;
  ///
  bool isWatertight() const;
  ///
  bool isMeshOrientationOK(const bool qFix = true);
/// Conversion to/from simplicial form
  ///
  void makeSimplicial() {
    assert(getNumCells() == getNumTetCells());
    m_simplexMesh = true;
  }

 public:

  /// Validity checking
  bool isValid() const;

  //Added by SG 2007/06/28. A substitute to WatsonInfo class.
  struct WatsonData {

    std::set<Cell*> cells_to_remove;
    std::set<Face*> faces_to_remove;
    std::set<Face*> hull_faces;
    std::set<BFace*> encroached_bfaces;
  
    WatsonData() 
      : cells_to_remove(), faces_to_remove(), 
	hull_faces(), encroached_bfaces() {}

    void clear_containers() {

      cells_to_remove.clear();
      faces_to_remove.clear();
      hull_faces.clear();
      encroached_bfaces.clear();

    }

  };

  //Computes Watson insertion data using adaptive predicates.
  void computeWatsonData_deprecated(const Vert* const vertex,
			   const Cell* const seed_cell,
			   WatsonData& watson_data,
			   const bool test_bdry_for_encroachment = true,
			   const bool exit_on_encroached_bdry    = true) const;
  ///Addendum end.

  void insertWatsonInterior_deprecated(Vert* const pVNew,
			     const std::set<Cell*>& spCToRemove,
			     const std::set<Face*>& spFToRemove,
			     const std::set<Face*>& spFHull,
			     std::vector<Cell*>* const new_cells = NULL);

  void insertWatsonBoundary_deprecated(Vert* const pVNew,
			     std::set<Cell*>& spCToRemove,
			     std::set<Face*>& spFToRemove,
			     std::set<Face*>& spFHull,
			     const std::set<BFace*>& spBFEncroached,
			     std::vector<Cell*>* const new_cells = NULL,
			     std::vector<BFace*>* const new_bfaces = NULL);

  ///// *** The following calls were added by SG 08/2008. *** ///// 
  
  //The two public methods are designed to be called for the TetMeshRefiner
  //class. The functions accomplish a task similar to the previously existing
  //Watson insertion calls (and are somewhat their genetically modified clones).
  //They require more info as input, but this allows them to deal a wider range of 
  //domain's topology; dangling curves and surfaces are now supported for instance.
  //They also use Shewchuk's adaptive precision predicates.
 
 private:
 
  void stripCavity_deprecated( Vert* const pVNew,
                     const std::set<Cell*>& cells_to_remove,
		     const std::set<Face*>& faces_to_remove,
		     const std::set<BFace*>* bfaces_to_remove = NULL );

  void reconnectCavity_deprecated( Vert* const new_vert,
			 const std::map<Face*, int>& faces_of_hull,
			 std::vector<Cell*>*  new_cells,
			 std::vector<BFace*>* new_bfaces,
			 std::set<TetRefinerEdge>* edges_with_bface = NULL,
			 bool insert_on_subsegment = false );

  void postCheckCavity_deprecated( const std::vector<Cell*>& new_cells );

 public:

  void insertWatsonInterior_deprecated( Vert* const new_vert,
			       const std::set<Cell*>& cells_to_remove,
			       const std::set<Face*>& faces_to_remove,
			       const std::map<Face*, int>& faces_of_hull,
			       std::vector<Cell*>* const new_cells = NULL );


  void insertWatsonBoundary_deprecated( Vert* const new_vert,
			       std::set<Cell*>&  cells_to_remove,
			       std::set<Face*>&  faces_to_remove,
			       std::set<BFace*>& bfaces_to_remove,
			       std::map<Face*, int>& faces_of_hull,
			       std::set<TetRefinerEdge>& edges_with_bface,
			       bool insert_on_subsegment,
			       std::vector<Cell*>*  const new_cells  = NULL,
			       std::vector<BFace*>* const new_bfaces = NULL);

  ///// *** Addendum by SG 08/2008 stops here *** /////

  // Bdry encroachment check.
  virtual int queueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF) const;
  virtual int queueEncroachedBdryEntities(InsertionQueue& IQ,
					   const std::set<BFace*>& spBF,
					   const double adLoc[],
					   const double dOffset = 0) const;
public:
  int insertPointWatson_deprecated(WatsonInfo_deprecated& WI);
  void cleanupWatson_deprecated(WatsonInfo_deprecated& WI);
  // The worst shape quality measure allowed.
  virtual double getWorstAllowedCellShape() const
    {
      switch (m_encroachType) {
      case eBall:
	return sqrt(0.09375); // sqrt(3) sqrt(2) / 8
      case eLens:
	return sqrt(0.1875);  // sqrt(3) / 4
      case eNewLens:
	return sqrt(0.375);   // sqrt(3) sqrt(2) / 4
	// The mythical best-case scenario would be to use sqrt(3) / 2,
	// because then slivers would be impossible.
      default:
	assert(0);
	return 1;
      }
    }
  bool insertPointWatson_deprecated(const double adPoint[], Cell* const pCSeed);
  bool insertPointWatson_deprecated(Vert* const pVNew, Cell* const pCSeed);
  virtual bool deleteInteriorPointsInBall(const Cell *pCSeed,
					   const double adLoc[],
					   const double dRadius,
					   int& iNDeleted);
  virtual void getWatsonData_deprecated(const double adPoint[3],
			      Cell* const pCSeed,
			      std::set<Cell*>& spCSearch,
			      std::set<Face*>& spFHull,
			      std::set<Face*>& spFToRemove,
			      std::set<BFace*>& spBFEncroached) const;
// Mesh optimization routines
/// Sliver fix
public:
  int repairBadCells(bool qAllowInsertion = false);
  ///
  int breakBadBdryCells(bool qAllowInsertion = false);
  ///
  int splitLargeAngle(Cell *pC,
                       const double dSplitAngle,
		       const double * const adDihed = 0,
		       const bool qOnlyInterior = false);
// // Mesh coarsening routines
public:
  void protectSmallAngles();
  ///
 private:
  virtual bool qDoSwap(const Vert* const pVVertA,
		       const Vert* const pVVertB,
		       const Vert* const pVVertC,
		       const Vert* const pVVertD,
		       const Vert* const pVVertE) const;

 public:
  // This call is deprecated; don't use it in new code.  It's still used
  // in a couple of places, but those are slated for change: coarsening,
  // aniso refinement in 2D, and the STL mesher.
  virtual int iSwap_deprecated(const int iMaxPasses = 2,
			       const bool qAlreadyMarked = false);
  ///
  int iFaceSwap_deprecated(Face*& pF);
  ///
  bool areSurfaceEdgeChangesAllowed() const {return m_OKToSwapSurfaceEdges;}
  ///
  void allowSurfaceEdgeChanges(const double dMaxAngle = 0)
    {
      assert(dMaxAngle >= 0 && dMaxAngle < 180.);
      m_OKToSwapSurfaceEdges = true;
      m_maxAngleForSurfSwap = dMaxAngle;
    }
  ///
  double getMaxAngleForSurfaceEdgeChanges() const {return m_maxAngleForSurfSwap;}
  ///
  void disallowSurfaceEdgeChanges() {m_OKToSwapSurfaceEdges = false;}
  ///
  bool isStrictPatchCheckingUsed() const {return m_strictPatchChecking;}
  ///
  void useStrictPatchChecking() {m_strictPatchChecking = true;}
  ///
  void useLenientPatchChecking() {m_strictPatchChecking = false;}
  virtual GR_index_t getNumBdryPatches() {return m_Bdry3D->iNumPatches();}
  ///
  bool areBdryFacesOKToSwap(const TriBFaceBase * const pBF0,
			  const TriBFaceBase * const pBF1) const;
  ///
  bool isEdgeSwappingAllowed() const {return m_doEdgeSwaps;}
  ///
  void allowEdgeSwapping() {m_doEdgeSwaps = true;}
  ///
  void disallowEdgeSwapping() {m_doEdgeSwaps = false;}

  ///
  void refineToLengthScale(const bool qSameSize,
			    const int iMaxPasses = 40);
  ///
  virtual bool removeVert(Vert * const pV, int& iNewSwaps)
  { return removeVertByContraction(pV, iNewSwaps); }
  virtual bool removeVertByContraction(Vert * const pV, int& iNewSwaps,
			   Vert * apVPreferred[] = NULL,
			   const int iNPref = 0);
  /// The following routine was an 1100 line monstrosity that was never
  //  used.  
  //  virtual bool qRemoveVertByRemeshing(Vert * const pV, int& iNewSwaps);
  ///
  virtual void identifyVertexTypesGeometrically() const;
  virtual double getCoarseningConstant() const {return 0.36;}
  ///
  bool makeDelaunay();
  ///
  int reconfigure_deprecated(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int reconfTet23_deprecated(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int reconfTet32_deprecated(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int reconfTet22_deprecated(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int reconfTet44_deprecated(TetCell* apTCTets[], TriFace* const pFFace,
		   Vert* const pVVertA, Vert* const pVVertB,
		   Vert* const pVVertC, Vert* const pVVertD,
		   Vert* const pVVertE);
  ///
  int edgeSwap3D(Face* const pF, Vert* pVNorth,
		  Vert* pVSouth, Vert* const pVOther,
		  const bool qAllowAnyValid = false,
		  const Vert* const pVWant0 = pVInvalidVert,
		  const Vert* const pVWant1 = pVInvalidVert);
  ///
  int bdryEdgeSwap3D(Face* const pF, Vert* pVNorth,
                      Vert* pVSouth, Vert* const pVOther);
private:
  double evalQualFunc(Vert* const pV0, Vert* const pV1,
		   Vert* const pV2, Vert* const pV3) const;
 public:
  // Boundary recovery routines
  void recoverConstrainedSurface(SurfMesh& SM, const int iNumOrigVerts,
				  const int iNumBBoxVerts = 8);
  void markCleanNeighbors(Cell* pC);
  int recoverFace(const int iVerts[3],
		   int * const piPointsInserted = NULL,
		   const bool qAllowEdgeSwap = true,
		   const int iRecurDepth = 0);
  int recoverEdge(const Vert* const pV0,
		   const Vert* const pV1,
		   const bool qInsertionOK = false);
  int recoverEdge(const Vert* const pV0,
		   const Vert* const pV1,
		   SurfMesh& SM,
		   const bool qInsertionOK = false);
  void splitEdge(const Vert* const pV0,
		  const Vert* const pV1,
		  SurfMesh& SM);
  // Find the cell incident on pV0 that covers the ray towards pV1 (may be
  // a multiple choice question if pV0 and pV1 are adjacent, or if there
  // is a face containing one but not the other and coplanar with both. 
  Cell* beginPipe(const Vert* const pV0, const Vert* const pV1) const;
  int clearPipe(const Vert* const pVInit,
		const Vert* const pVEnd,
		bool& qHitEdge, Face* apFSkipped[], int& iNSkip);
  void deleteExternal(const SurfMesh* pSM, const int iNumOrigVerts,
		       const int iNumBBoxVerts = 8);
  void identifyBadEdgesAndFaces(const Vert* const pV0,
				 const Vert* const pV1,
				 const Vert* const pV2,
				 std::set<BadEdge>& sBEBadEdges,
				 std::set<Face*>& spFBadFaces);
public:
  /// Mesh quality assessment
  void classifyTets() const;
  ///
  friend class VolQual;

public:
  /// Iterator functions
  EntContainer<TriFace>::iterator triFace_begin() const
  { return m_ECTriF.begin(); }
  EntContainer<TriFace>::iterator triFace_end() const
  { return m_ECTriF.end(); }


};

// Check to see whether a VolMesh correctly conforms to a surface mesh.
bool isBdryConstrained(VolMesh* pVM, SurfMesh* pSM, 
			std::set<ConstrainEdge>& sCESubSegs,
			std::set<ConstrainEdge>& sCEInFacets,
			std::set<ConstrainFace>& sCFSubFacets);


void readUGridBinary(const char * const fileName, VolMesh * const pVM);
void readVGridBinary(const char * const fileName, VolMesh * const pVM);
void readVTK_ASCII(const char * const fileName, VolMesh * const pVM);

void writeVTK_ASCII(VolMesh& OutMesh,
		     const char strBaseFileName[]);

/** Unlikely ever to be called by user code. */
void writeFile_VolMesh(VolMesh & Mesh,
		        const char strBaseFileName[],
		        const char strExtraFileSuffix[] = "");

void writeFile_PWM(VolMesh & Mesh,
		    const char strBaseFileName[],
		    const char strExtraFileSuffix[] = "");

///
void readFile_VolMesh(const char * const strBaseFileName,
		       GR_index_t& iNumVerts,
		       GR_index_t& iNumFaces,
		       GR_index_t& iNumCells,
		       GR_index_t& iNumBdryFaces,
                       GR_index_t& iNumIntBdryFaces,
		       bool& qFaceVert,
		       bool& qCellVert,
		       bool& qFaceCell,
		       bool& qCellFace,
		       bool& qCellRegion,
		       bool& qBFaceFace,
		       bool& qBFaceVert,
		       bool& qBFaceBC,
		       bool& qIntBFaceFace,
		       bool& qIntBFaceVert,
                       bool& qIntBFaceBC,
		       EntContainer<Vert>& EC,
		       GR_index_t (*&a2iFaceVert)[3],
		       GR_sindex_t (*&a2iFaceCell)[2],
		       GR_index_t (*&a2iCellVert)[4],
		       GR_index_t (*&a2iCellFace)[4],
		       int *&aiCellRegion,
		       GR_index_t *&aiBFaceFace,
		       int *&aiBFaceBC,
		       GR_index_t (*&a2iBFaceVert)[3],
                       GR_index_t (*&a2iIntBFaceFace)[2],
                       int *&aiIntBFaceBC,
                       GR_index_t (*&a2iIntBFaceVert)[3]);

void repairBadCells(VolMesh* pVM);
void recoverSurface(VolMesh* const pVM, SurfMesh* const pSM);
#endif
