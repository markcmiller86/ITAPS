#ifndef DREFFACEARRAY_HPP
#define DREFFACEARRAY_HPP
 
#include "DynamicArray.hpp"
 
class RefFace;
 
DynamicArrayDeclare(DRefFaceArray,RefFace*)
 
#endif

