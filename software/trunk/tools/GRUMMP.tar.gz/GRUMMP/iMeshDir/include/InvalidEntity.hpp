#ifndef INVALIDENTITY_HPP
#define INVALIDENTITY_HPP

class InvalidEntity
{ public: virtual ~InvalidEntity() {} };
#endif

