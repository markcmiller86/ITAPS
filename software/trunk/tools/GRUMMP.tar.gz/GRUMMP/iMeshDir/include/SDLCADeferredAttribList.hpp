#ifndef SDL_DEFERREDATTRIB_LIST_HPP
#define SDL_DEFERREDATTRIB_LIST_HPP

#include "SDLList.hpp"
#include "CADeferredAttrib.hpp"

SDLListdeclare(SDLCADeferredAttribList, CADeferredAttrib*, unique_id, int)

#endif 

