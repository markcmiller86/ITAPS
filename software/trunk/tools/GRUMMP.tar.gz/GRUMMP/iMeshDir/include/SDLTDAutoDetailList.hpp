#ifndef SDL_TDAUTODETAIL_LIST_HPP
#define SDL_TDAUTODETAIL_LIST_HPP

#include "SDLList.hpp"
#include "TDAutoDetail.hpp"

SDLListdeclare(SDLTDAutoDetailList, TDAutoDetail*, entity_measure, double)

#endif 

