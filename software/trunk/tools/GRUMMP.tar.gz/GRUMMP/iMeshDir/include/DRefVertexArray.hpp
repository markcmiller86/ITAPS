#ifndef DREFVERTEXARRAY_HPP
#define DREFVERTEXARRAY_HPP
 
#include "DynamicArray.hpp"
 
class RefVertex;
 
DynamicArrayDeclare(DRefVertexArray,RefVertex*)
 
#endif

