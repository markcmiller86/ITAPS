#ifndef DMREFFACEARRAY_HPP
#define DMREFFACEARRAY_HPP
 
#include "DynamicArray.hpp"
 
class MRefFace;
 
DynamicArrayDeclare(DMRefFaceArray,MRefFace*)
 
#endif

