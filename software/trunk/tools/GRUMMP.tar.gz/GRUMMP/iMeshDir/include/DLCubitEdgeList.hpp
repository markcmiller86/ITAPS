#ifndef DLCUBITEDGELIST_HPP
#define DLCUBITEDGELIST_HPP

#include "DLList.hpp"

class CubitEdge;

DLListdeclare(DLCubitEdgeList,CubitEdge*)

#endif 

