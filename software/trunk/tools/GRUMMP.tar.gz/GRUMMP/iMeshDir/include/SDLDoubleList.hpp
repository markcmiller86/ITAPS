#ifndef SDL_DOUBLE_LIST_HPP
#define SDL_DOUBLE_LIST_HPP

#include "SDLList.hpp"
#include "DoubleListItem.hpp"

SDLListdeclare(SDLDoubleList, DoubleListItem*, double_value, double)

#endif 

