/* Title: LocalStart.hpp
 * Description: Start position for a local surface search
 * Checked By: */

#ifndef LOCAL_START_HPP
#define LOCAL_START_HPP

typedef int LocalStart;

#endif

