#ifndef DLCUBITFACELIST_HPP
#define DLCUBITFACELIST_HPP

#include "DLList.hpp"

class CubitFace;

DLListdeclare(DLCubitFaceList,CubitFace*)

#endif 

