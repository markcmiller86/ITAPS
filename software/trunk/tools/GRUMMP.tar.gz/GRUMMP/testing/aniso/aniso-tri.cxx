#include <unistd.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "GR_config.h"
#include "GR_AdaptPred.h"
#include "GR_Bdry2D.h"
#include "GR_InsertionQueue.h"
#include "GR_Mesh2D.h"
#include "GR_Quality.h"
#include "GR_events.h"
#include "GR_misc.h"

#include "OptMS.h"

static void vUsageTri()
{
  logMessage(0, "Usage:  tri -i basefilename [options] \n");
  logMessage(0, "   -i          Base file name for boundary geometry input file\n");
  logMessage(0, "   -A          Use adaptive precision geometric predicates\n");
  logMessage(0, "   -b #        Allow boundary insertion (1 for true, 0 for false)\n");
  logMessage(0, "   -g #        Multiplier for length scale (grading; larger is slower) [1]\n");
  logMessage(0, "   -q #        Quality measure; see below [2]\n");
  logMessage(0, "   -r #        Multiplier for length scale (resolution; larger is finer) [1]\n");
  logMessage(0, "\nThe following options are only valid when using Ruppert's scheme (default)\n\n");
  logMessage(0, "   -c [01]     Use diametral lenses instead of diametral circles [0]\n");
  logMessage(0, "               This will push the minimum angle to 30 degrees (instead of 20)\n");
  
  logMessage(0, "Choices for quality measure to produce histogram of:\n\n");
  logMessage(0, " 0  Maximum angle\n");
  logMessage(0, " 1  Minimum angle\n");
  logMessage(0, " 2  All angles\n");
  logMessage(0, " 6  Aspect ratio I (inscribed to circum radius)\n");
  logMessage(0, " 9  Aspect ratio II (based on area versus perimeter)\n");
  logMessage(0, "10  Aspect ratio III (shortest edge to circumradius)\n\n");
  exit(1);
}

static void vUsageOther(const char strCanonName[])
{
  logMessage(0, "Usage:  %s -i basefilename [options] \n", strCanonName);
  logMessage(0, "   -i          Base file name for mesh input file\n");
  logMessage(0, "   -A          Use adaptive precision geometric predicates\n");
  logMessage(0, "   -b #        Allow boundary insertion (1 for true, 0 for false)\n");
  logMessage(0, "   -q #        Quality measure; see below [2]\n");
  logMessage(0, "   -r #        Multiplier for length scale [1] (resolution; larger is finer)\n\n");
  logMessage(0, "Choices for quality measure to produce histogram of:\n\n");
  logMessage(0, " 0  Maximum angle\n");
  logMessage(0, " 1  Minimum angle\n");
  logMessage(0, " 2  All angles\n");
  logMessage(0, " 6  Aspect ratio I (inscribed to circum radius)\n");
  logMessage(0, " 9  Aspect ratio II (based on area versus perimeter)\n");
  logMessage(0, "10  Aspect ratio III (shortest edge to circumradius)\n\n");
  exit(1);
}


int main(int iNArg, char *apcArgs[]) {
  extern char *optarg;
  char strBaseFileName[FILE_NAME_LEN], strQualFileName[FILE_NAME_LEN];
  double dScale = 1.;
  double dGrading = 1.;
  bool   qCircleEncroaching = true;

  char strExecName[FILE_NAME_LEN];
  char strCanonicalName[20];
  enum {UNKNOWN, TRI, MESHOPT, COARSEN} iExec = UNKNOWN;

  qAdaptPred = false;

  sprintf(strExecName, "%s", apcArgs[0]);
  if (strstr(strExecName, "coarsen2d")) {
    iExec = COARSEN;
    sprintf(strCanonicalName, "coarsen2d");
  }
  else if (strstr(strExecName, "meshopt2d")) {
    iExec = MESHOPT;
    sprintf(strCanonicalName, "meshopt2d");
  }
  else if (strstr(strExecName, "tri")) {
    iExec = TRI;
    sprintf(strCanonicalName, "tri");
  }
  else {
    vFatalError("Invalid executable name.  Be less creative renaming files.\n",
		"tri.cxx:main()");
  }
  
  GRUMMPInit(strCanonicalName);
  
  int iQualMeasure = 2;
  bool qAllowBdryChanges = true;

  int iPChar, iError = 1;
  while ((iPChar = getopt(iNArg, apcArgs, "Ab:c:g:i:q:R:r:")) != EOF) {
    switch (iPChar) {
    case 'A':
      qAdaptPred = true;
      break;
    case 'b':
      qAllowBdryChanges = (optarg[0] == '1');
      break;
    case 'c':
      qCircleEncroaching = ! (optarg[0] == '1');
      break;
    case 'g':
      sscanf(optarg, "%lf", &dGrading);
      if (dGrading < 1) dGrading = 1;
      break;
    case 'i':
      (void) strncpy(strBaseFileName, optarg, FILE_NAME_LEN-1);
      {
	int iDum;
	for (iDum = 0; iDum < FILE_NAME_LEN && strBaseFileName[iDum];
	     iDum++);
	if (iDum == FILE_NAME_LEN) // No null; file name too long
	  vFatalError("File name too long", "command line");
      }
      iError--;
      break;
    case 'q':
      {
	int iTmp;
	sscanf(optarg, "%d", &iTmp);
	if (iTmp == 0 || iTmp == 1 || iTmp == 2 || iTmp == 6 || iTmp == 9
	    || iTmp == 10)
	  iQualMeasure = iTmp;
	break;
      }
    case 'r':
      sscanf(optarg, "%lf", &dScale);
      break;
    default:
      iError += 10;
      break;
    }
  }
  if (iError)
    if (iExec == TRI)
      vUsageTri();
    else
      vUsageOther(strCanonicalName);

    // File name manipulation
  makeFileName(strQualFileName, "%s.qual",
		strBaseFileName, "main() [tri.C]");  

  // Open input and log files
  openMessageFile(strBaseFileName);
  logMessage(1, "Mesh quality output file: %s\n", strQualFileName);

  if (iExec == MESHOPT) dScale /= sqrt(2);

  Mesh2D *pM2D;
  // Read and validate 2D mesh
  if (iExec == TRI) {
    // Reading a bdry file and creating a mesh from that
    Bdry2D B2D(strBaseFileName, false);
    pM2D = new Mesh2D(B2D);
    pM2D->initLengthScale(1.0/dScale, 1.0/dGrading);
    
    logMessage(2, "Number of verts in initial triangulation:  %d\n",
	     pM2D->iNumVerts());
    logMessage(1, "Number of triangles in initial triangulation:  %d\n",
	     pM2D->getNumCells());
  }
  else { // coarsen2d or meshopt2d
    // Reading an existing mesh file
    pM2D = new Mesh2D(strBaseFileName);
    logMessage(1, "Number of cells read: %d\n", pM2D->getNumCells());
  }
  assert(pM2D->isValid());

//   Quality Qual(pM2D, iQualMeasure);
//   Qual.vEvaluate();

  if (qAllowBdryChanges)
    pM2D->allowBdryChanges();
  else
    pM2D->disallowBdryChanges();    
      
  double dThresholdAngle = 30;
  int iNumPasses = 0;
  switch (iExec) {
  case MESHOPT:
  case TRI:
    {
      pM2D->checkForSmallAngles();
      
      pM2D->initLengthScale(1.0/dScale, 1.0/dGrading);
      pM2D->setLSChecking(true);
      
      //  	pM2D->vCheckForLargeAngles();
      //  	pM2D->qRuppert(0);
      
      {
	int aiBC[] = {1};
	pM2D->generateAnisotropic(1, aiBC, dScale, dGrading);
      }
//       InsertionQueue IQ(pM2D);
//       IQ.vQualityRefine();
	
//       Qual.vEvaluate();
      pM2D->setSwapType(eMaxDihed);
      pM2D->iSwap_deprecated();
      // Smoothing parameters for later
      dThresholdAngle = 40;
      iNumPasses = 0;
    }
    logMessage(1,"Number of triangles after refinement:  %d\n",
	     pM2D->getNumCells());
    break;
  case COARSEN:
    pM2D->initLengthScale(1.0/dScale, 1.0/dGrading);
    pM2D->coarsen();
    logMessage(1, "Number of cells after coarsening: %d\n", pM2D->getNumCells());
      
    pM2D->setSwapType(eDelaunay);
    pM2D->iSwap_deprecated();
    //    Qual.vEvaluate();

    dThresholdAngle = 30;
    iNumPasses = 5;
    break;
  default:
    assert(0);
    break;
  }

  if (iNumPasses > 0) {
    // Do some smoothing if requested
    void *pvSmoothData;
    SMinitSmoothing(2, 'f', OPTMS_DEFAULT, -1, &pvSmoothData);
    logMessage(1, "Smoothing vertices...\n");
    for (int ii = iNumPasses - 1; ii >= 0; ii--) {
      logMessage(2, "Pass %d of %d...\n", iNumPasses - ii - 1, iNumPasses);
      SMsetSmoothThreshold(pvSmoothData,dThresholdAngle);
      SMinitGlobalMinValue(pvSmoothData);
      pM2D->iSmooth(1);
      if ((ii+1)%3 == 0) {
	// After a few smoothing passes, try swapping to see if that
	// helps any.
	pM2D->iSwap_deprecated();
      }
      // This next is a special value so that the Threshold will be set
      // automatically using the data from the last pass. 
      dThresholdAngle = 0;
    }
    SMfinalizeSmoothing(pvSmoothData);
//     Qual.vEvaluate();
  }
  
    // Quality output
//   Qual.vWriteToFile(strQualFileName);
  
  // pM2D->vReorderVerts_RCM();
  // pM2D->vReorderCells();
  // Mesh output
  logMessage(1,"Writing mesh to file(s)...\n");
  if (iExec == TRI)
    writeFile_Mesh2D(*pM2D, strBaseFileName);
  else
    writeFile_Mesh2D(*pM2D, strBaseFileName, ".out");
  logMessage(1,"Done\n");

  pM2D->checkEdgeLengths();

  if (pM2D != NULL)
    delete pM2D;
  
  return (0);
}
