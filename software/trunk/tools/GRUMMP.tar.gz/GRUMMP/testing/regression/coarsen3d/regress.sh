#!/bin/sh

THIS_DIR=`pwd`
REGRESS_DIR=`dirname ${THIS_DIR}`
TESTING_DIR=`dirname ${REGRESS_DIR}`
GRUMMP_DIR=`dirname ${TESTING_DIR}`

COARSEN="/home/cfog/GRUMMP/branches/0.4-series/src/programs/coarsen3d"
COARSEN_COMMAND="${COARSEN} -a 25"
COARSEN_INPUTS="cube-clip case2_inv"
INPUT_EXT=vmesh
OUTPUT_EXT=vmesh.out

declare -i PASSED FAILED
PASSED=0
FAILED=0

if (test $# -eq 1 -a "$1" = "--setup"); then
  echo "Setting up regression test data for coarsen..."
  echo "   coarsen executable is ${COARSEN}, dynamically linked to:"
  ldd ${COARSEN}
  echo 

  for i in ${COARSEN_INPUTS}; do
    echo -n Setting up data for $i.${INPUT_EXT}...
    cp inputs/$i.${INPUT_EXT}.gz .
    gunzip $i.${INPUT_EXT}.gz
    ${COARSEN_COMMAND} -i $i > $i.output
    head -1 $i.${OUTPUT_EXT} > data/$i.size
    head -12 $i.qual | tail -1 > data/$i.final-qual
    rm -f $i.*
    echo done.
  done
else
  echo "Usage: regress [--setup]"
fi
