#include <stdlib.h>
#include <stdio.h>

#define SUCCESS 0
#define OVERFLOW 1
#define COPY_FAILED 2
#define MESHING_FAILED 3
#define FILE_IO_ERROR 4
#define SMALLEST_ANGLE_BETTER 8
#define LARGEST_ANGLE_BETTER 16
#define SIZE_DECREASED 32
#define SIZE_INCREASED 64
#define SMALLEST_ANGLE_WORSE 128
#define LARGEST_ANGLE_WORSE 256

#define CHECK_OVERFLOW(a) \
  if (a == -1) {\
    fprintf(stderr, "Buffer overflow!\n");\
    return OVERFLOW;\
  }

#define CHECK_FILE(a) \
  if (a == NULL) {\
    fprintf(stderr, "File I/O error!\n");\
    return FILE_IO_ERROR;\
  }

static int iRunCase(const char strExec[], const char strOptions[],
		     const char strInput[])
{
  int iRetVal = SUCCESS, i;
  char strCopy[1024], strCommand[1024];

  i = snprintf(strCopy, 1024, "cp inputs/%s.vmesh.gz . ; gunzip %s.vmesh.gz",
	       strInput, strInput);
  CHECK_OVERFLOW(i);
    
  i = snprintf(strCommand, 1024, "%s %s -i %s > /dev/null",
	       strExec, strOptions, strInput);
  CHECK_OVERFLOW(i);
    
  i = system(strCopy);
  if (i != 0) {
    fprintf(stderr, "Copy of input file failed!\n");
    return COPY_FAILED;
  }

  i = system(strCommand);
  if (i != 0) {
    fprintf(stderr, "Mesh coarsening failed!\n");
    return MESHING_FAILED;
  }

  /* Now compare cell counts. */
  {
    FILE *pFNew, *pFRef;
    char strNewMeshFile[1024], strRefMeshFile[1024];
    int iNewCells, iRefCells;

    i = snprintf(strNewMeshFile, 1024, "%s.vmesh.out", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefMeshFile, 1024, "data/%s.size", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewMeshFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefMeshFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFNew, "%d", &iNewCells);
    fscanf(pFRef, "%d", &iRefCells);

    close(pFNew);
    close(pFRef);

    if (iNewCells > iRefCells*1.05)
      iRetVal += SIZE_INCREASED;
    else if (iNewCells < iRefCells*0.95)
      iRetVal += SIZE_DECREASED;
  }

  /* Now compare mesh quality. */
  {
    FILE *pFNew, *pFRef;
    char strNewQualFile[1024], strRefQualFile[1024];
    float fNewMin, fNewMax, fRefMin, fRefMax;

    i = snprintf(strNewQualFile, 1024, "%s.qual", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefQualFile, 1024, "data/%s.final-qual", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewQualFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefQualFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFRef, "%*s %*d %f %f", &fRefMin, &fRefMax);

    /* Throw away eleven lines. */
    for (i = 0; i < 11; i++) {
      char strBuffer[1024];
      fgets(strBuffer, 1024, pFNew);
    }
    fscanf(pFNew, "%*s %*d %f %f", &fNewMin, &fNewMax);

    close(pFNew);
    close(pFRef);

    if (fRefMin > fNewMin + 0.05)
      iRetVal += SMALLEST_ANGLE_WORSE;
    else if (fRefMin < fNewMin - 0.05)
      iRetVal += SMALLEST_ANGLE_BETTER;
    if (fRefMax < fNewMax - 0.05)
      iRetVal += LARGEST_ANGLE_WORSE;
    if (fRefMax > fNewMax + 0.05)
      iRetVal += LARGEST_ANGLE_BETTER;
  }

  /* Now clean up new files. */
  i = snprintf(strCommand, 1024, "rm %s.*", strInput);
  CHECK_OVERFLOW(i);

  i = system(strCommand);

  return iRetVal;
}

static const int iNumCases = 2;
static char astrNames[][32] = {
  "cube-clip",
  "case2_inv"
  };

int main() {
  int i, iRetVal;
  int iSuccess = 0, iBiggerMesh = 0, iWorseQuality = 0, iFailed = 0;
  int iSmallerMesh = 0, iBetterQuality = 0;
  for (i = 0; i < iNumCases; i++) {
    fprintf(stderr, "Running regression test for input file %s...",
	   astrNames[i]);
    fflush(stderr);
    iRetVal = iRunCase("/home/cfog/GRUMMP/trunk/src/programs/coarsen3d",
		       "-a 25", astrNames[i]);
    if (iRetVal == 0) {
      iSuccess++;
      fprintf(stderr, "passed");
    }
    else if (iRetVal > 0 && iRetVal < SIZE_DECREASED) {
      fprintf(stderr, "failed with code %d\n", iRetVal);
      iFailed++;
    }
    else if (iRetVal < SIZE_INCREASED) {
      fprintf(stderr, "passed");
      if (iRetVal & SIZE_DECREASED) {
	iSmallerMesh++;
	fprintf(stderr, "smaller mesh...");
      }
      if (iRetVal & (SMALLEST_ANGLE_BETTER | LARGEST_ANGLE_BETTER)) {
	iBetterQuality++;
	if (iRetVal & SMALLEST_ANGLE_BETTER) {
	  fprintf(stderr, "smallest angle better...");
	}
	if (iRetVal & LARGEST_ANGLE_BETTER) {
	  fprintf(stderr, "largest angle better...");
	}
      }
    }
    else {
      if (iRetVal & SIZE_INCREASED) {
	iBiggerMesh++;
	fprintf(stderr, "bigger mesh...");
      }
      if (iRetVal & (SMALLEST_ANGLE_WORSE | LARGEST_ANGLE_WORSE)) {
	iWorseQuality++;
	if (iRetVal & SMALLEST_ANGLE_WORSE) {
	  fprintf(stderr, "smallest angle worse...");
	}
	if (iRetVal & LARGEST_ANGLE_WORSE) {
	  fprintf(stderr, "largest angle worse...");
	}
      }
    }
    fprintf(stderr, "\n");
  }
  fprintf(stderr, "\nTested a total of %d input files\n", iNumCases);
  fprintf(stderr, "Of these, %3d successfully generated coarse meshes.\n",
	  iNumCases - iFailed);
  fprintf(stderr, "          %3d passed regression\n", iSuccess);
  fprintf(stderr, "          %3d generated smaller meshes\n", iSmallerMesh);
  fprintf(stderr, "          %3d produced better-quality meshes\n",
	  iBetterQuality);
  fprintf(stderr, "          %3d generated larger meshes\n", iBiggerMesh);
  fprintf(stderr, "          %3d produced worse-quality meshes\n",
	  iWorseQuality);
  fprintf(stderr, "%3d failed entirely\n", iFailed);
}
