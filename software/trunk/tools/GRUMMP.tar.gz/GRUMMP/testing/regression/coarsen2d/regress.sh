#!/bin/sh

THIS_DIR=`pwd`
REGRESS_DIR=`dirname ${THIS_DIR}`
TESTING_DIR=`dirname ${REGRESS_DIR}`
GRUMMP_DIR=`dirname ${TESTING_DIR}`

COARSEN="/home/cfog/GRUMMP/branches/0.4-series/src/programs/coarsen2d"
COARSEN_COMMAND="${COARSEN}"
COARSEN_INPUTS="af4-spline branch scram"
COARSEN_INPUT_DIR="${GRUMMP_DIR}/examples/2D"
INPUT_EXT=mesh
OUTPUT_EXT=mesh.out

declare -i PASSED FAILED
PASSED=0
FAILED=0

if (test $# -eq 1 -a "$1" = "--setup"); then
  echo "Setting up regression test data for coarsen..."
  echo "   coarsen executable is ${COARSEN}, dynamically linked to:"
  ldd ${COARSEN}
  echo 

  for i in ${COARSEN_INPUTS}; do
    echo -n Setting up data for $i.${INPUT_EXT}...
    cp inputs/$i.${INPUT_EXT} .
    ${COARSEN_COMMAND} -i $i > $i.output
    head -1 $i.${OUTPUT_EXT} > data/$i.size
    head -6 $i.qual | tail -1 > data/$i.final-qual
    rm -f $i.*
    echo done.
  done
else
  echo "Usage: regress [--setup]"
fi
