#!/bin/sh

THIS_DIR=`pwd`
REGRESS_DIR=`dirname ${THIS_DIR}`
TESTING_DIR=`dirname ${REGRESS_DIR}`
GRUMMP_DIR=`dirname ${TESTING_DIR}`

TRI="${GRUMMP_DIR}/src/programs/tri"
TRI_COMMAND="${TRI} -r 4 -g 4"
TRI_INPUTS="0012 0012-spline 6IMR.test2 6IMR.test af4 af4-spline annulus anslab-round blob branch circle cubicbezier curvestar cyl destruct easyspline face front-step hexagon longarc mapleleaf-circle multi-region nozzle periodic-square periodic-wedge plate-hole quad saddle scram sector shortarc square square-circhole-arcside square-circhole-bezier square-hole"
TRI_INPUT_DIR="${GRUMMP_DIR}/examples/2D"
INPUT_EXT=bdry
OUTPUT_EXT=mesh

declare -i PASSED FAILED
PASSED=0
FAILED=0

if (test $# -eq 0); then
  echo "Running regression tests for tri..."
  echo "   tri executable is ${TRI}, dynamically linked to:"
  ldd ${TRI}
  echo 

  for i in ${TRI_INPUTS}; do
    echo -n Testing $i.${INPUT_EXT}...
    cp ${TRI_INPUT_DIR}/$i.${INPUT_EXT} .
    ${TRI_COMMAND} -i $i > $i.output
    if (test $? -eq 0); then 
      head -1 $i.${OUTPUT_EXT} > $i.tmp
      diff $i.tmp data/$i.size
      if (test $? -eq 0); then
        head -6 $i.qual | tail -1 > $i.tmp
        diff $i.tmp data/$i.final-qual
        if (test $? -eq 0); then
	  echo passed.
          PASSED=${PASSED}+1
        else
	  echo failed.
          FAILED=${FAILED}+1
        fi
      else 
        echo failed.
        FAILED=${FAILED}+1
      fi
    else
      # tri didn't exit cleanly
      echo failed.
      FAILED=${FAILED}+1
    fi
    rm -f $i.*
  done
  echo Passed ${PASSED} tests.
  echo Failed ${FAILED} tests.
else
  if (test $# -eq 1 -a "$1" = "--setup"); then
    echo "Setting up regression test data for tri..."
    echo "   tri executable is ${TRI}, dynamically linked to:"
    ldd ${TRI}
    echo 

    for i in ${TRI_INPUTS}; do
      echo -n Setting up data for $i.${INPUT_EXT}...
      cp ${TRI_INPUT_DIR}/$i.${INPUT_EXT} .
      ${TRI_COMMAND} -i $i > $i.output
      head -1 $i.${OUTPUT_EXT} > data/$i.size
      head -6 $i.qual | tail -1 > data/$i.final-qual
      rm -f $i.*
      echo done.
    done
  else
    echo "Usage: regress [--setup]"
  fi
fi
