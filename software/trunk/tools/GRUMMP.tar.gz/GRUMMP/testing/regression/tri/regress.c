#include <stdlib.h>
#include <stdio.h>

#define SUCCESS 0
#define OVERFLOW 1
#define COPY_FAILED 2
#define MESHING_FAILED 3
#define FILE_IO_ERROR 4
#define SIZE_INCREASED 8
#define SMALLEST_ANGLE_WORSE 16
#define LARGEST_ANGLE_WORSE 32

#define CHECK_OVERFLOW(a) \
  if (a == -1) {\
    fprintf(stderr, "Buffer overflow!\n");\
    return OVERFLOW;\
  }

#define CHECK_FILE(a) \
  if (a == NULL) {\
    fprintf(stderr, "File I/O error!\n");\
    return FILE_IO_ERROR;\
  }

static int iNumRan = 0, iNumPassed = 0, iNumFailed = 0;

static int qPerformanceBaseline = 0;

static int iRunCase(const char strExec[], const char strOptions[],
		     const char strInput[], const char strInputPath[])
{
  int iRetVal = SUCCESS, i;
  char strCopy[1024], strCommand[1024];

  i = snprintf(strCopy, 1024, "cp %s/%s.bdry .", strInputPath, strInput);
  CHECK_OVERFLOW(i);
    
  i = snprintf(strCommand, 1024, "%s %s -i %s > %s.out",
		     strExec, strOptions, strInput, strInput);
  CHECK_OVERFLOW(i);
    
  i = system(strCopy);
  if (i != 0) {
    fprintf(stderr, "Copy of input file failed!\n");
    return COPY_FAILED;
  }

  i = system(strCommand);
  if (i != 0) {
    fprintf(stderr, "Meshing failed!\n");
    return MESHING_FAILED;
  }

  /* Now compare cell counts. */
  {
    FILE *pFNew, *pFRef;
    char strNewMeshFile[1024], strRefMeshFile[1024];
    int iNewCells, iRefCells;

    i = snprintf(strNewMeshFile, 1024, "%s.mesh", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefMeshFile, 1024, "data/%s.size", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewMeshFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefMeshFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFNew, "%d", &iNewCells);
    fscanf(pFRef, "%d", &iRefCells);

    close(pFNew);
    close(pFRef);

    if (iNewCells > iRefCells*1.05)
      iRetVal += SIZE_INCREASED;
  }

  /* Now compare mesh quality. */
  {
    FILE *pFNew, *pFRef;
    char strNewQualFile[1024], strRefQualFile[1024];
    float fNewMin, fNewMax, fRefMin, fRefMax;

    i = snprintf(strNewQualFile, 1024, "%s.qual", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefQualFile, 1024, "data/%s.final-qual", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewQualFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefQualFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFRef, "%*s %*d %f %f", &fRefMin, &fRefMax);

    /* Throw away five lines. */
    for (i = 0; i < 5; i++) {
      char strBuffer[1024];
      fgets(strBuffer, 1024, pFNew);
    }
    fscanf(pFNew, "%*s %*d %f %f", &fNewMin, &fNewMax);

    close(pFNew);
    close(pFRef);

    if (fRefMin > fNewMin + 0.05)
      iRetVal += SMALLEST_ANGLE_WORSE;
    if (fRefMax < fNewMax - 0.05)
      iRetVal += LARGEST_ANGLE_WORSE;
  }

  /* If this case is meant to establish a performance baseline, then
     copy the output file. */
  if (qPerformanceBaseline) {
    i = snprintf(strCommand, 1024, "cp %s.out baseline", strInput);
    CHECK_OVERFLOW(i);
    i = system(strCommand);
  }

  /* Now clean up new files. */
  i = snprintf(strCommand, 1024, "rm %s.*", strInput);
  CHECK_OVERFLOW(i);

  i = system(strCommand);

  return iRetVal;
}

static const int iNumCases = 29;
static char astrNames[][32] = {
  "0012",
  "0012-spline",
  "6IMR.test2",
  "6IMR.test",
  "af4",
  "af4-spline",
  "annulus",
  "anslab-round",
  "branch",
  "circle",
  "cubicbezier",
  "cyl",
  "destruct",
  "easyspline",
  "face",
  "front-step",
  "hexagon",
  "longarc",
  "mapleleaf-circle",
  "nozzle",
  "plate-hole",
  "saddle",
  "scram",
  "sector",
  "shortarc",
  "square",
  "square-circhole-arcside",
  "square-circhole-bezier",
  "square-hole",
  "blob",
  "curvestar",
  "multi-region",
  "periodic-square",
  "periodic-wedge",
  "quad"
  };

int main(int iNArgs, char *apcArgs[]) {
  int i, iRetVal;
  int iSuccess = 0, iBiggerMesh = 0, iWorseQuality = 0, iFailed = 0;
  int status[iNumCases];

  if (iNArgs == 2 && strncmp(apcArgs[1], "-perf", 5) == 0) {
    qPerformanceBaseline = 1;
  }
    
  for (i = 0; i < iNumCases; i++) {
    fprintf(stderr, "Running regression test for input file %s...",
	   astrNames[i]);
    fflush(stderr);
    iRetVal = status[i] 
      = iRunCase("../../../src/programs/tri",
		 "-r 4 -g 4", astrNames[i],
		 "../../../examples/2D");
    if (iRetVal == 0) {
      iSuccess++;
      fprintf(stderr, "passed");
    }
    else if (iRetVal == MESHING_FAILED) {
      iFailed++;
    }
    else if (iRetVal >= SIZE_INCREASED) {
      if (iRetVal & SIZE_INCREASED) {
	iBiggerMesh++;
	fprintf(stderr, "bigger mesh...");
      }
      if (iRetVal & (SMALLEST_ANGLE_WORSE | LARGEST_ANGLE_WORSE)) {
	iWorseQuality++;
	if (iRetVal & SMALLEST_ANGLE_WORSE) {
	  fprintf(stderr, "smallest angle worse...");
	}
	if (iRetVal & LARGEST_ANGLE_WORSE) {
	  fprintf(stderr, "largest angle worse...");
	}
      }
      else {
	fprintf(stderr, "failed with code %d\n", iRetVal);
	iFailed++;
      }
    }
    fprintf(stderr, "\n");
  }
  fprintf(stderr, "\nTested a total of %d input files\n", iNumCases);
  fprintf(stderr, "Of these, %3d successfully generated meshes.\n",
	  iNumCases - iFailed);
  fprintf(stderr, "          %3d passed regression\n", iSuccess);
  fprintf(stderr, "          %3d generated larger meshes\n", iBiggerMesh);
  fprintf(stderr, "          %3d produced worse-quality meshes\n", iWorseQuality);
  fprintf(stderr, "          %3d failed entirely\n\n", iFailed);

  for (i = 0; i < iNumCases; i++) {
    if (status[i] == MESHING_FAILED) {
      fprintf(stderr, "Failed for input file: %s\n", astrNames[i]);
    }
  }
}
