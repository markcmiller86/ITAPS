#!/bin/bash

THIS_DIR=`pwd`
REGRESS_DIR=`dirname ${THIS_DIR}`
TESTING_DIR=`dirname ${REGRESS_DIR}`
GRUMMP_DIR=`dirname ${TESTING_DIR}`

TETRA="${GRUMMP_DIR}/src/programs/tetra"
TETRA_INPUT_DIR="${GRUMMP_DIR}/examples/3D"
OUTPUT_EXT=vmesh

simple_bdry_INPUTS="cube-clip cutout-cube hex-bdry hex-cavity2 hex-cavity hex-dual hex-embed2 hex-embed hex-multi hex-tunnel pyramid seg-split tet3 tet4 tunnel2 tunnel3"

simple_smesh_INPUTS="badprism doorroom faceknife goodprism hex1 hex2 hex3 hex4 hex indpint knife2 knife3 knife normprism octa patho1 pint skinny sliver sphere2 sphere tet2 tet tint2 tint"

contrib_bdry_INPUTS="3dtest-bdry2 3dtest-min circular head2br heng Simple2 Simple3"

contrib_smesh_INPUTS="3dtest1 3dtest2 3dtest aircraftsidewall allfJ ball2 current2 current doorroom2 doubtet mheadR Simple slant test test5 test5a test5b test5c thalam thalam2 tint2hole wagner wagner2"

declare -i PASSED FAILED
PASSED=0
FAILED=0

if (test $# -eq 0); then
  echo "Running regression tests for tetra..."
  echo "   tetra executable is ${TETRA}, dynamically linked to:"
  ldd ${TETRA}
  echo 

  for ext in bdry smesh; do
    for dir in simple contrib; do
      INPUT_LIST=${dir}_${ext}_INPUTS
      for i in ${!INPUT_LIST}; do
	echo -n Testing ${dir}/$i.${ext}...
        cp ${TETRA_INPUT_DIR}/${dir}/$i.${ext} .
        ${TETRA} -i $i > $i.output
	if (test $? -eq 0); then
	    head -1 $i.${OUTPUT_EXT} > $i.tmp
	    diff $i.tmp data/$i.size
	    if (test $? -eq 0); then
		head -6 $i.qual | tail -1 > $i.tmp
		diff $i.tmp data/$i.final-qual
		if (test $? -eq 0); then
		    echo passed.
		    PASSED=${PASSED}+1
		else
		    echo failed.
		    FAILED=${FAILED}+1
		fi
	    else 
		echo failed.
		FAILED=${FAILED}+1
	    fi
	else
	    # tetra didn't exit cleanly
	    echo failed.
	    FAILED=${FAILED}+1
	fi
	rm -f $i.*
      done # Loop over entries in list
    done # Loop over file suffixes
  done # Loop over dirs
  echo Passed ${PASSED} tests.
  echo Failed ${FAILED} tests.
else
  if (test $# -eq 1 -a "$1" = "--setup"); then
    echo "Setting up regression test data for tetra..."
    echo "   tetra executable is ${TETRA}, dynamically linked to:"
    ldd ${TETRA}
    echo 

    for ext in bdry smesh; do
      for dir in simple contrib; do
        INPUT_LIST=${dir}_${ext}_INPUTS
        for i in ${!INPUT_LIST}; do
	  echo -n Setting up data for ${dir}/$i.${ext}...
          cp ${TETRA_INPUT_DIR}/${dir}/$i.${ext} .
          ${TETRA} -i $i > $i.output
          head -1 $i.${OUTPUT_EXT} > data/$i.size
          head -6 $i.qual | tail -1 > data/$i.final-qual
          rm -f $i.*
          echo done.
        done # Loop over entries in list
      done # Loop over file suffixes
    done # Loop over dirs
  else
    echo "Usage: regress [--setup]"
  fi
fi
