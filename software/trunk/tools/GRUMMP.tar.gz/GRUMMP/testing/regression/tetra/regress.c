#include <stdlib.h>
#include <stdio.h>

#define SUCCESS 0
#define OVERFLOW 1
#define COPY_FAILED 2
#define MESHING_FAILED 3
#define FILE_IO_ERROR 4
#define SIZE_INCREASED 8
#define SMALLEST_ANGLE_WORSE 16
#define LARGEST_ANGLE_WORSE 32

#define CHECK_OVERFLOW(a) \
  if (a == -1) {\
    fprintf(stderr, "Buffer overflow!\n");\
    return OVERFLOW;\
  }

#define CHECK_FILE(a) \
  if (a == NULL) {\
    fprintf(stderr, "File I/O error!\n");\
    return FILE_IO_ERROR;\
  }

static int qPerformanceBaseline = 0;

static int iRunCase(const char strExec[], const char strOptions[],
		    const char strInput[], const char strExtension[],
		    const char strInputPath[], const char strEndOfPath[])
{
  int iRetVal = SUCCESS, i;
  char strCopy[1024], strCommand[1024];

  i = snprintf(strCopy, 1024, "cp %s/%s/%s.%s .", strInputPath,
	       strEndOfPath, strInput, strExtension);
  CHECK_OVERFLOW(i);

  i = system(strCopy);
  if (i != 0) {
    fprintf(stderr, "Copy of input file failed!\n");
    return COPY_FAILED;
  }

  i = snprintf(strCommand, 1024, "%s %s -i %s > %s.out",
		     strExec, strOptions, strInput, strInput);
  CHECK_OVERFLOW(i);

  i = system(strCommand);
  if (i != 0) {
    fprintf(stderr, "Meshing failed!\n");
    return MESHING_FAILED;
  }

  /* Now compare cell counts. */
  {
    FILE *pFNew, *pFRef;
    char strNewMeshFile[1024], strRefMeshFile[1024];
    int iNewCells, iRefCells;

    i = snprintf(strNewMeshFile, 1024, "%s.vmesh", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefMeshFile, 1024, "data/%s.size", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewMeshFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefMeshFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFNew, "%d", &iNewCells);
    fscanf(pFRef, "%d", &iRefCells);

    close(pFNew);
    close(pFRef);

    if (iNewCells > iRefCells*1.05)
      iRetVal += SIZE_INCREASED;
  }

  /* Now compare mesh quality. */
  {
    FILE *pFNew, *pFRef;
    char strNewQualFile[1024], strRefQualFile[1024];
    float fNewMin, fNewMax, fRefMin, fRefMax;

    i = snprintf(strNewQualFile, 1024, "%s.qual", strInput);
    CHECK_OVERFLOW(i);

    i = snprintf(strRefQualFile, 1024, "data/%s.final-qual", strInput);
    CHECK_OVERFLOW(i);

    /* Open new and reference mesh files, and read the number of cells. */
    pFNew = fopen(strNewQualFile, "r");
    CHECK_FILE(pFNew);

    pFRef = fopen(strRefQualFile, "r");
    CHECK_FILE(pFRef);

    fscanf(pFRef, "%*s %*d %f %f", &fRefMin, &fRefMax);

    /* Throw away five lines. */
    for (i = 0; i < 5; i++) {
      char strBuffer[1024];
      fgets(strBuffer, 1024, pFNew);
    }
    fscanf(pFNew, "%*s %*d %f %f", &fNewMin, &fNewMax);

    close(pFNew);
    close(pFRef);

    if (fRefMin > fNewMin + 0.05)
      iRetVal += SMALLEST_ANGLE_WORSE;
    if (fRefMax < fNewMax - 0.05)
      iRetVal += LARGEST_ANGLE_WORSE;
  }

  /* If this case is meant to establish a performance baseline, then
     copy the output file. */
  if (qPerformanceBaseline) {
    i = snprintf(strCommand, 1024, "cp %s.out baseline", strInput);
    CHECK_OVERFLOW(i);
    i = system(strCommand);
  }

  /* Now clean up new files. */
  i = snprintf(strCommand, 1024, "rm %s.*", strInput);
  CHECK_OVERFLOW(i);

  i = system(strCommand);

  return iRetVal;
}

static const int iNumSBCases = 16, iNumSSCases = 25, iNumCBCases = 7,
  iNumCSCases = 23;
static char astrSimpleBdry[][32] = {
  "cube-clip", "cutout-cube", "hex-bdry", "hex-cavity2", "hex-cavity",
  "hex-dual", "hex-embed2", "hex-embed", "hex-multi", "hex-tunnel",
  "pyramid", "seg-split", "tet3", "tet4", "tunnel2",
  "tunnel3"};
static char astrSimpleSMesh[][32] = {
  "badprism", "doorroom", "faceknife", "goodprism", "hex1",
  "hex2", "hex3", "hex4", "hex", "indpint",
  "knife2", "knife3", "knife", "normprism", "octa",
  "patho1", "pint", "skinny", "sliver", "sphere2",
  "sphere", "tet2", "tet", "tint2", "tint"};
static char astrContribBdry[][32] = {
  "3dtest-bdry2", "3dtest-min", "circular", "head2br", "heng",
  "Simple2", "Simple3"};
static char astrContribSMesh[][32] = {
  "3dtest1", "3dtest2", "3dtest", "aircraftsidewall", "allfJ",
  "ball2", "current2", "current", "doorroom2", "doubtet",
  "mheadR", "Simple", "slant", "test", "test5",
  "test5a", "test5b", "test5c", "thalam", "thalam2",
  "tint2hole", "wagner", "wagner2"};

static void vRunCollection(const char strEndOfPath[],
			   char astrInputs[][32],
			   const char strExtension[],
			   const int iNumCases,
			   int * const piSuccess,
			   int * const piBiggerMesh,
			   int * const piWorseQuality,
			   int * const piFailed)
{
  int i, iRetVal;
  for (i = 0; i < iNumCases; i++) {
    fprintf(stderr, "Running regression test for input file %s...",
	   astrInputs[i]);
    fflush(stderr);
    iRetVal = iRunCase("/home/cfog/GRUMMP/trunk/src/programs/tetra",
		       "", astrInputs[i], strExtension,
		       "/home/cfog/GRUMMP/trunk/examples/3D",
		       strEndOfPath);
    if (iRetVal == 0) {
      (*piSuccess)++;
      fprintf(stderr, "passed");
    }
    else if (iRetVal >= SIZE_INCREASED) {
      if (iRetVal & SIZE_INCREASED) {
	(*piBiggerMesh)++;
	fprintf(stderr, "bigger mesh...");
      }
      if (iRetVal & (SMALLEST_ANGLE_WORSE | LARGEST_ANGLE_WORSE)) {
	(*piWorseQuality)++;
	if (iRetVal & SMALLEST_ANGLE_WORSE) {
	  fprintf(stderr, "smallest angle worse...");
	}
	if (iRetVal & LARGEST_ANGLE_WORSE) {
	  fprintf(stderr, "largest angle worse...");
	}
      }
    }
    else {
      fprintf(stderr, "failed with code %d\n", iRetVal);
      (*piFailed)++;
    }
    fprintf(stderr, "\n");
  }
}

int main(int iNArgs, char *apcArgs[]) {
  int iSuccess = 0, iBiggerMesh = 0, iWorseQuality = 0, iFailed = 0;
  int iNumCases = 0;

  if (iNArgs == 2 && strncmp(apcArgs[1], "-perf", 5) == 0) {
    qPerformanceBaseline = 1;
  }
    

  vRunCollection("simple", astrSimpleBdry, "bdry", iNumSBCases,
		 &iSuccess, &iBiggerMesh, &iWorseQuality, &iFailed);
  vRunCollection("simple", astrSimpleSMesh, "smesh", iNumSSCases,
		 &iSuccess, &iBiggerMesh, &iWorseQuality, &iFailed);
  vRunCollection("contrib", astrContribBdry, "bdry", iNumCBCases,
		 &iSuccess, &iBiggerMesh, &iWorseQuality, &iFailed);
  vRunCollection("contrib", astrContribSMesh, "smesh", iNumCSCases,
		 &iSuccess, &iBiggerMesh, &iWorseQuality, &iFailed);
  iNumCases = iNumSBCases + iNumSSCases + iNumCBCases + iNumCSCases;

  fprintf(stderr, "\nTested a total of %d input files\n", iNumCases);
  fprintf(stderr, "Of these, %3d successfully generated meshes.\n",
	  iNumCases - iFailed);
  fprintf(stderr, "          %3d passed regression\n", iSuccess);
  fprintf(stderr, "          %3d generated larger meshes\n", iBiggerMesh);
  fprintf(stderr, "          %3d produced worse-quality meshes\n", iWorseQuality);
  fprintf(stderr, "%3d failed entirely\n", iFailed);
}
