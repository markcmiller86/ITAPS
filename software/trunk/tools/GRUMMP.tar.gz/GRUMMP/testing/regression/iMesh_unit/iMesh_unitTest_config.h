/* iMesh_unitTest_config.h.  Generated from iMesh_unitTest_config.h.in by configure.  */
/* iMesh_unitTest_config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "cfog@mech.ubc.ca"

/* Define to the full name of this package. */
#define PACKAGE_NAME "iMesh Unit Test"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "iMesh Unit Test 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "imesh-unit-test"

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to empty if `const' does not conform to ANSI C. */
/* #undef const */

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif
