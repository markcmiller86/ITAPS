#include "GR_config.h"
#include "GR_misc.h"
#include "GR_GRCurveGeom.h"
#include "CubitDefines.h"
#include "CubitVector.hpp"
#include "CubitBox.hpp"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <cstdlib>

using std::cout;
using std::endl;

static int iPass = 0, iFail = 0;

#define TEST(a) ((a) ? iPass++ : \
		 (cout << endl << "Line " << __LINE__ << ": Failed " << #a << endl, iFail++))
#define TEST_EQUAL(a, b) (TEST((a) == (b)))
#define TEST_FLOAT_EQUAL(a, b) (TEST(iFuzzyComp((a), (b)) == 0))
#define TEST_LESS(a, b) (TEST((a)-(b)) < 0)
#define TEST_SUMMARY \
  cout << "Passed " << iPass << " tests." << endl; \
  cout << "Failed " << iFail << " tests." << endl; \
  return(iFail)

//Test function declarations:

void vTestTriDiag();
void vTestSolveQuadratic();
void vTestSolveCubic();
void vTestGRLine();
void vTestGRArc();
void vTestGRCubic();
void vTestGRBezier();
void vTestGRInterp();

int main() {

  vTestTriDiag();
  vTestSolveQuadratic();
  vTestSolveCubic();
  vTestGRLine();
  vTestGRArc();
  vTestGRCubic();
  vTestGRBezier();
  vTestGRInterp();

  cout << "*****" << endl;
  TEST_SUMMARY;

  return(0);

}

void vTestTriDiag() {

  //////////////////////////////////
  //Testing the tridiagonal solver//
  //////////////////////////////////

  cout << "Testing the tridiagonal solver... ";

  double** a2dLHS = new double* [5];
  for(int i = 0; i < 5; i++) {
    a2dLHS[i] = new double[3];
  }
  double* adRHS = new double[5];
  
  for(int i = 0; i < 5; i++) {
    a2dLHS[i][0] = static_cast<double>(i);
    a2dLHS[i][1] = static_cast<double>(i + 2);
    a2dLHS[i][2] = static_cast<double>(i + 1);
    adRHS[i] = static_cast<double>(i);
  }

  solveTriDiag(a2dLHS, adRHS, 3);
  TEST_FLOAT_EQUAL(adRHS[0], -0.41176470588235);
  TEST_FLOAT_EQUAL(adRHS[1], 0.82352941176471);
  TEST_FLOAT_EQUAL(adRHS[2], -0.52941176470588);
  TEST_FLOAT_EQUAL(adRHS[3], 0.82352941176471);
  TEST_FLOAT_EQUAL(adRHS[4], 0.11764705882353);

  delete[] adRHS;
  for(int i = 0; i < 5; i++) {
    delete [] a2dLHS[i];
  }
  delete[] a2dLHS;

  cout << "done." << endl;

}

void vTestSolveQuadratic() {

  /////////////////////////////////////////
  //Testing the quadratic equation solver//
  /////////////////////////////////////////

  cout << "Testing the quadratic equation solver... ";

  double dA, dB, dC, dRoot1, dRoot2;
  int iNRoots;
  
  //dA and dB equal to 0. No root should be found.
  dA = dB = 0.;
  dC = 10.;
  solveQuadratic(dA, dB, dC, &iNRoots, &dRoot1, &dRoot2);
  TEST_EQUAL(iNRoots, 0);

  //dA = 0, solution to a linear equation.
  dA = 0.;
  dB = 1.;
  dC = 1.5;
  solveQuadratic(dA, dB, dC, &iNRoots, &dRoot1, &dRoot2);
  TEST_EQUAL(iNRoots, 1);
  TEST_FLOAT_EQUAL(dRoot1, -1.5);

  //Coefficients are such that quadratic equation does not have any real roots.
  dA = 4.;
  dB = 3.;
  dC = 1.;
  solveQuadratic(dA, dB, dC, &iNRoots, &dRoot1, &dRoot2);
  TEST_EQUAL(iNRoots, 0);

  //Coefficients are such that quadratic equation has only one root.
  dA = 4.;
  dB = 4.;
  dC = 1.;
  solveQuadratic(dA, dB, dC, &iNRoots, &dRoot1, &dRoot2);
  TEST_EQUAL(iNRoots, 1);
  TEST_FLOAT_EQUAL(dRoot1, -0.5);
  
  //Coefficients are such that quadratic equation has two real roots.
  dA = 1.;
  dB = 4.;
  dC = -2.25;
  solveQuadratic(dA, dB, dC, &iNRoots, &dRoot1, &dRoot2);
  TEST_EQUAL(iNRoots, 2);
  TEST_FLOAT_EQUAL(dRoot1, 0.5);
  TEST_FLOAT_EQUAL(dRoot2, -9./2.);
   
  cout << "done." << endl;

}

void vTestSolveCubic() {

  /////////////////////////////////////
  //Testing the cubic equation solver//
  /////////////////////////////////////
  
  cout << "Testing the cubic equation solver... ";

  double dA, dB, dC, dD;
  double adRoots[3];
  int iNRoots;
  
  //dA, dB and dC are equal to 0. No root should be found.
  dA = dB = dC = 0.;
  dD = 10.;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 0);

  //dA and dB are equal to 0. Solution to linear equation.
  dA = dB = 0.;
  dC = 5.;
  dD = 10.;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 1);
  TEST_FLOAT_EQUAL(adRoots[0], -2.);

  //dA = 0. Solution to a quadratic equation.
  dA = 0.;
  dB = 1.;
  dC = 4.;
  dD = -2.25;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 2);
  TEST_FLOAT_EQUAL(adRoots[0], 0.5);
  TEST_FLOAT_EQUAL(adRoots[1], -9./2.);

  //Coefficients are such that cubic equation has three different real roots.
  dA = 2.;
  dB = -4.;
  dC = -22.;
  dD = 24.;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 3);
  TEST_FLOAT_EQUAL(adRoots[0], 4.);
  TEST_FLOAT_EQUAL(adRoots[1], -3.);
  TEST_FLOAT_EQUAL(adRoots[2], 1.);

  //Coefficients are such that cubic equation has three equal real roots.
  dA = 1.;
  dB = 6.;
  dC = 12.;
  dD = 8.;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 3);
  TEST_FLOAT_EQUAL(adRoots[0], -2.);
  TEST_FLOAT_EQUAL(adRoots[1], -2.);
  TEST_FLOAT_EQUAL(adRoots[2], -2.);
 
  //Coefficients are such that cubic equation has only one real roots.
  dA = 3.;
  dB = -10.;
  dC = 14.;
  dD = 27.;
  solveCubic(dA, dB, dC, dD, &iNRoots, adRoots);
  TEST_EQUAL(iNRoots, 1);
  TEST_FLOAT_EQUAL(adRoots[0], -1.);

  cout << "done." << endl;

}


void vTestGRLine() {

  ////////////////////////////
  //Testing the GRLine class//
  ////////////////////////////

  cout << "Testing the GRLine class... ";

  CubitVector V1(0., 0., 0.);
  CubitVector V2(1., -2., 0.);
 
  GRLine* line = new GRLine(V1, V2);

  //Testing basic access function.
  TEST_EQUAL(line->topo_dim(), 1);
  TEST_EQUAL(line->geom_dim(), 2);
  TEST_EQUAL(line->get_curve_type(), GRCurveGeom::LINE);

  //Testing min and max param
  TEST_FLOAT_EQUAL(line->min_param(), 0.);
  TEST_FLOAT_EQUAL(line->max_param(), 1.);

  //Testing the bounding box
  CubitBox box = line->bounding_box();
  CubitVector mini = box.minimum();
  CubitVector maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 0.);
  TEST_FLOAT_EQUAL(mini.y(), -2.);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 1.);
  TEST_FLOAT_EQUAL(maxi.y(), 0.);
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  //Testing function returning parameter at coordinate.
  CubitVector coord(0.5, -1., 0.);
  double length = sqrt(0.5 * 0.5 + 1.);
  TEST_FLOAT_EQUAL(line->param_at_coord(coord), 0.5);
  TEST_FLOAT_EQUAL(line->param_at_arc_length(0., length), 0.5);

  //Testing function returning coord at parameter.
  line->coord_at_param(0.75, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.75);
  TEST_FLOAT_EQUAL(coord.y(), -2. * 0.75);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  //Testing function returning coord at distance.
  line->coord_at_dist(length, true, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.5);
  TEST_FLOAT_EQUAL(coord.y(), -1.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);
  line->coord_at_dist(length, false, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.5);
  TEST_FLOAT_EQUAL(coord.y(), -1.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  //Testing funtion returning coord at middle distance between points.
  line->coord_at_mid_dist(line->min_param(), line->max_param(), coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.5);
  TEST_FLOAT_EQUAL(coord.y(), -1.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);
  CubitVector coord1;
  CubitVector coord2;
  line->coord_at_param(line->min_param(), coord1);
  line->coord_at_param(line->max_param(), coord2);
  line->coord_at_mid_dist(coord1, coord2, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.5);
  TEST_FLOAT_EQUAL(coord.y(), -1.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  //Testing function returning closest point on curve.
  coord.set(5., -10., 0.);
  CubitVector closest;
  line->closest_coord_on_curve(coord, closest);
  TEST_FLOAT_EQUAL(closest.x(), 1.);
  TEST_FLOAT_EQUAL(closest.y(), -2.);
  TEST_FLOAT_EQUAL(closest.z(), 0.);
  line->closest_coord_on_curve(coord, closest, line->min_param(), 0.9);
  line->coord_at_param(0.9, coord1);
  TEST_FLOAT_EQUAL(closest.x(), coord1.x());
  TEST_FLOAT_EQUAL(closest.y(), coord1.y());
  TEST_FLOAT_EQUAL(closest.z(), 0.);

  coord.set(-5., 10., 0.);
  line->closest_coord_on_curve(coord, closest);
  TEST_FLOAT_EQUAL(closest.x(), 0.);
  TEST_FLOAT_EQUAL(closest.y(), 0.);
  TEST_FLOAT_EQUAL(closest.z(), 0.);
  line->closest_coord_on_curve(coord, closest, 0.1, line->max_param());
  line->coord_at_param(0.1, coord1);
  TEST_FLOAT_EQUAL(closest.x(), coord1.x());
  TEST_FLOAT_EQUAL(closest.y(), coord1.y());
  TEST_FLOAT_EQUAL(closest.z(), 0.);

  coord.set(0.5, -1., 0.);
  line->closest_coord_on_curve(coord, closest);
  TEST_FLOAT_EQUAL(closest.x(), 0.5);
  TEST_FLOAT_EQUAL(closest.y(), -1.);
  TEST_FLOAT_EQUAL(closest.z(), 0.);
  
  coord.set(-0.39442719099992, -1.44721359549996, 0.);
  line->closest_coord_on_curve(coord, closest);
  TEST_FLOAT_EQUAL(closest.x(), 0.5);
  TEST_FLOAT_EQUAL(closest.y(), -1.);
  TEST_FLOAT_EQUAL(closest.z(), 0.);
  TEST_FLOAT_EQUAL(line->closest_param_on_curve(coord), 0.5);

  //Testing function that verify if a coord is on the curve.
  TEST_FLOAT_EQUAL(line->coord_on_curve(closest), 1.);
 
  //Testing function that calculate first and second derivative with respect to param.
  CubitVector FD, SD;

  line->first_deriv(closest, FD);
  TEST_FLOAT_EQUAL(FD.x(), 1.);
  TEST_FLOAT_EQUAL(FD.y(), -2.);
  TEST_FLOAT_EQUAL(FD.z(), 0.);
  line->first_deriv(0.5, FD);
  TEST_FLOAT_EQUAL(FD.x(), 1.);
  TEST_FLOAT_EQUAL(FD.y(), -2.);
  TEST_FLOAT_EQUAL(FD.z(), 0.);

  line->second_deriv(closest, SD);
  TEST_FLOAT_EQUAL(SD.x(), 0.);
  TEST_FLOAT_EQUAL(SD.y(), 0.);
  TEST_FLOAT_EQUAL(SD.z(), 0.);
  line->second_deriv(0.5, SD);
  TEST_FLOAT_EQUAL(SD.x(), 0.);
  TEST_FLOAT_EQUAL(SD.y(), 0.);
  TEST_FLOAT_EQUAL(SD.z(), 0.);

  //Testing curvature query function
  TEST_FLOAT_EQUAL(line->curvature(0.5), 0.);
  TEST_FLOAT_EQUAL(line->curvature(closest), 0.);

  //Testing unit normal
  line->unit_normal(closest, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.89442719099992);
  TEST_FLOAT_EQUAL(coord.y(), 0.44721359549996);
  TEST_FLOAT_EQUAL(coord.z(), 0.);
  line->unit_normal(0.5, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.89442719099992);
  TEST_FLOAT_EQUAL(coord.y(), 0.44721359549996);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  //Testing unit tangent
  line->unit_tangent(closest, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.44721359549996);
  TEST_FLOAT_EQUAL(coord.y(), -0.89442719099992);
  TEST_FLOAT_EQUAL(coord.z(), 0.);
  line->unit_tangent(0.5, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.44721359549996);
  TEST_FLOAT_EQUAL(coord.y(), -0.89442719099992);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  //Testing arc length measurement.
  TEST_FLOAT_EQUAL(line->arc_length(), 2.23606797749979);
  coord.set(0.25, -0.5, 0.);
  closest.set(0.75, -1.5, 0.);
  TEST_FLOAT_EQUAL(line->arc_length(coord, closest), 1.11803398874989);
  TEST_FLOAT_EQUAL(line->arc_length(0.25, 0.75), 1.11803398874989);

  line->center_point(coord1);
  TEST_FLOAT_EQUAL(coord1.x(), 0.5);
  TEST_FLOAT_EQUAL(coord1.y(), -1);
  TEST_FLOAT_EQUAL(coord1.z(), 0.);
  coord1.set(-10, -10, 10);
  line->center_point(line->min_param(), line->max_param(), coord1);
  TEST_FLOAT_EQUAL(coord1.x(), 0.5);
  TEST_FLOAT_EQUAL(coord1.y(), -1);
  TEST_FLOAT_EQUAL(coord1.z(), 0.);
  coord1.set(-10, -10, 10);
  line->center_point(V1, V2, coord1);
  TEST_FLOAT_EQUAL(coord1.x(), 0.5);
  TEST_FLOAT_EQUAL(coord1.y(), -1);
  TEST_FLOAT_EQUAL(coord1.z(), 0.);

  //Testing total variation of the tangent
  TEST_FLOAT_EQUAL(line->TVT(), 0.);
  TEST_FLOAT_EQUAL(line->TVT(coord, closest), 0.);
  TEST_FLOAT_EQUAL(line->TVT(0.25, 0.5), 0.);

  TEST_FLOAT_EQUAL(line->mid_TVT(0.2, 0.4), 0.3);
  TEST_FLOAT_EQUAL(line->mid_TVT(V1, V2), 0.5);
    
  //Testing coord access functions.
  TEST_FLOAT_EQUAL(line->X(0), 0.);
  TEST_FLOAT_EQUAL(line->X(1), 1.);
  TEST_FLOAT_EQUAL(line->Y(0), 0.);
  TEST_FLOAT_EQUAL(line->Y(1), -2.);
  TEST_FLOAT_EQUAL(line->Z(0), 0.);
  TEST_FLOAT_EQUAL(line->Z(1), 0.);

  line->get_coord(0, coord);
  TEST_FLOAT_EQUAL(coord.x(), 0.);
  TEST_FLOAT_EQUAL(coord.y(), 0.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);
  line->get_coord(1, coord);
  TEST_FLOAT_EQUAL(coord.x(), 1.);
  TEST_FLOAT_EQUAL(coord.y(), -2.);
  TEST_FLOAT_EQUAL(coord.z(), 0.);

  TEST_FLOAT_EQUAL(line->get_coord(0).x(), 0.);
  TEST_FLOAT_EQUAL(line->get_coord(0).y(), 0.);
  TEST_FLOAT_EQUAL(line->get_coord(0).z(), 0.);
  TEST_FLOAT_EQUAL(line->get_coord(1).x(), 1.);
  TEST_FLOAT_EQUAL(line->get_coord(1).y(), -2.);
  TEST_FLOAT_EQUAL(line->get_coord(1).z(), 0.);
  
  //Testing functions to set points.
  line->set_X(0, 1.);
  line->set_Y(0, 2.);
  line->set_X(1, 3.);
  line->set_Y(1, 4.);
  TEST_FLOAT_EQUAL(line->X(0), 1.);
  TEST_FLOAT_EQUAL(line->X(1), 3.);
  TEST_FLOAT_EQUAL(line->Y(0), 2.);
  TEST_FLOAT_EQUAL(line->Y(1), 4.);
  TEST_FLOAT_EQUAL(line->Z(0), 0.);
  TEST_FLOAT_EQUAL(line->Z(1), 0.);
  
  line->set_coord(0, V1);
  line->set_coord(1, V2);
  TEST_FLOAT_EQUAL(line->X(0), 0.);
  TEST_FLOAT_EQUAL(line->X(1), 1.);
  TEST_FLOAT_EQUAL(line->Y(0), 0.);
  TEST_FLOAT_EQUAL(line->Y(1), -2.);
  TEST_FLOAT_EQUAL(line->Z(0), 0.);
  TEST_FLOAT_EQUAL(line->Z(1), 0.);
  
  //Testing copy constructor and operator=
  GRLine* new_line = new GRLine(*line);
  GRLine other_line = *line;

  TEST_FLOAT_EQUAL(new_line->X(0), 0.);
  TEST_FLOAT_EQUAL(new_line->X(1), 1.);
  TEST_FLOAT_EQUAL(new_line->Y(0), 0.);
  TEST_FLOAT_EQUAL(new_line->Y(1), -2.);
  TEST_FLOAT_EQUAL(new_line->Z(0), 0.);
  TEST_FLOAT_EQUAL(new_line->Z(1), 0.);
  TEST_FLOAT_EQUAL(other_line.X(0), 0.);
  TEST_FLOAT_EQUAL(other_line.X(1), 1.);
  TEST_FLOAT_EQUAL(other_line.Y(0), 0.);
  TEST_FLOAT_EQUAL(other_line.Y(1), -2.);
  TEST_FLOAT_EQUAL(other_line.Z(0), 0.);
  TEST_FLOAT_EQUAL(other_line.Z(1), 0.);
  
  delete line;
  delete new_line;

  cout << "done." << endl;

}


void vTestGRArc() {

  ///////////////////////////
  //Testing the GRArc class//
  ///////////////////////////

  cout << "Testing the GRArc class... ";

  CubitVector v1(1., 1., 0.);
  CubitVector v2(1. + 0.5 * sqrt(3.), 1.5, 0.);
  CubitVector v3(1.5, 1. + 0.5 * sqrt(3.), 0.);

  GRArc* arc1  = new GRArc(v1, v2, v3);
  GRArc* arc1r = new GRArc(v2, v3, 1., true);

  v2.set(1., 0., 0.);
  
  GRArc* arc2  = new GRArc(v1, v2, v3);
  GRArc* arc2r = new GRArc(v2, v3, 1., true);

  v2.set(1 + 0.5 * sqrt(3.), 1.5, 0.);
  v3.set(1., 0., 0.);

  GRArc* arc3  = new GRArc(v1, v2, v3);
  GRArc* arc3r = new GRArc(v2, v3, 1., false);

  v2.set(1., 0., 0.);
  v3.set(0., 1., 0.);

  GRArc* arc4  = new GRArc(v1, v2, v3);
  GRArc* arc4r = new GRArc(v2, v3, 1., false);

  //Basic queries.
  TEST_EQUAL(arc1->topo_dim(), 1);
  TEST_EQUAL(arc1r->topo_dim(), 1);
  TEST_EQUAL(arc1->geom_dim(), 2);
  TEST_EQUAL(arc1r->geom_dim(), 2);
  TEST_EQUAL(arc1->get_curve_type(), GRCurveGeom::ARC);
  TEST_EQUAL(arc1r->get_curve_type(), GRCurveGeom::ARC);

  //Testing the bounding box.
  CubitBox box = arc1->bounding_box();
  CubitVector mini = box.minimum();
  CubitVector maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 1.5);
  TEST_FLOAT_EQUAL(mini.y(), 1.5);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 1. + 0.5 * sqrt(3.));
  TEST_FLOAT_EQUAL(maxi.y(), 1. + 0.5 * sqrt(3.));
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  box = arc2->bounding_box();
  mini = box.minimum();
  maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 1.);
  TEST_FLOAT_EQUAL(mini.y(), 0.);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 2.);
  TEST_FLOAT_EQUAL(maxi.y(), 1. + 0.5 * sqrt(3.));
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  box = arc3->bounding_box();
  mini = box.minimum();
  maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 0.);
  TEST_FLOAT_EQUAL(mini.y(), 0.);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 1. + 0.5 * sqrt(3.));
  TEST_FLOAT_EQUAL(maxi.y(), 2.);
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  //Testing dParamAtCoord
  v1.set(1. + cos(0.25 * M_PI), 1. + sin(0.25 * M_PI), 0.);
  v2.set(1. + 0.5 * sqrt(3.), 1.5, 0.);
  v3.set(1.5, 1. + 0.5 * sqrt(3), 0.);

  TEST_FLOAT_EQUAL(arc1->param_at_coord(v1), 0.5);
  TEST_FLOAT_EQUAL(arc1r->param_at_coord(v1), 0.5);
  TEST_FLOAT_EQUAL(arc1->param_at_coord(v2), 0.);
  TEST_FLOAT_EQUAL(arc1r->param_at_coord(v2), 0.);
  TEST_FLOAT_EQUAL(arc1->param_at_coord(v3), 1.);
  TEST_FLOAT_EQUAL(arc1r->param_at_coord(v3), 1.);

  v1.set(1. + cos(0.25 * 7. * M_PI), 1. + sin(0.25 * 7. * M_PI), 0.);
  v2.set(1. + cos(0.25 * M_PI), 1. + sin(0.25 * M_PI), 0.);

  TEST_FLOAT_EQUAL(arc2->param_at_coord(v1), 0.3);
  TEST_FLOAT_EQUAL(arc2r->param_at_coord(v1), 0.3);
  TEST_FLOAT_EQUAL(arc2->param_at_coord(v2), 0.9);
  TEST_FLOAT_EQUAL(arc2r->param_at_coord(v2), 0.9);

  TEST_FLOAT_EQUAL(arc3->param_at_coord(v2), 0.0625);
  TEST_FLOAT_EQUAL(arc3r->param_at_coord(v2), 0.0625);

  TEST_FLOAT_EQUAL(arc4->param_at_coord(v1), 1. / 6.);
  TEST_FLOAT_EQUAL(arc4r->param_at_coord(v1), 1. / 6.);
  TEST_FLOAT_EQUAL(arc4->param_at_coord(v2), 0.5);
  TEST_FLOAT_EQUAL(arc4r->param_at_coord(v2), 0.5);
 
  //Testing param at given arc length
  TEST_FLOAT_EQUAL(arc2->param_at_arc_length(arc2->min_param(), M_PI/6.), 0.2);
  TEST_FLOAT_EQUAL(arc2->param_at_arc_length(0.2, M_PI/6.), 0.4);

  //Testing coord_at_param
  arc1->coord_at_param(0.5, v1);
  arc1r->coord_at_param(0.5, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v1.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v1.z(), 0.);
  TEST_FLOAT_EQUAL(v2.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.z(), 0.);
  
  arc2->coord_at_param(0.3, v1);
  arc2r->coord_at_param(0.9, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1. + cos(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v1.y(), 1. + sin(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v2.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.y(), 1. + sin(0.25 * M_PI));
  
  arc3->coord_at_param(0.0625, v1);
  arc3r->coord_at_param(0.0625, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v1.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.y(), 1. + sin(0.25 * M_PI));

  arc4->coord_at_param(1. / 6., v1);
  arc4r->coord_at_param(0.5, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1. + cos(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v1.y(), 1. + sin(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v2.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v2.y(), 1. + sin(0.25 * M_PI));
  
  //Testing coord_at_dist
  arc2->coord_at_dist(0.2, true, v1);
  arc2r->coord_at_dist(0.2, true, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1.198997487421);
  TEST_FLOAT_EQUAL(v1.y(), 0.02);
  TEST_FLOAT_EQUAL(v2.x(), 1.198997487421);
  TEST_FLOAT_EQUAL(v2.y(), 0.02);
  v1.set(0., 0., 0.); v2.set(0., 0., 0.);

  arc2->coord_at_dist(0.2, false, v1);
  arc2r->coord_at_dist(0.2, false, v2);
  TEST_FLOAT_EQUAL(v1.x(), 1.662336879396);
  TEST_FLOAT_EQUAL(v1.y(), 1.749206151998);
  TEST_FLOAT_EQUAL(v2.x(), 1.662336879396);
  TEST_FLOAT_EQUAL(v2.y(), 1.749206151998);

  //Testing coord_at_mid_dist
  arc2->coord_at_mid_dist(0.1, 0.3, v1);
  arc2->coord_at_param(0.2, v2);
  TEST_FLOAT_EQUAL(v1.x(), v2.x());
  TEST_FLOAT_EQUAL(v1.y(), v2.y());
  arc2->coord_at_param(0.2, v1);
  arc2->coord_at_param(0.6, v2);
  arc2->coord_at_mid_dist(v1, v2, v3);
  arc2->coord_at_param(0.4, v1);
  TEST_FLOAT_EQUAL(v3.x(), v1.x());
  TEST_FLOAT_EQUAL(v3.y(), v1.y());

  //Testing closest_coord_on_curve and closest_param_on_curve.
  CubitVector v(0.,0.,0.);

  v1.set(1. + 2. * cos(0.25 * M_PI), 1. + 2. * sin(0.25 * M_PI), 0.);
  v2.set(2., 1., 0.);
  v3.set(1., 2., 0.);
  arc1->closest_coord_on_curve(v1, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(arc1->closest_param_on_curve(v1), 0.5);
  arc1->closest_coord_on_curve(v1, v, 0., 0.4);
  arc1->coord_at_param(0.4, v1);
  TEST_FLOAT_EQUAL(v.x(), v1.x());
  TEST_FLOAT_EQUAL(v.y(), v1.y());
  arc1->closest_coord_on_curve(v1, v, 0.6, 1.);
  arc1->coord_at_param(0.6, v1);
  TEST_FLOAT_EQUAL(v.x(), v1.x());
  TEST_FLOAT_EQUAL(v.y(), v1.y());
  arc1->closest_coord_on_curve(v2, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(v.y(), 1.5);
  TEST_FLOAT_EQUAL(arc1->closest_param_on_curve(v2), 0.);
  arc1->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 1.5);
  TEST_FLOAT_EQUAL(v.y(), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(arc1->closest_param_on_curve(v3), 1.);

  v1.set(1. + 2. * cos(0.25 * 7. * M_PI), 1. + 2. * sin(0.25 * 7. * M_PI), 0.);
  v2.set(1. + 2. * cos(0.25 * M_PI), 1. + 2. * sin(0.25 * M_PI), 0.);
  v3.set(0., 1., 0.);
  arc2->closest_coord_on_curve(v1, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(arc2->closest_param_on_curve(v1), 0.3);
  arc2->closest_coord_on_curve(v2, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(arc2->closest_param_on_curve(v2), 0.9);
  arc2->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 1.);
  TEST_FLOAT_EQUAL(v.y(), 0.);
  TEST_FLOAT_EQUAL(arc2->closest_param_on_curve(v3), 0.);
  v3.set(1. + 2. * cos(0.25 * 3. * M_PI), 1. + 2. * sin(0.25 * 3. * M_PI), 0.);
  arc2->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 1.5);
  TEST_FLOAT_EQUAL(v.y(), 1. + 0.5 * sqrt(3.));
  TEST_FLOAT_EQUAL(arc2->closest_param_on_curve(v3), 1.);

  v1.set(1. + 2. * cos(0.25 * M_PI), 1. + 2. * sin(0.25 * M_PI), 0.);
  v2.set(3., 1., 0.);
  v3.set(1. + 2. * cos(0.25 * 7. * M_PI), 1. + 2. * sin(0.25 * 7. * M_PI), 0.);
  arc3->closest_coord_on_curve(v1, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(arc3->closest_param_on_curve(v1), 0.0625);
  arc3->closest_coord_on_curve(v2, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(v.y(), 1.5);
  TEST_FLOAT_EQUAL(arc3->closest_param_on_curve(v2), 0.);
  arc3->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 1.);
  TEST_FLOAT_EQUAL(v.y(), 0.);
  TEST_FLOAT_EQUAL(arc3->closest_param_on_curve(v3), 1.);
  
  v1.set(1. + 2. * cos(0.25 * 7. * M_PI), 1. + 2. * sin(0.25 * 7. * M_PI), 0.);
  v2.set(1. + 2. * cos(0.25 * M_PI), 1. + 2. * sin(0.25 * M_PI), 0.);
  v3.set(1. + 2. * cos(1.1 * M_PI), 1. + 2. * sin(1.1 * M_PI), 0.);
  arc4->closest_coord_on_curve(v1, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * 7. * M_PI));
  TEST_FLOAT_EQUAL(arc4->closest_param_on_curve(v1), 1. / 6.);
  arc4->closest_coord_on_curve(v2, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(arc4->closest_param_on_curve(v2), 0.5);
  arc4->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 0.);
  TEST_FLOAT_EQUAL(v.y(), 1.);
  TEST_FLOAT_EQUAL(arc4->closest_param_on_curve(v3), 1.);
  v3.set(1. + 2. * cos(1.4 * M_PI), 1. + 2. * sin(1.4 * M_PI), 0.);
  arc4->closest_coord_on_curve(v3, v);
  TEST_FLOAT_EQUAL(v.x(), 1.);
  TEST_FLOAT_EQUAL(v.y(), 0.);
  TEST_FLOAT_EQUAL(arc4->closest_param_on_curve(v3), 0.);

  //Testing rest of coord_on_curve (other parts tested before).
  v1.set(1.5, 2., 0.);
  v2.set(1. + cos(0.25 * 7. * M_PI), 1. + sin(0.25 * 7. * M_PI), 0.);
  v3.set(1. + cos(0.25 * 3. * M_PI), 1. + sin(0.25 * 3. * M_PI), 0.);
  TEST_EQUAL(arc1->coord_on_curve(v1), false);
  TEST_EQUAL(arc1->coord_on_curve(v2), false);
  TEST_EQUAL(arc2->coord_on_curve(v3), false);
  TEST_EQUAL(arc3->coord_on_curve(v2), false);
  v1.set(1. + cos(0.25 * 5. * M_PI), 1. + sin(0.25 * 5. * M_PI), 0.);
  TEST_EQUAL(arc4->coord_on_curve(v1), false);

  delete arc2;
  delete arc3;
  delete arc1r;
  delete arc2r;
  delete arc3r;
  delete arc4r;

  //Testing first_deriv and second_deriv
  CubitVector D1, D2;
  v.set(1. + cos(0.25 * M_PI), 1. + sin(0.25 * M_PI), 0.);
  
  arc1->first_deriv(arc1->param_at_coord(v), D1);
  arc1->first_deriv(v, D2);
  TEST_FLOAT_EQUAL(D1.x(), -0.37024024484);
  TEST_FLOAT_EQUAL(D1.y(), 0.37024024484);
  TEST_FLOAT_EQUAL(D1.z(), 0.);
  TEST_FLOAT_EQUAL(D2.x(), -0.37024024484);
  TEST_FLOAT_EQUAL(D2.y(), 0.37024024484);
  TEST_FLOAT_EQUAL(D2.z(), 0.);
  arc1->second_deriv(arc1->param_at_coord(v), D1);
  arc1->second_deriv(v, D2);
  TEST_FLOAT_EQUAL(D1.x(), -0.1938573388);
  TEST_FLOAT_EQUAL(D1.y(), -0.1938573388);
  TEST_FLOAT_EQUAL(D1.z(), 0.);
  TEST_FLOAT_EQUAL(D2.x(), -0.1938573388);
  TEST_FLOAT_EQUAL(D2.y(), -0.1938573388);
  TEST_FLOAT_EQUAL(D1.z(), 0.);
  
  //Testing curvature.
  v1.set(1.5, 1. + 0.5 * sqrt(3), 0.);
  TEST_FLOAT_EQUAL(arc1->curvature(0.5), 1.);
  TEST_FLOAT_EQUAL(arc1->curvature(v1), 1.);

  //Testing normal and tangent
  arc1->unit_tangent(arc1->param_at_coord(v), D1);
  arc1->unit_tangent(v, D2);
  TEST_FLOAT_EQUAL(D1.x(), -0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D1.y(), 0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D2.x(), -0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D2.y(), 0.5 * sqrt(2));
  arc1->unit_normal(arc1->param_at_coord(v), D1);
  arc1->unit_normal(v, D2);
  TEST_FLOAT_EQUAL(D1.x(), -0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D1.y(), -0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D2.x(), -0.5 * sqrt(2));
  TEST_FLOAT_EQUAL(D2.y(), -0.5 * sqrt(2));

  //Testing arc_length.
  TEST_FLOAT_EQUAL(arc1->arc_length(), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(arc4->arc_length(), 1.5 * M_PI);
  TEST_FLOAT_EQUAL(arc1->arc_length(0.2, 0.6), 1. / 6. * 0.4 * M_PI);
  TEST_FLOAT_EQUAL(arc4->arc_length(0.2, 0.6), 1.5 * 0.4 * M_PI);
  v1.set(1. + 0.5 * sqrt(3), 1.5, 0.);
  v2.set(1.5, 1. + 0.5 * sqrt(3), 0.);
  TEST_FLOAT_EQUAL(arc1->arc_length(v1, v2), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(arc4->arc_length(v1, v2), 1. / 6. * M_PI);

  arc1->center_point(v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.z(), 0.);
  v.set(-10, -10, 10);
  arc1->center_point(arc1->min_param(), arc1->max_param(), v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.z(), 0.);
  v.set(-10, -10, 10);
  arc1->center_point(v1, v2, v);
  TEST_FLOAT_EQUAL(v.x(), 1. + cos(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.y(), 1. + sin(0.25 * M_PI));
  TEST_FLOAT_EQUAL(v.z(), 0.);

  //Testing TVT and mid_TVT.

  TEST_FLOAT_EQUAL(arc1->TVT(), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(arc4->TVT(), 1.5 * M_PI);
  TEST_FLOAT_EQUAL(arc1->TVT(0.2, 0.6), 1. / 6. * 0.4 * M_PI);
  TEST_FLOAT_EQUAL(arc4->TVT(0.2, 0.6), 1.5 * 0.4 * M_PI);
  TEST_FLOAT_EQUAL(arc1->arc_length(v1, v2), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(arc4->arc_length(v1, v2), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(arc1->mid_TVT(0.1, 0.7), 0.4);
  TEST_FLOAT_EQUAL(arc4->mid_TVT(0.1, 0.7), 0.4);
  arc1->coord_at_param(0.1, v3);
  arc1->coord_at_param(0.7, v);
  TEST_FLOAT_EQUAL(arc1->mid_TVT(v3, v), 0.4);

  //Testing coord query and modification functions. 
  TEST_FLOAT_EQUAL(arc1->X(0), 1.);
  TEST_FLOAT_EQUAL(arc1->Y(0), 1.);
  arc1->get_coord(0, v);
  TEST_FLOAT_EQUAL(v.x(), 1.);
  TEST_FLOAT_EQUAL(v.y(), 1.);
  TEST_FLOAT_EQUAL(arc1->get_coord(0).x(), 1.);
  TEST_FLOAT_EQUAL(arc1->get_coord(0).y(), 1.);
  TEST_FLOAT_EQUAL(arc1->get_coord(0).z(), 0.);

  arc1->set_X(0, 2.);
  arc1->set_Y(0, 2.);
  TEST_FLOAT_EQUAL(arc1->X(0), 2.);
  TEST_FLOAT_EQUAL(arc1->Y(0), 2.);
  TEST_FLOAT_EQUAL(arc1->X(1), 2. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(arc1->Y(1), 2.5);
  TEST_FLOAT_EQUAL(arc1->X(2), 2.5);
  TEST_FLOAT_EQUAL(arc1->Y(2), 2. + 0.5 * sqrt(3));
  arc1->set_coord(0, v);
  TEST_FLOAT_EQUAL(arc1->X(0), 1.);
  TEST_FLOAT_EQUAL(arc1->Y(0), 1.);
  TEST_FLOAT_EQUAL(arc1->X(1), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(arc1->Y(1), 1.5);
  TEST_FLOAT_EQUAL(arc1->X(2), 1.5);
  TEST_FLOAT_EQUAL(arc1->Y(2), 1. + 0.5 * sqrt(3));

  //Testing copy constructor and operator=
  GRArc* arc_new = new GRArc(*arc1);
  GRArc  other_arc = *arc1;

  TEST_FLOAT_EQUAL(arc_new->X(0), 1.);
  TEST_FLOAT_EQUAL(arc_new->Y(0), 1.);
  TEST_FLOAT_EQUAL(arc_new->X(1), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(arc_new->Y(1), 1.5);
  TEST_FLOAT_EQUAL(arc_new->X(2), 1.5);
  TEST_FLOAT_EQUAL(arc_new->Y(2), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(arc_new->arc_length(), 1. / 6. * M_PI);
  TEST_FLOAT_EQUAL(other_arc.X(0), 1.);
  TEST_FLOAT_EQUAL(other_arc.Y(0), 1.);
  TEST_FLOAT_EQUAL(other_arc.X(1), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(other_arc.Y(1), 1.5);
  TEST_FLOAT_EQUAL(other_arc.X(2), 1.5);
  TEST_FLOAT_EQUAL(other_arc.Y(2), 1. + 0.5 * sqrt(3));
  TEST_FLOAT_EQUAL(other_arc.arc_length(), 1. / 6. * M_PI);

  delete arc1;
  delete arc4;
  delete arc_new;
  
  cout << "done." << endl;

}

void vTestGRCubic() {

  /////////////////////////////
  //Testing the GRCubic class//
  /////////////////////////////

  cout << "Testing the GRCubic class... ";

  double* x_coeff = new double[4];
  double* y_coeff = new double[4];

  x_coeff[0] = 2.;
  x_coeff[1] = -2.;
  x_coeff[2] = 6.;
  x_coeff[3] = -5.;
  y_coeff[0] = -1.;
  y_coeff[1] = 4.;
  y_coeff[2] = -3.;
  y_coeff[3] = 4.;

  GRCubic* cubic = new GRCubic(x_coeff, y_coeff);

  TEST_EQUAL(cubic->topo_dim(), 1);
  TEST_EQUAL(cubic->geom_dim(), 2);
  TEST_EQUAL(cubic->get_curve_type(), GRCurveGeom::CUBIC);
  TEST_FLOAT_EQUAL(cubic->min_param(), 0.);
  TEST_FLOAT_EQUAL(cubic->max_param(), 1.);

  //Testing the bounding box
  CubitBox box = cubic->bounding_box();
  CubitVector mini = box.minimum();
  CubitVector maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 1.);
  TEST_FLOAT_EQUAL(mini.y(), -1.);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 2.);
  TEST_FLOAT_EQUAL(maxi.y(), 4.);
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  //Testing mapping between param and cartesian space.
  CubitVector v(1.875, 0.75, 0.);
  double param = cubic->param_at_coord(v);
  TEST_FLOAT_EQUAL(param, 0.5);

  v.set(0., 0., 0.);
  cubic->coord_at_param(param, v);
  TEST_FLOAT_EQUAL(v.x(), 1.875);
  TEST_FLOAT_EQUAL(v.y(), 0.75);
  TEST_FLOAT_EQUAL(v.z(), 0.);

  //Testing closest parameter from a point located near the curve.
  //Testing qCoordOnCurve from the returned coord.

  v.set(0., 5., 0.);
  TEST_FLOAT_EQUAL(cubic->closest_param_on_curve(v), 1.);
  v.set(3., -2., 0.);
  TEST_FLOAT_EQUAL(cubic->closest_param_on_curve(v), 0.);

  CubitVector normal;
  int num_tests = 20;

  for(int i = 0; i < num_tests; i++) {
    param = static_cast<double>(i) / static_cast<double>(num_tests);
    double move = - 0.5 * pow(-1., i+1);
    cubic->coord_at_param(param, v);
    cubic->unit_normal(param, normal);

    double x = v.x() + move * normal.x();
    double y = v.y() + move * normal.y();
    v.set(x, y, 0.);

    double tmp_param = cubic->closest_param_on_curve(v);
//     printf("param = %e, closest = %e\n", param, tmp_param);

    TEST_FLOAT_EQUAL(tmp_param, param);
    cubic->coord_at_param(param, v);
    
    TEST_EQUAL(cubic->coord_on_curve(v), true);    
  }

  v.set(1.3, 2.5, 0.);
  CubitVector new_v;
  cubic->closest_coord_on_curve(v, new_v);
  TEST_FLOAT_EQUAL(new_v.x(), 1.595181970135);
  TEST_FLOAT_EQUAL(new_v.y(), 2.598830521724);
  TEST_FLOAT_EQUAL(new_v.z(), 0.);

  //Testing validity of first and second derivatives.

  param = 0.25;
  cubic->coord_at_param(param, v);
  CubitVector FD, SD;

  cubic->first_deriv(0.25, FD);
  cubic->second_deriv(0.25, SD);
  TEST_FLOAT_EQUAL(FD.x(), 0.0625);
  TEST_FLOAT_EQUAL(FD.y(), 3.25);
  TEST_FLOAT_EQUAL(FD.z(), 0.);
  TEST_FLOAT_EQUAL(SD.x(), 4.5);
  TEST_FLOAT_EQUAL(SD.y(), 0.);
  TEST_FLOAT_EQUAL(SD.z(), 0.);

  FD.set(0., 0., 0.);
  SD.set(0., 0., 0.);
  cubic->first_deriv(v, FD);
  cubic->second_deriv(v, SD);
  TEST_FLOAT_EQUAL(FD.x(), 0.0625);
  TEST_FLOAT_EQUAL(FD.y(), 3.25);
  TEST_FLOAT_EQUAL(FD.z(), 0.);
  TEST_FLOAT_EQUAL(SD.x(), 4.5);
  TEST_FLOAT_EQUAL(SD.y(), 0.);
  TEST_FLOAT_EQUAL(SD.z(), 0.);

  //Testing curvature
  TEST_FLOAT_EQUAL(cubic->curvature(0.),0.40249223594996);
  TEST_FLOAT_EQUAL(cubic->curvature(0.34), 0.13850566115484);
  TEST_FLOAT_EQUAL(cubic->curvature(1.), 0.06439875775199);

  cubic->coord_at_param(0.34, v);  
  TEST_FLOAT_EQUAL(cubic->curvature(v),0.13850566115484);

  //Testing tangent and normal vectors.
  CubitVector tangent;

  param = 0.75;
  cubic->coord_at_param(param, v);
  cubic->unit_tangent(param, tangent);  
  cubic->unit_normal(param, normal);

  TEST_FLOAT_EQUAL(tangent.x(), -0.22414769292143);
  TEST_FLOAT_EQUAL(tangent.y(), 0.9745551866149);
  TEST_FLOAT_EQUAL(tangent.z(), 0.);
  TEST_FLOAT_EQUAL(normal.x(), -0.9745551866149);
  TEST_FLOAT_EQUAL(normal.y(), -0.22414769292143);
  TEST_FLOAT_EQUAL(normal.z(), 0.);

  tangent.set(0., 0., 0.);
  normal.set(0., 0., 0.);
  cubic->unit_tangent(v, tangent);  
  cubic->unit_normal(v, normal);

  TEST_FLOAT_EQUAL(tangent.x(), -0.22414769292143);
  TEST_FLOAT_EQUAL(tangent.y(), 0.9745551866149);
  TEST_FLOAT_EQUAL(tangent.z(), 0.);
  TEST_FLOAT_EQUAL(normal.x(), -0.9745551866149);
  TEST_FLOAT_EQUAL(normal.y(), -0.22414769292143);
  TEST_FLOAT_EQUAL(normal.z(), 0.);

  //Testing arc length calculation.
  cubic->coord_at_param(0.2, v);
  cubic->coord_at_param(0.6, new_v);
    
  TEST_FLOAT_EQUAL(cubic->arc_length(), 5.19245698666);
  TEST_FLOAT_EQUAL(cubic->arc_length(0.2, 0.6), 1.47603494216);
  TEST_FLOAT_EQUAL(cubic->arc_length(v, new_v), 1.47603494216);
  
  //Testing center point
  cubic->center_point(cubic->min_param(), cubic->max_param(), v);
  TEST_FLOAT_EQUAL(v.x(), 1.8467664119);
  TEST_FLOAT_EQUAL(v.y(), 1.5577471815);
  TEST_FLOAT_EQUAL(v.z(), 0.);
  cubic->coord_at_param(cubic->min_param(), v);
  cubic->coord_at_param(cubic->max_param(), new_v);
  cubic->center_point(v, new_v, v);
  TEST_FLOAT_EQUAL(v.x(), 1.8467664119);
  TEST_FLOAT_EQUAL(v.y(), 1.5577471815);
  TEST_FLOAT_EQUAL(v.z(), 0.);

  //Testing total variation of the tangent angle.
  //  printf("%.16e %.16e\n", cubic->TVT(), cubic->TVT() - 1.15504911858 );
  TEST_FLOAT_EQUAL(cubic->TVT(), 1.1550491335);
  TEST_FLOAT_EQUAL(cubic->TVT(0.2, 0.6), 0.3310016578);
  cubic->coord_at_param(0.2, v);
  cubic->coord_at_param(0.6, new_v);
  TEST_FLOAT_EQUAL(cubic->TVT(v, new_v), 0.3310016578);

  //Testing copy constructor and operator= (use arc length and TVT)

  GRCubic* new_cubic = new GRCubic(*cubic);
  TEST_FLOAT_EQUAL(new_cubic->TVT(), 1.1550491335);
  TEST_FLOAT_EQUAL(new_cubic->arc_length(), 5.19245698666);

  GRCubic other_cubic = *cubic;
  TEST_FLOAT_EQUAL(other_cubic.TVT(), 1.1550491335);
  TEST_FLOAT_EQUAL(other_cubic.arc_length(), 5.19245698666);

   delete cubic;
   delete new_cubic;

   cout << "done." << endl;

} 

void vTestGRBezier() {

  //////////////////////////////
  //Testing the GRBezier class//
  //////////////////////////////

  cout << "Testing the GRBezier class... ";

  CubitVector coord[4];  
  coord[0].set(3., 2., 0.);
  coord[1].set(2., 4., 0.);
  coord[2].set(6., 3., 0.);
  coord[3].set(5., 4., 0.);

  GRBezier* bezier = new GRBezier(coord);

  TEST_EQUAL(bezier->topo_dim(), 1);
  TEST_EQUAL(bezier->geom_dim(), 2);
  TEST_EQUAL(bezier->get_curve_type(), GRCurveGeom::BEZIER);

  TEST_FLOAT_EQUAL(bezier->min_param(), 0.);
  TEST_FLOAT_EQUAL(bezier->max_param(), 1.);

  //Testing the bounding box
  CubitBox box = bezier->bounding_box();
  CubitVector mini = box.minimum();
  CubitVector maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), 2.8381049961);
  TEST_FLOAT_EQUAL(mini.y(), 2.);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 5.1618950039);
  TEST_FLOAT_EQUAL(maxi.y(), 4.);
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  //Testing param_at_coord and param_at_arc_length
  CubitVector test_coord(4., 3.375, 0.);
  TEST_FLOAT_EQUAL(bezier->param_at_coord(test_coord), 0.5);
  TEST_FLOAT_EQUAL(bezier->param_at_arc_length(0.2, 1.1), 0.47307077932);

  //Testing coord_at_param
  test_coord.set(0., 0., 0.);
  bezier->coord_at_param(0.5, test_coord);
  TEST_FLOAT_EQUAL(test_coord.x(), 4.);
  TEST_FLOAT_EQUAL(test_coord.y(), 3.375);
  TEST_FLOAT_EQUAL(test_coord.z(), 0.);

  //Testing coord_at_dist
  bezier->coord_at_param(bezier->min_param(), coord[0]);
  bezier->coord_at_param(0.2, coord[1]);
  bezier->coord_at_dist((coord[0] - coord[1]).length(), true, test_coord);
  TEST_FLOAT_EQUAL(test_coord.x(), coord[1].x());
  TEST_FLOAT_EQUAL(test_coord.y(), coord[1].y());
  TEST_FLOAT_EQUAL(test_coord.z(), coord[1].z());

  bezier->coord_at_param(bezier->max_param(), coord[0]);
  bezier->coord_at_param(0.8, coord[1]);
  bezier->coord_at_dist((coord[0] - coord[1]).length(), false, test_coord);
  TEST_FLOAT_EQUAL(test_coord.x(), coord[1].x());
  TEST_FLOAT_EQUAL(test_coord.y(), coord[1].y());
  TEST_FLOAT_EQUAL(test_coord.z(), coord[1].z());
  
  //Testing coord_at_mid_dist.
  bezier->coord_at_param(bezier->min_param(), coord[0]);
  bezier->coord_at_param(bezier->max_param(), coord[1]);
  bezier->coord_at_mid_dist(coord[0], coord[1], coord[2]);
  TEST_FLOAT_EQUAL((coord[0]-coord[2]).length(), (coord[1]-coord[2]).length());
 
  //Testing function to get closest point on curve.

  int n_tests = 20;
  for(int i = 0; i < n_tests; i++) {    
    double param = static_cast<double>(i) / static_cast<double>(n_tests);
    double move = - 0.1 * pow(-1., i+1);
    CubitVector normal;
    bezier->coord_at_param(param, coord[0]);
    bezier->unit_normal(param, normal);
    
    coord[0].x(coord[0].x() + move * normal.x());
    coord[0].y(coord[0].y() + move * normal.y());
    
    TEST_FLOAT_EQUAL(bezier->closest_param_on_curve(coord[0]), param);
    
    bezier->coord_at_param(param, coord[0]);
    TEST_EQUAL(bezier->coord_on_curve(coord[0]), true);    
  }

  coord[0].set(4., 3., 0.);
  bezier->closest_coord_on_curve(coord[0], coord[1]);  
  TEST_FLOAT_EQUAL(coord[1].x(), 3.93553046773);
  TEST_FLOAT_EQUAL(coord[1].y(), 3.36392729063);
  TEST_FLOAT_EQUAL(coord[1].z(), 0.);
  
  coord[0].set(3.5, 3.5, 0.);
  TEST_FLOAT_EQUAL(bezier->closest_param_on_curve(coord[0], 0.8, 0.9), 0.8);
  TEST_FLOAT_EQUAL(bezier->closest_param_on_curve(coord[0], 0.1, 0.2), 0.2);
  
  //Testing first and second derivatives.
  bezier->coord_at_param(0.25, coord[0]);
   
  bezier->first_deriv(0.25, coord[1]);
  bezier->second_deriv(0.25, coord[2]);
  TEST_FLOAT_EQUAL(coord[1].x(), 2.625);
  TEST_FLOAT_EQUAL(coord[1].y(), 2.4375);
  TEST_FLOAT_EQUAL(coord[1].z(), 0.);
  TEST_FLOAT_EQUAL(coord[2].x(), 15.);
  TEST_FLOAT_EQUAL(coord[2].y(), -10.5);
  TEST_FLOAT_EQUAL(coord[2].z(), 0.);

  coord[1].set(0.,0.,0.);
  coord[2].set(0.,0.,0.);
  bezier->first_deriv(coord[0], coord[1]);
  bezier->second_deriv(coord[0], coord[2]);
  TEST_FLOAT_EQUAL(coord[1].x(), 2.625);
  TEST_FLOAT_EQUAL(coord[1].y(), 2.4375);
  TEST_FLOAT_EQUAL(coord[1].z(), 0.);
  TEST_FLOAT_EQUAL(coord[2].x(), 15.);
  TEST_FLOAT_EQUAL(coord[2].y(), -10.5);
  TEST_FLOAT_EQUAL(coord[2].z(), 0.);

  //Testing tangent and normal vectors.
  bezier->coord_at_param(0.75, coord[0]);
  bezier->unit_tangent(0.75, coord[1]);  
  bezier->unit_normal(0.75, coord[2]);
  TEST_FLOAT_EQUAL(coord[1].x(), 0.94174191159484);
  TEST_FLOAT_EQUAL(coord[1].y(), 0.33633639699816);
  TEST_FLOAT_EQUAL(coord[1].z(), 0.);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.33633639699816);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.94174191159484);
  TEST_FLOAT_EQUAL(coord[2].z(), 0.);

  coord[1].set(0.,0.,0.);
  coord[2].set(0.,0.,0.);
  bezier->unit_tangent(coord[0], coord[1]);  
  bezier->unit_normal(coord[0], coord[2]);
  TEST_FLOAT_EQUAL(coord[1].x(), 0.94174191159484);
  TEST_FLOAT_EQUAL(coord[1].y(), 0.33633639699816);
  TEST_FLOAT_EQUAL(coord[1].z(), 0.);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.33633639699816);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.94174191159484);
  TEST_FLOAT_EQUAL(coord[2].z(), 0.);

  //Testing curvature
  TEST_FLOAT_EQUAL(bezier->curvature(0.75), 1.19478051615393);
  bezier->coord_at_param(0.75, coord[0]);
  TEST_FLOAT_EQUAL(bezier->curvature(coord[0]), 1.19478051615393);

  //Testing arc length
  TEST_FLOAT_EQUAL(bezier->arc_length(), 3.7363838928543686);
  TEST_FLOAT_EQUAL(bezier->arc_length(0.2, 0.6), 1.66765099753);
  bezier->coord_at_param(0.2, coord[0]);
  bezier->coord_at_param(0.6, coord[1]);
  TEST_FLOAT_EQUAL(bezier->arc_length(coord[0], coord[1]), 1.66765099753);

  //Testing total variation tangent
  TEST_FLOAT_EQUAL(bezier->TVT(), 4.1111687558);
  TEST_FLOAT_EQUAL(bezier->TVT(0.2, 0.6), 0.89280419598);
  bezier->coord_at_param(0.2, coord[0]);
  bezier->coord_at_param(0.6, coord[1]);
  TEST_FLOAT_EQUAL(bezier->arc_length(coord[0], coord[1]), 1.66765099753);

  //Testing center_point;
  bezier->center_point(coord[0]);
  bezier->coord_at_param(bezier->min_param(), coord[1]);
  bezier->coord_at_param(bezier->max_param(), coord[2]);
  double l1 = bezier->arc_length(coord[1], coord[0]);
  double l2 = bezier->arc_length(coord[0], coord[2]);
  TEST_EQUAL(fabs(l1 - l2) < 1.e-6, true);

  bezier->center_point(0.2, 0.6, coord[0]);
  bezier->coord_at_param(0.2, coord[1]);
  bezier->coord_at_param(0.6, coord[2]);
  l1 = bezier->arc_length(coord[1], coord[0]);
  l2 = bezier->arc_length(coord[0], coord[2]);
  TEST_EQUAL(fabs(l1 - l2) < 1.e-6, true);

  //Testing mid_TVT
  double param = bezier->mid_TVT(bezier->min_param(), bezier->max_param());
  // These two are ridiculously close to testing as equal.  Their
  // difference is something like 2% too large (and the tolerance on
  // relative difference is set at 5e-9).
//   TEST_FLOAT_EQUAL(bezier->TVT(bezier->min_param(), param), 
// 		   bezier->TVT(param, bezier->max_param()));

  bezier->coord_at_param(bezier->min_param(), coord[1]);
  bezier->coord_at_param(bezier->max_param(), coord[2]);
  param = bezier->mid_TVT(coord[1], coord[2]);
  TEST_FLOAT_EQUAL(bezier->TVT(bezier->min_param(), param), 
		   bezier->TVT(param, bezier->max_param()));

  //Testing coord queries
  TEST_FLOAT_EQUAL(bezier->X(0), 3.);
  TEST_FLOAT_EQUAL(bezier->X(1), 2.);
  TEST_FLOAT_EQUAL(bezier->X(2), 6.);
  TEST_FLOAT_EQUAL(bezier->X(3), 5.);
  TEST_FLOAT_EQUAL(bezier->Y(0), 2.);
  TEST_FLOAT_EQUAL(bezier->Y(1), 4.);
  TEST_FLOAT_EQUAL(bezier->Y(2), 3.);
  TEST_FLOAT_EQUAL(bezier->Y(3), 4.);

  bezier->get_coord(1, coord[0]);
  TEST_FLOAT_EQUAL(coord[0].x(), 2.);
  TEST_FLOAT_EQUAL(coord[0].y(), 4.);
  TEST_FLOAT_EQUAL(coord[0].z(), 0.);

  TEST_FLOAT_EQUAL(bezier->get_coord(2).x(), 6.);
  TEST_FLOAT_EQUAL(bezier->get_coord(2).y(), 3.);
  TEST_FLOAT_EQUAL(bezier->get_coord(2).z(), 0.);

  //Testing copy constructor and operator=.
  GRBezier* new_bezier = new GRBezier(*bezier);
  TEST_FLOAT_EQUAL(new_bezier->arc_length(), 3.7363838928543686);
  TEST_FLOAT_EQUAL(new_bezier->TVT(), 4.1111687558);

  GRBezier other_bezier = *bezier;
  TEST_FLOAT_EQUAL(other_bezier.arc_length(), 3.7363838928543686);
  TEST_FLOAT_EQUAL(other_bezier.TVT(), 4.1111687558);
  
  //Testing functions to set coords.
  bezier->set_X(0, 4.);
  bezier->set_Y(0, 1.);  
  TEST_FLOAT_EQUAL(bezier->arc_length(), 4.2174104931702931);
  TEST_FLOAT_EQUAL(bezier->TVT(), 3.949883536669);

  coord[0].set(3., 2., 0.);
  bezier->set_coord(0, coord[0]);
  TEST_FLOAT_EQUAL(bezier->arc_length(), 3.7363838928543686);
  TEST_FLOAT_EQUAL(bezier->TVT(), 4.1111687558);
  
  delete bezier;
  delete new_bezier;

  cout << "done." << endl;

}

void vTestGRInterp() {

  //////////////////////////////
  //Testing the GRInterp class//
  //////////////////////////////

  cout << "Testing the GRInterp class... ";
  
  // interp approximates a sine with an increasing number of points. Using a random
  // sample of points, compare the reduction in L1, L2 and LInf norms. With piecewise
  // cubic polynomials, doubling the number of interpolating points should decrease the
  // norm by around 8.

  CubitVector coord[320];
     
  int num_points = 5;
  std::vector<double> L1, L2, LInf;

  while(num_points <= 320) {
    
    coord[0].set(0.,0.,0.);
    coord[num_points-1].set(2 * M_PI, 0., 0.);
    
    int i;
    for(i = 1; i < num_points - 1; i++) {
      double theta = 2 * M_PI * static_cast<double>(i) / static_cast<double>(num_points - 1);
      coord[i].set(theta, sin(theta), 0.);
    }
        
    GRInterp* interp = new GRInterp(coord, num_points);
       
    double dL1 = 0.;
    double dL2 = 0.;
    double dLInf = 0.;

    //Using 1000 random sample points.
    for(i = 0; i < 1000; i++) {
      double param = drand48() * (num_points - 1);
      CubitVector location;
      interp->coord_at_param(param, location);
      double error = location.y() - sin(location.x());
      dL1 += fabs(error);
      dL2 += error*error;
      dLInf = std::max(dLInf, fabs(error));
    }

    L1.push_back(dL1 / 1000.);
    L2.push_back(sqrt(dL2) / 1000.);
    LInf.push_back(dLInf);
 
    num_points *= 2;
    delete interp;

  }

  //Testing the reduction in the norms: This test validates
  //the function computing the cubic polynomials.
  for(unsigned int i = 1; i < L1.size(); i++) {
    TEST(iFuzzyComp((L1[i - 1] / L1[i]), 6.) >= 0);
    TEST(iFuzzyComp((L2[i - 1] / L2[i]), 6.) >= 0);
    TEST(iFuzzyComp((LInf[i - 1] / LInf[i]), 6.) >= 0);
  }

  //Testing basic query functions. All tests will be conducted
  //with both a self-connected and a non self-connected spline.
  //Testing for a closed spline (periodic parameterization) will
  //also have to be conducted once the constructor is correctly
  //implemented

  num_points = 5;
  coord[0].set(0.,0.,0.);
  coord[1].set(0.,2.,0.);
  coord[2].set(2.,2.,0.);
  coord[3].set(2.,0.,0.);
  coord[4].set(4.,0.,0.);

  GRInterp* open = new GRInterp(coord, num_points);

  coord[4].set(0., 0., 0.);
  GRInterp* closed = new GRInterp(coord, num_points);

  TEST_EQUAL(open->topo_dim(), 1);
  TEST_EQUAL(closed->topo_dim(), 1);
  TEST_EQUAL(open->geom_dim(), 2);
  TEST_EQUAL(closed->geom_dim(), 2);
  TEST_EQUAL(open->get_curve_type(), GRCurveGeom::INTERP);
  TEST_EQUAL(closed->get_curve_type(), GRCurveGeom::INTERP);

  //Testing point queries. Duplicating a lot of the tests,
  //just to be on the safe side.

  //Testing a bunch of query functions for at least one param on each cubic curve.
  open->coord_at_param(0., coord[0]);
  open->unit_normal(0., coord[1]);
  open->unit_tangent(0., coord[2]);
  open->first_deriv(0., coord[3]);
  open->second_deriv(0., coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 0.);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.95702440443347);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.29000739528287);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.29000739528287);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.95702440443347);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.71428571428571);
  TEST_FLOAT_EQUAL(coord[3].y(), 2.35714285714286);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.);
  TEST_FLOAT_EQUAL(open->curvature(0.), 0.);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 0.);

  open->coord_at_param(0.3, coord[0]);
  open->unit_normal(0.3, coord[1]);
  open->unit_tangent(0.3, coord[2]);
  open->first_deriv(0.3, coord[3]);
  open->second_deriv(0.3, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), -0.195);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.6975);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.97441713353845);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.22474707977348);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.22474707977348);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.97441713353845);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.52142857142857);
  TEST_FLOAT_EQUAL(coord[3].y(), 2.26071428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), 1.28571428571429);
  TEST_FLOAT_EQUAL(coord[4].y(), -0.64285714285714);
  TEST_FLOAT_EQUAL(open->curvature(0.3), 0.20590749929525);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 0.3);

  open->coord_at_param(1.4, coord[0]);
  open->unit_normal(1.4, coord[1]);
  open->unit_tangent(1.4, coord[2]);
  open->first_deriv(1.4, coord[3]);
  open->second_deriv(1.4, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 0.81371428571429);
  TEST_FLOAT_EQUAL(coord[0].y(), 2.32914285714286);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.13511320473331);
  TEST_FLOAT_EQUAL(coord[1].y(), 0.99083016804430);
  TEST_FLOAT_EQUAL(coord[2].x(), 0.99083016804430);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.13511320473331);
  TEST_FLOAT_EQUAL(coord[3].x(), 2.38857142857143);
  TEST_FLOAT_EQUAL(coord[3].y(), 0.32571428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.51428571428571);
  TEST_FLOAT_EQUAL(coord[4].y(), -2.65714285714286);
  TEST_FLOAT_EQUAL(open->curvature(1.4), 0.46499658880366);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 1.4);

  open->coord_at_param(2.6, coord[0]);
  open->unit_normal(2.6, coord[1]);
  open->unit_tangent(2.6, coord[2]);
  open->first_deriv(2.6, coord[3]);
  open->second_deriv(2.6, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 2.01371428571429);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.74514285714286);
  TEST_FLOAT_EQUAL(coord[1].x(), 0.98535860724400);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.17049461906512);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.17049461906512);
  TEST_FLOAT_EQUAL(coord[2].y(), -0.98535860724400);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.38857142857143);
  TEST_FLOAT_EQUAL(coord[3].y(), -2.24571428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.51428571428571);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.94285714285714);
  TEST_FLOAT_EQUAL(open->curvature(2.6), 0.06661322750302);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 2.6);

  open->coord_at_param(3.7, coord[0]);
  open->unit_normal(3.7, coord[1]);
  open->unit_tangent(3.7, coord[2]);
  open->first_deriv(3.7, coord[3]);
  open->second_deriv(3.7, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 3.205);
  TEST_FLOAT_EQUAL(coord[0].y(), -0.1755);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.18297677728136);
  TEST_FLOAT_EQUAL(coord[1].y(), 0.98311723562133);
  TEST_FLOAT_EQUAL(coord[2].x(), 0.98311723562133);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.18297677728136);
  TEST_FLOAT_EQUAL(coord[3].x(), 2.52142857142857);
  TEST_FLOAT_EQUAL(coord[3].y(), 0.46928571428571);
  TEST_FLOAT_EQUAL(coord[4].x(), 1.28571428571428);
  TEST_FLOAT_EQUAL(coord[4].y(), 1.15714285714286);
  TEST_FLOAT_EQUAL(open->curvature(3.7), 0.13718066238415);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 3.7);

  open->coord_at_param(4., coord[0]);
  open->unit_normal(4., coord[1]);
  open->unit_tangent(4., coord[2]);
  open->first_deriv(4., coord[3]);
  open->second_deriv(4., coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 4.);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.23046638387921);
  TEST_FLOAT_EQUAL(coord[1].y(), 0.97308028749001);
  TEST_FLOAT_EQUAL(coord[2].x(), 0.97308028749001);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.23046638387921);
  TEST_FLOAT_EQUAL(coord[3].x(), 2.71428571428571);
  TEST_FLOAT_EQUAL(coord[3].y(), 0.64285714285714);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.);
  TEST_FLOAT_EQUAL(open->curvature(4.), 0.);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(open->closest_param_on_curve(coord[0]), 4.);

  closed->coord_at_param(0., coord[0]);
  closed->unit_normal(0., coord[1]);
  closed->unit_tangent(0., coord[2]);
  closed->first_deriv(0., coord[3]);
  closed->second_deriv(0., coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 0.);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.96476382123773);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.26311740579211);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.26311740579211);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.96476382123773);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.64285714285714);
  TEST_FLOAT_EQUAL(coord[3].y(), 2.35714285714286);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.);
  TEST_FLOAT_EQUAL(closed->curvature(0.), 0.);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(closed->closest_param_on_curve(coord[0]), 0.);

  closed->coord_at_param(0.3, coord[0]);
  closed->unit_normal(0.3, coord[1]);
  closed->unit_tangent(0.3, coord[2]);
  closed->first_deriv(0.3, coord[3]);
  closed->second_deriv(0.3, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), - 0.1755);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.6975);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.97912686835473);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.20325003238833);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.20325003238833);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.97912686835473);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.46928571428571);
  TEST_FLOAT_EQUAL(coord[3].y(), 2.26071428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), 1.15714285714286);
  TEST_FLOAT_EQUAL(coord[4].y(), -0.64285714285714);
  TEST_FLOAT_EQUAL(closed->curvature(0.3), 0.18801688072985);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(closed->closest_param_on_curve(coord[0]), 0.3);

  closed->coord_at_param(2.6, coord[0]);
  closed->unit_normal(2.6, coord[1]);
  closed->unit_tangent(2.6, coord[2]);
  closed->first_deriv(2.6, coord[3]);
  closed->second_deriv(2.6, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 2.32914285714286);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.74514285714286);
  TEST_FLOAT_EQUAL(coord[1].x(), 0.98964505206262);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.14353630526099);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.14353630526099);
  TEST_FLOAT_EQUAL(coord[2].y(), -0.98964505206262);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.32571428571429);
  TEST_FLOAT_EQUAL(coord[3].y(), -2.24571428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), -2.65714285714286);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.94285714285714);
  TEST_FLOAT_EQUAL(closed->curvature(2.6), 0.53695656841562);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(closed->closest_param_on_curve(coord[0]), 2.6);

  closed->coord_at_param(3.7, coord[0]);
  closed->unit_normal(3.7, coord[1]);
  closed->unit_tangent(3.7, coord[2]);
  closed->first_deriv(3.7, coord[3]);
  closed->second_deriv(3.7, coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 0.6975);
  TEST_FLOAT_EQUAL(coord[0].y(), - 0.1755);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.20325003238833);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.97912686835473);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.97912686835473);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.20325003238833);
  TEST_FLOAT_EQUAL(coord[3].x(), -2.26071428571429);
  TEST_FLOAT_EQUAL(coord[3].y(), 0.46928571428571);
  TEST_FLOAT_EQUAL(coord[4].x(), -0.64285714285714);
  TEST_FLOAT_EQUAL(coord[4].y(), 1.15714285714286);
  TEST_FLOAT_EQUAL(closed->curvature(3.7), 0.18801688072985);
  coord[0].x(coord[0].x() + 0.1 * coord[1].x());
  coord[0].y(coord[0].y() + 0.1 * coord[1].y());
  TEST_FLOAT_EQUAL(closed->closest_param_on_curve(coord[0]), 3.7);

  closed->coord_at_param(4., coord[0]);
  closed->unit_normal(4., coord[1]);
  closed->unit_tangent(4., coord[2]);
  closed->first_deriv(4., coord[3]);
  closed->second_deriv(4., coord[4]);
  TEST_FLOAT_EQUAL(coord[0].x(), 0.);
  TEST_FLOAT_EQUAL(coord[0].y(), 0.);
  TEST_FLOAT_EQUAL(coord[1].x(), -0.26311740579211);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.96476382123773);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.96476382123773);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.26311740579211);
  TEST_FLOAT_EQUAL(coord[3].x(), -2.35714285714286);
  TEST_FLOAT_EQUAL(coord[3].y(), 0.64285714285714);
  TEST_FLOAT_EQUAL(coord[4].x(), 0.);
  TEST_FLOAT_EQUAL(coord[4].y(), 0.);
  TEST_FLOAT_EQUAL(closed->curvature(4.), 0.);
  
  //Same tests, this time with coords.
  coord[0].set(-0.195, 0.6975, 0.);
  TEST_EQUAL(open->coord_on_curve(coord[0]), true);
  open->unit_normal(coord[0], coord[1]);
  open->unit_tangent(coord[0], coord[2]);
  open->first_deriv(coord[0], coord[3]);
  open->second_deriv(coord[0], coord[4]);
  TEST_FLOAT_EQUAL(open->param_at_coord(coord[0]), 0.3);
  TEST_FLOAT_EQUAL(coord[1].y(), -0.22474707977348);
  TEST_FLOAT_EQUAL(coord[2].x(), -0.22474707977348);
  TEST_FLOAT_EQUAL(coord[2].y(), 0.97441713353845);
  TEST_FLOAT_EQUAL(coord[3].x(), -0.52142857142857);
  TEST_FLOAT_EQUAL(coord[3].y(), 2.26071428571429);
  TEST_FLOAT_EQUAL(coord[4].x(), 1.28571428571429);
  TEST_FLOAT_EQUAL(coord[4].y(), -0.64285714285714);
  TEST_FLOAT_EQUAL(open->curvature(coord[0]), 0.20590749929525);
  coord[0].x(coord[0].x() + coord[1].x() * 0.1);
  coord[0].y(coord[0].y() + coord[1].y() * 0.1);
  open->closest_coord_on_curve(coord[0], coord[1]);
  TEST_FLOAT_EQUAL(open->param_at_coord(coord[1]), 0.3);

  //Testing arc length.
  TEST_FLOAT_EQUAL(open->arc_length(), 8.438576078627);
  TEST_FLOAT_EQUAL(closed->arc_length(), 8.52015078201);
  TEST_FLOAT_EQUAL(open->arc_length(1.2, 3.4), 4.4115541851);
  TEST_FLOAT_EQUAL(closed->arc_length(1.2, 3.4), 4.6756818941);
  TEST_FLOAT_EQUAL(open->arc_length(2.1, 2.6), 1.0997069818);
  TEST_FLOAT_EQUAL(closed->arc_length(2.1, 2.6), 1.12917271033);
  
  open->coord_at_param(2.1, coord[0]);
  open->coord_at_param(2.6, coord[1]);
  TEST_FLOAT_EQUAL(open->arc_length(coord[0], coord[1]), 1.0997069818);
  closed->coord_at_param(2.1, coord[0]);
  closed->coord_at_param(2.6, coord[1]);
  TEST_FLOAT_EQUAL(closed->arc_length(coord[0], coord[1]), 1.12917271033);

  //Testing TVT
  TEST_FLOAT_EQUAL(open->TVT(), 5.58827032124);
  TEST_FLOAT_EQUAL(closed->TVT(), 5.24489309358);
  
  TEST_FLOAT_EQUAL(open->TVT(1.2, 3.4), 3.84166706625);
  TEST_FLOAT_EQUAL(closed->TVT(1.2, 3.4), 3.525802914144);
  TEST_FLOAT_EQUAL(open->TVT(2.1, 2.6), 0.464601524786);
  TEST_FLOAT_EQUAL(closed->TVT(2.1, 2.6), 0.716270078694);
  
  open->coord_at_param(2.1, coord[0]);
  open->coord_at_param(2.6, coord[1]);
  TEST_FLOAT_EQUAL(open->TVT(coord[0], coord[1]), 0.464601524786);
  closed->coord_at_param(2.1, coord[0]);
  closed->coord_at_param(2.6, coord[1]);
  TEST_FLOAT_EQUAL(closed->TVT(coord[0], coord[1]), 0.716270078694);
  
  //Testing the bounding box
  CubitBox box = open->bounding_box();
  CubitVector mini = box.minimum();
  CubitVector maxi = box.maximum();
  TEST_FLOAT_EQUAL(mini.x(), -0.274928699614);
  TEST_FLOAT_EQUAL(mini.y(), -0.247435829653);
  TEST_FLOAT_EQUAL(mini.z(), 0.);
  TEST_FLOAT_EQUAL(maxi.x(), 4.);
  TEST_FLOAT_EQUAL(maxi.y(), 2.348727881666);
  TEST_FLOAT_EQUAL(maxi.z(), 0.);

  //Testing param_at_arc_length
  double param = open->param_at_arc_length(0.2, 4.);
  TEST_FLOAT_EQUAL(open->arc_length(0.2, param), 4.);

  //Testing coord_at_dist.
  open->coord_at_dist(0.5, true, coord[0]);
  open->coord_at_dist(0.5, false, coord[1]);
  open->coord_at_param(open->min_param(), coord[2]);
  open->coord_at_param(open->max_param(), coord[3]);
  double dist1 = (coord[0] - coord[2]).length(); 
  double dist2 = (coord[1] - coord[3]).length();
  TEST_FLOAT_EQUAL(dist1, 0.5);
  TEST_FLOAT_EQUAL(dist2, 0.5);

  closed->coord_at_dist(0.5, true, coord[0]);
  closed->coord_at_dist(0.5, false, coord[1]);
  closed->coord_at_param(closed->min_param(), coord[2]);
  closed->coord_at_param(closed->max_param(), coord[3]);
  dist1 = (coord[0] - coord[2]).length(); 
  dist2 = (coord[1] - coord[3]).length();
  TEST_FLOAT_EQUAL(dist1, 0.5);
  TEST_FLOAT_EQUAL(dist2, 0.5);

  //Testing coord_at_mid_dist
  open->coord_at_mid_dist(open->min_param(), open->max_param(), coord[0]);
  open->coord_at_param(open->min_param(), coord[1]);
  open->coord_at_param(open->max_param(), coord[2]);
  dist1 = (coord[0] - coord[1]).length();
  dist2 = (coord[0] - coord[2]).length();
  TEST_FLOAT_EQUAL(dist1, dist2);

  open->coord_at_mid_dist(coord[1], coord[2], coord[0]);
  dist1 = (coord[0] - coord[1]).length();
  dist2 = (coord[0] - coord[2]).length();
  TEST_FLOAT_EQUAL(dist1, dist2);

  closed->coord_at_mid_dist(closed->min_param(), closed->max_param(), coord[0]);
  closed->coord_at_param(closed->min_param(), coord[1]);
  closed->coord_at_param(closed->max_param(), coord[2]);
  dist1 = (coord[0] - coord[1]).length();
  dist2 = (coord[0] - coord[2]).length();
  TEST_FLOAT_EQUAL(dist1, dist2);

  //Testing center_point
  open->center_point(coord[0]);
  param = open->param_at_coord(coord[0]);
  dist1 = open->arc_length(open->min_param(), param);
  dist2 = open->arc_length(param, open->max_param());
  TEST_FLOAT_EQUAL(dist1, dist2);

  closed->center_point(coord[0]);
  param = closed->param_at_coord(coord[0]);
  dist1 = closed->arc_length(closed->min_param(), param);
  dist2 = closed->arc_length(param, closed->max_param());
  TEST_FLOAT_EQUAL(dist1, dist2);

  //Testing mid_TVT
  param = open->mid_TVT(open->min_param(), open->max_param());
  double tvt1 = open->TVT(open->min_param(), param);
  double tvt2 = open->TVT(param, open->max_param());
  TEST_FLOAT_EQUAL(tvt1, tvt2);

  param = closed->mid_TVT(closed->min_param(), closed->max_param());
  tvt1 = closed->TVT(closed->min_param(), param);
  tvt2 = closed->TVT(param, closed->max_param());
  TEST_EQUAL( fabs(tvt1 - tvt2) < 1.e-7, true);

  //Testing point coordinates query / setting functions

  TEST_FLOAT_EQUAL(open->X(0), 0.);
  TEST_FLOAT_EQUAL(open->X(1), 0.);
  TEST_FLOAT_EQUAL(open->X(2), 2.);
  TEST_FLOAT_EQUAL(open->X(3), 2.);
  TEST_FLOAT_EQUAL(open->X(4), 4.);
  TEST_FLOAT_EQUAL(open->X(0), 0.);
  TEST_FLOAT_EQUAL(open->Y(1), 2.);
  TEST_FLOAT_EQUAL(open->Y(2), 2.);
  TEST_FLOAT_EQUAL(open->Y(3), 0.);
  TEST_FLOAT_EQUAL(open->Y(4), 0.);

  open->get_coord(2, coord[0]);
  TEST_FLOAT_EQUAL(coord[0].x(), 2.);
  TEST_FLOAT_EQUAL(coord[0].y(), 2.);

  TEST_FLOAT_EQUAL(open->get_coord(3).x(), 2.);
  TEST_FLOAT_EQUAL(open->get_coord(3).y(), 0.);

  closed->set_X(0, 0.5);
  closed->set_Y(0, 0.5);
  TEST_FLOAT_EQUAL(closed->X(0), 0.5);
  TEST_FLOAT_EQUAL(closed->Y(0), 0.5);
  closed->set_X(0, 0.);
  closed->set_Y(0, 0.);
  TEST_FLOAT_EQUAL(closed->arc_length(), 8.52015078201);
  TEST_FLOAT_EQUAL(closed->TVT(), 5.24489309358);

  closed->set_X(0, -0.5);
  closed->set_Y(0, -0.5);
  coord[0].set(0., 0., 0.);
  closed->set_coord(0, coord[0]);
  TEST_FLOAT_EQUAL(closed->X(0), 0.);
  TEST_FLOAT_EQUAL(closed->Y(0), 0.);
  TEST_FLOAT_EQUAL(closed->arc_length(), 8.52015078201);
  TEST_FLOAT_EQUAL(closed->TVT(), 5.24489309358);
  
  //Testing copy constructor and operator=

  GRInterp* new_interp = new GRInterp(*open);
  GRInterp other_interp = *open;
  
  TEST_FLOAT_EQUAL(new_interp->arc_length(), 8.438576078627);
  TEST_FLOAT_EQUAL(new_interp->TVT(), 5.58827032124);
  TEST_FLOAT_EQUAL(other_interp.arc_length(), 8.438576078627);
  TEST_FLOAT_EQUAL(other_interp.TVT(), 5.58827032124);

  delete new_interp;
  delete open;
  delete closed;
  
  cout << "done." << endl;

}
