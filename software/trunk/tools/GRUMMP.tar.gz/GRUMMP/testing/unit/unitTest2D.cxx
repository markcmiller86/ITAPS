#include <vector>
#define BOOST_TEST_MODULE Mesh2D
#include <boost/test/unit_test.hpp>

#include "Mesh2DFixtureBase.h"
#include "GR_Geometry.h"

#include "GR_Geometry.h"
#include "CubitVector.hpp"

struct MeshMod2DFixture : public Mesh2DFixtureBase {
  MeshMod2DFixture() : Mesh2DFixtureBase()
  {
    M2D.disallowSwapRecursion();
    M2D.allowNonSimplicial();
    // First, create some verts.  The first six can be used to create
    // two quads; verts 1, 2, 6, 7 to create two independent triangles.
    // Sketch:
    //
    //
    //
    //
    //       5 --5-- 4
    //       |       |
    //       6       4
    //       |       |
    //       3 --2-- 2 --9-- 7
    //       |       |     / |
    //       3       1   10  8
    //       |       | /     |
    //       0 --0-- 1 --7-- 6

    BOOST_CHECK(M2D.isValid());
    Vert *pV0 = M2D.createVert(0, 0);
    Vert *pV1 = M2D.createVert(1, 0); 
    Vert *pV2 = M2D.createVert(1, 1);
    Vert *pV3 = M2D.createVert(0, 1);
    Vert *pV4 = M2D.createVert(1, 2);
    Vert *pV5 = M2D.createVert(0, 2);
    Vert *pV6 = M2D.createVert(2, 0); 
    Vert *pV7 = M2D.createVert(2.1, 1.1); // So that the swap will happen

    (void) M2D.createQuadCell(pV0, pV1, pV2, pV3, 1);
    (void) M2D.createTriCell(pV1, pV6, pV7, 1);

    // The first face already exists.
    Face *pF2 = findCommonFace(pV2, pV3);
    // These three are new.
    bool isNew = false;
    Face *pF4 = M2D.createFace(isNew, pV2, pV4);
    Face *pF5 = M2D.createFace(isNew, pV4, pV5);
    Face *pF6 = M2D.createFace(isNew, pV5, pV3);

    // Creation from faces out of canonical order
    (void) M2D.createQuadCell(pF2, pF4, pF5, pF6, 1);

    // These two exist
    Face *pF10 = findCommonFace(pV1, pV7);
    Face *pF1  = findCommonFace(pV1, pV2);
    // This one is new
    Face *pF9 = M2D.createFace(isNew, pV2, pV7);

    (void) M2D.createTriCell(pF1, pF10, pF9, 1);

    Face *pF0 = findCommonFace(pV1, pV0);
    Face *pF3 = findCommonFace(pV0, pV3);
    Face *pF7 = findCommonFace(pV1, pV6);
    Face *pF8 = findCommonFace(pV6, pV7);
    M2D.createBFace(pF0);
    M2D.createBFace(pF3);
    M2D.createBFace(pF4);
    M2D.createBFace(pF5);
    M2D.createBFace(pF6);
    M2D.createBFace(pF7);
    M2D.createBFace(pF8);
    M2D.createBFace(pF9);
  }
  ~MeshMod2DFixture() {}

  void deleteTris()
  {
    // Deletes the triangles, but not the bdry faces around them.
    Face *pF = findCommonFace(M2D.getCell(0), M2D.getCell(1));

    M2D.deleteCell(M2D.getCell(0));
    M2D.deleteCell(M2D.getCell(1));

    BOOST_CHECK(M2D.getCell(0)->isDeleted());
    BOOST_CHECK(M2D.getCell(1)->isDeleted());
    BOOST_CHECK_EQUAL(pCInvalidCell, pF->getLeftCell());
    BOOST_CHECK_EQUAL(pCInvalidCell, pF->getRightCell());
    BOOST_CHECK(pF->isDeleted());
    checkMeshSize(8, 10, 8, 2, 0, 2);

  }
};

BOOST_FIXTURE_TEST_SUITE(MeshMod2D, MeshMod2DFixture)

BOOST_AUTO_TEST_CASE(Setup)
{
  BOOST_CHECK(M2D.isValid());
  checkMeshSize(8, 11, 8, 4, 2, 2);
}

BOOST_AUTO_TEST_CASE(VertexDegree)
{
  BOOST_CHECK_EQUAL(2, M2D.getVert(0)->getNumFaces());
  BOOST_CHECK_EQUAL(4, M2D.getVert(1)->getNumFaces());
  BOOST_CHECK_EQUAL(4, M2D.getVert(2)->getNumFaces());
  BOOST_CHECK_EQUAL(3, M2D.getVert(3)->getNumFaces());
  BOOST_CHECK_EQUAL(2, M2D.getVert(4)->getNumFaces());
  BOOST_CHECK_EQUAL(2, M2D.getVert(5)->getNumFaces());
  BOOST_CHECK_EQUAL(2, M2D.getVert(6)->getNumFaces());
  BOOST_CHECK_EQUAL(3, M2D.getVert(7)->getNumFaces());
}

BOOST_AUTO_TEST_CASE(Orient2D)
{
  Vert *pV0 = M2D.getVert(0);
  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV4 = M2D.getVert(4);

  BOOST_CHECK_EQUAL(1, iOrient2D(pV0, pV1, pV2));
  BOOST_CHECK_EQUAL(-1, iOrient2D(pV0, pV2, pV1));
  BOOST_CHECK_EQUAL(0, iOrient2D(pV1, pV2, pV4));
}

BOOST_AUTO_TEST_CASE(Connect)
{
  Vert *pV0 = M2D.getVert(0);
  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV3 = M2D.getVert(3);
  Vert *pV4 = M2D.getVert(4);
  Vert *pV5 = M2D.getVert(5);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  Cell *pCA = M2D.getCell(0);
  Cell *pCB = M2D.getCell(1);
  Cell *pCC = M2D.getCell(2);
  Cell *pCD = M2D.getCell(3);

  // Tris always come before quads, regardless of creation order.
  BOOST_CHECK_EQUAL(pCA->getType(), CellSkel::eTriCell);
  BOOST_CHECK_EQUAL(pCB->getType(), CellSkel::eTriCell);
  BOOST_CHECK_EQUAL(pCC->getType(), CellSkel::eQuadCell);
  BOOST_CHECK_EQUAL(pCD->getType(), CellSkel::eQuadCell);

  // Check orientation and canonical ordering for triangles
  checkCanonicalTri(pCA, pV1, pV6, pV7);
  checkCanonicalTri(pCB, pV1, pV7, pV2);

  // Check orientation and canonical ordering for quads
  checkCanonicalQuad(pCC, pV0, pV1, pV2, pV3);
  checkCanonicalQuad(pCD, pV3, pV2, pV4, pV5);
}

BOOST_AUTO_TEST_CASE(Delete)
{
  deleteTris();

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  BOOST_CHECK_EQUAL(3, pV1->getNumFaces());
  BOOST_CHECK_EQUAL(4, pV2->getNumFaces());
  BOOST_CHECK_EQUAL(2, pV6->getNumFaces());
  BOOST_CHECK_EQUAL(2, pV7->getNumFaces());
}

BOOST_AUTO_TEST_CASE(FakeSwap)
{
  deleteTris();

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  Cell *pCA = M2D.createTriCell(pV1, pV6, pV2, 1);
  Cell *pCB = M2D.createTriCell(pV2, pV6, pV7, 1);

  checkMeshSize(8, 11, 8, 4, 2, 2);

  BOOST_CHECK_EQUAL(3, pV1->getNumFaces());
  BOOST_CHECK_EQUAL(5, pV2->getNumFaces());
  BOOST_CHECK_EQUAL(3, pV6->getNumFaces());
  BOOST_CHECK_EQUAL(2, pV7->getNumFaces());

  Face *pF = findCommonFace(pCA, pCB);
  BOOST_CHECK(pF->hasVert(pV2));
  BOOST_CHECK(pF->hasVert(pV6));
}

BOOST_AUTO_TEST_CASE(Purge)
{
  deleteTris();

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  (void) M2D.createTriCell(pV1, pV6, pV2, 1);
  (void) M2D.createTriCell(pV2, pV6, pV7, 1);

  M2D.purgeAllEntities();
  BOOST_CHECK(M2D.isValid());
}

BOOST_AUTO_TEST_CASE(Reconfig)
{
  Cell *pCA = M2D.getCell(0);
  Cell *pCB = M2D.getCell(1);

  Face *pF = findCommonFace(pCA, pCB);
  int iRes = M2D.reconfigure(pF);
  BOOST_CHECK_EQUAL(1, iRes);

  checkMeshSize(8, 11, 8, 4, 2, 2);

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  BOOST_CHECK_EQUAL(3, pV1->getNumFaces());
  BOOST_CHECK_EQUAL(5, pV2->getNumFaces());
  BOOST_CHECK_EQUAL(3, pV6->getNumFaces());
  BOOST_CHECK_EQUAL(2, pV7->getNumFaces());

  // The old tri's were deleted and replaced with two others in the same
  // memory slots, so use indices 0 and 1 here.
  pCA = M2D.getCell(0);
  pCB = M2D.getCell(1);
  pF = findCommonFace(pCA, pCB);
  BOOST_CHECK(pF->hasVert(pV2));
  BOOST_CHECK(pF->hasVert(pV6));
}

BOOST_AUTO_TEST_CASE(Swap)
{
  Cell *pCA = M2D.getCell(0);
  Cell *pCB = M2D.getCell(1);

  Face *pF = findCommonFace(pCA, pCB);

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);

  //  BOOST_CHECK(M2D.qDoSwap(pV1, pV7, pV6, pV2));

  int iRes = M2D.iFaceSwap_deprecated(pF);
  BOOST_CHECK_EQUAL(1, iRes);

  checkMeshSize(8, 11, 8, 4, 2, 2);

  BOOST_CHECK_EQUAL(3, pV1->getNumFaces());
  BOOST_CHECK_EQUAL(5, pV2->getNumFaces());
  BOOST_CHECK_EQUAL(3, pV6->getNumFaces());
  BOOST_CHECK_EQUAL(2, pV7->getNumFaces());

  // The old tri's were deleted and replaced with two others in the same
  // memory slots, so use indices 0 and 1 here.
  pCA = M2D.getCell(0);
  pCB = M2D.getCell(1);
  pF = findCommonFace(pCA, pCB);
  BOOST_CHECK(pF->hasVert(pV2));
  BOOST_CHECK(pF->hasVert(pV6));
}

BOOST_AUTO_TEST_CASE(FakeInsert)
{
  deleteTris();

  Vert *pV1 = M2D.getVert(1);
  Vert *pV2 = M2D.getVert(2);
  Vert *pV6 = M2D.getVert(6);
  Vert *pV7 = M2D.getVert(7);
  Vert *pV8 = M2D.createVert(1.5, 0.5);

  Cell *pT0 = M2D.createTriCell(pV8, pV1, pV6, 1);
  Cell *pT1 = M2D.createTriCell(pV8, pV6, pV7, 1);
  Cell *pT2 = M2D.createTriCell(pV8, pV7, pV2, 1);
  Cell *pT3 = M2D.createTriCell(pV8, pV2, pV1, 1);

  BOOST_CHECK(M2D.isValid());

  checkCanonicalTri(pT0, pV8, pV1, pV6);
  checkCanonicalTri(pT1, pV8, pV6, pV7);
  checkCanonicalTri(pT2, pV8, pV7, pV2);
  checkCanonicalTri(pT3, pV8, pV2, pV1);

  checkMeshSize(9, 14, 8, 6, 4, 2);

  BOOST_CHECK_EQUAL(4, pV1->getNumFaces());
  BOOST_CHECK_EQUAL(5, pV2->getNumFaces());
  BOOST_CHECK_EQUAL(3, pV6->getNumFaces());
  BOOST_CHECK_EQUAL(3, pV7->getNumFaces());
  BOOST_CHECK_EQUAL(4, pV8->getNumFaces());
}

BOOST_AUTO_TEST_SUITE_END()

