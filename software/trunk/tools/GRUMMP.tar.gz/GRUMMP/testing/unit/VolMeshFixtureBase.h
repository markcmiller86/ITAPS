#ifndef VolMeshFixtureBase_h_
#define VolMeshFixtureBase_h_

#include "GR_Geometry.h"
#include "GR_VolMesh.h"

struct VolMeshFixtureBase {
  VolMesh VM;
  VolMeshFixtureBase() : VM() 
  {
    iMessageStdoutLevel = 0;
  }
  ~VolMeshFixtureBase() {}
protected:
  void checkMeshSize(const int nVerts, const int nFaces,
		     const int nBdryFaces, const int nTris, const int nQuads,
		     const int nCells, const int nTets, const int nPyrs, 
		     const int nPrisms, const int nHexes)
  {
    BOOST_CHECK_EQUAL(nVerts, VM.getNumVerts());
    BOOST_CHECK_EQUAL(nTris, VM.getNumTrisInUse());
    BOOST_CHECK_EQUAL(nQuads, VM.getNumQuadsInUse());
    BOOST_CHECK_EQUAL(nFaces, 
		      VM.getNumQuadsInUse() + VM.getNumTrisInUse());
    BOOST_CHECK_EQUAL(nBdryFaces, VM.getNumBdryFacesInUse());
    BOOST_CHECK_EQUAL(nTets, VM.getNumTetsInUse());
    BOOST_CHECK_EQUAL(nPyrs, VM.getNumPyrsInUse());
    BOOST_CHECK_EQUAL(nPrisms, VM.getNumPrismsInUse());
    BOOST_CHECK_EQUAL(nHexes, VM.getNumHexesInUse());
    BOOST_CHECK_EQUAL(nCells, VM.getNumTetsInUse() + VM.getNumPyrsInUse() + VM.getNumPrismsInUse() + VM.getNumHexesInUse());
  }
};

#endif
