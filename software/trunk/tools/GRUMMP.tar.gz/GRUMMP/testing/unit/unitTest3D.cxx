#define BOOST_TEST_MODULE VolMesh_Tests
#include "boost/test/unit_test.hpp"

#include "GR_VolMesh.h"

BOOST_AUTO_TEST_SUITE(VolMesh_ReadTests)

BOOST_AUTO_TEST_CASE(Read_VMesh)
{
  VolMesh VM("meshes/sphere.vmesh", 2, 0, NULL);
  BOOST_CHECK(VM.isValid());

  BOOST_CHECK_MESSAGE( VM.getNumVerts()==768, "VM.iNumVerts() result: " << VM.getNumVerts() );
  BOOST_CHECK_MESSAGE( VM.getNumFaces()==6163, "VM.iNumFaces() result: " << VM.getNumFaces() );
  BOOST_CHECK_MESSAGE( VM.getNumCells()==2821, "VM.iNumCells() result: " << VM.getNumCells() );
  BOOST_CHECK_MESSAGE( VM.getNumBdryFaces()==1042, "VM.iNumBdryFaces() result: " << VM.getNumBdryFaces() );
}

BOOST_AUTO_TEST_CASE(Read_VTK)
{
  VolMesh VM("meshes/sphere.vtk", 2, 0, NULL);
  BOOST_CHECK(VM.isValid());

  BOOST_CHECK_MESSAGE( VM.getNumVerts()==768, "VM.iNumVerts() result: " << VM.getNumVerts() );
  BOOST_CHECK_MESSAGE( VM.getNumFaces()==6163, "VM.iNumFaces() result: " << VM.getNumFaces() );
  BOOST_CHECK_MESSAGE( VM.getNumCells()==2821, "VM.iNumCells() result: " << VM.getNumCells() );
  BOOST_CHECK_MESSAGE( VM.getNumBdryFaces()==1042, "VM.iNumBdryFaces() result: " << VM.getNumBdryFaces() );
}

BOOST_AUTO_TEST_CASE(Read_Globe_Mats_VTK)
{
  VolMesh VM("meshes/globe_mats.vtk", 2, 0, NULL);
  BOOST_CHECK(VM.isValid());

  BOOST_CHECK_MESSAGE( VM.getNumVerts()==1093, "VM.iNumVerts() result: " << VM.getNumVerts() );
  BOOST_CHECK_MESSAGE( VM.getNumFaces()==3480, "VM.iNumFaces() result: " << VM.getNumFaces() );
  BOOST_CHECK_MESSAGE( VM.getNumCells()==1200, "VM.iNumCells() result: " << VM.getNumCells() );
  BOOST_CHECK_MESSAGE( VM.getNumBdryFaces()==200, "VM.iNumBdryFaces() result: " << VM.getNumBdryFaces() );
} 


BOOST_AUTO_TEST_SUITE_END()

