/* include/RI_config.h.  Generated from RI_config.h.in by configure.  */
// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef CONFIG_H_RefImpl
#define CONFIG_H_RefImpl

/* Define to enable support for ITAPS */
#define ITAPS

/* Define if the standard C headers are missing */
#define STDC_HEADERS 1

/* Define if fcntl.h exists */
#define HAVE_FCNTL_H 1

/* Define if limits.h exists */
#define HAVE_LIMITS_H 1

/* Define if unistd.h exists */
#define HAVE_UNISTD_H 1

#ifndef __cplusplus
/* Define to empty if the const keyword is broken in the C compiler */
/* #undef const */
#endif

/* Define if the bool type is known to your compiler */
/* #undef HAVE_bool_c */

/* Define to unsigned if sys/types.h doesn't define it */
/* #undef size_t */

/* Define if vprintf exists */
#define HAVE_VPRINTF 1

/* Define if snprintf exists */
#define HAVE_SNPRINTF 1

/* Define if atexit exists */
#define HAVE_ATEXIT 1

/* Define if on_exit exists */
#define HAVE_ON_EXIT 1

/* Define to disable assertions */
#define NDEBUG 1

/* #undef SUNOS4 */
/* #undef SOLARIS2 */
#define LINUX_GNU 1
/* #undef LINUX */
/* #undef IRIX5 */
/* #undef IRIX6 */
/* #undef HPUX10 */
/* #undef OSF4 */

#ifdef NDEBUG
#define MESSAGE_LEVEL_STDOUT 1
#define MESSAGE_LEVEL_FILE 2
#else
#define MESSAGE_LEVEL_STDOUT 2
#define MESSAGE_LEVEL_FILE 3
#endif

/* The following is fine for IEEE double precision, or anything else */
/* with at least ten bits of binary exponent. */
#define LARGE_DBL 1.e+300

#if (defined(IRIX5) || defined(IRIX6))
#define IRIX
#endif

#ifdef SUNOS4
/* Sun OS 4.1.x has some missing declarations */
#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif
int fflush( FILE *stream);
int fclose( FILE *stream);
int tolower (int c);
int printf( const char *format, ...);
int fprintf( FILE *stream, const char *format, ...);
#ifdef __cplusplus
}
#else
#include <varargs.h>
int vprintf(const char *format, va_list ap);
int vfprintf(FILE *stream, const char *format, va_list ap);
char *vsprintf(char *s, const char *format, va_list ap);
#endif
#endif

#if ((!defined(HAVE_SNPRINTF)) || (defined(_AIX) && !defined(__GNUG__)))
#ifdef __cplusplus
extern "C" {
#endif
#include <stdlib.h>
int snprintf ( char *str, size_t n, const char *format, ... );
#ifdef __cplusplus
}
#endif
#endif

#if defined(HAVE_ATEXIT)
/* atexit() is defined */
#define RefImpl_AT_EXIT(a) atexit(a)
#else
#if defined(HAVE_ON_EXIT)
/* atexit() is not defined but on_exit() is.  Sun 4, for example, has */
/* no prototype for atexit(), although the function appears to exist. */
#define RefImpl_AT_EXIT(a) on_exit(a, (void*)(0))
#else
/* neither atexit() nor on_exit() is defined */
#define RefImpl_AT_EXIT(a) 
#endif /* HAVE_ON_EXIT */
#endif /* HAVE_ATEXIT */

#define RefImpl_VERSION "1.4.0"
#define RefImpl_SERIAL 10000

#define HOST_OS "LINUX_GNU"

/* Be sure these always get included along with config info. */
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#ifdef __cplusplus
#include "RI_Classes.h"
#endif

#endif
