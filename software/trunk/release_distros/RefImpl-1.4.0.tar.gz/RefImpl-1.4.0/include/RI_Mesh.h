// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_Mesh
#define RI_Mesh 1

#include <map>
#include <set>

#include "RI_config.h"
#include "RI_Face.h"
#include "RI_Cell.h"
#include "RI_VarArrayBase.h"
#include "RI_Vertex.h"

/**\brief This is the base class for all mesh data.
 *
 * Vertex data is the only thing stored internally; connectivity data is
 * declared in the derived classes.
 */
class Mesh {
private:
  /// Operator= disallowed.
  Mesh& operator=(const Mesh&) {assert(0); return(*this);}
protected:
  /// Variable-sized array for storing vertex data.
  VAVertex VAVerts;
public:
  /// Enumeration for mesh type
  enum eMeshType {eMesh2D = 2, eVolMesh = 3};
  
  /// Default constructor
  Mesh() : VAVerts() {}

  /// Destructor
  virtual ~Mesh() {}
public:

  ////////////////////////////////////////////////////////
  /// Functions that directly query the mesh database. ///
  ////////////////////////////////////////////////////////
  
  /**\brief Is this entity really a valid entity in the mesh?
   *
   * The argument is an iMesh entity handle.
   */
  virtual bool qIsValidEnt(void* pvEnt) const = 0;

  /// Return the type for this mesh
  virtual eMeshType eType() const = 0;

  /////////////////////////////////////////////////////////////////
  /// Primitive functions that modify mesh geometry or topology ///
  /////////////////////////////////////////////////////////////////

  /// Create a vertex at the given location.
  virtual Vert* createVert(const double dX, const double dY,
			   const double dZ) = 0;

  /// Delete this vertex.
  bool deleteVert(Vert * const pV);

  /// Delete this face
  bool deleteFace(Face * const pF);

  /// Delete this cell
  bool deleteCell(Cell * const pC);
  
  ///////////////////////////////////////
  /// Database maintainence functions ///
  ///////////////////////////////////////
  
  /// Compact and garbage collect the faces stored by this mesh.
  virtual void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL) = 0;

  /// Compact and garbage collect the cells stored by this mesh.
  virtual void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL) = 0;

  /// Compact and garbage collect the vertices stored by this mesh.
  virtual void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL) = 0;

  /// Compact and garbage collect all entities stored by this mesh.
  virtual void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
		      std::map<Face*, Face*>*   face_map  = NULL,
		      std::map<Cell*, Cell*>*   cell_map  = NULL) = 0;

 public:
  /**\brief Set face neighbors for all vertices.
   *
   * Upward connectivity from vertices to faces is stored in two
   * alternate ways (the database is in transition).  One of these is to
   * store, for each vertex, the handles of all faces that contain the
   * vertex.  This is a time-space trade-off: it's much faster to find
   * the neighborhood with this data than just a single face.
   */
  void vSetVertFaceNeighbors();

  /// Clear the face neighbor data for all vertices.
  void vClearVertFaceNeighbors();

  /// Return the number of vertices in the database; some may be deleted.
  int iNumVerts() const {return VAVerts.iSize();}

  /// Return the number of faces in the database; some may be deleted.
  virtual int iNumFaces() const = 0;

  /// Return the number of cells in the database; some may be deleted.
  virtual int iNumCells() const = 0;

  /// Return a cell by index.
  virtual Cell* pCCell(const int i) const = 0;

  /// Return a vertex by index.
  Vert* pVVert(const int i) const {return VAVerts.pTEntry(i);}

  /// Return a face by index.
  virtual Face* pFFace(const int i) const = 0;

 protected:
  /// Return the handle of an unused vertex in the database.
  Vert* pVNewVert()
    {
      Vert *pV = VAVerts.pTNewEntry();
      pV->vClearFaceConnectivity();
      pV->vSetDefaultFlags();
      return (pV);
    }
};

/// Return info about entities in the one-cell ball around the vertex.
void vNeighborhood(const Vert* const pVert,
		   std::set<Cell*>& spCInc,
		   std::set<Vert*>& spVNeigh,
		   std::set<Face*>* pspFNearby = NULL);

#endif // Done with class Mesh
