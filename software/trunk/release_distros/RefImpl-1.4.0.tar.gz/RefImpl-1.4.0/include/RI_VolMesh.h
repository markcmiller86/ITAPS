// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_VolMesh
#define RI_VolMesh 1

#include "RI_config.h"
#include "RI_Mesh.h"
#include "RI_VarArray3D.h"

/**\brief The 3D specialization of the Mesh base class.
 *
 * Functions inherited from Mesh will not be documented again here.
 */
class VolMesh : public Mesh {
private:
  /// Variable size array containing triangular faces in the 3D mesh
  VATriFace       VATriF;      

  /// Variable size array containing quadrilateral faces in the 3D mesh
  VAQuadFace      VAQuadF;     

  /// Variable size array containing tetrahedral cells in the 3D mesh
  VATetCell       VATet;       

  /// Variable size array containing pyramidal cells in the 3D mesh
  VAPyrCell       VAPyr;       

  /// Variable size array containing prismatic cells in the 3D mesh
  VAPrismCell     VAPrism;     

  /// Variable size array containing hexahedral cells in the 3D mesh
  VAHexCell       VAHex;       
private:
  /// Copying disallowed.
  VolMesh& operator=(const VolMesh&) {assert(0); return *this;}
  /// Copy creation disallowed.
  VolMesh(const VolMesh&) : Mesh() {assert(0);}

public:
  /// Constructor
  VolMesh();
//   ///
//   VolMesh(const char fileName[]);

  /// Destructor
  virtual ~VolMesh();

  // Inherited from Mesh
  eMeshType eType() const {return eVolMesh;}
  int iNumFaces() const {return VATriF.iSize() + VAQuadF.iSize();}
  int iNumCells() const {return VATet.iSize() + VAPyr.iSize() +
			   VAPrism.iSize() + VAHex.iSize();}
  Face*    pFFace(const int i) const;
  Cell*    pCCell(const int i) const;
  virtual bool qIsValidEnt(void* pvEnt) const;

  /// Returns the number of triangular faces in the mesh; some may be deleted.
  int iNumTriFaces() const {return VATriF.iSize();}

  /// Returns the number of quad faces in the mesh; some may be deleted.
  int iNumQuadFaces() const {return VAQuadF.iSize();}

  /// Returns the number of tetrahedral cells in the mesh; some may be deleted.
  int iNumTetCells() const {return VATet.iSize();}

  /// Returns the number of pyramidal cells in the mesh; some may be deleted.
  int iNumPyrCells() const {return VAPyr.iSize();}

  /// Returns the number of prismatic cells in the mesh; some may be deleted.
  int iNumPrismCells() const {return VAPrism.iSize();}

  /// Returns the number of hexahedral cells in the mesh; some may be deleted.
  int iNumHexCells() const {return VAHex.iSize();}

  /// Return an unused face (type correct for the argument).
  Face*    pFNewFace(const int iNV = 3);

  /// Return an unused cell (type correct for the argument).
  Cell*    pCNewCell(const int iNF = 4, const int iNV = 4);

  // Inherited from Mesh.
  Vert* createVert(const double dX, const double dY, const double dZ);

  /// Create a face from verts; first arg returns true if the face existed.
  Face* createFace(int *status, Vert * const pVA, Vert * const pVB,
		   Vert * const pVC, Vert * const pVD = pVInvalidVert);

  /// Create a tetrahedral cell from vertices.
  TetCell* createTetCell(int *status,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD);

  /// Create a pyramidal cell from vertices.
  PyrCell* createPyrCell(int *status,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE);

  /// Create a prismatic cell from vertices.
  PrismCell* createPrismCell(int *status,
			     Vert * const pVA, Vert * const pVB,
			     Vert * const pVC, Vert * const pVD,
			     Vert * const pVE, Vert * const pVF);

  /// Create a hexahedral cell from vertices.
  HexCell* createHexCell(int *status,
			 Vert * const pVA, Vert * const pVB,
			 Vert * const pVC, Vert * const pVD,
			 Vert * const pVE, Vert * const pVF,
			 Vert * const pVG, Vert * const pVH);

  /// Create a tetrahedral cell from faces.
  TetCell* createTetCell(int *status,
			 Face * const pFA, Face * const pFB,
			 Face * const pFC, Face * const pFD);

  /// Create a pyramidal cell from faces.
  PyrCell* createPyrCell(int *status,
			 Face * const pFA, Face * const pFB,
			 Face * const pFC, Face * const pFD,
			 Face * const pFE);

  /// Create a prismatic cell from faces.
  PrismCell* createPrismCell(int *status,
			     Face * const pFA, Face * const pFB,
			     Face * const pFC, Face * const pFD,
			     Face * const pFE);

  /// Create a hexahedral cell from faces.
  // Cyclic around the sides, then bottom, then top.
  HexCell* createHexCell(int *status,
			 Face * const pFA, Face * const pFB,
			 Face * const pFC, Face * const pFD,
			 Face * const pFE, Face * const pFF);

  // Inherited from Mesh.
  bool deleteVert(Vert * const pV, const bool qForce = false);
  bool deleteFace(Face * const pF, const bool qForce = false);
  bool deleteCell(Cell * const pC);

  void vPurgeCells(std::map<Cell*, Cell*>* cell_map = NULL);
  void vPurgeFaces(std::map<Face*, Face*>* face_map = NULL);
  void vPurgeVerts(std::map<Vert*, Vert*>* vert_map = NULL);
  void vPurge(std::map<Vert*, Vert*>*   vert_map  = NULL,
	      std::map<Face*, Face*>*   face_map  = NULL,
	      std::map<Cell*, Cell*>*   cell_map  = NULL);
};

#endif
