// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#ifndef RI_misc
#define RI_misc 1

#include <stdlib.h>
#include <limits.h>
#include <stdio.h>

#include "RI_config.h"

#ifndef misc_implementation
#ifdef __cplusplus
extern "C" {
#endif
extern int iMessageStdoutLevel;
#ifdef __cplusplus
}
#endif
#endif

#ifdef __cplusplus
#include <algorithm>
using std::min;
using std::max;
#endif

#define XOR(a,b) ((a) ? (!b) : (b))

/* Define a macro so that gcc can use function and variable attributes
   without messing up other compilers. */
#ifdef __GNUC__
#define ATTRIBUTE(a) __attribute__(a)
#else
#define ATTRIBUTE(a)
#endif

#ifdef __cplusplus
extern "C" {
#endif
  /**\brief Write a message to stdout, if it's marked as important enough.
   */
  void vMessage(const int i, const char *acFormat, ...)
    ATTRIBUTE ((format (printf, 2, 3)));

#ifdef __cplusplus
}
#endif

#endif


