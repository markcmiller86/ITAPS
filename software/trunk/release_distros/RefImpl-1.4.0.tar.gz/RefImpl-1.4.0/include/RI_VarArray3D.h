// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

/// This file declares the variable-sized arrays for 3D meshes.

#ifndef RI_VA3D
#define RI_VA3D 1

#include "RI_config.h"
#include "RI_misc.h"
#include "RI_Face.h"
#include "RI_Cell.h"

#define Type TriFace
#define VAType VATriFace
#include "RI_VarArray.h"

#define Type QuadFace
#define VAType VAQuadFace
#include "RI_VarArray.h"

#define Type TetCell
#define VAType VATetCell
#include "RI_VarArray.h"

#define Type PyrCell
#define VAType VAPyrCell
#include "RI_VarArray.h"

#define Type PrismCell
#define VAType VAPrismCell
#include "RI_VarArray.h"

#define Type HexCell
#define VAType VAHexCell
#include "RI_VarArray.h"

#endif
