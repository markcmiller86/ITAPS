// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include "RI_misc.h"
#include "RI_Face.h"
#include "RI_Vertex.h"

Face::Face(Cell* const pCA, Cell* const pCB, const int iNV,
	   Vert* const pV0, Vert* const pV1,
	   Vert* const pV2, Vert* const pV3) :
  pCL(pCA), pCR(pCB)
  // Other stuff initialized in SetDefaultFlags and SetFaceLoc
{
  assert(iNV>0 && iNV<=4);
  // Fallthrough is deliberate
  switch (iNV) {
  case 4:
    apVVerts[3] = pV3;
  case 3:
    apVVerts[2] = pV2;
  case 2:
    apVVerts[1] = pV1;
  case 1:
    apVVerts[0] = pV0;
    break;
  default:
    assert(0); // Bad number of verts
  }
  vSetDefaultFlags();
}

/// This function makes it so that a face has no connectivity and
/// default flags and location.  This is needed when re-using a Face
/// stored in an array, which would otherwise inherit garbage data.
void Face::vResetAllData()
{
  pCL = pCR = pCInvalidCell;
  apVVerts[0] = apVVerts[1] = apVVerts[2] = apVVerts[3] = pVInvalidVert;
  vSetDefaultFlags();
}  

void Face::vCopyAllFlags(const Face &F) {
  qDel = F.qDel;
}

void Face::vSetDefaultFlags()
{
  qDel = false;
}

Face& Face::operator=(const Face& F)
{
  assert(eType() == F.eType());
  if (this != &F) {
    if (!qDeleted()) {
      // The face *this will no longer be connected to its previous
      // cells. Only do this if the face hasn't been marked as deleted
      // from the mesh already.
      if (pCL->qValid() && pCL->qHasFace(this)) pCL->vRemoveFace(this);
      if (pCR->qValid() && pCR->qHasFace(this)) pCR->vRemoveFace(this);
    }

    // Copy all the flag information for the face.
    vCopyAllFlags(F);

    // Not only copy the cells, but also make sure that the face
    // pointers for the cells are updated properly.
    pCL = F.pCL;
    if (pCL->qValid())
      pCL->vReplaceFace(&F, this);
    pCR = F.pCR;
    if (pCR->qValid())
      pCR->vReplaceFace(&F, this);

    // Copy the vertex pointers and make sure that the vertex hints are
    // updated properly.
    for (int i = 0; i < iNumVerts(); i++) {
      apVVerts[i] = F.apVVerts[i];
    }
  }
  assert(!qDeleted());
  return (*this);
}

int Face::iFullCheck() const
{
  if (!qValid() || qDeleted()) return 0;
  if (pVVert(0)->iSpaceDimen() == 2) {
    for (int iV = iNumVerts() - 1; iV >= 0; iV--) {
      const Vert *pV = pVVert(iV);
      if (!pV->qHasFace(this)) return 0;
    }
  }
  if ( (pCL->qValid() && (pCL->qDeleted() || !pCL->qHasFace(this))) ||
       (pCR->qValid() && (pCR->qDeleted() || !pCR->qHasFace(this))) ) {
    return 0;
  }
  else 
    return 1;
}

bool Face::qHasVert(const Vert* const pV) const {
  assert(qValid());
  for (int i = iNumVerts() - 1; i >= 0; i--)
    if (pV == apVVerts[i]) return (true);
  return (false);
};

/// Deprecated for external use, though it may survive in Cell::operator=()
void Face::vAddCell(Cell* const pCNew)
{
  assert(qValid());
  // Need exactly one invalid cell
  assert((pCL == pCInvalidCell || pCR == pCInvalidCell)
	  &&
	  (pCL != pCInvalidCell || pCR != pCInvalidCell));
  if (pCL == pCInvalidCell) pCL = pCNew;
  else                      pCR = pCNew;
}

/// Deprecated for external use, though it may survive in Cell::operator=()
void Face::vRemoveCell(const Cell* const pCOld)
{
  if (!qValid()) return; // A useful short-circuit when destroying part
			 // of a mesh.  This way there is no need to be
			 // careful about the order in which objects are
			 // killed.
  assert((pCL == pCOld || pCR == pCOld)); // Cell must bound the face
  if (pCL == pCOld) pCL = pCInvalidCell;
  else              pCR = pCInvalidCell;
}

/// Deprecated for external use, though it may survive in Cell::operator=()
void Face::vReplaceCell(const Cell* const pCOld, Cell* const pCNew)
{
  assert(qValid());
  assert(pCNew->qValid());
  assert((pCL == pCOld || pCR == pCOld)); // Cell must bound the face
  if (pCL == pCOld) pCL = pCNew;
  else              pCR = pCNew;
}

Cell* pCCommonCell(const Face* const pF0, const Face* const pF1)
{
  if (pF0 == pFInvalidFace || pF1 == pFInvalidFace) return (pCInvalidCell);
  Cell* pC0L = pF0->pCCellLeft();
  Cell* pC0R = pF0->pCCellRight();
  Cell* pC1L = pF1->pCCellLeft();
  Cell* pC1R = pF1->pCCellRight();
  // Don't return invalid cell if there's still a chance for a match
  if ((pC0L == pC1L || pC0L == pC1R) && pC0L->qValid()) return (pC0L);
  // Now returning invalid cell doesn't eliminate hope for a match
  else if (pC0R == pC1L || pC0R == pC1R) return (pC0R);
  else return (pCInvalidCell);
}

Vert* pVCommonVert(const Face* const pF0, const Face* const pF1)
{
  if (pF0 == pFInvalidFace || pF1 == pFInvalidFace) return (pVInvalidVert);
  RefImpl_Entity *apV0[4], *apV1[4];
  int iNV0 = pF0->iNumVerts(), iNV1 = pF1->iNumVerts();
  pF0->vAllVertHandles(apV0);
  pF1->vAllVertHandles(apV1);
  for (int i = 0; i < iNV0; i ++) {
    for (int j = 0; j < iNV1; j ++) {
      if (apV0[i] == apV1[j])
        return static_cast<Vert*>(apV0[i]);
    }
  }
  return (pVInvalidVert);
}

void Face::vAllCellHandles(RefImpl_Entity* apEnt[]) const
{
  int i = 0;
  if (pCL->qValid()) {
    apEnt[i++] = pCL;
  }
  if (pCR->qValid()) {
    apEnt[i] = pCR;
  }
}
