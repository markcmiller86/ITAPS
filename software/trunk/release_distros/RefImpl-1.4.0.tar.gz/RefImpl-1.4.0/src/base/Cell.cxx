// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <stdlib.h>

#include "RI_config.h"
#include "RI_Cell.h"
#include "RI_Vertex.h"
#include "RI_Face.h"

Cell::Cell(const int iNFaces, const int iNVerts, Face** const ppFIn,
	   Cell::eCellType eTypeIn)
  : ppFFaces(NULL)
{
  qDel = false;
  uiType = eTypeIn;
  assert(iNFaces >= 3 && iNFaces <= 6);
  assert(iNVerts >= 3 && iNVerts <= 8);
#ifndef NDEBUG
  switch (iNFaces) {
  case 2: assert(iNVerts == 2); break;
  case 3: assert(iNVerts == 3); break;
  case 4: assert(iNVerts == 4); break;
  case 5: assert(iNVerts == 5 || iNVerts == 6); break;
  case 6: assert(iNVerts == 8); break;
  default: assert(0); break; // Illegal number of faces for cell
  }
#endif
  // Cell type will be explicitly set by derived class constructor.
  ppFFaces = new Face*[iNFaces];
  int i;
  if (ppFIn) {
    for (i = 0; i < iNFaces; i++) {
      ppFFaces[i] = ppFIn[i];
      assert(ppFFaces[i] != pFInvalidFace); // Uninitialized face
    }
    vCanonicalizeFaceOrder();
  }
  else
    for (i = 0; i < iNFaces; i++)
      ppFFaces[i] = pFInvalidFace;
}

Cell::~Cell()
{
  if (ppFFaces != NULL) delete [] ppFFaces;
}

Cell& Cell::operator=(const Cell& C)
{
  assert(eType() == C.eType());
  if (this != &C) {
    int i;
    // The cell *this will no longer be connected to its previous faces,
    // if the cell still exists.  If it doesn't, then either the face is
    // deleted or the face has been modified so that it isn't attached
    // to the cell anymore.
    if (!qDeleted()) {
      for (i = iNumFaces() - 1; i >= 0; i--)
	if (ppFFaces[i]->qValid() && ppFFaces[i]->qHasCell(this))
	  ppFFaces[i]->vRemoveCell(this);
    }
    // Copy the face pointers and connect them to this cell
    for (i = iNumFaces() - 1; i >= 0; i--) {
      ppFFaces[i] = C.ppFFaces[i];
      if (ppFFaces[i]->qValid()) {
	ppFFaces[i]->vReplaceCell(&C, this);
	assert(ppFFaces[i]->pCCellLeft() == this ||
	       ppFFaces[i]->pCCellRight() == this);
      }
    }
    vCopyAllFlags(C);
  }
  return (*this);
}

int Cell::iFullCheck() const
{
  if (!qValid() || qDeleted()) return 0;
  bool qOkay = true;

  int iInvalid = 0;
  for (int i = 0; qOkay && i < iNumFaces(); i++) {
    const Face* pFThisFace = pFFace(i);
    if (pFThisFace->qValid()) {
      qOkay = qOkay && pFThisFace->qHasCell(this);
    }
    else 
      iInvalid++;
  }
 
  if (iInvalid == 0 && qOkay) return 1;
  else if (iInvalid == iNumFaces() && qOkay) return 2;
  else return 0;
}

const Face* Cell::pFFace(const int i) const
{
  assert(qValid());
  assert(i >= 0 && i < iNumFaces()); // Index out of range
  return ppFFaces[i];
}

Face* Cell::pFFace(const int i)
{
  assert(qValid());
  assert(i >= 0 && i < iNumFaces()); // Index out of range
  return ppFFaces[i];
}

bool Cell::qHasFace(const Face* pF) const
{
  assert(qValid());
  assert(pF->qValid());
  for (int i = 0; i < iNumFaces(); i++)
    if (ppFFaces[i] == pF) return(true);
  return(false);
}

void Cell::vReplaceFace(const Face* const pFOld, Face* const pFNew)
{
  assert(qValid());
  assert(pFOld->qValid()); // Tried to replace non-existent face
  assert(pFNew->qValid()); // Tried to add non-existent face
  int iRepl = -1;
  for (int i = 0; i < iNumFaces(); i++) {
    if (ppFFaces[i] == pFOld) iRepl = i;
  }
  assert(iRepl >= 0); // Tried to replace face which doesn't bound this cell
  ppFFaces[iRepl] = pFNew;
}

void Cell::vRemoveFace(const Face* const pFOld)
{
  if (!qValid()) return; // A useful short-circuit when destroying part
			 // of a mesh.  This way there is no need to be
			 // careful about the order in which objects are
			 // killed.
  assert(pFOld->qValid()); // Tried to remove non-existent face
  int iRepl = -1;
  for (int i = 0; i < iNumFaces(); i++) {
    if (ppFFaces[i] == pFOld) iRepl = i;
  }
  assert(iRepl >= 0); // Tried to remove face which doesn't bound this cell
  ppFFaces[iRepl] = pFInvalidFace;
}

void Cell::vAssign(Face* const apF[])
{
  assert(qValid());
  assert(apF != NULL);
  for (int i = 0; i < iNumFaces(); i++) {
    ppFFaces[i] = apF[i];
    assert(ppFFaces[i] != pFInvalidFace); //Uninitialized face
  }
  vCanonicalizeFaceOrder();
}

void Cell::vAssign(Face* const pF0, Face* const pF1, Face* const pF2,
		   Face* const pF3, Face* const pF4, Face* const pF5)
     // All alternate interface to vAssign, so that stuff doesn't have
     // to be loaded into an array by the user.
{
  assert(qValid());
  Face *apF[] = {pF0, pF1, pF2, pF3, pF4, pF5};
  vAssign(apF);
}

void Cell::vResetAllData()
{
  vSetDefaultFlags();
  for (int i = 0; i < iNumFaces(); i++)
    ppFFaces[i] = pFInvalidFace;
}  

bool Cell::qHasVert(const Vert* pV) const
{
  assert(qValid());
  for (int i = 0; i < iNumFaces(); i++)
    if (ppFFaces[i]->qHasVert(pV)) return true;
  return false;
}

Face *pFCommonFace(Cell* const pC0, Cell* const pC1)
{
  if (pC0->iFullCheck() != 1 || pC1->iFullCheck() != 1)
    return (pFInvalidFace);
  for (int iF0 = 0; iF0 < pC0->iNumFaces(); iF0++) {
    Face *pF0 = pC0->pFFace(iF0);
    for (int iF1 = 0; iF1 < pC1->iNumFaces(); iF1++)
      if (pF0 == pC1->pFFace(iF1)) return pF0;
  }
  return pFInvalidFace;
}

void Cell::vAllFaceHandles(RefImpl_Entity* aHandles[]) const {
  for (int i = iNumFaces() - 1; i >= 0; i--) {
    aHandles[i] = ppFFaces[i];
  }
}
