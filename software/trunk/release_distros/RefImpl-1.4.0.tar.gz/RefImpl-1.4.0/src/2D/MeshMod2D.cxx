// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

#include <stdlib.h>

#include "RI_config.h"
#include "RI_Classes.h"

#include "RI_Cell.h"
#include "RI_Face.h"
#include "RI_Mesh2D.h"
#include "RI_Vertex.h"

// The semantics of these calls are essentially identical to the ITAPS
// createEnt calls.
//   createFace returns a face with given vertices; if the face
//     already existed it might be opposite in sense, but that's OK.
//   create*Cell returns a cell with given verts or faces.

Face* Mesh2D::createFace(Vert * const pV0, Vert * const pV1)
{
  assert(pV0->qValid());
  assert(pV1->qValid());
  // Check for prior existence.
  Face *pF = findCommonFace(pV0, pV1);
  if (pF == pFInvalidFace) {
    // Face doesn't exist yet.
    pF = pFNewFace();
    pF->vSetVerts(pV0, pV1);
  }

  assert(pF->iFullCheck());

  return pF;
}

Cell* Mesh2D::createTriCell(Face * const pF0, Face * const pF1,
			    Face * const pF2)
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());

  // Set up the face->cell connectivity properly.  The canonical tet
  // looks like this, where face 3 is the bottom (see ITAPS docs):
  //
  //                2
  //               / \         .
  //              /   \        .
  //             2     1       .
  //            /       \      .
  //           0 - -0- - 1


  // Each pair of faces  must have a common vert.
  Vert *apV[3];
  apV[0] = pVCommonVert(pF0, pF2);
  apV[1] = pVCommonVert(pF0, pF1);
  apV[2] = pVCommonVert(pF1, pF2);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());

  Cell *pC = pCNewCell(3);

  int iOrient = iOrient2D(apV[0], apV[1], apV[2]);
  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pC->vAssign(pF0, pF1, pF2);
  }
  else {
    // Left-handed (faces 2 and 3 reversed above)
    pC->vAssign(pF0, pF2, pF1);
  }

  if (XOR(iOrient == 1, (pF0->pVVert(0) == apV[0])))
    { pF0->vSetRightCell(pC); }
  else
    { pF0->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF1->pVVert(0) == apV[1])))
    { pF1->vSetRightCell(pC); }
  else
    { pF1->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF2->pVVert(0) == apV[2])))
    { pF2->vSetRightCell(pC); }
  else
    { pF2->vSetLeftCell(pC); }

  assert(pC->iFullCheck());
  assert(pC->qHasFace(pF0));
  assert(pC->qHasFace(pF1));
  assert(pC->qHasFace(pF2));
  assert(pF0->iFullCheck());
  assert(pF1->iFullCheck());
  assert(pF2->iFullCheck());

  return pC;
}


Cell* Mesh2D::createTriCell(Vert * const pV0, Vert * const pV1,
			    Vert * const pV2)
{
  Face *pF01 = createFace(pV0, pV1);
  Face *pF12 = createFace(pV1, pV2);
  Face *pF20 = createFace(pV2, pV0);

  Cell *pC = createTriCell(pF01, pF12, pF20);
  assert(pC->qHasVert(pV0));
  assert(pC->qHasVert(pV1));
  assert(pC->qHasVert(pV2));
  return (pC);
}


Cell* Mesh2D::createQuadCell(Vert * const pV0, Vert * const pV1,
			     Vert * const pV2, Vert * const pV3)
{
  Face *pF01 = createFace(pV0, pV1);
  Face *pF12 = createFace(pV1, pV2);
  Face *pF23 = createFace(pV2, pV3);
  Face *pF30 = createFace(pV3, pV0);

  Cell *pC = createQuadCell(pF01, pF12, pF23, pF30);
  assert(pC->qHasVert(pV0));
  assert(pC->qHasVert(pV1));
  assert(pC->qHasVert(pV2));
  assert(pC->qHasVert(pV3));
  return (pC);
}


Cell* Mesh2D::createQuadCell(Face * const pF0, Face * const pF1,
			     Face * const pF2, Face * const pF3)
{
  // Faces must already exist
  assert(pF0->qValid());
  assert(pF1->qValid());
  assert(pF2->qValid());
  assert(pF3->qValid());

  // Set up the face->cell connectivity properly.  The canonical quad
  // looks like this (see ITAPS docs):
  //
  //      3 - -2- - 2
  //       \         \         .
  //        \         \        .
  //         3         1       .
  //          \         \      .
  //           0 - -0- - 1


  // Each pair of faces  must have a common vert.
  Vert *apV[4];
  apV[0] = pVCommonVert(pF0, pF3);
  apV[1] = pVCommonVert(pF0, pF1);
  apV[2] = pVCommonVert(pF1, pF2);
  apV[3] = pVCommonVert(pF2, pF3);
  assert(apV[0]->qValid());
  assert(apV[1]->qValid());
  assert(apV[2]->qValid());
  assert(apV[3]->qValid());

  Cell *pC = pCNewCell(4);
  
  int iOrient = iOrient2D(apV[0], apV[1], apV[2]);
  assert(iOrient2D(apV[0], apV[2], apV[3]) == iOrient);

  if (XOR(iOrient == 1, (pF0->pVVert(0) == apV[0])))
    { pF0->vSetRightCell(pC); }
  else
    { pF0->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF1->pVVert(0) == apV[1])))
    { pF1->vSetRightCell(pC); }
  else
    { pF1->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF2->pVVert(0) == apV[2])))
    { pF2->vSetRightCell(pC); }
  else
    { pF2->vSetLeftCell(pC); }

  if (XOR(iOrient == 1, (pF3->pVVert(0) == apV[3])))
    { pF3->vSetRightCell(pC); }
  else
    { pF3->vSetLeftCell(pC); }

  if (iOrient == 1) {
    // Right-handed (as sketched above)
    pC->vAssign(pF0, pF1, pF2, pF3);
  }
  else {
    // Left-handed (faces 2 and 3 reversed above)
    pC->vAssign(pF0, pF3, pF2, pF1);
  }

  assert(pC->iFullCheck());
  assert(pC->qHasFace(pF0));
  assert(pC->qHasFace(pF1));
  assert(pC->qHasFace(pF2));
  assert(pC->qHasFace(pF3));
  assert(pF0->iFullCheck());
  assert(pF1->iFullCheck());
  assert(pF2->iFullCheck());
  assert(pF3->iFullCheck());

  return pC;
}

bool Mesh2D::deleteCell(Cell * const pC)
{
  if (pC->qDeleted()) return true;
#ifndef OMIT_OLD_DATA_STRUCTURES
  // Free up connectivity for faces.
  for (int i = pC->iNumFaces() - 1; i >= 0; i--) {
    Face *pF = pC->pFFace(i);
    if (pF->qValid()) {
      pF->vRemoveCell(pC);
      if (!pF->pCCellLeft()->qValid() &&
	  !pF->pCCellRight()->qValid()) deleteFace(pF);
    }
  }
  // Under the old data structures, just mark it.
  pC->vMarkDeleted();
  return true;
#endif
}

// Like ITAPS, faces that are in use can't be deleted.
bool Mesh2D::deleteFace(Face * const pF)
{
  if (pF->qDeleted()) return true;
  if (pF->pCCellRight()->qValid() || pF->pCCellLeft()->qValid())
    return false;
  pF->pVVert(0)->vRemoveFace(pF);
  pF->pVVert(1)->vRemoveFace(pF);

#ifndef OMIT_OLD_DATA_STRUCTURES
  // Under the old data structures, just mark it.
  pF->vMarkDeleted();
#endif
  return true;
}

Vert* Mesh2D::createVert(const double dX, const double dY, const double dZ)
{
  assert(dZ == 0);
  Vert *pV = pVNewVert();
  pV->vSetDefaultFlags();
  double adData[] = {dX, dY};
  pV->vSetCoords(2, adData);
  return pV;
}

// For verts, it's non-trivial to keep the hint face up to date as faces
// are deleted, so there's no reliable test for when these are safe to
// delete.  So just mark it, and caveat emptor.
bool Mesh2D::deleteVert(Vert * const pV)
{
  if (pV->qDeleted()) return true;
  pV->vClearFaceConnectivity();

  // Under the old data structures, just mark it.
  pV->vMarkDeleted();
  return true;
}


