// Copyright 2009 Carl Ollivier-Gooch

// This file is part of the iMesh Reference Implementation (RefImpl).

// The iMesh Reference Implementation is free software: you can
// redistribute it and/or modify it under the terms of the GNU Lesser
// General Public License as published by the Free Software Foundation,
// either version 3 of the License, or (at your option) any later version.

// The iMesh Reference Implementation is distributed in the hope that it
// will be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See
// the GNU Lesser General Public License for more details.

// You should have received a copy of the GNU Lesser General Public License
// along with the iMesh Reference Implementation.  If not, see
// <http://www.gnu.org/licenses/>.

//#include <cmath>
//#include <string.h>
//#include <stdlib.h>
//#include <sys/stat.h>
#include <map>

using std::map;

#include "RI_Mesh2D.h"
#include "RI_misc.h"

// This is here so that configure can find the library.
extern "C"
{
  void vRefImpl_2D_Lib (void) {}
}



//@ Default constructor
Mesh2D::Mesh2D()
  : Mesh (), VATri(), VAQuad()
{}

//@ Retrieval by index
Face* Mesh2D::
pFFace (const int i) const
{
  assert (i >= 0 && i < iNumFaces ());
  return VAEdgeF.pTEntry (i);
}

Cell* Mesh2D::
pCCell (const int i) const
{
  assert (i >= 0 && i < iNumCells ());
  if (i < VATri.iSize ())
    return VATri.pTEntry (i);
  else
    return VAQuad.pTEntry (i - VATri.iSize ());
}

//@ Creation of new entities

bool Mesh2D::
qIsValidEnt (void* pvEnt) const
  // Determines if the memory location pointed to by the pointer
  // given is valid (within the range) for any of the entity types
  // for this mesh
{
  return ( VAEdgeF.qValid( static_cast<EdgeFace*>(pvEnt) ) ||
	   VATri.qValid( static_cast<TriCell*>(pvEnt) )    ||
	   VAQuad.qValid( static_cast<QuadCell*>(pvEnt) )  ||
	   VAVerts.qValid( static_cast<Vert*>(pvEnt) )     );
}

Face* Mesh2D::
pFNewFace (const int iNV)
{
  assert (iNV == 2);
  Face *pF = VAEdgeF.pTNewEntry ();
  pF->vResetAllData ();
  return pF;
}

Cell* Mesh2D::
pCNewCell (const int iNF)
{
  assert (iNF == 3 || (iNF == 4));
  if (iNF == 3) {
    TriCell *pTriC = VATri.pTNewEntry ();
    pTriC->vResetAllData();
    assert(pTriC->eType() == Cell::eTriCell);
    return pTriC;
  }
  else {
    QuadCell *pQuadC = VAQuad.pTNewEntry ();
    pQuadC->vResetAllData();
    assert(pQuadC->eType() == Cell::eQuadCell);
    return pQuadC;
  }
}

//@ Purge unused entries
void Mesh2D::
vPurge (map<Vert*, Vert*>*   vert_map,
	map<Face*, Face*>*   face_map,
	map<Cell*, Cell*>*   cell_map)
{
  vPurgeCells (cell_map);
  vPurgeFaces (face_map);
  vPurgeVerts (vert_map);
}

void Mesh2D::
vPurgeVerts (map<Vert*, Vert*>* vert_map)
  // Renumber vertices, removing those that have been marked as deleted
{
  int *aiVertInd = new int[iNumVerts()];
  int iV, iVActive;

  vSetVertFaceNeighbors();
  iVActive = 0;
  // Copy the vertex data down within the list and establish a lookup so
  // that the faces can figure out where their verts are now stored.
  for (iV = 0; iV < iNumVerts(); iV++) {
    Vert *pV = pVVert(iV);
    if (pV->qDeleted()) {// If vert is deleted, copy over it.
      aiVertInd[iV] = -1;
    }
    else {
      aiVertInd[iV] = iVActive;
      Vert *pVA = pVVert(iVActive);
      if(vert_map) vert_map->insert( std::make_pair(pV, pVA) );
      // Copy the data from its old to its new location
      (*pVA) = (*pV);
      iVActive++;
    }
  }

  for (int iF = iNumFaces() - 1; iF >= 0; iF--) {
    Face *pF = pFFace(iF);
    if (pF->qDeleted()) continue;
    Vert *apVNew[] = {NULL, NULL, NULL, NULL};
    for (int ii = pF->iNumVerts() - 1; ii >= 0; ii--) {
      std::map<Vert*, Vert*>::iterator iter =
	vert_map->find(pF->pVVert(ii));
      apVNew[ii] = iter->second;
    }
    // Passing the extra arguments does no harm, as they are ignored.
    pF->vSetVerts(apVNew[0], apVNew[1], apVNew[2], apVNew[3]);
  }
  vSetVertFaceNeighbors();

  delete [] aiVertInd;
}

void Mesh2D::
vPurgeFaces (map<Face*, Face*>* face_map)
  // Get rid of all unused faces in the connectivity table.
{
  EdgeFace *pFFor = VAEdgeF.pTFirst ();
  EdgeFace *pFBack = VAEdgeF.pTLast ();

  int iNewSize = 0;
  // The case of exactly one valid face
  if (pFFor == pFBack && pFFor != pFInvalidFace && 
      !pFFor->qDeleted ()) { 
    if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
    iNewSize++;
  }

  while (pFFor != pFBack) {
    while (!pFFor->qDeleted () && pFFor != pFBack) {
      if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
      pFFor = VAEdgeF.pTNext (pFFor);
      iNewSize++;
    }

    while (pFBack->qDeleted () && pFFor != pFBack)
      pFBack = VAEdgeF.pTPrev (pFBack);

    if (pFFor != pFBack) {
      assert (pFFor->qDeleted ());
      if(face_map) face_map->insert( std::make_pair(pFBack, pFFor) );
      iNewSize++;
      (*pFFor) = (*pFBack);
      assert (!pFFor->qDeleted ());
      pFBack->vMarkDeleted ();
      pFFor = VAEdgeF.pTNext (pFFor);
    }
    // Allow for the case where nothing has been deleted
    else if (!pFFor->qDeleted ()) {
      if(face_map) face_map->insert( std::make_pair(pFFor, pFFor) );
      iNewSize++;
    }
  }				// Loop over all faces

  // This resets the number of entries in use to iNewSize.
  VAEdgeF.vSetup (iNewSize);
  vClearVertFaceNeighbors();
  vSetVertFaceNeighbors();
}

void Mesh2D::
vPurgeCells (map<Cell*, Cell*>* cell_map)
  // Get rid of all unused cells in the connectivity table.
{
  {
    TriCell *pCFor = VATri.pTFirst ();
    TriCell *pCBack = VATri.pTLast ();
    int iNewSize = 0;
    // The case of exactly one valid cell
    if (pCFor == pCBack &&
	pCFor != pCInvalidCell &&
	!pCFor->qDeleted ()) {
      iNewSize = 1;
      if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
    }

    while (pCFor != pCBack) {
      while (!pCFor->qDeleted () && pCFor != pCBack) {
	if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
	pCFor = VATri.pTNext (pCFor);
	iNewSize++;
      }

      while (pCBack->qDeleted () && pCFor != pCBack)
	pCBack = VATri.pTPrev (pCBack);

      if (pCFor != pCBack) {
	assert (pCFor->qDeleted ());
	if(cell_map) cell_map->insert( std::make_pair(pCBack, pCFor) );
	iNewSize++;
	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pCFor->iNumFaces (); i++) {
	  assert (pCFor->pFFace (i)->iFullCheck ());
	}
#endif
	pCFor = VATri.pTNext (pCFor);
      }
      // Allow for the case where nothing has been deleted
      else if (!pCFor->qDeleted ()) {
	if(cell_map) cell_map->insert( std::make_pair(pCFor, pCFor) );
	iNewSize++;
      }
    }				// Loop over triangles
    // Reset the number of tri cells in use

    VATri.vSetup (iNewSize);
  }				// Contex for loop over triangles

  {
    QuadCell *pCFor = VAQuad.pTFirst ();
    QuadCell *pCBack = VAQuad.pTLast ();
    int iNewSize = 0;
    // The case of exactly one valid cell
    if (pCFor == pCBack &&
	pCFor != pCInvalidCell &&
	!pCFor->qDeleted ())
      iNewSize++;
    while (pCFor != pCBack) {
      while (!pCFor->qDeleted () && pCFor != pCBack) {
	pCFor = VAQuad.pTNext (pCFor);
	iNewSize++;
      }

      while (pCBack->qDeleted () && pCFor != pCBack)
	pCBack = VAQuad.pTPrev (pCBack);

      if (pCFor != pCBack) {
	assert (pCFor->qDeleted ());
	iNewSize++;

	(*pCFor) = (*pCBack);
	pCBack->vMarkDeleted ();
#ifndef NDEBUG
	for (int i = 0; i < pCFor->iNumFaces (); i++)
	  assert (pCFor->pFFace (i)->iFullCheck ());
#endif
	pCFor = VAQuad.pTNext (pCFor);
      }
      // Allow for the case where nothing has been deleted
      else if (!pCFor->qDeleted ())
	iNewSize++;
    }				// Loop over quads
    // Reset the number of quad cells in use

    VAQuad.vSetup (iNewSize);
  }				// Context for loop over quads
}
