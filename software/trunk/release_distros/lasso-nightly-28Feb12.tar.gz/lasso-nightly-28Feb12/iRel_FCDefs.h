/* iBase_FCDefs.h.  Generated from iBase_FCDefs.h.in by configure.  */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#define IREL_FC_FUNC(name,NAME) name ## _

/* As IREL_FC_FUNC, but for C identifiers containing underscores. */
#define IREL_FC_FUNC_(name,NAME) name ## _
